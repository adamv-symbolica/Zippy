#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_7(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_8(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Path n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Path n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Path n44(Context&, const Env&);
static ZIPPY_NOINLINE Path n45(Context&, const Env&);
static ZIPPY_NOINLINE Path n46(Context&, const Env&);
static ZIPPY_NOINLINE Path n47(Context&, const Env&);
static ZIPPY_NOINLINE Path n48(Context&, const Env&);
static ZIPPY_NOINLINE Path n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Path n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Path n64(Context&, const Env&);
static ZIPPY_NOINLINE Path n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Path n67(Context&, const Env&);
static ZIPPY_NOINLINE Path n68(Context&, const Env&);
static ZIPPY_NOINLINE Path n69(Context&, const Env&);
static ZIPPY_NOINLINE Path n70(Context&, const Env&);
static ZIPPY_NOINLINE Path n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Path n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Space n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Path n88(Context&, const Env&);
static ZIPPY_NOINLINE Path n89(Context&, const Env&);
static ZIPPY_NOINLINE Path n90(Context&, const Env&);
static ZIPPY_NOINLINE Path n91(Context&, const Env&);
static ZIPPY_NOINLINE Path n92(Context&, const Env&);
static ZIPPY_NOINLINE Path n93(Context&, const Env&);
static ZIPPY_NOINLINE Path n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Path n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Path n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Space n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Path n110(Context&, const Env&);
static ZIPPY_NOINLINE Path n111(Context&, const Env&);
static ZIPPY_NOINLINE Path n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Path n114(Context&, const Env&);
static ZIPPY_NOINLINE Path n115(Context&, const Env&);
static ZIPPY_NOINLINE Path n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Space n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Path n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Path n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n127(Context&, const Env&);
static ZIPPY_NOINLINE Path n128(Context&, const Env&);
static ZIPPY_NOINLINE Space n129(Context&, const Env&);
static ZIPPY_NOINLINE Space n130(Context&, const Env&);
static ZIPPY_NOINLINE Space n131(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n132(Context&, const Env&);
static ZIPPY_NOINLINE Path n133(Context&, const Env&);
static ZIPPY_NOINLINE Space n134(Context&, const Env&);
static ZIPPY_NOINLINE Space n135(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Space n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Space n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Path n143(Context&, const Env&);
static ZIPPY_NOINLINE Path n144(Context&, const Env&);
static ZIPPY_NOINLINE Path n145(Context&, const Env&);
static ZIPPY_NOINLINE Path n146(Context&, const Env&);
static ZIPPY_NOINLINE Path n147(Context&, const Env&);
static ZIPPY_NOINLINE Path n148(Context&, const Env&);
static ZIPPY_NOINLINE Path n149(Context&, const Env&);
static ZIPPY_NOINLINE Path n150(Context&, const Env&);
static ZIPPY_NOINLINE Space n151(Context&, const Env&);
static ZIPPY_NOINLINE Space n152(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_4(Context&, const Env&);
static ZIPPY_NOINLINE Space n153(Context&, const Env&);
static ZIPPY_NOINLINE Path n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Space n157(Context&, const Env&);
static ZIPPY_NOINLINE Space n158(Context&, const Env&);
static ZIPPY_NOINLINE Space n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Space n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Path n164(Context&, const Env&);
static ZIPPY_NOINLINE Path n165(Context&, const Env&);
static ZIPPY_NOINLINE Path n166(Context&, const Env&);
static ZIPPY_NOINLINE Path n167(Context&, const Env&);
static ZIPPY_NOINLINE Path n168(Context&, const Env&);
static ZIPPY_NOINLINE Path n169(Context&, const Env&);
static ZIPPY_NOINLINE Path n170(Context&, const Env&);
static ZIPPY_NOINLINE Path n171(Context&, const Env&);
static ZIPPY_NOINLINE Space n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_6(Context&, const Env&);
static ZIPPY_NOINLINE Space n174(Context&, const Env&);
static ZIPPY_NOINLINE Path n175(Context&, const Env&);
static ZIPPY_NOINLINE Space n176(Context&, const Env&);
static ZIPPY_NOINLINE Space n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Space n179(Context&, const Env&);
static ZIPPY_NOINLINE Space n180(Context&, const Env&);
static ZIPPY_NOINLINE Space n181(Context&, const Env&);
static ZIPPY_NOINLINE Space n182(Context&, const Env&);
static ZIPPY_NOINLINE Space n183(Context&, const Env&);
static ZIPPY_NOINLINE Space n184(Context&, const Env&);
static ZIPPY_NOINLINE Path n185(Context&, const Env&);
static ZIPPY_NOINLINE Path n186(Context&, const Env&);
static ZIPPY_NOINLINE Path n187(Context&, const Env&);
static ZIPPY_NOINLINE Path n188(Context&, const Env&);
static ZIPPY_NOINLINE Path n189(Context&, const Env&);
static ZIPPY_NOINLINE Path n190(Context&, const Env&);
static ZIPPY_NOINLINE Path n191(Context&, const Env&);
static ZIPPY_NOINLINE Path n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Space n194(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Space n196(Context&, const Env&);
static ZIPPY_NOINLINE Path n197(Context&, const Env&);
static ZIPPY_NOINLINE Space n198(Context&, const Env&);
static ZIPPY_NOINLINE Path n199(Context&, const Env&);
static ZIPPY_NOINLINE Space n200(Context&, const Env&);
static ZIPPY_NOINLINE Path n201(Context&, const Env&);
static ZIPPY_NOINLINE Space n202(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_3(Context&, const Env&);
static ZIPPY_NOINLINE Space n204(Context&, const Env&);
static ZIPPY_NOINLINE Space n205(Context&, const Env&);
static ZIPPY_NOINLINE Path n206(Context&, const Env&);
static ZIPPY_NOINLINE Space n207(Context&, const Env&);
static ZIPPY_NOINLINE Path n208(Context&, const Env&);
static ZIPPY_NOINLINE Space n209(Context&, const Env&);
static ZIPPY_NOINLINE Path n210(Context&, const Env&);
static ZIPPY_NOINLINE Space n211(Context&, const Env&);
static ZIPPY_NOINLINE Space n212(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_5(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Space n214(Context&, const Env&);
static ZIPPY_NOINLINE Path n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Path n217(Context&, const Env&);
static ZIPPY_NOINLINE Space n218(Context&, const Env&);
static ZIPPY_NOINLINE Path n219(Context&, const Env&);
static ZIPPY_NOINLINE Space n220(Context&, const Env&);
static ZIPPY_NOINLINE Space n221(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context& c, const Env& e) { return Path{1,1,1,1,1,1,1,2}; }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{}; Env n;   return routine_7(c,n); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto p=n1(c,e); return unwrap(n2(c,e),p); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { static const Space value=literal_text("94 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 9"); return value; }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { static const Space value=literal_text("184 16 1 1 1 1 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 2 1 1 1 28 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 11"); return value; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n6(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_8(c,n); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto a=n4(c,e); auto b=n5(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_7(Context& c,const Env& e) { return n3(c,e); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { auto p=n16(c,e); return unwrap(n17(c,e),p); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return Path{1,1,1,29}; }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { auto p=n19(c,e); return unwrap(n20(c,e),p); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n18(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto p=n13(c,e); return wrap(n14(c,e),p); }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return Path{1,1,1,29,1,1,1,2}; }
static ZIPPY_NOINLINE Path n30(Context& c, const Env& e) { return Path{1,1,1,3}; }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto p=n32(c,e); return unwrap(n33(c,e),p); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { auto p=n30(c,e); return unwrap(n31(c,e),p); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n45(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n46(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n44(Context& c, const Env& e) { auto a=n45(c,e); auto b=n46(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n47(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { auto a=n44(c,e); auto b=n47(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n48(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n42(Context& c, const Env& e) { auto a=n43(c,e); auto b=n48(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n49(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { auto a=n42(c,e); auto b=n49(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { std::vector<Path> pv{n41(c,e)}; std::vector<Space> sv{n50(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[5]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { return iterate(c,e,n39(c,e),3,4,n40); }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { return iterate(c,e,n37(c,e),2,3,n38); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { return iterate(c,e,n35(c,e),1,2,n36); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return iterate(c,e,n29(c,e),0,1,n34); }
static ZIPPY_NOINLINE Path n53(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { auto p=n55(c,e); return unwrap(n56(c,e),p); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { auto p=n53(c,e); return unwrap(n54(c,e),p); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Path n68(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n67(Context& c, const Env& e) { auto a=n45(c,e); auto b=n68(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n69(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { auto a=n67(c,e); auto b=n69(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n70(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n65(Context& c, const Env& e) { auto a=n66(c,e); auto b=n70(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n71(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n64(Context& c, const Env& e) { auto a=n65(c,e); auto b=n71(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { std::vector<Path> pv{n64(c,e)}; std::vector<Space> sv{n72(c,e),n73(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[10]=sv[0];n.spaces[0]=sv[1];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { return iterate(c,e,n62(c,e),8,9,n63); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { return iterate(c,e,n60(c,e),7,8,n61); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { return iterate(c,e,n58(c,e),6,7,n59); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { return iterate(c,e,n52(c,e),5,6,n57); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n51(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n76(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return Path{1,1,1,29}; }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { auto p=n78(c,e); return unwrap(n79(c,e),p); }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { auto p=n76(c,e); return unwrap(n77(c,e),p); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Path n91(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n90(Context& c, const Env& e) { auto a=n45(c,e); auto b=n91(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n92(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n89(Context& c, const Env& e) { auto a=n90(c,e); auto b=n92(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n93(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n88(Context& c, const Env& e) { auto a=n89(c,e); auto b=n93(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n94(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { auto a=n88(c,e); auto b=n94(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { std::vector<Path> pv{n87(c,e)}; std::vector<Space> sv{n95(c,e),n96(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[15]=sv[0];n.spaces[0]=sv[1];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return iterate(c,e,n85(c,e),13,14,n86); }
static ZIPPY_NOINLINE Space n82(Context& c, const Env& e) { return iterate(c,e,n83(c,e),12,13,n84); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return iterate(c,e,n81(c,e),11,12,n82); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { return iterate(c,e,n75(c,e),10,11,n80); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n74(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n99(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n101(Context& c, const Env& e) { return Path{1,1,1,29}; }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { auto p=n101(c,e); return unwrap(n102(c,e),p); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { auto p=n99(c,e); return unwrap(n100(c,e),p); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { return e.spaces.at(17); }
static ZIPPY_NOINLINE Space n108(Context& c, const Env& e) { return e.spaces.at(18); }
static ZIPPY_NOINLINE Path n114(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { auto a=n45(c,e); auto b=n114(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n115(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Path n112(Context& c, const Env& e) { auto a=n113(c,e); auto b=n115(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n116(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n111(Context& c, const Env& e) { auto a=n112(c,e); auto b=n116(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n110(Context& c, const Env& e) { auto a=n111(c,e); auto b=n117(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n118(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n119(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { std::vector<Path> pv{n110(c,e)}; std::vector<Space> sv{n118(c,e),n119(c,e)}; Env n; n.paths[19]=pv[0];n.spaces[20]=sv[0];n.spaces[0]=sv[1];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { return iterate(c,e,n108(c,e),18,19,n109); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { return iterate(c,e,n106(c,e),17,18,n107); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { return iterate(c,e,n104(c,e),16,17,n105); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { return iterate(c,e,n98(c,e),15,16,n103); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n97(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n121(Context& c, const Env& e) { return Path{1,1,1,1,1,1,1,2}; }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { auto p=n121(c,e); return unwrap(n122(c,e),p); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { auto a=n25(c,e); auto b=n120(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n124(Context& c, const Env& e) { return Path{1,1,1,29,1,1,1,2}; }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { auto p=n124(c,e); return unwrap(n125(c,e),p); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto a=n24(c,e); auto b=n123(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { auto p=n22(c,e); return wrap(n23(c,e),p); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { auto a=n12(c,e); auto b=n21(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto a=n11(c,e); auto b=n126(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n10(c,e)}; Env n; n.spaces[0]=sv[0]; if(equal(n10(c,n),sv[0])) return n8(c,n); return routine_8(c,n); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto a=n8(c,e); auto b=n9(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_8(Context& c,const Env& e) { return n7(c,e); }
static ZIPPY_NOINLINE Path n128(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n130(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n131(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n129(Context& c, const Env& e) { auto a=n130(c,e); auto b=n131(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n127(Context& c, const Env& e) { auto p=n128(c,e); return wrap(n129(c,e),p); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n127(c,e); }
static ZIPPY_NOINLINE Path n133(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n135(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Path n147(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n146(Context& c, const Env& e) { auto a=n45(c,e); auto b=n147(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n148(Context& c, const Env& e) { return e.paths.at(21); }
static ZIPPY_NOINLINE Path n145(Context& c, const Env& e) { auto a=n146(c,e); auto b=n148(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n149(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n144(Context& c, const Env& e) { auto a=n145(c,e); auto b=n149(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n150(Context& c, const Env& e) { return e.paths.at(23); }
static ZIPPY_NOINLINE Path n143(Context& c, const Env& e) { auto a=n144(c,e); auto b=n150(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n151(Context& c, const Env& e) { return e.spaces.at(24); }
static ZIPPY_NOINLINE Space n152(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { std::vector<Path> pv{n143(c,e)}; std::vector<Space> sv{n151(c,e),n152(c,e)}; Env n; n.paths[24]=pv[0];n.spaces[25]=sv[0];n.spaces[0]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n140(Context& c, const Env& e) { return iterate(c,e,n141(c,e),23,24,n142); }
static ZIPPY_NOINLINE Space n138(Context& c, const Env& e) { return iterate(c,e,n139(c,e),22,23,n140); }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return iterate(c,e,n137(c,e),21,22,n138); }
static ZIPPY_NOINLINE Space n134(Context& c, const Env& e) { return iterate(c,e,n135(c,e),20,21,n136); }
static ZIPPY_NOINLINE Space n132(Context& c, const Env& e) { auto p=n133(c,e); return wrap(n134(c,e),p); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n132(c,e); }
static ZIPPY_NOINLINE Path n154(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n158(Context& c, const Env& e) { return e.spaces.at(26); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { return e.spaces.at(28); }
static ZIPPY_NOINLINE Path n168(Context& c, const Env& e) { return e.paths.at(25); }
static ZIPPY_NOINLINE Path n167(Context& c, const Env& e) { auto a=n45(c,e); auto b=n168(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n169(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n166(Context& c, const Env& e) { auto a=n167(c,e); auto b=n169(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n170(Context& c, const Env& e) { return e.paths.at(27); }
static ZIPPY_NOINLINE Path n165(Context& c, const Env& e) { auto a=n166(c,e); auto b=n170(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n171(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n164(Context& c, const Env& e) { auto a=n165(c,e); auto b=n171(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n172(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { std::vector<Path> pv{n164(c,e)}; std::vector<Space> sv{n172(c,e),n173(c,e)}; Env n; n.paths[29]=pv[0];n.spaces[30]=sv[0];n.spaces[0]=sv[1];  return routine_3(c,n); }
static ZIPPY_NOINLINE Space n161(Context& c, const Env& e) { return iterate(c,e,n162(c,e),28,29,n163); }
static ZIPPY_NOINLINE Space n159(Context& c, const Env& e) { return iterate(c,e,n160(c,e),27,28,n161); }
static ZIPPY_NOINLINE Space n157(Context& c, const Env& e) { return iterate(c,e,n158(c,e),26,27,n159); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { return iterate(c,e,n156(c,e),25,26,n157); }
static ZIPPY_NOINLINE Space n153(Context& c, const Env& e) { auto p=n154(c,e); return wrap(n155(c,e),p); }
static ZIPPY_NOINLINE Space routine_4(Context& c,const Env& e) { return n153(c,e); }
static ZIPPY_NOINLINE Path n175(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Space n177(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n179(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Space n181(Context& c, const Env& e) { return e.spaces.at(32); }
static ZIPPY_NOINLINE Space n183(Context& c, const Env& e) { return e.spaces.at(33); }
static ZIPPY_NOINLINE Path n189(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Path n188(Context& c, const Env& e) { auto a=n45(c,e); auto b=n189(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n190(Context& c, const Env& e) { return e.paths.at(31); }
static ZIPPY_NOINLINE Path n187(Context& c, const Env& e) { auto a=n188(c,e); auto b=n190(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n191(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n186(Context& c, const Env& e) { auto a=n187(c,e); auto b=n191(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n192(Context& c, const Env& e) { return e.paths.at(33); }
static ZIPPY_NOINLINE Path n185(Context& c, const Env& e) { auto a=n186(c,e); auto b=n192(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { return e.spaces.at(34); }
static ZIPPY_NOINLINE Space n194(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n184(Context& c, const Env& e) { std::vector<Path> pv{n185(c,e)}; std::vector<Space> sv{n193(c,e),n194(c,e)}; Env n; n.paths[34]=pv[0];n.spaces[35]=sv[0];n.spaces[0]=sv[1];  return routine_5(c,n); }
static ZIPPY_NOINLINE Space n182(Context& c, const Env& e) { return iterate(c,e,n183(c,e),33,34,n184); }
static ZIPPY_NOINLINE Space n180(Context& c, const Env& e) { return iterate(c,e,n181(c,e),32,33,n182); }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { return iterate(c,e,n179(c,e),31,32,n180); }
static ZIPPY_NOINLINE Space n176(Context& c, const Env& e) { return iterate(c,e,n177(c,e),30,31,n178); }
static ZIPPY_NOINLINE Space n174(Context& c, const Env& e) { auto p=n175(c,e); return wrap(n176(c,e),p); }
static ZIPPY_NOINLINE Space routine_6(Context& c,const Env& e) { return n174(c,e); }
static ZIPPY_NOINLINE Path n197(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n199(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n201(Context& c, const Env& e) { return Path{1,1,1,29}; }
static ZIPPY_NOINLINE Space n202(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n200(Context& c, const Env& e) { auto p=n201(c,e); return unwrap(n202(c,e),p); }
static ZIPPY_NOINLINE Space n198(Context& c, const Env& e) { auto p=n199(c,e); return unwrap(n200(c,e),p); }
static ZIPPY_NOINLINE Space n196(Context& c, const Env& e) { auto p=n197(c,e); return unwrap(n198(c,e),p); }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { auto a=n196(c,e); auto b=n203(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n195(c,e); }
static ZIPPY_NOINLINE Path n206(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n208(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n210(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n211(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n209(Context& c, const Env& e) { auto p=n210(c,e); return unwrap(n211(c,e),p); }
static ZIPPY_NOINLINE Space n207(Context& c, const Env& e) { auto p=n208(c,e); return unwrap(n209(c,e),p); }
static ZIPPY_NOINLINE Space n205(Context& c, const Env& e) { auto p=n206(c,e); return unwrap(n207(c,e),p); }
static ZIPPY_NOINLINE Space n212(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n204(Context& c, const Env& e) { auto a=n205(c,e); auto b=n212(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space routine_3(Context& c,const Env& e) { return n204(c,e); }
static ZIPPY_NOINLINE Path n215(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Path n217(Context& c, const Env& e) { return Path{1,1,1,2}; }
static ZIPPY_NOINLINE Path n219(Context& c, const Env& e) { return Path{1,1,1,29}; }
static ZIPPY_NOINLINE Space n220(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n218(Context& c, const Env& e) { auto p=n219(c,e); return unwrap(n220(c,e),p); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { auto p=n217(c,e); return unwrap(n218(c,e),p); }
static ZIPPY_NOINLINE Space n214(Context& c, const Env& e) { auto p=n215(c,e); return unwrap(n216(c,e),p); }
static ZIPPY_NOINLINE Space n221(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { auto a=n214(c,e); auto b=n221(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space routine_5(Context& c,const Env& e) { return n213(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
