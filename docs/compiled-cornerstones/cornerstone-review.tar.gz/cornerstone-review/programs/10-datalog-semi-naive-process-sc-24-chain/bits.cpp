#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("94 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 2 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 1 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 1 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 1 1 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 1 2 1 2 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 1 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 1 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 1 2 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 1 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 20 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 1 1 1 2 2 20 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 2 1 1 2 2 22 2 2 1 1 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 22 2 2 1 1 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 18 2 2 1 1 2 2 1 1 1 1 2 2 1 2 1 1 2 2 18 2 2 1 1 2 2 1 1 1 1 2 2 2 1 1 1 2 2 22 2 2 1 1 2 2 1 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 22 2 2 1 1 2 2 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 21 2 2 1 1 2 2 1 1 1 2 1 2 2 1 1 1 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 16 2 2 1 1 2 2 1 1 1 2 2 1 2 1 2 2 16 2 2 1 1 2 2 1 1 1 2 2 2 1 1 2 2 22 2 2 1 1 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 22 2 2 1 1 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 20 2 2 1 1 2 2 1 1 2 1 1 2 2 1 1 1 2 1 2 2 20 2 2 1 1 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 19 2 2 1 1 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 18 2 2 1 1 2 2 1 1 2 1 2 2 2 1 2 1 2 2 20 2 2 1 1 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 18 2 2 1 1 2 2 1 2 1 1 2 2 1 1 2 1 2 2 18 2 2 1 1 2 2 1 2 1 1 2 2 2 1 2 1 2 2 20 2 2 1 1 2 2 1 2 1 2 1 1 2 2 1 1 1 1 2 2 20 2 2 1 1 2 2 1 2 1 2 1 1 2 2 2 1 1 1 2 2 21 2 2 1 1 2 2 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 21 2 2 1 1 2 2 1 2 1 2 1 2 2 2 1 2 1 1 1 2 2 19 2 2 1 1 2 2 1 2 1 2 2 1 1 2 1 1 1 2 2 18 2 2 1 1 2 2 1 2 1 2 2 1 2 1 2 1 2 2 22 2 2 1 1 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 20 2 2 1 1 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 18 2 2 1 1 2 2 2 1 1 1 2 2 1 1 2 1 2 2 18 2 2 1 1 2 2 2 1 1 1 2 2 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 1 2 1 1 2 2 1 1 1 1 2 2 22 2 2 1 1 2 2 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 21 2 2 1 1 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 21 2 2 1 1 2 2 2 1 1 2 1 2 2 2 1 1 1 1 1 2 2 18 2 2 1 1 2 2 2 1 1 2 2 1 2 1 2 1 2 2 16 2 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2 22 2 2 1 1 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 22 2 2 1 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 2 1 1 2 2 1 1 1 2 1 2 2 20 2 2 1 1 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 19 2 2 1 1 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 19 2 2 1 1 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 15 2 2 1 1 2 2 2 1 2 2 1 1 1 2 2 15 2 2 1 1 2 2 2 1 2 2 2 1 1 2 2");
static const Space constant_1 = literal_text("184 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 1 2 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 2 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 1 1 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 2 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 1 1 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 1 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 1 1 1 2 2 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 1 2 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 1 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 1 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 2 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 2 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 1 2 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 1 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 2 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 2 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 1 2 2 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 1 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 2 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 1 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 1 1 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 1 2 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 1 2 1 2 2 2 1 2 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 1 2 2 2 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 1 2 2 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 2 2 1 2 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 1 2 2 2 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 1 1 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 1 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 1 2 2 2 1 2 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 1 1 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 1 2 1 2 1 1 2 2 27 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 1 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 1 1 1 2 1 2 2 26 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 2 1 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 1 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 20 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 1 1 1 2 2 22 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 1 2 1 2 2 20 1 1 1 1 2 1 2 2 1 2 2 2 1 2 2 2 1 1 2 2 22 2 2 1 1 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 22 2 2 1 1 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 18 2 2 1 1 2 2 1 1 1 1 2 2 1 2 1 1 2 2 18 2 2 1 1 2 2 1 1 1 1 2 2 2 1 1 1 2 2 22 2 2 1 1 2 2 1 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 22 2 2 1 1 2 2 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 21 2 2 1 1 2 2 1 1 1 2 1 2 2 1 1 1 1 1 1 2 2 20 2 2 1 1 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 16 2 2 1 1 2 2 1 1 1 2 2 1 2 1 2 2 16 2 2 1 1 2 2 1 1 1 2 2 2 1 1 2 2 22 2 2 1 1 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 22 2 2 1 1 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 20 2 2 1 1 2 2 1 1 2 1 1 2 2 1 1 1 2 1 2 2 20 2 2 1 1 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 19 2 2 1 1 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 18 2 2 1 1 2 2 1 1 2 1 2 2 2 1 2 1 2 2 20 2 2 1 1 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 18 2 2 1 1 2 2 1 2 1 1 2 2 1 1 2 1 2 2 18 2 2 1 1 2 2 1 2 1 1 2 2 2 1 2 1 2 2 20 2 2 1 1 2 2 1 2 1 2 1 1 2 2 1 1 1 1 2 2 20 2 2 1 1 2 2 1 2 1 2 1 1 2 2 2 1 1 1 2 2 21 2 2 1 1 2 2 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 21 2 2 1 1 2 2 1 2 1 2 1 2 2 2 1 2 1 1 1 2 2 19 2 2 1 1 2 2 1 2 1 2 2 1 1 2 1 1 1 2 2 18 2 2 1 1 2 2 1 2 1 2 2 1 2 1 2 1 2 2 22 2 2 1 1 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 20 2 2 1 1 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 18 2 2 1 1 2 2 2 1 1 1 2 2 1 1 2 1 2 2 18 2 2 1 1 2 2 2 1 1 1 2 2 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 1 2 1 1 2 2 1 1 1 1 2 2 22 2 2 1 1 2 2 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 21 2 2 1 1 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 21 2 2 1 1 2 2 2 1 1 2 1 2 2 2 1 1 1 1 1 2 2 18 2 2 1 1 2 2 2 1 1 2 2 1 2 1 2 1 2 2 16 2 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2 22 2 2 1 1 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 22 2 2 1 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 20 2 2 1 1 2 2 2 1 2 1 1 2 2 1 1 1 2 1 2 2 20 2 2 1 1 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 19 2 2 1 1 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 19 2 2 1 1 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 15 2 2 1 1 2 2 2 1 2 2 1 1 1 2 2 15 2 2 1 1 2 2 2 1 2 2 2 1 1 2 2 21 2 2 1 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 21 2 2 1 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 19 2 2 1 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 19 2 2 1 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 17 2 2 1 2 2 1 1 1 1 2 2 1 2 1 1 2 2 17 2 2 1 2 2 1 1 1 1 2 2 2 1 1 1 2 2 21 2 2 1 2 2 1 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 21 2 2 1 2 2 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 20 2 2 1 2 2 1 1 1 2 1 2 2 1 1 1 1 1 1 2 2 19 2 2 1 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 15 2 2 1 2 2 1 1 1 2 2 1 2 1 2 2 15 2 2 1 2 2 1 1 1 2 2 2 1 1 2 2 21 2 2 1 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 21 2 2 1 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 19 2 2 1 2 2 1 1 2 1 1 2 2 1 1 1 2 1 2 2 19 2 2 1 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 18 2 2 1 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 17 2 2 1 2 2 1 1 2 1 2 2 2 1 2 1 2 2 19 2 2 1 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 19 2 2 1 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 17 2 2 1 2 2 1 2 1 1 2 2 1 1 2 1 2 2 17 2 2 1 2 2 1 2 1 1 2 2 2 1 2 1 2 2 19 2 2 1 2 2 1 2 1 2 1 1 2 2 1 1 1 1 2 2 19 2 2 1 2 2 1 2 1 2 1 1 2 2 2 1 1 1 2 2 20 2 2 1 2 2 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 20 2 2 1 2 2 1 2 1 2 1 2 2 2 1 2 1 1 1 2 2 18 2 2 1 2 2 1 2 1 2 2 1 1 2 1 1 1 2 2 17 2 2 1 2 2 1 2 1 2 2 1 2 1 2 1 2 2 21 2 2 1 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 19 2 2 1 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 19 2 2 1 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 17 2 2 1 2 2 2 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 2 2 2 1 1 1 2 2 1 2 1 1 2 2 19 2 2 1 2 2 2 1 1 2 1 1 2 2 1 1 1 1 2 2 21 2 2 1 2 2 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 2 20 2 2 1 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 20 2 2 1 2 2 2 1 1 2 1 2 2 2 1 1 1 1 1 2 2 17 2 2 1 2 2 2 1 1 2 2 1 2 1 2 1 2 2 15 2 2 1 2 2 2 1 1 2 2 1 2 1 2 2 21 2 2 1 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 21 2 2 1 2 2 2 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 19 2 2 1 2 2 2 1 2 1 1 2 2 1 1 1 2 1 2 2 19 2 2 1 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 18 2 2 1 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 18 2 2 1 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 14 2 2 1 2 2 2 1 2 2 1 1 1 2 2 14 2 2 1 2 2 2 1 2 2 2 1 1 2 2");
static const Path constant_2 = Path{2,2,1,2,2};
static const Path constant_3 = Path{1,1,1,1,2,1,2,2};
static const Path constant_4 = Path{1,2,2};
static const Space constant_5 = literal_text("1 0 ");
static const Space constant_6 = literal_text("1 1 2");
static const Space constant_7 = singleton(Path{});
static const Path constant_8 = Path{2,2};
static const Path constant_9 = Path{1,1,2,2};
static const Path constant_10 = Path{1,1,1,1,2,1,2,2,1,2,2};
static Space routine_0(Context& c);
static Space routine_16(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_25(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_39(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_40(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_47(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_48(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_65(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_61(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_66(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_62(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_67(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_43(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_68(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_64(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_69(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_71(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_70(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_27(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_2 = routine_1(c, constant_1);
  const Space v0_3 = unite(constant_0,v0_2);
  const Space v0_5 = unwrap(v0_3,constant_2);
  return v0_5;
}

static Space routine_1(Context& c, const Space& s0) {
  const Space v1_2 = unwrap(s0,constant_3);
  const Space v1_4 = unwrap(v1_2,constant_4);
  Space v1_14_result;
  for (int v1_14_label = 1; v1_14_label <= 2; ++v1_14_label) {
    const Space v1_14_tail = child(v1_4,v1_14_label);
    if (v1_14_tail.empty()) continue;
    const Path v1_14_head{v1_14_label};
    const Space v2_2 = singleton(v1_14_head);
    const Space v2_3 = intersect(constant_6,v2_2);
    const Space v2_4 = (has_head(v2_3) ? constant_7 : Space{});
    const Space v2_5 = subtract(constant_5,v2_4);
    Space v2_7;
    if (!v2_5.empty()) {
      Space v3_6_result;
      for (int v3_6_label = 1; v3_6_label <= 2; ++v3_6_label) {
        const Space v3_6_tail = child(v1_14_tail,v3_6_label);
        if (v3_6_tail.empty()) continue;
        const Path v3_6_head{v3_6_label};
        const Space v4_2 = singleton(v3_6_head);
        const Space v4_3 = intersect(constant_6,v4_2);
        const Space v4_4 = (has_head(v4_3) ? constant_7 : Space{});
        const Space v4_5 = subtract(constant_5,v4_4);
        Space v4_8;
        if (!v4_5.empty()) {
          const Path v5_6 = concat_path(v1_14_head,v3_6_head);
          const Space v5_7 = routine_2(c, v5_6, v3_6_tail, s0);
          v4_8 = compose(v4_5,v5_7);
        }
        const Space v4_9 = intersect(constant_6,v4_2);
        const Space v4_10 = (has_head(v4_9) ? constant_7 : Space{});
        Space v4_12;
        if (!v4_10.empty()) {
          const Path v6_6 = concat_path(v1_14_head,v3_6_head);
          const Space v6_11 = routine_3(c, v6_6, v3_6_tail, s0);
          v4_12 = compose(v4_10,v6_11);
        }
        const Space v4_13 = unite(v4_8,v4_12);
        v3_6_result = unite(v3_6_result,v4_13);
      }
      const Space v3_6 = std::move(v3_6_result);
      v2_7 = compose(v2_5,v3_6);
    }
    const Space v2_8 = intersect(constant_6,v2_2);
    const Space v2_9 = (has_head(v2_8) ? constant_7 : Space{});
    Space v2_11;
    if (!v2_9.empty()) {
      Space v7_10_result;
      for (int v7_10_label = 1; v7_10_label <= 2; ++v7_10_label) {
        const Space v7_10_tail = child(v1_14_tail,v7_10_label);
        if (v7_10_tail.empty()) continue;
        const Path v7_10_head{v7_10_label};
        const Space v8_2 = singleton(v7_10_head);
        const Space v8_3 = intersect(constant_6,v8_2);
        const Space v8_4 = (has_head(v8_3) ? constant_7 : Space{});
        const Space v8_5 = subtract(constant_5,v8_4);
        Space v8_8;
        if (!v8_5.empty()) {
          const Path v9_6 = concat_path(v1_14_head,v7_10_head);
          const Space v9_7 = routine_2(c, v9_6, v7_10_tail, s0);
          v8_8 = compose(v8_5,v9_7);
        }
        const Space v8_9 = intersect(constant_6,v8_2);
        const Space v8_10 = (has_head(v8_9) ? constant_7 : Space{});
        Space v8_12;
        if (!v8_10.empty()) {
          const Path v10_6 = concat_path(v1_14_head,v7_10_head);
          const Space v10_11 = routine_4(c, v10_6, v7_10_tail, s0);
          v8_12 = compose(v8_10,v10_11);
        }
        const Space v8_13 = unite(v8_8,v8_12);
        v7_10_result = unite(v7_10_result,v8_13);
      }
      const Space v7_10 = std::move(v7_10_result);
      v2_11 = compose(v2_9,v7_10);
    }
    const Space v2_12 = unite(v2_7,v2_11);
    v1_14_result = unite(v1_14_result,v2_12);
  }
  const Space v1_14 = std::move(v1_14_result);
  Space v1_24_result;
  for (int v1_24_label = 1; v1_24_label <= 2; ++v1_24_label) {
    const Space v1_24_tail = child(v1_4,v1_24_label);
    if (v1_24_tail.empty()) continue;
    const Path v1_24_head{v1_24_label};
    const Space v11_2 = singleton(v1_24_head);
    const Space v11_3 = intersect(constant_6,v11_2);
    const Space v11_4 = (has_head(v11_3) ? constant_7 : Space{});
    const Space v11_5 = subtract(constant_5,v11_4);
    Space v11_7;
    if (!v11_5.empty()) {
      Space v12_6_result;
      for (int v12_6_label = 1; v12_6_label <= 2; ++v12_6_label) {
        const Space v12_6_tail = child(v1_24_tail,v12_6_label);
        if (v12_6_tail.empty()) continue;
        const Path v12_6_head{v12_6_label};
        const Space v13_2 = singleton(v12_6_head);
        const Space v13_3 = intersect(constant_6,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_7 : Space{});
        const Space v13_5 = subtract(constant_5,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v1_24_head,v12_6_head);
          const Space v14_7 = routine_5(c, v14_6, v12_6_tail, s0);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_6,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_7 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v1_24_head,v12_6_head);
          const Space v15_11 = routine_6(c, v15_6, v12_6_tail, s0);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_6_result = unite(v12_6_result,v13_13);
      }
      const Space v12_6 = std::move(v12_6_result);
      v11_7 = compose(v11_5,v12_6);
    }
    const Space v11_8 = intersect(constant_6,v11_2);
    const Space v11_9 = (has_head(v11_8) ? constant_7 : Space{});
    Space v11_11;
    if (!v11_9.empty()) {
      Space v16_10_result;
      for (int v16_10_label = 1; v16_10_label <= 2; ++v16_10_label) {
        const Space v16_10_tail = child(v1_24_tail,v16_10_label);
        if (v16_10_tail.empty()) continue;
        const Path v16_10_head{v16_10_label};
        const Space v17_2 = singleton(v16_10_head);
        const Space v17_3 = intersect(constant_6,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_7 : Space{});
        const Space v17_5 = subtract(constant_5,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v1_24_head,v16_10_head);
          const Space v18_7 = routine_5(c, v18_6, v16_10_tail, s0);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_6,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_7 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v1_24_head,v16_10_head);
          const Space v19_11 = routine_7(c, v19_6, v16_10_tail, s0);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_10_result = unite(v16_10_result,v17_13);
      }
      const Space v16_10 = std::move(v16_10_result);
      v11_11 = compose(v11_9,v16_10);
    }
    const Space v11_12 = unite(v11_7,v11_11);
    v1_24_result = unite(v1_24_result,v11_12);
  }
  const Space v1_24 = std::move(v1_24_result);
  const Space v1_25 = unite(v1_14,v1_24);
  const Space v1_27 = unwrap(s0,constant_8);
  const Space v1_29 = unwrap(v1_27,constant_9);
  Space v1_39_result;
  for (int v1_39_label = 1; v1_39_label <= 2; ++v1_39_label) {
    const Space v1_39_tail = child(v1_29,v1_39_label);
    if (v1_39_tail.empty()) continue;
    const Path v1_39_head{v1_39_label};
    const Space v20_2 = singleton(v1_39_head);
    const Space v20_3 = intersect(constant_6,v20_2);
    const Space v20_4 = (has_head(v20_3) ? constant_7 : Space{});
    const Space v20_5 = subtract(constant_5,v20_4);
    Space v20_7;
    if (!v20_5.empty()) {
      Space v21_6_result;
      for (int v21_6_label = 1; v21_6_label <= 2; ++v21_6_label) {
        const Space v21_6_tail = child(v1_39_tail,v21_6_label);
        if (v21_6_tail.empty()) continue;
        const Path v21_6_head{v21_6_label};
        const Space v22_2 = singleton(v21_6_head);
        const Space v22_3 = intersect(constant_6,v22_2);
        const Space v22_4 = (has_head(v22_3) ? constant_7 : Space{});
        const Space v22_5 = subtract(constant_5,v22_4);
        Space v22_8;
        if (!v22_5.empty()) {
          const Path v23_6 = concat_path(v1_39_head,v21_6_head);
          const Space v23_7 = routine_8(c, v23_6, v21_6_tail);
          v22_8 = compose(v22_5,v23_7);
        }
        const Space v22_9 = intersect(constant_6,v22_2);
        const Space v22_10 = (has_head(v22_9) ? constant_7 : Space{});
        Space v22_12;
        if (!v22_10.empty()) {
          const Path v24_6 = concat_path(v1_39_head,v21_6_head);
          const Space v24_11 = routine_9(c, v24_6, v21_6_tail);
          v22_12 = compose(v22_10,v24_11);
        }
        const Space v22_13 = unite(v22_8,v22_12);
        v21_6_result = unite(v21_6_result,v22_13);
      }
      const Space v21_6 = std::move(v21_6_result);
      v20_7 = compose(v20_5,v21_6);
    }
    const Space v20_8 = intersect(constant_6,v20_2);
    const Space v20_9 = (has_head(v20_8) ? constant_7 : Space{});
    Space v20_11;
    if (!v20_9.empty()) {
      Space v25_10_result;
      for (int v25_10_label = 1; v25_10_label <= 2; ++v25_10_label) {
        const Space v25_10_tail = child(v1_39_tail,v25_10_label);
        if (v25_10_tail.empty()) continue;
        const Path v25_10_head{v25_10_label};
        const Space v26_2 = singleton(v25_10_head);
        const Space v26_3 = intersect(constant_6,v26_2);
        const Space v26_4 = (has_head(v26_3) ? constant_7 : Space{});
        const Space v26_5 = subtract(constant_5,v26_4);
        Space v26_8;
        if (!v26_5.empty()) {
          const Path v27_6 = concat_path(v1_39_head,v25_10_head);
          const Space v27_7 = routine_8(c, v27_6, v25_10_tail);
          v26_8 = compose(v26_5,v27_7);
        }
        const Space v26_9 = intersect(constant_6,v26_2);
        const Space v26_10 = (has_head(v26_9) ? constant_7 : Space{});
        Space v26_12;
        if (!v26_10.empty()) {
          const Path v28_6 = concat_path(v1_39_head,v25_10_head);
          const Space v28_11 = routine_10(c, v28_6, v25_10_tail);
          v26_12 = compose(v26_10,v28_11);
        }
        const Space v26_13 = unite(v26_8,v26_12);
        v25_10_result = unite(v25_10_result,v26_13);
      }
      const Space v25_10 = std::move(v25_10_result);
      v20_11 = compose(v20_9,v25_10);
    }
    const Space v20_12 = unite(v20_7,v20_11);
    v1_39_result = unite(v1_39_result,v20_12);
  }
  const Space v1_39 = std::move(v1_39_result);
  const Space v1_40 = unite(v1_25,v1_39);
  const Space v1_41 = unwrap(v1_27,constant_4);
  Space v1_51_result;
  for (int v1_51_label = 1; v1_51_label <= 2; ++v1_51_label) {
    const Space v1_51_tail = child(v1_41,v1_51_label);
    if (v1_51_tail.empty()) continue;
    const Path v1_51_head{v1_51_label};
    const Space v29_2 = singleton(v1_51_head);
    const Space v29_3 = intersect(constant_6,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_7 : Space{});
    const Space v29_5 = subtract(constant_5,v29_4);
    Space v29_7;
    if (!v29_5.empty()) {
      Space v30_6_result;
      for (int v30_6_label = 1; v30_6_label <= 2; ++v30_6_label) {
        const Space v30_6_tail = child(v1_51_tail,v30_6_label);
        if (v30_6_tail.empty()) continue;
        const Path v30_6_head{v30_6_label};
        const Space v31_2 = singleton(v30_6_head);
        const Space v31_3 = intersect(constant_6,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_7 : Space{});
        const Space v31_5 = subtract(constant_5,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v1_51_head,v30_6_head);
          const Space v32_7 = routine_11(c, v32_6, v30_6_tail, s0);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_6,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_7 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v1_51_head,v30_6_head);
          const Space v33_11 = routine_12(c, v33_6, v30_6_tail, s0);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_6_result = unite(v30_6_result,v31_13);
      }
      const Space v30_6 = std::move(v30_6_result);
      v29_7 = compose(v29_5,v30_6);
    }
    const Space v29_8 = intersect(constant_6,v29_2);
    const Space v29_9 = (has_head(v29_8) ? constant_7 : Space{});
    Space v29_11;
    if (!v29_9.empty()) {
      Space v34_10_result;
      for (int v34_10_label = 1; v34_10_label <= 2; ++v34_10_label) {
        const Space v34_10_tail = child(v1_51_tail,v34_10_label);
        if (v34_10_tail.empty()) continue;
        const Path v34_10_head{v34_10_label};
        const Space v35_2 = singleton(v34_10_head);
        const Space v35_3 = intersect(constant_6,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_7 : Space{});
        const Space v35_5 = subtract(constant_5,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v1_51_head,v34_10_head);
          const Space v36_7 = routine_11(c, v36_6, v34_10_tail, s0);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_6,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_7 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v1_51_head,v34_10_head);
          const Space v37_11 = routine_13(c, v37_6, v34_10_tail, s0);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_10_result = unite(v34_10_result,v35_13);
      }
      const Space v34_10 = std::move(v34_10_result);
      v29_11 = compose(v29_9,v34_10);
    }
    const Space v29_12 = unite(v29_7,v29_11);
    v1_51_result = unite(v1_51_result,v29_12);
  }
  const Space v1_51 = std::move(v1_51_result);
  const Space v1_52 = unite(v1_40,v1_51);
  const Space v1_54 = unwrap(s0,constant_2);
  const Space v1_55 = subtract(v1_52,v1_54);
  const Space v1_57 = unwrap(s0,constant_10);
  const Space v1_58 = subtract(v1_55,v1_57);
  const Space v1_59 = wrap(v1_58,constant_10);
  const Space v1_60 = unite(v1_2,v1_27);
  const Space v1_61 = wrap(v1_60,constant_8);
  const Space v1_62 = unite(v1_59,v1_61);
  const Space v1_63 = unite(v1_62,s0);
  Space v1_100 = v1_63;
  for (;;) {
    const Space v38_1 = unwrap(v1_100,constant_3);
    const Space v38_2 = unwrap(v38_1,constant_4);
    Space v38_3_result;
    for (int v38_3_label = 1; v38_3_label <= 2; ++v38_3_label) {
      const Space v38_3_tail = child(v38_2,v38_3_label);
      if (v38_3_tail.empty()) continue;
      const Path v38_3_head{v38_3_label};
      const Space v39_2 = singleton(v38_3_head);
      const Space v39_3 = intersect(constant_6,v39_2);
      const Space v39_4 = (has_head(v39_3) ? constant_7 : Space{});
      const Space v39_5 = subtract(constant_5,v39_4);
      Space v39_7;
      if (!v39_5.empty()) {
        Space v40_6_result;
        for (int v40_6_label = 1; v40_6_label <= 2; ++v40_6_label) {
          const Space v40_6_tail = child(v38_3_tail,v40_6_label);
          if (v40_6_tail.empty()) continue;
          const Path v40_6_head{v40_6_label};
          const Space v41_2 = singleton(v40_6_head);
          const Space v41_3 = intersect(constant_6,v41_2);
          const Space v41_4 = (has_head(v41_3) ? constant_7 : Space{});
          const Space v41_5 = subtract(constant_5,v41_4);
          Space v41_8;
          if (!v41_5.empty()) {
            const Path v42_6 = concat_path(v38_3_head,v40_6_head);
            const Space v42_7 = routine_2(c, v42_6, v40_6_tail, v1_100);
            v41_8 = compose(v41_5,v42_7);
          }
          const Space v41_9 = intersect(constant_6,v41_2);
          const Space v41_10 = (has_head(v41_9) ? constant_7 : Space{});
          Space v41_12;
          if (!v41_10.empty()) {
            const Path v43_6 = concat_path(v38_3_head,v40_6_head);
            const Space v43_11 = routine_3(c, v43_6, v40_6_tail, v1_100);
            v41_12 = compose(v41_10,v43_11);
          }
          const Space v41_13 = unite(v41_8,v41_12);
          v40_6_result = unite(v40_6_result,v41_13);
        }
        const Space v40_6 = std::move(v40_6_result);
        v39_7 = compose(v39_5,v40_6);
      }
      const Space v39_8 = intersect(constant_6,v39_2);
      const Space v39_9 = (has_head(v39_8) ? constant_7 : Space{});
      Space v39_11;
      if (!v39_9.empty()) {
        Space v44_10_result;
        for (int v44_10_label = 1; v44_10_label <= 2; ++v44_10_label) {
          const Space v44_10_tail = child(v38_3_tail,v44_10_label);
          if (v44_10_tail.empty()) continue;
          const Path v44_10_head{v44_10_label};
          const Space v45_2 = singleton(v44_10_head);
          const Space v45_3 = intersect(constant_6,v45_2);
          const Space v45_4 = (has_head(v45_3) ? constant_7 : Space{});
          const Space v45_5 = subtract(constant_5,v45_4);
          Space v45_8;
          if (!v45_5.empty()) {
            const Path v46_6 = concat_path(v38_3_head,v44_10_head);
            const Space v46_7 = routine_2(c, v46_6, v44_10_tail, v1_100);
            v45_8 = compose(v45_5,v46_7);
          }
          const Space v45_9 = intersect(constant_6,v45_2);
          const Space v45_10 = (has_head(v45_9) ? constant_7 : Space{});
          Space v45_12;
          if (!v45_10.empty()) {
            const Path v47_6 = concat_path(v38_3_head,v44_10_head);
            const Space v47_11 = routine_4(c, v47_6, v44_10_tail, v1_100);
            v45_12 = compose(v45_10,v47_11);
          }
          const Space v45_13 = unite(v45_8,v45_12);
          v44_10_result = unite(v44_10_result,v45_13);
        }
        const Space v44_10 = std::move(v44_10_result);
        v39_11 = compose(v39_9,v44_10);
      }
      const Space v39_12 = unite(v39_7,v39_11);
      v38_3_result = unite(v38_3_result,v39_12);
    }
    const Space v38_3 = std::move(v38_3_result);
    Space v38_4_result;
    for (int v38_4_label = 1; v38_4_label <= 2; ++v38_4_label) {
      const Space v38_4_tail = child(v38_2,v38_4_label);
      if (v38_4_tail.empty()) continue;
      const Path v38_4_head{v38_4_label};
      const Space v48_2 = singleton(v38_4_head);
      const Space v48_3 = intersect(constant_6,v48_2);
      const Space v48_4 = (has_head(v48_3) ? constant_7 : Space{});
      const Space v48_5 = subtract(constant_5,v48_4);
      Space v48_7;
      if (!v48_5.empty()) {
        Space v49_6_result;
        for (int v49_6_label = 1; v49_6_label <= 2; ++v49_6_label) {
          const Space v49_6_tail = child(v38_4_tail,v49_6_label);
          if (v49_6_tail.empty()) continue;
          const Path v49_6_head{v49_6_label};
          const Space v50_2 = singleton(v49_6_head);
          const Space v50_3 = intersect(constant_6,v50_2);
          const Space v50_4 = (has_head(v50_3) ? constant_7 : Space{});
          const Space v50_5 = subtract(constant_5,v50_4);
          Space v50_8;
          if (!v50_5.empty()) {
            const Path v51_6 = concat_path(v38_4_head,v49_6_head);
            const Space v51_7 = routine_5(c, v51_6, v49_6_tail, v1_100);
            v50_8 = compose(v50_5,v51_7);
          }
          const Space v50_9 = intersect(constant_6,v50_2);
          const Space v50_10 = (has_head(v50_9) ? constant_7 : Space{});
          Space v50_12;
          if (!v50_10.empty()) {
            const Path v52_6 = concat_path(v38_4_head,v49_6_head);
            const Space v52_11 = routine_6(c, v52_6, v49_6_tail, v1_100);
            v50_12 = compose(v50_10,v52_11);
          }
          const Space v50_13 = unite(v50_8,v50_12);
          v49_6_result = unite(v49_6_result,v50_13);
        }
        const Space v49_6 = std::move(v49_6_result);
        v48_7 = compose(v48_5,v49_6);
      }
      const Space v48_8 = intersect(constant_6,v48_2);
      const Space v48_9 = (has_head(v48_8) ? constant_7 : Space{});
      Space v48_11;
      if (!v48_9.empty()) {
        Space v53_10_result;
        for (int v53_10_label = 1; v53_10_label <= 2; ++v53_10_label) {
          const Space v53_10_tail = child(v38_4_tail,v53_10_label);
          if (v53_10_tail.empty()) continue;
          const Path v53_10_head{v53_10_label};
          const Space v54_2 = singleton(v53_10_head);
          const Space v54_3 = intersect(constant_6,v54_2);
          const Space v54_4 = (has_head(v54_3) ? constant_7 : Space{});
          const Space v54_5 = subtract(constant_5,v54_4);
          Space v54_8;
          if (!v54_5.empty()) {
            const Path v55_6 = concat_path(v38_4_head,v53_10_head);
            const Space v55_7 = routine_5(c, v55_6, v53_10_tail, v1_100);
            v54_8 = compose(v54_5,v55_7);
          }
          const Space v54_9 = intersect(constant_6,v54_2);
          const Space v54_10 = (has_head(v54_9) ? constant_7 : Space{});
          Space v54_12;
          if (!v54_10.empty()) {
            const Path v56_6 = concat_path(v38_4_head,v53_10_head);
            const Space v56_11 = routine_7(c, v56_6, v53_10_tail, v1_100);
            v54_12 = compose(v54_10,v56_11);
          }
          const Space v54_13 = unite(v54_8,v54_12);
          v53_10_result = unite(v53_10_result,v54_13);
        }
        const Space v53_10 = std::move(v53_10_result);
        v48_11 = compose(v48_9,v53_10);
      }
      const Space v48_12 = unite(v48_7,v48_11);
      v38_4_result = unite(v38_4_result,v48_12);
    }
    const Space v38_4 = std::move(v38_4_result);
    const Space v38_5 = unite(v38_3,v38_4);
    const Space v38_6 = unwrap(v1_100,constant_8);
    const Space v38_7 = unwrap(v38_6,constant_9);
    Space v38_8_result;
    for (int v38_8_label = 1; v38_8_label <= 2; ++v38_8_label) {
      const Space v38_8_tail = child(v38_7,v38_8_label);
      if (v38_8_tail.empty()) continue;
      const Path v38_8_head{v38_8_label};
      const Space v57_2 = singleton(v38_8_head);
      const Space v57_3 = intersect(constant_6,v57_2);
      const Space v57_4 = (has_head(v57_3) ? constant_7 : Space{});
      const Space v57_5 = subtract(constant_5,v57_4);
      Space v57_7;
      if (!v57_5.empty()) {
        Space v58_6_result;
        for (int v58_6_label = 1; v58_6_label <= 2; ++v58_6_label) {
          const Space v58_6_tail = child(v38_8_tail,v58_6_label);
          if (v58_6_tail.empty()) continue;
          const Path v58_6_head{v58_6_label};
          const Space v59_2 = singleton(v58_6_head);
          const Space v59_3 = intersect(constant_6,v59_2);
          const Space v59_4 = (has_head(v59_3) ? constant_7 : Space{});
          const Space v59_5 = subtract(constant_5,v59_4);
          Space v59_8;
          if (!v59_5.empty()) {
            const Path v60_6 = concat_path(v38_8_head,v58_6_head);
            const Space v60_7 = routine_8(c, v60_6, v58_6_tail);
            v59_8 = compose(v59_5,v60_7);
          }
          const Space v59_9 = intersect(constant_6,v59_2);
          const Space v59_10 = (has_head(v59_9) ? constant_7 : Space{});
          Space v59_12;
          if (!v59_10.empty()) {
            const Path v61_6 = concat_path(v38_8_head,v58_6_head);
            const Space v61_11 = routine_9(c, v61_6, v58_6_tail);
            v59_12 = compose(v59_10,v61_11);
          }
          const Space v59_13 = unite(v59_8,v59_12);
          v58_6_result = unite(v58_6_result,v59_13);
        }
        const Space v58_6 = std::move(v58_6_result);
        v57_7 = compose(v57_5,v58_6);
      }
      const Space v57_8 = intersect(constant_6,v57_2);
      const Space v57_9 = (has_head(v57_8) ? constant_7 : Space{});
      Space v57_11;
      if (!v57_9.empty()) {
        Space v62_10_result;
        for (int v62_10_label = 1; v62_10_label <= 2; ++v62_10_label) {
          const Space v62_10_tail = child(v38_8_tail,v62_10_label);
          if (v62_10_tail.empty()) continue;
          const Path v62_10_head{v62_10_label};
          const Space v63_2 = singleton(v62_10_head);
          const Space v63_3 = intersect(constant_6,v63_2);
          const Space v63_4 = (has_head(v63_3) ? constant_7 : Space{});
          const Space v63_5 = subtract(constant_5,v63_4);
          Space v63_8;
          if (!v63_5.empty()) {
            const Path v64_6 = concat_path(v38_8_head,v62_10_head);
            const Space v64_7 = routine_8(c, v64_6, v62_10_tail);
            v63_8 = compose(v63_5,v64_7);
          }
          const Space v63_9 = intersect(constant_6,v63_2);
          const Space v63_10 = (has_head(v63_9) ? constant_7 : Space{});
          Space v63_12;
          if (!v63_10.empty()) {
            const Path v65_6 = concat_path(v38_8_head,v62_10_head);
            const Space v65_11 = routine_10(c, v65_6, v62_10_tail);
            v63_12 = compose(v63_10,v65_11);
          }
          const Space v63_13 = unite(v63_8,v63_12);
          v62_10_result = unite(v62_10_result,v63_13);
        }
        const Space v62_10 = std::move(v62_10_result);
        v57_11 = compose(v57_9,v62_10);
      }
      const Space v57_12 = unite(v57_7,v57_11);
      v38_8_result = unite(v38_8_result,v57_12);
    }
    const Space v38_8 = std::move(v38_8_result);
    const Space v38_9 = unite(v38_5,v38_8);
    const Space v38_10 = unwrap(v38_6,constant_4);
    Space v38_11_result;
    for (int v38_11_label = 1; v38_11_label <= 2; ++v38_11_label) {
      const Space v38_11_tail = child(v38_10,v38_11_label);
      if (v38_11_tail.empty()) continue;
      const Path v38_11_head{v38_11_label};
      const Space v66_2 = singleton(v38_11_head);
      const Space v66_3 = intersect(constant_6,v66_2);
      const Space v66_4 = (has_head(v66_3) ? constant_7 : Space{});
      const Space v66_5 = subtract(constant_5,v66_4);
      Space v66_7;
      if (!v66_5.empty()) {
        Space v67_6_result;
        for (int v67_6_label = 1; v67_6_label <= 2; ++v67_6_label) {
          const Space v67_6_tail = child(v38_11_tail,v67_6_label);
          if (v67_6_tail.empty()) continue;
          const Path v67_6_head{v67_6_label};
          const Space v68_2 = singleton(v67_6_head);
          const Space v68_3 = intersect(constant_6,v68_2);
          const Space v68_4 = (has_head(v68_3) ? constant_7 : Space{});
          const Space v68_5 = subtract(constant_5,v68_4);
          Space v68_8;
          if (!v68_5.empty()) {
            const Path v69_6 = concat_path(v38_11_head,v67_6_head);
            const Space v69_7 = routine_11(c, v69_6, v67_6_tail, v1_100);
            v68_8 = compose(v68_5,v69_7);
          }
          const Space v68_9 = intersect(constant_6,v68_2);
          const Space v68_10 = (has_head(v68_9) ? constant_7 : Space{});
          Space v68_12;
          if (!v68_10.empty()) {
            const Path v70_6 = concat_path(v38_11_head,v67_6_head);
            const Space v70_11 = routine_12(c, v70_6, v67_6_tail, v1_100);
            v68_12 = compose(v68_10,v70_11);
          }
          const Space v68_13 = unite(v68_8,v68_12);
          v67_6_result = unite(v67_6_result,v68_13);
        }
        const Space v67_6 = std::move(v67_6_result);
        v66_7 = compose(v66_5,v67_6);
      }
      const Space v66_8 = intersect(constant_6,v66_2);
      const Space v66_9 = (has_head(v66_8) ? constant_7 : Space{});
      Space v66_11;
      if (!v66_9.empty()) {
        Space v71_10_result;
        for (int v71_10_label = 1; v71_10_label <= 2; ++v71_10_label) {
          const Space v71_10_tail = child(v38_11_tail,v71_10_label);
          if (v71_10_tail.empty()) continue;
          const Path v71_10_head{v71_10_label};
          const Space v72_2 = singleton(v71_10_head);
          const Space v72_3 = intersect(constant_6,v72_2);
          const Space v72_4 = (has_head(v72_3) ? constant_7 : Space{});
          const Space v72_5 = subtract(constant_5,v72_4);
          Space v72_8;
          if (!v72_5.empty()) {
            const Path v73_6 = concat_path(v38_11_head,v71_10_head);
            const Space v73_7 = routine_11(c, v73_6, v71_10_tail, v1_100);
            v72_8 = compose(v72_5,v73_7);
          }
          const Space v72_9 = intersect(constant_6,v72_2);
          const Space v72_10 = (has_head(v72_9) ? constant_7 : Space{});
          Space v72_12;
          if (!v72_10.empty()) {
            const Path v74_6 = concat_path(v38_11_head,v71_10_head);
            const Space v74_11 = routine_13(c, v74_6, v71_10_tail, v1_100);
            v72_12 = compose(v72_10,v74_11);
          }
          const Space v72_13 = unite(v72_8,v72_12);
          v71_10_result = unite(v71_10_result,v72_13);
        }
        const Space v71_10 = std::move(v71_10_result);
        v66_11 = compose(v66_9,v71_10);
      }
      const Space v66_12 = unite(v66_7,v66_11);
      v38_11_result = unite(v38_11_result,v66_12);
    }
    const Space v38_11 = std::move(v38_11_result);
    const Space v38_12 = unite(v38_9,v38_11);
    const Space v38_13 = unwrap(v1_100,constant_2);
    const Space v38_14 = subtract(v38_12,v38_13);
    const Space v38_15 = unwrap(v1_100,constant_10);
    const Space v38_16 = subtract(v38_14,v38_15);
    const Space v38_17 = wrap(v38_16,constant_10);
    const Space v38_18 = unite(v38_1,v38_6);
    const Space v38_19 = wrap(v38_18,constant_8);
    const Space v38_20 = unite(v38_17,v38_19);
    const Space v38_21 = unite(v38_20,v1_100);
    Space v1_100_next = unite(v1_100,v38_21);
    if (equal(v1_100_next,v1_100)) break;
    v1_100 = std::move(v1_100_next);
  }
  const Space v1_101 = unite(s0,v1_100);
  return v1_101;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v75_12_result;
  for (int v75_12_label = 1; v75_12_label <= 2; ++v75_12_label) {
    const Space v75_12_tail = child(s0,v75_12_label);
    if (v75_12_tail.empty()) continue;
    const Path v75_12_head{v75_12_label};
    const Space v76_2 = singleton(v75_12_head);
    const Space v76_3 = intersect(constant_6,v76_2);
    const Space v76_4 = (has_head(v76_3) ? constant_7 : Space{});
    const Space v76_5 = subtract(constant_5,v76_4);
    Space v76_8;
    if (!v76_5.empty()) {
      const Path v77_6 = concat_path(p0,v75_12_head);
      Space v77_7_result;
      for (int v77_7_label = 1; v77_7_label <= 2; ++v77_7_label) {
        const Space v77_7_tail = child(v75_12_tail,v77_7_label);
        if (v77_7_tail.empty()) continue;
        const Path v77_7_head{v77_7_label};
        const Space v78_2 = singleton(v77_7_head);
        const Space v78_3 = intersect(constant_6,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_7 : Space{});
        const Space v78_5 = subtract(constant_5,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_7_head);
          const Space v79_7 = routine_14(c, v79_6, v77_7_tail, s1);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_6,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_7 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_7_head);
          const Space v80_11 = routine_15(c, v80_6, v77_7_tail, s1);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_7_result = unite(v77_7_result,v78_13);
      }
      const Space v77_7 = std::move(v77_7_result);
      v76_8 = compose(v76_5,v77_7);
    }
    const Space v76_9 = intersect(constant_6,v76_2);
    const Space v76_10 = (has_head(v76_9) ? constant_7 : Space{});
    Space v76_12;
    if (!v76_10.empty()) {
      const Path v81_6 = concat_path(p0,v75_12_head);
      Space v81_11_result;
      for (int v81_11_label = 1; v81_11_label <= 2; ++v81_11_label) {
        const Space v81_11_tail = child(v75_12_tail,v81_11_label);
        if (v81_11_tail.empty()) continue;
        const Path v81_11_head{v81_11_label};
        const Space v82_2 = singleton(v81_11_head);
        const Space v82_3 = intersect(constant_6,v82_2);
        const Space v82_4 = (has_head(v82_3) ? constant_7 : Space{});
        const Space v82_5 = subtract(constant_5,v82_4);
        Space v82_8;
        if (!v82_5.empty()) {
          const Path v83_6 = concat_path(v81_6,v81_11_head);
          const Space v83_7 = routine_14(c, v83_6, v81_11_tail, s1);
          v82_8 = compose(v82_5,v83_7);
        }
        const Space v82_9 = intersect(constant_6,v82_2);
        const Space v82_10 = (has_head(v82_9) ? constant_7 : Space{});
        Space v82_12;
        if (!v82_10.empty()) {
          const Path v84_6 = concat_path(v81_6,v81_11_head);
          const Space v84_11 = routine_4(c, v84_6, v81_11_tail, s1);
          v82_12 = compose(v82_10,v84_11);
        }
        const Space v82_13 = unite(v82_8,v82_12);
        v81_11_result = unite(v81_11_result,v82_13);
      }
      const Space v81_11 = std::move(v81_11_result);
      v76_12 = compose(v76_10,v81_11);
    }
    const Space v76_13 = unite(v76_8,v76_12);
    v75_12_result = unite(v75_12_result,v76_13);
  }
  const Space v75_12 = std::move(v75_12_result);
  return v75_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v85_12_result;
  for (int v85_12_label = 1; v85_12_label <= 2; ++v85_12_label) {
    const Space v85_12_tail = child(s0,v85_12_label);
    if (v85_12_tail.empty()) continue;
    const Path v85_12_head{v85_12_label};
    const Space v86_2 = singleton(v85_12_head);
    const Space v86_3 = intersect(constant_6,v86_2);
    const Space v86_4 = (has_head(v86_3) ? constant_7 : Space{});
    const Space v86_5 = subtract(constant_5,v86_4);
    Space v86_8;
    if (!v86_5.empty()) {
      const Path v87_6 = concat_path(p0,v85_12_head);
      Space v87_7_result;
      for (int v87_7_label = 1; v87_7_label <= 2; ++v87_7_label) {
        const Space v87_7_tail = child(v85_12_tail,v87_7_label);
        if (v87_7_tail.empty()) continue;
        const Path v87_7_head{v87_7_label};
        const Space v88_2 = singleton(v87_7_head);
        const Space v88_3 = intersect(constant_6,v88_2);
        const Space v88_4 = (has_head(v88_3) ? constant_7 : Space{});
        const Space v88_5 = subtract(constant_5,v88_4);
        Space v88_8;
        if (!v88_5.empty()) {
          const Path v89_6 = concat_path(v87_6,v87_7_head);
          const Space v89_7 = routine_14(c, v89_6, v87_7_tail, s1);
          v88_8 = compose(v88_5,v89_7);
        }
        const Space v88_9 = intersect(constant_6,v88_2);
        const Space v88_10 = (has_head(v88_9) ? constant_7 : Space{});
        Space v88_12;
        if (!v88_10.empty()) {
          const Path v90_6 = concat_path(v87_6,v87_7_head);
          const Space v90_11 = routine_15(c, v90_6, v87_7_tail, s1);
          v88_12 = compose(v88_10,v90_11);
        }
        const Space v88_13 = unite(v88_8,v88_12);
        v87_7_result = unite(v87_7_result,v88_13);
      }
      const Space v87_7 = std::move(v87_7_result);
      v86_8 = compose(v86_5,v87_7);
    }
    const Space v86_9 = intersect(constant_6,v86_2);
    const Space v86_10 = (has_head(v86_9) ? constant_7 : Space{});
    Space v86_12;
    if (!v86_10.empty()) {
      Space v91_11_result;
      for (int v91_11_label = 1; v91_11_label <= 2; ++v91_11_label) {
        const Space v91_11_tail = child(v85_12_tail,v91_11_label);
        if (v91_11_tail.empty()) continue;
        const Path v91_11_head{v91_11_label};
        const Space v92_2 = singleton(v91_11_head);
        const Space v92_3 = intersect(constant_6,v92_2);
        const Space v92_4 = (has_head(v92_3) ? constant_7 : Space{});
        const Space v92_5 = subtract(constant_5,v92_4);
        Space v92_7;
        if (!v92_5.empty()) {
          const Space v93_6 = routine_16(c, v91_11_head, v91_11_tail, s1);
          v92_7 = compose(v92_5,v93_6);
        }
        const Space v92_8 = intersect(constant_6,v92_2);
        const Space v92_9 = (has_head(v92_8) ? constant_7 : Space{});
        Space v92_11;
        if (!v92_9.empty()) {
          const Space v94_10 = routine_17(c, v91_11_head, v91_11_tail, s1);
          v92_11 = compose(v92_9,v94_10);
        }
        const Space v92_12 = unite(v92_7,v92_11);
        v91_11_result = unite(v91_11_result,v92_12);
      }
      const Space v91_11 = std::move(v91_11_result);
      v86_12 = compose(v86_10,v91_11);
    }
    const Path v95_6 = concat_path(p0,v85_12_head);
    const Space v86_13 = wrap(v86_12,v95_6);
    const Space v86_14 = unite(v86_8,v86_13);
    v85_12_result = unite(v85_12_result,v86_14);
  }
  const Space v85_12 = std::move(v85_12_result);
  return v85_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v96_12_result;
  for (int v96_12_label = 1; v96_12_label <= 2; ++v96_12_label) {
    const Space v96_12_tail = child(s0,v96_12_label);
    if (v96_12_tail.empty()) continue;
    const Path v96_12_head{v96_12_label};
    const Space v97_2 = singleton(v96_12_head);
    const Space v97_3 = intersect(constant_6,v97_2);
    const Space v97_4 = (has_head(v97_3) ? constant_7 : Space{});
    const Space v97_5 = subtract(constant_5,v97_4);
    Space v97_7;
    if (!v97_5.empty()) {
      Space v98_6_result;
      for (int v98_6_label = 1; v98_6_label <= 2; ++v98_6_label) {
        const Space v98_6_tail = child(v96_12_tail,v98_6_label);
        if (v98_6_tail.empty()) continue;
        const Path v98_6_head{v98_6_label};
        const Space v99_2 = singleton(v98_6_head);
        const Space v99_3 = intersect(constant_6,v99_2);
        const Space v99_4 = (has_head(v99_3) ? constant_7 : Space{});
        const Space v99_5 = subtract(constant_5,v99_4);
        Space v99_8;
        if (!v99_5.empty()) {
          const Path v100_6 = concat_path(v96_12_head,v98_6_head);
          const Space v100_7 = routine_18(c, v100_6, v98_6_tail, s1);
          v99_8 = compose(v99_5,v100_7);
        }
        const Space v99_9 = intersect(constant_6,v99_2);
        const Space v99_10 = (has_head(v99_9) ? constant_7 : Space{});
        Space v99_12;
        if (!v99_10.empty()) {
          const Path v101_6 = concat_path(v96_12_head,v98_6_head);
          const Space v101_11 = routine_19(c, v101_6, v98_6_tail, s1);
          v99_12 = compose(v99_10,v101_11);
        }
        const Space v99_13 = unite(v99_8,v99_12);
        v98_6_result = unite(v98_6_result,v99_13);
      }
      const Space v98_6 = std::move(v98_6_result);
      v97_7 = compose(v97_5,v98_6);
    }
    const Space v97_8 = intersect(constant_6,v97_2);
    const Space v97_9 = (has_head(v97_8) ? constant_7 : Space{});
    Space v97_11;
    if (!v97_9.empty()) {
      Space v102_10_result;
      for (int v102_10_label = 1; v102_10_label <= 2; ++v102_10_label) {
        const Space v102_10_tail = child(v96_12_tail,v102_10_label);
        if (v102_10_tail.empty()) continue;
        const Path v102_10_head{v102_10_label};
        const Space v103_2 = singleton(v102_10_head);
        const Space v103_3 = intersect(constant_6,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_7 : Space{});
        const Space v103_5 = subtract(constant_5,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v96_12_head,v102_10_head);
          const Space v104_7 = routine_18(c, v104_6, v102_10_tail, s1);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_6,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_7 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v96_12_head,v102_10_head);
          const Space v105_11 = routine_20(c, v105_6, v102_10_tail, s1);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_10_result = unite(v102_10_result,v103_13);
      }
      const Space v102_10 = std::move(v102_10_result);
      v97_11 = compose(v97_9,v102_10);
    }
    const Space v97_12 = unite(v97_7,v97_11);
    v96_12_result = unite(v96_12_result,v97_12);
  }
  const Space v96_12 = std::move(v96_12_result);
  const Space v96_13 = wrap(v96_12,p0);
  return v96_13;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v106_12_result;
  for (int v106_12_label = 1; v106_12_label <= 2; ++v106_12_label) {
    const Space v106_12_tail = child(s0,v106_12_label);
    if (v106_12_tail.empty()) continue;
    const Path v106_12_head{v106_12_label};
    const Space v107_2 = singleton(v106_12_head);
    const Space v107_3 = intersect(constant_6,v107_2);
    const Space v107_4 = (has_head(v107_3) ? constant_7 : Space{});
    const Space v107_5 = subtract(constant_5,v107_4);
    Space v107_8;
    if (!v107_5.empty()) {
      const Path v108_6 = concat_path(p0,v106_12_head);
      Space v108_7_result;
      for (int v108_7_label = 1; v108_7_label <= 2; ++v108_7_label) {
        const Space v108_7_tail = child(v106_12_tail,v108_7_label);
        if (v108_7_tail.empty()) continue;
        const Path v108_7_head{v108_7_label};
        const Space v109_2 = singleton(v108_7_head);
        const Space v109_3 = intersect(constant_6,v109_2);
        const Space v109_4 = (has_head(v109_3) ? constant_7 : Space{});
        const Space v109_5 = subtract(constant_5,v109_4);
        Space v109_8;
        if (!v109_5.empty()) {
          const Path v110_6 = concat_path(v108_6,v108_7_head);
          const Space v110_7 = routine_21(c, v110_6, v108_7_tail, s1);
          v109_8 = compose(v109_5,v110_7);
        }
        const Space v109_9 = intersect(constant_6,v109_2);
        const Space v109_10 = (has_head(v109_9) ? constant_7 : Space{});
        Space v109_12;
        if (!v109_10.empty()) {
          const Path v111_6 = concat_path(v108_6,v108_7_head);
          const Space v111_11 = routine_22(c, v111_6, v108_7_tail, s1);
          v109_12 = compose(v109_10,v111_11);
        }
        const Space v109_13 = unite(v109_8,v109_12);
        v108_7_result = unite(v108_7_result,v109_13);
      }
      const Space v108_7 = std::move(v108_7_result);
      v107_8 = compose(v107_5,v108_7);
    }
    const Space v107_9 = intersect(constant_6,v107_2);
    const Space v107_10 = (has_head(v107_9) ? constant_7 : Space{});
    Space v107_12;
    if (!v107_10.empty()) {
      const Path v112_6 = concat_path(p0,v106_12_head);
      Space v112_11_result;
      for (int v112_11_label = 1; v112_11_label <= 2; ++v112_11_label) {
        const Space v112_11_tail = child(v106_12_tail,v112_11_label);
        if (v112_11_tail.empty()) continue;
        const Path v112_11_head{v112_11_label};
        const Space v113_2 = singleton(v112_11_head);
        const Space v113_3 = intersect(constant_6,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_7 : Space{});
        const Space v113_5 = subtract(constant_5,v113_4);
        Space v113_8;
        if (!v113_5.empty()) {
          const Path v114_6 = concat_path(v112_6,v112_11_head);
          const Space v114_7 = routine_21(c, v114_6, v112_11_tail, s1);
          v113_8 = compose(v113_5,v114_7);
        }
        const Space v113_9 = intersect(constant_6,v113_2);
        const Space v113_10 = (has_head(v113_9) ? constant_7 : Space{});
        Space v113_12;
        if (!v113_10.empty()) {
          const Path v115_6 = concat_path(v112_6,v112_11_head);
          const Space v115_11 = routine_7(c, v115_6, v112_11_tail, s1);
          v113_12 = compose(v113_10,v115_11);
        }
        const Space v113_13 = unite(v113_8,v113_12);
        v112_11_result = unite(v112_11_result,v113_13);
      }
      const Space v112_11 = std::move(v112_11_result);
      v107_12 = compose(v107_10,v112_11);
    }
    const Space v107_13 = unite(v107_8,v107_12);
    v106_12_result = unite(v106_12_result,v107_13);
  }
  const Space v106_12 = std::move(v106_12_result);
  return v106_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v116_12_result;
  for (int v116_12_label = 1; v116_12_label <= 2; ++v116_12_label) {
    const Space v116_12_tail = child(s0,v116_12_label);
    if (v116_12_tail.empty()) continue;
    const Path v116_12_head{v116_12_label};
    const Space v117_2 = singleton(v116_12_head);
    const Space v117_3 = intersect(constant_6,v117_2);
    const Space v117_4 = (has_head(v117_3) ? constant_7 : Space{});
    const Space v117_5 = subtract(constant_5,v117_4);
    Space v117_8;
    if (!v117_5.empty()) {
      const Path v118_6 = concat_path(p0,v116_12_head);
      Space v118_7_result;
      for (int v118_7_label = 1; v118_7_label <= 2; ++v118_7_label) {
        const Space v118_7_tail = child(v116_12_tail,v118_7_label);
        if (v118_7_tail.empty()) continue;
        const Path v118_7_head{v118_7_label};
        const Space v119_2 = singleton(v118_7_head);
        const Space v119_3 = intersect(constant_6,v119_2);
        const Space v119_4 = (has_head(v119_3) ? constant_7 : Space{});
        const Space v119_5 = subtract(constant_5,v119_4);
        Space v119_8;
        if (!v119_5.empty()) {
          const Path v120_6 = concat_path(v118_6,v118_7_head);
          const Space v120_7 = routine_21(c, v120_6, v118_7_tail, s1);
          v119_8 = compose(v119_5,v120_7);
        }
        const Space v119_9 = intersect(constant_6,v119_2);
        const Space v119_10 = (has_head(v119_9) ? constant_7 : Space{});
        Space v119_12;
        if (!v119_10.empty()) {
          const Path v121_6 = concat_path(v118_6,v118_7_head);
          const Space v121_11 = routine_22(c, v121_6, v118_7_tail, s1);
          v119_12 = compose(v119_10,v121_11);
        }
        const Space v119_13 = unite(v119_8,v119_12);
        v118_7_result = unite(v118_7_result,v119_13);
      }
      const Space v118_7 = std::move(v118_7_result);
      v117_8 = compose(v117_5,v118_7);
    }
    const Space v117_9 = intersect(constant_6,v117_2);
    const Space v117_10 = (has_head(v117_9) ? constant_7 : Space{});
    Space v117_12;
    if (!v117_10.empty()) {
      Space v122_11_result;
      for (int v122_11_label = 1; v122_11_label <= 2; ++v122_11_label) {
        const Space v122_11_tail = child(v116_12_tail,v122_11_label);
        if (v122_11_tail.empty()) continue;
        const Path v122_11_head{v122_11_label};
        const Space v123_2 = singleton(v122_11_head);
        const Space v123_3 = intersect(constant_6,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_7 : Space{});
        const Space v123_5 = subtract(constant_5,v123_4);
        Space v123_7;
        if (!v123_5.empty()) {
          const Space v124_6 = routine_23(c, v122_11_head, v122_11_tail, s1);
          v123_7 = compose(v123_5,v124_6);
        }
        const Space v123_8 = intersect(constant_6,v123_2);
        const Space v123_9 = (has_head(v123_8) ? constant_7 : Space{});
        Space v123_11;
        if (!v123_9.empty()) {
          const Space v125_10 = routine_24(c, v122_11_head, v122_11_tail, s1);
          v123_11 = compose(v123_9,v125_10);
        }
        const Space v123_12 = unite(v123_7,v123_11);
        v122_11_result = unite(v122_11_result,v123_12);
      }
      const Space v122_11 = std::move(v122_11_result);
      v117_12 = compose(v117_10,v122_11);
    }
    const Path v126_6 = concat_path(p0,v116_12_head);
    const Space v117_13 = wrap(v117_12,v126_6);
    const Space v117_14 = unite(v117_8,v117_13);
    v116_12_result = unite(v116_12_result,v117_14);
  }
  const Space v116_12 = std::move(v116_12_result);
  return v116_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v127_12_result;
  for (int v127_12_label = 1; v127_12_label <= 2; ++v127_12_label) {
    const Space v127_12_tail = child(s0,v127_12_label);
    if (v127_12_tail.empty()) continue;
    const Path v127_12_head{v127_12_label};
    const Space v128_2 = singleton(v127_12_head);
    const Space v128_3 = intersect(constant_6,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_7 : Space{});
    const Space v128_5 = subtract(constant_5,v128_4);
    Space v128_7;
    if (!v128_5.empty()) {
      Space v129_6_result;
      for (int v129_6_label = 1; v129_6_label <= 2; ++v129_6_label) {
        const Space v129_6_tail = child(v127_12_tail,v129_6_label);
        if (v129_6_tail.empty()) continue;
        const Path v129_6_head{v129_6_label};
        const Space v130_2 = singleton(v129_6_head);
        const Space v130_3 = intersect(constant_6,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_7 : Space{});
        const Space v130_5 = subtract(constant_5,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v127_12_head,v129_6_head);
          const Space v131_7 = routine_25(c, v131_6, v129_6_tail, s1);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_6,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_7 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v127_12_head,v129_6_head);
          const Space v132_11 = routine_26(c, v132_6, v129_6_tail, s1);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_6_result = unite(v129_6_result,v130_13);
      }
      const Space v129_6 = std::move(v129_6_result);
      v128_7 = compose(v128_5,v129_6);
    }
    const Space v128_8 = intersect(constant_6,v128_2);
    const Space v128_9 = (has_head(v128_8) ? constant_7 : Space{});
    Space v128_11;
    if (!v128_9.empty()) {
      Space v133_10_result;
      for (int v133_10_label = 1; v133_10_label <= 2; ++v133_10_label) {
        const Space v133_10_tail = child(v127_12_tail,v133_10_label);
        if (v133_10_tail.empty()) continue;
        const Path v133_10_head{v133_10_label};
        const Space v134_2 = singleton(v133_10_head);
        const Space v134_3 = intersect(constant_6,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_7 : Space{});
        const Space v134_5 = subtract(constant_5,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v127_12_head,v133_10_head);
          const Space v135_7 = routine_25(c, v135_6, v133_10_tail, s1);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_6,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_7 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v127_12_head,v133_10_head);
          const Space v136_11 = routine_27(c, v136_6, v133_10_tail, s1);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_10_result = unite(v133_10_result,v134_13);
      }
      const Space v133_10 = std::move(v133_10_result);
      v128_11 = compose(v128_9,v133_10);
    }
    const Space v128_12 = unite(v128_7,v128_11);
    v127_12_result = unite(v127_12_result,v128_12);
  }
  const Space v127_12 = std::move(v127_12_result);
  const Space v127_13 = wrap(v127_12,p0);
  return v127_13;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v137_11_result;
  for (int v137_11_label = 1; v137_11_label <= 2; ++v137_11_label) {
    const Space v137_11_tail = child(s0,v137_11_label);
    if (v137_11_tail.empty()) continue;
    const Path v137_11_head{v137_11_label};
    const Space v138_2 = singleton(v137_11_head);
    const Space v138_3 = intersect(constant_6,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_7 : Space{});
    const Space v138_5 = subtract(constant_5,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_11_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_11_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_6,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_7 : Space{});
        const Space v140_5 = subtract(constant_5,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_28(c, v141_6, v139_7_tail);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_6,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_7 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_29(c, v142_6, v139_7_tail);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_6,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_7 : Space{});
    Space v138_12;
    if (!v138_10.empty()) {
      const Path v143_6 = concat_path(p0,v137_11_head);
      Space v143_11_result;
      for (int v143_11_label = 1; v143_11_label <= 2; ++v143_11_label) {
        const Space v143_11_tail = child(v137_11_tail,v143_11_label);
        if (v143_11_tail.empty()) continue;
        const Path v143_11_head{v143_11_label};
        const Space v144_2 = singleton(v143_11_head);
        const Space v144_3 = intersect(constant_6,v144_2);
        const Space v144_4 = (has_head(v144_3) ? constant_7 : Space{});
        const Space v144_5 = subtract(constant_5,v144_4);
        Space v144_8;
        if (!v144_5.empty()) {
          const Path v145_6 = concat_path(v143_6,v143_11_head);
          const Space v145_7 = routine_28(c, v145_6, v143_11_tail);
          v144_8 = compose(v144_5,v145_7);
        }
        const Space v144_9 = intersect(constant_6,v144_2);
        const Space v144_10 = (has_head(v144_9) ? constant_7 : Space{});
        Space v144_12;
        if (!v144_10.empty()) {
          const Path v146_6 = concat_path(v143_6,v143_11_head);
          const Space v146_11 = routine_10(c, v146_6, v143_11_tail);
          v144_12 = compose(v144_10,v146_11);
        }
        const Space v144_13 = unite(v144_8,v144_12);
        v143_11_result = unite(v143_11_result,v144_13);
      }
      const Space v143_11 = std::move(v143_11_result);
      v138_12 = compose(v138_10,v143_11);
    }
    const Space v138_13 = unite(v138_8,v138_12);
    v137_11_result = unite(v137_11_result,v138_13);
  }
  const Space v137_11 = std::move(v137_11_result);
  return v137_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v147_9_result;
  for (int v147_9_label = 1; v147_9_label <= 2; ++v147_9_label) {
    const Space v147_9_tail = child(s0,v147_9_label);
    if (v147_9_tail.empty()) continue;
    const Path v147_9_head{v147_9_label};
    const Space v148_2 = singleton(v147_9_head);
    const Space v148_3 = intersect(constant_6,v148_2);
    const Space v148_4 = (has_head(v148_3) ? constant_7 : Space{});
    const Space v148_5 = subtract(constant_5,v148_4);
    Space v148_8;
    if (!v148_5.empty()) {
      const Path v149_6 = concat_path(p0,v147_9_head);
      Space v149_7_result;
      for (int v149_7_label = 1; v149_7_label <= 2; ++v149_7_label) {
        const Space v149_7_tail = child(v147_9_tail,v149_7_label);
        if (v149_7_tail.empty()) continue;
        const Path v149_7_head{v149_7_label};
        const Space v150_2 = singleton(v149_7_head);
        const Space v150_3 = intersect(constant_6,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_7 : Space{});
        const Space v150_5 = subtract(constant_5,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_7_head);
          const Space v151_7 = routine_28(c, v151_6, v149_7_tail);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_6,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_7 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_7_head);
          const Space v152_11 = routine_29(c, v152_6, v149_7_tail);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_7_result = unite(v149_7_result,v150_13);
      }
      const Space v149_7 = std::move(v149_7_result);
      v148_8 = compose(v148_5,v149_7);
    }
    const Space v148_9 = intersect(constant_6,v148_2);
    const Space v148_10 = (has_head(v148_9) ? constant_7 : Space{});
    const Space v148_11 = subtract(v147_9_tail,constant_5);
    const Space v148_12 = compose(v148_10,v148_11);
    const Path v153_6 = concat_path(p0,v147_9_head);
    const Space v148_13 = wrap(v148_12,v153_6);
    const Space v148_14 = unite(v148_8,v148_13);
    v147_9_result = unite(v147_9_result,v148_14);
  }
  const Space v147_9 = std::move(v147_9_result);
  return v147_9;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  const Space v154_3 = subtract(s0,constant_5);
  const Space v154_4 = wrap(v154_3,p0);
  return v154_4;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v155_12_result;
  for (int v155_12_label = 1; v155_12_label <= 2; ++v155_12_label) {
    const Space v155_12_tail = child(s0,v155_12_label);
    if (v155_12_tail.empty()) continue;
    const Path v155_12_head{v155_12_label};
    const Space v156_2 = singleton(v155_12_head);
    const Space v156_3 = intersect(constant_6,v156_2);
    const Space v156_4 = (has_head(v156_3) ? constant_7 : Space{});
    const Space v156_5 = subtract(constant_5,v156_4);
    Space v156_8;
    if (!v156_5.empty()) {
      const Path v157_6 = concat_path(p0,v155_12_head);
      Space v157_7_result;
      for (int v157_7_label = 1; v157_7_label <= 2; ++v157_7_label) {
        const Space v157_7_tail = child(v155_12_tail,v157_7_label);
        if (v157_7_tail.empty()) continue;
        const Path v157_7_head{v157_7_label};
        const Space v158_2 = singleton(v157_7_head);
        const Space v158_3 = intersect(constant_6,v158_2);
        const Space v158_4 = (has_head(v158_3) ? constant_7 : Space{});
        const Space v158_5 = subtract(constant_5,v158_4);
        Space v158_8;
        if (!v158_5.empty()) {
          const Path v159_6 = concat_path(v157_6,v157_7_head);
          const Space v159_7 = routine_30(c, v159_6, v157_7_tail, s1);
          v158_8 = compose(v158_5,v159_7);
        }
        const Space v158_9 = intersect(constant_6,v158_2);
        const Space v158_10 = (has_head(v158_9) ? constant_7 : Space{});
        Space v158_12;
        if (!v158_10.empty()) {
          const Path v160_6 = concat_path(v157_6,v157_7_head);
          const Space v160_11 = routine_31(c, v160_6, v157_7_tail, s1);
          v158_12 = compose(v158_10,v160_11);
        }
        const Space v158_13 = unite(v158_8,v158_12);
        v157_7_result = unite(v157_7_result,v158_13);
      }
      const Space v157_7 = std::move(v157_7_result);
      v156_8 = compose(v156_5,v157_7);
    }
    const Space v156_9 = intersect(constant_6,v156_2);
    const Space v156_10 = (has_head(v156_9) ? constant_7 : Space{});
    Space v156_12;
    if (!v156_10.empty()) {
      const Path v161_6 = concat_path(p0,v155_12_head);
      Space v161_11_result;
      for (int v161_11_label = 1; v161_11_label <= 2; ++v161_11_label) {
        const Space v161_11_tail = child(v155_12_tail,v161_11_label);
        if (v161_11_tail.empty()) continue;
        const Path v161_11_head{v161_11_label};
        const Space v162_2 = singleton(v161_11_head);
        const Space v162_3 = intersect(constant_6,v162_2);
        const Space v162_4 = (has_head(v162_3) ? constant_7 : Space{});
        const Space v162_5 = subtract(constant_5,v162_4);
        Space v162_8;
        if (!v162_5.empty()) {
          const Path v163_6 = concat_path(v161_6,v161_11_head);
          const Space v163_7 = routine_30(c, v163_6, v161_11_tail, s1);
          v162_8 = compose(v162_5,v163_7);
        }
        const Space v162_9 = intersect(constant_6,v162_2);
        const Space v162_10 = (has_head(v162_9) ? constant_7 : Space{});
        Space v162_12;
        if (!v162_10.empty()) {
          const Path v164_6 = concat_path(v161_6,v161_11_head);
          const Space v164_11 = routine_13(c, v164_6, v161_11_tail, s1);
          v162_12 = compose(v162_10,v164_11);
        }
        const Space v162_13 = unite(v162_8,v162_12);
        v161_11_result = unite(v161_11_result,v162_13);
      }
      const Space v161_11 = std::move(v161_11_result);
      v156_12 = compose(v156_10,v161_11);
    }
    const Space v156_13 = unite(v156_8,v156_12);
    v155_12_result = unite(v155_12_result,v156_13);
  }
  const Space v155_12 = std::move(v155_12_result);
  return v155_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v165_12_result;
  for (int v165_12_label = 1; v165_12_label <= 2; ++v165_12_label) {
    const Space v165_12_tail = child(s0,v165_12_label);
    if (v165_12_tail.empty()) continue;
    const Path v165_12_head{v165_12_label};
    const Space v166_2 = singleton(v165_12_head);
    const Space v166_3 = intersect(constant_6,v166_2);
    const Space v166_4 = (has_head(v166_3) ? constant_7 : Space{});
    const Space v166_5 = subtract(constant_5,v166_4);
    Space v166_8;
    if (!v166_5.empty()) {
      const Path v167_6 = concat_path(p0,v165_12_head);
      Space v167_7_result;
      for (int v167_7_label = 1; v167_7_label <= 2; ++v167_7_label) {
        const Space v167_7_tail = child(v165_12_tail,v167_7_label);
        if (v167_7_tail.empty()) continue;
        const Path v167_7_head{v167_7_label};
        const Space v168_2 = singleton(v167_7_head);
        const Space v168_3 = intersect(constant_6,v168_2);
        const Space v168_4 = (has_head(v168_3) ? constant_7 : Space{});
        const Space v168_5 = subtract(constant_5,v168_4);
        Space v168_8;
        if (!v168_5.empty()) {
          const Path v169_6 = concat_path(v167_6,v167_7_head);
          const Space v169_7 = routine_30(c, v169_6, v167_7_tail, s1);
          v168_8 = compose(v168_5,v169_7);
        }
        const Space v168_9 = intersect(constant_6,v168_2);
        const Space v168_10 = (has_head(v168_9) ? constant_7 : Space{});
        Space v168_12;
        if (!v168_10.empty()) {
          const Path v170_6 = concat_path(v167_6,v167_7_head);
          const Space v170_11 = routine_31(c, v170_6, v167_7_tail, s1);
          v168_12 = compose(v168_10,v170_11);
        }
        const Space v168_13 = unite(v168_8,v168_12);
        v167_7_result = unite(v167_7_result,v168_13);
      }
      const Space v167_7 = std::move(v167_7_result);
      v166_8 = compose(v166_5,v167_7);
    }
    const Space v166_9 = intersect(constant_6,v166_2);
    const Space v166_10 = (has_head(v166_9) ? constant_7 : Space{});
    Space v166_12;
    if (!v166_10.empty()) {
      Space v171_11_result;
      for (int v171_11_label = 1; v171_11_label <= 2; ++v171_11_label) {
        const Space v171_11_tail = child(v165_12_tail,v171_11_label);
        if (v171_11_tail.empty()) continue;
        const Path v171_11_head{v171_11_label};
        const Space v172_2 = singleton(v171_11_head);
        const Space v172_3 = intersect(constant_6,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_7 : Space{});
        const Space v172_5 = subtract(constant_5,v172_4);
        Space v172_7;
        if (!v172_5.empty()) {
          const Space v173_6 = routine_32(c, v171_11_head, v171_11_tail, s1);
          v172_7 = compose(v172_5,v173_6);
        }
        const Space v172_8 = intersect(constant_6,v172_2);
        const Space v172_9 = (has_head(v172_8) ? constant_7 : Space{});
        Space v172_11;
        if (!v172_9.empty()) {
          const Space v174_10 = routine_33(c, v171_11_head, v171_11_tail, s1);
          v172_11 = compose(v172_9,v174_10);
        }
        const Space v172_12 = unite(v172_7,v172_11);
        v171_11_result = unite(v171_11_result,v172_12);
      }
      const Space v171_11 = std::move(v171_11_result);
      v166_12 = compose(v166_10,v171_11);
    }
    const Path v175_6 = concat_path(p0,v165_12_head);
    const Space v166_13 = wrap(v166_12,v175_6);
    const Space v166_14 = unite(v166_8,v166_13);
    v165_12_result = unite(v165_12_result,v166_14);
  }
  const Space v165_12 = std::move(v165_12_result);
  return v165_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v176_12_result;
  for (int v176_12_label = 1; v176_12_label <= 2; ++v176_12_label) {
    const Space v176_12_tail = child(s0,v176_12_label);
    if (v176_12_tail.empty()) continue;
    const Path v176_12_head{v176_12_label};
    const Space v177_2 = singleton(v176_12_head);
    const Space v177_3 = intersect(constant_6,v177_2);
    const Space v177_4 = (has_head(v177_3) ? constant_7 : Space{});
    const Space v177_5 = subtract(constant_5,v177_4);
    Space v177_7;
    if (!v177_5.empty()) {
      Space v178_6_result;
      for (int v178_6_label = 1; v178_6_label <= 2; ++v178_6_label) {
        const Space v178_6_tail = child(v176_12_tail,v178_6_label);
        if (v178_6_tail.empty()) continue;
        const Path v178_6_head{v178_6_label};
        const Space v179_2 = singleton(v178_6_head);
        const Space v179_3 = intersect(constant_6,v179_2);
        const Space v179_4 = (has_head(v179_3) ? constant_7 : Space{});
        const Space v179_5 = subtract(constant_5,v179_4);
        Space v179_8;
        if (!v179_5.empty()) {
          const Path v180_6 = concat_path(v176_12_head,v178_6_head);
          const Space v180_7 = routine_34(c, v180_6, v178_6_tail, s1);
          v179_8 = compose(v179_5,v180_7);
        }
        const Space v179_9 = intersect(constant_6,v179_2);
        const Space v179_10 = (has_head(v179_9) ? constant_7 : Space{});
        Space v179_12;
        if (!v179_10.empty()) {
          const Path v181_6 = concat_path(v176_12_head,v178_6_head);
          const Space v181_11 = routine_35(c, v181_6, v178_6_tail, s1);
          v179_12 = compose(v179_10,v181_11);
        }
        const Space v179_13 = unite(v179_8,v179_12);
        v178_6_result = unite(v178_6_result,v179_13);
      }
      const Space v178_6 = std::move(v178_6_result);
      v177_7 = compose(v177_5,v178_6);
    }
    const Space v177_8 = intersect(constant_6,v177_2);
    const Space v177_9 = (has_head(v177_8) ? constant_7 : Space{});
    Space v177_11;
    if (!v177_9.empty()) {
      Space v182_10_result;
      for (int v182_10_label = 1; v182_10_label <= 2; ++v182_10_label) {
        const Space v182_10_tail = child(v176_12_tail,v182_10_label);
        if (v182_10_tail.empty()) continue;
        const Path v182_10_head{v182_10_label};
        const Space v183_2 = singleton(v182_10_head);
        const Space v183_3 = intersect(constant_6,v183_2);
        const Space v183_4 = (has_head(v183_3) ? constant_7 : Space{});
        const Space v183_5 = subtract(constant_5,v183_4);
        Space v183_8;
        if (!v183_5.empty()) {
          const Path v184_6 = concat_path(v176_12_head,v182_10_head);
          const Space v184_7 = routine_34(c, v184_6, v182_10_tail, s1);
          v183_8 = compose(v183_5,v184_7);
        }
        const Space v183_9 = intersect(constant_6,v183_2);
        const Space v183_10 = (has_head(v183_9) ? constant_7 : Space{});
        Space v183_12;
        if (!v183_10.empty()) {
          const Path v185_6 = concat_path(v176_12_head,v182_10_head);
          const Space v185_11 = routine_36(c, v185_6, v182_10_tail, s1);
          v183_12 = compose(v183_10,v185_11);
        }
        const Space v183_13 = unite(v183_8,v183_12);
        v182_10_result = unite(v182_10_result,v183_13);
      }
      const Space v182_10 = std::move(v182_10_result);
      v177_11 = compose(v177_9,v182_10);
    }
    const Space v177_12 = unite(v177_7,v177_11);
    v176_12_result = unite(v176_12_result,v177_12);
  }
  const Space v176_12 = std::move(v176_12_result);
  const Space v176_13 = wrap(v176_12,p0);
  return v176_13;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v186_12_result;
  for (int v186_12_label = 1; v186_12_label <= 2; ++v186_12_label) {
    const Space v186_12_tail = child(s0,v186_12_label);
    if (v186_12_tail.empty()) continue;
    const Path v186_12_head{v186_12_label};
    const Space v187_2 = singleton(v186_12_head);
    const Space v187_3 = intersect(constant_6,v187_2);
    const Space v187_4 = (has_head(v187_3) ? constant_7 : Space{});
    const Space v187_5 = subtract(constant_5,v187_4);
    Space v187_8;
    if (!v187_5.empty()) {
      const Path v188_6 = concat_path(p0,v186_12_head);
      Space v188_7_result;
      for (int v188_7_label = 1; v188_7_label <= 2; ++v188_7_label) {
        const Space v188_7_tail = child(v186_12_tail,v188_7_label);
        if (v188_7_tail.empty()) continue;
        const Path v188_7_head{v188_7_label};
        const Space v189_2 = singleton(v188_7_head);
        const Space v189_3 = intersect(constant_6,v189_2);
        const Space v189_4 = (has_head(v189_3) ? constant_7 : Space{});
        const Space v189_5 = subtract(constant_5,v189_4);
        Space v189_8;
        if (!v189_5.empty()) {
          const Path v190_6 = concat_path(v188_6,v188_7_head);
          const Space v190_7 = routine_37(c, v190_6, v188_7_tail, s1);
          v189_8 = compose(v189_5,v190_7);
        }
        const Space v189_9 = intersect(constant_6,v189_2);
        const Space v189_10 = (has_head(v189_9) ? constant_7 : Space{});
        Space v189_12;
        if (!v189_10.empty()) {
          const Path v191_6 = concat_path(v188_6,v188_7_head);
          const Space v191_11 = routine_38(c, v191_6, v188_7_tail, s1);
          v189_12 = compose(v189_10,v191_11);
        }
        const Space v189_13 = unite(v189_8,v189_12);
        v188_7_result = unite(v188_7_result,v189_13);
      }
      const Space v188_7 = std::move(v188_7_result);
      v187_8 = compose(v187_5,v188_7);
    }
    const Space v187_9 = intersect(constant_6,v187_2);
    const Space v187_10 = (has_head(v187_9) ? constant_7 : Space{});
    Space v187_12;
    if (!v187_10.empty()) {
      const Path v192_6 = concat_path(p0,v186_12_head);
      Space v192_11_result;
      for (int v192_11_label = 1; v192_11_label <= 2; ++v192_11_label) {
        const Space v192_11_tail = child(v186_12_tail,v192_11_label);
        if (v192_11_tail.empty()) continue;
        const Path v192_11_head{v192_11_label};
        const Space v193_2 = singleton(v192_11_head);
        const Space v193_3 = intersect(constant_6,v193_2);
        const Space v193_4 = (has_head(v193_3) ? constant_7 : Space{});
        const Space v193_5 = subtract(constant_5,v193_4);
        Space v193_8;
        if (!v193_5.empty()) {
          const Path v194_6 = concat_path(v192_6,v192_11_head);
          const Space v194_7 = routine_37(c, v194_6, v192_11_tail, s1);
          v193_8 = compose(v193_5,v194_7);
        }
        const Space v193_9 = intersect(constant_6,v193_2);
        const Space v193_10 = (has_head(v193_9) ? constant_7 : Space{});
        Space v193_12;
        if (!v193_10.empty()) {
          const Path v195_6 = concat_path(v192_6,v192_11_head);
          const Space v195_11 = routine_4(c, v195_6, v192_11_tail, s1);
          v193_12 = compose(v193_10,v195_11);
        }
        const Space v193_13 = unite(v193_8,v193_12);
        v192_11_result = unite(v192_11_result,v193_13);
      }
      const Space v192_11 = std::move(v192_11_result);
      v187_12 = compose(v187_10,v192_11);
    }
    const Space v187_13 = unite(v187_8,v187_12);
    v186_12_result = unite(v186_12_result,v187_13);
  }
  const Space v186_12 = std::move(v186_12_result);
  return v186_12;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v196_12_result;
  for (int v196_12_label = 1; v196_12_label <= 2; ++v196_12_label) {
    const Space v196_12_tail = child(s0,v196_12_label);
    if (v196_12_tail.empty()) continue;
    const Path v196_12_head{v196_12_label};
    const Space v197_2 = singleton(v196_12_head);
    const Space v197_3 = intersect(constant_6,v197_2);
    const Space v197_4 = (has_head(v197_3) ? constant_7 : Space{});
    const Space v197_5 = subtract(constant_5,v197_4);
    Space v197_8;
    if (!v197_5.empty()) {
      const Path v198_6 = concat_path(p0,v196_12_head);
      Space v198_7_result;
      for (int v198_7_label = 1; v198_7_label <= 2; ++v198_7_label) {
        const Space v198_7_tail = child(v196_12_tail,v198_7_label);
        if (v198_7_tail.empty()) continue;
        const Path v198_7_head{v198_7_label};
        const Space v199_2 = singleton(v198_7_head);
        const Space v199_3 = intersect(constant_6,v199_2);
        const Space v199_4 = (has_head(v199_3) ? constant_7 : Space{});
        const Space v199_5 = subtract(constant_5,v199_4);
        Space v199_8;
        if (!v199_5.empty()) {
          const Path v200_6 = concat_path(v198_6,v198_7_head);
          const Space v200_7 = routine_37(c, v200_6, v198_7_tail, s1);
          v199_8 = compose(v199_5,v200_7);
        }
        const Space v199_9 = intersect(constant_6,v199_2);
        const Space v199_10 = (has_head(v199_9) ? constant_7 : Space{});
        Space v199_12;
        if (!v199_10.empty()) {
          const Path v201_6 = concat_path(v198_6,v198_7_head);
          const Space v201_11 = routine_38(c, v201_6, v198_7_tail, s1);
          v199_12 = compose(v199_10,v201_11);
        }
        const Space v199_13 = unite(v199_8,v199_12);
        v198_7_result = unite(v198_7_result,v199_13);
      }
      const Space v198_7 = std::move(v198_7_result);
      v197_8 = compose(v197_5,v198_7);
    }
    const Space v197_9 = intersect(constant_6,v197_2);
    const Space v197_10 = (has_head(v197_9) ? constant_7 : Space{});
    Space v197_12;
    if (!v197_10.empty()) {
      Space v202_11_result;
      for (int v202_11_label = 1; v202_11_label <= 2; ++v202_11_label) {
        const Space v202_11_tail = child(v196_12_tail,v202_11_label);
        if (v202_11_tail.empty()) continue;
        const Path v202_11_head{v202_11_label};
        const Space v203_2 = singleton(v202_11_head);
        const Space v203_3 = intersect(constant_6,v203_2);
        const Space v203_4 = (has_head(v203_3) ? constant_7 : Space{});
        const Space v203_5 = subtract(constant_5,v203_4);
        Space v203_7;
        if (!v203_5.empty()) {
          const Space v204_6 = routine_16(c, v202_11_head, v202_11_tail, s1);
          v203_7 = compose(v203_5,v204_6);
        }
        const Space v203_8 = intersect(constant_6,v203_2);
        const Space v203_9 = (has_head(v203_8) ? constant_7 : Space{});
        Space v203_11;
        if (!v203_9.empty()) {
          const Space v205_10 = routine_17(c, v202_11_head, v202_11_tail, s1);
          v203_11 = compose(v203_9,v205_10);
        }
        const Space v203_12 = unite(v203_7,v203_11);
        v202_11_result = unite(v202_11_result,v203_12);
      }
      const Space v202_11 = std::move(v202_11_result);
      v197_12 = compose(v197_10,v202_11);
    }
    const Path v206_6 = concat_path(p0,v196_12_head);
    const Space v197_13 = wrap(v197_12,v206_6);
    const Space v197_14 = unite(v197_8,v197_13);
    v196_12_result = unite(v196_12_result,v197_14);
  }
  const Space v196_12 = std::move(v196_12_result);
  return v196_12;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v207_12_result;
  for (int v207_12_label = 1; v207_12_label <= 2; ++v207_12_label) {
    const Space v207_12_tail = child(s0,v207_12_label);
    if (v207_12_tail.empty()) continue;
    const Path v207_12_head{v207_12_label};
    const Space v208_2 = singleton(v207_12_head);
    const Space v208_3 = intersect(constant_6,v208_2);
    const Space v208_4 = (has_head(v208_3) ? constant_7 : Space{});
    const Space v208_5 = subtract(constant_5,v208_4);
    Space v208_8;
    if (!v208_5.empty()) {
      const Path v209_6 = concat_path(p0,v207_12_head);
      Space v209_7_result;
      for (int v209_7_label = 1; v209_7_label <= 2; ++v209_7_label) {
        const Space v209_7_tail = child(v207_12_tail,v209_7_label);
        if (v209_7_tail.empty()) continue;
        const Path v209_7_head{v209_7_label};
        const Space v210_2 = singleton(v209_7_head);
        const Space v210_3 = intersect(constant_6,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_7 : Space{});
        const Space v210_5 = subtract(constant_5,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_7_head);
          const Space v211_7 = routine_39(c, v211_6, v209_7_tail, s1);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_6,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_7 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_7_head);
          const Space v212_11 = routine_40(c, v212_6, v209_7_tail, s1);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_7_result = unite(v209_7_result,v210_13);
      }
      const Space v209_7 = std::move(v209_7_result);
      v208_8 = compose(v208_5,v209_7);
    }
    const Space v208_9 = intersect(constant_6,v208_2);
    const Space v208_10 = (has_head(v208_9) ? constant_7 : Space{});
    Space v208_12;
    if (!v208_10.empty()) {
      const Path v213_6 = concat_path(p0,v207_12_head);
      Space v213_11_result;
      for (int v213_11_label = 1; v213_11_label <= 2; ++v213_11_label) {
        const Space v213_11_tail = child(v207_12_tail,v213_11_label);
        if (v213_11_tail.empty()) continue;
        const Path v213_11_head{v213_11_label};
        const Space v214_2 = singleton(v213_11_head);
        const Space v214_3 = intersect(constant_6,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_7 : Space{});
        const Space v214_5 = subtract(constant_5,v214_4);
        Space v214_8;
        if (!v214_5.empty()) {
          const Path v215_6 = concat_path(v213_6,v213_11_head);
          const Space v215_7 = routine_39(c, v215_6, v213_11_tail, s1);
          v214_8 = compose(v214_5,v215_7);
        }
        const Space v214_9 = intersect(constant_6,v214_2);
        const Space v214_10 = (has_head(v214_9) ? constant_7 : Space{});
        Space v214_12;
        if (!v214_10.empty()) {
          const Path v216_6 = concat_path(v213_6,v213_11_head);
          const Space v216_11 = routine_20(c, v216_6, v213_11_tail, s1);
          v214_12 = compose(v214_10,v216_11);
        }
        const Space v214_13 = unite(v214_8,v214_12);
        v213_11_result = unite(v213_11_result,v214_13);
      }
      const Space v213_11 = std::move(v213_11_result);
      v208_12 = compose(v208_10,v213_11);
    }
    const Space v208_13 = unite(v208_8,v208_12);
    v207_12_result = unite(v207_12_result,v208_13);
  }
  const Space v207_12 = std::move(v207_12_result);
  return v207_12;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v217_7 = unwrap(s1,constant_8);
  const Space v217_9 = unwrap(v217_7,constant_4);
  const Space v217_10 = unwrap(v217_9,p0);
  Space v217_15_result;
  for (int v217_15_label = 1; v217_15_label <= 2; ++v217_15_label) {
    const Space v217_15_tail = child(s0,v217_15_label);
    if (v217_15_tail.empty()) continue;
    const Path v217_15_head{v217_15_label};
    const Space v218_2 = singleton(v217_15_head);
    const Space v218_3 = intersect(constant_6,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_7 : Space{});
    const Space v218_5 = subtract(constant_5,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_15_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_15_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_6,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_7 : Space{});
        const Space v220_5 = subtract(constant_5,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_39(c, v221_6, v219_7_tail, s1);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_6,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_7 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_40(c, v222_6, v219_7_tail, s1);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_6,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_7 : Space{});
    const Space v218_11 = unwrap(v217_10,v217_15_head);
    const Space v218_12 = subtract(v218_11,constant_5);
    const Space v218_13 = compose(v218_10,v218_12);
    const Space v218_14 = unite(v218_8,v218_13);
    v217_15_result = unite(v217_15_result,v218_14);
  }
  const Space v217_15 = std::move(v217_15_result);
  return v217_15;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v223_12_result;
  for (int v223_12_label = 1; v223_12_label <= 2; ++v223_12_label) {
    const Space v223_12_tail = child(s0,v223_12_label);
    if (v223_12_tail.empty()) continue;
    const Path v223_12_head{v223_12_label};
    const Space v224_2 = singleton(v223_12_head);
    const Space v224_3 = intersect(constant_6,v224_2);
    const Space v224_4 = (has_head(v224_3) ? constant_7 : Space{});
    const Space v224_5 = subtract(constant_5,v224_4);
    Space v224_8;
    if (!v224_5.empty()) {
      const Path v225_6 = concat_path(p0,v223_12_head);
      Space v225_7_result;
      for (int v225_7_label = 1; v225_7_label <= 2; ++v225_7_label) {
        const Space v225_7_tail = child(v223_12_tail,v225_7_label);
        if (v225_7_tail.empty()) continue;
        const Path v225_7_head{v225_7_label};
        const Space v226_2 = singleton(v225_7_head);
        const Space v226_3 = intersect(constant_6,v226_2);
        const Space v226_4 = (has_head(v226_3) ? constant_7 : Space{});
        const Space v226_5 = subtract(constant_5,v226_4);
        Space v226_8;
        if (!v226_5.empty()) {
          const Path v227_6 = concat_path(v225_6,v225_7_head);
          const Space v227_7 = routine_41(c, v227_6, v225_7_tail, s1);
          v226_8 = compose(v226_5,v227_7);
        }
        const Space v226_9 = intersect(constant_6,v226_2);
        const Space v226_10 = (has_head(v226_9) ? constant_7 : Space{});
        Space v226_12;
        if (!v226_10.empty()) {
          const Path v228_6 = concat_path(v225_6,v225_7_head);
          const Space v228_11 = routine_42(c, v228_6, v225_7_tail, s1);
          v226_12 = compose(v226_10,v228_11);
        }
        const Space v226_13 = unite(v226_8,v226_12);
        v225_7_result = unite(v225_7_result,v226_13);
      }
      const Space v225_7 = std::move(v225_7_result);
      v224_8 = compose(v224_5,v225_7);
    }
    const Space v224_9 = intersect(constant_6,v224_2);
    const Space v224_10 = (has_head(v224_9) ? constant_7 : Space{});
    Space v224_12;
    if (!v224_10.empty()) {
      const Path v229_6 = concat_path(p0,v223_12_head);
      Space v229_11_result;
      for (int v229_11_label = 1; v229_11_label <= 2; ++v229_11_label) {
        const Space v229_11_tail = child(v223_12_tail,v229_11_label);
        if (v229_11_tail.empty()) continue;
        const Path v229_11_head{v229_11_label};
        const Space v230_2 = singleton(v229_11_head);
        const Space v230_3 = intersect(constant_6,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_7 : Space{});
        const Space v230_5 = subtract(constant_5,v230_4);
        Space v230_8;
        if (!v230_5.empty()) {
          const Path v231_6 = concat_path(v229_6,v229_11_head);
          const Space v231_7 = routine_41(c, v231_6, v229_11_tail, s1);
          v230_8 = compose(v230_5,v231_7);
        }
        const Space v230_9 = intersect(constant_6,v230_2);
        const Space v230_10 = (has_head(v230_9) ? constant_7 : Space{});
        Space v230_12;
        if (!v230_10.empty()) {
          const Path v232_6 = concat_path(v229_6,v229_11_head);
          const Space v232_11 = routine_20(c, v232_6, v229_11_tail, s1);
          v230_12 = compose(v230_10,v232_11);
        }
        const Space v230_13 = unite(v230_8,v230_12);
        v229_11_result = unite(v229_11_result,v230_13);
      }
      const Space v229_11 = std::move(v229_11_result);
      v224_12 = compose(v224_10,v229_11);
    }
    const Space v224_13 = unite(v224_8,v224_12);
    v223_12_result = unite(v223_12_result,v224_13);
  }
  const Space v223_12 = std::move(v223_12_result);
  return v223_12;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v233_7 = unwrap(s1,constant_8);
  const Space v233_9 = unwrap(v233_7,constant_4);
  const Space v233_10 = unwrap(v233_9,p0);
  Space v233_15_result;
  for (int v233_15_label = 1; v233_15_label <= 2; ++v233_15_label) {
    const Space v233_15_tail = child(s0,v233_15_label);
    if (v233_15_tail.empty()) continue;
    const Path v233_15_head{v233_15_label};
    const Space v234_2 = singleton(v233_15_head);
    const Space v234_3 = intersect(constant_6,v234_2);
    const Space v234_4 = (has_head(v234_3) ? constant_7 : Space{});
    const Space v234_5 = subtract(constant_5,v234_4);
    Space v234_8;
    if (!v234_5.empty()) {
      const Path v235_6 = concat_path(p0,v233_15_head);
      Space v235_7_result;
      for (int v235_7_label = 1; v235_7_label <= 2; ++v235_7_label) {
        const Space v235_7_tail = child(v233_15_tail,v235_7_label);
        if (v235_7_tail.empty()) continue;
        const Path v235_7_head{v235_7_label};
        const Space v236_2 = singleton(v235_7_head);
        const Space v236_3 = intersect(constant_6,v236_2);
        const Space v236_4 = (has_head(v236_3) ? constant_7 : Space{});
        const Space v236_5 = subtract(constant_5,v236_4);
        Space v236_8;
        if (!v236_5.empty()) {
          const Path v237_6 = concat_path(v235_6,v235_7_head);
          const Space v237_7 = routine_41(c, v237_6, v235_7_tail, s1);
          v236_8 = compose(v236_5,v237_7);
        }
        const Space v236_9 = intersect(constant_6,v236_2);
        const Space v236_10 = (has_head(v236_9) ? constant_7 : Space{});
        Space v236_12;
        if (!v236_10.empty()) {
          const Path v238_6 = concat_path(v235_6,v235_7_head);
          const Space v238_11 = routine_42(c, v238_6, v235_7_tail, s1);
          v236_12 = compose(v236_10,v238_11);
        }
        const Space v236_13 = unite(v236_8,v236_12);
        v235_7_result = unite(v235_7_result,v236_13);
      }
      const Space v235_7 = std::move(v235_7_result);
      v234_8 = compose(v234_5,v235_7);
    }
    const Space v234_9 = intersect(constant_6,v234_2);
    const Space v234_10 = (has_head(v234_9) ? constant_7 : Space{});
    const Space v234_11 = unwrap(v233_10,v233_15_head);
    const Space v234_12 = subtract(v234_11,constant_5);
    const Space v234_13 = compose(v234_10,v234_12);
    const Space v234_14 = unite(v234_8,v234_13);
    v233_15_result = unite(v233_15_result,v234_14);
  }
  const Space v233_15 = std::move(v233_15_result);
  return v233_15;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v239_4 = unwrap(s1,constant_8);
  const Space v239_6 = unwrap(v239_4,constant_4);
  const Space v239_7 = unwrap(v239_6,p0);
  const Space v239_9 = subtract(v239_7,constant_5);
  return v239_9;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v240_12_result;
  for (int v240_12_label = 1; v240_12_label <= 2; ++v240_12_label) {
    const Space v240_12_tail = child(s0,v240_12_label);
    if (v240_12_tail.empty()) continue;
    const Path v240_12_head{v240_12_label};
    const Space v241_2 = singleton(v240_12_head);
    const Space v241_3 = intersect(constant_6,v241_2);
    const Space v241_4 = (has_head(v241_3) ? constant_7 : Space{});
    const Space v241_5 = subtract(constant_5,v241_4);
    Space v241_8;
    if (!v241_5.empty()) {
      const Path v242_6 = concat_path(p0,v240_12_head);
      Space v242_7_result;
      for (int v242_7_label = 1; v242_7_label <= 2; ++v242_7_label) {
        const Space v242_7_tail = child(v240_12_tail,v242_7_label);
        if (v242_7_tail.empty()) continue;
        const Path v242_7_head{v242_7_label};
        const Space v243_2 = singleton(v242_7_head);
        const Space v243_3 = intersect(constant_6,v243_2);
        const Space v243_4 = (has_head(v243_3) ? constant_7 : Space{});
        const Space v243_5 = subtract(constant_5,v243_4);
        Space v243_8;
        if (!v243_5.empty()) {
          const Path v244_6 = concat_path(v242_6,v242_7_head);
          const Space v244_7 = routine_43(c, v244_6, v242_7_tail, s1);
          v243_8 = compose(v243_5,v244_7);
        }
        const Space v243_9 = intersect(constant_6,v243_2);
        const Space v243_10 = (has_head(v243_9) ? constant_7 : Space{});
        Space v243_12;
        if (!v243_10.empty()) {
          const Path v245_6 = concat_path(v242_6,v242_7_head);
          const Space v245_11 = routine_44(c, v245_6, v242_7_tail, s1);
          v243_12 = compose(v243_10,v245_11);
        }
        const Space v243_13 = unite(v243_8,v243_12);
        v242_7_result = unite(v242_7_result,v243_13);
      }
      const Space v242_7 = std::move(v242_7_result);
      v241_8 = compose(v241_5,v242_7);
    }
    const Space v241_9 = intersect(constant_6,v241_2);
    const Space v241_10 = (has_head(v241_9) ? constant_7 : Space{});
    Space v241_12;
    if (!v241_10.empty()) {
      const Path v246_6 = concat_path(p0,v240_12_head);
      Space v246_11_result;
      for (int v246_11_label = 1; v246_11_label <= 2; ++v246_11_label) {
        const Space v246_11_tail = child(v240_12_tail,v246_11_label);
        if (v246_11_tail.empty()) continue;
        const Path v246_11_head{v246_11_label};
        const Space v247_2 = singleton(v246_11_head);
        const Space v247_3 = intersect(constant_6,v247_2);
        const Space v247_4 = (has_head(v247_3) ? constant_7 : Space{});
        const Space v247_5 = subtract(constant_5,v247_4);
        Space v247_8;
        if (!v247_5.empty()) {
          const Path v248_6 = concat_path(v246_6,v246_11_head);
          const Space v248_7 = routine_43(c, v248_6, v246_11_tail, s1);
          v247_8 = compose(v247_5,v248_7);
        }
        const Space v247_9 = intersect(constant_6,v247_2);
        const Space v247_10 = (has_head(v247_9) ? constant_7 : Space{});
        Space v247_12;
        if (!v247_10.empty()) {
          const Path v249_6 = concat_path(v246_6,v246_11_head);
          const Space v249_11 = routine_7(c, v249_6, v246_11_tail, s1);
          v247_12 = compose(v247_10,v249_11);
        }
        const Space v247_13 = unite(v247_8,v247_12);
        v246_11_result = unite(v246_11_result,v247_13);
      }
      const Space v246_11 = std::move(v246_11_result);
      v241_12 = compose(v241_10,v246_11);
    }
    const Space v241_13 = unite(v241_8,v241_12);
    v240_12_result = unite(v240_12_result,v241_13);
  }
  const Space v240_12 = std::move(v240_12_result);
  return v240_12;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v250_12_result;
  for (int v250_12_label = 1; v250_12_label <= 2; ++v250_12_label) {
    const Space v250_12_tail = child(s0,v250_12_label);
    if (v250_12_tail.empty()) continue;
    const Path v250_12_head{v250_12_label};
    const Space v251_2 = singleton(v250_12_head);
    const Space v251_3 = intersect(constant_6,v251_2);
    const Space v251_4 = (has_head(v251_3) ? constant_7 : Space{});
    const Space v251_5 = subtract(constant_5,v251_4);
    Space v251_8;
    if (!v251_5.empty()) {
      const Path v252_6 = concat_path(p0,v250_12_head);
      Space v252_7_result;
      for (int v252_7_label = 1; v252_7_label <= 2; ++v252_7_label) {
        const Space v252_7_tail = child(v250_12_tail,v252_7_label);
        if (v252_7_tail.empty()) continue;
        const Path v252_7_head{v252_7_label};
        const Space v253_2 = singleton(v252_7_head);
        const Space v253_3 = intersect(constant_6,v253_2);
        const Space v253_4 = (has_head(v253_3) ? constant_7 : Space{});
        const Space v253_5 = subtract(constant_5,v253_4);
        Space v253_8;
        if (!v253_5.empty()) {
          const Path v254_6 = concat_path(v252_6,v252_7_head);
          const Space v254_7 = routine_43(c, v254_6, v252_7_tail, s1);
          v253_8 = compose(v253_5,v254_7);
        }
        const Space v253_9 = intersect(constant_6,v253_2);
        const Space v253_10 = (has_head(v253_9) ? constant_7 : Space{});
        Space v253_12;
        if (!v253_10.empty()) {
          const Path v255_6 = concat_path(v252_6,v252_7_head);
          const Space v255_11 = routine_44(c, v255_6, v252_7_tail, s1);
          v253_12 = compose(v253_10,v255_11);
        }
        const Space v253_13 = unite(v253_8,v253_12);
        v252_7_result = unite(v252_7_result,v253_13);
      }
      const Space v252_7 = std::move(v252_7_result);
      v251_8 = compose(v251_5,v252_7);
    }
    const Space v251_9 = intersect(constant_6,v251_2);
    const Space v251_10 = (has_head(v251_9) ? constant_7 : Space{});
    Space v251_12;
    if (!v251_10.empty()) {
      Space v256_11_result;
      for (int v256_11_label = 1; v256_11_label <= 2; ++v256_11_label) {
        const Space v256_11_tail = child(v250_12_tail,v256_11_label);
        if (v256_11_tail.empty()) continue;
        const Path v256_11_head{v256_11_label};
        const Space v257_2 = singleton(v256_11_head);
        const Space v257_3 = intersect(constant_6,v257_2);
        const Space v257_4 = (has_head(v257_3) ? constant_7 : Space{});
        const Space v257_5 = subtract(constant_5,v257_4);
        Space v257_7;
        if (!v257_5.empty()) {
          const Space v258_6 = routine_23(c, v256_11_head, v256_11_tail, s1);
          v257_7 = compose(v257_5,v258_6);
        }
        const Space v257_8 = intersect(constant_6,v257_2);
        const Space v257_9 = (has_head(v257_8) ? constant_7 : Space{});
        Space v257_11;
        if (!v257_9.empty()) {
          const Space v259_10 = routine_24(c, v256_11_head, v256_11_tail, s1);
          v257_11 = compose(v257_9,v259_10);
        }
        const Space v257_12 = unite(v257_7,v257_11);
        v256_11_result = unite(v256_11_result,v257_12);
      }
      const Space v256_11 = std::move(v256_11_result);
      v251_12 = compose(v251_10,v256_11);
    }
    const Path v260_6 = concat_path(p0,v250_12_head);
    const Space v251_13 = wrap(v251_12,v260_6);
    const Space v251_14 = unite(v251_8,v251_13);
    v250_12_result = unite(v250_12_result,v251_14);
  }
  const Space v250_12 = std::move(v250_12_result);
  return v250_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v261_12_result;
  for (int v261_12_label = 1; v261_12_label <= 2; ++v261_12_label) {
    const Space v261_12_tail = child(s0,v261_12_label);
    if (v261_12_tail.empty()) continue;
    const Path v261_12_head{v261_12_label};
    const Space v262_2 = singleton(v261_12_head);
    const Space v262_3 = intersect(constant_6,v262_2);
    const Space v262_4 = (has_head(v262_3) ? constant_7 : Space{});
    const Space v262_5 = subtract(constant_5,v262_4);
    Space v262_8;
    if (!v262_5.empty()) {
      const Path v263_6 = concat_path(p0,v261_12_head);
      Space v263_7_result;
      for (int v263_7_label = 1; v263_7_label <= 2; ++v263_7_label) {
        const Space v263_7_tail = child(v261_12_tail,v263_7_label);
        if (v263_7_tail.empty()) continue;
        const Path v263_7_head{v263_7_label};
        const Space v264_2 = singleton(v263_7_head);
        const Space v264_3 = intersect(constant_6,v264_2);
        const Space v264_4 = (has_head(v264_3) ? constant_7 : Space{});
        const Space v264_5 = subtract(constant_5,v264_4);
        Space v264_8;
        if (!v264_5.empty()) {
          const Path v265_6 = concat_path(v263_6,v263_7_head);
          const Space v265_7 = routine_45(c, v265_6, v263_7_tail, s1);
          v264_8 = compose(v264_5,v265_7);
        }
        const Space v264_9 = intersect(constant_6,v264_2);
        const Space v264_10 = (has_head(v264_9) ? constant_7 : Space{});
        Space v264_12;
        if (!v264_10.empty()) {
          const Path v266_6 = concat_path(v263_6,v263_7_head);
          const Space v266_11 = routine_46(c, v266_6, v263_7_tail, s1);
          v264_12 = compose(v264_10,v266_11);
        }
        const Space v264_13 = unite(v264_8,v264_12);
        v263_7_result = unite(v263_7_result,v264_13);
      }
      const Space v263_7 = std::move(v263_7_result);
      v262_8 = compose(v262_5,v263_7);
    }
    const Space v262_9 = intersect(constant_6,v262_2);
    const Space v262_10 = (has_head(v262_9) ? constant_7 : Space{});
    Space v262_12;
    if (!v262_10.empty()) {
      const Path v267_6 = concat_path(p0,v261_12_head);
      Space v267_11_result;
      for (int v267_11_label = 1; v267_11_label <= 2; ++v267_11_label) {
        const Space v267_11_tail = child(v261_12_tail,v267_11_label);
        if (v267_11_tail.empty()) continue;
        const Path v267_11_head{v267_11_label};
        const Space v268_2 = singleton(v267_11_head);
        const Space v268_3 = intersect(constant_6,v268_2);
        const Space v268_4 = (has_head(v268_3) ? constant_7 : Space{});
        const Space v268_5 = subtract(constant_5,v268_4);
        Space v268_8;
        if (!v268_5.empty()) {
          const Path v269_6 = concat_path(v267_6,v267_11_head);
          const Space v269_7 = routine_45(c, v269_6, v267_11_tail, s1);
          v268_8 = compose(v268_5,v269_7);
        }
        const Space v268_9 = intersect(constant_6,v268_2);
        const Space v268_10 = (has_head(v268_9) ? constant_7 : Space{});
        Space v268_12;
        if (!v268_10.empty()) {
          const Path v270_6 = concat_path(v267_6,v267_11_head);
          const Space v270_11 = routine_27(c, v270_6, v267_11_tail, s1);
          v268_12 = compose(v268_10,v270_11);
        }
        const Space v268_13 = unite(v268_8,v268_12);
        v267_11_result = unite(v267_11_result,v268_13);
      }
      const Space v267_11 = std::move(v267_11_result);
      v262_12 = compose(v262_10,v267_11);
    }
    const Space v262_13 = unite(v262_8,v262_12);
    v261_12_result = unite(v261_12_result,v262_13);
  }
  const Space v261_12 = std::move(v261_12_result);
  return v261_12;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v271_7 = unwrap(s1,constant_3);
  const Space v271_9 = unwrap(v271_7,constant_4);
  const Space v271_10 = unwrap(v271_9,p0);
  Space v271_15_result;
  for (int v271_15_label = 1; v271_15_label <= 2; ++v271_15_label) {
    const Space v271_15_tail = child(s0,v271_15_label);
    if (v271_15_tail.empty()) continue;
    const Path v271_15_head{v271_15_label};
    const Space v272_2 = singleton(v271_15_head);
    const Space v272_3 = intersect(constant_6,v272_2);
    const Space v272_4 = (has_head(v272_3) ? constant_7 : Space{});
    const Space v272_5 = subtract(constant_5,v272_4);
    Space v272_8;
    if (!v272_5.empty()) {
      const Path v273_6 = concat_path(p0,v271_15_head);
      Space v273_7_result;
      for (int v273_7_label = 1; v273_7_label <= 2; ++v273_7_label) {
        const Space v273_7_tail = child(v271_15_tail,v273_7_label);
        if (v273_7_tail.empty()) continue;
        const Path v273_7_head{v273_7_label};
        const Space v274_2 = singleton(v273_7_head);
        const Space v274_3 = intersect(constant_6,v274_2);
        const Space v274_4 = (has_head(v274_3) ? constant_7 : Space{});
        const Space v274_5 = subtract(constant_5,v274_4);
        Space v274_8;
        if (!v274_5.empty()) {
          const Path v275_6 = concat_path(v273_6,v273_7_head);
          const Space v275_7 = routine_45(c, v275_6, v273_7_tail, s1);
          v274_8 = compose(v274_5,v275_7);
        }
        const Space v274_9 = intersect(constant_6,v274_2);
        const Space v274_10 = (has_head(v274_9) ? constant_7 : Space{});
        Space v274_12;
        if (!v274_10.empty()) {
          const Path v276_6 = concat_path(v273_6,v273_7_head);
          const Space v276_11 = routine_46(c, v276_6, v273_7_tail, s1);
          v274_12 = compose(v274_10,v276_11);
        }
        const Space v274_13 = unite(v274_8,v274_12);
        v273_7_result = unite(v273_7_result,v274_13);
      }
      const Space v273_7 = std::move(v273_7_result);
      v272_8 = compose(v272_5,v273_7);
    }
    const Space v272_9 = intersect(constant_6,v272_2);
    const Space v272_10 = (has_head(v272_9) ? constant_7 : Space{});
    const Space v272_11 = unwrap(v271_10,v271_15_head);
    const Space v272_12 = subtract(v272_11,constant_5);
    const Space v272_13 = compose(v272_10,v272_12);
    const Space v272_14 = unite(v272_8,v272_13);
    v271_15_result = unite(v271_15_result,v272_14);
  }
  const Space v271_15 = std::move(v271_15_result);
  return v271_15;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v277_12_result;
  for (int v277_12_label = 1; v277_12_label <= 2; ++v277_12_label) {
    const Space v277_12_tail = child(s0,v277_12_label);
    if (v277_12_tail.empty()) continue;
    const Path v277_12_head{v277_12_label};
    const Space v278_2 = singleton(v277_12_head);
    const Space v278_3 = intersect(constant_6,v278_2);
    const Space v278_4 = (has_head(v278_3) ? constant_7 : Space{});
    const Space v278_5 = subtract(constant_5,v278_4);
    Space v278_8;
    if (!v278_5.empty()) {
      const Path v279_6 = concat_path(p0,v277_12_head);
      Space v279_7_result;
      for (int v279_7_label = 1; v279_7_label <= 2; ++v279_7_label) {
        const Space v279_7_tail = child(v277_12_tail,v279_7_label);
        if (v279_7_tail.empty()) continue;
        const Path v279_7_head{v279_7_label};
        const Space v280_2 = singleton(v279_7_head);
        const Space v280_3 = intersect(constant_6,v280_2);
        const Space v280_4 = (has_head(v280_3) ? constant_7 : Space{});
        const Space v280_5 = subtract(constant_5,v280_4);
        Space v280_8;
        if (!v280_5.empty()) {
          const Path v281_6 = concat_path(v279_6,v279_7_head);
          const Space v281_7 = routine_47(c, v281_6, v279_7_tail, s1);
          v280_8 = compose(v280_5,v281_7);
        }
        const Space v280_9 = intersect(constant_6,v280_2);
        const Space v280_10 = (has_head(v280_9) ? constant_7 : Space{});
        Space v280_12;
        if (!v280_10.empty()) {
          const Path v282_6 = concat_path(v279_6,v279_7_head);
          const Space v282_11 = routine_48(c, v282_6, v279_7_tail, s1);
          v280_12 = compose(v280_10,v282_11);
        }
        const Space v280_13 = unite(v280_8,v280_12);
        v279_7_result = unite(v279_7_result,v280_13);
      }
      const Space v279_7 = std::move(v279_7_result);
      v278_8 = compose(v278_5,v279_7);
    }
    const Space v278_9 = intersect(constant_6,v278_2);
    const Space v278_10 = (has_head(v278_9) ? constant_7 : Space{});
    Space v278_12;
    if (!v278_10.empty()) {
      const Path v283_6 = concat_path(p0,v277_12_head);
      Space v283_11_result;
      for (int v283_11_label = 1; v283_11_label <= 2; ++v283_11_label) {
        const Space v283_11_tail = child(v277_12_tail,v283_11_label);
        if (v283_11_tail.empty()) continue;
        const Path v283_11_head{v283_11_label};
        const Space v284_2 = singleton(v283_11_head);
        const Space v284_3 = intersect(constant_6,v284_2);
        const Space v284_4 = (has_head(v284_3) ? constant_7 : Space{});
        const Space v284_5 = subtract(constant_5,v284_4);
        Space v284_8;
        if (!v284_5.empty()) {
          const Path v285_6 = concat_path(v283_6,v283_11_head);
          const Space v285_7 = routine_47(c, v285_6, v283_11_tail, s1);
          v284_8 = compose(v284_5,v285_7);
        }
        const Space v284_9 = intersect(constant_6,v284_2);
        const Space v284_10 = (has_head(v284_9) ? constant_7 : Space{});
        Space v284_12;
        if (!v284_10.empty()) {
          const Path v286_6 = concat_path(v283_6,v283_11_head);
          const Space v286_11 = routine_27(c, v286_6, v283_11_tail, s1);
          v284_12 = compose(v284_10,v286_11);
        }
        const Space v284_13 = unite(v284_8,v284_12);
        v283_11_result = unite(v283_11_result,v284_13);
      }
      const Space v283_11 = std::move(v283_11_result);
      v278_12 = compose(v278_10,v283_11);
    }
    const Space v278_13 = unite(v278_8,v278_12);
    v277_12_result = unite(v277_12_result,v278_13);
  }
  const Space v277_12 = std::move(v277_12_result);
  return v277_12;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v287_7 = unwrap(s1,constant_3);
  const Space v287_9 = unwrap(v287_7,constant_4);
  const Space v287_10 = unwrap(v287_9,p0);
  Space v287_15_result;
  for (int v287_15_label = 1; v287_15_label <= 2; ++v287_15_label) {
    const Space v287_15_tail = child(s0,v287_15_label);
    if (v287_15_tail.empty()) continue;
    const Path v287_15_head{v287_15_label};
    const Space v288_2 = singleton(v287_15_head);
    const Space v288_3 = intersect(constant_6,v288_2);
    const Space v288_4 = (has_head(v288_3) ? constant_7 : Space{});
    const Space v288_5 = subtract(constant_5,v288_4);
    Space v288_8;
    if (!v288_5.empty()) {
      const Path v289_6 = concat_path(p0,v287_15_head);
      Space v289_7_result;
      for (int v289_7_label = 1; v289_7_label <= 2; ++v289_7_label) {
        const Space v289_7_tail = child(v287_15_tail,v289_7_label);
        if (v289_7_tail.empty()) continue;
        const Path v289_7_head{v289_7_label};
        const Space v290_2 = singleton(v289_7_head);
        const Space v290_3 = intersect(constant_6,v290_2);
        const Space v290_4 = (has_head(v290_3) ? constant_7 : Space{});
        const Space v290_5 = subtract(constant_5,v290_4);
        Space v290_8;
        if (!v290_5.empty()) {
          const Path v291_6 = concat_path(v289_6,v289_7_head);
          const Space v291_7 = routine_47(c, v291_6, v289_7_tail, s1);
          v290_8 = compose(v290_5,v291_7);
        }
        const Space v290_9 = intersect(constant_6,v290_2);
        const Space v290_10 = (has_head(v290_9) ? constant_7 : Space{});
        Space v290_12;
        if (!v290_10.empty()) {
          const Path v292_6 = concat_path(v289_6,v289_7_head);
          const Space v292_11 = routine_48(c, v292_6, v289_7_tail, s1);
          v290_12 = compose(v290_10,v292_11);
        }
        const Space v290_13 = unite(v290_8,v290_12);
        v289_7_result = unite(v289_7_result,v290_13);
      }
      const Space v289_7 = std::move(v289_7_result);
      v288_8 = compose(v288_5,v289_7);
    }
    const Space v288_9 = intersect(constant_6,v288_2);
    const Space v288_10 = (has_head(v288_9) ? constant_7 : Space{});
    const Space v288_11 = unwrap(v287_10,v287_15_head);
    const Space v288_12 = subtract(v288_11,constant_5);
    const Space v288_13 = compose(v288_10,v288_12);
    const Space v288_14 = unite(v288_8,v288_13);
    v287_15_result = unite(v287_15_result,v288_14);
  }
  const Space v287_15 = std::move(v287_15_result);
  return v287_15;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v293_4 = unwrap(s1,constant_3);
  const Space v293_6 = unwrap(v293_4,constant_4);
  const Space v293_7 = unwrap(v293_6,p0);
  const Space v293_9 = subtract(v293_7,constant_5);
  return v293_9;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v294_11_result;
  for (int v294_11_label = 1; v294_11_label <= 2; ++v294_11_label) {
    const Space v294_11_tail = child(s0,v294_11_label);
    if (v294_11_tail.empty()) continue;
    const Path v294_11_head{v294_11_label};
    const Space v295_2 = singleton(v294_11_head);
    const Space v295_3 = intersect(constant_6,v295_2);
    const Space v295_4 = (has_head(v295_3) ? constant_7 : Space{});
    const Space v295_5 = subtract(constant_5,v295_4);
    Space v295_8;
    if (!v295_5.empty()) {
      const Path v296_6 = concat_path(p0,v294_11_head);
      Space v296_7_result;
      for (int v296_7_label = 1; v296_7_label <= 2; ++v296_7_label) {
        const Space v296_7_tail = child(v294_11_tail,v296_7_label);
        if (v296_7_tail.empty()) continue;
        const Path v296_7_head{v296_7_label};
        const Space v297_2 = singleton(v296_7_head);
        const Space v297_3 = intersect(constant_6,v297_2);
        const Space v297_4 = (has_head(v297_3) ? constant_7 : Space{});
        const Space v297_5 = subtract(constant_5,v297_4);
        Space v297_8;
        if (!v297_5.empty()) {
          const Path v298_6 = concat_path(v296_6,v296_7_head);
          const Space v298_7 = routine_49(c, v298_6, v296_7_tail);
          v297_8 = compose(v297_5,v298_7);
        }
        const Space v297_9 = intersect(constant_6,v297_2);
        const Space v297_10 = (has_head(v297_9) ? constant_7 : Space{});
        Space v297_12;
        if (!v297_10.empty()) {
          const Path v299_6 = concat_path(v296_6,v296_7_head);
          const Space v299_11 = routine_50(c, v299_6, v296_7_tail);
          v297_12 = compose(v297_10,v299_11);
        }
        const Space v297_13 = unite(v297_8,v297_12);
        v296_7_result = unite(v296_7_result,v297_13);
      }
      const Space v296_7 = std::move(v296_7_result);
      v295_8 = compose(v295_5,v296_7);
    }
    const Space v295_9 = intersect(constant_6,v295_2);
    const Space v295_10 = (has_head(v295_9) ? constant_7 : Space{});
    Space v295_12;
    if (!v295_10.empty()) {
      const Path v300_6 = concat_path(p0,v294_11_head);
      Space v300_11_result;
      for (int v300_11_label = 1; v300_11_label <= 2; ++v300_11_label) {
        const Space v300_11_tail = child(v294_11_tail,v300_11_label);
        if (v300_11_tail.empty()) continue;
        const Path v300_11_head{v300_11_label};
        const Space v301_2 = singleton(v300_11_head);
        const Space v301_3 = intersect(constant_6,v301_2);
        const Space v301_4 = (has_head(v301_3) ? constant_7 : Space{});
        const Space v301_5 = subtract(constant_5,v301_4);
        Space v301_8;
        if (!v301_5.empty()) {
          const Path v302_6 = concat_path(v300_6,v300_11_head);
          const Space v302_7 = routine_49(c, v302_6, v300_11_tail);
          v301_8 = compose(v301_5,v302_7);
        }
        const Space v301_9 = intersect(constant_6,v301_2);
        const Space v301_10 = (has_head(v301_9) ? constant_7 : Space{});
        Space v301_12;
        if (!v301_10.empty()) {
          const Path v303_6 = concat_path(v300_6,v300_11_head);
          const Space v303_11 = routine_10(c, v303_6, v300_11_tail);
          v301_12 = compose(v301_10,v303_11);
        }
        const Space v301_13 = unite(v301_8,v301_12);
        v300_11_result = unite(v300_11_result,v301_13);
      }
      const Space v300_11 = std::move(v300_11_result);
      v295_12 = compose(v295_10,v300_11);
    }
    const Space v295_13 = unite(v295_8,v295_12);
    v294_11_result = unite(v294_11_result,v295_13);
  }
  const Space v294_11 = std::move(v294_11_result);
  return v294_11;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v304_9_result;
  for (int v304_9_label = 1; v304_9_label <= 2; ++v304_9_label) {
    const Space v304_9_tail = child(s0,v304_9_label);
    if (v304_9_tail.empty()) continue;
    const Path v304_9_head{v304_9_label};
    const Space v305_2 = singleton(v304_9_head);
    const Space v305_3 = intersect(constant_6,v305_2);
    const Space v305_4 = (has_head(v305_3) ? constant_7 : Space{});
    const Space v305_5 = subtract(constant_5,v305_4);
    Space v305_8;
    if (!v305_5.empty()) {
      const Path v306_6 = concat_path(p0,v304_9_head);
      Space v306_7_result;
      for (int v306_7_label = 1; v306_7_label <= 2; ++v306_7_label) {
        const Space v306_7_tail = child(v304_9_tail,v306_7_label);
        if (v306_7_tail.empty()) continue;
        const Path v306_7_head{v306_7_label};
        const Space v307_2 = singleton(v306_7_head);
        const Space v307_3 = intersect(constant_6,v307_2);
        const Space v307_4 = (has_head(v307_3) ? constant_7 : Space{});
        const Space v307_5 = subtract(constant_5,v307_4);
        Space v307_8;
        if (!v307_5.empty()) {
          const Path v308_6 = concat_path(v306_6,v306_7_head);
          const Space v308_7 = routine_49(c, v308_6, v306_7_tail);
          v307_8 = compose(v307_5,v308_7);
        }
        const Space v307_9 = intersect(constant_6,v307_2);
        const Space v307_10 = (has_head(v307_9) ? constant_7 : Space{});
        Space v307_12;
        if (!v307_10.empty()) {
          const Path v309_6 = concat_path(v306_6,v306_7_head);
          const Space v309_11 = routine_50(c, v309_6, v306_7_tail);
          v307_12 = compose(v307_10,v309_11);
        }
        const Space v307_13 = unite(v307_8,v307_12);
        v306_7_result = unite(v306_7_result,v307_13);
      }
      const Space v306_7 = std::move(v306_7_result);
      v305_8 = compose(v305_5,v306_7);
    }
    const Space v305_9 = intersect(constant_6,v305_2);
    const Space v305_10 = (has_head(v305_9) ? constant_7 : Space{});
    const Space v305_11 = subtract(v304_9_tail,constant_5);
    const Space v305_12 = compose(v305_10,v305_11);
    const Path v310_6 = concat_path(p0,v304_9_head);
    const Space v305_13 = wrap(v305_12,v310_6);
    const Space v305_14 = unite(v305_8,v305_13);
    v304_9_result = unite(v304_9_result,v305_14);
  }
  const Space v304_9 = std::move(v304_9_result);
  return v304_9;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v311_12_result;
  for (int v311_12_label = 1; v311_12_label <= 2; ++v311_12_label) {
    const Space v311_12_tail = child(s0,v311_12_label);
    if (v311_12_tail.empty()) continue;
    const Path v311_12_head{v311_12_label};
    const Space v312_2 = singleton(v311_12_head);
    const Space v312_3 = intersect(constant_6,v312_2);
    const Space v312_4 = (has_head(v312_3) ? constant_7 : Space{});
    const Space v312_5 = subtract(constant_5,v312_4);
    Space v312_8;
    if (!v312_5.empty()) {
      const Path v313_6 = concat_path(p0,v311_12_head);
      Space v313_7_result;
      for (int v313_7_label = 1; v313_7_label <= 2; ++v313_7_label) {
        const Space v313_7_tail = child(v311_12_tail,v313_7_label);
        if (v313_7_tail.empty()) continue;
        const Path v313_7_head{v313_7_label};
        const Space v314_2 = singleton(v313_7_head);
        const Space v314_3 = intersect(constant_6,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_7 : Space{});
        const Space v314_5 = subtract(constant_5,v314_4);
        Space v314_8;
        if (!v314_5.empty()) {
          const Path v315_6 = concat_path(v313_6,v313_7_head);
          const Space v315_7 = routine_51(c, v315_6, v313_7_tail, s1);
          v314_8 = compose(v314_5,v315_7);
        }
        const Space v314_9 = intersect(constant_6,v314_2);
        const Space v314_10 = (has_head(v314_9) ? constant_7 : Space{});
        Space v314_12;
        if (!v314_10.empty()) {
          const Path v316_6 = concat_path(v313_6,v313_7_head);
          const Space v316_11 = routine_52(c, v316_6, v313_7_tail, s1);
          v314_12 = compose(v314_10,v316_11);
        }
        const Space v314_13 = unite(v314_8,v314_12);
        v313_7_result = unite(v313_7_result,v314_13);
      }
      const Space v313_7 = std::move(v313_7_result);
      v312_8 = compose(v312_5,v313_7);
    }
    const Space v312_9 = intersect(constant_6,v312_2);
    const Space v312_10 = (has_head(v312_9) ? constant_7 : Space{});
    Space v312_12;
    if (!v312_10.empty()) {
      const Path v317_6 = concat_path(p0,v311_12_head);
      Space v317_11_result;
      for (int v317_11_label = 1; v317_11_label <= 2; ++v317_11_label) {
        const Space v317_11_tail = child(v311_12_tail,v317_11_label);
        if (v317_11_tail.empty()) continue;
        const Path v317_11_head{v317_11_label};
        const Space v318_2 = singleton(v317_11_head);
        const Space v318_3 = intersect(constant_6,v318_2);
        const Space v318_4 = (has_head(v318_3) ? constant_7 : Space{});
        const Space v318_5 = subtract(constant_5,v318_4);
        Space v318_8;
        if (!v318_5.empty()) {
          const Path v319_6 = concat_path(v317_6,v317_11_head);
          const Space v319_7 = routine_51(c, v319_6, v317_11_tail, s1);
          v318_8 = compose(v318_5,v319_7);
        }
        const Space v318_9 = intersect(constant_6,v318_2);
        const Space v318_10 = (has_head(v318_9) ? constant_7 : Space{});
        Space v318_12;
        if (!v318_10.empty()) {
          const Path v320_6 = concat_path(v317_6,v317_11_head);
          const Space v320_11 = routine_13(c, v320_6, v317_11_tail, s1);
          v318_12 = compose(v318_10,v320_11);
        }
        const Space v318_13 = unite(v318_8,v318_12);
        v317_11_result = unite(v317_11_result,v318_13);
      }
      const Space v317_11 = std::move(v317_11_result);
      v312_12 = compose(v312_10,v317_11);
    }
    const Space v312_13 = unite(v312_8,v312_12);
    v311_12_result = unite(v311_12_result,v312_13);
  }
  const Space v311_12 = std::move(v311_12_result);
  return v311_12;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v321_12_result;
  for (int v321_12_label = 1; v321_12_label <= 2; ++v321_12_label) {
    const Space v321_12_tail = child(s0,v321_12_label);
    if (v321_12_tail.empty()) continue;
    const Path v321_12_head{v321_12_label};
    const Space v322_2 = singleton(v321_12_head);
    const Space v322_3 = intersect(constant_6,v322_2);
    const Space v322_4 = (has_head(v322_3) ? constant_7 : Space{});
    const Space v322_5 = subtract(constant_5,v322_4);
    Space v322_8;
    if (!v322_5.empty()) {
      const Path v323_6 = concat_path(p0,v321_12_head);
      Space v323_7_result;
      for (int v323_7_label = 1; v323_7_label <= 2; ++v323_7_label) {
        const Space v323_7_tail = child(v321_12_tail,v323_7_label);
        if (v323_7_tail.empty()) continue;
        const Path v323_7_head{v323_7_label};
        const Space v324_2 = singleton(v323_7_head);
        const Space v324_3 = intersect(constant_6,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_7 : Space{});
        const Space v324_5 = subtract(constant_5,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_7_head);
          const Space v325_7 = routine_51(c, v325_6, v323_7_tail, s1);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_6,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_7 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_7_head);
          const Space v326_11 = routine_52(c, v326_6, v323_7_tail, s1);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_7_result = unite(v323_7_result,v324_13);
      }
      const Space v323_7 = std::move(v323_7_result);
      v322_8 = compose(v322_5,v323_7);
    }
    const Space v322_9 = intersect(constant_6,v322_2);
    const Space v322_10 = (has_head(v322_9) ? constant_7 : Space{});
    Space v322_12;
    if (!v322_10.empty()) {
      Space v327_11_result;
      for (int v327_11_label = 1; v327_11_label <= 2; ++v327_11_label) {
        const Space v327_11_tail = child(v321_12_tail,v327_11_label);
        if (v327_11_tail.empty()) continue;
        const Path v327_11_head{v327_11_label};
        const Space v328_2 = singleton(v327_11_head);
        const Space v328_3 = intersect(constant_6,v328_2);
        const Space v328_4 = (has_head(v328_3) ? constant_7 : Space{});
        const Space v328_5 = subtract(constant_5,v328_4);
        Space v328_7;
        if (!v328_5.empty()) {
          const Space v329_6 = routine_32(c, v327_11_head, v327_11_tail, s1);
          v328_7 = compose(v328_5,v329_6);
        }
        const Space v328_8 = intersect(constant_6,v328_2);
        const Space v328_9 = (has_head(v328_8) ? constant_7 : Space{});
        Space v328_11;
        if (!v328_9.empty()) {
          const Space v330_10 = routine_33(c, v327_11_head, v327_11_tail, s1);
          v328_11 = compose(v328_9,v330_10);
        }
        const Space v328_12 = unite(v328_7,v328_11);
        v327_11_result = unite(v327_11_result,v328_12);
      }
      const Space v327_11 = std::move(v327_11_result);
      v322_12 = compose(v322_10,v327_11);
    }
    const Path v331_6 = concat_path(p0,v321_12_head);
    const Space v322_13 = wrap(v322_12,v331_6);
    const Space v322_14 = unite(v322_8,v322_13);
    v321_12_result = unite(v321_12_result,v322_14);
  }
  const Space v321_12 = std::move(v321_12_result);
  return v321_12;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v332_12_result;
  for (int v332_12_label = 1; v332_12_label <= 2; ++v332_12_label) {
    const Space v332_12_tail = child(s0,v332_12_label);
    if (v332_12_tail.empty()) continue;
    const Path v332_12_head{v332_12_label};
    const Space v333_2 = singleton(v332_12_head);
    const Space v333_3 = intersect(constant_6,v333_2);
    const Space v333_4 = (has_head(v333_3) ? constant_7 : Space{});
    const Space v333_5 = subtract(constant_5,v333_4);
    Space v333_8;
    if (!v333_5.empty()) {
      const Path v334_6 = concat_path(p0,v332_12_head);
      Space v334_7_result;
      for (int v334_7_label = 1; v334_7_label <= 2; ++v334_7_label) {
        const Space v334_7_tail = child(v332_12_tail,v334_7_label);
        if (v334_7_tail.empty()) continue;
        const Path v334_7_head{v334_7_label};
        const Space v335_2 = singleton(v334_7_head);
        const Space v335_3 = intersect(constant_6,v335_2);
        const Space v335_4 = (has_head(v335_3) ? constant_7 : Space{});
        const Space v335_5 = subtract(constant_5,v335_4);
        Space v335_8;
        if (!v335_5.empty()) {
          const Path v336_6 = concat_path(v334_6,v334_7_head);
          const Space v336_7 = routine_53(c, v336_6, v334_7_tail, s1);
          v335_8 = compose(v335_5,v336_7);
        }
        const Space v335_9 = intersect(constant_6,v335_2);
        const Space v335_10 = (has_head(v335_9) ? constant_7 : Space{});
        Space v335_12;
        if (!v335_10.empty()) {
          const Path v337_6 = concat_path(v334_6,v334_7_head);
          const Space v337_11 = routine_54(c, v337_6, v334_7_tail, s1);
          v335_12 = compose(v335_10,v337_11);
        }
        const Space v335_13 = unite(v335_8,v335_12);
        v334_7_result = unite(v334_7_result,v335_13);
      }
      const Space v334_7 = std::move(v334_7_result);
      v333_8 = compose(v333_5,v334_7);
    }
    const Space v333_9 = intersect(constant_6,v333_2);
    const Space v333_10 = (has_head(v333_9) ? constant_7 : Space{});
    Space v333_12;
    if (!v333_10.empty()) {
      const Path v338_6 = concat_path(p0,v332_12_head);
      Space v338_11_result;
      for (int v338_11_label = 1; v338_11_label <= 2; ++v338_11_label) {
        const Space v338_11_tail = child(v332_12_tail,v338_11_label);
        if (v338_11_tail.empty()) continue;
        const Path v338_11_head{v338_11_label};
        const Space v339_2 = singleton(v338_11_head);
        const Space v339_3 = intersect(constant_6,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_7 : Space{});
        const Space v339_5 = subtract(constant_5,v339_4);
        Space v339_8;
        if (!v339_5.empty()) {
          const Path v340_6 = concat_path(v338_6,v338_11_head);
          const Space v340_7 = routine_53(c, v340_6, v338_11_tail, s1);
          v339_8 = compose(v339_5,v340_7);
        }
        const Space v339_9 = intersect(constant_6,v339_2);
        const Space v339_10 = (has_head(v339_9) ? constant_7 : Space{});
        Space v339_12;
        if (!v339_10.empty()) {
          const Path v341_6 = concat_path(v338_6,v338_11_head);
          const Space v341_11 = routine_36(c, v341_6, v338_11_tail, s1);
          v339_12 = compose(v339_10,v341_11);
        }
        const Space v339_13 = unite(v339_8,v339_12);
        v338_11_result = unite(v338_11_result,v339_13);
      }
      const Space v338_11 = std::move(v338_11_result);
      v333_12 = compose(v333_10,v338_11);
    }
    const Space v333_13 = unite(v333_8,v333_12);
    v332_12_result = unite(v332_12_result,v333_13);
  }
  const Space v332_12 = std::move(v332_12_result);
  return v332_12;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v342_7 = unwrap(s1,constant_3);
  const Space v342_9 = unwrap(v342_7,constant_4);
  const Space v342_10 = unwrap(v342_9,p0);
  Space v342_15_result;
  for (int v342_15_label = 1; v342_15_label <= 2; ++v342_15_label) {
    const Space v342_15_tail = child(s0,v342_15_label);
    if (v342_15_tail.empty()) continue;
    const Path v342_15_head{v342_15_label};
    const Space v343_2 = singleton(v342_15_head);
    const Space v343_3 = intersect(constant_6,v343_2);
    const Space v343_4 = (has_head(v343_3) ? constant_7 : Space{});
    const Space v343_5 = subtract(constant_5,v343_4);
    Space v343_8;
    if (!v343_5.empty()) {
      const Path v344_6 = concat_path(p0,v342_15_head);
      Space v344_7_result;
      for (int v344_7_label = 1; v344_7_label <= 2; ++v344_7_label) {
        const Space v344_7_tail = child(v342_15_tail,v344_7_label);
        if (v344_7_tail.empty()) continue;
        const Path v344_7_head{v344_7_label};
        const Space v345_2 = singleton(v344_7_head);
        const Space v345_3 = intersect(constant_6,v345_2);
        const Space v345_4 = (has_head(v345_3) ? constant_7 : Space{});
        const Space v345_5 = subtract(constant_5,v345_4);
        Space v345_8;
        if (!v345_5.empty()) {
          const Path v346_6 = concat_path(v344_6,v344_7_head);
          const Space v346_7 = routine_53(c, v346_6, v344_7_tail, s1);
          v345_8 = compose(v345_5,v346_7);
        }
        const Space v345_9 = intersect(constant_6,v345_2);
        const Space v345_10 = (has_head(v345_9) ? constant_7 : Space{});
        Space v345_12;
        if (!v345_10.empty()) {
          const Path v347_6 = concat_path(v344_6,v344_7_head);
          const Space v347_11 = routine_54(c, v347_6, v344_7_tail, s1);
          v345_12 = compose(v345_10,v347_11);
        }
        const Space v345_13 = unite(v345_8,v345_12);
        v344_7_result = unite(v344_7_result,v345_13);
      }
      const Space v344_7 = std::move(v344_7_result);
      v343_8 = compose(v343_5,v344_7);
    }
    const Space v343_9 = intersect(constant_6,v343_2);
    const Space v343_10 = (has_head(v343_9) ? constant_7 : Space{});
    const Space v343_11 = unwrap(v342_10,v342_15_head);
    const Space v343_12 = subtract(v343_11,constant_5);
    const Space v343_13 = compose(v343_10,v343_12);
    const Space v343_14 = unite(v343_8,v343_13);
    v342_15_result = unite(v342_15_result,v343_14);
  }
  const Space v342_15 = std::move(v342_15_result);
  return v342_15;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v348_12_result;
  for (int v348_12_label = 1; v348_12_label <= 2; ++v348_12_label) {
    const Space v348_12_tail = child(s0,v348_12_label);
    if (v348_12_tail.empty()) continue;
    const Path v348_12_head{v348_12_label};
    const Space v349_2 = singleton(v348_12_head);
    const Space v349_3 = intersect(constant_6,v349_2);
    const Space v349_4 = (has_head(v349_3) ? constant_7 : Space{});
    const Space v349_5 = subtract(constant_5,v349_4);
    Space v349_8;
    if (!v349_5.empty()) {
      const Path v350_6 = concat_path(p0,v348_12_head);
      Space v350_7_result;
      for (int v350_7_label = 1; v350_7_label <= 2; ++v350_7_label) {
        const Space v350_7_tail = child(v348_12_tail,v350_7_label);
        if (v350_7_tail.empty()) continue;
        const Path v350_7_head{v350_7_label};
        const Space v351_2 = singleton(v350_7_head);
        const Space v351_3 = intersect(constant_6,v351_2);
        const Space v351_4 = (has_head(v351_3) ? constant_7 : Space{});
        const Space v351_5 = subtract(constant_5,v351_4);
        Space v351_8;
        if (!v351_5.empty()) {
          const Path v352_6 = concat_path(v350_6,v350_7_head);
          const Space v352_7 = routine_55(c, v352_6, v350_7_tail, s1);
          v351_8 = compose(v351_5,v352_7);
        }
        const Space v351_9 = intersect(constant_6,v351_2);
        const Space v351_10 = (has_head(v351_9) ? constant_7 : Space{});
        Space v351_12;
        if (!v351_10.empty()) {
          const Path v353_6 = concat_path(v350_6,v350_7_head);
          const Space v353_11 = routine_56(c, v353_6, v350_7_tail, s1);
          v351_12 = compose(v351_10,v353_11);
        }
        const Space v351_13 = unite(v351_8,v351_12);
        v350_7_result = unite(v350_7_result,v351_13);
      }
      const Space v350_7 = std::move(v350_7_result);
      v349_8 = compose(v349_5,v350_7);
    }
    const Space v349_9 = intersect(constant_6,v349_2);
    const Space v349_10 = (has_head(v349_9) ? constant_7 : Space{});
    Space v349_12;
    if (!v349_10.empty()) {
      const Path v354_6 = concat_path(p0,v348_12_head);
      Space v354_11_result;
      for (int v354_11_label = 1; v354_11_label <= 2; ++v354_11_label) {
        const Space v354_11_tail = child(v348_12_tail,v354_11_label);
        if (v354_11_tail.empty()) continue;
        const Path v354_11_head{v354_11_label};
        const Space v355_2 = singleton(v354_11_head);
        const Space v355_3 = intersect(constant_6,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_7 : Space{});
        const Space v355_5 = subtract(constant_5,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_11_head);
          const Space v356_7 = routine_55(c, v356_6, v354_11_tail, s1);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_6,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_7 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_11_head);
          const Space v357_11 = routine_36(c, v357_6, v354_11_tail, s1);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_11_result = unite(v354_11_result,v355_13);
      }
      const Space v354_11 = std::move(v354_11_result);
      v349_12 = compose(v349_10,v354_11);
    }
    const Space v349_13 = unite(v349_8,v349_12);
    v348_12_result = unite(v348_12_result,v349_13);
  }
  const Space v348_12 = std::move(v348_12_result);
  return v348_12;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v358_7 = unwrap(s1,constant_3);
  const Space v358_9 = unwrap(v358_7,constant_4);
  const Space v358_10 = unwrap(v358_9,p0);
  Space v358_15_result;
  for (int v358_15_label = 1; v358_15_label <= 2; ++v358_15_label) {
    const Space v358_15_tail = child(s0,v358_15_label);
    if (v358_15_tail.empty()) continue;
    const Path v358_15_head{v358_15_label};
    const Space v359_2 = singleton(v358_15_head);
    const Space v359_3 = intersect(constant_6,v359_2);
    const Space v359_4 = (has_head(v359_3) ? constant_7 : Space{});
    const Space v359_5 = subtract(constant_5,v359_4);
    Space v359_8;
    if (!v359_5.empty()) {
      const Path v360_6 = concat_path(p0,v358_15_head);
      Space v360_7_result;
      for (int v360_7_label = 1; v360_7_label <= 2; ++v360_7_label) {
        const Space v360_7_tail = child(v358_15_tail,v360_7_label);
        if (v360_7_tail.empty()) continue;
        const Path v360_7_head{v360_7_label};
        const Space v361_2 = singleton(v360_7_head);
        const Space v361_3 = intersect(constant_6,v361_2);
        const Space v361_4 = (has_head(v361_3) ? constant_7 : Space{});
        const Space v361_5 = subtract(constant_5,v361_4);
        Space v361_8;
        if (!v361_5.empty()) {
          const Path v362_6 = concat_path(v360_6,v360_7_head);
          const Space v362_7 = routine_55(c, v362_6, v360_7_tail, s1);
          v361_8 = compose(v361_5,v362_7);
        }
        const Space v361_9 = intersect(constant_6,v361_2);
        const Space v361_10 = (has_head(v361_9) ? constant_7 : Space{});
        Space v361_12;
        if (!v361_10.empty()) {
          const Path v363_6 = concat_path(v360_6,v360_7_head);
          const Space v363_11 = routine_56(c, v363_6, v360_7_tail, s1);
          v361_12 = compose(v361_10,v363_11);
        }
        const Space v361_13 = unite(v361_8,v361_12);
        v360_7_result = unite(v360_7_result,v361_13);
      }
      const Space v360_7 = std::move(v360_7_result);
      v359_8 = compose(v359_5,v360_7);
    }
    const Space v359_9 = intersect(constant_6,v359_2);
    const Space v359_10 = (has_head(v359_9) ? constant_7 : Space{});
    const Space v359_11 = unwrap(v358_10,v358_15_head);
    const Space v359_12 = subtract(v359_11,constant_5);
    const Space v359_13 = compose(v359_10,v359_12);
    const Space v359_14 = unite(v359_8,v359_13);
    v358_15_result = unite(v358_15_result,v359_14);
  }
  const Space v358_15 = std::move(v358_15_result);
  return v358_15;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v364_4 = unwrap(s1,constant_3);
  const Space v364_6 = unwrap(v364_4,constant_4);
  const Space v364_7 = unwrap(v364_6,p0);
  const Space v364_9 = subtract(v364_7,constant_5);
  return v364_9;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v365_7_result;
  for (int v365_7_label = 1; v365_7_label <= 2; ++v365_7_label) {
    const Space v365_7_tail = child(s0,v365_7_label);
    if (v365_7_tail.empty()) continue;
    const Path v365_7_head{v365_7_label};
    const Space v366_2 = singleton(v365_7_head);
    const Space v366_3 = intersect(constant_6,v366_2);
    const Space v366_4 = (has_head(v366_3) ? constant_7 : Space{});
    const Space v366_5 = subtract(constant_5,v366_4);
    Space v366_6_result;
    for (int v366_6_label = 1; v366_6_label <= 2; ++v366_6_label) {
      const Space v366_6_tail = child(v365_7_tail,v366_6_label);
      if (v366_6_tail.empty()) continue;
      const Path v366_6_head{v366_6_label};
      const Space v367_2 = Space{};
      v366_6_result = unite(v366_6_result,v367_2);
    }
    const Space v366_6 = std::move(v366_6_result);
    const Space v366_7 = compose(v366_5,v366_6);
    const Space v366_8 = intersect(constant_6,v366_2);
    const Space v366_9 = (has_head(v366_8) ? constant_7 : Space{});
    Space v366_12;
    if (!v366_9.empty()) {
      const Path v368_10 = concat_path(p0,v365_7_head);
      Space v368_11_result;
      for (int v368_11_label = 1; v368_11_label <= 2; ++v368_11_label) {
        const Space v368_11_tail = child(v365_7_tail,v368_11_label);
        if (v368_11_tail.empty()) continue;
        const Path v368_11_head{v368_11_label};
        const Space v369_2 = singleton(v368_11_head);
        const Space v369_3 = intersect(constant_6,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_7 : Space{});
        Space v369_7;
        if (!v369_4.empty()) {
          const Path v370_5 = concat_path(v368_10,v368_11_head);
          const Space v370_6 = routine_4(c, v370_5, v368_11_tail, s1);
          v369_7 = compose(v369_4,v370_6);
        }
        v368_11_result = unite(v368_11_result,v369_7);
      }
      const Space v368_11 = std::move(v368_11_result);
      v366_12 = compose(v366_9,v368_11);
    }
    const Space v366_13 = unite(v366_7,v366_12);
    v365_7_result = unite(v365_7_result,v366_13);
  }
  const Space v365_7 = std::move(v365_7_result);
  return v365_7;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v371_9_result;
  for (int v371_9_label = 1; v371_9_label <= 2; ++v371_9_label) {
    const Space v371_9_tail = child(s0,v371_9_label);
    if (v371_9_tail.empty()) continue;
    const Path v371_9_head{v371_9_label};
    const Space v372_2 = singleton(v371_9_head);
    const Space v372_3 = intersect(constant_6,v372_2);
    const Space v372_4 = (has_head(v372_3) ? constant_7 : Space{});
    const Space v372_5 = subtract(constant_5,v372_4);
    Space v372_6_result;
    for (int v372_6_label = 1; v372_6_label <= 2; ++v372_6_label) {
      const Space v372_6_tail = child(v371_9_tail,v372_6_label);
      if (v372_6_tail.empty()) continue;
      const Path v372_6_head{v372_6_label};
      const Space v373_2 = Space{};
      v372_6_result = unite(v372_6_result,v373_2);
    }
    const Space v372_6 = std::move(v372_6_result);
    const Space v372_7 = compose(v372_5,v372_6);
    const Space v372_8 = intersect(constant_6,v372_2);
    const Space v372_9 = (has_head(v372_8) ? constant_7 : Space{});
    Space v372_11;
    if (!v372_9.empty()) {
      Space v374_10_result;
      for (int v374_10_label = 1; v374_10_label <= 2; ++v374_10_label) {
        const Space v374_10_tail = child(v371_9_tail,v374_10_label);
        if (v374_10_tail.empty()) continue;
        const Path v374_10_head{v374_10_label};
        const Space v375_2 = singleton(v374_10_head);
        const Space v375_3 = intersect(constant_6,v375_2);
        const Space v375_4 = (has_head(v375_3) ? constant_7 : Space{});
        const Space v375_5 = subtract(constant_5,v375_4);
        Space v375_7;
        if (!v375_5.empty()) {
          const Space v376_6 = routine_16(c, v374_10_head, v374_10_tail, s1);
          v375_7 = compose(v375_5,v376_6);
        }
        const Space v375_8 = intersect(constant_6,v375_2);
        const Space v375_9 = (has_head(v375_8) ? constant_7 : Space{});
        Space v375_11;
        if (!v375_9.empty()) {
          const Space v377_10 = routine_17(c, v374_10_head, v374_10_tail, s1);
          v375_11 = compose(v375_9,v377_10);
        }
        const Space v375_12 = unite(v375_7,v375_11);
        v374_10_result = unite(v374_10_result,v375_12);
      }
      const Space v374_10 = std::move(v374_10_result);
      v372_11 = compose(v372_9,v374_10);
    }
    const Path v372_12 = concat_path(p0,v371_9_head);
    const Space v372_13 = wrap(v372_11,v372_12);
    const Space v372_14 = unite(v372_7,v372_13);
    v371_9_result = unite(v371_9_result,v372_14);
  }
  const Space v371_9 = std::move(v371_9_result);
  return v371_9;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v378_12_result;
  for (int v378_12_label = 1; v378_12_label <= 2; ++v378_12_label) {
    const Space v378_12_tail = child(s0,v378_12_label);
    if (v378_12_tail.empty()) continue;
    const Path v378_12_head{v378_12_label};
    const Space v379_2 = singleton(v378_12_head);
    const Space v379_3 = intersect(constant_6,v379_2);
    const Space v379_4 = (has_head(v379_3) ? constant_7 : Space{});
    const Space v379_5 = subtract(constant_5,v379_4);
    Space v379_8;
    if (!v379_5.empty()) {
      const Path v380_6 = concat_path(p0,v378_12_head);
      Space v380_7_result;
      for (int v380_7_label = 1; v380_7_label <= 2; ++v380_7_label) {
        const Space v380_7_tail = child(v378_12_tail,v380_7_label);
        if (v380_7_tail.empty()) continue;
        const Path v380_7_head{v380_7_label};
        const Space v381_2 = singleton(v380_7_head);
        const Space v381_3 = intersect(constant_6,v381_2);
        const Space v381_4 = (has_head(v381_3) ? constant_7 : Space{});
        const Space v381_5 = subtract(constant_5,v381_4);
        Space v381_8;
        if (!v381_5.empty()) {
          const Path v382_6 = concat_path(v380_6,v380_7_head);
          const Space v382_7 = routine_57(c, v382_6, v380_7_tail, s1);
          v381_8 = compose(v381_5,v382_7);
        }
        const Space v381_9 = intersect(constant_6,v381_2);
        const Space v381_10 = (has_head(v381_9) ? constant_7 : Space{});
        Space v381_12;
        if (!v381_10.empty()) {
          const Path v383_6 = concat_path(v380_6,v380_7_head);
          const Space v383_11 = routine_58(c, v383_6, v380_7_tail, s1);
          v381_12 = compose(v381_10,v383_11);
        }
        const Space v381_13 = unite(v381_8,v381_12);
        v380_7_result = unite(v380_7_result,v381_13);
      }
      const Space v380_7 = std::move(v380_7_result);
      v379_8 = compose(v379_5,v380_7);
    }
    const Space v379_9 = intersect(constant_6,v379_2);
    const Space v379_10 = (has_head(v379_9) ? constant_7 : Space{});
    Space v379_12;
    if (!v379_10.empty()) {
      const Path v384_6 = concat_path(p0,v378_12_head);
      Space v384_11_result;
      for (int v384_11_label = 1; v384_11_label <= 2; ++v384_11_label) {
        const Space v384_11_tail = child(v378_12_tail,v384_11_label);
        if (v384_11_tail.empty()) continue;
        const Path v384_11_head{v384_11_label};
        const Space v385_2 = singleton(v384_11_head);
        const Space v385_3 = intersect(constant_6,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_7 : Space{});
        const Space v385_5 = subtract(constant_5,v385_4);
        Space v385_8;
        if (!v385_5.empty()) {
          const Path v386_6 = concat_path(v384_6,v384_11_head);
          const Space v386_7 = routine_57(c, v386_6, v384_11_tail, s1);
          v385_8 = compose(v385_5,v386_7);
        }
        const Space v385_9 = intersect(constant_6,v385_2);
        const Space v385_10 = (has_head(v385_9) ? constant_7 : Space{});
        Space v385_12;
        if (!v385_10.empty()) {
          const Path v387_6 = concat_path(v384_6,v384_11_head);
          const Space v387_11 = routine_20(c, v387_6, v384_11_tail, s1);
          v385_12 = compose(v385_10,v387_11);
        }
        const Space v385_13 = unite(v385_8,v385_12);
        v384_11_result = unite(v384_11_result,v385_13);
      }
      const Space v384_11 = std::move(v384_11_result);
      v379_12 = compose(v379_10,v384_11);
    }
    const Space v379_13 = unite(v379_8,v379_12);
    v378_12_result = unite(v378_12_result,v379_13);
  }
  const Space v378_12 = std::move(v378_12_result);
  return v378_12;
}

static Space routine_40(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v388_7 = unwrap(s1,constant_8);
  const Space v388_9 = unwrap(v388_7,constant_4);
  const Space v388_10 = unwrap(v388_9,p0);
  Space v388_15_result;
  for (int v388_15_label = 1; v388_15_label <= 2; ++v388_15_label) {
    const Space v388_15_tail = child(s0,v388_15_label);
    if (v388_15_tail.empty()) continue;
    const Path v388_15_head{v388_15_label};
    const Space v389_2 = singleton(v388_15_head);
    const Space v389_3 = intersect(constant_6,v389_2);
    const Space v389_4 = (has_head(v389_3) ? constant_7 : Space{});
    const Space v389_5 = subtract(constant_5,v389_4);
    Space v389_8;
    if (!v389_5.empty()) {
      const Path v390_6 = concat_path(p0,v388_15_head);
      Space v390_7_result;
      for (int v390_7_label = 1; v390_7_label <= 2; ++v390_7_label) {
        const Space v390_7_tail = child(v388_15_tail,v390_7_label);
        if (v390_7_tail.empty()) continue;
        const Path v390_7_head{v390_7_label};
        const Space v391_2 = singleton(v390_7_head);
        const Space v391_3 = intersect(constant_6,v391_2);
        const Space v391_4 = (has_head(v391_3) ? constant_7 : Space{});
        const Space v391_5 = subtract(constant_5,v391_4);
        Space v391_8;
        if (!v391_5.empty()) {
          const Path v392_6 = concat_path(v390_6,v390_7_head);
          const Space v392_7 = routine_57(c, v392_6, v390_7_tail, s1);
          v391_8 = compose(v391_5,v392_7);
        }
        const Space v391_9 = intersect(constant_6,v391_2);
        const Space v391_10 = (has_head(v391_9) ? constant_7 : Space{});
        Space v391_12;
        if (!v391_10.empty()) {
          const Path v393_6 = concat_path(v390_6,v390_7_head);
          const Space v393_11 = routine_58(c, v393_6, v390_7_tail, s1);
          v391_12 = compose(v391_10,v393_11);
        }
        const Space v391_13 = unite(v391_8,v391_12);
        v390_7_result = unite(v390_7_result,v391_13);
      }
      const Space v390_7 = std::move(v390_7_result);
      v389_8 = compose(v389_5,v390_7);
    }
    const Space v389_9 = intersect(constant_6,v389_2);
    const Space v389_10 = (has_head(v389_9) ? constant_7 : Space{});
    const Space v389_11 = unwrap(v388_10,v388_15_head);
    const Space v389_12 = subtract(v389_11,constant_5);
    const Space v389_13 = compose(v389_10,v389_12);
    const Space v389_14 = unite(v389_8,v389_13);
    v388_15_result = unite(v388_15_result,v389_14);
  }
  const Space v388_15 = std::move(v388_15_result);
  return v388_15;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v394_12_result;
  for (int v394_12_label = 1; v394_12_label <= 2; ++v394_12_label) {
    const Space v394_12_tail = child(s0,v394_12_label);
    if (v394_12_tail.empty()) continue;
    const Path v394_12_head{v394_12_label};
    const Space v395_2 = singleton(v394_12_head);
    const Space v395_3 = intersect(constant_6,v395_2);
    const Space v395_4 = (has_head(v395_3) ? constant_7 : Space{});
    const Space v395_5 = subtract(constant_5,v395_4);
    Space v395_8;
    if (!v395_5.empty()) {
      const Path v396_6 = concat_path(p0,v394_12_head);
      Space v396_7_result;
      for (int v396_7_label = 1; v396_7_label <= 2; ++v396_7_label) {
        const Space v396_7_tail = child(v394_12_tail,v396_7_label);
        if (v396_7_tail.empty()) continue;
        const Path v396_7_head{v396_7_label};
        const Space v397_2 = singleton(v396_7_head);
        const Space v397_3 = intersect(constant_6,v397_2);
        const Space v397_4 = (has_head(v397_3) ? constant_7 : Space{});
        const Space v397_5 = subtract(constant_5,v397_4);
        Space v397_8;
        if (!v397_5.empty()) {
          const Path v398_6 = concat_path(v396_6,v396_7_head);
          const Space v398_7 = routine_59(c, v398_6, v396_7_tail, s1);
          v397_8 = compose(v397_5,v398_7);
        }
        const Space v397_9 = intersect(constant_6,v397_2);
        const Space v397_10 = (has_head(v397_9) ? constant_7 : Space{});
        Space v397_12;
        if (!v397_10.empty()) {
          const Path v399_6 = concat_path(v396_6,v396_7_head);
          const Space v399_11 = routine_60(c, v399_6, v396_7_tail, s1);
          v397_12 = compose(v397_10,v399_11);
        }
        const Space v397_13 = unite(v397_8,v397_12);
        v396_7_result = unite(v396_7_result,v397_13);
      }
      const Space v396_7 = std::move(v396_7_result);
      v395_8 = compose(v395_5,v396_7);
    }
    const Space v395_9 = intersect(constant_6,v395_2);
    const Space v395_10 = (has_head(v395_9) ? constant_7 : Space{});
    Space v395_12;
    if (!v395_10.empty()) {
      const Path v400_6 = concat_path(p0,v394_12_head);
      Space v400_11_result;
      for (int v400_11_label = 1; v400_11_label <= 2; ++v400_11_label) {
        const Space v400_11_tail = child(v394_12_tail,v400_11_label);
        if (v400_11_tail.empty()) continue;
        const Path v400_11_head{v400_11_label};
        const Space v401_2 = singleton(v400_11_head);
        const Space v401_3 = intersect(constant_6,v401_2);
        const Space v401_4 = (has_head(v401_3) ? constant_7 : Space{});
        const Space v401_5 = subtract(constant_5,v401_4);
        Space v401_8;
        if (!v401_5.empty()) {
          const Path v402_6 = concat_path(v400_6,v400_11_head);
          const Space v402_7 = routine_59(c, v402_6, v400_11_tail, s1);
          v401_8 = compose(v401_5,v402_7);
        }
        const Space v401_9 = intersect(constant_6,v401_2);
        const Space v401_10 = (has_head(v401_9) ? constant_7 : Space{});
        Space v401_12;
        if (!v401_10.empty()) {
          const Path v403_6 = concat_path(v400_6,v400_11_head);
          const Space v403_11 = routine_20(c, v403_6, v400_11_tail, s1);
          v401_12 = compose(v401_10,v403_11);
        }
        const Space v401_13 = unite(v401_8,v401_12);
        v400_11_result = unite(v400_11_result,v401_13);
      }
      const Space v400_11 = std::move(v400_11_result);
      v395_12 = compose(v395_10,v400_11);
    }
    const Space v395_13 = unite(v395_8,v395_12);
    v394_12_result = unite(v394_12_result,v395_13);
  }
  const Space v394_12 = std::move(v394_12_result);
  return v394_12;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v404_7 = unwrap(s1,constant_8);
  const Space v404_9 = unwrap(v404_7,constant_4);
  const Space v404_10 = unwrap(v404_9,p0);
  Space v404_15_result;
  for (int v404_15_label = 1; v404_15_label <= 2; ++v404_15_label) {
    const Space v404_15_tail = child(s0,v404_15_label);
    if (v404_15_tail.empty()) continue;
    const Path v404_15_head{v404_15_label};
    const Space v405_2 = singleton(v404_15_head);
    const Space v405_3 = intersect(constant_6,v405_2);
    const Space v405_4 = (has_head(v405_3) ? constant_7 : Space{});
    const Space v405_5 = subtract(constant_5,v405_4);
    Space v405_8;
    if (!v405_5.empty()) {
      const Path v406_6 = concat_path(p0,v404_15_head);
      Space v406_7_result;
      for (int v406_7_label = 1; v406_7_label <= 2; ++v406_7_label) {
        const Space v406_7_tail = child(v404_15_tail,v406_7_label);
        if (v406_7_tail.empty()) continue;
        const Path v406_7_head{v406_7_label};
        const Space v407_2 = singleton(v406_7_head);
        const Space v407_3 = intersect(constant_6,v407_2);
        const Space v407_4 = (has_head(v407_3) ? constant_7 : Space{});
        const Space v407_5 = subtract(constant_5,v407_4);
        Space v407_8;
        if (!v407_5.empty()) {
          const Path v408_6 = concat_path(v406_6,v406_7_head);
          const Space v408_7 = routine_59(c, v408_6, v406_7_tail, s1);
          v407_8 = compose(v407_5,v408_7);
        }
        const Space v407_9 = intersect(constant_6,v407_2);
        const Space v407_10 = (has_head(v407_9) ? constant_7 : Space{});
        Space v407_12;
        if (!v407_10.empty()) {
          const Path v409_6 = concat_path(v406_6,v406_7_head);
          const Space v409_11 = routine_60(c, v409_6, v406_7_tail, s1);
          v407_12 = compose(v407_10,v409_11);
        }
        const Space v407_13 = unite(v407_8,v407_12);
        v406_7_result = unite(v406_7_result,v407_13);
      }
      const Space v406_7 = std::move(v406_7_result);
      v405_8 = compose(v405_5,v406_7);
    }
    const Space v405_9 = intersect(constant_6,v405_2);
    const Space v405_10 = (has_head(v405_9) ? constant_7 : Space{});
    const Space v405_11 = unwrap(v404_10,v404_15_head);
    const Space v405_12 = subtract(v405_11,constant_5);
    const Space v405_13 = compose(v405_10,v405_12);
    const Space v405_14 = unite(v405_8,v405_13);
    v404_15_result = unite(v404_15_result,v405_14);
  }
  const Space v404_15 = std::move(v404_15_result);
  return v404_15;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v410_7_result;
  for (int v410_7_label = 1; v410_7_label <= 2; ++v410_7_label) {
    const Space v410_7_tail = child(s0,v410_7_label);
    if (v410_7_tail.empty()) continue;
    const Path v410_7_head{v410_7_label};
    const Space v411_2 = singleton(v410_7_head);
    const Space v411_3 = intersect(constant_6,v411_2);
    const Space v411_4 = (has_head(v411_3) ? constant_7 : Space{});
    const Space v411_5 = subtract(constant_5,v411_4);
    Space v411_6_result;
    for (int v411_6_label = 1; v411_6_label <= 2; ++v411_6_label) {
      const Space v411_6_tail = child(v410_7_tail,v411_6_label);
      if (v411_6_tail.empty()) continue;
      const Path v411_6_head{v411_6_label};
      const Space v412_2 = Space{};
      v411_6_result = unite(v411_6_result,v412_2);
    }
    const Space v411_6 = std::move(v411_6_result);
    const Space v411_7 = compose(v411_5,v411_6);
    const Space v411_8 = intersect(constant_6,v411_2);
    const Space v411_9 = (has_head(v411_8) ? constant_7 : Space{});
    Space v411_12;
    if (!v411_9.empty()) {
      const Path v413_10 = concat_path(p0,v410_7_head);
      Space v413_11_result;
      for (int v413_11_label = 1; v413_11_label <= 2; ++v413_11_label) {
        const Space v413_11_tail = child(v410_7_tail,v413_11_label);
        if (v413_11_tail.empty()) continue;
        const Path v413_11_head{v413_11_label};
        const Space v414_2 = singleton(v413_11_head);
        const Space v414_3 = intersect(constant_6,v414_2);
        const Space v414_4 = (has_head(v414_3) ? constant_7 : Space{});
        Space v414_7;
        if (!v414_4.empty()) {
          const Path v415_5 = concat_path(v413_10,v413_11_head);
          const Space v415_6 = routine_7(c, v415_5, v413_11_tail, s1);
          v414_7 = compose(v414_4,v415_6);
        }
        v413_11_result = unite(v413_11_result,v414_7);
      }
      const Space v413_11 = std::move(v413_11_result);
      v411_12 = compose(v411_9,v413_11);
    }
    const Space v411_13 = unite(v411_7,v411_12);
    v410_7_result = unite(v410_7_result,v411_13);
  }
  const Space v410_7 = std::move(v410_7_result);
  return v410_7;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v416_9_result;
  for (int v416_9_label = 1; v416_9_label <= 2; ++v416_9_label) {
    const Space v416_9_tail = child(s0,v416_9_label);
    if (v416_9_tail.empty()) continue;
    const Path v416_9_head{v416_9_label};
    const Space v417_2 = singleton(v416_9_head);
    const Space v417_3 = intersect(constant_6,v417_2);
    const Space v417_4 = (has_head(v417_3) ? constant_7 : Space{});
    const Space v417_5 = subtract(constant_5,v417_4);
    Space v417_6_result;
    for (int v417_6_label = 1; v417_6_label <= 2; ++v417_6_label) {
      const Space v417_6_tail = child(v416_9_tail,v417_6_label);
      if (v417_6_tail.empty()) continue;
      const Path v417_6_head{v417_6_label};
      const Space v418_2 = Space{};
      v417_6_result = unite(v417_6_result,v418_2);
    }
    const Space v417_6 = std::move(v417_6_result);
    const Space v417_7 = compose(v417_5,v417_6);
    const Space v417_8 = intersect(constant_6,v417_2);
    const Space v417_9 = (has_head(v417_8) ? constant_7 : Space{});
    Space v417_11;
    if (!v417_9.empty()) {
      Space v419_10_result;
      for (int v419_10_label = 1; v419_10_label <= 2; ++v419_10_label) {
        const Space v419_10_tail = child(v416_9_tail,v419_10_label);
        if (v419_10_tail.empty()) continue;
        const Path v419_10_head{v419_10_label};
        const Space v420_2 = singleton(v419_10_head);
        const Space v420_3 = intersect(constant_6,v420_2);
        const Space v420_4 = (has_head(v420_3) ? constant_7 : Space{});
        const Space v420_5 = subtract(constant_5,v420_4);
        Space v420_7;
        if (!v420_5.empty()) {
          const Space v421_6 = routine_23(c, v419_10_head, v419_10_tail, s1);
          v420_7 = compose(v420_5,v421_6);
        }
        const Space v420_8 = intersect(constant_6,v420_2);
        const Space v420_9 = (has_head(v420_8) ? constant_7 : Space{});
        Space v420_11;
        if (!v420_9.empty()) {
          const Space v422_10 = routine_24(c, v419_10_head, v419_10_tail, s1);
          v420_11 = compose(v420_9,v422_10);
        }
        const Space v420_12 = unite(v420_7,v420_11);
        v419_10_result = unite(v419_10_result,v420_12);
      }
      const Space v419_10 = std::move(v419_10_result);
      v417_11 = compose(v417_9,v419_10);
    }
    const Path v417_12 = concat_path(p0,v416_9_head);
    const Space v417_13 = wrap(v417_11,v417_12);
    const Space v417_14 = unite(v417_7,v417_13);
    v416_9_result = unite(v416_9_result,v417_14);
  }
  const Space v416_9 = std::move(v416_9_result);
  return v416_9;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v423_12_result;
  for (int v423_12_label = 1; v423_12_label <= 2; ++v423_12_label) {
    const Space v423_12_tail = child(s0,v423_12_label);
    if (v423_12_tail.empty()) continue;
    const Path v423_12_head{v423_12_label};
    const Space v424_2 = singleton(v423_12_head);
    const Space v424_3 = intersect(constant_6,v424_2);
    const Space v424_4 = (has_head(v424_3) ? constant_7 : Space{});
    const Space v424_5 = subtract(constant_5,v424_4);
    Space v424_8;
    if (!v424_5.empty()) {
      const Path v425_6 = concat_path(p0,v423_12_head);
      Space v425_7_result;
      for (int v425_7_label = 1; v425_7_label <= 2; ++v425_7_label) {
        const Space v425_7_tail = child(v423_12_tail,v425_7_label);
        if (v425_7_tail.empty()) continue;
        const Path v425_7_head{v425_7_label};
        const Space v426_2 = singleton(v425_7_head);
        const Space v426_3 = intersect(constant_6,v426_2);
        const Space v426_4 = (has_head(v426_3) ? constant_7 : Space{});
        const Space v426_5 = subtract(constant_5,v426_4);
        Space v426_8;
        if (!v426_5.empty()) {
          const Path v427_6 = concat_path(v425_6,v425_7_head);
          const Space v427_7 = routine_61(c, v427_6, v425_7_tail, s1);
          v426_8 = compose(v426_5,v427_7);
        }
        const Space v426_9 = intersect(constant_6,v426_2);
        const Space v426_10 = (has_head(v426_9) ? constant_7 : Space{});
        Space v426_12;
        if (!v426_10.empty()) {
          const Path v428_6 = concat_path(v425_6,v425_7_head);
          const Space v428_11 = routine_62(c, v428_6, v425_7_tail, s1);
          v426_12 = compose(v426_10,v428_11);
        }
        const Space v426_13 = unite(v426_8,v426_12);
        v425_7_result = unite(v425_7_result,v426_13);
      }
      const Space v425_7 = std::move(v425_7_result);
      v424_8 = compose(v424_5,v425_7);
    }
    const Space v424_9 = intersect(constant_6,v424_2);
    const Space v424_10 = (has_head(v424_9) ? constant_7 : Space{});
    Space v424_12;
    if (!v424_10.empty()) {
      const Path v429_6 = concat_path(p0,v423_12_head);
      Space v429_11_result;
      for (int v429_11_label = 1; v429_11_label <= 2; ++v429_11_label) {
        const Space v429_11_tail = child(v423_12_tail,v429_11_label);
        if (v429_11_tail.empty()) continue;
        const Path v429_11_head{v429_11_label};
        const Space v430_2 = singleton(v429_11_head);
        const Space v430_3 = intersect(constant_6,v430_2);
        const Space v430_4 = (has_head(v430_3) ? constant_7 : Space{});
        const Space v430_5 = subtract(constant_5,v430_4);
        Space v430_8;
        if (!v430_5.empty()) {
          const Path v431_6 = concat_path(v429_6,v429_11_head);
          const Space v431_7 = routine_61(c, v431_6, v429_11_tail, s1);
          v430_8 = compose(v430_5,v431_7);
        }
        const Space v430_9 = intersect(constant_6,v430_2);
        const Space v430_10 = (has_head(v430_9) ? constant_7 : Space{});
        Space v430_12;
        if (!v430_10.empty()) {
          const Path v432_6 = concat_path(v429_6,v429_11_head);
          const Space v432_11 = routine_27(c, v432_6, v429_11_tail, s1);
          v430_12 = compose(v430_10,v432_11);
        }
        const Space v430_13 = unite(v430_8,v430_12);
        v429_11_result = unite(v429_11_result,v430_13);
      }
      const Space v429_11 = std::move(v429_11_result);
      v424_12 = compose(v424_10,v429_11);
    }
    const Space v424_13 = unite(v424_8,v424_12);
    v423_12_result = unite(v423_12_result,v424_13);
  }
  const Space v423_12 = std::move(v423_12_result);
  return v423_12;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v433_7 = unwrap(s1,constant_3);
  const Space v433_9 = unwrap(v433_7,constant_4);
  const Space v433_10 = unwrap(v433_9,p0);
  Space v433_15_result;
  for (int v433_15_label = 1; v433_15_label <= 2; ++v433_15_label) {
    const Space v433_15_tail = child(s0,v433_15_label);
    if (v433_15_tail.empty()) continue;
    const Path v433_15_head{v433_15_label};
    const Space v434_2 = singleton(v433_15_head);
    const Space v434_3 = intersect(constant_6,v434_2);
    const Space v434_4 = (has_head(v434_3) ? constant_7 : Space{});
    const Space v434_5 = subtract(constant_5,v434_4);
    Space v434_8;
    if (!v434_5.empty()) {
      const Path v435_6 = concat_path(p0,v433_15_head);
      Space v435_7_result;
      for (int v435_7_label = 1; v435_7_label <= 2; ++v435_7_label) {
        const Space v435_7_tail = child(v433_15_tail,v435_7_label);
        if (v435_7_tail.empty()) continue;
        const Path v435_7_head{v435_7_label};
        const Space v436_2 = singleton(v435_7_head);
        const Space v436_3 = intersect(constant_6,v436_2);
        const Space v436_4 = (has_head(v436_3) ? constant_7 : Space{});
        const Space v436_5 = subtract(constant_5,v436_4);
        Space v436_8;
        if (!v436_5.empty()) {
          const Path v437_6 = concat_path(v435_6,v435_7_head);
          const Space v437_7 = routine_61(c, v437_6, v435_7_tail, s1);
          v436_8 = compose(v436_5,v437_7);
        }
        const Space v436_9 = intersect(constant_6,v436_2);
        const Space v436_10 = (has_head(v436_9) ? constant_7 : Space{});
        Space v436_12;
        if (!v436_10.empty()) {
          const Path v438_6 = concat_path(v435_6,v435_7_head);
          const Space v438_11 = routine_62(c, v438_6, v435_7_tail, s1);
          v436_12 = compose(v436_10,v438_11);
        }
        const Space v436_13 = unite(v436_8,v436_12);
        v435_7_result = unite(v435_7_result,v436_13);
      }
      const Space v435_7 = std::move(v435_7_result);
      v434_8 = compose(v434_5,v435_7);
    }
    const Space v434_9 = intersect(constant_6,v434_2);
    const Space v434_10 = (has_head(v434_9) ? constant_7 : Space{});
    const Space v434_11 = unwrap(v433_10,v433_15_head);
    const Space v434_12 = subtract(v434_11,constant_5);
    const Space v434_13 = compose(v434_10,v434_12);
    const Space v434_14 = unite(v434_8,v434_13);
    v433_15_result = unite(v433_15_result,v434_14);
  }
  const Space v433_15 = std::move(v433_15_result);
  return v433_15;
}

static Space routine_47(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v439_12_result;
  for (int v439_12_label = 1; v439_12_label <= 2; ++v439_12_label) {
    const Space v439_12_tail = child(s0,v439_12_label);
    if (v439_12_tail.empty()) continue;
    const Path v439_12_head{v439_12_label};
    const Space v440_2 = singleton(v439_12_head);
    const Space v440_3 = intersect(constant_6,v440_2);
    const Space v440_4 = (has_head(v440_3) ? constant_7 : Space{});
    const Space v440_5 = subtract(constant_5,v440_4);
    Space v440_8;
    if (!v440_5.empty()) {
      const Path v441_6 = concat_path(p0,v439_12_head);
      Space v441_7_result;
      for (int v441_7_label = 1; v441_7_label <= 2; ++v441_7_label) {
        const Space v441_7_tail = child(v439_12_tail,v441_7_label);
        if (v441_7_tail.empty()) continue;
        const Path v441_7_head{v441_7_label};
        const Space v442_2 = singleton(v441_7_head);
        const Space v442_3 = intersect(constant_6,v442_2);
        const Space v442_4 = (has_head(v442_3) ? constant_7 : Space{});
        const Space v442_5 = subtract(constant_5,v442_4);
        Space v442_8;
        if (!v442_5.empty()) {
          const Path v443_6 = concat_path(v441_6,v441_7_head);
          const Space v443_7 = routine_63(c, v443_6, v441_7_tail, s1);
          v442_8 = compose(v442_5,v443_7);
        }
        const Space v442_9 = intersect(constant_6,v442_2);
        const Space v442_10 = (has_head(v442_9) ? constant_7 : Space{});
        Space v442_12;
        if (!v442_10.empty()) {
          const Path v444_6 = concat_path(v441_6,v441_7_head);
          const Space v444_11 = routine_64(c, v444_6, v441_7_tail, s1);
          v442_12 = compose(v442_10,v444_11);
        }
        const Space v442_13 = unite(v442_8,v442_12);
        v441_7_result = unite(v441_7_result,v442_13);
      }
      const Space v441_7 = std::move(v441_7_result);
      v440_8 = compose(v440_5,v441_7);
    }
    const Space v440_9 = intersect(constant_6,v440_2);
    const Space v440_10 = (has_head(v440_9) ? constant_7 : Space{});
    Space v440_12;
    if (!v440_10.empty()) {
      const Path v445_6 = concat_path(p0,v439_12_head);
      Space v445_11_result;
      for (int v445_11_label = 1; v445_11_label <= 2; ++v445_11_label) {
        const Space v445_11_tail = child(v439_12_tail,v445_11_label);
        if (v445_11_tail.empty()) continue;
        const Path v445_11_head{v445_11_label};
        const Space v446_2 = singleton(v445_11_head);
        const Space v446_3 = intersect(constant_6,v446_2);
        const Space v446_4 = (has_head(v446_3) ? constant_7 : Space{});
        const Space v446_5 = subtract(constant_5,v446_4);
        Space v446_8;
        if (!v446_5.empty()) {
          const Path v447_6 = concat_path(v445_6,v445_11_head);
          const Space v447_7 = routine_63(c, v447_6, v445_11_tail, s1);
          v446_8 = compose(v446_5,v447_7);
        }
        const Space v446_9 = intersect(constant_6,v446_2);
        const Space v446_10 = (has_head(v446_9) ? constant_7 : Space{});
        Space v446_12;
        if (!v446_10.empty()) {
          const Path v448_6 = concat_path(v445_6,v445_11_head);
          const Space v448_11 = routine_27(c, v448_6, v445_11_tail, s1);
          v446_12 = compose(v446_10,v448_11);
        }
        const Space v446_13 = unite(v446_8,v446_12);
        v445_11_result = unite(v445_11_result,v446_13);
      }
      const Space v445_11 = std::move(v445_11_result);
      v440_12 = compose(v440_10,v445_11);
    }
    const Space v440_13 = unite(v440_8,v440_12);
    v439_12_result = unite(v439_12_result,v440_13);
  }
  const Space v439_12 = std::move(v439_12_result);
  return v439_12;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v449_7 = unwrap(s1,constant_3);
  const Space v449_9 = unwrap(v449_7,constant_4);
  const Space v449_10 = unwrap(v449_9,p0);
  Space v449_15_result;
  for (int v449_15_label = 1; v449_15_label <= 2; ++v449_15_label) {
    const Space v449_15_tail = child(s0,v449_15_label);
    if (v449_15_tail.empty()) continue;
    const Path v449_15_head{v449_15_label};
    const Space v450_2 = singleton(v449_15_head);
    const Space v450_3 = intersect(constant_6,v450_2);
    const Space v450_4 = (has_head(v450_3) ? constant_7 : Space{});
    const Space v450_5 = subtract(constant_5,v450_4);
    Space v450_8;
    if (!v450_5.empty()) {
      const Path v451_6 = concat_path(p0,v449_15_head);
      Space v451_7_result;
      for (int v451_7_label = 1; v451_7_label <= 2; ++v451_7_label) {
        const Space v451_7_tail = child(v449_15_tail,v451_7_label);
        if (v451_7_tail.empty()) continue;
        const Path v451_7_head{v451_7_label};
        const Space v452_2 = singleton(v451_7_head);
        const Space v452_3 = intersect(constant_6,v452_2);
        const Space v452_4 = (has_head(v452_3) ? constant_7 : Space{});
        const Space v452_5 = subtract(constant_5,v452_4);
        Space v452_8;
        if (!v452_5.empty()) {
          const Path v453_6 = concat_path(v451_6,v451_7_head);
          const Space v453_7 = routine_63(c, v453_6, v451_7_tail, s1);
          v452_8 = compose(v452_5,v453_7);
        }
        const Space v452_9 = intersect(constant_6,v452_2);
        const Space v452_10 = (has_head(v452_9) ? constant_7 : Space{});
        Space v452_12;
        if (!v452_10.empty()) {
          const Path v454_6 = concat_path(v451_6,v451_7_head);
          const Space v454_11 = routine_64(c, v454_6, v451_7_tail, s1);
          v452_12 = compose(v452_10,v454_11);
        }
        const Space v452_13 = unite(v452_8,v452_12);
        v451_7_result = unite(v451_7_result,v452_13);
      }
      const Space v451_7 = std::move(v451_7_result);
      v450_8 = compose(v450_5,v451_7);
    }
    const Space v450_9 = intersect(constant_6,v450_2);
    const Space v450_10 = (has_head(v450_9) ? constant_7 : Space{});
    const Space v450_11 = unwrap(v449_10,v449_15_head);
    const Space v450_12 = subtract(v450_11,constant_5);
    const Space v450_13 = compose(v450_10,v450_12);
    const Space v450_14 = unite(v450_8,v450_13);
    v449_15_result = unite(v449_15_result,v450_14);
  }
  const Space v449_15 = std::move(v449_15_result);
  return v449_15;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v455_6_result;
  for (int v455_6_label = 1; v455_6_label <= 2; ++v455_6_label) {
    const Space v455_6_tail = child(s0,v455_6_label);
    if (v455_6_tail.empty()) continue;
    const Path v455_6_head{v455_6_label};
    const Space v456_2 = singleton(v455_6_head);
    const Space v456_3 = intersect(constant_6,v456_2);
    const Space v456_4 = (has_head(v456_3) ? constant_7 : Space{});
    const Space v456_5 = subtract(constant_5,v456_4);
    Space v456_6_result;
    for (int v456_6_label = 1; v456_6_label <= 2; ++v456_6_label) {
      const Space v456_6_tail = child(v455_6_tail,v456_6_label);
      if (v456_6_tail.empty()) continue;
      const Path v456_6_head{v456_6_label};
      const Space v457_2 = Space{};
      v456_6_result = unite(v456_6_result,v457_2);
    }
    const Space v456_6 = std::move(v456_6_result);
    const Space v456_7 = compose(v456_5,v456_6);
    const Space v456_8 = intersect(constant_6,v456_2);
    const Space v456_9 = (has_head(v456_8) ? constant_7 : Space{});
    Space v456_12;
    if (!v456_9.empty()) {
      const Path v458_10 = concat_path(p0,v455_6_head);
      Space v458_11_result;
      for (int v458_11_label = 1; v458_11_label <= 2; ++v458_11_label) {
        const Space v458_11_tail = child(v455_6_tail,v458_11_label);
        if (v458_11_tail.empty()) continue;
        const Path v458_11_head{v458_11_label};
        const Space v459_2 = singleton(v458_11_head);
        const Space v459_3 = intersect(constant_6,v459_2);
        const Space v459_4 = (has_head(v459_3) ? constant_7 : Space{});
        Space v459_7;
        if (!v459_4.empty()) {
          const Path v460_5 = concat_path(v458_10,v458_11_head);
          const Space v460_6 = routine_10(c, v460_5, v458_11_tail);
          v459_7 = compose(v459_4,v460_6);
        }
        v458_11_result = unite(v458_11_result,v459_7);
      }
      const Space v458_11 = std::move(v458_11_result);
      v456_12 = compose(v456_9,v458_11);
    }
    const Space v456_13 = unite(v456_7,v456_12);
    v455_6_result = unite(v455_6_result,v456_13);
  }
  const Space v455_6 = std::move(v455_6_result);
  return v455_6;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v461_6_result;
  for (int v461_6_label = 1; v461_6_label <= 2; ++v461_6_label) {
    const Space v461_6_tail = child(s0,v461_6_label);
    if (v461_6_tail.empty()) continue;
    const Path v461_6_head{v461_6_label};
    const Space v462_2 = singleton(v461_6_head);
    const Space v462_3 = intersect(constant_6,v462_2);
    const Space v462_4 = (has_head(v462_3) ? constant_7 : Space{});
    const Space v462_5 = subtract(constant_5,v462_4);
    Space v462_6_result;
    for (int v462_6_label = 1; v462_6_label <= 2; ++v462_6_label) {
      const Space v462_6_tail = child(v461_6_tail,v462_6_label);
      if (v462_6_tail.empty()) continue;
      const Path v462_6_head{v462_6_label};
      const Space v463_2 = Space{};
      v462_6_result = unite(v462_6_result,v463_2);
    }
    const Space v462_6 = std::move(v462_6_result);
    const Space v462_7 = compose(v462_5,v462_6);
    const Space v462_8 = intersect(constant_6,v462_2);
    const Space v462_9 = (has_head(v462_8) ? constant_7 : Space{});
    const Space v462_10 = subtract(v461_6_tail,constant_5);
    const Space v462_11 = compose(v462_9,v462_10);
    const Path v462_12 = concat_path(p0,v461_6_head);
    const Space v462_13 = wrap(v462_11,v462_12);
    const Space v462_14 = unite(v462_7,v462_13);
    v461_6_result = unite(v461_6_result,v462_14);
  }
  const Space v461_6 = std::move(v461_6_result);
  return v461_6;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v464_7_result;
  for (int v464_7_label = 1; v464_7_label <= 2; ++v464_7_label) {
    const Space v464_7_tail = child(s0,v464_7_label);
    if (v464_7_tail.empty()) continue;
    const Path v464_7_head{v464_7_label};
    const Space v465_2 = singleton(v464_7_head);
    const Space v465_3 = intersect(constant_6,v465_2);
    const Space v465_4 = (has_head(v465_3) ? constant_7 : Space{});
    const Space v465_5 = subtract(constant_5,v465_4);
    Space v465_6_result;
    for (int v465_6_label = 1; v465_6_label <= 2; ++v465_6_label) {
      const Space v465_6_tail = child(v464_7_tail,v465_6_label);
      if (v465_6_tail.empty()) continue;
      const Path v465_6_head{v465_6_label};
      const Space v466_2 = Space{};
      v465_6_result = unite(v465_6_result,v466_2);
    }
    const Space v465_6 = std::move(v465_6_result);
    const Space v465_7 = compose(v465_5,v465_6);
    const Space v465_8 = intersect(constant_6,v465_2);
    const Space v465_9 = (has_head(v465_8) ? constant_7 : Space{});
    Space v465_12;
    if (!v465_9.empty()) {
      const Path v467_10 = concat_path(p0,v464_7_head);
      Space v467_11_result;
      for (int v467_11_label = 1; v467_11_label <= 2; ++v467_11_label) {
        const Space v467_11_tail = child(v464_7_tail,v467_11_label);
        if (v467_11_tail.empty()) continue;
        const Path v467_11_head{v467_11_label};
        const Space v468_2 = singleton(v467_11_head);
        const Space v468_3 = intersect(constant_6,v468_2);
        const Space v468_4 = (has_head(v468_3) ? constant_7 : Space{});
        Space v468_7;
        if (!v468_4.empty()) {
          const Path v469_5 = concat_path(v467_10,v467_11_head);
          const Space v469_6 = routine_13(c, v469_5, v467_11_tail, s1);
          v468_7 = compose(v468_4,v469_6);
        }
        v467_11_result = unite(v467_11_result,v468_7);
      }
      const Space v467_11 = std::move(v467_11_result);
      v465_12 = compose(v465_9,v467_11);
    }
    const Space v465_13 = unite(v465_7,v465_12);
    v464_7_result = unite(v464_7_result,v465_13);
  }
  const Space v464_7 = std::move(v464_7_result);
  return v464_7;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v470_9_result;
  for (int v470_9_label = 1; v470_9_label <= 2; ++v470_9_label) {
    const Space v470_9_tail = child(s0,v470_9_label);
    if (v470_9_tail.empty()) continue;
    const Path v470_9_head{v470_9_label};
    const Space v471_2 = singleton(v470_9_head);
    const Space v471_3 = intersect(constant_6,v471_2);
    const Space v471_4 = (has_head(v471_3) ? constant_7 : Space{});
    const Space v471_5 = subtract(constant_5,v471_4);
    Space v471_6_result;
    for (int v471_6_label = 1; v471_6_label <= 2; ++v471_6_label) {
      const Space v471_6_tail = child(v470_9_tail,v471_6_label);
      if (v471_6_tail.empty()) continue;
      const Path v471_6_head{v471_6_label};
      const Space v472_2 = Space{};
      v471_6_result = unite(v471_6_result,v472_2);
    }
    const Space v471_6 = std::move(v471_6_result);
    const Space v471_7 = compose(v471_5,v471_6);
    const Space v471_8 = intersect(constant_6,v471_2);
    const Space v471_9 = (has_head(v471_8) ? constant_7 : Space{});
    Space v471_11;
    if (!v471_9.empty()) {
      Space v473_10_result;
      for (int v473_10_label = 1; v473_10_label <= 2; ++v473_10_label) {
        const Space v473_10_tail = child(v470_9_tail,v473_10_label);
        if (v473_10_tail.empty()) continue;
        const Path v473_10_head{v473_10_label};
        const Space v474_2 = singleton(v473_10_head);
        const Space v474_3 = intersect(constant_6,v474_2);
        const Space v474_4 = (has_head(v474_3) ? constant_7 : Space{});
        const Space v474_5 = subtract(constant_5,v474_4);
        Space v474_7;
        if (!v474_5.empty()) {
          const Space v475_6 = routine_32(c, v473_10_head, v473_10_tail, s1);
          v474_7 = compose(v474_5,v475_6);
        }
        const Space v474_8 = intersect(constant_6,v474_2);
        const Space v474_9 = (has_head(v474_8) ? constant_7 : Space{});
        Space v474_11;
        if (!v474_9.empty()) {
          const Space v476_10 = routine_33(c, v473_10_head, v473_10_tail, s1);
          v474_11 = compose(v474_9,v476_10);
        }
        const Space v474_12 = unite(v474_7,v474_11);
        v473_10_result = unite(v473_10_result,v474_12);
      }
      const Space v473_10 = std::move(v473_10_result);
      v471_11 = compose(v471_9,v473_10);
    }
    const Path v471_12 = concat_path(p0,v470_9_head);
    const Space v471_13 = wrap(v471_11,v471_12);
    const Space v471_14 = unite(v471_7,v471_13);
    v470_9_result = unite(v470_9_result,v471_14);
  }
  const Space v470_9 = std::move(v470_9_result);
  return v470_9;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v477_12_result;
  for (int v477_12_label = 1; v477_12_label <= 2; ++v477_12_label) {
    const Space v477_12_tail = child(s0,v477_12_label);
    if (v477_12_tail.empty()) continue;
    const Path v477_12_head{v477_12_label};
    const Space v478_2 = singleton(v477_12_head);
    const Space v478_3 = intersect(constant_6,v478_2);
    const Space v478_4 = (has_head(v478_3) ? constant_7 : Space{});
    const Space v478_5 = subtract(constant_5,v478_4);
    Space v478_8;
    if (!v478_5.empty()) {
      const Path v479_6 = concat_path(p0,v477_12_head);
      Space v479_7_result;
      for (int v479_7_label = 1; v479_7_label <= 2; ++v479_7_label) {
        const Space v479_7_tail = child(v477_12_tail,v479_7_label);
        if (v479_7_tail.empty()) continue;
        const Path v479_7_head{v479_7_label};
        const Space v480_2 = singleton(v479_7_head);
        const Space v480_3 = intersect(constant_6,v480_2);
        const Space v480_4 = (has_head(v480_3) ? constant_7 : Space{});
        const Space v480_5 = subtract(constant_5,v480_4);
        Space v480_8;
        if (!v480_5.empty()) {
          const Path v481_6 = concat_path(v479_6,v479_7_head);
          const Space v481_7 = routine_65(c, v481_6, v479_7_tail, s1);
          v480_8 = compose(v480_5,v481_7);
        }
        const Space v480_9 = intersect(constant_6,v480_2);
        const Space v480_10 = (has_head(v480_9) ? constant_7 : Space{});
        Space v480_12;
        if (!v480_10.empty()) {
          const Path v482_6 = concat_path(v479_6,v479_7_head);
          const Space v482_11 = routine_66(c, v482_6, v479_7_tail, s1);
          v480_12 = compose(v480_10,v482_11);
        }
        const Space v480_13 = unite(v480_8,v480_12);
        v479_7_result = unite(v479_7_result,v480_13);
      }
      const Space v479_7 = std::move(v479_7_result);
      v478_8 = compose(v478_5,v479_7);
    }
    const Space v478_9 = intersect(constant_6,v478_2);
    const Space v478_10 = (has_head(v478_9) ? constant_7 : Space{});
    Space v478_12;
    if (!v478_10.empty()) {
      const Path v483_6 = concat_path(p0,v477_12_head);
      Space v483_11_result;
      for (int v483_11_label = 1; v483_11_label <= 2; ++v483_11_label) {
        const Space v483_11_tail = child(v477_12_tail,v483_11_label);
        if (v483_11_tail.empty()) continue;
        const Path v483_11_head{v483_11_label};
        const Space v484_2 = singleton(v483_11_head);
        const Space v484_3 = intersect(constant_6,v484_2);
        const Space v484_4 = (has_head(v484_3) ? constant_7 : Space{});
        const Space v484_5 = subtract(constant_5,v484_4);
        Space v484_8;
        if (!v484_5.empty()) {
          const Path v485_6 = concat_path(v483_6,v483_11_head);
          const Space v485_7 = routine_65(c, v485_6, v483_11_tail, s1);
          v484_8 = compose(v484_5,v485_7);
        }
        const Space v484_9 = intersect(constant_6,v484_2);
        const Space v484_10 = (has_head(v484_9) ? constant_7 : Space{});
        Space v484_12;
        if (!v484_10.empty()) {
          const Path v486_6 = concat_path(v483_6,v483_11_head);
          const Space v486_11 = routine_36(c, v486_6, v483_11_tail, s1);
          v484_12 = compose(v484_10,v486_11);
        }
        const Space v484_13 = unite(v484_8,v484_12);
        v483_11_result = unite(v483_11_result,v484_13);
      }
      const Space v483_11 = std::move(v483_11_result);
      v478_12 = compose(v478_10,v483_11);
    }
    const Space v478_13 = unite(v478_8,v478_12);
    v477_12_result = unite(v477_12_result,v478_13);
  }
  const Space v477_12 = std::move(v477_12_result);
  return v477_12;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v487_7 = unwrap(s1,constant_3);
  const Space v487_9 = unwrap(v487_7,constant_4);
  const Space v487_10 = unwrap(v487_9,p0);
  Space v487_15_result;
  for (int v487_15_label = 1; v487_15_label <= 2; ++v487_15_label) {
    const Space v487_15_tail = child(s0,v487_15_label);
    if (v487_15_tail.empty()) continue;
    const Path v487_15_head{v487_15_label};
    const Space v488_2 = singleton(v487_15_head);
    const Space v488_3 = intersect(constant_6,v488_2);
    const Space v488_4 = (has_head(v488_3) ? constant_7 : Space{});
    const Space v488_5 = subtract(constant_5,v488_4);
    Space v488_8;
    if (!v488_5.empty()) {
      const Path v489_6 = concat_path(p0,v487_15_head);
      Space v489_7_result;
      for (int v489_7_label = 1; v489_7_label <= 2; ++v489_7_label) {
        const Space v489_7_tail = child(v487_15_tail,v489_7_label);
        if (v489_7_tail.empty()) continue;
        const Path v489_7_head{v489_7_label};
        const Space v490_2 = singleton(v489_7_head);
        const Space v490_3 = intersect(constant_6,v490_2);
        const Space v490_4 = (has_head(v490_3) ? constant_7 : Space{});
        const Space v490_5 = subtract(constant_5,v490_4);
        Space v490_8;
        if (!v490_5.empty()) {
          const Path v491_6 = concat_path(v489_6,v489_7_head);
          const Space v491_7 = routine_65(c, v491_6, v489_7_tail, s1);
          v490_8 = compose(v490_5,v491_7);
        }
        const Space v490_9 = intersect(constant_6,v490_2);
        const Space v490_10 = (has_head(v490_9) ? constant_7 : Space{});
        Space v490_12;
        if (!v490_10.empty()) {
          const Path v492_6 = concat_path(v489_6,v489_7_head);
          const Space v492_11 = routine_66(c, v492_6, v489_7_tail, s1);
          v490_12 = compose(v490_10,v492_11);
        }
        const Space v490_13 = unite(v490_8,v490_12);
        v489_7_result = unite(v489_7_result,v490_13);
      }
      const Space v489_7 = std::move(v489_7_result);
      v488_8 = compose(v488_5,v489_7);
    }
    const Space v488_9 = intersect(constant_6,v488_2);
    const Space v488_10 = (has_head(v488_9) ? constant_7 : Space{});
    const Space v488_11 = unwrap(v487_10,v487_15_head);
    const Space v488_12 = subtract(v488_11,constant_5);
    const Space v488_13 = compose(v488_10,v488_12);
    const Space v488_14 = unite(v488_8,v488_13);
    v487_15_result = unite(v487_15_result,v488_14);
  }
  const Space v487_15 = std::move(v487_15_result);
  return v487_15;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v493_12_result;
  for (int v493_12_label = 1; v493_12_label <= 2; ++v493_12_label) {
    const Space v493_12_tail = child(s0,v493_12_label);
    if (v493_12_tail.empty()) continue;
    const Path v493_12_head{v493_12_label};
    const Space v494_2 = singleton(v493_12_head);
    const Space v494_3 = intersect(constant_6,v494_2);
    const Space v494_4 = (has_head(v494_3) ? constant_7 : Space{});
    const Space v494_5 = subtract(constant_5,v494_4);
    Space v494_8;
    if (!v494_5.empty()) {
      const Path v495_6 = concat_path(p0,v493_12_head);
      Space v495_7_result;
      for (int v495_7_label = 1; v495_7_label <= 2; ++v495_7_label) {
        const Space v495_7_tail = child(v493_12_tail,v495_7_label);
        if (v495_7_tail.empty()) continue;
        const Path v495_7_head{v495_7_label};
        const Space v496_2 = singleton(v495_7_head);
        const Space v496_3 = intersect(constant_6,v496_2);
        const Space v496_4 = (has_head(v496_3) ? constant_7 : Space{});
        const Space v496_5 = subtract(constant_5,v496_4);
        Space v496_8;
        if (!v496_5.empty()) {
          const Path v497_6 = concat_path(v495_6,v495_7_head);
          const Space v497_7 = routine_67(c, v497_6, v495_7_tail, s1);
          v496_8 = compose(v496_5,v497_7);
        }
        const Space v496_9 = intersect(constant_6,v496_2);
        const Space v496_10 = (has_head(v496_9) ? constant_7 : Space{});
        Space v496_12;
        if (!v496_10.empty()) {
          const Path v498_6 = concat_path(v495_6,v495_7_head);
          const Space v498_11 = routine_68(c, v498_6, v495_7_tail, s1);
          v496_12 = compose(v496_10,v498_11);
        }
        const Space v496_13 = unite(v496_8,v496_12);
        v495_7_result = unite(v495_7_result,v496_13);
      }
      const Space v495_7 = std::move(v495_7_result);
      v494_8 = compose(v494_5,v495_7);
    }
    const Space v494_9 = intersect(constant_6,v494_2);
    const Space v494_10 = (has_head(v494_9) ? constant_7 : Space{});
    Space v494_12;
    if (!v494_10.empty()) {
      const Path v499_6 = concat_path(p0,v493_12_head);
      Space v499_11_result;
      for (int v499_11_label = 1; v499_11_label <= 2; ++v499_11_label) {
        const Space v499_11_tail = child(v493_12_tail,v499_11_label);
        if (v499_11_tail.empty()) continue;
        const Path v499_11_head{v499_11_label};
        const Space v500_2 = singleton(v499_11_head);
        const Space v500_3 = intersect(constant_6,v500_2);
        const Space v500_4 = (has_head(v500_3) ? constant_7 : Space{});
        const Space v500_5 = subtract(constant_5,v500_4);
        Space v500_8;
        if (!v500_5.empty()) {
          const Path v501_6 = concat_path(v499_6,v499_11_head);
          const Space v501_7 = routine_67(c, v501_6, v499_11_tail, s1);
          v500_8 = compose(v500_5,v501_7);
        }
        const Space v500_9 = intersect(constant_6,v500_2);
        const Space v500_10 = (has_head(v500_9) ? constant_7 : Space{});
        Space v500_12;
        if (!v500_10.empty()) {
          const Path v502_6 = concat_path(v499_6,v499_11_head);
          const Space v502_11 = routine_36(c, v502_6, v499_11_tail, s1);
          v500_12 = compose(v500_10,v502_11);
        }
        const Space v500_13 = unite(v500_8,v500_12);
        v499_11_result = unite(v499_11_result,v500_13);
      }
      const Space v499_11 = std::move(v499_11_result);
      v494_12 = compose(v494_10,v499_11);
    }
    const Space v494_13 = unite(v494_8,v494_12);
    v493_12_result = unite(v493_12_result,v494_13);
  }
  const Space v493_12 = std::move(v493_12_result);
  return v493_12;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v503_7 = unwrap(s1,constant_3);
  const Space v503_9 = unwrap(v503_7,constant_4);
  const Space v503_10 = unwrap(v503_9,p0);
  Space v503_15_result;
  for (int v503_15_label = 1; v503_15_label <= 2; ++v503_15_label) {
    const Space v503_15_tail = child(s0,v503_15_label);
    if (v503_15_tail.empty()) continue;
    const Path v503_15_head{v503_15_label};
    const Space v504_2 = singleton(v503_15_head);
    const Space v504_3 = intersect(constant_6,v504_2);
    const Space v504_4 = (has_head(v504_3) ? constant_7 : Space{});
    const Space v504_5 = subtract(constant_5,v504_4);
    Space v504_8;
    if (!v504_5.empty()) {
      const Path v505_6 = concat_path(p0,v503_15_head);
      Space v505_7_result;
      for (int v505_7_label = 1; v505_7_label <= 2; ++v505_7_label) {
        const Space v505_7_tail = child(v503_15_tail,v505_7_label);
        if (v505_7_tail.empty()) continue;
        const Path v505_7_head{v505_7_label};
        const Space v506_2 = singleton(v505_7_head);
        const Space v506_3 = intersect(constant_6,v506_2);
        const Space v506_4 = (has_head(v506_3) ? constant_7 : Space{});
        const Space v506_5 = subtract(constant_5,v506_4);
        Space v506_8;
        if (!v506_5.empty()) {
          const Path v507_6 = concat_path(v505_6,v505_7_head);
          const Space v507_7 = routine_67(c, v507_6, v505_7_tail, s1);
          v506_8 = compose(v506_5,v507_7);
        }
        const Space v506_9 = intersect(constant_6,v506_2);
        const Space v506_10 = (has_head(v506_9) ? constant_7 : Space{});
        Space v506_12;
        if (!v506_10.empty()) {
          const Path v508_6 = concat_path(v505_6,v505_7_head);
          const Space v508_11 = routine_68(c, v508_6, v505_7_tail, s1);
          v506_12 = compose(v506_10,v508_11);
        }
        const Space v506_13 = unite(v506_8,v506_12);
        v505_7_result = unite(v505_7_result,v506_13);
      }
      const Space v505_7 = std::move(v505_7_result);
      v504_8 = compose(v504_5,v505_7);
    }
    const Space v504_9 = intersect(constant_6,v504_2);
    const Space v504_10 = (has_head(v504_9) ? constant_7 : Space{});
    const Space v504_11 = unwrap(v503_10,v503_15_head);
    const Space v504_12 = subtract(v504_11,constant_5);
    const Space v504_13 = compose(v504_10,v504_12);
    const Space v504_14 = unite(v504_8,v504_13);
    v503_15_result = unite(v503_15_result,v504_14);
  }
  const Space v503_15 = std::move(v503_15_result);
  return v503_15;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v509_12_result;
  for (int v509_12_label = 1; v509_12_label <= 2; ++v509_12_label) {
    const Space v509_12_tail = child(s0,v509_12_label);
    if (v509_12_tail.empty()) continue;
    const Path v509_12_head{v509_12_label};
    const Space v510_2 = singleton(v509_12_head);
    const Space v510_3 = intersect(constant_6,v510_2);
    const Space v510_4 = (has_head(v510_3) ? constant_7 : Space{});
    const Space v510_5 = subtract(constant_5,v510_4);
    Space v510_8;
    if (!v510_5.empty()) {
      const Path v511_6 = concat_path(p0,v509_12_head);
      Space v511_7_result;
      for (int v511_7_label = 1; v511_7_label <= 2; ++v511_7_label) {
        const Space v511_7_tail = child(v509_12_tail,v511_7_label);
        if (v511_7_tail.empty()) continue;
        const Path v511_7_head{v511_7_label};
        const Space v512_2 = singleton(v511_7_head);
        const Space v512_3 = intersect(constant_6,v512_2);
        const Space v512_4 = (has_head(v512_3) ? constant_7 : Space{});
        const Space v512_5 = subtract(constant_5,v512_4);
        Space v512_8;
        if (!v512_5.empty()) {
          const Path v513_6 = concat_path(v511_6,v511_7_head);
          const Space v513_7 = routine_69(c, v513_6, v511_7_tail, s1);
          v512_8 = compose(v512_5,v513_7);
        }
        const Space v512_9 = intersect(constant_6,v512_2);
        const Space v512_10 = (has_head(v512_9) ? constant_7 : Space{});
        Space v512_12;
        if (!v512_10.empty()) {
          const Path v514_6 = concat_path(v511_6,v511_7_head);
          const Space v514_11 = routine_70(c, v514_6, v511_7_tail, s1);
          v512_12 = compose(v512_10,v514_11);
        }
        const Space v512_13 = unite(v512_8,v512_12);
        v511_7_result = unite(v511_7_result,v512_13);
      }
      const Space v511_7 = std::move(v511_7_result);
      v510_8 = compose(v510_5,v511_7);
    }
    const Space v510_9 = intersect(constant_6,v510_2);
    const Space v510_10 = (has_head(v510_9) ? constant_7 : Space{});
    Space v510_12;
    if (!v510_10.empty()) {
      const Path v515_6 = concat_path(p0,v509_12_head);
      Space v515_11_result;
      for (int v515_11_label = 1; v515_11_label <= 2; ++v515_11_label) {
        const Space v515_11_tail = child(v509_12_tail,v515_11_label);
        if (v515_11_tail.empty()) continue;
        const Path v515_11_head{v515_11_label};
        const Space v516_2 = singleton(v515_11_head);
        const Space v516_3 = intersect(constant_6,v516_2);
        const Space v516_4 = (has_head(v516_3) ? constant_7 : Space{});
        const Space v516_5 = subtract(constant_5,v516_4);
        Space v516_8;
        if (!v516_5.empty()) {
          const Path v517_6 = concat_path(v515_6,v515_11_head);
          const Space v517_7 = routine_69(c, v517_6, v515_11_tail, s1);
          v516_8 = compose(v516_5,v517_7);
        }
        const Space v516_9 = intersect(constant_6,v516_2);
        const Space v516_10 = (has_head(v516_9) ? constant_7 : Space{});
        Space v516_12;
        if (!v516_10.empty()) {
          const Path v518_6 = concat_path(v515_6,v515_11_head);
          const Space v518_11 = routine_20(c, v518_6, v515_11_tail, s1);
          v516_12 = compose(v516_10,v518_11);
        }
        const Space v516_13 = unite(v516_8,v516_12);
        v515_11_result = unite(v515_11_result,v516_13);
      }
      const Space v515_11 = std::move(v515_11_result);
      v510_12 = compose(v510_10,v515_11);
    }
    const Space v510_13 = unite(v510_8,v510_12);
    v509_12_result = unite(v509_12_result,v510_13);
  }
  const Space v509_12 = std::move(v509_12_result);
  return v509_12;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v519_7 = unwrap(s1,constant_8);
  const Space v519_9 = unwrap(v519_7,constant_4);
  const Space v519_10 = unwrap(v519_9,p0);
  Space v519_15_result;
  for (int v519_15_label = 1; v519_15_label <= 2; ++v519_15_label) {
    const Space v519_15_tail = child(s0,v519_15_label);
    if (v519_15_tail.empty()) continue;
    const Path v519_15_head{v519_15_label};
    const Space v520_2 = singleton(v519_15_head);
    const Space v520_3 = intersect(constant_6,v520_2);
    const Space v520_4 = (has_head(v520_3) ? constant_7 : Space{});
    const Space v520_5 = subtract(constant_5,v520_4);
    Space v520_8;
    if (!v520_5.empty()) {
      const Path v521_6 = concat_path(p0,v519_15_head);
      Space v521_7_result;
      for (int v521_7_label = 1; v521_7_label <= 2; ++v521_7_label) {
        const Space v521_7_tail = child(v519_15_tail,v521_7_label);
        if (v521_7_tail.empty()) continue;
        const Path v521_7_head{v521_7_label};
        const Space v522_2 = singleton(v521_7_head);
        const Space v522_3 = intersect(constant_6,v522_2);
        const Space v522_4 = (has_head(v522_3) ? constant_7 : Space{});
        const Space v522_5 = subtract(constant_5,v522_4);
        Space v522_8;
        if (!v522_5.empty()) {
          const Path v523_6 = concat_path(v521_6,v521_7_head);
          const Space v523_7 = routine_69(c, v523_6, v521_7_tail, s1);
          v522_8 = compose(v522_5,v523_7);
        }
        const Space v522_9 = intersect(constant_6,v522_2);
        const Space v522_10 = (has_head(v522_9) ? constant_7 : Space{});
        Space v522_12;
        if (!v522_10.empty()) {
          const Path v524_6 = concat_path(v521_6,v521_7_head);
          const Space v524_11 = routine_70(c, v524_6, v521_7_tail, s1);
          v522_12 = compose(v522_10,v524_11);
        }
        const Space v522_13 = unite(v522_8,v522_12);
        v521_7_result = unite(v521_7_result,v522_13);
      }
      const Space v521_7 = std::move(v521_7_result);
      v520_8 = compose(v520_5,v521_7);
    }
    const Space v520_9 = intersect(constant_6,v520_2);
    const Space v520_10 = (has_head(v520_9) ? constant_7 : Space{});
    const Space v520_11 = unwrap(v519_10,v519_15_head);
    const Space v520_12 = subtract(v520_11,constant_5);
    const Space v520_13 = compose(v520_10,v520_12);
    const Space v520_14 = unite(v520_8,v520_13);
    v519_15_result = unite(v519_15_result,v520_14);
  }
  const Space v519_15 = std::move(v519_15_result);
  return v519_15;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v525_7_result;
  for (int v525_7_label = 1; v525_7_label <= 2; ++v525_7_label) {
    const Space v525_7_tail = child(s0,v525_7_label);
    if (v525_7_tail.empty()) continue;
    const Path v525_7_head{v525_7_label};
    const Space v526_2 = singleton(v525_7_head);
    const Space v526_3 = intersect(constant_6,v526_2);
    const Space v526_4 = (has_head(v526_3) ? constant_7 : Space{});
    const Space v526_5 = subtract(constant_5,v526_4);
    Space v526_6_result;
    for (int v526_6_label = 1; v526_6_label <= 2; ++v526_6_label) {
      const Space v526_6_tail = child(v525_7_tail,v526_6_label);
      if (v526_6_tail.empty()) continue;
      const Path v526_6_head{v526_6_label};
      const Space v527_2 = Space{};
      v526_6_result = unite(v526_6_result,v527_2);
    }
    const Space v526_6 = std::move(v526_6_result);
    const Space v526_7 = compose(v526_5,v526_6);
    const Space v526_8 = intersect(constant_6,v526_2);
    const Space v526_9 = (has_head(v526_8) ? constant_7 : Space{});
    Space v526_12;
    if (!v526_9.empty()) {
      const Path v528_10 = concat_path(p0,v525_7_head);
      Space v528_11_result;
      for (int v528_11_label = 1; v528_11_label <= 2; ++v528_11_label) {
        const Space v528_11_tail = child(v525_7_tail,v528_11_label);
        if (v528_11_tail.empty()) continue;
        const Path v528_11_head{v528_11_label};
        const Space v529_2 = singleton(v528_11_head);
        const Space v529_3 = intersect(constant_6,v529_2);
        const Space v529_4 = (has_head(v529_3) ? constant_7 : Space{});
        Space v529_7;
        if (!v529_4.empty()) {
          const Path v530_5 = concat_path(v528_10,v528_11_head);
          const Space v530_6 = routine_20(c, v530_5, v528_11_tail, s1);
          v529_7 = compose(v529_4,v530_6);
        }
        v528_11_result = unite(v528_11_result,v529_7);
      }
      const Space v528_11 = std::move(v528_11_result);
      v526_12 = compose(v526_9,v528_11);
    }
    const Space v526_13 = unite(v526_7,v526_12);
    v525_7_result = unite(v525_7_result,v526_13);
  }
  const Space v525_7 = std::move(v525_7_result);
  return v525_7;
}

static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v531_7 = unwrap(s1,constant_8);
  const Space v531_9 = unwrap(v531_7,constant_4);
  const Space v531_10 = unwrap(v531_9,p0);
  Space v531_12_result;
  for (int v531_12_label = 1; v531_12_label <= 2; ++v531_12_label) {
    const Space v531_12_tail = child(s0,v531_12_label);
    if (v531_12_tail.empty()) continue;
    const Path v531_12_head{v531_12_label};
    const Space v532_2 = singleton(v531_12_head);
    const Space v532_3 = intersect(constant_6,v532_2);
    const Space v532_4 = (has_head(v532_3) ? constant_7 : Space{});
    const Space v532_5 = subtract(constant_5,v532_4);
    Space v532_6_result;
    for (int v532_6_label = 1; v532_6_label <= 2; ++v532_6_label) {
      const Space v532_6_tail = child(v531_12_tail,v532_6_label);
      if (v532_6_tail.empty()) continue;
      const Path v532_6_head{v532_6_label};
      const Space v533_2 = Space{};
      v532_6_result = unite(v532_6_result,v533_2);
    }
    const Space v532_6 = std::move(v532_6_result);
    const Space v532_7 = compose(v532_5,v532_6);
    const Space v532_8 = intersect(constant_6,v532_2);
    const Space v532_9 = (has_head(v532_8) ? constant_7 : Space{});
    const Space v532_10 = unwrap(v531_10,v531_12_head);
    const Space v532_11 = subtract(v532_10,constant_5);
    const Space v532_12 = compose(v532_9,v532_11);
    const Space v532_13 = unite(v532_7,v532_12);
    v531_12_result = unite(v531_12_result,v532_13);
  }
  const Space v531_12 = std::move(v531_12_result);
  return v531_12;
}

static Space routine_61(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v534_12_result;
  for (int v534_12_label = 1; v534_12_label <= 2; ++v534_12_label) {
    const Space v534_12_tail = child(s0,v534_12_label);
    if (v534_12_tail.empty()) continue;
    const Path v534_12_head{v534_12_label};
    const Space v535_2 = singleton(v534_12_head);
    const Space v535_3 = intersect(constant_6,v535_2);
    const Space v535_4 = (has_head(v535_3) ? constant_7 : Space{});
    const Space v535_5 = subtract(constant_5,v535_4);
    Space v535_8;
    if (!v535_5.empty()) {
      const Path v536_6 = concat_path(p0,v534_12_head);
      Space v536_7_result;
      for (int v536_7_label = 1; v536_7_label <= 2; ++v536_7_label) {
        const Space v536_7_tail = child(v534_12_tail,v536_7_label);
        if (v536_7_tail.empty()) continue;
        const Path v536_7_head{v536_7_label};
        const Space v537_2 = singleton(v536_7_head);
        const Space v537_3 = intersect(constant_6,v537_2);
        const Space v537_4 = (has_head(v537_3) ? constant_7 : Space{});
        const Space v537_5 = subtract(constant_5,v537_4);
        Space v537_8;
        if (!v537_5.empty()) {
          const Path v538_6 = concat_path(v536_6,v536_7_head);
          const Space v538_7 = routine_71(c, v538_6, v536_7_tail, s1);
          v537_8 = compose(v537_5,v538_7);
        }
        const Space v537_9 = intersect(constant_6,v537_2);
        const Space v537_10 = (has_head(v537_9) ? constant_7 : Space{});
        Space v537_12;
        if (!v537_10.empty()) {
          const Path v539_6 = concat_path(v536_6,v536_7_head);
          const Space v539_11 = routine_72(c, v539_6, v536_7_tail, s1);
          v537_12 = compose(v537_10,v539_11);
        }
        const Space v537_13 = unite(v537_8,v537_12);
        v536_7_result = unite(v536_7_result,v537_13);
      }
      const Space v536_7 = std::move(v536_7_result);
      v535_8 = compose(v535_5,v536_7);
    }
    const Space v535_9 = intersect(constant_6,v535_2);
    const Space v535_10 = (has_head(v535_9) ? constant_7 : Space{});
    Space v535_12;
    if (!v535_10.empty()) {
      const Path v540_6 = concat_path(p0,v534_12_head);
      Space v540_11_result;
      for (int v540_11_label = 1; v540_11_label <= 2; ++v540_11_label) {
        const Space v540_11_tail = child(v534_12_tail,v540_11_label);
        if (v540_11_tail.empty()) continue;
        const Path v540_11_head{v540_11_label};
        const Space v541_2 = singleton(v540_11_head);
        const Space v541_3 = intersect(constant_6,v541_2);
        const Space v541_4 = (has_head(v541_3) ? constant_7 : Space{});
        const Space v541_5 = subtract(constant_5,v541_4);
        Space v541_8;
        if (!v541_5.empty()) {
          const Path v542_6 = concat_path(v540_6,v540_11_head);
          const Space v542_7 = routine_71(c, v542_6, v540_11_tail, s1);
          v541_8 = compose(v541_5,v542_7);
        }
        const Space v541_9 = intersect(constant_6,v541_2);
        const Space v541_10 = (has_head(v541_9) ? constant_7 : Space{});
        Space v541_12;
        if (!v541_10.empty()) {
          const Path v543_6 = concat_path(v540_6,v540_11_head);
          const Space v543_11 = routine_27(c, v543_6, v540_11_tail, s1);
          v541_12 = compose(v541_10,v543_11);
        }
        const Space v541_13 = unite(v541_8,v541_12);
        v540_11_result = unite(v540_11_result,v541_13);
      }
      const Space v540_11 = std::move(v540_11_result);
      v535_12 = compose(v535_10,v540_11);
    }
    const Space v535_13 = unite(v535_8,v535_12);
    v534_12_result = unite(v534_12_result,v535_13);
  }
  const Space v534_12 = std::move(v534_12_result);
  return v534_12;
}

static Space routine_62(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v544_7 = unwrap(s1,constant_3);
  const Space v544_9 = unwrap(v544_7,constant_4);
  const Space v544_10 = unwrap(v544_9,p0);
  Space v544_15_result;
  for (int v544_15_label = 1; v544_15_label <= 2; ++v544_15_label) {
    const Space v544_15_tail = child(s0,v544_15_label);
    if (v544_15_tail.empty()) continue;
    const Path v544_15_head{v544_15_label};
    const Space v545_2 = singleton(v544_15_head);
    const Space v545_3 = intersect(constant_6,v545_2);
    const Space v545_4 = (has_head(v545_3) ? constant_7 : Space{});
    const Space v545_5 = subtract(constant_5,v545_4);
    Space v545_8;
    if (!v545_5.empty()) {
      const Path v546_6 = concat_path(p0,v544_15_head);
      Space v546_7_result;
      for (int v546_7_label = 1; v546_7_label <= 2; ++v546_7_label) {
        const Space v546_7_tail = child(v544_15_tail,v546_7_label);
        if (v546_7_tail.empty()) continue;
        const Path v546_7_head{v546_7_label};
        const Space v547_2 = singleton(v546_7_head);
        const Space v547_3 = intersect(constant_6,v547_2);
        const Space v547_4 = (has_head(v547_3) ? constant_7 : Space{});
        const Space v547_5 = subtract(constant_5,v547_4);
        Space v547_8;
        if (!v547_5.empty()) {
          const Path v548_6 = concat_path(v546_6,v546_7_head);
          const Space v548_7 = routine_71(c, v548_6, v546_7_tail, s1);
          v547_8 = compose(v547_5,v548_7);
        }
        const Space v547_9 = intersect(constant_6,v547_2);
        const Space v547_10 = (has_head(v547_9) ? constant_7 : Space{});
        Space v547_12;
        if (!v547_10.empty()) {
          const Path v549_6 = concat_path(v546_6,v546_7_head);
          const Space v549_11 = routine_72(c, v549_6, v546_7_tail, s1);
          v547_12 = compose(v547_10,v549_11);
        }
        const Space v547_13 = unite(v547_8,v547_12);
        v546_7_result = unite(v546_7_result,v547_13);
      }
      const Space v546_7 = std::move(v546_7_result);
      v545_8 = compose(v545_5,v546_7);
    }
    const Space v545_9 = intersect(constant_6,v545_2);
    const Space v545_10 = (has_head(v545_9) ? constant_7 : Space{});
    const Space v545_11 = unwrap(v544_10,v544_15_head);
    const Space v545_12 = subtract(v545_11,constant_5);
    const Space v545_13 = compose(v545_10,v545_12);
    const Space v545_14 = unite(v545_8,v545_13);
    v544_15_result = unite(v544_15_result,v545_14);
  }
  const Space v544_15 = std::move(v544_15_result);
  return v544_15;
}

static Space routine_63(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v550_7_result;
  for (int v550_7_label = 1; v550_7_label <= 2; ++v550_7_label) {
    const Space v550_7_tail = child(s0,v550_7_label);
    if (v550_7_tail.empty()) continue;
    const Path v550_7_head{v550_7_label};
    const Space v551_2 = singleton(v550_7_head);
    const Space v551_3 = intersect(constant_6,v551_2);
    const Space v551_4 = (has_head(v551_3) ? constant_7 : Space{});
    const Space v551_5 = subtract(constant_5,v551_4);
    Space v551_6_result;
    for (int v551_6_label = 1; v551_6_label <= 2; ++v551_6_label) {
      const Space v551_6_tail = child(v550_7_tail,v551_6_label);
      if (v551_6_tail.empty()) continue;
      const Path v551_6_head{v551_6_label};
      const Space v552_2 = Space{};
      v551_6_result = unite(v551_6_result,v552_2);
    }
    const Space v551_6 = std::move(v551_6_result);
    const Space v551_7 = compose(v551_5,v551_6);
    const Space v551_8 = intersect(constant_6,v551_2);
    const Space v551_9 = (has_head(v551_8) ? constant_7 : Space{});
    Space v551_12;
    if (!v551_9.empty()) {
      const Path v553_10 = concat_path(p0,v550_7_head);
      Space v553_11_result;
      for (int v553_11_label = 1; v553_11_label <= 2; ++v553_11_label) {
        const Space v553_11_tail = child(v550_7_tail,v553_11_label);
        if (v553_11_tail.empty()) continue;
        const Path v553_11_head{v553_11_label};
        const Space v554_2 = singleton(v553_11_head);
        const Space v554_3 = intersect(constant_6,v554_2);
        const Space v554_4 = (has_head(v554_3) ? constant_7 : Space{});
        Space v554_7;
        if (!v554_4.empty()) {
          const Path v555_5 = concat_path(v553_10,v553_11_head);
          const Space v555_6 = routine_27(c, v555_5, v553_11_tail, s1);
          v554_7 = compose(v554_4,v555_6);
        }
        v553_11_result = unite(v553_11_result,v554_7);
      }
      const Space v553_11 = std::move(v553_11_result);
      v551_12 = compose(v551_9,v553_11);
    }
    const Space v551_13 = unite(v551_7,v551_12);
    v550_7_result = unite(v550_7_result,v551_13);
  }
  const Space v550_7 = std::move(v550_7_result);
  return v550_7;
}

static Space routine_64(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v556_7 = unwrap(s1,constant_3);
  const Space v556_9 = unwrap(v556_7,constant_4);
  const Space v556_10 = unwrap(v556_9,p0);
  Space v556_12_result;
  for (int v556_12_label = 1; v556_12_label <= 2; ++v556_12_label) {
    const Space v556_12_tail = child(s0,v556_12_label);
    if (v556_12_tail.empty()) continue;
    const Path v556_12_head{v556_12_label};
    const Space v557_2 = singleton(v556_12_head);
    const Space v557_3 = intersect(constant_6,v557_2);
    const Space v557_4 = (has_head(v557_3) ? constant_7 : Space{});
    const Space v557_5 = subtract(constant_5,v557_4);
    Space v557_6_result;
    for (int v557_6_label = 1; v557_6_label <= 2; ++v557_6_label) {
      const Space v557_6_tail = child(v556_12_tail,v557_6_label);
      if (v557_6_tail.empty()) continue;
      const Path v557_6_head{v557_6_label};
      const Space v558_2 = Space{};
      v557_6_result = unite(v557_6_result,v558_2);
    }
    const Space v557_6 = std::move(v557_6_result);
    const Space v557_7 = compose(v557_5,v557_6);
    const Space v557_8 = intersect(constant_6,v557_2);
    const Space v557_9 = (has_head(v557_8) ? constant_7 : Space{});
    const Space v557_10 = unwrap(v556_10,v556_12_head);
    const Space v557_11 = subtract(v557_10,constant_5);
    const Space v557_12 = compose(v557_9,v557_11);
    const Space v557_13 = unite(v557_7,v557_12);
    v556_12_result = unite(v556_12_result,v557_13);
  }
  const Space v556_12 = std::move(v556_12_result);
  return v556_12;
}

static Space routine_65(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v559_12_result;
  for (int v559_12_label = 1; v559_12_label <= 2; ++v559_12_label) {
    const Space v559_12_tail = child(s0,v559_12_label);
    if (v559_12_tail.empty()) continue;
    const Path v559_12_head{v559_12_label};
    const Space v560_2 = singleton(v559_12_head);
    const Space v560_3 = intersect(constant_6,v560_2);
    const Space v560_4 = (has_head(v560_3) ? constant_7 : Space{});
    const Space v560_5 = subtract(constant_5,v560_4);
    Space v560_8;
    if (!v560_5.empty()) {
      const Path v561_6 = concat_path(p0,v559_12_head);
      Space v561_7_result;
      for (int v561_7_label = 1; v561_7_label <= 2; ++v561_7_label) {
        const Space v561_7_tail = child(v559_12_tail,v561_7_label);
        if (v561_7_tail.empty()) continue;
        const Path v561_7_head{v561_7_label};
        const Space v562_2 = singleton(v561_7_head);
        const Space v562_3 = intersect(constant_6,v562_2);
        const Space v562_4 = (has_head(v562_3) ? constant_7 : Space{});
        const Space v562_5 = subtract(constant_5,v562_4);
        Space v562_8;
        if (!v562_5.empty()) {
          const Path v563_6 = concat_path(v561_6,v561_7_head);
          const Space v563_7 = routine_73(c, v563_6, v561_7_tail, s1);
          v562_8 = compose(v562_5,v563_7);
        }
        const Space v562_9 = intersect(constant_6,v562_2);
        const Space v562_10 = (has_head(v562_9) ? constant_7 : Space{});
        Space v562_12;
        if (!v562_10.empty()) {
          const Path v564_6 = concat_path(v561_6,v561_7_head);
          const Space v564_11 = routine_74(c, v564_6, v561_7_tail, s1);
          v562_12 = compose(v562_10,v564_11);
        }
        const Space v562_13 = unite(v562_8,v562_12);
        v561_7_result = unite(v561_7_result,v562_13);
      }
      const Space v561_7 = std::move(v561_7_result);
      v560_8 = compose(v560_5,v561_7);
    }
    const Space v560_9 = intersect(constant_6,v560_2);
    const Space v560_10 = (has_head(v560_9) ? constant_7 : Space{});
    Space v560_12;
    if (!v560_10.empty()) {
      const Path v565_6 = concat_path(p0,v559_12_head);
      Space v565_11_result;
      for (int v565_11_label = 1; v565_11_label <= 2; ++v565_11_label) {
        const Space v565_11_tail = child(v559_12_tail,v565_11_label);
        if (v565_11_tail.empty()) continue;
        const Path v565_11_head{v565_11_label};
        const Space v566_2 = singleton(v565_11_head);
        const Space v566_3 = intersect(constant_6,v566_2);
        const Space v566_4 = (has_head(v566_3) ? constant_7 : Space{});
        const Space v566_5 = subtract(constant_5,v566_4);
        Space v566_8;
        if (!v566_5.empty()) {
          const Path v567_6 = concat_path(v565_6,v565_11_head);
          const Space v567_7 = routine_73(c, v567_6, v565_11_tail, s1);
          v566_8 = compose(v566_5,v567_7);
        }
        const Space v566_9 = intersect(constant_6,v566_2);
        const Space v566_10 = (has_head(v566_9) ? constant_7 : Space{});
        Space v566_12;
        if (!v566_10.empty()) {
          const Path v568_6 = concat_path(v565_6,v565_11_head);
          const Space v568_11 = routine_36(c, v568_6, v565_11_tail, s1);
          v566_12 = compose(v566_10,v568_11);
        }
        const Space v566_13 = unite(v566_8,v566_12);
        v565_11_result = unite(v565_11_result,v566_13);
      }
      const Space v565_11 = std::move(v565_11_result);
      v560_12 = compose(v560_10,v565_11);
    }
    const Space v560_13 = unite(v560_8,v560_12);
    v559_12_result = unite(v559_12_result,v560_13);
  }
  const Space v559_12 = std::move(v559_12_result);
  return v559_12;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v569_7 = unwrap(s1,constant_3);
  const Space v569_9 = unwrap(v569_7,constant_4);
  const Space v569_10 = unwrap(v569_9,p0);
  Space v569_15_result;
  for (int v569_15_label = 1; v569_15_label <= 2; ++v569_15_label) {
    const Space v569_15_tail = child(s0,v569_15_label);
    if (v569_15_tail.empty()) continue;
    const Path v569_15_head{v569_15_label};
    const Space v570_2 = singleton(v569_15_head);
    const Space v570_3 = intersect(constant_6,v570_2);
    const Space v570_4 = (has_head(v570_3) ? constant_7 : Space{});
    const Space v570_5 = subtract(constant_5,v570_4);
    Space v570_8;
    if (!v570_5.empty()) {
      const Path v571_6 = concat_path(p0,v569_15_head);
      Space v571_7_result;
      for (int v571_7_label = 1; v571_7_label <= 2; ++v571_7_label) {
        const Space v571_7_tail = child(v569_15_tail,v571_7_label);
        if (v571_7_tail.empty()) continue;
        const Path v571_7_head{v571_7_label};
        const Space v572_2 = singleton(v571_7_head);
        const Space v572_3 = intersect(constant_6,v572_2);
        const Space v572_4 = (has_head(v572_3) ? constant_7 : Space{});
        const Space v572_5 = subtract(constant_5,v572_4);
        Space v572_8;
        if (!v572_5.empty()) {
          const Path v573_6 = concat_path(v571_6,v571_7_head);
          const Space v573_7 = routine_73(c, v573_6, v571_7_tail, s1);
          v572_8 = compose(v572_5,v573_7);
        }
        const Space v572_9 = intersect(constant_6,v572_2);
        const Space v572_10 = (has_head(v572_9) ? constant_7 : Space{});
        Space v572_12;
        if (!v572_10.empty()) {
          const Path v574_6 = concat_path(v571_6,v571_7_head);
          const Space v574_11 = routine_74(c, v574_6, v571_7_tail, s1);
          v572_12 = compose(v572_10,v574_11);
        }
        const Space v572_13 = unite(v572_8,v572_12);
        v571_7_result = unite(v571_7_result,v572_13);
      }
      const Space v571_7 = std::move(v571_7_result);
      v570_8 = compose(v570_5,v571_7);
    }
    const Space v570_9 = intersect(constant_6,v570_2);
    const Space v570_10 = (has_head(v570_9) ? constant_7 : Space{});
    const Space v570_11 = unwrap(v569_10,v569_15_head);
    const Space v570_12 = subtract(v570_11,constant_5);
    const Space v570_13 = compose(v570_10,v570_12);
    const Space v570_14 = unite(v570_8,v570_13);
    v569_15_result = unite(v569_15_result,v570_14);
  }
  const Space v569_15 = std::move(v569_15_result);
  return v569_15;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v575_7_result;
  for (int v575_7_label = 1; v575_7_label <= 2; ++v575_7_label) {
    const Space v575_7_tail = child(s0,v575_7_label);
    if (v575_7_tail.empty()) continue;
    const Path v575_7_head{v575_7_label};
    const Space v576_2 = singleton(v575_7_head);
    const Space v576_3 = intersect(constant_6,v576_2);
    const Space v576_4 = (has_head(v576_3) ? constant_7 : Space{});
    const Space v576_5 = subtract(constant_5,v576_4);
    Space v576_6_result;
    for (int v576_6_label = 1; v576_6_label <= 2; ++v576_6_label) {
      const Space v576_6_tail = child(v575_7_tail,v576_6_label);
      if (v576_6_tail.empty()) continue;
      const Path v576_6_head{v576_6_label};
      const Space v577_2 = Space{};
      v576_6_result = unite(v576_6_result,v577_2);
    }
    const Space v576_6 = std::move(v576_6_result);
    const Space v576_7 = compose(v576_5,v576_6);
    const Space v576_8 = intersect(constant_6,v576_2);
    const Space v576_9 = (has_head(v576_8) ? constant_7 : Space{});
    Space v576_12;
    if (!v576_9.empty()) {
      const Path v578_10 = concat_path(p0,v575_7_head);
      Space v578_11_result;
      for (int v578_11_label = 1; v578_11_label <= 2; ++v578_11_label) {
        const Space v578_11_tail = child(v575_7_tail,v578_11_label);
        if (v578_11_tail.empty()) continue;
        const Path v578_11_head{v578_11_label};
        const Space v579_2 = singleton(v578_11_head);
        const Space v579_3 = intersect(constant_6,v579_2);
        const Space v579_4 = (has_head(v579_3) ? constant_7 : Space{});
        Space v579_7;
        if (!v579_4.empty()) {
          const Path v580_5 = concat_path(v578_10,v578_11_head);
          const Space v580_6 = routine_36(c, v580_5, v578_11_tail, s1);
          v579_7 = compose(v579_4,v580_6);
        }
        v578_11_result = unite(v578_11_result,v579_7);
      }
      const Space v578_11 = std::move(v578_11_result);
      v576_12 = compose(v576_9,v578_11);
    }
    const Space v576_13 = unite(v576_7,v576_12);
    v575_7_result = unite(v575_7_result,v576_13);
  }
  const Space v575_7 = std::move(v575_7_result);
  return v575_7;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v581_7 = unwrap(s1,constant_3);
  const Space v581_9 = unwrap(v581_7,constant_4);
  const Space v581_10 = unwrap(v581_9,p0);
  Space v581_12_result;
  for (int v581_12_label = 1; v581_12_label <= 2; ++v581_12_label) {
    const Space v581_12_tail = child(s0,v581_12_label);
    if (v581_12_tail.empty()) continue;
    const Path v581_12_head{v581_12_label};
    const Space v582_2 = singleton(v581_12_head);
    const Space v582_3 = intersect(constant_6,v582_2);
    const Space v582_4 = (has_head(v582_3) ? constant_7 : Space{});
    const Space v582_5 = subtract(constant_5,v582_4);
    Space v582_6_result;
    for (int v582_6_label = 1; v582_6_label <= 2; ++v582_6_label) {
      const Space v582_6_tail = child(v581_12_tail,v582_6_label);
      if (v582_6_tail.empty()) continue;
      const Path v582_6_head{v582_6_label};
      const Space v583_2 = Space{};
      v582_6_result = unite(v582_6_result,v583_2);
    }
    const Space v582_6 = std::move(v582_6_result);
    const Space v582_7 = compose(v582_5,v582_6);
    const Space v582_8 = intersect(constant_6,v582_2);
    const Space v582_9 = (has_head(v582_8) ? constant_7 : Space{});
    const Space v582_10 = unwrap(v581_10,v581_12_head);
    const Space v582_11 = subtract(v582_10,constant_5);
    const Space v582_12 = compose(v582_9,v582_11);
    const Space v582_13 = unite(v582_7,v582_12);
    v581_12_result = unite(v581_12_result,v582_13);
  }
  const Space v581_12 = std::move(v581_12_result);
  return v581_12;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v584_3_result;
  for (int v584_3_label = 1; v584_3_label <= 2; ++v584_3_label) {
    const Space v584_3_tail = child(s0,v584_3_label);
    if (v584_3_tail.empty()) continue;
    const Path v584_3_head{v584_3_label};
    const Space v585_2 = Space{};
    v584_3_result = unite(v584_3_result,v585_2);
  }
  const Space v584_3 = std::move(v584_3_result);
  return v584_3;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v586_5 = unwrap(s1,constant_8);
  const Space v586_7 = unwrap(v586_5,constant_4);
  const Space v586_8 = unwrap(v586_7,p0);
  Space v586_10_result;
  for (int v586_10_label = 1; v586_10_label <= 2; ++v586_10_label) {
    const Space v586_10_tail = child(s0,v586_10_label);
    if (v586_10_tail.empty()) continue;
    const Path v586_10_head{v586_10_label};
    const Space v587_2 = singleton(v586_10_head);
    const Space v587_3 = intersect(constant_6,v587_2);
    const Space v587_4 = (has_head(v587_3) ? constant_7 : Space{});
    const Space v587_5 = unwrap(v586_8,v586_10_head);
    const Space v587_6 = subtract(v587_5,constant_5);
    const Space v587_7 = compose(v587_4,v587_6);
    v586_10_result = unite(v586_10_result,v587_7);
  }
  const Space v586_10 = std::move(v586_10_result);
  return v586_10;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v588_3_result;
  for (int v588_3_label = 1; v588_3_label <= 2; ++v588_3_label) {
    const Space v588_3_tail = child(s0,v588_3_label);
    if (v588_3_tail.empty()) continue;
    const Path v588_3_head{v588_3_label};
    const Space v589_2 = Space{};
    v588_3_result = unite(v588_3_result,v589_2);
  }
  const Space v588_3 = std::move(v588_3_result);
  return v588_3;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v590_5 = unwrap(s1,constant_3);
  const Space v590_7 = unwrap(v590_5,constant_4);
  const Space v590_8 = unwrap(v590_7,p0);
  Space v590_10_result;
  for (int v590_10_label = 1; v590_10_label <= 2; ++v590_10_label) {
    const Space v590_10_tail = child(s0,v590_10_label);
    if (v590_10_tail.empty()) continue;
    const Path v590_10_head{v590_10_label};
    const Space v591_2 = singleton(v590_10_head);
    const Space v591_3 = intersect(constant_6,v591_2);
    const Space v591_4 = (has_head(v591_3) ? constant_7 : Space{});
    const Space v591_5 = unwrap(v590_8,v590_10_head);
    const Space v591_6 = subtract(v591_5,constant_5);
    const Space v591_7 = compose(v591_4,v591_6);
    v590_10_result = unite(v590_10_result,v591_7);
  }
  const Space v590_10 = std::move(v590_10_result);
  return v590_10;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v592_3_result;
  for (int v592_3_label = 1; v592_3_label <= 2; ++v592_3_label) {
    const Space v592_3_tail = child(s0,v592_3_label);
    if (v592_3_tail.empty()) continue;
    const Path v592_3_head{v592_3_label};
    const Space v593_2 = Space{};
    v592_3_result = unite(v592_3_result,v593_2);
  }
  const Space v592_3 = std::move(v592_3_result);
  return v592_3;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v594_5 = unwrap(s1,constant_3);
  const Space v594_7 = unwrap(v594_5,constant_4);
  const Space v594_8 = unwrap(v594_7,p0);
  Space v594_10_result;
  for (int v594_10_label = 1; v594_10_label <= 2; ++v594_10_label) {
    const Space v594_10_tail = child(s0,v594_10_label);
    if (v594_10_tail.empty()) continue;
    const Path v594_10_head{v594_10_label};
    const Space v595_2 = singleton(v594_10_head);
    const Space v595_3 = intersect(constant_6,v595_2);
    const Space v595_4 = (has_head(v595_3) ? constant_7 : Space{});
    const Space v595_5 = unwrap(v594_8,v594_10_head);
    const Space v595_6 = subtract(v595_5,constant_5);
    const Space v595_7 = compose(v595_4,v595_6);
    v594_10_result = unite(v594_10_result,v595_7);
  }
  const Space v594_10 = std::move(v594_10_result);
  return v594_10;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
