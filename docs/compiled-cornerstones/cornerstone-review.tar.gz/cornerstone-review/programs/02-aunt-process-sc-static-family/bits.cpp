#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{1,1,1,1,2,2};
static const Space constant_4 = literal_text("6 8 1 1 1 2 2 1 2 2 8 1 2 1 2 2 1 2 2 9 1 2 1 2 2 2 1 2 2 8 1 2 2 2 1 1 2 2 5 1 2 2 2 2 9 2 1 1 2 2 1 1 2 2");
static const Space constant_5 = literal_text("6 9 1 1 2 2 2 1 1 2 2 8 1 2 2 1 1 1 2 2 8 1 2 2 1 2 1 2 2 8 2 1 1 2 2 1 2 2 9 2 1 2 2 1 2 1 2 2 5 2 2 1 2 2");
static const Space constant_6 = literal_text("4 5 1 1 1 2 2 5 2 1 1 2 2 4 2 1 2 2 2 2 2");
static Space routine_0(Context& c, const Space* s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  Space v0_4_result;
  for (int v0_4_label = 1; v0_4_label <= 2; ++v0_4_label) {
    const Space v0_4_tail = child(bound_space(s0),v0_4_label);
    if (v0_4_tail.empty()) continue;
    const Path v0_4_head{v0_4_label};
    const Space v1_2 = singleton(v0_4_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_4_head, v0_4_tail);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_4_head, v0_4_tail);
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_4_result = unite(v0_4_result,v1_12);
  }
  const Space v0_4 = std::move(v0_4_result);
  const Space v0_6 = wrap(v0_4,constant_3);
  return v0_6;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v4_11_result;
  for (int v4_11_label = 1; v4_11_label <= 2; ++v4_11_label) {
    const Space v4_11_tail = child(s0,v4_11_label);
    if (v4_11_tail.empty()) continue;
    const Path v4_11_head{v4_11_label};
    const Space v5_2 = singleton(v4_11_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_11_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_11_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_11_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_11_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_11_result = unite(v4_11_result,v5_13);
  }
  const Space v4_11 = std::move(v4_11_result);
  return v4_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  const Space v14_8 = unwrap(constant_5,p0);
  const Space v14_10 = unwrap(constant_5,p0);
  Space v14_21_result;
  for (int v14_21_label = 1; v14_21_label <= 2; ++v14_21_label) {
    const Space v14_21_tail = child(s0,v14_21_label);
    if (v14_21_tail.empty()) continue;
    const Path v14_21_head{v14_21_label};
    const Space v15_2 = singleton(v14_21_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_21_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_21_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_19;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_8,v14_21_head);
      const Space v20_12 = restrict_to(constant_5,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(constant_4,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = unwrap(v14_10,v14_21_head);
      const Space v20_17 = subtract(v20_15,v20_16);
      const Space v20_18 = intersect(v20_17,constant_6);
      v15_19 = compose(v15_10,v20_18);
    }
    const Path v27_6 = concat_path(p0,v14_21_head);
    const Space v15_20 = wrap(v15_19,v27_6);
    const Space v15_21 = unite(v15_8,v15_20);
    v14_21_result = unite(v14_21_result,v15_21);
  }
  const Space v14_21 = std::move(v14_21_result);
  return v14_21;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v28_11_result;
  for (int v28_11_label = 1; v28_11_label <= 2; ++v28_11_label) {
    const Space v28_11_tail = child(s0,v28_11_label);
    if (v28_11_tail.empty()) continue;
    const Path v28_11_head{v28_11_label};
    const Space v29_2 = singleton(v28_11_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_11_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_11_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_11_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_11_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_11_result = unite(v28_11_result,v29_13);
  }
  const Space v28_11 = std::move(v28_11_result);
  return v28_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  const Space v38_8 = unwrap(constant_5,p0);
  const Space v38_10 = unwrap(constant_5,p0);
  Space v38_21_result;
  for (int v38_21_label = 1; v38_21_label <= 2; ++v38_21_label) {
    const Space v38_21_tail = child(s0,v38_21_label);
    if (v38_21_tail.empty()) continue;
    const Path v38_21_head{v38_21_label};
    const Space v39_2 = singleton(v38_21_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_21_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_21_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_19;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_8,v38_21_head);
      const Space v44_12 = restrict_to(constant_5,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(constant_4,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = unwrap(v38_10,v38_21_head);
      const Space v44_17 = subtract(v44_15,v44_16);
      const Space v44_18 = intersect(v44_17,constant_6);
      v39_19 = compose(v39_10,v44_18);
    }
    const Path v51_6 = concat_path(p0,v38_21_head);
    const Space v39_20 = wrap(v39_19,v51_6);
    const Space v39_21 = unite(v39_8,v39_20);
    v38_21_result = unite(v38_21_result,v39_21);
  }
  const Space v38_21 = std::move(v38_21_result);
  return v38_21;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  const Space v52_5 = unwrap(constant_5,p0);
  const Space v52_6 = restrict_to(constant_5,v52_5);
  Space v52_16_result;
  for (int v52_16_label = 1; v52_16_label <= 2; ++v52_16_label) {
    const Space v52_16_tail = child(v52_6,v52_16_label);
    if (v52_16_tail.empty()) continue;
    const Path v52_16_head{v52_16_label};
    const Space v53_2 = singleton(v52_16_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_16_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_16_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_16_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_16_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_16_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_16_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_16_result = unite(v52_16_result,v53_12);
  }
  const Space v52_16 = std::move(v52_16_result);
  const Space v52_17 = restrict_to(constant_4,v52_16);
  Space v52_27_result;
  for (int v52_27_label = 1; v52_27_label <= 2; ++v52_27_label) {
    const Space v52_27_tail = child(v52_17,v52_27_label);
    if (v52_27_tail.empty()) continue;
    const Path v52_27_head{v52_27_label};
    const Space v62_2 = singleton(v52_27_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_27_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_27_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_27_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_27_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_27_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_27_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_27_result = unite(v52_27_result,v62_12);
  }
  const Space v52_27 = std::move(v52_27_result);
  const Space v52_29 = unwrap(constant_5,p0);
  const Space v52_30 = subtract(v52_27,v52_29);
  const Space v52_32 = intersect(v52_30,constant_6);
  const Space v52_33 = wrap(v52_32,p0);
  return v52_33;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  Space v103_2_result;
  for (int v103_2_label = 1; v103_2_label <= 2; ++v103_2_label) {
    const Space v103_2_tail = child(s0,v103_2_label);
    if (v103_2_tail.empty()) continue;
    const Path v103_2_head{v103_2_label};
    const Space v104_2 = Space{};
    v103_2_result = unite(v103_2_result,v104_2);
  }
  const Space v103_2 = std::move(v103_2_result);
  return v103_2;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  const Space v105_6 = unwrap(constant_5,p0);
  const Space v105_8 = unwrap(constant_5,p0);
  Space v105_16_result;
  for (int v105_16_label = 1; v105_16_label <= 2; ++v105_16_label) {
    const Space v105_16_tail = child(s0,v105_16_label);
    if (v105_16_tail.empty()) continue;
    const Path v105_16_head{v105_16_label};
    const Space v106_2 = singleton(v105_16_head);
    const Space v106_3 = intersect(constant_1,v106_2);
    const Space v106_4 = (has_head(v106_3) ? constant_2 : Space{});
    Space v106_13;
    if (!v106_4.empty()) {
      const Space v107_5 = unwrap(v105_6,v105_16_head);
      const Space v107_6 = restrict_to(constant_5,v107_5);
      Space v107_7_result;
      for (int v107_7_label = 1; v107_7_label <= 2; ++v107_7_label) {
        const Space v107_7_tail = child(v107_6,v107_7_label);
        if (v107_7_tail.empty()) continue;
        const Path v107_7_head{v107_7_label};
        const Space v108_2 = singleton(v107_7_head);
        const Space v108_3 = intersect(constant_1,v108_2);
        const Space v108_4 = (has_head(v108_3) ? constant_2 : Space{});
        const Space v108_5 = subtract(constant_0,v108_4);
        Space v108_7;
        if (!v108_5.empty()) {
          const Space v109_6 = routine_6(c, v107_7_head, v107_7_tail);
          v108_7 = compose(v108_5,v109_6);
        }
        const Space v108_8 = intersect(constant_1,v108_2);
        const Space v108_9 = (has_head(v108_8) ? constant_2 : Space{});
        Space v108_11;
        if (!v108_9.empty()) {
          const Space v110_10 = routine_7(c, v107_7_head, v107_7_tail);
          v108_11 = compose(v108_9,v110_10);
        }
        const Space v108_12 = unite(v108_7,v108_11);
        v107_7_result = unite(v107_7_result,v108_12);
      }
      const Space v107_7 = std::move(v107_7_result);
      const Space v107_8 = restrict_to(constant_4,v107_7);
      Space v107_9_result;
      for (int v107_9_label = 1; v107_9_label <= 2; ++v107_9_label) {
        const Space v107_9_tail = child(v107_8,v107_9_label);
        if (v107_9_tail.empty()) continue;
        const Path v107_9_head{v107_9_label};
        const Space v111_2 = singleton(v107_9_head);
        const Space v111_3 = intersect(constant_1,v111_2);
        const Space v111_4 = (has_head(v111_3) ? constant_2 : Space{});
        const Space v111_5 = subtract(constant_0,v111_4);
        Space v111_7;
        if (!v111_5.empty()) {
          const Space v112_6 = routine_8(c, v107_9_head, v107_9_tail);
          v111_7 = compose(v111_5,v112_6);
        }
        const Space v111_8 = intersect(constant_1,v111_2);
        const Space v111_9 = (has_head(v111_8) ? constant_2 : Space{});
        Space v111_11;
        if (!v111_9.empty()) {
          const Space v113_10 = routine_9(c, v107_9_head, v107_9_tail);
          v111_11 = compose(v111_9,v113_10);
        }
        const Space v111_12 = unite(v111_7,v111_11);
        v107_9_result = unite(v107_9_result,v111_12);
      }
      const Space v107_9 = std::move(v107_9_result);
      const Space v107_10 = unwrap(v105_8,v105_16_head);
      const Space v107_11 = subtract(v107_9,v107_10);
      const Space v107_12 = intersect(v107_11,constant_6);
      v106_13 = compose(v106_4,v107_12);
    }
    const Path v106_14 = concat_path(p0,v105_16_head);
    const Space v106_15 = wrap(v106_13,v106_14);
    v105_16_result = unite(v105_16_result,v106_15);
  }
  const Space v105_16 = std::move(v105_16_result);
  return v105_16;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v114_11_result;
  for (int v114_11_label = 1; v114_11_label <= 2; ++v114_11_label) {
    const Space v114_11_tail = child(s0,v114_11_label);
    if (v114_11_tail.empty()) continue;
    const Path v114_11_head{v114_11_label};
    const Space v115_2 = singleton(v114_11_head);
    const Space v115_3 = intersect(constant_1,v115_2);
    const Space v115_4 = (has_head(v115_3) ? constant_2 : Space{});
    const Space v115_5 = subtract(constant_0,v115_4);
    Space v115_8;
    if (!v115_5.empty()) {
      const Path v116_6 = concat_path(p0,v114_11_head);
      Space v116_7_result;
      for (int v116_7_label = 1; v116_7_label <= 2; ++v116_7_label) {
        const Space v116_7_tail = child(v114_11_tail,v116_7_label);
        if (v116_7_tail.empty()) continue;
        const Path v116_7_head{v116_7_label};
        const Space v117_2 = singleton(v116_7_head);
        const Space v117_3 = intersect(constant_1,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_2 : Space{});
        const Space v117_5 = subtract(constant_0,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v116_6,v116_7_head);
          const Space v118_7 = routine_22(c, v118_6, v116_7_tail);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_1,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_2 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v116_6,v116_7_head);
          const Space v119_11 = routine_23(c, v119_6, v116_7_tail);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_7_result = unite(v116_7_result,v117_13);
      }
      const Space v116_7 = std::move(v116_7_result);
      v115_8 = compose(v115_5,v116_7);
    }
    const Space v115_9 = intersect(constant_1,v115_2);
    const Space v115_10 = (has_head(v115_9) ? constant_2 : Space{});
    Space v115_12;
    if (!v115_10.empty()) {
      const Path v120_6 = concat_path(p0,v114_11_head);
      Space v120_11_result;
      for (int v120_11_label = 1; v120_11_label <= 2; ++v120_11_label) {
        const Space v120_11_tail = child(v114_11_tail,v120_11_label);
        if (v120_11_tail.empty()) continue;
        const Path v120_11_head{v120_11_label};
        const Space v121_2 = singleton(v120_11_head);
        const Space v121_3 = intersect(constant_1,v121_2);
        const Space v121_4 = (has_head(v121_3) ? constant_2 : Space{});
        const Space v121_5 = subtract(constant_0,v121_4);
        Space v121_8;
        if (!v121_5.empty()) {
          const Path v122_6 = concat_path(v120_6,v120_11_head);
          const Space v122_7 = routine_22(c, v122_6, v120_11_tail);
          v121_8 = compose(v121_5,v122_7);
        }
        const Space v121_9 = intersect(constant_1,v121_2);
        const Space v121_10 = (has_head(v121_9) ? constant_2 : Space{});
        Space v121_12;
        if (!v121_10.empty()) {
          const Path v123_6 = concat_path(v120_6,v120_11_head);
          const Space v123_11 = routine_14(c, v123_6, v120_11_tail);
          v121_12 = compose(v121_10,v123_11);
        }
        const Space v121_13 = unite(v121_8,v121_12);
        v120_11_result = unite(v120_11_result,v121_13);
      }
      const Space v120_11 = std::move(v120_11_result);
      v115_12 = compose(v115_10,v120_11);
    }
    const Space v115_13 = unite(v115_8,v115_12);
    v114_11_result = unite(v114_11_result,v115_13);
  }
  const Space v114_11 = std::move(v114_11_result);
  return v114_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v124_8_result;
  for (int v124_8_label = 1; v124_8_label <= 2; ++v124_8_label) {
    const Space v124_8_tail = child(s0,v124_8_label);
    if (v124_8_tail.empty()) continue;
    const Path v124_8_head{v124_8_label};
    const Space v125_2 = singleton(v124_8_head);
    const Space v125_3 = intersect(constant_1,v125_2);
    const Space v125_4 = (has_head(v125_3) ? constant_2 : Space{});
    const Space v125_5 = subtract(constant_0,v125_4);
    Space v125_8;
    if (!v125_5.empty()) {
      const Path v126_6 = concat_path(p0,v124_8_head);
      Space v126_7_result;
      for (int v126_7_label = 1; v126_7_label <= 2; ++v126_7_label) {
        const Space v126_7_tail = child(v124_8_tail,v126_7_label);
        if (v126_7_tail.empty()) continue;
        const Path v126_7_head{v126_7_label};
        const Space v127_2 = singleton(v126_7_head);
        const Space v127_3 = intersect(constant_1,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_2 : Space{});
        const Space v127_5 = subtract(constant_0,v127_4);
        Space v127_8;
        if (!v127_5.empty()) {
          const Path v128_6 = concat_path(v126_6,v126_7_head);
          const Space v128_7 = routine_22(c, v128_6, v126_7_tail);
          v127_8 = compose(v127_5,v128_7);
        }
        const Space v127_9 = intersect(constant_1,v127_2);
        const Space v127_10 = (has_head(v127_9) ? constant_2 : Space{});
        Space v127_12;
        if (!v127_10.empty()) {
          const Path v129_6 = concat_path(v126_6,v126_7_head);
          const Space v129_11 = routine_23(c, v129_6, v126_7_tail);
          v127_12 = compose(v127_10,v129_11);
        }
        const Space v127_13 = unite(v127_8,v127_12);
        v126_7_result = unite(v126_7_result,v127_13);
      }
      const Space v126_7 = std::move(v126_7_result);
      v125_8 = compose(v125_5,v126_7);
    }
    const Space v125_9 = intersect(constant_1,v125_2);
    const Space v125_10 = (has_head(v125_9) ? constant_2 : Space{});
    const Space v125_11 = compose(v125_10,v124_8_tail);
    const Space v125_12 = unite(v125_8,v125_11);
    v124_8_result = unite(v124_8_result,v125_12);
  }
  const Space v124_8 = std::move(v124_8_result);
  return v124_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v131_11_result;
  for (int v131_11_label = 1; v131_11_label <= 2; ++v131_11_label) {
    const Space v131_11_tail = child(s0,v131_11_label);
    if (v131_11_tail.empty()) continue;
    const Path v131_11_head{v131_11_label};
    const Space v132_2 = singleton(v131_11_head);
    const Space v132_3 = intersect(constant_1,v132_2);
    const Space v132_4 = (has_head(v132_3) ? constant_2 : Space{});
    const Space v132_5 = subtract(constant_0,v132_4);
    Space v132_8;
    if (!v132_5.empty()) {
      const Path v133_6 = concat_path(p0,v131_11_head);
      Space v133_7_result;
      for (int v133_7_label = 1; v133_7_label <= 2; ++v133_7_label) {
        const Space v133_7_tail = child(v131_11_tail,v133_7_label);
        if (v133_7_tail.empty()) continue;
        const Path v133_7_head{v133_7_label};
        const Space v134_2 = singleton(v133_7_head);
        const Space v134_3 = intersect(constant_1,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_2 : Space{});
        const Space v134_5 = subtract(constant_0,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v133_6,v133_7_head);
          const Space v135_7 = routine_24(c, v135_6, v133_7_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_1,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_2 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v133_6,v133_7_head);
          const Space v136_11 = routine_25(c, v136_6, v133_7_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_7_result = unite(v133_7_result,v134_13);
      }
      const Space v133_7 = std::move(v133_7_result);
      v132_8 = compose(v132_5,v133_7);
    }
    const Space v132_9 = intersect(constant_1,v132_2);
    const Space v132_10 = (has_head(v132_9) ? constant_2 : Space{});
    Space v132_12;
    if (!v132_10.empty()) {
      const Path v137_6 = concat_path(p0,v131_11_head);
      Space v137_11_result;
      for (int v137_11_label = 1; v137_11_label <= 2; ++v137_11_label) {
        const Space v137_11_tail = child(v131_11_tail,v137_11_label);
        if (v137_11_tail.empty()) continue;
        const Path v137_11_head{v137_11_label};
        const Space v138_2 = singleton(v137_11_head);
        const Space v138_3 = intersect(constant_1,v138_2);
        const Space v138_4 = (has_head(v138_3) ? constant_2 : Space{});
        const Space v138_5 = subtract(constant_0,v138_4);
        Space v138_8;
        if (!v138_5.empty()) {
          const Path v139_6 = concat_path(v137_6,v137_11_head);
          const Space v139_7 = routine_24(c, v139_6, v137_11_tail);
          v138_8 = compose(v138_5,v139_7);
        }
        const Space v138_9 = intersect(constant_1,v138_2);
        const Space v138_10 = (has_head(v138_9) ? constant_2 : Space{});
        Space v138_12;
        if (!v138_10.empty()) {
          const Path v140_6 = concat_path(v137_6,v137_11_head);
          const Space v140_11 = routine_17(c, v140_6, v137_11_tail);
          v138_12 = compose(v138_10,v140_11);
        }
        const Space v138_13 = unite(v138_8,v138_12);
        v137_11_result = unite(v137_11_result,v138_13);
      }
      const Space v137_11 = std::move(v137_11_result);
      v132_12 = compose(v132_10,v137_11);
    }
    const Space v132_13 = unite(v132_8,v132_12);
    v131_11_result = unite(v131_11_result,v132_13);
  }
  const Space v131_11 = std::move(v131_11_result);
  return v131_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v141_8_result;
  for (int v141_8_label = 1; v141_8_label <= 2; ++v141_8_label) {
    const Space v141_8_tail = child(s0,v141_8_label);
    if (v141_8_tail.empty()) continue;
    const Path v141_8_head{v141_8_label};
    const Space v142_2 = singleton(v141_8_head);
    const Space v142_3 = intersect(constant_1,v142_2);
    const Space v142_4 = (has_head(v142_3) ? constant_2 : Space{});
    const Space v142_5 = subtract(constant_0,v142_4);
    Space v142_8;
    if (!v142_5.empty()) {
      const Path v143_6 = concat_path(p0,v141_8_head);
      Space v143_7_result;
      for (int v143_7_label = 1; v143_7_label <= 2; ++v143_7_label) {
        const Space v143_7_tail = child(v141_8_tail,v143_7_label);
        if (v143_7_tail.empty()) continue;
        const Path v143_7_head{v143_7_label};
        const Space v144_2 = singleton(v143_7_head);
        const Space v144_3 = intersect(constant_1,v144_2);
        const Space v144_4 = (has_head(v144_3) ? constant_2 : Space{});
        const Space v144_5 = subtract(constant_0,v144_4);
        Space v144_8;
        if (!v144_5.empty()) {
          const Path v145_6 = concat_path(v143_6,v143_7_head);
          const Space v145_7 = routine_24(c, v145_6, v143_7_tail);
          v144_8 = compose(v144_5,v145_7);
        }
        const Space v144_9 = intersect(constant_1,v144_2);
        const Space v144_10 = (has_head(v144_9) ? constant_2 : Space{});
        Space v144_12;
        if (!v144_10.empty()) {
          const Path v146_6 = concat_path(v143_6,v143_7_head);
          const Space v146_11 = routine_25(c, v146_6, v143_7_tail);
          v144_12 = compose(v144_10,v146_11);
        }
        const Space v144_13 = unite(v144_8,v144_12);
        v143_7_result = unite(v143_7_result,v144_13);
      }
      const Space v143_7 = std::move(v143_7_result);
      v142_8 = compose(v142_5,v143_7);
    }
    const Space v142_9 = intersect(constant_1,v142_2);
    const Space v142_10 = (has_head(v142_9) ? constant_2 : Space{});
    const Space v142_11 = compose(v142_10,v141_8_tail);
    const Space v142_12 = unite(v142_8,v142_11);
    v141_8_result = unite(v141_8_result,v142_12);
  }
  const Space v141_8 = std::move(v141_8_result);
  return v141_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v148_11_result;
  for (int v148_11_label = 1; v148_11_label <= 2; ++v148_11_label) {
    const Space v148_11_tail = child(s0,v148_11_label);
    if (v148_11_tail.empty()) continue;
    const Path v148_11_head{v148_11_label};
    const Space v149_2 = singleton(v148_11_head);
    const Space v149_3 = intersect(constant_1,v149_2);
    const Space v149_4 = (has_head(v149_3) ? constant_2 : Space{});
    const Space v149_5 = subtract(constant_0,v149_4);
    Space v149_8;
    if (!v149_5.empty()) {
      const Path v150_6 = concat_path(p0,v148_11_head);
      Space v150_7_result;
      for (int v150_7_label = 1; v150_7_label <= 2; ++v150_7_label) {
        const Space v150_7_tail = child(v148_11_tail,v150_7_label);
        if (v150_7_tail.empty()) continue;
        const Path v150_7_head{v150_7_label};
        const Space v151_2 = singleton(v150_7_head);
        const Space v151_3 = intersect(constant_1,v151_2);
        const Space v151_4 = (has_head(v151_3) ? constant_2 : Space{});
        const Space v151_5 = subtract(constant_0,v151_4);
        Space v151_8;
        if (!v151_5.empty()) {
          const Path v152_6 = concat_path(v150_6,v150_7_head);
          const Space v152_7 = routine_26(c, v152_6, v150_7_tail);
          v151_8 = compose(v151_5,v152_7);
        }
        const Space v151_9 = intersect(constant_1,v151_2);
        const Space v151_10 = (has_head(v151_9) ? constant_2 : Space{});
        Space v151_12;
        if (!v151_10.empty()) {
          const Path v153_6 = concat_path(v150_6,v150_7_head);
          const Space v153_11 = routine_27(c, v153_6, v150_7_tail);
          v151_12 = compose(v151_10,v153_11);
        }
        const Space v151_13 = unite(v151_8,v151_12);
        v150_7_result = unite(v150_7_result,v151_13);
      }
      const Space v150_7 = std::move(v150_7_result);
      v149_8 = compose(v149_5,v150_7);
    }
    const Space v149_9 = intersect(constant_1,v149_2);
    const Space v149_10 = (has_head(v149_9) ? constant_2 : Space{});
    Space v149_12;
    if (!v149_10.empty()) {
      const Path v154_6 = concat_path(p0,v148_11_head);
      Space v154_11_result;
      for (int v154_11_label = 1; v154_11_label <= 2; ++v154_11_label) {
        const Space v154_11_tail = child(v148_11_tail,v154_11_label);
        if (v154_11_tail.empty()) continue;
        const Path v154_11_head{v154_11_label};
        const Space v155_2 = singleton(v154_11_head);
        const Space v155_3 = intersect(constant_1,v155_2);
        const Space v155_4 = (has_head(v155_3) ? constant_2 : Space{});
        const Space v155_5 = subtract(constant_0,v155_4);
        Space v155_8;
        if (!v155_5.empty()) {
          const Path v156_6 = concat_path(v154_6,v154_11_head);
          const Space v156_7 = routine_26(c, v156_6, v154_11_tail);
          v155_8 = compose(v155_5,v156_7);
        }
        const Space v155_9 = intersect(constant_1,v155_2);
        const Space v155_10 = (has_head(v155_9) ? constant_2 : Space{});
        Space v155_12;
        if (!v155_10.empty()) {
          const Path v157_6 = concat_path(v154_6,v154_11_head);
          const Space v157_11 = routine_14(c, v157_6, v154_11_tail);
          v155_12 = compose(v155_10,v157_11);
        }
        const Space v155_13 = unite(v155_8,v155_12);
        v154_11_result = unite(v154_11_result,v155_13);
      }
      const Space v154_11 = std::move(v154_11_result);
      v149_12 = compose(v149_10,v154_11);
    }
    const Space v149_13 = unite(v149_8,v149_12);
    v148_11_result = unite(v148_11_result,v149_13);
  }
  const Space v148_11 = std::move(v148_11_result);
  return v148_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v158_8_result;
  for (int v158_8_label = 1; v158_8_label <= 2; ++v158_8_label) {
    const Space v158_8_tail = child(s0,v158_8_label);
    if (v158_8_tail.empty()) continue;
    const Path v158_8_head{v158_8_label};
    const Space v159_2 = singleton(v158_8_head);
    const Space v159_3 = intersect(constant_1,v159_2);
    const Space v159_4 = (has_head(v159_3) ? constant_2 : Space{});
    const Space v159_5 = subtract(constant_0,v159_4);
    Space v159_8;
    if (!v159_5.empty()) {
      const Path v160_6 = concat_path(p0,v158_8_head);
      Space v160_7_result;
      for (int v160_7_label = 1; v160_7_label <= 2; ++v160_7_label) {
        const Space v160_7_tail = child(v158_8_tail,v160_7_label);
        if (v160_7_tail.empty()) continue;
        const Path v160_7_head{v160_7_label};
        const Space v161_2 = singleton(v160_7_head);
        const Space v161_3 = intersect(constant_1,v161_2);
        const Space v161_4 = (has_head(v161_3) ? constant_2 : Space{});
        const Space v161_5 = subtract(constant_0,v161_4);
        Space v161_8;
        if (!v161_5.empty()) {
          const Path v162_6 = concat_path(v160_6,v160_7_head);
          const Space v162_7 = routine_26(c, v162_6, v160_7_tail);
          v161_8 = compose(v161_5,v162_7);
        }
        const Space v161_9 = intersect(constant_1,v161_2);
        const Space v161_10 = (has_head(v161_9) ? constant_2 : Space{});
        Space v161_12;
        if (!v161_10.empty()) {
          const Path v163_6 = concat_path(v160_6,v160_7_head);
          const Space v163_11 = routine_27(c, v163_6, v160_7_tail);
          v161_12 = compose(v161_10,v163_11);
        }
        const Space v161_13 = unite(v161_8,v161_12);
        v160_7_result = unite(v160_7_result,v161_13);
      }
      const Space v160_7 = std::move(v160_7_result);
      v159_8 = compose(v159_5,v160_7);
    }
    const Space v159_9 = intersect(constant_1,v159_2);
    const Space v159_10 = (has_head(v159_9) ? constant_2 : Space{});
    const Space v159_11 = compose(v159_10,v158_8_tail);
    const Space v159_12 = unite(v159_8,v159_11);
    v158_8_result = unite(v158_8_result,v159_12);
  }
  const Space v158_8 = std::move(v158_8_result);
  return v158_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v164_11_result;
  for (int v164_11_label = 1; v164_11_label <= 2; ++v164_11_label) {
    const Space v164_11_tail = child(s0,v164_11_label);
    if (v164_11_tail.empty()) continue;
    const Path v164_11_head{v164_11_label};
    const Space v165_2 = singleton(v164_11_head);
    const Space v165_3 = intersect(constant_1,v165_2);
    const Space v165_4 = (has_head(v165_3) ? constant_2 : Space{});
    const Space v165_5 = subtract(constant_0,v165_4);
    Space v165_8;
    if (!v165_5.empty()) {
      const Path v166_6 = concat_path(p0,v164_11_head);
      Space v166_7_result;
      for (int v166_7_label = 1; v166_7_label <= 2; ++v166_7_label) {
        const Space v166_7_tail = child(v164_11_tail,v166_7_label);
        if (v166_7_tail.empty()) continue;
        const Path v166_7_head{v166_7_label};
        const Space v167_2 = singleton(v166_7_head);
        const Space v167_3 = intersect(constant_1,v167_2);
        const Space v167_4 = (has_head(v167_3) ? constant_2 : Space{});
        const Space v167_5 = subtract(constant_0,v167_4);
        Space v167_8;
        if (!v167_5.empty()) {
          const Path v168_6 = concat_path(v166_6,v166_7_head);
          const Space v168_7 = routine_28(c, v168_6, v166_7_tail);
          v167_8 = compose(v167_5,v168_7);
        }
        const Space v167_9 = intersect(constant_1,v167_2);
        const Space v167_10 = (has_head(v167_9) ? constant_2 : Space{});
        Space v167_12;
        if (!v167_10.empty()) {
          const Path v169_6 = concat_path(v166_6,v166_7_head);
          const Space v169_11 = routine_29(c, v169_6, v166_7_tail);
          v167_12 = compose(v167_10,v169_11);
        }
        const Space v167_13 = unite(v167_8,v167_12);
        v166_7_result = unite(v166_7_result,v167_13);
      }
      const Space v166_7 = std::move(v166_7_result);
      v165_8 = compose(v165_5,v166_7);
    }
    const Space v165_9 = intersect(constant_1,v165_2);
    const Space v165_10 = (has_head(v165_9) ? constant_2 : Space{});
    Space v165_12;
    if (!v165_10.empty()) {
      const Path v170_6 = concat_path(p0,v164_11_head);
      Space v170_11_result;
      for (int v170_11_label = 1; v170_11_label <= 2; ++v170_11_label) {
        const Space v170_11_tail = child(v164_11_tail,v170_11_label);
        if (v170_11_tail.empty()) continue;
        const Path v170_11_head{v170_11_label};
        const Space v171_2 = singleton(v170_11_head);
        const Space v171_3 = intersect(constant_1,v171_2);
        const Space v171_4 = (has_head(v171_3) ? constant_2 : Space{});
        const Space v171_5 = subtract(constant_0,v171_4);
        Space v171_8;
        if (!v171_5.empty()) {
          const Path v172_6 = concat_path(v170_6,v170_11_head);
          const Space v172_7 = routine_28(c, v172_6, v170_11_tail);
          v171_8 = compose(v171_5,v172_7);
        }
        const Space v171_9 = intersect(constant_1,v171_2);
        const Space v171_10 = (has_head(v171_9) ? constant_2 : Space{});
        Space v171_12;
        if (!v171_10.empty()) {
          const Path v173_6 = concat_path(v170_6,v170_11_head);
          const Space v173_11 = routine_17(c, v173_6, v170_11_tail);
          v171_12 = compose(v171_10,v173_11);
        }
        const Space v171_13 = unite(v171_8,v171_12);
        v170_11_result = unite(v170_11_result,v171_13);
      }
      const Space v170_11 = std::move(v170_11_result);
      v165_12 = compose(v165_10,v170_11);
    }
    const Space v165_13 = unite(v165_8,v165_12);
    v164_11_result = unite(v164_11_result,v165_13);
  }
  const Space v164_11 = std::move(v164_11_result);
  return v164_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v174_8_result;
  for (int v174_8_label = 1; v174_8_label <= 2; ++v174_8_label) {
    const Space v174_8_tail = child(s0,v174_8_label);
    if (v174_8_tail.empty()) continue;
    const Path v174_8_head{v174_8_label};
    const Space v175_2 = singleton(v174_8_head);
    const Space v175_3 = intersect(constant_1,v175_2);
    const Space v175_4 = (has_head(v175_3) ? constant_2 : Space{});
    const Space v175_5 = subtract(constant_0,v175_4);
    Space v175_8;
    if (!v175_5.empty()) {
      const Path v176_6 = concat_path(p0,v174_8_head);
      Space v176_7_result;
      for (int v176_7_label = 1; v176_7_label <= 2; ++v176_7_label) {
        const Space v176_7_tail = child(v174_8_tail,v176_7_label);
        if (v176_7_tail.empty()) continue;
        const Path v176_7_head{v176_7_label};
        const Space v177_2 = singleton(v176_7_head);
        const Space v177_3 = intersect(constant_1,v177_2);
        const Space v177_4 = (has_head(v177_3) ? constant_2 : Space{});
        const Space v177_5 = subtract(constant_0,v177_4);
        Space v177_8;
        if (!v177_5.empty()) {
          const Path v178_6 = concat_path(v176_6,v176_7_head);
          const Space v178_7 = routine_28(c, v178_6, v176_7_tail);
          v177_8 = compose(v177_5,v178_7);
        }
        const Space v177_9 = intersect(constant_1,v177_2);
        const Space v177_10 = (has_head(v177_9) ? constant_2 : Space{});
        Space v177_12;
        if (!v177_10.empty()) {
          const Path v179_6 = concat_path(v176_6,v176_7_head);
          const Space v179_11 = routine_29(c, v179_6, v176_7_tail);
          v177_12 = compose(v177_10,v179_11);
        }
        const Space v177_13 = unite(v177_8,v177_12);
        v176_7_result = unite(v176_7_result,v177_13);
      }
      const Space v176_7 = std::move(v176_7_result);
      v175_8 = compose(v175_5,v176_7);
    }
    const Space v175_9 = intersect(constant_1,v175_2);
    const Space v175_10 = (has_head(v175_9) ? constant_2 : Space{});
    const Space v175_11 = compose(v175_10,v174_8_tail);
    const Space v175_12 = unite(v175_8,v175_11);
    v174_8_result = unite(v174_8_result,v175_12);
  }
  const Space v174_8 = std::move(v174_8_result);
  return v174_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  Space v180_6_result;
  for (int v180_6_label = 1; v180_6_label <= 2; ++v180_6_label) {
    const Space v180_6_tail = child(s0,v180_6_label);
    if (v180_6_tail.empty()) continue;
    const Path v180_6_head{v180_6_label};
    const Space v181_2 = singleton(v180_6_head);
    const Space v181_3 = intersect(constant_1,v181_2);
    const Space v181_4 = (has_head(v181_3) ? constant_2 : Space{});
    const Space v181_5 = subtract(constant_0,v181_4);
    Space v181_6_result;
    for (int v181_6_label = 1; v181_6_label <= 2; ++v181_6_label) {
      const Space v181_6_tail = child(v180_6_tail,v181_6_label);
      if (v181_6_tail.empty()) continue;
      const Path v181_6_head{v181_6_label};
      const Space v182_2 = Space{};
      v181_6_result = unite(v181_6_result,v182_2);
    }
    const Space v181_6 = std::move(v181_6_result);
    const Space v181_7 = compose(v181_5,v181_6);
    const Space v181_8 = intersect(constant_1,v181_2);
    const Space v181_9 = (has_head(v181_8) ? constant_2 : Space{});
    Space v181_12;
    if (!v181_9.empty()) {
      const Path v183_10 = concat_path(p0,v180_6_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v180_6_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_1,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_2 : Space{});
        Space v184_7;
        if (!v184_4.empty()) {
          const Path v185_5 = concat_path(v183_10,v183_11_head);
          const Space v185_6 = routine_14(c, v185_5, v183_11_tail);
          v184_7 = compose(v184_4,v185_6);
        }
        v183_11_result = unite(v183_11_result,v184_7);
      }
      const Space v183_11 = std::move(v183_11_result);
      v181_12 = compose(v181_9,v183_11);
    }
    const Space v181_13 = unite(v181_7,v181_12);
    v180_6_result = unite(v180_6_result,v181_13);
  }
  const Space v180_6 = std::move(v180_6_result);
  return v180_6;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  Space v186_5_result;
  for (int v186_5_label = 1; v186_5_label <= 2; ++v186_5_label) {
    const Space v186_5_tail = child(s0,v186_5_label);
    if (v186_5_tail.empty()) continue;
    const Path v186_5_head{v186_5_label};
    const Space v187_2 = singleton(v186_5_head);
    const Space v187_3 = intersect(constant_1,v187_2);
    const Space v187_4 = (has_head(v187_3) ? constant_2 : Space{});
    const Space v187_5 = subtract(constant_0,v187_4);
    Space v187_6_result;
    for (int v187_6_label = 1; v187_6_label <= 2; ++v187_6_label) {
      const Space v187_6_tail = child(v186_5_tail,v187_6_label);
      if (v187_6_tail.empty()) continue;
      const Path v187_6_head{v187_6_label};
      const Space v188_2 = Space{};
      v187_6_result = unite(v187_6_result,v188_2);
    }
    const Space v187_6 = std::move(v187_6_result);
    const Space v187_7 = compose(v187_5,v187_6);
    const Space v187_8 = intersect(constant_1,v187_2);
    const Space v187_9 = (has_head(v187_8) ? constant_2 : Space{});
    const Space v187_10 = compose(v187_9,v186_5_tail);
    const Space v187_11 = unite(v187_7,v187_10);
    v186_5_result = unite(v186_5_result,v187_11);
  }
  const Space v186_5 = std::move(v186_5_result);
  return v186_5;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v189_6_result;
  for (int v189_6_label = 1; v189_6_label <= 2; ++v189_6_label) {
    const Space v189_6_tail = child(s0,v189_6_label);
    if (v189_6_tail.empty()) continue;
    const Path v189_6_head{v189_6_label};
    const Space v190_2 = singleton(v189_6_head);
    const Space v190_3 = intersect(constant_1,v190_2);
    const Space v190_4 = (has_head(v190_3) ? constant_2 : Space{});
    const Space v190_5 = subtract(constant_0,v190_4);
    Space v190_6_result;
    for (int v190_6_label = 1; v190_6_label <= 2; ++v190_6_label) {
      const Space v190_6_tail = child(v189_6_tail,v190_6_label);
      if (v190_6_tail.empty()) continue;
      const Path v190_6_head{v190_6_label};
      const Space v191_2 = Space{};
      v190_6_result = unite(v190_6_result,v191_2);
    }
    const Space v190_6 = std::move(v190_6_result);
    const Space v190_7 = compose(v190_5,v190_6);
    const Space v190_8 = intersect(constant_1,v190_2);
    const Space v190_9 = (has_head(v190_8) ? constant_2 : Space{});
    Space v190_12;
    if (!v190_9.empty()) {
      const Path v192_10 = concat_path(p0,v189_6_head);
      Space v192_11_result;
      for (int v192_11_label = 1; v192_11_label <= 2; ++v192_11_label) {
        const Space v192_11_tail = child(v189_6_tail,v192_11_label);
        if (v192_11_tail.empty()) continue;
        const Path v192_11_head{v192_11_label};
        const Space v193_2 = singleton(v192_11_head);
        const Space v193_3 = intersect(constant_1,v193_2);
        const Space v193_4 = (has_head(v193_3) ? constant_2 : Space{});
        Space v193_7;
        if (!v193_4.empty()) {
          const Path v194_5 = concat_path(v192_10,v192_11_head);
          const Space v194_6 = routine_17(c, v194_5, v192_11_tail);
          v193_7 = compose(v193_4,v194_6);
        }
        v192_11_result = unite(v192_11_result,v193_7);
      }
      const Space v192_11 = std::move(v192_11_result);
      v190_12 = compose(v190_9,v192_11);
    }
    const Space v190_13 = unite(v190_7,v190_12);
    v189_6_result = unite(v189_6_result,v190_13);
  }
  const Space v189_6 = std::move(v189_6_result);
  return v189_6;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v195_5_result;
  for (int v195_5_label = 1; v195_5_label <= 2; ++v195_5_label) {
    const Space v195_5_tail = child(s0,v195_5_label);
    if (v195_5_tail.empty()) continue;
    const Path v195_5_head{v195_5_label};
    const Space v196_2 = singleton(v195_5_head);
    const Space v196_3 = intersect(constant_1,v196_2);
    const Space v196_4 = (has_head(v196_3) ? constant_2 : Space{});
    const Space v196_5 = subtract(constant_0,v196_4);
    Space v196_6_result;
    for (int v196_6_label = 1; v196_6_label <= 2; ++v196_6_label) {
      const Space v196_6_tail = child(v195_5_tail,v196_6_label);
      if (v196_6_tail.empty()) continue;
      const Path v196_6_head{v196_6_label};
      const Space v197_2 = Space{};
      v196_6_result = unite(v196_6_result,v197_2);
    }
    const Space v196_6 = std::move(v196_6_result);
    const Space v196_7 = compose(v196_5,v196_6);
    const Space v196_8 = intersect(constant_1,v196_2);
    const Space v196_9 = (has_head(v196_8) ? constant_2 : Space{});
    const Space v196_10 = compose(v196_9,v195_5_tail);
    const Space v196_11 = unite(v196_7,v196_10);
    v195_5_result = unite(v195_5_result,v196_11);
  }
  const Space v195_5 = std::move(v195_5_result);
  return v195_5;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v198_2_result;
  for (int v198_2_label = 1; v198_2_label <= 2; ++v198_2_label) {
    const Space v198_2_tail = child(s0,v198_2_label);
    if (v198_2_tail.empty()) continue;
    const Path v198_2_head{v198_2_label};
    const Space v199_2 = Space{};
    v198_2_result = unite(v198_2_result,v199_2);
  }
  const Space v198_2 = std::move(v198_2_result);
  return v198_2;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v200_3_result;
  for (int v200_3_label = 1; v200_3_label <= 2; ++v200_3_label) {
    const Space v200_3_tail = child(s0,v200_3_label);
    if (v200_3_tail.empty()) continue;
    const Path v200_3_head{v200_3_label};
    const Space v201_2 = singleton(v200_3_head);
    const Space v201_3 = intersect(constant_1,v201_2);
    const Space v201_4 = (has_head(v201_3) ? constant_2 : Space{});
    const Space v201_5 = compose(v201_4,v200_3_tail);
    v200_3_result = unite(v200_3_result,v201_5);
  }
  const Space v200_3 = std::move(v200_3_result);
  return v200_3;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v202_2_result;
  for (int v202_2_label = 1; v202_2_label <= 2; ++v202_2_label) {
    const Space v202_2_tail = child(s0,v202_2_label);
    if (v202_2_tail.empty()) continue;
    const Path v202_2_head{v202_2_label};
    const Space v203_2 = Space{};
    v202_2_result = unite(v202_2_result,v203_2);
  }
  const Space v202_2 = std::move(v202_2_result);
  return v202_2;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v204_3_result;
  for (int v204_3_label = 1; v204_3_label <= 2; ++v204_3_label) {
    const Space v204_3_tail = child(s0,v204_3_label);
    if (v204_3_tail.empty()) continue;
    const Path v204_3_head{v204_3_label};
    const Space v205_2 = singleton(v204_3_head);
    const Space v205_3 = intersect(constant_1,v205_2);
    const Space v205_4 = (has_head(v205_3) ? constant_2 : Space{});
    const Space v205_5 = compose(v205_4,v204_3_tail);
    v204_3_result = unite(v204_3_result,v205_5);
  }
  const Space v204_3 = std::move(v204_3_result);
  return v204_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
