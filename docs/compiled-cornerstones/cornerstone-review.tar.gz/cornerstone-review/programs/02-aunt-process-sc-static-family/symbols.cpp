#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Space n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n7(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { static const Space value=literal_text("6 2 2 3 2 3 5 2 4 5 2 5 6 2 5 8 2 7 8"); return value; }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto p=n15(c,e); return unwrap(n16(c,e),p); }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { static const Space value=literal_text("6 2 2 3 2 3 5 2 4 5 2 5 6 2 5 8 2 7 8"); return value; }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { auto b=n14(c,e); auto a=n17(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return tails_union(n13(c,e)); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { static const Space value=literal_text("6 2 3 2 2 5 3 2 5 4 2 6 5 2 8 5 2 8 7"); return value; }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { auto b=n12(c,e); auto a=n18(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return tails_union(n11(c,e)); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { static const Space value=literal_text("6 2 2 3 2 3 5 2 4 5 2 5 6 2 5 8 2 7 8"); return value; }
static ZIPPY_NOINLINE Space n19(Context& c, const Env& e) { auto p=n20(c,e); return unwrap(n21(c,e),p); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { auto a=n10(c,e); auto b=n19(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { static const Space value=literal_text("4 1 3 1 4 1 6 1 7"); return value; }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { auto a=n9(c,e); auto b=n22(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { auto p=n7(c,e); return wrap(n8(c,e),p); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),0,-1,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n2(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"8 1 4 65 117 110 116 2 3 74 105 109 3 3 80 97 116 4 3 65 110 110 5 3 66 111 98 6 3 80 97 109 7 3 76 105 122 8 3 84 111 109"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
