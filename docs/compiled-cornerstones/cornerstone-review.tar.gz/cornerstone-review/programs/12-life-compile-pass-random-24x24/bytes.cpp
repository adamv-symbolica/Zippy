#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_23(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Path n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Path n23(Context&, const Env&);
static ZIPPY_NOINLINE Path n24(Context&, const Env&);
static ZIPPY_NOINLINE Path n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Path n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Path n37(Context&, const Env&);
static ZIPPY_NOINLINE Path n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Path n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Path n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Path n56(Context&, const Env&);
static ZIPPY_NOINLINE Path n57(Context&, const Env&);
static ZIPPY_NOINLINE Path n58(Context&, const Env&);
static ZIPPY_NOINLINE Path n59(Context&, const Env&);
static ZIPPY_NOINLINE Path n60(Context&, const Env&);
static ZIPPY_NOINLINE Path n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_10(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Space n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Path n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Path n76(Context&, const Env&);
static ZIPPY_NOINLINE Path n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Path n79(Context&, const Env&);
static ZIPPY_NOINLINE Path n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_15(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Space n87(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Path n93(Context&, const Env&);
static ZIPPY_NOINLINE Path n94(Context&, const Env&);
static ZIPPY_NOINLINE Path n95(Context&, const Env&);
static ZIPPY_NOINLINE Path n96(Context&, const Env&);
static ZIPPY_NOINLINE Path n97(Context&, const Env&);
static ZIPPY_NOINLINE Path n98(Context&, const Env&);
static ZIPPY_NOINLINE Path n99(Context&, const Env&);
static ZIPPY_NOINLINE Path n100(Context&, const Env&);
static ZIPPY_NOINLINE Path n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_21(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Space n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Space n110(Context&, const Env&);
static ZIPPY_NOINLINE Space n111(Context&, const Env&);
static ZIPPY_NOINLINE Space n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Path n114(Context&, const Env&);
static ZIPPY_NOINLINE Path n115(Context&, const Env&);
static ZIPPY_NOINLINE Path n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Path n118(Context&, const Env&);
static ZIPPY_NOINLINE Path n119(Context&, const Env&);
static ZIPPY_NOINLINE Path n120(Context&, const Env&);
static ZIPPY_NOINLINE Path n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_22(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Path n127(Context&, const Env&);
static ZIPPY_NOINLINE Space n128(Context&, const Env&);
static ZIPPY_NOINLINE Space n129(Context&, const Env&);
static ZIPPY_NOINLINE Path n130(Context&, const Env&);
static ZIPPY_NOINLINE Space n131(Context&, const Env&);
static ZIPPY_NOINLINE Space n132(Context&, const Env&);
static ZIPPY_NOINLINE Path n133(Context&, const Env&);
static ZIPPY_NOINLINE Path n134(Context&, const Env&);
static ZIPPY_NOINLINE Path n135(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_14(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Space n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Space n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Space n143(Context&, const Env&);
static ZIPPY_NOINLINE Space n144(Context&, const Env&);
static ZIPPY_NOINLINE Path n145(Context&, const Env&);
static ZIPPY_NOINLINE Space n146(Context&, const Env&);
static ZIPPY_NOINLINE Space n147(Context&, const Env&);
static ZIPPY_NOINLINE Path n148(Context&, const Env&);
static ZIPPY_NOINLINE Space n149(Context&, const Env&);
static ZIPPY_NOINLINE Space n150(Context&, const Env&);
static ZIPPY_NOINLINE Path n151(Context&, const Env&);
static ZIPPY_NOINLINE Path n152(Context&, const Env&);
static ZIPPY_NOINLINE Path n153(Context&, const Env&);
static ZIPPY_NOINLINE Space n154(Context&, const Env&);
static ZIPPY_NOINLINE Path n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Space n157(Context&, const Env&);
static ZIPPY_NOINLINE Space n158(Context&, const Env&);
static ZIPPY_NOINLINE Space n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Space n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Path n164(Context&, const Env&);
static ZIPPY_NOINLINE Path n165(Context&, const Env&);
static ZIPPY_NOINLINE Path n166(Context&, const Env&);
static ZIPPY_NOINLINE Path n167(Context&, const Env&);
static ZIPPY_NOINLINE Path n168(Context&, const Env&);
static ZIPPY_NOINLINE Path n169(Context&, const Env&);
static ZIPPY_NOINLINE Path n170(Context&, const Env&);
static ZIPPY_NOINLINE Path n171(Context&, const Env&);
static ZIPPY_NOINLINE Space n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Space n174(Context&, const Env&);
static ZIPPY_NOINLINE Space n175(Context&, const Env&);
static ZIPPY_NOINLINE Space n176(Context&, const Env&);
static ZIPPY_NOINLINE Space n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Path n179(Context&, const Env&);
static ZIPPY_NOINLINE Space n180(Context&, const Env&);
static ZIPPY_NOINLINE Space n181(Context&, const Env&);
static ZIPPY_NOINLINE Path n182(Context&, const Env&);
static ZIPPY_NOINLINE Space n183(Context&, const Env&);
static ZIPPY_NOINLINE Space n184(Context&, const Env&);
static ZIPPY_NOINLINE Path n185(Context&, const Env&);
static ZIPPY_NOINLINE Path n186(Context&, const Env&);
static ZIPPY_NOINLINE Path n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Path n189(Context&, const Env&);
static ZIPPY_NOINLINE Space n190(Context&, const Env&);
static ZIPPY_NOINLINE Space n191(Context&, const Env&);
static ZIPPY_NOINLINE Space n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Space n194(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Space n196(Context&, const Env&);
static ZIPPY_NOINLINE Space n197(Context&, const Env&);
static ZIPPY_NOINLINE Path n198(Context&, const Env&);
static ZIPPY_NOINLINE Path n199(Context&, const Env&);
static ZIPPY_NOINLINE Path n200(Context&, const Env&);
static ZIPPY_NOINLINE Path n201(Context&, const Env&);
static ZIPPY_NOINLINE Path n202(Context&, const Env&);
static ZIPPY_NOINLINE Path n203(Context&, const Env&);
static ZIPPY_NOINLINE Path n204(Context&, const Env&);
static ZIPPY_NOINLINE Path n205(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Space n207(Context&, const Env&);
static ZIPPY_NOINLINE Path n208(Context&, const Env&);
static ZIPPY_NOINLINE Path n209(Context&, const Env&);
static ZIPPY_NOINLINE Path n210(Context&, const Env&);
static ZIPPY_NOINLINE Space n211(Context&, const Env&);
static ZIPPY_NOINLINE Space n212(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Space n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Space n217(Context&, const Env&);
static ZIPPY_NOINLINE Path n218(Context&, const Env&);
static ZIPPY_NOINLINE Path n219(Context&, const Env&);
static ZIPPY_NOINLINE Path n220(Context&, const Env&);
static ZIPPY_NOINLINE Path n221(Context&, const Env&);
static ZIPPY_NOINLINE Path n222(Context&, const Env&);
static ZIPPY_NOINLINE Path n223(Context&, const Env&);
static ZIPPY_NOINLINE Path n224(Context&, const Env&);
static ZIPPY_NOINLINE Path n225(Context&, const Env&);
static ZIPPY_NOINLINE Space n226(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_20(Context&, const Env&);
static ZIPPY_NOINLINE Space n227(Context&, const Env&);
static ZIPPY_NOINLINE Space n228(Context&, const Env&);
static ZIPPY_NOINLINE Space n229(Context&, const Env&);
static ZIPPY_NOINLINE Space n230(Context&, const Env&);
static ZIPPY_NOINLINE Space n231(Context&, const Env&);
static ZIPPY_NOINLINE Space n232(Context&, const Env&);
static ZIPPY_NOINLINE Space n233(Context&, const Env&);
static ZIPPY_NOINLINE Space n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Path n236(Context&, const Env&);
static ZIPPY_NOINLINE Space n237(Context&, const Env&);
static ZIPPY_NOINLINE Space n238(Context&, const Env&);
static ZIPPY_NOINLINE Path n239(Context&, const Env&);
static ZIPPY_NOINLINE Space n240(Context&, const Env&);
static ZIPPY_NOINLINE Space n241(Context&, const Env&);
static ZIPPY_NOINLINE Path n242(Context&, const Env&);
static ZIPPY_NOINLINE Path n243(Context&, const Env&);
static ZIPPY_NOINLINE Path n244(Context&, const Env&);
static ZIPPY_NOINLINE Space n245(Context&, const Env&);
static ZIPPY_NOINLINE Path n246(Context&, const Env&);
static ZIPPY_NOINLINE Space n247(Context&, const Env&);
static ZIPPY_NOINLINE Space n248(Context&, const Env&);
static ZIPPY_NOINLINE Space n249(Context&, const Env&);
static ZIPPY_NOINLINE Space n250(Context&, const Env&);
static ZIPPY_NOINLINE Space n251(Context&, const Env&);
static ZIPPY_NOINLINE Space n252(Context&, const Env&);
static ZIPPY_NOINLINE Space n253(Context&, const Env&);
static ZIPPY_NOINLINE Space n254(Context&, const Env&);
static ZIPPY_NOINLINE Path n255(Context&, const Env&);
static ZIPPY_NOINLINE Path n256(Context&, const Env&);
static ZIPPY_NOINLINE Path n257(Context&, const Env&);
static ZIPPY_NOINLINE Path n258(Context&, const Env&);
static ZIPPY_NOINLINE Path n259(Context&, const Env&);
static ZIPPY_NOINLINE Path n260(Context&, const Env&);
static ZIPPY_NOINLINE Path n261(Context&, const Env&);
static ZIPPY_NOINLINE Path n262(Context&, const Env&);
static ZIPPY_NOINLINE Space n263(Context&, const Env&);
static ZIPPY_NOINLINE Space n264(Context&, const Env&);
static ZIPPY_NOINLINE Space n265(Context&, const Env&);
static ZIPPY_NOINLINE Space n266(Context&, const Env&);
static ZIPPY_NOINLINE Space n267(Context&, const Env&);
static ZIPPY_NOINLINE Space n268(Context&, const Env&);
static ZIPPY_NOINLINE Space n269(Context&, const Env&);
static ZIPPY_NOINLINE Path n270(Context&, const Env&);
static ZIPPY_NOINLINE Space n271(Context&, const Env&);
static ZIPPY_NOINLINE Space n272(Context&, const Env&);
static ZIPPY_NOINLINE Path n273(Context&, const Env&);
static ZIPPY_NOINLINE Space n274(Context&, const Env&);
static ZIPPY_NOINLINE Space n275(Context&, const Env&);
static ZIPPY_NOINLINE Path n276(Context&, const Env&);
static ZIPPY_NOINLINE Path n277(Context&, const Env&);
static ZIPPY_NOINLINE Path n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Path n280(Context&, const Env&);
static ZIPPY_NOINLINE Space n281(Context&, const Env&);
static ZIPPY_NOINLINE Space n282(Context&, const Env&);
static ZIPPY_NOINLINE Space n283(Context&, const Env&);
static ZIPPY_NOINLINE Space n284(Context&, const Env&);
static ZIPPY_NOINLINE Space n285(Context&, const Env&);
static ZIPPY_NOINLINE Space n286(Context&, const Env&);
static ZIPPY_NOINLINE Space n287(Context&, const Env&);
static ZIPPY_NOINLINE Space n288(Context&, const Env&);
static ZIPPY_NOINLINE Path n289(Context&, const Env&);
static ZIPPY_NOINLINE Path n290(Context&, const Env&);
static ZIPPY_NOINLINE Path n291(Context&, const Env&);
static ZIPPY_NOINLINE Path n292(Context&, const Env&);
static ZIPPY_NOINLINE Path n293(Context&, const Env&);
static ZIPPY_NOINLINE Path n294(Context&, const Env&);
static ZIPPY_NOINLINE Path n295(Context&, const Env&);
static ZIPPY_NOINLINE Path n296(Context&, const Env&);
static ZIPPY_NOINLINE Space n297(Context&, const Env&);
static ZIPPY_NOINLINE Space n298(Context&, const Env&);
static ZIPPY_NOINLINE Path n299(Context&, const Env&);
static ZIPPY_NOINLINE Path n300(Context&, const Env&);
static ZIPPY_NOINLINE Path n301(Context&, const Env&);
static ZIPPY_NOINLINE Space n302(Context&, const Env&);
static ZIPPY_NOINLINE Space n303(Context&, const Env&);
static ZIPPY_NOINLINE Space n304(Context&, const Env&);
static ZIPPY_NOINLINE Space n305(Context&, const Env&);
static ZIPPY_NOINLINE Space n306(Context&, const Env&);
static ZIPPY_NOINLINE Space n307(Context&, const Env&);
static ZIPPY_NOINLINE Space n308(Context&, const Env&);
static ZIPPY_NOINLINE Path n309(Context&, const Env&);
static ZIPPY_NOINLINE Path n310(Context&, const Env&);
static ZIPPY_NOINLINE Path n311(Context&, const Env&);
static ZIPPY_NOINLINE Path n312(Context&, const Env&);
static ZIPPY_NOINLINE Path n313(Context&, const Env&);
static ZIPPY_NOINLINE Path n314(Context&, const Env&);
static ZIPPY_NOINLINE Path n315(Context&, const Env&);
static ZIPPY_NOINLINE Path n316(Context&, const Env&);
static ZIPPY_NOINLINE Space n317(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_6(Context&, const Env&);
static ZIPPY_NOINLINE Space n318(Context&, const Env&);
static ZIPPY_NOINLINE Space n319(Context&, const Env&);
static ZIPPY_NOINLINE Space n320(Context&, const Env&);
static ZIPPY_NOINLINE Space n321(Context&, const Env&);
static ZIPPY_NOINLINE Space n322(Context&, const Env&);
static ZIPPY_NOINLINE Space n323(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_11(Context&, const Env&);
static ZIPPY_NOINLINE Space n324(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_7(Context&, const Env&);
static ZIPPY_NOINLINE Space n325(Context&, const Env&);
static ZIPPY_NOINLINE Space n326(Context&, const Env&);
static ZIPPY_NOINLINE Space n327(Context&, const Env&);
static ZIPPY_NOINLINE Space n328(Context&, const Env&);
static ZIPPY_NOINLINE Space n329(Context&, const Env&);
static ZIPPY_NOINLINE Space n330(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_12(Context&, const Env&);
static ZIPPY_NOINLINE Space n331(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_13(Context&, const Env&);
static ZIPPY_NOINLINE Space n332(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_8(Context&, const Env&);
static ZIPPY_NOINLINE Space n333(Context&, const Env&);
static ZIPPY_NOINLINE Space n334(Context&, const Env&);
static ZIPPY_NOINLINE Space n335(Context&, const Env&);
static ZIPPY_NOINLINE Space n336(Context&, const Env&);
static ZIPPY_NOINLINE Space n337(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_16(Context&, const Env&);
static ZIPPY_NOINLINE Space n338(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_18(Context&, const Env&);
static ZIPPY_NOINLINE Space n339(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_19(Context&, const Env&);
static ZIPPY_NOINLINE Space n340(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n341(Context&, const Env&);
static ZIPPY_NOINLINE Space n342(Context&, const Env&);
static ZIPPY_NOINLINE Space n343(Context&, const Env&);
static ZIPPY_NOINLINE Space n344(Context&, const Env&);
static ZIPPY_NOINLINE Space n345(Context&, const Env&);
static ZIPPY_NOINLINE Space n346(Context&, const Env&);
static ZIPPY_NOINLINE Space n347(Context&, const Env&);
static ZIPPY_NOINLINE Space n348(Context&, const Env&);
static ZIPPY_NOINLINE Space n349(Context&, const Env&);
static ZIPPY_NOINLINE Space n350(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n351(Context&, const Env&);
static ZIPPY_NOINLINE Space n352(Context&, const Env&);
static ZIPPY_NOINLINE Space n353(Context&, const Env&);
static ZIPPY_NOINLINE Space n354(Context&, const Env&);
static ZIPPY_NOINLINE Space n355(Context&, const Env&);
static ZIPPY_NOINLINE Space n356(Context&, const Env&);
static ZIPPY_NOINLINE Space n357(Context&, const Env&);
static ZIPPY_NOINLINE Space n358(Context&, const Env&);
static ZIPPY_NOINLINE Space n359(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_3(Context&, const Env&);
static ZIPPY_NOINLINE Space n360(Context&, const Env&);
static ZIPPY_NOINLINE Space n361(Context&, const Env&);
static ZIPPY_NOINLINE Space n362(Context&, const Env&);
static ZIPPY_NOINLINE Space n363(Context&, const Env&);
static ZIPPY_NOINLINE Space n364(Context&, const Env&);
static ZIPPY_NOINLINE Space n365(Context&, const Env&);
static ZIPPY_NOINLINE Space n366(Context&, const Env&);
static ZIPPY_NOINLINE Space n367(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_4(Context&, const Env&);
static ZIPPY_NOINLINE Space n368(Context&, const Env&);
static ZIPPY_NOINLINE Space n369(Context&, const Env&);
static ZIPPY_NOINLINE Space n370(Context&, const Env&);
static ZIPPY_NOINLINE Space n371(Context&, const Env&);
static ZIPPY_NOINLINE Space n372(Context&, const Env&);
static ZIPPY_NOINLINE Space n373(Context&, const Env&);
static ZIPPY_NOINLINE Space n374(Context&, const Env&);
static ZIPPY_NOINLINE Space n375(Context&, const Env&);
static ZIPPY_NOINLINE Space n376(Context&, const Env&);
static ZIPPY_NOINLINE Space n377(Context&, const Env&);
static ZIPPY_NOINLINE Space n378(Context&, const Env&);
static ZIPPY_NOINLINE Space n379(Context&, const Env&);
static ZIPPY_NOINLINE Space n380(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n381(Context&, const Env&);
static ZIPPY_NOINLINE Space n382(Context&, const Env&);
static ZIPPY_NOINLINE Space n383(Context&, const Env&);
static ZIPPY_NOINLINE Space n384(Context&, const Env&);
static ZIPPY_NOINLINE Space n385(Context&, const Env&);
static ZIPPY_NOINLINE Path n386(Context&, const Env&);
static ZIPPY_NOINLINE Space n387(Context&, const Env&);
static ZIPPY_NOINLINE Space n388(Context&, const Env&);
static ZIPPY_NOINLINE Space n389(Context&, const Env&);
static ZIPPY_NOINLINE Space n390(Context&, const Env&);
static ZIPPY_NOINLINE Path n391(Context&, const Env&);
static ZIPPY_NOINLINE Path n392(Context&, const Env&);
static ZIPPY_NOINLINE Path n393(Context&, const Env&);
static ZIPPY_NOINLINE Space n394(Context&, const Env&);
static ZIPPY_NOINLINE Space n395(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_9(Context&, const Env&);
static ZIPPY_NOINLINE Space n396(Context&, const Env&);
static ZIPPY_NOINLINE Path n397(Context&, const Env&);
static ZIPPY_NOINLINE Space n398(Context&, const Env&);
static ZIPPY_NOINLINE Space n399(Context&, const Env&);
static ZIPPY_NOINLINE Path n400(Context&, const Env&);
static ZIPPY_NOINLINE Space n401(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("120 12 1 1 1 1 1 1 1 2 1 1 1 3 12 1 1 1 1 1 1 1 2 1 1 1 4 12 1 1 1 1 1 1 1 3 1 1 1 9 12 1 1 1 1 1 1 1 3 1 1 1 10 12 1 1 1 1 1 1 1 3 1 1 1 11 12 1 1 1 1 1 1 1 3 1 1 1 12 12 1 1 1 1 1 1 1 3 1 1 1 13 12 1 1 1 1 1 1 1 4 1 1 1 4 12 1 1 1 1 1 1 1 4 1 1 1 9 12 1 1 1 1 1 1 1 4 1 1 1 11 12 1 1 1 1 1 1 1 4 1 1 1 14 12 1 1 1 1 1 1 1 4 1 1 1 15 12 1 1 1 1 1 1 1 5 1 1 1 6 12 1 1 1 1 1 1 1 5 1 1 1 7 12 1 1 1 1 1 1 1 5 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 7 12 1 1 1 1 1 1 1 6 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 13 12 1 1 1 1 1 1 1 6 1 1 1 19 12 1 1 1 1 1 1 1 7 1 1 1 2 12 1 1 1 1 1 1 1 7 1 1 1 10 12 1 1 1 1 1 1 1 7 1 1 1 12 12 1 1 1 1 1 1 1 7 1 1 1 13 12 1 1 1 1 1 1 1 7 1 1 1 20 12 1 1 1 1 1 1 1 8 1 1 1 13 12 1 1 1 1 1 1 1 8 1 1 1 15 12 1 1 1 1 1 1 1 8 1 1 1 18 12 1 1 1 1 1 1 1 8 1 1 1 21 12 1 1 1 1 1 1 1 8 1 1 1 24 12 1 1 1 1 1 1 1 9 1 1 1 16 12 1 1 1 1 1 1 1 9 1 1 1 17 12 1 1 1 1 1 1 1 9 1 1 1 18 12 1 1 1 1 1 1 1 10 1 1 1 3 12 1 1 1 1 1 1 1 10 1 1 1 6 12 1 1 1 1 1 1 1 10 1 1 1 9 12 1 1 1 1 1 1 1 10 1 1 1 15 12 1 1 1 1 1 1 1 10 1 1 1 21 12 1 1 1 1 1 1 1 10 1 1 1 22 12 1 1 1 1 1 1 1 10 1 1 1 25 12 1 1 1 1 1 1 1 11 1 1 1 5 12 1 1 1 1 1 1 1 11 1 1 1 13 12 1 1 1 1 1 1 1 11 1 1 1 15 12 1 1 1 1 1 1 1 11 1 1 1 18 12 1 1 1 1 1 1 1 11 1 1 1 24 12 1 1 1 1 1 1 1 12 1 1 1 5 12 1 1 1 1 1 1 1 12 1 1 1 7 12 1 1 1 1 1 1 1 12 1 1 1 8 12 1 1 1 1 1 1 1 12 1 1 1 12 12 1 1 1 1 1 1 1 12 1 1 1 18 12 1 1 1 1 1 1 1 12 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 9 12 1 1 1 1 1 1 1 13 1 1 1 11 12 1 1 1 1 1 1 1 13 1 1 1 14 12 1 1 1 1 1 1 1 13 1 1 1 15 12 1 1 1 1 1 1 1 13 1 1 1 17 12 1 1 1 1 1 1 1 13 1 1 1 22 12 1 1 1 1 1 1 1 13 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 24 12 1 1 1 1 1 1 1 14 1 1 1 5 12 1 1 1 1 1 1 1 14 1 1 1 15 12 1 1 1 1 1 1 1 14 1 1 1 18 12 1 1 1 1 1 1 1 14 1 1 1 19 12 1 1 1 1 1 1 1 14 1 1 1 24 12 1 1 1 1 1 1 1 15 1 1 1 3 12 1 1 1 1 1 1 1 15 1 1 1 9 12 1 1 1 1 1 1 1 15 1 1 1 10 12 1 1 1 1 1 1 1 15 1 1 1 17 12 1 1 1 1 1 1 1 15 1 1 1 24 12 1 1 1 1 1 1 1 16 1 1 1 2 12 1 1 1 1 1 1 1 17 1 1 1 10 12 1 1 1 1 1 1 1 17 1 1 1 14 12 1 1 1 1 1 1 1 17 1 1 1 19 12 1 1 1 1 1 1 1 18 1 1 1 3 12 1 1 1 1 1 1 1 18 1 1 1 6 12 1 1 1 1 1 1 1 18 1 1 1 19 12 1 1 1 1 1 1 1 19 1 1 1 6 12 1 1 1 1 1 1 1 19 1 1 1 13 12 1 1 1 1 1 1 1 19 1 1 1 20 12 1 1 1 1 1 1 1 19 1 1 1 21 12 1 1 1 1 1 1 1 19 1 1 1 23 12 1 1 1 1 1 1 1 20 1 1 1 4 12 1 1 1 1 1 1 1 20 1 1 1 12 12 1 1 1 1 1 1 1 20 1 1 1 13 12 1 1 1 1 1 1 1 20 1 1 1 15 12 1 1 1 1 1 1 1 20 1 1 1 17 12 1 1 1 1 1 1 1 20 1 1 1 19 12 1 1 1 1 1 1 1 21 1 1 1 5 12 1 1 1 1 1 1 1 21 1 1 1 8 12 1 1 1 1 1 1 1 21 1 1 1 12 12 1 1 1 1 1 1 1 21 1 1 1 14 12 1 1 1 1 1 1 1 21 1 1 1 15 12 1 1 1 1 1 1 1 21 1 1 1 16 12 1 1 1 1 1 1 1 21 1 1 1 17 12 1 1 1 1 1 1 1 21 1 1 1 22 12 1 1 1 1 1 1 1 22 1 1 1 9 12 1 1 1 1 1 1 1 22 1 1 1 10 12 1 1 1 1 1 1 1 22 1 1 1 12 12 1 1 1 1 1 1 1 22 1 1 1 13 12 1 1 1 1 1 1 1 22 1 1 1 14 12 1 1 1 1 1 1 1 22 1 1 1 16 12 1 1 1 1 1 1 1 22 1 1 1 18 12 1 1 1 1 1 1 1 22 1 1 1 23 12 1 1 1 1 1 1 1 22 1 1 1 24 12 1 1 1 1 1 1 1 23 1 1 1 4 12 1 1 1 1 1 1 1 23 1 1 1 8 12 1 1 1 1 1 1 1 23 1 1 1 11 12 1 1 1 1 1 1 1 23 1 1 1 16 12 1 1 1 1 1 1 1 23 1 1 1 17 12 1 1 1 1 1 1 1 23 1 1 1 20 12 1 1 1 1 1 1 1 23 1 1 1 21 12 1 1 1 1 1 1 1 24 1 1 1 3 12 1 1 1 1 1 1 1 24 1 1 1 5 12 1 1 1 1 1 1 1 24 1 1 1 7 12 1 1 1 1 1 1 1 24 1 1 1 8 12 1 1 1 1 1 1 1 24 1 1 1 15 12 1 1 1 1 1 1 1 24 1 1 1 17 12 1 1 1 1 1 1 1 24 1 1 1 23 12 1 1 1 1 1 1 1 25 1 1 1 16 12 1 1 1 1 1 1 1 25 1 1 1 18 12 1 1 1 1 1 1 1 25 1 1 1 25"); return value; }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_23(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Path n8(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto p=n8(c,e); return unwrap(n9(c,e),p); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { auto a=n21(c,e); auto b=n22(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n23(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { auto a=n20(c,e); auto b=n23(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n24(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { auto a=n19(c,e); auto b=n24(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n25(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { auto a=n18(c,e); auto b=n25(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { std::vector<Path> pv{n17(c,e)}; std::vector<Space> sv{n26(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[5]=sv[0];  return routine_10(c,n); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { return iterate(c,e,n15(c,e),3,4,n16); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return iterate(c,e,n13(c,e),2,3,n14); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return iterate(c,e,n11(c,e),1,2,n12); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),0,1,n10); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Path n38(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n37(Context& c, const Env& e) { auto a=n21(c,e); auto b=n38(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { auto a=n37(c,e); auto b=n39(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n40(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { auto a=n36(c,e); auto b=n40(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n34(Context& c, const Env& e) { auto a=n35(c,e); auto b=n41(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { std::vector<Path> pv{n34(c,e)}; std::vector<Space> sv{n42(c,e),n43(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[10]=sv[0];n.spaces[0]=sv[1];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { return iterate(c,e,n32(c,e),8,9,n33); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { return iterate(c,e,n30(c,e),7,8,n31); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return iterate(c,e,n28(c,e),6,7,n29); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),5,6,n27); }
static ZIPPY_NOINLINE Path n46(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { auto p=n46(c,e); return unwrap(n47(c,e),p); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Path n59(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n58(Context& c, const Env& e) { auto a=n21(c,e); auto b=n59(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n60(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n57(Context& c, const Env& e) { auto a=n58(c,e); auto b=n60(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n61(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n56(Context& c, const Env& e) { auto a=n57(c,e); auto b=n61(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { auto a=n56(c,e); auto b=n62(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { std::vector<Path> pv{n55(c,e)}; std::vector<Space> sv{n63(c,e),n64(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[15]=sv[0];n.spaces[0]=sv[1];  return routine_21(c,n); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { return iterate(c,e,n53(c,e),13,14,n54); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return iterate(c,e,n51(c,e),12,13,n52); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return iterate(c,e,n49(c,e),11,12,n50); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return iterate(c,e,n45(c,e),10,11,n48); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { auto a=n5(c,e); auto b=n44(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_23(Context& c,const Env& e) { return n2(c,e); }
static ZIPPY_NOINLINE Space n66(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { return e.spaces.at(17); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(18); }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n77(Context& c, const Env& e) { auto a=n21(c,e); auto b=n78(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n79(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Path n76(Context& c, const Env& e) { auto a=n77(c,e); auto b=n79(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n80(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { auto a=n76(c,e); auto b=n80(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n74(Context& c, const Env& e) { auto a=n75(c,e); auto b=n81(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { std::vector<Path> pv{n74(c,e),n82(c,e)}; std::vector<Space> sv{n83(c,e)}; Env n; n.paths[19]=pv[0];n.paths[4]=pv[1];n.spaces[20]=sv[0];  return routine_22(c,n); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { return iterate(c,e,n72(c,e),18,19,n73); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { return iterate(c,e,n70(c,e),17,18,n71); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return iterate(c,e,n68(c,e),16,17,n69); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { return iterate(c,e,n66(c,e),15,16,n67); }
static ZIPPY_NOINLINE Space routine_10(Context& c,const Env& e) { return n65(c,e); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space n87(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Path n97(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n96(Context& c, const Env& e) { auto a=n21(c,e); auto b=n97(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n98(Context& c, const Env& e) { return e.paths.at(21); }
static ZIPPY_NOINLINE Path n95(Context& c, const Env& e) { auto a=n96(c,e); auto b=n98(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n99(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n94(Context& c, const Env& e) { auto a=n95(c,e); auto b=n99(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n100(Context& c, const Env& e) { return e.paths.at(23); }
static ZIPPY_NOINLINE Path n93(Context& c, const Env& e) { auto a=n94(c,e); auto b=n100(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n101(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { return e.spaces.at(24); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { std::vector<Path> pv{n93(c,e),n101(c,e)}; std::vector<Space> sv{n102(c,e),n103(c,e)}; Env n; n.paths[24]=pv[0];n.paths[9]=pv[1];n.spaces[25]=sv[0];n.spaces[0]=sv[1];  return routine_14(c,n); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { return iterate(c,e,n91(c,e),23,24,n92); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { return iterate(c,e,n89(c,e),22,23,n90); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { return iterate(c,e,n87(c,e),21,22,n88); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return iterate(c,e,n85(c,e),20,21,n86); }
static ZIPPY_NOINLINE Space routine_15(Context& c,const Env& e) { return n84(c,e); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { return e.spaces.at(26); }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n111(Context& c, const Env& e) { return e.spaces.at(28); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(25); }
static ZIPPY_NOINLINE Path n116(Context& c, const Env& e) { auto a=n21(c,e); auto b=n117(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n118(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n115(Context& c, const Env& e) { auto a=n116(c,e); auto b=n118(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n119(Context& c, const Env& e) { return e.paths.at(27); }
static ZIPPY_NOINLINE Path n114(Context& c, const Env& e) { auto a=n115(c,e); auto b=n119(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n120(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { auto a=n114(c,e); auto b=n120(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n121(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n112(Context& c, const Env& e) { std::vector<Path> pv{n113(c,e),n121(c,e)}; std::vector<Space> sv{n122(c,e),n123(c,e)}; Env n; n.paths[29]=pv[0];n.paths[14]=pv[1];n.spaces[30]=sv[0];n.spaces[0]=sv[1];  return routine_20(c,n); }
static ZIPPY_NOINLINE Space n110(Context& c, const Env& e) { return iterate(c,e,n111(c,e),28,29,n112); }
static ZIPPY_NOINLINE Space n108(Context& c, const Env& e) { return iterate(c,e,n109(c,e),27,28,n110); }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { return iterate(c,e,n107(c,e),26,27,n108); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return iterate(c,e,n105(c,e),25,26,n106); }
static ZIPPY_NOINLINE Space routine_21(Context& c,const Env& e) { return n104(c,e); }
static ZIPPY_NOINLINE Path n127(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n128(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { auto p=n127(c,e); return unwrap(n128(c,e),p); }
static ZIPPY_NOINLINE Path n130(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Space n131(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n129(Context& c, const Env& e) { auto p=n130(c,e); return unwrap(n131(c,e),p); }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { auto a=n126(c,e); if(a.empty()) return a; return compose(a,n129(c,e)); }
static ZIPPY_NOINLINE Path n134(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n135(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Path n133(Context& c, const Env& e) { auto a=n134(c,e); auto b=n135(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n132(Context& c, const Env& e) { return singleton(n133(c,e)); }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { auto a=n125(c,e); auto b=n132(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space routine_22(Context& c,const Env& e) { return n124(c,e); }
static ZIPPY_NOINLINE Path n145(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n146(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n144(Context& c, const Env& e) { auto p=n145(c,e); return unwrap(n146(c,e),p); }
static ZIPPY_NOINLINE Path n148(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n149(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n147(Context& c, const Env& e) { auto p=n148(c,e); return unwrap(n149(c,e),p); }
static ZIPPY_NOINLINE Space n143(Context& c, const Env& e) { auto a=n144(c,e); if(a.empty()) return a; return compose(a,n147(c,e)); }
static ZIPPY_NOINLINE Path n152(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Path n153(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n151(Context& c, const Env& e) { auto a=n152(c,e); auto b=n153(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n150(Context& c, const Env& e) { return singleton(n151(c,e)); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { auto a=n143(c,e); auto b=n150(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n155(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n154(Context& c, const Env& e) { auto p=n155(c,e); return unwrap(n156(c,e),p); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { auto a=n142(c,e); auto b=n154(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n140(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n141(c,e)}; Env n; n.spaces[31]=sv[0];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n158(Context& c, const Env& e) { return e.spaces.at(32); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { return e.spaces.at(33); }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { return e.spaces.at(34); }
static ZIPPY_NOINLINE Path n168(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Path n167(Context& c, const Env& e) { auto a=n21(c,e); auto b=n168(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n169(Context& c, const Env& e) { return e.paths.at(31); }
static ZIPPY_NOINLINE Path n166(Context& c, const Env& e) { auto a=n167(c,e); auto b=n169(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n170(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n165(Context& c, const Env& e) { auto a=n166(c,e); auto b=n170(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n171(Context& c, const Env& e) { return e.paths.at(33); }
static ZIPPY_NOINLINE Path n164(Context& c, const Env& e) { auto a=n165(c,e); auto b=n171(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n172(Context& c, const Env& e) { return e.spaces.at(35); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { std::vector<Path> pv{n164(c,e)}; std::vector<Space> sv{n172(c,e)}; Env n; n.paths[34]=pv[0];n.spaces[36]=sv[0];  return routine_11(c,n); }
static ZIPPY_NOINLINE Space n161(Context& c, const Env& e) { return iterate(c,e,n162(c,e),33,35,n163); }
static ZIPPY_NOINLINE Space n159(Context& c, const Env& e) { return iterate(c,e,n160(c,e),32,34,n161); }
static ZIPPY_NOINLINE Space n157(Context& c, const Env& e) { return iterate(c,e,n158(c,e),31,33,n159); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { return iterate(c,e,n140(c,e),30,32,n157); }
static ZIPPY_NOINLINE Path n179(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n180(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { auto p=n179(c,e); return unwrap(n180(c,e),p); }
static ZIPPY_NOINLINE Path n182(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n183(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n181(Context& c, const Env& e) { auto p=n182(c,e); return unwrap(n183(c,e),p); }
static ZIPPY_NOINLINE Space n177(Context& c, const Env& e) { auto a=n178(c,e); if(a.empty()) return a; return compose(a,n181(c,e)); }
static ZIPPY_NOINLINE Path n186(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Path n187(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n185(Context& c, const Env& e) { auto a=n186(c,e); auto b=n187(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n184(Context& c, const Env& e) { return singleton(n185(c,e)); }
static ZIPPY_NOINLINE Space n176(Context& c, const Env& e) { auto a=n177(c,e); auto b=n184(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n189(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n190(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { auto p=n189(c,e); return unwrap(n190(c,e),p); }
static ZIPPY_NOINLINE Space n175(Context& c, const Env& e) { auto a=n176(c,e); auto b=n188(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n174(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n175(c,e)}; Env n; n.spaces[37]=sv[0];  return routine_7(c,n); }
static ZIPPY_NOINLINE Space n192(Context& c, const Env& e) { return e.spaces.at(38); }
static ZIPPY_NOINLINE Space n194(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n196(Context& c, const Env& e) { return e.spaces.at(40); }
static ZIPPY_NOINLINE Path n202(Context& c, const Env& e) { return e.paths.at(35); }
static ZIPPY_NOINLINE Path n201(Context& c, const Env& e) { auto a=n21(c,e); auto b=n202(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n203(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Path n200(Context& c, const Env& e) { auto a=n201(c,e); auto b=n203(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n204(Context& c, const Env& e) { return e.paths.at(37); }
static ZIPPY_NOINLINE Path n199(Context& c, const Env& e) { auto a=n200(c,e); auto b=n204(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n205(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Path n198(Context& c, const Env& e) { auto a=n199(c,e); auto b=n205(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n197(Context& c, const Env& e) { std::vector<Path> pv{n198(c,e)}; std::vector<Space> sv{n206(c,e)}; Env n; n.paths[39]=pv[0];n.spaces[42]=sv[0];  return routine_12(c,n); }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { return iterate(c,e,n196(c,e),38,41,n197); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { return iterate(c,e,n194(c,e),37,40,n195); }
static ZIPPY_NOINLINE Space n191(Context& c, const Env& e) { return iterate(c,e,n192(c,e),36,39,n193); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { return iterate(c,e,n174(c,e),35,38,n191); }
static ZIPPY_NOINLINE Space n138(Context& c, const Env& e) { auto a=n139(c,e); auto b=n173(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n209(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Path n210(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n208(Context& c, const Env& e) { auto a=n209(c,e); auto b=n210(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n207(Context& c, const Env& e) { return singleton(n208(c,e)); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { auto a=n138(c,e); if(a.empty()) return a; return compose(a,n207(c,e)); }
static ZIPPY_NOINLINE Space n212(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n214(Context& c, const Env& e) { return e.spaces.at(44); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { return e.spaces.at(45); }
static ZIPPY_NOINLINE Path n222(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n221(Context& c, const Env& e) { auto a=n21(c,e); auto b=n222(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n223(Context& c, const Env& e) { return e.paths.at(41); }
static ZIPPY_NOINLINE Path n220(Context& c, const Env& e) { auto a=n221(c,e); auto b=n223(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n224(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Path n219(Context& c, const Env& e) { auto a=n220(c,e); auto b=n224(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n225(Context& c, const Env& e) { return e.paths.at(43); }
static ZIPPY_NOINLINE Path n218(Context& c, const Env& e) { auto a=n219(c,e); auto b=n225(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n226(Context& c, const Env& e) { return e.spaces.at(46); }
static ZIPPY_NOINLINE Space n217(Context& c, const Env& e) { std::vector<Path> pv{n218(c,e)}; std::vector<Space> sv{n226(c,e)}; Env n; n.paths[44]=pv[0];n.spaces[47]=sv[0];  return routine_13(c,n); }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { return iterate(c,e,n216(c,e),43,46,n217); }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { return iterate(c,e,n214(c,e),42,45,n215); }
static ZIPPY_NOINLINE Space n211(Context& c, const Env& e) { return iterate(c,e,n212(c,e),41,44,n213); }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return iterate(c,e,n137(c,e),40,43,n211); }
static ZIPPY_NOINLINE Space routine_14(Context& c,const Env& e) { return n136(c,e); }
static ZIPPY_NOINLINE Path n236(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n237(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { auto p=n236(c,e); return unwrap(n237(c,e),p); }
static ZIPPY_NOINLINE Path n239(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Space n240(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n238(Context& c, const Env& e) { auto p=n239(c,e); return unwrap(n240(c,e),p); }
static ZIPPY_NOINLINE Space n234(Context& c, const Env& e) { auto a=n235(c,e); if(a.empty()) return a; return compose(a,n238(c,e)); }
static ZIPPY_NOINLINE Path n243(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n244(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n242(Context& c, const Env& e) { auto a=n243(c,e); auto b=n244(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n241(Context& c, const Env& e) { return singleton(n242(c,e)); }
static ZIPPY_NOINLINE Space n233(Context& c, const Env& e) { auto a=n234(c,e); auto b=n241(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n246(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n247(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n245(Context& c, const Env& e) { auto p=n246(c,e); return unwrap(n247(c,e),p); }
static ZIPPY_NOINLINE Space n232(Context& c, const Env& e) { auto a=n233(c,e); auto b=n245(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n231(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n232(c,e)}; Env n; n.spaces[48]=sv[0];  return routine_8(c,n); }
static ZIPPY_NOINLINE Space n249(Context& c, const Env& e) { return e.spaces.at(49); }
static ZIPPY_NOINLINE Space n251(Context& c, const Env& e) { return e.spaces.at(50); }
static ZIPPY_NOINLINE Space n253(Context& c, const Env& e) { return e.spaces.at(51); }
static ZIPPY_NOINLINE Path n259(Context& c, const Env& e) { return e.paths.at(45); }
static ZIPPY_NOINLINE Path n258(Context& c, const Env& e) { auto a=n21(c,e); auto b=n259(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n260(Context& c, const Env& e) { return e.paths.at(46); }
static ZIPPY_NOINLINE Path n257(Context& c, const Env& e) { auto a=n258(c,e); auto b=n260(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n261(Context& c, const Env& e) { return e.paths.at(47); }
static ZIPPY_NOINLINE Path n256(Context& c, const Env& e) { auto a=n257(c,e); auto b=n261(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n262(Context& c, const Env& e) { return e.paths.at(48); }
static ZIPPY_NOINLINE Path n255(Context& c, const Env& e) { auto a=n256(c,e); auto b=n262(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n263(Context& c, const Env& e) { return e.spaces.at(52); }
static ZIPPY_NOINLINE Space n254(Context& c, const Env& e) { std::vector<Path> pv{n255(c,e)}; std::vector<Space> sv{n263(c,e)}; Env n; n.paths[49]=pv[0];n.spaces[53]=sv[0];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n252(Context& c, const Env& e) { return iterate(c,e,n253(c,e),48,52,n254); }
static ZIPPY_NOINLINE Space n250(Context& c, const Env& e) { return iterate(c,e,n251(c,e),47,51,n252); }
static ZIPPY_NOINLINE Space n248(Context& c, const Env& e) { return iterate(c,e,n249(c,e),46,50,n250); }
static ZIPPY_NOINLINE Space n230(Context& c, const Env& e) { return iterate(c,e,n231(c,e),45,49,n248); }
static ZIPPY_NOINLINE Path n270(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n271(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n269(Context& c, const Env& e) { auto p=n270(c,e); return unwrap(n271(c,e),p); }
static ZIPPY_NOINLINE Path n273(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Space n274(Context& c, const Env& e) { static const Space value=literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n272(Context& c, const Env& e) { auto p=n273(c,e); return unwrap(n274(c,e),p); }
static ZIPPY_NOINLINE Space n268(Context& c, const Env& e) { auto a=n269(c,e); if(a.empty()) return a; return compose(a,n272(c,e)); }
static ZIPPY_NOINLINE Path n277(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n278(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n276(Context& c, const Env& e) { auto a=n277(c,e); auto b=n278(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n275(Context& c, const Env& e) { return singleton(n276(c,e)); }
static ZIPPY_NOINLINE Space n267(Context& c, const Env& e) { auto a=n268(c,e); auto b=n275(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n280(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n281(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { auto p=n280(c,e); return unwrap(n281(c,e),p); }
static ZIPPY_NOINLINE Space n266(Context& c, const Env& e) { auto a=n267(c,e); auto b=n279(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n265(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n266(c,e)}; Env n; n.spaces[31]=sv[0];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n283(Context& c, const Env& e) { return e.spaces.at(54); }
static ZIPPY_NOINLINE Space n285(Context& c, const Env& e) { return e.spaces.at(55); }
static ZIPPY_NOINLINE Space n287(Context& c, const Env& e) { return e.spaces.at(56); }
static ZIPPY_NOINLINE Path n293(Context& c, const Env& e) { return e.paths.at(50); }
static ZIPPY_NOINLINE Path n292(Context& c, const Env& e) { auto a=n21(c,e); auto b=n293(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n294(Context& c, const Env& e) { return e.paths.at(51); }
static ZIPPY_NOINLINE Path n291(Context& c, const Env& e) { auto a=n292(c,e); auto b=n294(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n295(Context& c, const Env& e) { return e.paths.at(52); }
static ZIPPY_NOINLINE Path n290(Context& c, const Env& e) { auto a=n291(c,e); auto b=n295(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n296(Context& c, const Env& e) { return e.paths.at(53); }
static ZIPPY_NOINLINE Path n289(Context& c, const Env& e) { auto a=n290(c,e); auto b=n296(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n297(Context& c, const Env& e) { return e.spaces.at(57); }
static ZIPPY_NOINLINE Space n288(Context& c, const Env& e) { std::vector<Path> pv{n289(c,e)}; std::vector<Space> sv{n297(c,e)}; Env n; n.paths[54]=pv[0];n.spaces[58]=sv[0];  return routine_18(c,n); }
static ZIPPY_NOINLINE Space n286(Context& c, const Env& e) { return iterate(c,e,n287(c,e),53,57,n288); }
static ZIPPY_NOINLINE Space n284(Context& c, const Env& e) { return iterate(c,e,n285(c,e),52,56,n286); }
static ZIPPY_NOINLINE Space n282(Context& c, const Env& e) { return iterate(c,e,n283(c,e),51,55,n284); }
static ZIPPY_NOINLINE Space n264(Context& c, const Env& e) { return iterate(c,e,n265(c,e),50,54,n282); }
static ZIPPY_NOINLINE Space n229(Context& c, const Env& e) { auto a=n230(c,e); auto b=n264(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n300(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n301(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n299(Context& c, const Env& e) { auto a=n300(c,e); auto b=n301(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n298(Context& c, const Env& e) { return singleton(n299(c,e)); }
static ZIPPY_NOINLINE Space n228(Context& c, const Env& e) { auto a=n229(c,e); if(a.empty()) return a; return compose(a,n298(c,e)); }
static ZIPPY_NOINLINE Space n303(Context& c, const Env& e) { return e.spaces.at(59); }
static ZIPPY_NOINLINE Space n305(Context& c, const Env& e) { return e.spaces.at(60); }
static ZIPPY_NOINLINE Space n307(Context& c, const Env& e) { return e.spaces.at(61); }
static ZIPPY_NOINLINE Path n313(Context& c, const Env& e) { return e.paths.at(55); }
static ZIPPY_NOINLINE Path n312(Context& c, const Env& e) { auto a=n21(c,e); auto b=n313(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n314(Context& c, const Env& e) { return e.paths.at(56); }
static ZIPPY_NOINLINE Path n311(Context& c, const Env& e) { auto a=n312(c,e); auto b=n314(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n315(Context& c, const Env& e) { return e.paths.at(57); }
static ZIPPY_NOINLINE Path n310(Context& c, const Env& e) { auto a=n311(c,e); auto b=n315(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n316(Context& c, const Env& e) { return e.paths.at(58); }
static ZIPPY_NOINLINE Path n309(Context& c, const Env& e) { auto a=n310(c,e); auto b=n316(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n317(Context& c, const Env& e) { return e.spaces.at(62); }
static ZIPPY_NOINLINE Space n308(Context& c, const Env& e) { std::vector<Path> pv{n309(c,e)}; std::vector<Space> sv{n317(c,e)}; Env n; n.paths[59]=pv[0];n.spaces[63]=sv[0];  return routine_19(c,n); }
static ZIPPY_NOINLINE Space n306(Context& c, const Env& e) { return iterate(c,e,n307(c,e),58,62,n308); }
static ZIPPY_NOINLINE Space n304(Context& c, const Env& e) { return iterate(c,e,n305(c,e),57,61,n306); }
static ZIPPY_NOINLINE Space n302(Context& c, const Env& e) { return iterate(c,e,n303(c,e),56,60,n304); }
static ZIPPY_NOINLINE Space n227(Context& c, const Env& e) { return iterate(c,e,n228(c,e),55,59,n302); }
static ZIPPY_NOINLINE Space routine_20(Context& c,const Env& e) { return n227(c,e); }
static ZIPPY_NOINLINE Space n320(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Space n319(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n320(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n323(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n320(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n322(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n323(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n321(Context& c, const Env& e) { auto a=n320(c,e); auto b=n322(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n318(Context& c, const Env& e) { auto a=n319(c,e); auto b=n321(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_6(Context& c,const Env& e) { return n318(c,e); }
static ZIPPY_NOINLINE Space n324(Context& c, const Env& e) { static const Space value=literal_text("1 4 1 1 1 133"); return value; }
static ZIPPY_NOINLINE Space routine_11(Context& c,const Env& e) { return n324(c,e); }
static ZIPPY_NOINLINE Space n328(Context& c, const Env& e) { return e.spaces.at(37); }
static ZIPPY_NOINLINE Space n327(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n328(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n326(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n327(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n330(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n328(c,e)}; Env n; n.spaces[66]=sv[0];  return routine_3(c,n); }
static ZIPPY_NOINLINE Space n329(Context& c, const Env& e) { auto a=n328(c,e); auto b=n330(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n325(Context& c, const Env& e) { auto a=n326(c,e); auto b=n329(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_7(Context& c,const Env& e) { return n325(c,e); }
static ZIPPY_NOINLINE Space n331(Context& c, const Env& e) { static const Space value=literal_text("1 4 1 1 1 133"); return value; }
static ZIPPY_NOINLINE Space routine_12(Context& c,const Env& e) { return n331(c,e); }
static ZIPPY_NOINLINE Space n332(Context& c, const Env& e) { return e.spaces.at(47); }
static ZIPPY_NOINLINE Space routine_13(Context& c,const Env& e) { return n332(c,e); }
static ZIPPY_NOINLINE Space n335(Context& c, const Env& e) { return e.spaces.at(48); }
static ZIPPY_NOINLINE Space n334(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n335(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n337(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n335(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n336(Context& c, const Env& e) { auto a=n335(c,e); auto b=n337(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n333(Context& c, const Env& e) { auto a=n334(c,e); auto b=n336(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_8(Context& c,const Env& e) { return n333(c,e); }
static ZIPPY_NOINLINE Space n338(Context& c, const Env& e) { static const Space value=literal_text("1 4 1 1 1 133"); return value; }
static ZIPPY_NOINLINE Space routine_16(Context& c,const Env& e) { return n338(c,e); }
static ZIPPY_NOINLINE Space n339(Context& c, const Env& e) { static const Space value=literal_text("1 4 1 1 1 133"); return value; }
static ZIPPY_NOINLINE Space routine_18(Context& c,const Env& e) { return n339(c,e); }
static ZIPPY_NOINLINE Space n340(Context& c, const Env& e) { return e.spaces.at(63); }
static ZIPPY_NOINLINE Space routine_19(Context& c,const Env& e) { return n340(c,e); }
static ZIPPY_NOINLINE Space n343(Context& c, const Env& e) { return e.spaces.at(64).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n346(Context& c, const Env& e) { return e.spaces.at(64); }
static ZIPPY_NOINLINE Space n345(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n346(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n344(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n345(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n342(Context& c, const Env& e) { auto a=n343(c,e); if(a.empty()) return a; return compose(a,n344(c,e)); }
static ZIPPY_NOINLINE Space n349(Context& c, const Env& e) { return singleton(n21(c,e)); }
static ZIPPY_NOINLINE Space n348(Context& c, const Env& e) { auto a=n349(c,e); auto b=n343(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n350(Context& c, const Env& e) { return Space(); }
static ZIPPY_NOINLINE Space n347(Context& c, const Env& e) { auto a=n348(c,e); if(a.empty()) return a; return compose(a,n350(c,e)); }
static ZIPPY_NOINLINE Space n341(Context& c, const Env& e) { auto a=n342(c,e); auto b=n347(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n341(c,e); }
static ZIPPY_NOINLINE Space n353(Context& c, const Env& e) { return e.spaces.at(65).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n355(Context& c, const Env& e) { return e.spaces.at(65); }
static ZIPPY_NOINLINE Space n357(Context& c, const Env& e) { return e.spaces.at(65); }
static ZIPPY_NOINLINE Space n356(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n357(c,e)}; Env n; n.spaces[67]=sv[0];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n354(Context& c, const Env& e) { auto a=n355(c,e); auto b=n356(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n352(Context& c, const Env& e) { auto a=n353(c,e); if(a.empty()) return a; return compose(a,n354(c,e)); }
static ZIPPY_NOINLINE Space n359(Context& c, const Env& e) { auto a=n349(c,e); auto b=n353(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n358(Context& c, const Env& e) { auto a=n359(c,e); if(a.empty()) return a; return compose(a,n350(c,e)); }
static ZIPPY_NOINLINE Space n351(Context& c, const Env& e) { auto a=n352(c,e); auto b=n358(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n351(c,e); }
static ZIPPY_NOINLINE Space n362(Context& c, const Env& e) { return e.spaces.at(66).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n365(Context& c, const Env& e) { return e.spaces.at(66); }
static ZIPPY_NOINLINE Space n364(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n365(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n363(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n364(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n361(Context& c, const Env& e) { auto a=n362(c,e); if(a.empty()) return a; return compose(a,n363(c,e)); }
static ZIPPY_NOINLINE Space n367(Context& c, const Env& e) { auto a=n349(c,e); auto b=n362(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n366(Context& c, const Env& e) { auto a=n367(c,e); if(a.empty()) return a; return compose(a,n350(c,e)); }
static ZIPPY_NOINLINE Space n360(Context& c, const Env& e) { auto a=n361(c,e); auto b=n366(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_3(Context& c,const Env& e) { return n360(c,e); }
static ZIPPY_NOINLINE Space n373(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n372(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n373(c,e),allowed,false); }
static ZIPPY_NOINLINE Space n371(Context& c, const Env& e) { auto a=n372(c,e); auto b=n349(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n374(Context& c, const Env& e) { return iterate(c,e,n372(c,e),60,68,n349); }
static ZIPPY_NOINLINE Space n370(Context& c, const Env& e) { auto a=n371(c,e); auto b=n374(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n369(Context& c, const Env& e) { auto a=n370(c,e); if(a.empty()) return a; return compose(a,n349(c,e)); }
static ZIPPY_NOINLINE Space n376(Context& c, const Env& e) { auto a=n349(c,e); auto b=n370(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n379(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n378(Context& c, const Env& e) { static const auto order=paths_text("133 4 1 1 1 26 4 1 1 1 28 4 1 1 1 29 4 1 1 1 31 4 1 1 1 32 4 1 1 1 33 4 1 1 1 34 4 1 1 1 35 4 1 1 1 36 4 1 1 1 37 4 1 1 1 38 4 1 1 1 27 4 1 1 1 39 4 1 1 1 41 4 1 1 1 42 4 1 1 1 43 4 1 1 1 44 4 1 1 1 45 4 1 1 1 46 4 1 1 1 47 4 1 1 1 48 4 1 1 1 49 4 1 1 1 40 4 1 1 1 50 4 1 1 1 52 4 1 1 1 53 4 1 1 1 54 4 1 1 1 55 4 1 1 1 56 4 1 1 1 57 4 1 1 1 58 4 1 1 1 59 4 1 1 1 60 4 1 1 1 51 4 1 1 1 61 4 1 1 1 63 4 1 1 1 64 4 1 1 1 65 4 1 1 1 66 4 1 1 1 67 4 1 1 1 68 4 1 1 1 69 4 1 1 1 70 4 1 1 1 71 4 1 1 1 62 4 1 1 1 72 4 1 1 1 74 4 1 1 1 75 4 1 1 1 76 4 1 1 1 77 4 1 1 1 78 4 1 1 1 79 4 1 1 1 80 4 1 1 1 81 4 1 1 1 82 4 1 1 1 73 4 1 1 1 83 4 1 1 1 85 4 1 1 1 86 4 1 1 1 87 4 1 1 1 88 4 1 1 1 89 4 1 1 1 84 4 1 1 1 90 4 1 1 1 30 4 1 1 1 2 4 1 1 1 5 4 1 1 1 3 4 1 1 1 4 4 1 1 1 9 4 1 1 1 6 4 1 1 1 7 4 1 1 1 21 4 1 1 1 16 4 1 1 1 22 4 1 1 1 10 4 1 1 1 17 4 1 1 1 18 4 1 1 1 8 4 1 1 1 19 4 1 1 1 25 4 1 1 1 11 4 1 1 1 91 4 1 1 1 92 4 1 1 1 93 4 1 1 1 94 4 1 1 1 95 4 1 1 1 96 4 1 1 1 14 4 1 1 1 97 4 1 1 1 98 4 1 1 1 99 4 1 1 1 100 4 1 1 1 101 4 1 1 1 102 4 1 1 1 103 4 1 1 1 104 4 1 1 1 105 4 1 1 1 106 4 1 1 1 23 4 1 1 1 107 4 1 1 1 108 4 1 1 1 109 4 1 1 1 110 4 1 1 1 111 4 1 1 1 112 4 1 1 1 113 4 1 1 1 114 4 1 1 1 115 4 1 1 1 116 4 1 1 1 15 4 1 1 1 117 4 1 1 1 118 4 1 1 1 119 4 1 1 1 120 4 1 1 1 121 4 1 1 1 122 4 1 1 1 123 4 1 1 1 124 4 1 1 1 125 4 1 1 1 126 4 1 1 1 12 4 1 1 1 127 4 1 1 1 128 4 1 1 1 129 4 1 1 1 130 4 1 1 1 131 4 1 1 1 132 4 1 1 1 24 4 1 1 1 20 4 1 1 1 13 4 1 1 1 1 4 1 1 1 133");return first_listed(n379(c,e),order,true); }
static ZIPPY_NOINLINE Space n380(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n377(Context& c, const Env& e) { std::vector<Path> pv{n21(c,e)}; std::vector<Space> sv{n378(c,e),n380(c,e)}; Env n; n.paths[61]=pv[0];n.spaces[69]=sv[0];n.spaces[67]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n375(Context& c, const Env& e) { auto a=n376(c,e); if(a.empty()) return a; return compose(a,n377(c,e)); }
static ZIPPY_NOINLINE Space n368(Context& c, const Env& e) { auto a=n369(c,e); auto b=n375(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_4(Context& c,const Env& e) { return n368(c,e); }
static ZIPPY_NOINLINE Space n384(Context& c, const Env& e) { return e.spaces.at(69); }
static ZIPPY_NOINLINE Space n383(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n384(c,e),allowed,false); }
static ZIPPY_NOINLINE Path n386(Context& c, const Env& e) { return e.paths.at(61); }
static ZIPPY_NOINLINE Space n387(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n385(Context& c, const Env& e) { std::vector<Path> pv{n386(c,e)}; std::vector<Space> sv{n387(c,e)}; Env n; n.paths[62]=pv[0];n.spaces[67]=sv[0];  return routine_9(c,n); }
static ZIPPY_NOINLINE Space n382(Context& c, const Env& e) { auto a=n383(c,e); if(a.empty()) return a; return compose(a,n385(c,e)); }
static ZIPPY_NOINLINE Space n389(Context& c, const Env& e) { return e.spaces.at(69); }
static ZIPPY_NOINLINE Path n392(Context& c, const Env& e) { return e.paths.at(61); }
static ZIPPY_NOINLINE Path n393(Context& c, const Env& e) { return e.paths.at(63); }
static ZIPPY_NOINLINE Path n391(Context& c, const Env& e) { auto a=n392(c,e); auto b=n393(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n394(Context& c, const Env& e) { return e.spaces.at(70); }
static ZIPPY_NOINLINE Space n395(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n390(Context& c, const Env& e) { std::vector<Path> pv{n391(c,e)}; std::vector<Space> sv{n394(c,e),n395(c,e)}; Env n; n.paths[61]=pv[0];n.spaces[69]=sv[0];n.spaces[67]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n388(Context& c, const Env& e) { return iterate(c,e,n389(c,e),63,70,n390); }
static ZIPPY_NOINLINE Space n381(Context& c, const Env& e) { auto a=n382(c,e); auto b=n388(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n381(c,e); }
static ZIPPY_NOINLINE Path n397(Context& c, const Env& e) { return e.paths.at(62); }
static ZIPPY_NOINLINE Path n400(Context& c, const Env& e) { return e.paths.at(62); }
static ZIPPY_NOINLINE Space n401(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n399(Context& c, const Env& e) { auto p=n400(c,e); return unwrap(n401(c,e),p); }
static ZIPPY_NOINLINE Space n398(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n399(c,e)}; Env n; n.spaces[67]=sv[0];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n396(Context& c, const Env& e) { auto p=n397(c,e); return wrap(n398(c,e),p); }
static ZIPPY_NOINLINE Space routine_9(Context& c,const Env& e) { return n396(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
