#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_3(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Path n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Space n41(Context&, const Env&);
static ZIPPY_NOINLINE Path n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Path n44(Context&, const Env&);
static ZIPPY_NOINLINE Path n45(Context&, const Env&);
static ZIPPY_NOINLINE Path n46(Context&, const Env&);
static ZIPPY_NOINLINE Path n47(Context&, const Env&);
static ZIPPY_NOINLINE Path n48(Context&, const Env&);
static ZIPPY_NOINLINE Path n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Path n59(Context&, const Env&);
static ZIPPY_NOINLINE Path n60(Context&, const Env&);
static ZIPPY_NOINLINE Path n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Path n63(Context&, const Env&);
static ZIPPY_NOINLINE Path n64(Context&, const Env&);
static ZIPPY_NOINLINE Path n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Path n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_3(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1,1,1,25}; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { auto a=n17(c,e); auto b=n18(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { auto a=n16(c,e); auto b=n19(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n20(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { auto a=n14(c,e); auto b=n21(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { std::vector<Path> pv{n13(c,e)}; std::vector<Space> sv{n22(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[5]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return iterate(c,e,n11(c,e),3,4,n12); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return iterate(c,e,n9(c,e),2,3,n10); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),1,2,n8); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),0,1,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_3(Context& c,const Env& e) { return n2(c,e); }
static ZIPPY_NOINLINE Path n24(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { static const Space value=literal_text("36 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 9 1 1 1 3 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 4 8 1 1 1 10 1 1 1 5 8 1 1 1 11 1 1 1 5 8 1 1 1 11 1 1 1 6 8 1 1 1 12 1 1 1 1 8 1 1 1 12 1 1 1 6 8 1 1 1 13 1 1 1 7 8 1 1 1 13 1 1 1 8 8 1 1 1 14 1 1 1 8 8 1 1 1 14 1 1 1 9 8 1 1 1 15 1 1 1 9 8 1 1 1 15 1 1 1 10 8 1 1 1 16 1 1 1 10 8 1 1 1 16 1 1 1 11 8 1 1 1 17 1 1 1 11 8 1 1 1 17 1 1 1 12 8 1 1 1 18 1 1 1 7 8 1 1 1 18 1 1 1 12 8 1 1 1 19 1 1 1 13 8 1 1 1 19 1 1 1 14 8 1 1 1 20 1 1 1 14 8 1 1 1 20 1 1 1 15 8 1 1 1 21 1 1 1 15 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 17 8 1 1 1 23 1 1 1 17 8 1 1 1 23 1 1 1 18 8 1 1 1 24 1 1 1 13 8 1 1 1 24 1 1 1 18"); return value; }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto p=n32(c,e); return unwrap(n33(c,e),p); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { static const Space value=literal_text("36 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 9 1 1 1 3 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 4 8 1 1 1 10 1 1 1 5 8 1 1 1 11 1 1 1 5 8 1 1 1 11 1 1 1 6 8 1 1 1 12 1 1 1 1 8 1 1 1 12 1 1 1 6 8 1 1 1 13 1 1 1 7 8 1 1 1 13 1 1 1 8 8 1 1 1 14 1 1 1 8 8 1 1 1 14 1 1 1 9 8 1 1 1 15 1 1 1 9 8 1 1 1 15 1 1 1 10 8 1 1 1 16 1 1 1 10 8 1 1 1 16 1 1 1 11 8 1 1 1 17 1 1 1 11 8 1 1 1 17 1 1 1 12 8 1 1 1 18 1 1 1 7 8 1 1 1 18 1 1 1 12 8 1 1 1 19 1 1 1 13 8 1 1 1 19 1 1 1 14 8 1 1 1 20 1 1 1 14 8 1 1 1 20 1 1 1 15 8 1 1 1 21 1 1 1 15 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 17 8 1 1 1 23 1 1 1 17 8 1 1 1 23 1 1 1 18 8 1 1 1 24 1 1 1 13 8 1 1 1 24 1 1 1 18"); return value; }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto b=n31(c,e); auto a=n34(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Path n46(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n45(Context& c, const Env& e) { auto a=n17(c,e); auto b=n46(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n47(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n44(Context& c, const Env& e) { auto a=n45(c,e); auto b=n47(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n48(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { auto a=n44(c,e); auto b=n48(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n49(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n42(Context& c, const Env& e) { auto a=n43(c,e); auto b=n49(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n41(Context& c, const Env& e) { std::vector<Path> pv{n42(c,e)}; std::vector<Space> sv{n50(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[10]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return iterate(c,e,n40(c,e),8,9,n41); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return iterate(c,e,n38(c,e),7,8,n39); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return iterate(c,e,n36(c,e),6,7,n37); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { return iterate(c,e,n30(c,e),5,6,n35); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { static const Space value=literal_text("36 8 1 1 1 1 1 1 1 7 8 1 1 1 1 1 1 1 12 8 1 1 1 2 1 1 1 7 8 1 1 1 2 1 1 1 8 8 1 1 1 3 1 1 1 8 8 1 1 1 3 1 1 1 9 8 1 1 1 4 1 1 1 9 8 1 1 1 4 1 1 1 10 8 1 1 1 5 1 1 1 10 8 1 1 1 5 1 1 1 11 8 1 1 1 6 1 1 1 11 8 1 1 1 6 1 1 1 12 8 1 1 1 7 1 1 1 13 8 1 1 1 7 1 1 1 18 8 1 1 1 8 1 1 1 13 8 1 1 1 8 1 1 1 14 8 1 1 1 9 1 1 1 14 8 1 1 1 9 1 1 1 15 8 1 1 1 10 1 1 1 15 8 1 1 1 10 1 1 1 16 8 1 1 1 11 1 1 1 16 8 1 1 1 11 1 1 1 17 8 1 1 1 12 1 1 1 17 8 1 1 1 12 1 1 1 18 8 1 1 1 13 1 1 1 19 8 1 1 1 13 1 1 1 24 8 1 1 1 14 1 1 1 19 8 1 1 1 14 1 1 1 20 8 1 1 1 15 1 1 1 20 8 1 1 1 15 1 1 1 21 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 22 8 1 1 1 17 1 1 1 23 8 1 1 1 18 1 1 1 23 8 1 1 1 18 1 1 1 24"); return value; }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto b=n29(c,e); auto a=n51(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Path n63(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { auto a=n17(c,e); auto b=n63(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n64(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n61(Context& c, const Env& e) { auto a=n62(c,e); auto b=n64(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n65(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n60(Context& c, const Env& e) { auto a=n61(c,e); auto b=n65(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n59(Context& c, const Env& e) { auto a=n60(c,e); auto b=n66(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { std::vector<Path> pv{n59(c,e)}; std::vector<Space> sv{n67(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[15]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return iterate(c,e,n57(c,e),13,14,n58); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { return iterate(c,e,n55(c,e),12,13,n56); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { return iterate(c,e,n53(c,e),11,12,n54); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return iterate(c,e,n28(c,e),10,11,n52); }
static ZIPPY_NOINLINE Path n69(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { static const Space value=literal_text("36 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 9 1 1 1 3 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 4 8 1 1 1 10 1 1 1 5 8 1 1 1 11 1 1 1 5 8 1 1 1 11 1 1 1 6 8 1 1 1 12 1 1 1 1 8 1 1 1 12 1 1 1 6 8 1 1 1 13 1 1 1 7 8 1 1 1 13 1 1 1 8 8 1 1 1 14 1 1 1 8 8 1 1 1 14 1 1 1 9 8 1 1 1 15 1 1 1 9 8 1 1 1 15 1 1 1 10 8 1 1 1 16 1 1 1 10 8 1 1 1 16 1 1 1 11 8 1 1 1 17 1 1 1 11 8 1 1 1 17 1 1 1 12 8 1 1 1 18 1 1 1 7 8 1 1 1 18 1 1 1 12 8 1 1 1 19 1 1 1 13 8 1 1 1 19 1 1 1 14 8 1 1 1 20 1 1 1 14 8 1 1 1 20 1 1 1 15 8 1 1 1 21 1 1 1 15 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 17 8 1 1 1 23 1 1 1 17 8 1 1 1 23 1 1 1 18 8 1 1 1 24 1 1 1 13 8 1 1 1 24 1 1 1 18"); return value; }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { auto p=n69(c,e); return unwrap(n70(c,e),p); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n68(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { static const Space value=literal_text("12 4 1 1 1 1 4 1 1 1 3 4 1 1 1 5 4 1 1 1 7 4 1 1 1 9 4 1 1 1 11 4 1 1 1 13 4 1 1 1 15 4 1 1 1 17 4 1 1 1 19 4 1 1 1 21 4 1 1 1 23"); return value; }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n71(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto p=n24(c,e); return wrap(n25(c,e),p); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n23(c,e); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n72(c,e); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n73(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
