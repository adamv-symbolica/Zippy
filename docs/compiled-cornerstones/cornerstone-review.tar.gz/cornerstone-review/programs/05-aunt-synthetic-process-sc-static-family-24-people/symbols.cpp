#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Space n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n7(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { static const Space value=literal_text("36 2 2 3 2 2 13 2 4 5 2 4 11 2 5 16 2 5 21 2 6 2 2 6 7 2 7 3 2 7 10 2 8 6 2 8 18 2 9 10 2 9 21 2 11 16 2 11 17 2 12 13 2 12 17 2 14 6 2 14 15 2 15 2 2 15 12 2 18 7 2 18 9 2 19 18 2 19 20 2 20 5 2 20 9 2 22 4 2 22 20 2 23 15 2 23 25 2 24 4 2 24 25 2 25 11 2 25 12"); return value; }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto p=n15(c,e); return unwrap(n16(c,e),p); }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { static const Space value=literal_text("36 2 2 3 2 2 13 2 4 5 2 4 11 2 5 16 2 5 21 2 6 2 2 6 7 2 7 3 2 7 10 2 8 6 2 8 18 2 9 10 2 9 21 2 11 16 2 11 17 2 12 13 2 12 17 2 14 6 2 14 15 2 15 2 2 15 12 2 18 7 2 18 9 2 19 18 2 19 20 2 20 5 2 20 9 2 22 4 2 22 20 2 23 15 2 23 25 2 24 4 2 24 25 2 25 11 2 25 12"); return value; }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { auto b=n14(c,e); auto a=n17(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return tails_union(n13(c,e)); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { static const Space value=literal_text("36 2 2 6 2 2 15 2 3 2 2 3 7 2 4 22 2 4 24 2 5 4 2 5 20 2 6 8 2 6 14 2 7 6 2 7 18 2 9 18 2 9 20 2 10 7 2 10 9 2 11 4 2 11 25 2 12 15 2 12 25 2 13 2 2 13 12 2 15 14 2 15 23 2 16 5 2 16 11 2 17 11 2 17 12 2 18 8 2 18 19 2 20 19 2 20 22 2 21 5 2 21 9 2 25 23 2 25 24"); return value; }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { auto b=n12(c,e); auto a=n18(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return tails_union(n11(c,e)); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { static const Space value=literal_text("36 2 2 3 2 2 13 2 4 5 2 4 11 2 5 16 2 5 21 2 6 2 2 6 7 2 7 3 2 7 10 2 8 6 2 8 18 2 9 10 2 9 21 2 11 16 2 11 17 2 12 13 2 12 17 2 14 6 2 14 15 2 15 2 2 15 12 2 18 7 2 18 9 2 19 18 2 19 20 2 20 5 2 20 9 2 22 4 2 22 20 2 23 15 2 23 25 2 24 4 2 24 25 2 25 11 2 25 12"); return value; }
static ZIPPY_NOINLINE Space n19(Context& c, const Env& e) { auto p=n20(c,e); return unwrap(n21(c,e),p); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { auto a=n10(c,e); auto b=n19(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { static const Space value=literal_text("12 1 5 1 6 1 7 1 10 1 12 1 13 1 14 1 16 1 19 1 20 1 24 1 25"); return value; }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { auto a=n9(c,e); auto b=n22(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { auto p=n7(c,e); return wrap(n8(c,e),p); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),0,-1,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n2(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"25 1 4 65 117 110 116 2 4 112 49 95 51 3 4 112 48 95 51 4 4 112 50 95 53 5 4 112 49 95 48 6 4 112 50 95 50 7 4 112 49 95 50 8 4 112 51 95 49 9 4 112 49 95 49 10 4 112 48 95 50 11 4 112 49 95 53 12 4 112 49 95 52 13 4 112 48 95 52 14 4 112 51 95 50 15 4 112 50 95 51 16 4 112 48 95 48 17 4 112 48 95 53 18 4 112 50 95 49 19 4 112 51 95 48 20 4 112 50 95 48 21 4 112 48 95 49 22 4 112 51 95 53 23 4 112 51 95 51 24 4 112 51 95 52 25 4 112 50 95 52"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
