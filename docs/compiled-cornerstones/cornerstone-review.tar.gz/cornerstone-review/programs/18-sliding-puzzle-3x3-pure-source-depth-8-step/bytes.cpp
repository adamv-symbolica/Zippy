#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,2};
static const Path constant_1 = Path{1,1,1,1};
static const Space constant_2 = literal_text("13 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 4 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 4 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8");
static const Path constant_3 = Path{1,1,1,10};
static const Space constant_4 = literal_text("11 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 4 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8");
static const Path constant_5 = Path{1,1,1,11};
static const Space constant_6 = literal_text("17 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 4 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 1 1 1 5 28 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 5 1 1 1 8 28 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 4 1 1 1 9 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 5 1 1 1 7 1 1 1 4 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 7 1 1 1 6 1 1 1 3 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 5 1 1 1 8 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8");
static const Path constant_7 = Path{1,1,1,12};
static const Space constant_8 = literal_text("11 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 6 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Path constant_9 = Path{1,1,1,13};
static const Space constant_10 = literal_text("17 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 5 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 6 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 7 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 8 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 8 1 1 1 5 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6");
static const Path constant_11 = Path{1,1,1,14};
static const Space constant_12 = literal_text("10 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 5 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Path constant_13 = Path{1,1,1,15};
static const Space constant_14 = literal_text("13 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 4 1 1 1 9 1 1 1 5 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 4 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 4 1 1 1 3 1 1 1 8 1 1 1 9");
static const Path constant_15 = Path{1,1,1,16};
static const Space constant_16 = literal_text("9 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 4 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9");
static const Path constant_17 = Path{1,1,1,17};
static const Space constant_18 = literal_text("13 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 4 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 5 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 9 1 1 1 8 1 1 1 4 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 9 1 1 1 4 1 1 1 7 28 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 4 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 3 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 6 1 1 1 5 1 1 1 4 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9");
static const Path constant_19 = Path{1,1,1,3};
static const Space constant_20 = literal_text("5 28 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 5 1 1 1 8 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 6 1 1 1 2 1 1 1 8 1 1 1 5 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_21 = literal_text("1 28 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_22 = literal_text("1 28 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9");
static const Path constant_23 = Path{1,1,1,4};
static const Space constant_24 = literal_text("11 28 1 1 1 2 1 1 1 5 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 7 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 7 1 1 1 6 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 8 1 1 1 2 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 3 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_25 = literal_text("13 28 1 1 1 2 1 1 1 5 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 5 1 1 1 9 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 2 1 1 1 7 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 7 1 1 1 6 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 5 1 1 1 2 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 8 1 1 1 2 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 5 1 1 1 3 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_26 = literal_text("11 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 6 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 2 1 1 1 5 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 6 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_27 = literal_text("17 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 6 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 8 1 1 1 6 1 1 1 5 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 2 1 1 1 5 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 6 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 2 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 2 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 5 1 1 1 2 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 8 1 1 1 2 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 6");
static const Space constant_28 = literal_text("9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 5 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 2 1 1 1 8 1 1 1 5 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_29 = literal_text("17 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 8 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 9 1 1 1 6 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 9 1 1 1 8 1 1 1 5 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 5 1 1 1 8 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 5 1 1 1 9 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 5 1 1 1 9 28 1 1 1 2 1 1 1 5 1 1 1 7 1 1 1 6 1 1 1 3 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 8 1 1 1 2 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 5 1 1 1 2 1 1 1 8 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 5 1 1 1 3 1 1 1 8 1 1 1 9");
static const Space constant_30 = literal_text("10 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 9 1 1 1 8 1 1 1 5 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 5 1 1 1 8 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 8 1 1 1 2 1 1 1 7 1 1 1 9 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9");
static const Space constant_31 = literal_text("13 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 5 1 1 1 9 1 1 1 8 1 1 1 7 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 9 1 1 1 8 1 1 1 5 28 1 1 1 2 1 1 1 3 1 1 1 7 1 1 1 9 1 1 1 5 1 1 1 8 1 1 1 6 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 6 1 1 1 9 1 1 1 5 1 1 1 7 28 1 1 1 2 1 1 1 3 1 1 1 8 1 1 1 7 1 1 1 6 1 1 1 5 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 2 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 6 1 1 1 5 1 1 1 8 1 1 1 2 1 1 1 7 1 1 1 9 28 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 2 1 1 1 9 1 1 1 8 1 1 1 5 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 3 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 6 1 1 1 2 1 1 1 5 1 1 1 8 1 1 1 3 1 1 1 7 1 1 1 9");
static const Path constant_32 = Path{1,1,1,5};
static const Space constant_33 = literal_text("6 28 1 1 1 3 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 2 1 1 1 4 1 1 1 8 1 1 1 7 1 1 1 9 1 1 1 6 28 1 1 1 3 1 1 1 2 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 6 1 1 1 8 28 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 9 1 1 1 4 1 1 1 7 1 1 1 8 28 1 1 1 3 1 1 1 2 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 28 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9");
static const Space constant_34 = literal_text("2 28 1 1 1 3 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9");
static const Space constant_35 = literal_text("3 28 1 1 1 3 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9 28 1 1 1 4 1 1 1 2 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_36 = literal_text("2 28 1 1 1 4 1 1 1 2 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_37 = literal_text("5 28 1 1 1 3 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 2 1 1 1 6 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 6 1 1 1 8 1 1 1 2 1 1 1 9 28 1 1 1 8 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 4 1 1 1 7 1 1 1 9");
static const Space constant_38 = literal_text("2 28 1 1 1 3 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9");
static const Space constant_39 = literal_text("3 28 1 1 1 4 1 1 1 2 1 1 1 7 1 1 1 6 1 1 1 3 1 1 1 8 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 9");
static const Space constant_40 = literal_text("2 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 9");
static const Space constant_41 = literal_text("4 28 1 1 1 3 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 9 1 1 1 7 1 1 1 8 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 8 1 1 1 6 1 1 1 7 1 1 1 9 28 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 9");
static const Path constant_42 = Path{1,1,1,6};
static const Space constant_43 = literal_text("2 28 1 1 1 2 1 1 1 4 1 1 1 5 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9 28 1 1 1 5 1 1 1 2 1 1 1 4 1 1 1 3 1 1 1 7 1 1 1 8 1 1 1 9");
static const Path constant_44 = Path{1,1,1,7};
static const Space constant_45 = literal_text("1 28 1 1 1 4 1 1 1 3 1 1 1 2 1 1 1 6 1 1 1 8 1 1 1 5 1 1 1 9");
static const Space constant_46 = literal_text("1 28 1 1 1 4 1 1 1 3 1 1 1 8 1 1 1 2 1 1 1 6 1 1 1 5 1 1 1 9");
static const Space constant_47 = literal_text("1 4 1 1 1 1");
static const Space constant_48 = literal_text("1 4 1 1 1 10");
static const Space constant_49 = literal_text("1 4 1 1 1 11");
static const Space constant_50 = literal_text("1 4 1 1 1 12");
static const Space constant_51 = literal_text("1 4 1 1 1 13");
static const Space constant_52 = literal_text("1 4 1 1 1 14");
static const Space constant_53 = literal_text("1 4 1 1 1 15");
static const Space constant_54 = literal_text("1 4 1 1 1 16");
static const Space constant_55 = literal_text("1 4 1 1 1 17");
static const Path constant_56 = Path{1,1,1,18};
static const Space constant_57 = literal_text("2 8 1 1 1 1 1 1 1 12 8 1 1 1 12 1 1 1 1");
static const Space constant_58 = literal_text("2 8 1 1 1 10 1 1 1 13 8 1 1 1 13 1 1 1 10");
static const Space constant_59 = literal_text("2 8 1 1 1 11 1 1 1 14 8 1 1 1 14 1 1 1 11");
static const Space constant_60 = literal_text("2 8 1 1 1 12 1 1 1 15 8 1 1 1 15 1 1 1 12");
static const Space constant_61 = literal_text("2 8 1 1 1 13 1 1 1 16 8 1 1 1 16 1 1 1 13");
static const Space constant_62 = literal_text("2 8 1 1 1 14 1 1 1 17 8 1 1 1 17 1 1 1 14");
static const Path constant_63 = Path{1,1,1,19};
static const Space constant_64 = literal_text("2 8 1 1 1 1 1 1 1 10 8 1 1 1 10 1 1 1 1");
static const Space constant_65 = literal_text("2 8 1 1 1 10 1 1 1 11 8 1 1 1 11 1 1 1 10");
static const Space constant_66 = literal_text("2 8 1 1 1 12 1 1 1 13 8 1 1 1 13 1 1 1 12");
static const Space constant_67 = literal_text("2 8 1 1 1 13 1 1 1 14 8 1 1 1 14 1 1 1 13");
static const Space constant_68 = literal_text("2 8 1 1 1 15 1 1 1 16 8 1 1 1 16 1 1 1 15");
static const Space constant_69 = literal_text("2 8 1 1 1 16 1 1 1 17 8 1 1 1 17 1 1 1 16");
static const Path constant_70 = Path{1,1,1,20};
static const Path constant_71 = Path{1,1,1,21};
static const Space constant_72 = literal_text("9 8 1 1 1 1 1 1 1 1 8 1 1 1 10 1 1 1 10 8 1 1 1 11 1 1 1 11 8 1 1 1 12 1 1 1 12 8 1 1 1 13 1 1 1 13 8 1 1 1 14 1 1 1 14 8 1 1 1 15 1 1 1 15 8 1 1 1 16 1 1 1 16 8 1 1 1 17 1 1 1 17");
static const Space constant_73 = literal_text("1 8 1 1 1 1 1 1 1 22");
static const Space constant_74 = literal_text("1 8 1 1 1 10 1 1 1 22");
static const Space constant_75 = literal_text("1 8 1 1 1 11 1 1 1 22");
static const Space constant_76 = literal_text("1 8 1 1 1 12 1 1 1 22");
static const Space constant_77 = literal_text("1 8 1 1 1 13 1 1 1 22");
static const Space constant_78 = literal_text("1 8 1 1 1 14 1 1 1 22");
static const Space constant_79 = literal_text("1 8 1 1 1 15 1 1 1 22");
static const Space constant_80 = literal_text("1 8 1 1 1 16 1 1 1 22");
static const Space constant_81 = literal_text("1 8 1 1 1 17 1 1 1 22");
static Space routine_0(Context& c);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_6 = routine_1(c, constant_0, constant_3, constant_4);
  const Space v0_7 = unite(v0_3,v0_6);
  const Space v0_10 = routine_1(c, constant_0, constant_5, constant_6);
  const Space v0_11 = unite(v0_7,v0_10);
  const Space v0_14 = routine_1(c, constant_0, constant_7, constant_8);
  const Space v0_15 = unite(v0_11,v0_14);
  const Space v0_18 = routine_1(c, constant_0, constant_9, constant_10);
  const Space v0_19 = unite(v0_15,v0_18);
  const Space v0_22 = routine_1(c, constant_0, constant_11, constant_12);
  const Space v0_23 = unite(v0_19,v0_22);
  const Space v0_26 = routine_1(c, constant_0, constant_13, constant_14);
  const Space v0_27 = unite(v0_23,v0_26);
  const Space v0_30 = routine_1(c, constant_0, constant_15, constant_16);
  const Space v0_31 = unite(v0_27,v0_30);
  const Space v0_34 = routine_1(c, constant_0, constant_17, constant_18);
  const Space v0_35 = unite(v0_31,v0_34);
  const Space v0_38 = routine_1(c, constant_19, constant_1, constant_20);
  const Space v0_39 = unite(v0_35,v0_38);
  const Space v0_41 = routine_1(c, constant_19, constant_3, constant_21);
  const Space v0_42 = unite(v0_39,v0_41);
  const Space v0_44 = routine_1(c, constant_19, constant_5, constant_21);
  const Space v0_45 = unite(v0_42,v0_44);
  const Space v0_47 = routine_1(c, constant_19, constant_9, constant_22);
  const Space v0_48 = unite(v0_45,v0_47);
  const Space v0_51 = routine_1(c, constant_23, constant_1, constant_24);
  const Space v0_52 = unite(v0_48,v0_51);
  const Space v0_54 = routine_1(c, constant_23, constant_3, constant_24);
  const Space v0_55 = unite(v0_52,v0_54);
  const Space v0_57 = routine_1(c, constant_23, constant_5, constant_25);
  const Space v0_58 = unite(v0_55,v0_57);
  const Space v0_60 = routine_1(c, constant_23, constant_7, constant_26);
  const Space v0_61 = unite(v0_58,v0_60);
  const Space v0_63 = routine_1(c, constant_23, constant_9, constant_27);
  const Space v0_64 = unite(v0_61,v0_63);
  const Space v0_66 = routine_1(c, constant_23, constant_11, constant_28);
  const Space v0_67 = unite(v0_64,v0_66);
  const Space v0_69 = routine_1(c, constant_23, constant_13, constant_29);
  const Space v0_70 = unite(v0_67,v0_69);
  const Space v0_72 = routine_1(c, constant_23, constant_15, constant_30);
  const Space v0_73 = unite(v0_70,v0_72);
  const Space v0_75 = routine_1(c, constant_23, constant_17, constant_31);
  const Space v0_76 = unite(v0_73,v0_75);
  const Space v0_79 = routine_1(c, constant_32, constant_1, constant_33);
  const Space v0_80 = unite(v0_76,v0_79);
  const Space v0_82 = routine_1(c, constant_32, constant_3, constant_34);
  const Space v0_83 = unite(v0_80,v0_82);
  const Space v0_85 = routine_1(c, constant_32, constant_5, constant_35);
  const Space v0_86 = unite(v0_83,v0_85);
  const Space v0_88 = routine_1(c, constant_32, constant_7, constant_36);
  const Space v0_89 = unite(v0_86,v0_88);
  const Space v0_91 = routine_1(c, constant_32, constant_9, constant_37);
  const Space v0_92 = unite(v0_89,v0_91);
  const Space v0_94 = routine_1(c, constant_32, constant_11, constant_38);
  const Space v0_95 = unite(v0_92,v0_94);
  const Space v0_97 = routine_1(c, constant_32, constant_13, constant_39);
  const Space v0_98 = unite(v0_95,v0_97);
  const Space v0_100 = routine_1(c, constant_32, constant_15, constant_40);
  const Space v0_101 = unite(v0_98,v0_100);
  const Space v0_103 = routine_1(c, constant_32, constant_17, constant_41);
  const Space v0_104 = unite(v0_101,v0_103);
  const Space v0_107 = routine_1(c, constant_42, constant_1, constant_43);
  const Space v0_108 = unite(v0_104,v0_107);
  const Space v0_111 = routine_1(c, constant_44, constant_7, constant_45);
  const Space v0_112 = unite(v0_108,v0_111);
  const Space v0_114 = routine_1(c, constant_44, constant_9, constant_45);
  const Space v0_115 = unite(v0_112,v0_114);
  const Space v0_117 = routine_1(c, constant_44, constant_13, constant_46);
  const Space v0_118 = unite(v0_115,v0_117);
  return v0_118;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v1_3_branches = branches(c,s0);
  std::vector<Space> v1_3_outputs;
  v1_3_outputs.reserve(v1_3_branches.size());
  for (const auto& v1_3_branch : v1_3_branches) {
    const Path v1_3_head{v1_3_branch.first};
    const Space& v1_3_tail = v1_3_branch.second;
    const auto v2_2_branches = branches(c,v1_3_tail);
    std::vector<Space> v2_2_outputs;
    v2_2_outputs.reserve(v2_2_branches.size());
    for (const auto& v2_2_branch : v2_2_branches) {
      const Path v2_2_head{v2_2_branch.first};
      const Space& v2_2_tail = v2_2_branch.second;
      const Path v3_2 = concat_path(v1_3_head,v2_2_head);
      const auto v3_3_branches = branches(c,v2_2_tail);
      std::vector<Space> v3_3_outputs;
      v3_3_outputs.reserve(v3_3_branches.size());
      for (const auto& v3_3_branch : v3_3_branches) {
        const Path v3_3_head{v3_3_branch.first};
        const Space& v3_3_tail = v3_3_branch.second;
        const Path v4_2 = concat_path(v3_2,v3_3_head);
        const auto v4_3_branches = branches(c,v3_3_tail);
        std::vector<Space> v4_3_outputs;
        v4_3_outputs.reserve(v4_3_branches.size());
        for (const auto& v4_3_branch : v4_3_branches) {
          const Path v4_3_head{v4_3_branch.first};
          const Space& v4_3_tail = v4_3_branch.second;
          const Path v5_2 = concat_path(v4_2,v4_3_head);
          const auto v5_3_branches = branches(c,v4_3_tail);
          std::vector<Space> v5_3_outputs;
          v5_3_outputs.reserve(v5_3_branches.size());
          for (const auto& v5_3_branch : v5_3_branches) {
            const Path v5_3_head{v5_3_branch.first};
            const Space& v5_3_tail = v5_3_branch.second;
            const auto v6_2_branches = branches(c,v5_3_tail);
            std::vector<Space> v6_2_outputs;
            v6_2_outputs.reserve(v6_2_branches.size());
            for (const auto& v6_2_branch : v6_2_branches) {
              const Path v6_2_head{v6_2_branch.first};
              const Space& v6_2_tail = v6_2_branch.second;
              const Path v7_2 = concat_path(v5_3_head,v6_2_head);
              const auto v7_3_branches = branches(c,v6_2_tail);
              std::vector<Space> v7_3_outputs;
              v7_3_outputs.reserve(v7_3_branches.size());
              for (const auto& v7_3_branch : v7_3_branches) {
                const Path v7_3_head{v7_3_branch.first};
                const Space& v7_3_tail = v7_3_branch.second;
                const Path v8_2 = concat_path(v7_2,v7_3_head);
                const auto v8_3_branches = branches(c,v7_3_tail);
                std::vector<Space> v8_3_outputs;
                v8_3_outputs.reserve(v8_3_branches.size());
                for (const auto& v8_3_branch : v8_3_branches) {
                  const Path v8_3_head{v8_3_branch.first};
                  const Space& v8_3_tail = v8_3_branch.second;
                  const Path v9_2 = concat_path(v8_2,v8_3_head);
                  const Space v9_3 = routine_2(c, v9_2, p1, p0, v5_2, v8_3_tail);
                  v8_3_outputs.push_back(v9_3);
                }
                const Space v8_3 = join_outputs(std::move(v8_3_outputs));
                v7_3_outputs.push_back(v8_3);
              }
              const Space v7_3 = join_outputs(std::move(v7_3_outputs));
              v6_2_outputs.push_back(v7_3);
            }
            const Space v6_2 = join_outputs(std::move(v6_2_outputs));
            v5_3_outputs.push_back(v6_2);
          }
          const Space v5_3 = join_outputs(std::move(v5_3_outputs));
          v4_3_outputs.push_back(v5_3);
        }
        const Space v4_3 = join_outputs(std::move(v4_3_outputs));
        v3_3_outputs.push_back(v4_3);
      }
      const Space v3_3 = join_outputs(std::move(v3_3_outputs));
      v2_2_outputs.push_back(v3_3);
    }
    const Space v2_2 = join_outputs(std::move(v2_2_outputs));
    v1_3_outputs.push_back(v2_2);
  }
  const Space v1_3 = join_outputs(std::move(v1_3_outputs));
  return v1_3;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v10_5_branches = branches(c,s0);
  std::vector<Space> v10_5_outputs;
  v10_5_outputs.reserve(v10_5_branches.size());
  for (const auto& v10_5_branch : v10_5_branches) {
    const Path v10_5_head{v10_5_branch.first};
    const Space& v10_5_tail = v10_5_branch.second;
    const auto v11_2_branches = branches(c,v10_5_tail);
    std::vector<Space> v11_2_outputs;
    v11_2_outputs.reserve(v11_2_branches.size());
    for (const auto& v11_2_branch : v11_2_branches) {
      const Path v11_2_head{v11_2_branch.first};
      const Space& v11_2_tail = v11_2_branch.second;
      const Path v12_2 = concat_path(v10_5_head,v11_2_head);
      const auto v12_3_branches = branches(c,v11_2_tail);
      std::vector<Space> v12_3_outputs;
      v12_3_outputs.reserve(v12_3_branches.size());
      for (const auto& v12_3_branch : v12_3_branches) {
        const Path v12_3_head{v12_3_branch.first};
        const Space& v12_3_tail = v12_3_branch.second;
        const Path v13_2 = concat_path(v12_2,v12_3_head);
        const auto v13_3_branches = branches(c,v12_3_tail);
        std::vector<Space> v13_3_outputs;
        v13_3_outputs.reserve(v13_3_branches.size());
        for (const auto& v13_3_branch : v13_3_branches) {
          const Path v13_3_head{v13_3_branch.first};
          const Space& v13_3_tail = v13_3_branch.second;
          const Path v14_2 = concat_path(v13_2,v13_3_head);
          const auto v14_3_branches = branches(c,v13_3_tail);
          std::vector<Space> v14_3_outputs;
          v14_3_outputs.reserve(v14_3_branches.size());
          for (const auto& v14_3_branch : v14_3_branches) {
            const Path v14_3_head{v14_3_branch.first};
            const Space& v14_3_tail = v14_3_branch.second;
            const auto v15_2_branches = branches(c,v14_3_tail);
            std::vector<Space> v15_2_outputs;
            v15_2_outputs.reserve(v15_2_branches.size());
            for (const auto& v15_2_branch : v15_2_branches) {
              const Path v15_2_head{v15_2_branch.first};
              const Space& v15_2_tail = v15_2_branch.second;
              const Path v16_2 = concat_path(v14_3_head,v15_2_head);
              const auto v16_3_branches = branches(c,v15_2_tail);
              std::vector<Space> v16_3_outputs;
              v16_3_outputs.reserve(v16_3_branches.size());
              for (const auto& v16_3_branch : v16_3_branches) {
                const Path v16_3_head{v16_3_branch.first};
                const Space& v16_3_tail = v16_3_branch.second;
                const Path v17_2 = concat_path(v16_2,v16_3_head);
                const auto v17_3_branches = branches(c,v16_3_tail);
                std::vector<Space> v17_3_outputs;
                v17_3_outputs.reserve(v17_3_branches.size());
                for (const auto& v17_3_branch : v17_3_branches) {
                  const Path v17_3_head{v17_3_branch.first};
                  const Space& v17_3_tail = v17_3_branch.second;
                  const Path v18_2 = concat_path(v17_2,v17_3_head);
                  const Space v18_3 = routine_3(c, v18_2, p1, p2, p3, p0, v14_2, v17_3_tail);
                  v17_3_outputs.push_back(v18_3);
                }
                const Space v17_3 = join_outputs(std::move(v17_3_outputs));
                v16_3_outputs.push_back(v17_3);
              }
              const Space v16_3 = join_outputs(std::move(v16_3_outputs));
              v15_2_outputs.push_back(v16_3);
            }
            const Space v15_2 = join_outputs(std::move(v15_2_outputs));
            v14_3_outputs.push_back(v15_2);
          }
          const Space v14_3 = join_outputs(std::move(v14_3_outputs));
          v13_3_outputs.push_back(v14_3);
        }
        const Space v13_3 = join_outputs(std::move(v13_3_outputs));
        v12_3_outputs.push_back(v13_3);
      }
      const Space v12_3 = join_outputs(std::move(v12_3_outputs));
      v11_2_outputs.push_back(v12_3);
    }
    const Space v11_2 = join_outputs(std::move(v11_2_outputs));
    v10_5_outputs.push_back(v11_2);
  }
  const Space v10_5 = join_outputs(std::move(v10_5_outputs));
  return v10_5;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v19_7_branches = branches(c,s0);
  std::vector<Space> v19_7_outputs;
  v19_7_outputs.reserve(v19_7_branches.size());
  for (const auto& v19_7_branch : v19_7_branches) {
    const Path v19_7_head{v19_7_branch.first};
    const Space& v19_7_tail = v19_7_branch.second;
    const auto v20_2_branches = branches(c,v19_7_tail);
    std::vector<Space> v20_2_outputs;
    v20_2_outputs.reserve(v20_2_branches.size());
    for (const auto& v20_2_branch : v20_2_branches) {
      const Path v20_2_head{v20_2_branch.first};
      const Space& v20_2_tail = v20_2_branch.second;
      const Path v21_2 = concat_path(v19_7_head,v20_2_head);
      const auto v21_3_branches = branches(c,v20_2_tail);
      std::vector<Space> v21_3_outputs;
      v21_3_outputs.reserve(v21_3_branches.size());
      for (const auto& v21_3_branch : v21_3_branches) {
        const Path v21_3_head{v21_3_branch.first};
        const Space& v21_3_tail = v21_3_branch.second;
        const Path v22_2 = concat_path(v21_2,v21_3_head);
        const auto v22_3_branches = branches(c,v21_3_tail);
        std::vector<Space> v22_3_outputs;
        v22_3_outputs.reserve(v22_3_branches.size());
        for (const auto& v22_3_branch : v22_3_branches) {
          const Path v22_3_head{v22_3_branch.first};
          const Space& v22_3_tail = v22_3_branch.second;
          const Path v23_2 = concat_path(v22_2,v22_3_head);
          const auto v23_3_branches = branches(c,v22_3_tail);
          std::vector<Space> v23_3_outputs;
          v23_3_outputs.reserve(v23_3_branches.size());
          for (const auto& v23_3_branch : v23_3_branches) {
            const Path v23_3_head{v23_3_branch.first};
            const Space& v23_3_tail = v23_3_branch.second;
            const auto v24_2_branches = branches(c,v23_3_tail);
            std::vector<Space> v24_2_outputs;
            v24_2_outputs.reserve(v24_2_branches.size());
            for (const auto& v24_2_branch : v24_2_branches) {
              const Path v24_2_head{v24_2_branch.first};
              const Space& v24_2_tail = v24_2_branch.second;
              const Path v25_2 = concat_path(v23_3_head,v24_2_head);
              const auto v25_3_branches = branches(c,v24_2_tail);
              std::vector<Space> v25_3_outputs;
              v25_3_outputs.reserve(v25_3_branches.size());
              for (const auto& v25_3_branch : v25_3_branches) {
                const Path v25_3_head{v25_3_branch.first};
                const Space& v25_3_tail = v25_3_branch.second;
                const Path v26_2 = concat_path(v25_2,v25_3_head);
                const auto v26_3_branches = branches(c,v25_3_tail);
                std::vector<Space> v26_3_outputs;
                v26_3_outputs.reserve(v26_3_branches.size());
                for (const auto& v26_3_branch : v26_3_branches) {
                  const Path v26_3_head{v26_3_branch.first};
                  const Space& v26_3_tail = v26_3_branch.second;
                  const Path v27_2 = concat_path(v26_2,v26_3_head);
                  const Space v27_3 = routine_4(c, v27_2, p1, p2, p3, p4, p5, p0, v23_2, v26_3_tail);
                  v26_3_outputs.push_back(v27_3);
                }
                const Space v26_3 = join_outputs(std::move(v26_3_outputs));
                v25_3_outputs.push_back(v26_3);
              }
              const Space v25_3 = join_outputs(std::move(v25_3_outputs));
              v24_2_outputs.push_back(v25_3);
            }
            const Space v24_2 = join_outputs(std::move(v24_2_outputs));
            v23_3_outputs.push_back(v24_2);
          }
          const Space v23_3 = join_outputs(std::move(v23_3_outputs));
          v22_3_outputs.push_back(v23_3);
        }
        const Space v22_3 = join_outputs(std::move(v22_3_outputs));
        v21_3_outputs.push_back(v22_3);
      }
      const Space v21_3 = join_outputs(std::move(v21_3_outputs));
      v20_2_outputs.push_back(v21_3);
    }
    const Space v20_2 = join_outputs(std::move(v20_2_outputs));
    v19_7_outputs.push_back(v20_2);
  }
  const Space v19_7 = join_outputs(std::move(v19_7_outputs));
  return v19_7;
}

static Space routine_4(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v28_9 = concat_path(p2,p3);
  const Path v28_10 = concat_path(v28_9,p4);
  const Path v28_11 = concat_path(v28_10,p5);
  const Path v28_12 = concat_path(v28_11,p6);
  const Path v28_13 = concat_path(v28_12,p7);
  const Path v28_14 = concat_path(v28_13,p0);
  const auto v28_15_branches = branches(c,s0);
  std::vector<Space> v28_15_outputs;
  v28_15_outputs.reserve(v28_15_branches.size());
  for (const auto& v28_15_branch : v28_15_branches) {
    const Path v28_15_head{v28_15_branch.first};
    const Space& v28_15_tail = v28_15_branch.second;
    const auto v29_2_branches = branches(c,v28_15_tail);
    std::vector<Space> v29_2_outputs;
    v29_2_outputs.reserve(v29_2_branches.size());
    for (const auto& v29_2_branch : v29_2_branches) {
      const Path v29_2_head{v29_2_branch.first};
      const Space& v29_2_tail = v29_2_branch.second;
      const Path v30_2 = concat_path(v28_15_head,v29_2_head);
      const auto v30_3_branches = branches(c,v29_2_tail);
      std::vector<Space> v30_3_outputs;
      v30_3_outputs.reserve(v30_3_branches.size());
      for (const auto& v30_3_branch : v30_3_branches) {
        const Path v30_3_head{v30_3_branch.first};
        const Space& v30_3_tail = v30_3_branch.second;
        const Path v31_2 = concat_path(v30_2,v30_3_head);
        const auto v31_3_branches = branches(c,v30_3_tail);
        std::vector<Space> v31_3_outputs;
        v31_3_outputs.reserve(v31_3_branches.size());
        for (const auto& v31_3_branch : v31_3_branches) {
          const Path v31_3_head{v31_3_branch.first};
          const Space& v31_3_tail = v31_3_branch.second;
          const Path v32_2 = concat_path(v31_2,v31_3_head);
          const Path v32_3 = concat_path(v28_14,v32_2);
          const Space v32_4 = singleton(v32_3);
          const Space v32_5 = routine_5(c, p1, v32_4);
          const auto v32_6_branches = branches(c,v32_5);
          std::vector<Space> v32_6_outputs;
          v32_6_outputs.reserve(v32_6_branches.size());
          for (const auto& v32_6_branch : v32_6_branches) {
            const Path v32_6_head{v32_6_branch.first};
            const Space& v32_6_tail = v32_6_branch.second;
            const auto v33_2_branches = branches(c,v32_6_tail);
            std::vector<Space> v33_2_outputs;
            v33_2_outputs.reserve(v33_2_branches.size());
            for (const auto& v33_2_branch : v33_2_branches) {
              const Path v33_2_head{v33_2_branch.first};
              const Space& v33_2_tail = v33_2_branch.second;
              const Path v34_2 = concat_path(v32_6_head,v33_2_head);
              const auto v34_3_branches = branches(c,v33_2_tail);
              std::vector<Space> v34_3_outputs;
              v34_3_outputs.reserve(v34_3_branches.size());
              for (const auto& v34_3_branch : v34_3_branches) {
                const Path v34_3_head{v34_3_branch.first};
                const Space& v34_3_tail = v34_3_branch.second;
                const Path v35_2 = concat_path(v34_2,v34_3_head);
                const auto v35_3_branches = branches(c,v34_3_tail);
                std::vector<Space> v35_3_outputs;
                v35_3_outputs.reserve(v35_3_branches.size());
                for (const auto& v35_3_branch : v35_3_branches) {
                  const Path v35_3_head{v35_3_branch.first};
                  const Space& v35_3_tail = v35_3_branch.second;
                  const Path v36_2 = concat_path(v35_2,v35_3_head);
                  const Space v36_3 = routine_6(c, v36_2, p1, v35_3_tail);
                  v35_3_outputs.push_back(v36_3);
                }
                const Space v35_3 = join_outputs(std::move(v35_3_outputs));
                v34_3_outputs.push_back(v35_3);
              }
              const Space v34_3 = join_outputs(std::move(v34_3_outputs));
              v33_2_outputs.push_back(v34_3);
            }
            const Space v33_2 = join_outputs(std::move(v33_2_outputs));
            v32_6_outputs.push_back(v33_2);
          }
          const Space v32_6 = join_outputs(std::move(v32_6_outputs));
          const auto v32_7_branches = branches(c,v32_6);
          std::vector<Space> v32_7_outputs;
          v32_7_outputs.reserve(v32_7_branches.size());
          for (const auto& v32_7_branch : v32_7_branches) {
            const Path v32_7_head{v32_7_branch.first};
            const Space& v32_7_tail = v32_7_branch.second;
            const auto v37_2_branches = branches(c,v32_7_tail);
            std::vector<Space> v37_2_outputs;
            v37_2_outputs.reserve(v37_2_branches.size());
            for (const auto& v37_2_branch : v37_2_branches) {
              const Path v37_2_head{v37_2_branch.first};
              const Space& v37_2_tail = v37_2_branch.second;
              const Path v38_2 = concat_path(v32_7_head,v37_2_head);
              const auto v38_3_branches = branches(c,v37_2_tail);
              std::vector<Space> v38_3_outputs;
              v38_3_outputs.reserve(v38_3_branches.size());
              for (const auto& v38_3_branch : v38_3_branches) {
                const Path v38_3_head{v38_3_branch.first};
                const Space& v38_3_tail = v38_3_branch.second;
                const Path v39_2 = concat_path(v38_2,v38_3_head);
                const auto v39_3_branches = branches(c,v38_3_tail);
                std::vector<Space> v39_3_outputs;
                v39_3_outputs.reserve(v39_3_branches.size());
                for (const auto& v39_3_branch : v39_3_branches) {
                  const Path v39_3_head{v39_3_branch.first};
                  const Space& v39_3_tail = v39_3_branch.second;
                  const Path v40_2 = concat_path(v39_2,v39_3_head);
                  const Space v40_3 = routine_7(c, v40_2, p1, v39_3_tail);
                  v39_3_outputs.push_back(v40_3);
                }
                const Space v39_3 = join_outputs(std::move(v39_3_outputs));
                v38_3_outputs.push_back(v39_3);
              }
              const Space v38_3 = join_outputs(std::move(v38_3_outputs));
              v37_2_outputs.push_back(v38_3);
            }
            const Space v37_2 = join_outputs(std::move(v37_2_outputs));
            v32_7_outputs.push_back(v37_2);
          }
          const Space v32_7 = join_outputs(std::move(v32_7_outputs));
          v31_3_outputs.push_back(v32_7);
        }
        const Space v31_3 = join_outputs(std::move(v31_3_outputs));
        v30_3_outputs.push_back(v31_3);
      }
      const Space v30_3 = join_outputs(std::move(v30_3_outputs));
      v29_2_outputs.push_back(v30_3);
    }
    const Space v29_2 = join_outputs(std::move(v29_2_outputs));
    v28_15_outputs.push_back(v29_2);
  }
  const Space v28_15 = join_outputs(std::move(v28_15_outputs));
  return v28_15;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  const Space v41_3 = singleton(p0);
  const Space v41_4 = intersect(constant_47,v41_3);
  const auto v41_5_branches = branches(c,v41_4);
  std::vector<Space> v41_5_outputs;
  v41_5_outputs.reserve(v41_5_branches.size());
  for (const auto& v41_5_branch : v41_5_branches) {
    const Path v41_5_head{v41_5_branch.first};
    const Space& v41_5_tail = v41_5_branch.second;
    const auto v42_2_branches = branches(c,v41_5_tail);
    std::vector<Space> v42_2_outputs;
    v42_2_outputs.reserve(v42_2_branches.size());
    for (const auto& v42_2_branch : v42_2_branches) {
      const Path v42_2_head{v42_2_branch.first};
      const Space& v42_2_tail = v42_2_branch.second;
      const auto v43_2_branches = branches(c,v42_2_tail);
      std::vector<Space> v43_2_outputs;
      v43_2_outputs.reserve(v43_2_branches.size());
      for (const auto& v43_2_branch : v43_2_branches) {
        const Path v43_2_head{v43_2_branch.first};
        const Space& v43_2_tail = v43_2_branch.second;
        const Space v44_2 = tails_union(v43_2_tail);
        v43_2_outputs.push_back(v44_2);
      }
      const Space v43_2 = join_outputs(std::move(v43_2_outputs));
      v42_2_outputs.push_back(v43_2);
    }
    const Space v42_2 = join_outputs(std::move(v42_2_outputs));
    v41_5_outputs.push_back(v42_2);
  }
  const Space v41_5 = join_outputs(std::move(v41_5_outputs));
  Space v41_7;
  if (!v41_5.empty()) {
    const auto v45_6_branches = branches(c,s0);
    std::vector<Space> v45_6_outputs;
    v45_6_outputs.reserve(v45_6_branches.size());
    for (const auto& v45_6_branch : v45_6_branches) {
      const Path v45_6_head{v45_6_branch.first};
      const Space& v45_6_tail = v45_6_branch.second;
      const auto v46_2_branches = branches(c,v45_6_tail);
      std::vector<Space> v46_2_outputs;
      v46_2_outputs.reserve(v46_2_branches.size());
      for (const auto& v46_2_branch : v46_2_branches) {
        const Path v46_2_head{v46_2_branch.first};
        const Space& v46_2_tail = v46_2_branch.second;
        const Path v47_2 = concat_path(v45_6_head,v46_2_head);
        const auto v47_3_branches = branches(c,v46_2_tail);
        std::vector<Space> v47_3_outputs;
        v47_3_outputs.reserve(v47_3_branches.size());
        for (const auto& v47_3_branch : v47_3_branches) {
          const Path v47_3_head{v47_3_branch.first};
          const Space& v47_3_tail = v47_3_branch.second;
          const Path v48_2 = concat_path(v47_2,v47_3_head);
          const auto v48_3_branches = branches(c,v47_3_tail);
          std::vector<Space> v48_3_outputs;
          v48_3_outputs.reserve(v48_3_branches.size());
          for (const auto& v48_3_branch : v48_3_branches) {
            const Path v48_3_head{v48_3_branch.first};
            const Space& v48_3_tail = v48_3_branch.second;
            const Path v49_2 = concat_path(v48_2,v48_3_head);
            const auto v49_3_branches = branches(c,v48_3_tail);
            std::vector<Space> v49_3_outputs;
            v49_3_outputs.reserve(v49_3_branches.size());
            for (const auto& v49_3_branch : v49_3_branches) {
              const Path v49_3_head{v49_3_branch.first};
              const Space& v49_3_tail = v49_3_branch.second;
              const auto v50_2_branches = branches(c,v49_3_tail);
              std::vector<Space> v50_2_outputs;
              v50_2_outputs.reserve(v50_2_branches.size());
              for (const auto& v50_2_branch : v50_2_branches) {
                const Path v50_2_head{v50_2_branch.first};
                const Space& v50_2_tail = v50_2_branch.second;
                const Path v51_2 = concat_path(v49_3_head,v50_2_head);
                const auto v51_3_branches = branches(c,v50_2_tail);
                std::vector<Space> v51_3_outputs;
                v51_3_outputs.reserve(v51_3_branches.size());
                for (const auto& v51_3_branch : v51_3_branches) {
                  const Path v51_3_head{v51_3_branch.first};
                  const Space& v51_3_tail = v51_3_branch.second;
                  const Path v52_2 = concat_path(v51_2,v51_3_head);
                  const auto v52_3_branches = branches(c,v51_3_tail);
                  std::vector<Space> v52_3_outputs;
                  v52_3_outputs.reserve(v52_3_branches.size());
                  for (const auto& v52_3_branch : v52_3_branches) {
                    const Path v52_3_head{v52_3_branch.first};
                    const Space& v52_3_tail = v52_3_branch.second;
                    const Path v53_2 = concat_path(v52_2,v52_3_head);
                    const Space v53_3 = routine_8(c, v53_2, v49_2, v52_3_tail);
                    v52_3_outputs.push_back(v53_3);
                  }
                  const Space v52_3 = join_outputs(std::move(v52_3_outputs));
                  v51_3_outputs.push_back(v52_3);
                }
                const Space v51_3 = join_outputs(std::move(v51_3_outputs));
                v50_2_outputs.push_back(v51_3);
              }
              const Space v50_2 = join_outputs(std::move(v50_2_outputs));
              v49_3_outputs.push_back(v50_2);
            }
            const Space v49_3 = join_outputs(std::move(v49_3_outputs));
            v48_3_outputs.push_back(v49_3);
          }
          const Space v48_3 = join_outputs(std::move(v48_3_outputs));
          v47_3_outputs.push_back(v48_3);
        }
        const Space v47_3 = join_outputs(std::move(v47_3_outputs));
        v46_2_outputs.push_back(v47_3);
      }
      const Space v46_2 = join_outputs(std::move(v46_2_outputs));
      v45_6_outputs.push_back(v46_2);
    }
    const Space v45_6 = join_outputs(std::move(v45_6_outputs));
    v41_7 = compose(v41_5,v45_6);
  }
  const Space v41_9 = intersect(constant_48,v41_3);
  const auto v41_10_branches = branches(c,v41_9);
  std::vector<Space> v41_10_outputs;
  v41_10_outputs.reserve(v41_10_branches.size());
  for (const auto& v41_10_branch : v41_10_branches) {
    const Path v41_10_head{v41_10_branch.first};
    const Space& v41_10_tail = v41_10_branch.second;
    const auto v54_2_branches = branches(c,v41_10_tail);
    std::vector<Space> v54_2_outputs;
    v54_2_outputs.reserve(v54_2_branches.size());
    for (const auto& v54_2_branch : v54_2_branches) {
      const Path v54_2_head{v54_2_branch.first};
      const Space& v54_2_tail = v54_2_branch.second;
      const auto v55_2_branches = branches(c,v54_2_tail);
      std::vector<Space> v55_2_outputs;
      v55_2_outputs.reserve(v55_2_branches.size());
      for (const auto& v55_2_branch : v55_2_branches) {
        const Path v55_2_head{v55_2_branch.first};
        const Space& v55_2_tail = v55_2_branch.second;
        const Space v56_2 = tails_union(v55_2_tail);
        v55_2_outputs.push_back(v56_2);
      }
      const Space v55_2 = join_outputs(std::move(v55_2_outputs));
      v54_2_outputs.push_back(v55_2);
    }
    const Space v54_2 = join_outputs(std::move(v54_2_outputs));
    v41_10_outputs.push_back(v54_2);
  }
  const Space v41_10 = join_outputs(std::move(v41_10_outputs));
  Space v41_12;
  if (!v41_10.empty()) {
    const auto v57_11_branches = branches(c,s0);
    std::vector<Space> v57_11_outputs;
    v57_11_outputs.reserve(v57_11_branches.size());
    for (const auto& v57_11_branch : v57_11_branches) {
      const Path v57_11_head{v57_11_branch.first};
      const Space& v57_11_tail = v57_11_branch.second;
      const auto v58_2_branches = branches(c,v57_11_tail);
      std::vector<Space> v58_2_outputs;
      v58_2_outputs.reserve(v58_2_branches.size());
      for (const auto& v58_2_branch : v58_2_branches) {
        const Path v58_2_head{v58_2_branch.first};
        const Space& v58_2_tail = v58_2_branch.second;
        const Path v59_2 = concat_path(v57_11_head,v58_2_head);
        const auto v59_3_branches = branches(c,v58_2_tail);
        std::vector<Space> v59_3_outputs;
        v59_3_outputs.reserve(v59_3_branches.size());
        for (const auto& v59_3_branch : v59_3_branches) {
          const Path v59_3_head{v59_3_branch.first};
          const Space& v59_3_tail = v59_3_branch.second;
          const Path v60_2 = concat_path(v59_2,v59_3_head);
          const auto v60_3_branches = branches(c,v59_3_tail);
          std::vector<Space> v60_3_outputs;
          v60_3_outputs.reserve(v60_3_branches.size());
          for (const auto& v60_3_branch : v60_3_branches) {
            const Path v60_3_head{v60_3_branch.first};
            const Space& v60_3_tail = v60_3_branch.second;
            const Path v61_2 = concat_path(v60_2,v60_3_head);
            const auto v61_3_branches = branches(c,v60_3_tail);
            std::vector<Space> v61_3_outputs;
            v61_3_outputs.reserve(v61_3_branches.size());
            for (const auto& v61_3_branch : v61_3_branches) {
              const Path v61_3_head{v61_3_branch.first};
              const Space& v61_3_tail = v61_3_branch.second;
              const auto v62_2_branches = branches(c,v61_3_tail);
              std::vector<Space> v62_2_outputs;
              v62_2_outputs.reserve(v62_2_branches.size());
              for (const auto& v62_2_branch : v62_2_branches) {
                const Path v62_2_head{v62_2_branch.first};
                const Space& v62_2_tail = v62_2_branch.second;
                const Path v63_2 = concat_path(v61_3_head,v62_2_head);
                const auto v63_3_branches = branches(c,v62_2_tail);
                std::vector<Space> v63_3_outputs;
                v63_3_outputs.reserve(v63_3_branches.size());
                for (const auto& v63_3_branch : v63_3_branches) {
                  const Path v63_3_head{v63_3_branch.first};
                  const Space& v63_3_tail = v63_3_branch.second;
                  const Path v64_2 = concat_path(v63_2,v63_3_head);
                  const auto v64_3_branches = branches(c,v63_3_tail);
                  std::vector<Space> v64_3_outputs;
                  v64_3_outputs.reserve(v64_3_branches.size());
                  for (const auto& v64_3_branch : v64_3_branches) {
                    const Path v64_3_head{v64_3_branch.first};
                    const Space& v64_3_tail = v64_3_branch.second;
                    const Path v65_2 = concat_path(v64_2,v64_3_head);
                    const Space v65_3 = routine_9(c, v65_2, v61_2, v64_3_tail);
                    v64_3_outputs.push_back(v65_3);
                  }
                  const Space v64_3 = join_outputs(std::move(v64_3_outputs));
                  v63_3_outputs.push_back(v64_3);
                }
                const Space v63_3 = join_outputs(std::move(v63_3_outputs));
                v62_2_outputs.push_back(v63_3);
              }
              const Space v62_2 = join_outputs(std::move(v62_2_outputs));
              v61_3_outputs.push_back(v62_2);
            }
            const Space v61_3 = join_outputs(std::move(v61_3_outputs));
            v60_3_outputs.push_back(v61_3);
          }
          const Space v60_3 = join_outputs(std::move(v60_3_outputs));
          v59_3_outputs.push_back(v60_3);
        }
        const Space v59_3 = join_outputs(std::move(v59_3_outputs));
        v58_2_outputs.push_back(v59_3);
      }
      const Space v58_2 = join_outputs(std::move(v58_2_outputs));
      v57_11_outputs.push_back(v58_2);
    }
    const Space v57_11 = join_outputs(std::move(v57_11_outputs));
    v41_12 = compose(v41_10,v57_11);
  }
  const Space v41_13 = unite(v41_7,v41_12);
  const Space v41_15 = intersect(constant_49,v41_3);
  const auto v41_16_branches = branches(c,v41_15);
  std::vector<Space> v41_16_outputs;
  v41_16_outputs.reserve(v41_16_branches.size());
  for (const auto& v41_16_branch : v41_16_branches) {
    const Path v41_16_head{v41_16_branch.first};
    const Space& v41_16_tail = v41_16_branch.second;
    const auto v66_2_branches = branches(c,v41_16_tail);
    std::vector<Space> v66_2_outputs;
    v66_2_outputs.reserve(v66_2_branches.size());
    for (const auto& v66_2_branch : v66_2_branches) {
      const Path v66_2_head{v66_2_branch.first};
      const Space& v66_2_tail = v66_2_branch.second;
      const auto v67_2_branches = branches(c,v66_2_tail);
      std::vector<Space> v67_2_outputs;
      v67_2_outputs.reserve(v67_2_branches.size());
      for (const auto& v67_2_branch : v67_2_branches) {
        const Path v67_2_head{v67_2_branch.first};
        const Space& v67_2_tail = v67_2_branch.second;
        const Space v68_2 = tails_union(v67_2_tail);
        v67_2_outputs.push_back(v68_2);
      }
      const Space v67_2 = join_outputs(std::move(v67_2_outputs));
      v66_2_outputs.push_back(v67_2);
    }
    const Space v66_2 = join_outputs(std::move(v66_2_outputs));
    v41_16_outputs.push_back(v66_2);
  }
  const Space v41_16 = join_outputs(std::move(v41_16_outputs));
  Space v41_18;
  if (!v41_16.empty()) {
    const auto v69_17_branches = branches(c,s0);
    std::vector<Space> v69_17_outputs;
    v69_17_outputs.reserve(v69_17_branches.size());
    for (const auto& v69_17_branch : v69_17_branches) {
      const Path v69_17_head{v69_17_branch.first};
      const Space& v69_17_tail = v69_17_branch.second;
      const auto v70_2_branches = branches(c,v69_17_tail);
      std::vector<Space> v70_2_outputs;
      v70_2_outputs.reserve(v70_2_branches.size());
      for (const auto& v70_2_branch : v70_2_branches) {
        const Path v70_2_head{v70_2_branch.first};
        const Space& v70_2_tail = v70_2_branch.second;
        const Path v71_2 = concat_path(v69_17_head,v70_2_head);
        const auto v71_3_branches = branches(c,v70_2_tail);
        std::vector<Space> v71_3_outputs;
        v71_3_outputs.reserve(v71_3_branches.size());
        for (const auto& v71_3_branch : v71_3_branches) {
          const Path v71_3_head{v71_3_branch.first};
          const Space& v71_3_tail = v71_3_branch.second;
          const Path v72_2 = concat_path(v71_2,v71_3_head);
          const auto v72_3_branches = branches(c,v71_3_tail);
          std::vector<Space> v72_3_outputs;
          v72_3_outputs.reserve(v72_3_branches.size());
          for (const auto& v72_3_branch : v72_3_branches) {
            const Path v72_3_head{v72_3_branch.first};
            const Space& v72_3_tail = v72_3_branch.second;
            const Path v73_2 = concat_path(v72_2,v72_3_head);
            const auto v73_3_branches = branches(c,v72_3_tail);
            std::vector<Space> v73_3_outputs;
            v73_3_outputs.reserve(v73_3_branches.size());
            for (const auto& v73_3_branch : v73_3_branches) {
              const Path v73_3_head{v73_3_branch.first};
              const Space& v73_3_tail = v73_3_branch.second;
              const auto v74_2_branches = branches(c,v73_3_tail);
              std::vector<Space> v74_2_outputs;
              v74_2_outputs.reserve(v74_2_branches.size());
              for (const auto& v74_2_branch : v74_2_branches) {
                const Path v74_2_head{v74_2_branch.first};
                const Space& v74_2_tail = v74_2_branch.second;
                const Path v75_2 = concat_path(v73_3_head,v74_2_head);
                const auto v75_3_branches = branches(c,v74_2_tail);
                std::vector<Space> v75_3_outputs;
                v75_3_outputs.reserve(v75_3_branches.size());
                for (const auto& v75_3_branch : v75_3_branches) {
                  const Path v75_3_head{v75_3_branch.first};
                  const Space& v75_3_tail = v75_3_branch.second;
                  const Path v76_2 = concat_path(v75_2,v75_3_head);
                  const auto v76_3_branches = branches(c,v75_3_tail);
                  std::vector<Space> v76_3_outputs;
                  v76_3_outputs.reserve(v76_3_branches.size());
                  for (const auto& v76_3_branch : v76_3_branches) {
                    const Path v76_3_head{v76_3_branch.first};
                    const Space& v76_3_tail = v76_3_branch.second;
                    const Path v77_2 = concat_path(v76_2,v76_3_head);
                    const Space v77_3 = routine_10(c, v77_2, v73_2, v76_3_tail);
                    v76_3_outputs.push_back(v77_3);
                  }
                  const Space v76_3 = join_outputs(std::move(v76_3_outputs));
                  v75_3_outputs.push_back(v76_3);
                }
                const Space v75_3 = join_outputs(std::move(v75_3_outputs));
                v74_2_outputs.push_back(v75_3);
              }
              const Space v74_2 = join_outputs(std::move(v74_2_outputs));
              v73_3_outputs.push_back(v74_2);
            }
            const Space v73_3 = join_outputs(std::move(v73_3_outputs));
            v72_3_outputs.push_back(v73_3);
          }
          const Space v72_3 = join_outputs(std::move(v72_3_outputs));
          v71_3_outputs.push_back(v72_3);
        }
        const Space v71_3 = join_outputs(std::move(v71_3_outputs));
        v70_2_outputs.push_back(v71_3);
      }
      const Space v70_2 = join_outputs(std::move(v70_2_outputs));
      v69_17_outputs.push_back(v70_2);
    }
    const Space v69_17 = join_outputs(std::move(v69_17_outputs));
    v41_18 = compose(v41_16,v69_17);
  }
  const Space v41_19 = unite(v41_13,v41_18);
  const Space v41_21 = intersect(constant_50,v41_3);
  const auto v41_22_branches = branches(c,v41_21);
  std::vector<Space> v41_22_outputs;
  v41_22_outputs.reserve(v41_22_branches.size());
  for (const auto& v41_22_branch : v41_22_branches) {
    const Path v41_22_head{v41_22_branch.first};
    const Space& v41_22_tail = v41_22_branch.second;
    const auto v78_2_branches = branches(c,v41_22_tail);
    std::vector<Space> v78_2_outputs;
    v78_2_outputs.reserve(v78_2_branches.size());
    for (const auto& v78_2_branch : v78_2_branches) {
      const Path v78_2_head{v78_2_branch.first};
      const Space& v78_2_tail = v78_2_branch.second;
      const auto v79_2_branches = branches(c,v78_2_tail);
      std::vector<Space> v79_2_outputs;
      v79_2_outputs.reserve(v79_2_branches.size());
      for (const auto& v79_2_branch : v79_2_branches) {
        const Path v79_2_head{v79_2_branch.first};
        const Space& v79_2_tail = v79_2_branch.second;
        const Space v80_2 = tails_union(v79_2_tail);
        v79_2_outputs.push_back(v80_2);
      }
      const Space v79_2 = join_outputs(std::move(v79_2_outputs));
      v78_2_outputs.push_back(v79_2);
    }
    const Space v78_2 = join_outputs(std::move(v78_2_outputs));
    v41_22_outputs.push_back(v78_2);
  }
  const Space v41_22 = join_outputs(std::move(v41_22_outputs));
  Space v41_24;
  if (!v41_22.empty()) {
    const auto v81_23_branches = branches(c,s0);
    std::vector<Space> v81_23_outputs;
    v81_23_outputs.reserve(v81_23_branches.size());
    for (const auto& v81_23_branch : v81_23_branches) {
      const Path v81_23_head{v81_23_branch.first};
      const Space& v81_23_tail = v81_23_branch.second;
      const auto v82_2_branches = branches(c,v81_23_tail);
      std::vector<Space> v82_2_outputs;
      v82_2_outputs.reserve(v82_2_branches.size());
      for (const auto& v82_2_branch : v82_2_branches) {
        const Path v82_2_head{v82_2_branch.first};
        const Space& v82_2_tail = v82_2_branch.second;
        const Path v83_2 = concat_path(v81_23_head,v82_2_head);
        const auto v83_3_branches = branches(c,v82_2_tail);
        std::vector<Space> v83_3_outputs;
        v83_3_outputs.reserve(v83_3_branches.size());
        for (const auto& v83_3_branch : v83_3_branches) {
          const Path v83_3_head{v83_3_branch.first};
          const Space& v83_3_tail = v83_3_branch.second;
          const Path v84_2 = concat_path(v83_2,v83_3_head);
          const auto v84_3_branches = branches(c,v83_3_tail);
          std::vector<Space> v84_3_outputs;
          v84_3_outputs.reserve(v84_3_branches.size());
          for (const auto& v84_3_branch : v84_3_branches) {
            const Path v84_3_head{v84_3_branch.first};
            const Space& v84_3_tail = v84_3_branch.second;
            const Path v85_2 = concat_path(v84_2,v84_3_head);
            const auto v85_3_branches = branches(c,v84_3_tail);
            std::vector<Space> v85_3_outputs;
            v85_3_outputs.reserve(v85_3_branches.size());
            for (const auto& v85_3_branch : v85_3_branches) {
              const Path v85_3_head{v85_3_branch.first};
              const Space& v85_3_tail = v85_3_branch.second;
              const auto v86_2_branches = branches(c,v85_3_tail);
              std::vector<Space> v86_2_outputs;
              v86_2_outputs.reserve(v86_2_branches.size());
              for (const auto& v86_2_branch : v86_2_branches) {
                const Path v86_2_head{v86_2_branch.first};
                const Space& v86_2_tail = v86_2_branch.second;
                const Path v87_2 = concat_path(v85_3_head,v86_2_head);
                const auto v87_3_branches = branches(c,v86_2_tail);
                std::vector<Space> v87_3_outputs;
                v87_3_outputs.reserve(v87_3_branches.size());
                for (const auto& v87_3_branch : v87_3_branches) {
                  const Path v87_3_head{v87_3_branch.first};
                  const Space& v87_3_tail = v87_3_branch.second;
                  const Path v88_2 = concat_path(v87_2,v87_3_head);
                  const auto v88_3_branches = branches(c,v87_3_tail);
                  std::vector<Space> v88_3_outputs;
                  v88_3_outputs.reserve(v88_3_branches.size());
                  for (const auto& v88_3_branch : v88_3_branches) {
                    const Path v88_3_head{v88_3_branch.first};
                    const Space& v88_3_tail = v88_3_branch.second;
                    const Path v89_2 = concat_path(v88_2,v88_3_head);
                    const Space v89_3 = routine_11(c, v89_2, v85_2, v88_3_tail);
                    v88_3_outputs.push_back(v89_3);
                  }
                  const Space v88_3 = join_outputs(std::move(v88_3_outputs));
                  v87_3_outputs.push_back(v88_3);
                }
                const Space v87_3 = join_outputs(std::move(v87_3_outputs));
                v86_2_outputs.push_back(v87_3);
              }
              const Space v86_2 = join_outputs(std::move(v86_2_outputs));
              v85_3_outputs.push_back(v86_2);
            }
            const Space v85_3 = join_outputs(std::move(v85_3_outputs));
            v84_3_outputs.push_back(v85_3);
          }
          const Space v84_3 = join_outputs(std::move(v84_3_outputs));
          v83_3_outputs.push_back(v84_3);
        }
        const Space v83_3 = join_outputs(std::move(v83_3_outputs));
        v82_2_outputs.push_back(v83_3);
      }
      const Space v82_2 = join_outputs(std::move(v82_2_outputs));
      v81_23_outputs.push_back(v82_2);
    }
    const Space v81_23 = join_outputs(std::move(v81_23_outputs));
    v41_24 = compose(v41_22,v81_23);
  }
  const Space v41_25 = unite(v41_19,v41_24);
  const Space v41_27 = intersect(constant_51,v41_3);
  const auto v41_28_branches = branches(c,v41_27);
  std::vector<Space> v41_28_outputs;
  v41_28_outputs.reserve(v41_28_branches.size());
  for (const auto& v41_28_branch : v41_28_branches) {
    const Path v41_28_head{v41_28_branch.first};
    const Space& v41_28_tail = v41_28_branch.second;
    const auto v90_2_branches = branches(c,v41_28_tail);
    std::vector<Space> v90_2_outputs;
    v90_2_outputs.reserve(v90_2_branches.size());
    for (const auto& v90_2_branch : v90_2_branches) {
      const Path v90_2_head{v90_2_branch.first};
      const Space& v90_2_tail = v90_2_branch.second;
      const auto v91_2_branches = branches(c,v90_2_tail);
      std::vector<Space> v91_2_outputs;
      v91_2_outputs.reserve(v91_2_branches.size());
      for (const auto& v91_2_branch : v91_2_branches) {
        const Path v91_2_head{v91_2_branch.first};
        const Space& v91_2_tail = v91_2_branch.second;
        const Space v92_2 = tails_union(v91_2_tail);
        v91_2_outputs.push_back(v92_2);
      }
      const Space v91_2 = join_outputs(std::move(v91_2_outputs));
      v90_2_outputs.push_back(v91_2);
    }
    const Space v90_2 = join_outputs(std::move(v90_2_outputs));
    v41_28_outputs.push_back(v90_2);
  }
  const Space v41_28 = join_outputs(std::move(v41_28_outputs));
  Space v41_30;
  if (!v41_28.empty()) {
    const auto v93_29_branches = branches(c,s0);
    std::vector<Space> v93_29_outputs;
    v93_29_outputs.reserve(v93_29_branches.size());
    for (const auto& v93_29_branch : v93_29_branches) {
      const Path v93_29_head{v93_29_branch.first};
      const Space& v93_29_tail = v93_29_branch.second;
      const auto v94_2_branches = branches(c,v93_29_tail);
      std::vector<Space> v94_2_outputs;
      v94_2_outputs.reserve(v94_2_branches.size());
      for (const auto& v94_2_branch : v94_2_branches) {
        const Path v94_2_head{v94_2_branch.first};
        const Space& v94_2_tail = v94_2_branch.second;
        const Path v95_2 = concat_path(v93_29_head,v94_2_head);
        const auto v95_3_branches = branches(c,v94_2_tail);
        std::vector<Space> v95_3_outputs;
        v95_3_outputs.reserve(v95_3_branches.size());
        for (const auto& v95_3_branch : v95_3_branches) {
          const Path v95_3_head{v95_3_branch.first};
          const Space& v95_3_tail = v95_3_branch.second;
          const Path v96_2 = concat_path(v95_2,v95_3_head);
          const auto v96_3_branches = branches(c,v95_3_tail);
          std::vector<Space> v96_3_outputs;
          v96_3_outputs.reserve(v96_3_branches.size());
          for (const auto& v96_3_branch : v96_3_branches) {
            const Path v96_3_head{v96_3_branch.first};
            const Space& v96_3_tail = v96_3_branch.second;
            const Path v97_2 = concat_path(v96_2,v96_3_head);
            const auto v97_3_branches = branches(c,v96_3_tail);
            std::vector<Space> v97_3_outputs;
            v97_3_outputs.reserve(v97_3_branches.size());
            for (const auto& v97_3_branch : v97_3_branches) {
              const Path v97_3_head{v97_3_branch.first};
              const Space& v97_3_tail = v97_3_branch.second;
              const auto v98_2_branches = branches(c,v97_3_tail);
              std::vector<Space> v98_2_outputs;
              v98_2_outputs.reserve(v98_2_branches.size());
              for (const auto& v98_2_branch : v98_2_branches) {
                const Path v98_2_head{v98_2_branch.first};
                const Space& v98_2_tail = v98_2_branch.second;
                const Path v99_2 = concat_path(v97_3_head,v98_2_head);
                const auto v99_3_branches = branches(c,v98_2_tail);
                std::vector<Space> v99_3_outputs;
                v99_3_outputs.reserve(v99_3_branches.size());
                for (const auto& v99_3_branch : v99_3_branches) {
                  const Path v99_3_head{v99_3_branch.first};
                  const Space& v99_3_tail = v99_3_branch.second;
                  const Path v100_2 = concat_path(v99_2,v99_3_head);
                  const auto v100_3_branches = branches(c,v99_3_tail);
                  std::vector<Space> v100_3_outputs;
                  v100_3_outputs.reserve(v100_3_branches.size());
                  for (const auto& v100_3_branch : v100_3_branches) {
                    const Path v100_3_head{v100_3_branch.first};
                    const Space& v100_3_tail = v100_3_branch.second;
                    const Path v101_2 = concat_path(v100_2,v100_3_head);
                    const Space v101_3 = routine_12(c, v101_2, v97_2, v100_3_tail);
                    v100_3_outputs.push_back(v101_3);
                  }
                  const Space v100_3 = join_outputs(std::move(v100_3_outputs));
                  v99_3_outputs.push_back(v100_3);
                }
                const Space v99_3 = join_outputs(std::move(v99_3_outputs));
                v98_2_outputs.push_back(v99_3);
              }
              const Space v98_2 = join_outputs(std::move(v98_2_outputs));
              v97_3_outputs.push_back(v98_2);
            }
            const Space v97_3 = join_outputs(std::move(v97_3_outputs));
            v96_3_outputs.push_back(v97_3);
          }
          const Space v96_3 = join_outputs(std::move(v96_3_outputs));
          v95_3_outputs.push_back(v96_3);
        }
        const Space v95_3 = join_outputs(std::move(v95_3_outputs));
        v94_2_outputs.push_back(v95_3);
      }
      const Space v94_2 = join_outputs(std::move(v94_2_outputs));
      v93_29_outputs.push_back(v94_2);
    }
    const Space v93_29 = join_outputs(std::move(v93_29_outputs));
    v41_30 = compose(v41_28,v93_29);
  }
  const Space v41_31 = unite(v41_25,v41_30);
  const Space v41_33 = intersect(constant_52,v41_3);
  const auto v41_34_branches = branches(c,v41_33);
  std::vector<Space> v41_34_outputs;
  v41_34_outputs.reserve(v41_34_branches.size());
  for (const auto& v41_34_branch : v41_34_branches) {
    const Path v41_34_head{v41_34_branch.first};
    const Space& v41_34_tail = v41_34_branch.second;
    const auto v102_2_branches = branches(c,v41_34_tail);
    std::vector<Space> v102_2_outputs;
    v102_2_outputs.reserve(v102_2_branches.size());
    for (const auto& v102_2_branch : v102_2_branches) {
      const Path v102_2_head{v102_2_branch.first};
      const Space& v102_2_tail = v102_2_branch.second;
      const auto v103_2_branches = branches(c,v102_2_tail);
      std::vector<Space> v103_2_outputs;
      v103_2_outputs.reserve(v103_2_branches.size());
      for (const auto& v103_2_branch : v103_2_branches) {
        const Path v103_2_head{v103_2_branch.first};
        const Space& v103_2_tail = v103_2_branch.second;
        const Space v104_2 = tails_union(v103_2_tail);
        v103_2_outputs.push_back(v104_2);
      }
      const Space v103_2 = join_outputs(std::move(v103_2_outputs));
      v102_2_outputs.push_back(v103_2);
    }
    const Space v102_2 = join_outputs(std::move(v102_2_outputs));
    v41_34_outputs.push_back(v102_2);
  }
  const Space v41_34 = join_outputs(std::move(v41_34_outputs));
  Space v41_36;
  if (!v41_34.empty()) {
    const auto v105_35_branches = branches(c,s0);
    std::vector<Space> v105_35_outputs;
    v105_35_outputs.reserve(v105_35_branches.size());
    for (const auto& v105_35_branch : v105_35_branches) {
      const Path v105_35_head{v105_35_branch.first};
      const Space& v105_35_tail = v105_35_branch.second;
      const auto v106_2_branches = branches(c,v105_35_tail);
      std::vector<Space> v106_2_outputs;
      v106_2_outputs.reserve(v106_2_branches.size());
      for (const auto& v106_2_branch : v106_2_branches) {
        const Path v106_2_head{v106_2_branch.first};
        const Space& v106_2_tail = v106_2_branch.second;
        const Path v107_2 = concat_path(v105_35_head,v106_2_head);
        const auto v107_3_branches = branches(c,v106_2_tail);
        std::vector<Space> v107_3_outputs;
        v107_3_outputs.reserve(v107_3_branches.size());
        for (const auto& v107_3_branch : v107_3_branches) {
          const Path v107_3_head{v107_3_branch.first};
          const Space& v107_3_tail = v107_3_branch.second;
          const Path v108_2 = concat_path(v107_2,v107_3_head);
          const auto v108_3_branches = branches(c,v107_3_tail);
          std::vector<Space> v108_3_outputs;
          v108_3_outputs.reserve(v108_3_branches.size());
          for (const auto& v108_3_branch : v108_3_branches) {
            const Path v108_3_head{v108_3_branch.first};
            const Space& v108_3_tail = v108_3_branch.second;
            const Path v109_2 = concat_path(v108_2,v108_3_head);
            const auto v109_3_branches = branches(c,v108_3_tail);
            std::vector<Space> v109_3_outputs;
            v109_3_outputs.reserve(v109_3_branches.size());
            for (const auto& v109_3_branch : v109_3_branches) {
              const Path v109_3_head{v109_3_branch.first};
              const Space& v109_3_tail = v109_3_branch.second;
              const auto v110_2_branches = branches(c,v109_3_tail);
              std::vector<Space> v110_2_outputs;
              v110_2_outputs.reserve(v110_2_branches.size());
              for (const auto& v110_2_branch : v110_2_branches) {
                const Path v110_2_head{v110_2_branch.first};
                const Space& v110_2_tail = v110_2_branch.second;
                const Path v111_2 = concat_path(v109_3_head,v110_2_head);
                const auto v111_3_branches = branches(c,v110_2_tail);
                std::vector<Space> v111_3_outputs;
                v111_3_outputs.reserve(v111_3_branches.size());
                for (const auto& v111_3_branch : v111_3_branches) {
                  const Path v111_3_head{v111_3_branch.first};
                  const Space& v111_3_tail = v111_3_branch.second;
                  const Path v112_2 = concat_path(v111_2,v111_3_head);
                  const auto v112_3_branches = branches(c,v111_3_tail);
                  std::vector<Space> v112_3_outputs;
                  v112_3_outputs.reserve(v112_3_branches.size());
                  for (const auto& v112_3_branch : v112_3_branches) {
                    const Path v112_3_head{v112_3_branch.first};
                    const Space& v112_3_tail = v112_3_branch.second;
                    const Path v113_2 = concat_path(v112_2,v112_3_head);
                    const Space v113_3 = routine_13(c, v113_2, v109_2, v112_3_tail);
                    v112_3_outputs.push_back(v113_3);
                  }
                  const Space v112_3 = join_outputs(std::move(v112_3_outputs));
                  v111_3_outputs.push_back(v112_3);
                }
                const Space v111_3 = join_outputs(std::move(v111_3_outputs));
                v110_2_outputs.push_back(v111_3);
              }
              const Space v110_2 = join_outputs(std::move(v110_2_outputs));
              v109_3_outputs.push_back(v110_2);
            }
            const Space v109_3 = join_outputs(std::move(v109_3_outputs));
            v108_3_outputs.push_back(v109_3);
          }
          const Space v108_3 = join_outputs(std::move(v108_3_outputs));
          v107_3_outputs.push_back(v108_3);
        }
        const Space v107_3 = join_outputs(std::move(v107_3_outputs));
        v106_2_outputs.push_back(v107_3);
      }
      const Space v106_2 = join_outputs(std::move(v106_2_outputs));
      v105_35_outputs.push_back(v106_2);
    }
    const Space v105_35 = join_outputs(std::move(v105_35_outputs));
    v41_36 = compose(v41_34,v105_35);
  }
  const Space v41_37 = unite(v41_31,v41_36);
  const Space v41_39 = intersect(constant_53,v41_3);
  const auto v41_40_branches = branches(c,v41_39);
  std::vector<Space> v41_40_outputs;
  v41_40_outputs.reserve(v41_40_branches.size());
  for (const auto& v41_40_branch : v41_40_branches) {
    const Path v41_40_head{v41_40_branch.first};
    const Space& v41_40_tail = v41_40_branch.second;
    const auto v114_2_branches = branches(c,v41_40_tail);
    std::vector<Space> v114_2_outputs;
    v114_2_outputs.reserve(v114_2_branches.size());
    for (const auto& v114_2_branch : v114_2_branches) {
      const Path v114_2_head{v114_2_branch.first};
      const Space& v114_2_tail = v114_2_branch.second;
      const auto v115_2_branches = branches(c,v114_2_tail);
      std::vector<Space> v115_2_outputs;
      v115_2_outputs.reserve(v115_2_branches.size());
      for (const auto& v115_2_branch : v115_2_branches) {
        const Path v115_2_head{v115_2_branch.first};
        const Space& v115_2_tail = v115_2_branch.second;
        const Space v116_2 = tails_union(v115_2_tail);
        v115_2_outputs.push_back(v116_2);
      }
      const Space v115_2 = join_outputs(std::move(v115_2_outputs));
      v114_2_outputs.push_back(v115_2);
    }
    const Space v114_2 = join_outputs(std::move(v114_2_outputs));
    v41_40_outputs.push_back(v114_2);
  }
  const Space v41_40 = join_outputs(std::move(v41_40_outputs));
  Space v41_42;
  if (!v41_40.empty()) {
    const auto v117_41_branches = branches(c,s0);
    std::vector<Space> v117_41_outputs;
    v117_41_outputs.reserve(v117_41_branches.size());
    for (const auto& v117_41_branch : v117_41_branches) {
      const Path v117_41_head{v117_41_branch.first};
      const Space& v117_41_tail = v117_41_branch.second;
      const auto v118_2_branches = branches(c,v117_41_tail);
      std::vector<Space> v118_2_outputs;
      v118_2_outputs.reserve(v118_2_branches.size());
      for (const auto& v118_2_branch : v118_2_branches) {
        const Path v118_2_head{v118_2_branch.first};
        const Space& v118_2_tail = v118_2_branch.second;
        const Path v119_2 = concat_path(v117_41_head,v118_2_head);
        const auto v119_3_branches = branches(c,v118_2_tail);
        std::vector<Space> v119_3_outputs;
        v119_3_outputs.reserve(v119_3_branches.size());
        for (const auto& v119_3_branch : v119_3_branches) {
          const Path v119_3_head{v119_3_branch.first};
          const Space& v119_3_tail = v119_3_branch.second;
          const Path v120_2 = concat_path(v119_2,v119_3_head);
          const auto v120_3_branches = branches(c,v119_3_tail);
          std::vector<Space> v120_3_outputs;
          v120_3_outputs.reserve(v120_3_branches.size());
          for (const auto& v120_3_branch : v120_3_branches) {
            const Path v120_3_head{v120_3_branch.first};
            const Space& v120_3_tail = v120_3_branch.second;
            const Path v121_2 = concat_path(v120_2,v120_3_head);
            const auto v121_3_branches = branches(c,v120_3_tail);
            std::vector<Space> v121_3_outputs;
            v121_3_outputs.reserve(v121_3_branches.size());
            for (const auto& v121_3_branch : v121_3_branches) {
              const Path v121_3_head{v121_3_branch.first};
              const Space& v121_3_tail = v121_3_branch.second;
              const auto v122_2_branches = branches(c,v121_3_tail);
              std::vector<Space> v122_2_outputs;
              v122_2_outputs.reserve(v122_2_branches.size());
              for (const auto& v122_2_branch : v122_2_branches) {
                const Path v122_2_head{v122_2_branch.first};
                const Space& v122_2_tail = v122_2_branch.second;
                const Path v123_2 = concat_path(v121_3_head,v122_2_head);
                const auto v123_3_branches = branches(c,v122_2_tail);
                std::vector<Space> v123_3_outputs;
                v123_3_outputs.reserve(v123_3_branches.size());
                for (const auto& v123_3_branch : v123_3_branches) {
                  const Path v123_3_head{v123_3_branch.first};
                  const Space& v123_3_tail = v123_3_branch.second;
                  const Path v124_2 = concat_path(v123_2,v123_3_head);
                  const auto v124_3_branches = branches(c,v123_3_tail);
                  std::vector<Space> v124_3_outputs;
                  v124_3_outputs.reserve(v124_3_branches.size());
                  for (const auto& v124_3_branch : v124_3_branches) {
                    const Path v124_3_head{v124_3_branch.first};
                    const Space& v124_3_tail = v124_3_branch.second;
                    const Path v125_2 = concat_path(v124_2,v124_3_head);
                    const Space v125_3 = routine_14(c, v125_2, v121_2, v124_3_tail);
                    v124_3_outputs.push_back(v125_3);
                  }
                  const Space v124_3 = join_outputs(std::move(v124_3_outputs));
                  v123_3_outputs.push_back(v124_3);
                }
                const Space v123_3 = join_outputs(std::move(v123_3_outputs));
                v122_2_outputs.push_back(v123_3);
              }
              const Space v122_2 = join_outputs(std::move(v122_2_outputs));
              v121_3_outputs.push_back(v122_2);
            }
            const Space v121_3 = join_outputs(std::move(v121_3_outputs));
            v120_3_outputs.push_back(v121_3);
          }
          const Space v120_3 = join_outputs(std::move(v120_3_outputs));
          v119_3_outputs.push_back(v120_3);
        }
        const Space v119_3 = join_outputs(std::move(v119_3_outputs));
        v118_2_outputs.push_back(v119_3);
      }
      const Space v118_2 = join_outputs(std::move(v118_2_outputs));
      v117_41_outputs.push_back(v118_2);
    }
    const Space v117_41 = join_outputs(std::move(v117_41_outputs));
    v41_42 = compose(v41_40,v117_41);
  }
  const Space v41_43 = unite(v41_37,v41_42);
  const Space v41_45 = intersect(constant_54,v41_3);
  const auto v41_46_branches = branches(c,v41_45);
  std::vector<Space> v41_46_outputs;
  v41_46_outputs.reserve(v41_46_branches.size());
  for (const auto& v41_46_branch : v41_46_branches) {
    const Path v41_46_head{v41_46_branch.first};
    const Space& v41_46_tail = v41_46_branch.second;
    const auto v126_2_branches = branches(c,v41_46_tail);
    std::vector<Space> v126_2_outputs;
    v126_2_outputs.reserve(v126_2_branches.size());
    for (const auto& v126_2_branch : v126_2_branches) {
      const Path v126_2_head{v126_2_branch.first};
      const Space& v126_2_tail = v126_2_branch.second;
      const auto v127_2_branches = branches(c,v126_2_tail);
      std::vector<Space> v127_2_outputs;
      v127_2_outputs.reserve(v127_2_branches.size());
      for (const auto& v127_2_branch : v127_2_branches) {
        const Path v127_2_head{v127_2_branch.first};
        const Space& v127_2_tail = v127_2_branch.second;
        const Space v128_2 = tails_union(v127_2_tail);
        v127_2_outputs.push_back(v128_2);
      }
      const Space v127_2 = join_outputs(std::move(v127_2_outputs));
      v126_2_outputs.push_back(v127_2);
    }
    const Space v126_2 = join_outputs(std::move(v126_2_outputs));
    v41_46_outputs.push_back(v126_2);
  }
  const Space v41_46 = join_outputs(std::move(v41_46_outputs));
  Space v41_48;
  if (!v41_46.empty()) {
    const auto v129_47_branches = branches(c,s0);
    std::vector<Space> v129_47_outputs;
    v129_47_outputs.reserve(v129_47_branches.size());
    for (const auto& v129_47_branch : v129_47_branches) {
      const Path v129_47_head{v129_47_branch.first};
      const Space& v129_47_tail = v129_47_branch.second;
      const auto v130_2_branches = branches(c,v129_47_tail);
      std::vector<Space> v130_2_outputs;
      v130_2_outputs.reserve(v130_2_branches.size());
      for (const auto& v130_2_branch : v130_2_branches) {
        const Path v130_2_head{v130_2_branch.first};
        const Space& v130_2_tail = v130_2_branch.second;
        const Path v131_2 = concat_path(v129_47_head,v130_2_head);
        const auto v131_3_branches = branches(c,v130_2_tail);
        std::vector<Space> v131_3_outputs;
        v131_3_outputs.reserve(v131_3_branches.size());
        for (const auto& v131_3_branch : v131_3_branches) {
          const Path v131_3_head{v131_3_branch.first};
          const Space& v131_3_tail = v131_3_branch.second;
          const Path v132_2 = concat_path(v131_2,v131_3_head);
          const auto v132_3_branches = branches(c,v131_3_tail);
          std::vector<Space> v132_3_outputs;
          v132_3_outputs.reserve(v132_3_branches.size());
          for (const auto& v132_3_branch : v132_3_branches) {
            const Path v132_3_head{v132_3_branch.first};
            const Space& v132_3_tail = v132_3_branch.second;
            const Path v133_2 = concat_path(v132_2,v132_3_head);
            const auto v133_3_branches = branches(c,v132_3_tail);
            std::vector<Space> v133_3_outputs;
            v133_3_outputs.reserve(v133_3_branches.size());
            for (const auto& v133_3_branch : v133_3_branches) {
              const Path v133_3_head{v133_3_branch.first};
              const Space& v133_3_tail = v133_3_branch.second;
              const auto v134_2_branches = branches(c,v133_3_tail);
              std::vector<Space> v134_2_outputs;
              v134_2_outputs.reserve(v134_2_branches.size());
              for (const auto& v134_2_branch : v134_2_branches) {
                const Path v134_2_head{v134_2_branch.first};
                const Space& v134_2_tail = v134_2_branch.second;
                const Path v135_2 = concat_path(v133_3_head,v134_2_head);
                const auto v135_3_branches = branches(c,v134_2_tail);
                std::vector<Space> v135_3_outputs;
                v135_3_outputs.reserve(v135_3_branches.size());
                for (const auto& v135_3_branch : v135_3_branches) {
                  const Path v135_3_head{v135_3_branch.first};
                  const Space& v135_3_tail = v135_3_branch.second;
                  const Path v136_2 = concat_path(v135_2,v135_3_head);
                  const auto v136_3_branches = branches(c,v135_3_tail);
                  std::vector<Space> v136_3_outputs;
                  v136_3_outputs.reserve(v136_3_branches.size());
                  for (const auto& v136_3_branch : v136_3_branches) {
                    const Path v136_3_head{v136_3_branch.first};
                    const Space& v136_3_tail = v136_3_branch.second;
                    const Path v137_2 = concat_path(v136_2,v136_3_head);
                    const Space v137_3 = routine_15(c, v137_2, v133_2, v136_3_tail);
                    v136_3_outputs.push_back(v137_3);
                  }
                  const Space v136_3 = join_outputs(std::move(v136_3_outputs));
                  v135_3_outputs.push_back(v136_3);
                }
                const Space v135_3 = join_outputs(std::move(v135_3_outputs));
                v134_2_outputs.push_back(v135_3);
              }
              const Space v134_2 = join_outputs(std::move(v134_2_outputs));
              v133_3_outputs.push_back(v134_2);
            }
            const Space v133_3 = join_outputs(std::move(v133_3_outputs));
            v132_3_outputs.push_back(v133_3);
          }
          const Space v132_3 = join_outputs(std::move(v132_3_outputs));
          v131_3_outputs.push_back(v132_3);
        }
        const Space v131_3 = join_outputs(std::move(v131_3_outputs));
        v130_2_outputs.push_back(v131_3);
      }
      const Space v130_2 = join_outputs(std::move(v130_2_outputs));
      v129_47_outputs.push_back(v130_2);
    }
    const Space v129_47 = join_outputs(std::move(v129_47_outputs));
    v41_48 = compose(v41_46,v129_47);
  }
  const Space v41_49 = unite(v41_43,v41_48);
  const Space v41_51 = intersect(constant_55,v41_3);
  const auto v41_52_branches = branches(c,v41_51);
  std::vector<Space> v41_52_outputs;
  v41_52_outputs.reserve(v41_52_branches.size());
  for (const auto& v41_52_branch : v41_52_branches) {
    const Path v41_52_head{v41_52_branch.first};
    const Space& v41_52_tail = v41_52_branch.second;
    const auto v138_2_branches = branches(c,v41_52_tail);
    std::vector<Space> v138_2_outputs;
    v138_2_outputs.reserve(v138_2_branches.size());
    for (const auto& v138_2_branch : v138_2_branches) {
      const Path v138_2_head{v138_2_branch.first};
      const Space& v138_2_tail = v138_2_branch.second;
      const auto v139_2_branches = branches(c,v138_2_tail);
      std::vector<Space> v139_2_outputs;
      v139_2_outputs.reserve(v139_2_branches.size());
      for (const auto& v139_2_branch : v139_2_branches) {
        const Path v139_2_head{v139_2_branch.first};
        const Space& v139_2_tail = v139_2_branch.second;
        const Space v140_2 = tails_union(v139_2_tail);
        v139_2_outputs.push_back(v140_2);
      }
      const Space v139_2 = join_outputs(std::move(v139_2_outputs));
      v138_2_outputs.push_back(v139_2);
    }
    const Space v138_2 = join_outputs(std::move(v138_2_outputs));
    v41_52_outputs.push_back(v138_2);
  }
  const Space v41_52 = join_outputs(std::move(v41_52_outputs));
  Space v41_54;
  if (!v41_52.empty()) {
    const auto v141_53_branches = branches(c,s0);
    std::vector<Space> v141_53_outputs;
    v141_53_outputs.reserve(v141_53_branches.size());
    for (const auto& v141_53_branch : v141_53_branches) {
      const Path v141_53_head{v141_53_branch.first};
      const Space& v141_53_tail = v141_53_branch.second;
      const auto v142_2_branches = branches(c,v141_53_tail);
      std::vector<Space> v142_2_outputs;
      v142_2_outputs.reserve(v142_2_branches.size());
      for (const auto& v142_2_branch : v142_2_branches) {
        const Path v142_2_head{v142_2_branch.first};
        const Space& v142_2_tail = v142_2_branch.second;
        const Path v143_2 = concat_path(v141_53_head,v142_2_head);
        const auto v143_3_branches = branches(c,v142_2_tail);
        std::vector<Space> v143_3_outputs;
        v143_3_outputs.reserve(v143_3_branches.size());
        for (const auto& v143_3_branch : v143_3_branches) {
          const Path v143_3_head{v143_3_branch.first};
          const Space& v143_3_tail = v143_3_branch.second;
          const Path v144_2 = concat_path(v143_2,v143_3_head);
          const auto v144_3_branches = branches(c,v143_3_tail);
          std::vector<Space> v144_3_outputs;
          v144_3_outputs.reserve(v144_3_branches.size());
          for (const auto& v144_3_branch : v144_3_branches) {
            const Path v144_3_head{v144_3_branch.first};
            const Space& v144_3_tail = v144_3_branch.second;
            const Path v145_2 = concat_path(v144_2,v144_3_head);
            const auto v145_3_branches = branches(c,v144_3_tail);
            std::vector<Space> v145_3_outputs;
            v145_3_outputs.reserve(v145_3_branches.size());
            for (const auto& v145_3_branch : v145_3_branches) {
              const Path v145_3_head{v145_3_branch.first};
              const Space& v145_3_tail = v145_3_branch.second;
              const auto v146_2_branches = branches(c,v145_3_tail);
              std::vector<Space> v146_2_outputs;
              v146_2_outputs.reserve(v146_2_branches.size());
              for (const auto& v146_2_branch : v146_2_branches) {
                const Path v146_2_head{v146_2_branch.first};
                const Space& v146_2_tail = v146_2_branch.second;
                const Path v147_2 = concat_path(v145_3_head,v146_2_head);
                const auto v147_3_branches = branches(c,v146_2_tail);
                std::vector<Space> v147_3_outputs;
                v147_3_outputs.reserve(v147_3_branches.size());
                for (const auto& v147_3_branch : v147_3_branches) {
                  const Path v147_3_head{v147_3_branch.first};
                  const Space& v147_3_tail = v147_3_branch.second;
                  const Path v148_2 = concat_path(v147_2,v147_3_head);
                  const auto v148_3_branches = branches(c,v147_3_tail);
                  std::vector<Space> v148_3_outputs;
                  v148_3_outputs.reserve(v148_3_branches.size());
                  for (const auto& v148_3_branch : v148_3_branches) {
                    const Path v148_3_head{v148_3_branch.first};
                    const Space& v148_3_tail = v148_3_branch.second;
                    const Path v149_2 = concat_path(v148_2,v148_3_head);
                    const Space v149_3 = routine_16(c, v149_2, v145_2, v148_3_tail);
                    v148_3_outputs.push_back(v149_3);
                  }
                  const Space v148_3 = join_outputs(std::move(v148_3_outputs));
                  v147_3_outputs.push_back(v148_3);
                }
                const Space v147_3 = join_outputs(std::move(v147_3_outputs));
                v146_2_outputs.push_back(v147_3);
              }
              const Space v146_2 = join_outputs(std::move(v146_2_outputs));
              v145_3_outputs.push_back(v146_2);
            }
            const Space v145_3 = join_outputs(std::move(v145_3_outputs));
            v144_3_outputs.push_back(v145_3);
          }
          const Space v144_3 = join_outputs(std::move(v144_3_outputs));
          v143_3_outputs.push_back(v144_3);
        }
        const Space v143_3 = join_outputs(std::move(v143_3_outputs));
        v142_2_outputs.push_back(v143_3);
      }
      const Space v142_2 = join_outputs(std::move(v142_2_outputs));
      v141_53_outputs.push_back(v142_2);
    }
    const Space v141_53 = join_outputs(std::move(v141_53_outputs));
    v41_54 = compose(v41_52,v141_53);
  }
  const Space v41_55 = unite(v41_49,v41_54);
  return v41_55;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v150_6 = routine_17(c, constant_56, constant_1, constant_57);
  const Space v150_9 = routine_17(c, constant_56, constant_3, constant_58);
  const Space v150_10 = unite(v150_6,v150_9);
  const Space v150_13 = routine_17(c, constant_56, constant_5, constant_59);
  const Space v150_14 = unite(v150_10,v150_13);
  const Space v150_17 = routine_17(c, constant_56, constant_7, constant_60);
  const Space v150_18 = unite(v150_14,v150_17);
  const Space v150_21 = routine_17(c, constant_56, constant_9, constant_61);
  const Space v150_22 = unite(v150_18,v150_21);
  const Space v150_25 = routine_17(c, constant_56, constant_11, constant_62);
  const Space v150_26 = unite(v150_22,v150_25);
  const Space v150_29 = routine_17(c, constant_63, constant_1, constant_64);
  const Space v150_30 = unite(v150_26,v150_29);
  const Space v150_32 = routine_17(c, constant_63, constant_3, constant_65);
  const Space v150_33 = unite(v150_30,v150_32);
  const Space v150_35 = routine_17(c, constant_63, constant_7, constant_66);
  const Space v150_36 = unite(v150_33,v150_35);
  const Space v150_38 = routine_17(c, constant_63, constant_9, constant_67);
  const Space v150_39 = unite(v150_36,v150_38);
  const Space v150_42 = routine_17(c, constant_63, constant_13, constant_68);
  const Space v150_43 = unite(v150_39,v150_42);
  const Space v150_46 = routine_17(c, constant_63, constant_15, constant_69);
  const Space v150_47 = unite(v150_43,v150_46);
  const Space v150_50 = routine_17(c, constant_70, constant_3, constant_64);
  const Space v150_51 = unite(v150_47,v150_50);
  const Space v150_53 = routine_17(c, constant_70, constant_5, constant_65);
  const Space v150_54 = unite(v150_51,v150_53);
  const Space v150_56 = routine_17(c, constant_70, constant_9, constant_66);
  const Space v150_57 = unite(v150_54,v150_56);
  const Space v150_59 = routine_17(c, constant_70, constant_11, constant_67);
  const Space v150_60 = unite(v150_57,v150_59);
  const Space v150_62 = routine_17(c, constant_70, constant_15, constant_68);
  const Space v150_63 = unite(v150_60,v150_62);
  const Space v150_66 = routine_17(c, constant_70, constant_17, constant_69);
  const Space v150_67 = unite(v150_63,v150_66);
  const Space v150_70 = routine_17(c, constant_71, constant_7, constant_57);
  const Space v150_71 = unite(v150_67,v150_70);
  const Space v150_73 = routine_17(c, constant_71, constant_9, constant_58);
  const Space v150_74 = unite(v150_71,v150_73);
  const Space v150_76 = routine_17(c, constant_71, constant_11, constant_59);
  const Space v150_77 = unite(v150_74,v150_76);
  const Space v150_79 = routine_17(c, constant_71, constant_13, constant_60);
  const Space v150_80 = unite(v150_77,v150_79);
  const Space v150_82 = routine_17(c, constant_71, constant_15, constant_61);
  const Space v150_83 = unite(v150_80,v150_82);
  const Space v150_85 = routine_17(c, constant_71, constant_17, constant_62);
  const Space v150_86 = unite(v150_83,v150_85);
  const Space v150_87 = unwrap(v150_86,p1);
  const auto v150_88_branches = branches(c,v150_87);
  std::vector<Space> v150_88_outputs;
  v150_88_outputs.reserve(v150_88_branches.size());
  for (const auto& v150_88_branch : v150_88_branches) {
    const Path v150_88_head{v150_88_branch.first};
    const Space& v150_88_tail = v150_88_branch.second;
    const auto v151_2_branches = branches(c,v150_88_tail);
    std::vector<Space> v151_2_outputs;
    v151_2_outputs.reserve(v151_2_branches.size());
    for (const auto& v151_2_branch : v151_2_branches) {
      const Path v151_2_head{v151_2_branch.first};
      const Space& v151_2_tail = v151_2_branch.second;
      const Path v152_2 = concat_path(v150_88_head,v151_2_head);
      const auto v152_3_branches = branches(c,v151_2_tail);
      std::vector<Space> v152_3_outputs;
      v152_3_outputs.reserve(v152_3_branches.size());
      for (const auto& v152_3_branch : v152_3_branches) {
        const Path v152_3_head{v152_3_branch.first};
        const Space& v152_3_tail = v152_3_branch.second;
        const Path v153_2 = concat_path(v152_2,v152_3_head);
        const auto v153_3_branches = branches(c,v152_3_tail);
        std::vector<Space> v153_3_outputs;
        v153_3_outputs.reserve(v153_3_branches.size());
        for (const auto& v153_3_branch : v153_3_branches) {
          const Path v153_3_head{v153_3_branch.first};
          const Space& v153_3_tail = v153_3_branch.second;
          const Space v154_2 = unwrap(v153_3_tail,p0);
          const Path v154_3 = concat_path(v153_2,v153_3_head);
          const Space v154_4 = wrap(v154_2,v154_3);
          const Space v154_5 = compose(v154_4,s0);
          v153_3_outputs.push_back(v154_5);
        }
        const Space v153_3 = join_outputs(std::move(v153_3_outputs));
        v152_3_outputs.push_back(v153_3);
      }
      const Space v152_3 = join_outputs(std::move(v152_3_outputs));
      v151_2_outputs.push_back(v152_3);
    }
    const Space v151_2 = join_outputs(std::move(v151_2_outputs));
    v150_88_outputs.push_back(v151_2);
  }
  const Space v150_88 = join_outputs(std::move(v150_88_outputs));
  return v150_88;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v155_6 = routine_18(c, constant_56, constant_1, constant_57);
  const Space v155_9 = routine_18(c, constant_56, constant_3, constant_58);
  const Space v155_10 = unite(v155_6,v155_9);
  const Space v155_13 = routine_18(c, constant_56, constant_5, constant_59);
  const Space v155_14 = unite(v155_10,v155_13);
  const Space v155_17 = routine_18(c, constant_56, constant_7, constant_60);
  const Space v155_18 = unite(v155_14,v155_17);
  const Space v155_21 = routine_18(c, constant_56, constant_9, constant_61);
  const Space v155_22 = unite(v155_18,v155_21);
  const Space v155_25 = routine_18(c, constant_56, constant_11, constant_62);
  const Space v155_26 = unite(v155_22,v155_25);
  const Space v155_29 = routine_18(c, constant_63, constant_1, constant_64);
  const Space v155_30 = unite(v155_26,v155_29);
  const Space v155_32 = routine_18(c, constant_63, constant_3, constant_65);
  const Space v155_33 = unite(v155_30,v155_32);
  const Space v155_35 = routine_18(c, constant_63, constant_7, constant_66);
  const Space v155_36 = unite(v155_33,v155_35);
  const Space v155_38 = routine_18(c, constant_63, constant_9, constant_67);
  const Space v155_39 = unite(v155_36,v155_38);
  const Space v155_42 = routine_18(c, constant_63, constant_13, constant_68);
  const Space v155_43 = unite(v155_39,v155_42);
  const Space v155_46 = routine_18(c, constant_63, constant_15, constant_69);
  const Space v155_47 = unite(v155_43,v155_46);
  const Space v155_50 = routine_18(c, constant_70, constant_3, constant_64);
  const Space v155_51 = unite(v155_47,v155_50);
  const Space v155_53 = routine_18(c, constant_70, constant_5, constant_65);
  const Space v155_54 = unite(v155_51,v155_53);
  const Space v155_56 = routine_18(c, constant_70, constant_9, constant_66);
  const Space v155_57 = unite(v155_54,v155_56);
  const Space v155_59 = routine_18(c, constant_70, constant_11, constant_67);
  const Space v155_60 = unite(v155_57,v155_59);
  const Space v155_62 = routine_18(c, constant_70, constant_15, constant_68);
  const Space v155_63 = unite(v155_60,v155_62);
  const Space v155_66 = routine_18(c, constant_70, constant_17, constant_69);
  const Space v155_67 = unite(v155_63,v155_66);
  const Space v155_70 = routine_18(c, constant_71, constant_7, constant_57);
  const Space v155_71 = unite(v155_67,v155_70);
  const Space v155_73 = routine_18(c, constant_71, constant_9, constant_58);
  const Space v155_74 = unite(v155_71,v155_73);
  const Space v155_76 = routine_18(c, constant_71, constant_11, constant_59);
  const Space v155_77 = unite(v155_74,v155_76);
  const Space v155_79 = routine_18(c, constant_71, constant_13, constant_60);
  const Space v155_80 = unite(v155_77,v155_79);
  const Space v155_82 = routine_18(c, constant_71, constant_15, constant_61);
  const Space v155_83 = unite(v155_80,v155_82);
  const Space v155_85 = routine_18(c, constant_71, constant_17, constant_62);
  const Space v155_86 = unite(v155_83,v155_85);
  const Space v155_87 = unwrap(v155_86,p1);
  const Space v155_88 = unwrap(v155_87,p0);
  const Space v155_89 = unwrap(v155_88,p1);
  const auto v155_90_branches = branches(c,v155_89);
  std::vector<Space> v155_90_outputs;
  v155_90_outputs.reserve(v155_90_branches.size());
  for (const auto& v155_90_branch : v155_90_branches) {
    const Path v155_90_head{v155_90_branch.first};
    const Space& v155_90_tail = v155_90_branch.second;
    const auto v156_2_branches = branches(c,v155_90_tail);
    std::vector<Space> v156_2_outputs;
    v156_2_outputs.reserve(v156_2_branches.size());
    for (const auto& v156_2_branch : v156_2_branches) {
      const Path v156_2_head{v156_2_branch.first};
      const Space& v156_2_tail = v156_2_branch.second;
      const Path v157_2 = concat_path(v155_90_head,v156_2_head);
      const auto v157_3_branches = branches(c,v156_2_tail);
      std::vector<Space> v157_3_outputs;
      v157_3_outputs.reserve(v157_3_branches.size());
      for (const auto& v157_3_branch : v157_3_branches) {
        const Path v157_3_head{v157_3_branch.first};
        const Space& v157_3_tail = v157_3_branch.second;
        const Path v158_2 = concat_path(v157_2,v157_3_head);
        const auto v158_3_branches = branches(c,v157_3_tail);
        std::vector<Space> v158_3_outputs;
        v158_3_outputs.reserve(v158_3_branches.size());
        for (const auto& v158_3_branch : v158_3_branches) {
          const Path v158_3_head{v158_3_branch.first};
          const Space& v158_3_tail = v158_3_branch.second;
          const Path v159_2 = concat_path(v158_2,v158_3_head);
          const Space v159_3 = routine_19(c, v159_2, s0);
          v158_3_outputs.push_back(v159_3);
        }
        const Space v158_3 = join_outputs(std::move(v158_3_outputs));
        v157_3_outputs.push_back(v158_3);
      }
      const Space v157_3 = join_outputs(std::move(v157_3_outputs));
      v156_2_outputs.push_back(v157_3);
    }
    const Space v156_2 = join_outputs(std::move(v156_2_outputs));
    v155_90_outputs.push_back(v156_2);
  }
  const Space v155_90 = join_outputs(std::move(v155_90_outputs));
  return v155_90;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v160_3_branches = branches(c,s0);
  std::vector<Space> v160_3_outputs;
  v160_3_outputs.reserve(v160_3_branches.size());
  for (const auto& v160_3_branch : v160_3_branches) {
    const Path v160_3_head{v160_3_branch.first};
    const Space& v160_3_tail = v160_3_branch.second;
    const auto v161_2_branches = branches(c,v160_3_tail);
    std::vector<Space> v161_2_outputs;
    v161_2_outputs.reserve(v161_2_branches.size());
    for (const auto& v161_2_branch : v161_2_branches) {
      const Path v161_2_head{v161_2_branch.first};
      const Space& v161_2_tail = v161_2_branch.second;
      const Path v162_2 = concat_path(v160_3_head,v161_2_head);
      const auto v162_3_branches = branches(c,v161_2_tail);
      std::vector<Space> v162_3_outputs;
      v162_3_outputs.reserve(v162_3_branches.size());
      for (const auto& v162_3_branch : v162_3_branches) {
        const Path v162_3_head{v162_3_branch.first};
        const Space& v162_3_tail = v162_3_branch.second;
        const Path v163_2 = concat_path(v162_2,v162_3_head);
        const auto v163_3_branches = branches(c,v162_3_tail);
        std::vector<Space> v163_3_outputs;
        v163_3_outputs.reserve(v163_3_branches.size());
        for (const auto& v163_3_branch : v163_3_branches) {
          const Path v163_3_head{v163_3_branch.first};
          const Space& v163_3_tail = v163_3_branch.second;
          const Path v164_2 = concat_path(v163_2,v163_3_head);
          const auto v164_3_branches = branches(c,v163_3_tail);
          std::vector<Space> v164_3_outputs;
          v164_3_outputs.reserve(v164_3_branches.size());
          for (const auto& v164_3_branch : v164_3_branches) {
            const Path v164_3_head{v164_3_branch.first};
            const Space& v164_3_tail = v164_3_branch.second;
            const auto v165_2_branches = branches(c,v164_3_tail);
            std::vector<Space> v165_2_outputs;
            v165_2_outputs.reserve(v165_2_branches.size());
            for (const auto& v165_2_branch : v165_2_branches) {
              const Path v165_2_head{v165_2_branch.first};
              const Space& v165_2_tail = v165_2_branch.second;
              const Path v166_2 = concat_path(v164_3_head,v165_2_head);
              const auto v166_3_branches = branches(c,v165_2_tail);
              std::vector<Space> v166_3_outputs;
              v166_3_outputs.reserve(v166_3_branches.size());
              for (const auto& v166_3_branch : v166_3_branches) {
                const Path v166_3_head{v166_3_branch.first};
                const Space& v166_3_tail = v166_3_branch.second;
                const Path v167_2 = concat_path(v166_2,v166_3_head);
                const auto v167_3_branches = branches(c,v166_3_tail);
                std::vector<Space> v167_3_outputs;
                v167_3_outputs.reserve(v167_3_branches.size());
                for (const auto& v167_3_branch : v167_3_branches) {
                  const Path v167_3_head{v167_3_branch.first};
                  const Space& v167_3_tail = v167_3_branch.second;
                  const Path v168_2 = concat_path(v167_2,v167_3_head);
                  const Space v168_3 = routine_20(c, v168_2, p1, p0, v164_2, v167_3_tail);
                  v167_3_outputs.push_back(v168_3);
                }
                const Space v167_3 = join_outputs(std::move(v167_3_outputs));
                v166_3_outputs.push_back(v167_3);
              }
              const Space v166_3 = join_outputs(std::move(v166_3_outputs));
              v165_2_outputs.push_back(v166_3);
            }
            const Space v165_2 = join_outputs(std::move(v165_2_outputs));
            v164_3_outputs.push_back(v165_2);
          }
          const Space v164_3 = join_outputs(std::move(v164_3_outputs));
          v163_3_outputs.push_back(v164_3);
        }
        const Space v163_3 = join_outputs(std::move(v163_3_outputs));
        v162_3_outputs.push_back(v163_3);
      }
      const Space v162_3 = join_outputs(std::move(v162_3_outputs));
      v161_2_outputs.push_back(v162_3);
    }
    const Space v161_2 = join_outputs(std::move(v161_2_outputs));
    v160_3_outputs.push_back(v161_2);
  }
  const Space v160_3 = join_outputs(std::move(v160_3_outputs));
  return v160_3;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v169_3_branches = branches(c,s0);
  std::vector<Space> v169_3_outputs;
  v169_3_outputs.reserve(v169_3_branches.size());
  for (const auto& v169_3_branch : v169_3_branches) {
    const Path v169_3_head{v169_3_branch.first};
    const Space& v169_3_tail = v169_3_branch.second;
    const auto v170_2_branches = branches(c,v169_3_tail);
    std::vector<Space> v170_2_outputs;
    v170_2_outputs.reserve(v170_2_branches.size());
    for (const auto& v170_2_branch : v170_2_branches) {
      const Path v170_2_head{v170_2_branch.first};
      const Space& v170_2_tail = v170_2_branch.second;
      const Path v171_2 = concat_path(v169_3_head,v170_2_head);
      const auto v171_3_branches = branches(c,v170_2_tail);
      std::vector<Space> v171_3_outputs;
      v171_3_outputs.reserve(v171_3_branches.size());
      for (const auto& v171_3_branch : v171_3_branches) {
        const Path v171_3_head{v171_3_branch.first};
        const Space& v171_3_tail = v171_3_branch.second;
        const Path v172_2 = concat_path(v171_2,v171_3_head);
        const auto v172_3_branches = branches(c,v171_3_tail);
        std::vector<Space> v172_3_outputs;
        v172_3_outputs.reserve(v172_3_branches.size());
        for (const auto& v172_3_branch : v172_3_branches) {
          const Path v172_3_head{v172_3_branch.first};
          const Space& v172_3_tail = v172_3_branch.second;
          const Path v173_2 = concat_path(v172_2,v172_3_head);
          const auto v173_3_branches = branches(c,v172_3_tail);
          std::vector<Space> v173_3_outputs;
          v173_3_outputs.reserve(v173_3_branches.size());
          for (const auto& v173_3_branch : v173_3_branches) {
            const Path v173_3_head{v173_3_branch.first};
            const Space& v173_3_tail = v173_3_branch.second;
            const auto v174_2_branches = branches(c,v173_3_tail);
            std::vector<Space> v174_2_outputs;
            v174_2_outputs.reserve(v174_2_branches.size());
            for (const auto& v174_2_branch : v174_2_branches) {
              const Path v174_2_head{v174_2_branch.first};
              const Space& v174_2_tail = v174_2_branch.second;
              const Path v175_2 = concat_path(v173_3_head,v174_2_head);
              const auto v175_3_branches = branches(c,v174_2_tail);
              std::vector<Space> v175_3_outputs;
              v175_3_outputs.reserve(v175_3_branches.size());
              for (const auto& v175_3_branch : v175_3_branches) {
                const Path v175_3_head{v175_3_branch.first};
                const Space& v175_3_tail = v175_3_branch.second;
                const Path v176_2 = concat_path(v175_2,v175_3_head);
                const auto v176_3_branches = branches(c,v175_3_tail);
                std::vector<Space> v176_3_outputs;
                v176_3_outputs.reserve(v176_3_branches.size());
                for (const auto& v176_3_branch : v176_3_branches) {
                  const Path v176_3_head{v176_3_branch.first};
                  const Space& v176_3_tail = v176_3_branch.second;
                  const Path v177_2 = concat_path(v176_2,v176_3_head);
                  const Space v177_3 = routine_21(c, v177_2, p1, p0, v173_2, v176_3_tail);
                  v176_3_outputs.push_back(v177_3);
                }
                const Space v176_3 = join_outputs(std::move(v176_3_outputs));
                v175_3_outputs.push_back(v176_3);
              }
              const Space v175_3 = join_outputs(std::move(v175_3_outputs));
              v174_2_outputs.push_back(v175_3);
            }
            const Space v174_2 = join_outputs(std::move(v174_2_outputs));
            v173_3_outputs.push_back(v174_2);
          }
          const Space v173_3 = join_outputs(std::move(v173_3_outputs));
          v172_3_outputs.push_back(v173_3);
        }
        const Space v172_3 = join_outputs(std::move(v172_3_outputs));
        v171_3_outputs.push_back(v172_3);
      }
      const Space v171_3 = join_outputs(std::move(v171_3_outputs));
      v170_2_outputs.push_back(v171_3);
    }
    const Space v170_2 = join_outputs(std::move(v170_2_outputs));
    v169_3_outputs.push_back(v170_2);
  }
  const Space v169_3 = join_outputs(std::move(v169_3_outputs));
  return v169_3;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v178_3_branches = branches(c,s0);
  std::vector<Space> v178_3_outputs;
  v178_3_outputs.reserve(v178_3_branches.size());
  for (const auto& v178_3_branch : v178_3_branches) {
    const Path v178_3_head{v178_3_branch.first};
    const Space& v178_3_tail = v178_3_branch.second;
    const auto v179_2_branches = branches(c,v178_3_tail);
    std::vector<Space> v179_2_outputs;
    v179_2_outputs.reserve(v179_2_branches.size());
    for (const auto& v179_2_branch : v179_2_branches) {
      const Path v179_2_head{v179_2_branch.first};
      const Space& v179_2_tail = v179_2_branch.second;
      const Path v180_2 = concat_path(v178_3_head,v179_2_head);
      const auto v180_3_branches = branches(c,v179_2_tail);
      std::vector<Space> v180_3_outputs;
      v180_3_outputs.reserve(v180_3_branches.size());
      for (const auto& v180_3_branch : v180_3_branches) {
        const Path v180_3_head{v180_3_branch.first};
        const Space& v180_3_tail = v180_3_branch.second;
        const Path v181_2 = concat_path(v180_2,v180_3_head);
        const auto v181_3_branches = branches(c,v180_3_tail);
        std::vector<Space> v181_3_outputs;
        v181_3_outputs.reserve(v181_3_branches.size());
        for (const auto& v181_3_branch : v181_3_branches) {
          const Path v181_3_head{v181_3_branch.first};
          const Space& v181_3_tail = v181_3_branch.second;
          const Path v182_2 = concat_path(v181_2,v181_3_head);
          const auto v182_3_branches = branches(c,v181_3_tail);
          std::vector<Space> v182_3_outputs;
          v182_3_outputs.reserve(v182_3_branches.size());
          for (const auto& v182_3_branch : v182_3_branches) {
            const Path v182_3_head{v182_3_branch.first};
            const Space& v182_3_tail = v182_3_branch.second;
            const auto v183_2_branches = branches(c,v182_3_tail);
            std::vector<Space> v183_2_outputs;
            v183_2_outputs.reserve(v183_2_branches.size());
            for (const auto& v183_2_branch : v183_2_branches) {
              const Path v183_2_head{v183_2_branch.first};
              const Space& v183_2_tail = v183_2_branch.second;
              const Path v184_2 = concat_path(v182_3_head,v183_2_head);
              const auto v184_3_branches = branches(c,v183_2_tail);
              std::vector<Space> v184_3_outputs;
              v184_3_outputs.reserve(v184_3_branches.size());
              for (const auto& v184_3_branch : v184_3_branches) {
                const Path v184_3_head{v184_3_branch.first};
                const Space& v184_3_tail = v184_3_branch.second;
                const Path v185_2 = concat_path(v184_2,v184_3_head);
                const auto v185_3_branches = branches(c,v184_3_tail);
                std::vector<Space> v185_3_outputs;
                v185_3_outputs.reserve(v185_3_branches.size());
                for (const auto& v185_3_branch : v185_3_branches) {
                  const Path v185_3_head{v185_3_branch.first};
                  const Space& v185_3_tail = v185_3_branch.second;
                  const Path v186_2 = concat_path(v185_2,v185_3_head);
                  const Space v186_3 = routine_22(c, v186_2, p1, p0, v182_2, v185_3_tail);
                  v185_3_outputs.push_back(v186_3);
                }
                const Space v185_3 = join_outputs(std::move(v185_3_outputs));
                v184_3_outputs.push_back(v185_3);
              }
              const Space v184_3 = join_outputs(std::move(v184_3_outputs));
              v183_2_outputs.push_back(v184_3);
            }
            const Space v183_2 = join_outputs(std::move(v183_2_outputs));
            v182_3_outputs.push_back(v183_2);
          }
          const Space v182_3 = join_outputs(std::move(v182_3_outputs));
          v181_3_outputs.push_back(v182_3);
        }
        const Space v181_3 = join_outputs(std::move(v181_3_outputs));
        v180_3_outputs.push_back(v181_3);
      }
      const Space v180_3 = join_outputs(std::move(v180_3_outputs));
      v179_2_outputs.push_back(v180_3);
    }
    const Space v179_2 = join_outputs(std::move(v179_2_outputs));
    v178_3_outputs.push_back(v179_2);
  }
  const Space v178_3 = join_outputs(std::move(v178_3_outputs));
  return v178_3;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v187_3_branches = branches(c,s0);
  std::vector<Space> v187_3_outputs;
  v187_3_outputs.reserve(v187_3_branches.size());
  for (const auto& v187_3_branch : v187_3_branches) {
    const Path v187_3_head{v187_3_branch.first};
    const Space& v187_3_tail = v187_3_branch.second;
    const auto v188_2_branches = branches(c,v187_3_tail);
    std::vector<Space> v188_2_outputs;
    v188_2_outputs.reserve(v188_2_branches.size());
    for (const auto& v188_2_branch : v188_2_branches) {
      const Path v188_2_head{v188_2_branch.first};
      const Space& v188_2_tail = v188_2_branch.second;
      const Path v189_2 = concat_path(v187_3_head,v188_2_head);
      const auto v189_3_branches = branches(c,v188_2_tail);
      std::vector<Space> v189_3_outputs;
      v189_3_outputs.reserve(v189_3_branches.size());
      for (const auto& v189_3_branch : v189_3_branches) {
        const Path v189_3_head{v189_3_branch.first};
        const Space& v189_3_tail = v189_3_branch.second;
        const Path v190_2 = concat_path(v189_2,v189_3_head);
        const auto v190_3_branches = branches(c,v189_3_tail);
        std::vector<Space> v190_3_outputs;
        v190_3_outputs.reserve(v190_3_branches.size());
        for (const auto& v190_3_branch : v190_3_branches) {
          const Path v190_3_head{v190_3_branch.first};
          const Space& v190_3_tail = v190_3_branch.second;
          const Path v191_2 = concat_path(v190_2,v190_3_head);
          const auto v191_3_branches = branches(c,v190_3_tail);
          std::vector<Space> v191_3_outputs;
          v191_3_outputs.reserve(v191_3_branches.size());
          for (const auto& v191_3_branch : v191_3_branches) {
            const Path v191_3_head{v191_3_branch.first};
            const Space& v191_3_tail = v191_3_branch.second;
            const auto v192_2_branches = branches(c,v191_3_tail);
            std::vector<Space> v192_2_outputs;
            v192_2_outputs.reserve(v192_2_branches.size());
            for (const auto& v192_2_branch : v192_2_branches) {
              const Path v192_2_head{v192_2_branch.first};
              const Space& v192_2_tail = v192_2_branch.second;
              const Path v193_2 = concat_path(v191_3_head,v192_2_head);
              const auto v193_3_branches = branches(c,v192_2_tail);
              std::vector<Space> v193_3_outputs;
              v193_3_outputs.reserve(v193_3_branches.size());
              for (const auto& v193_3_branch : v193_3_branches) {
                const Path v193_3_head{v193_3_branch.first};
                const Space& v193_3_tail = v193_3_branch.second;
                const Path v194_2 = concat_path(v193_2,v193_3_head);
                const auto v194_3_branches = branches(c,v193_3_tail);
                std::vector<Space> v194_3_outputs;
                v194_3_outputs.reserve(v194_3_branches.size());
                for (const auto& v194_3_branch : v194_3_branches) {
                  const Path v194_3_head{v194_3_branch.first};
                  const Space& v194_3_tail = v194_3_branch.second;
                  const Path v195_2 = concat_path(v194_2,v194_3_head);
                  const Space v195_3 = routine_23(c, v195_2, p1, p0, v191_2, v194_3_tail);
                  v194_3_outputs.push_back(v195_3);
                }
                const Space v194_3 = join_outputs(std::move(v194_3_outputs));
                v193_3_outputs.push_back(v194_3);
              }
              const Space v193_3 = join_outputs(std::move(v193_3_outputs));
              v192_2_outputs.push_back(v193_3);
            }
            const Space v192_2 = join_outputs(std::move(v192_2_outputs));
            v191_3_outputs.push_back(v192_2);
          }
          const Space v191_3 = join_outputs(std::move(v191_3_outputs));
          v190_3_outputs.push_back(v191_3);
        }
        const Space v190_3 = join_outputs(std::move(v190_3_outputs));
        v189_3_outputs.push_back(v190_3);
      }
      const Space v189_3 = join_outputs(std::move(v189_3_outputs));
      v188_2_outputs.push_back(v189_3);
    }
    const Space v188_2 = join_outputs(std::move(v188_2_outputs));
    v187_3_outputs.push_back(v188_2);
  }
  const Space v187_3 = join_outputs(std::move(v187_3_outputs));
  return v187_3;
}

static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v196_3_branches = branches(c,s0);
  std::vector<Space> v196_3_outputs;
  v196_3_outputs.reserve(v196_3_branches.size());
  for (const auto& v196_3_branch : v196_3_branches) {
    const Path v196_3_head{v196_3_branch.first};
    const Space& v196_3_tail = v196_3_branch.second;
    const auto v197_2_branches = branches(c,v196_3_tail);
    std::vector<Space> v197_2_outputs;
    v197_2_outputs.reserve(v197_2_branches.size());
    for (const auto& v197_2_branch : v197_2_branches) {
      const Path v197_2_head{v197_2_branch.first};
      const Space& v197_2_tail = v197_2_branch.second;
      const Path v198_2 = concat_path(v196_3_head,v197_2_head);
      const auto v198_3_branches = branches(c,v197_2_tail);
      std::vector<Space> v198_3_outputs;
      v198_3_outputs.reserve(v198_3_branches.size());
      for (const auto& v198_3_branch : v198_3_branches) {
        const Path v198_3_head{v198_3_branch.first};
        const Space& v198_3_tail = v198_3_branch.second;
        const Path v199_2 = concat_path(v198_2,v198_3_head);
        const auto v199_3_branches = branches(c,v198_3_tail);
        std::vector<Space> v199_3_outputs;
        v199_3_outputs.reserve(v199_3_branches.size());
        for (const auto& v199_3_branch : v199_3_branches) {
          const Path v199_3_head{v199_3_branch.first};
          const Space& v199_3_tail = v199_3_branch.second;
          const Path v200_2 = concat_path(v199_2,v199_3_head);
          const auto v200_3_branches = branches(c,v199_3_tail);
          std::vector<Space> v200_3_outputs;
          v200_3_outputs.reserve(v200_3_branches.size());
          for (const auto& v200_3_branch : v200_3_branches) {
            const Path v200_3_head{v200_3_branch.first};
            const Space& v200_3_tail = v200_3_branch.second;
            const auto v201_2_branches = branches(c,v200_3_tail);
            std::vector<Space> v201_2_outputs;
            v201_2_outputs.reserve(v201_2_branches.size());
            for (const auto& v201_2_branch : v201_2_branches) {
              const Path v201_2_head{v201_2_branch.first};
              const Space& v201_2_tail = v201_2_branch.second;
              const Path v202_2 = concat_path(v200_3_head,v201_2_head);
              const auto v202_3_branches = branches(c,v201_2_tail);
              std::vector<Space> v202_3_outputs;
              v202_3_outputs.reserve(v202_3_branches.size());
              for (const auto& v202_3_branch : v202_3_branches) {
                const Path v202_3_head{v202_3_branch.first};
                const Space& v202_3_tail = v202_3_branch.second;
                const Path v203_2 = concat_path(v202_2,v202_3_head);
                const auto v203_3_branches = branches(c,v202_3_tail);
                std::vector<Space> v203_3_outputs;
                v203_3_outputs.reserve(v203_3_branches.size());
                for (const auto& v203_3_branch : v203_3_branches) {
                  const Path v203_3_head{v203_3_branch.first};
                  const Space& v203_3_tail = v203_3_branch.second;
                  const Path v204_2 = concat_path(v203_2,v203_3_head);
                  const Space v204_3 = routine_24(c, v204_2, p1, p0, v200_2, v203_3_tail);
                  v203_3_outputs.push_back(v204_3);
                }
                const Space v203_3 = join_outputs(std::move(v203_3_outputs));
                v202_3_outputs.push_back(v203_3);
              }
              const Space v202_3 = join_outputs(std::move(v202_3_outputs));
              v201_2_outputs.push_back(v202_3);
            }
            const Space v201_2 = join_outputs(std::move(v201_2_outputs));
            v200_3_outputs.push_back(v201_2);
          }
          const Space v200_3 = join_outputs(std::move(v200_3_outputs));
          v199_3_outputs.push_back(v200_3);
        }
        const Space v199_3 = join_outputs(std::move(v199_3_outputs));
        v198_3_outputs.push_back(v199_3);
      }
      const Space v198_3 = join_outputs(std::move(v198_3_outputs));
      v197_2_outputs.push_back(v198_3);
    }
    const Space v197_2 = join_outputs(std::move(v197_2_outputs));
    v196_3_outputs.push_back(v197_2);
  }
  const Space v196_3 = join_outputs(std::move(v196_3_outputs));
  return v196_3;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v205_3_branches = branches(c,s0);
  std::vector<Space> v205_3_outputs;
  v205_3_outputs.reserve(v205_3_branches.size());
  for (const auto& v205_3_branch : v205_3_branches) {
    const Path v205_3_head{v205_3_branch.first};
    const Space& v205_3_tail = v205_3_branch.second;
    const auto v206_2_branches = branches(c,v205_3_tail);
    std::vector<Space> v206_2_outputs;
    v206_2_outputs.reserve(v206_2_branches.size());
    for (const auto& v206_2_branch : v206_2_branches) {
      const Path v206_2_head{v206_2_branch.first};
      const Space& v206_2_tail = v206_2_branch.second;
      const Path v207_2 = concat_path(v205_3_head,v206_2_head);
      const auto v207_3_branches = branches(c,v206_2_tail);
      std::vector<Space> v207_3_outputs;
      v207_3_outputs.reserve(v207_3_branches.size());
      for (const auto& v207_3_branch : v207_3_branches) {
        const Path v207_3_head{v207_3_branch.first};
        const Space& v207_3_tail = v207_3_branch.second;
        const Path v208_2 = concat_path(v207_2,v207_3_head);
        const auto v208_3_branches = branches(c,v207_3_tail);
        std::vector<Space> v208_3_outputs;
        v208_3_outputs.reserve(v208_3_branches.size());
        for (const auto& v208_3_branch : v208_3_branches) {
          const Path v208_3_head{v208_3_branch.first};
          const Space& v208_3_tail = v208_3_branch.second;
          const Path v209_2 = concat_path(v208_2,v208_3_head);
          const auto v209_3_branches = branches(c,v208_3_tail);
          std::vector<Space> v209_3_outputs;
          v209_3_outputs.reserve(v209_3_branches.size());
          for (const auto& v209_3_branch : v209_3_branches) {
            const Path v209_3_head{v209_3_branch.first};
            const Space& v209_3_tail = v209_3_branch.second;
            const auto v210_2_branches = branches(c,v209_3_tail);
            std::vector<Space> v210_2_outputs;
            v210_2_outputs.reserve(v210_2_branches.size());
            for (const auto& v210_2_branch : v210_2_branches) {
              const Path v210_2_head{v210_2_branch.first};
              const Space& v210_2_tail = v210_2_branch.second;
              const Path v211_2 = concat_path(v209_3_head,v210_2_head);
              const auto v211_3_branches = branches(c,v210_2_tail);
              std::vector<Space> v211_3_outputs;
              v211_3_outputs.reserve(v211_3_branches.size());
              for (const auto& v211_3_branch : v211_3_branches) {
                const Path v211_3_head{v211_3_branch.first};
                const Space& v211_3_tail = v211_3_branch.second;
                const Path v212_2 = concat_path(v211_2,v211_3_head);
                const auto v212_3_branches = branches(c,v211_3_tail);
                std::vector<Space> v212_3_outputs;
                v212_3_outputs.reserve(v212_3_branches.size());
                for (const auto& v212_3_branch : v212_3_branches) {
                  const Path v212_3_head{v212_3_branch.first};
                  const Space& v212_3_tail = v212_3_branch.second;
                  const Path v213_2 = concat_path(v212_2,v212_3_head);
                  const Space v213_3 = routine_25(c, v213_2, p1, p0, v209_2, v212_3_tail);
                  v212_3_outputs.push_back(v213_3);
                }
                const Space v212_3 = join_outputs(std::move(v212_3_outputs));
                v211_3_outputs.push_back(v212_3);
              }
              const Space v211_3 = join_outputs(std::move(v211_3_outputs));
              v210_2_outputs.push_back(v211_3);
            }
            const Space v210_2 = join_outputs(std::move(v210_2_outputs));
            v209_3_outputs.push_back(v210_2);
          }
          const Space v209_3 = join_outputs(std::move(v209_3_outputs));
          v208_3_outputs.push_back(v209_3);
        }
        const Space v208_3 = join_outputs(std::move(v208_3_outputs));
        v207_3_outputs.push_back(v208_3);
      }
      const Space v207_3 = join_outputs(std::move(v207_3_outputs));
      v206_2_outputs.push_back(v207_3);
    }
    const Space v206_2 = join_outputs(std::move(v206_2_outputs));
    v205_3_outputs.push_back(v206_2);
  }
  const Space v205_3 = join_outputs(std::move(v205_3_outputs));
  return v205_3;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v214_3_branches = branches(c,s0);
  std::vector<Space> v214_3_outputs;
  v214_3_outputs.reserve(v214_3_branches.size());
  for (const auto& v214_3_branch : v214_3_branches) {
    const Path v214_3_head{v214_3_branch.first};
    const Space& v214_3_tail = v214_3_branch.second;
    const auto v215_2_branches = branches(c,v214_3_tail);
    std::vector<Space> v215_2_outputs;
    v215_2_outputs.reserve(v215_2_branches.size());
    for (const auto& v215_2_branch : v215_2_branches) {
      const Path v215_2_head{v215_2_branch.first};
      const Space& v215_2_tail = v215_2_branch.second;
      const Path v216_2 = concat_path(v214_3_head,v215_2_head);
      const auto v216_3_branches = branches(c,v215_2_tail);
      std::vector<Space> v216_3_outputs;
      v216_3_outputs.reserve(v216_3_branches.size());
      for (const auto& v216_3_branch : v216_3_branches) {
        const Path v216_3_head{v216_3_branch.first};
        const Space& v216_3_tail = v216_3_branch.second;
        const Path v217_2 = concat_path(v216_2,v216_3_head);
        const auto v217_3_branches = branches(c,v216_3_tail);
        std::vector<Space> v217_3_outputs;
        v217_3_outputs.reserve(v217_3_branches.size());
        for (const auto& v217_3_branch : v217_3_branches) {
          const Path v217_3_head{v217_3_branch.first};
          const Space& v217_3_tail = v217_3_branch.second;
          const Path v218_2 = concat_path(v217_2,v217_3_head);
          const auto v218_3_branches = branches(c,v217_3_tail);
          std::vector<Space> v218_3_outputs;
          v218_3_outputs.reserve(v218_3_branches.size());
          for (const auto& v218_3_branch : v218_3_branches) {
            const Path v218_3_head{v218_3_branch.first};
            const Space& v218_3_tail = v218_3_branch.second;
            const auto v219_2_branches = branches(c,v218_3_tail);
            std::vector<Space> v219_2_outputs;
            v219_2_outputs.reserve(v219_2_branches.size());
            for (const auto& v219_2_branch : v219_2_branches) {
              const Path v219_2_head{v219_2_branch.first};
              const Space& v219_2_tail = v219_2_branch.second;
              const Path v220_2 = concat_path(v218_3_head,v219_2_head);
              const auto v220_3_branches = branches(c,v219_2_tail);
              std::vector<Space> v220_3_outputs;
              v220_3_outputs.reserve(v220_3_branches.size());
              for (const auto& v220_3_branch : v220_3_branches) {
                const Path v220_3_head{v220_3_branch.first};
                const Space& v220_3_tail = v220_3_branch.second;
                const Path v221_2 = concat_path(v220_2,v220_3_head);
                const auto v221_3_branches = branches(c,v220_3_tail);
                std::vector<Space> v221_3_outputs;
                v221_3_outputs.reserve(v221_3_branches.size());
                for (const auto& v221_3_branch : v221_3_branches) {
                  const Path v221_3_head{v221_3_branch.first};
                  const Space& v221_3_tail = v221_3_branch.second;
                  const Path v222_2 = concat_path(v221_2,v221_3_head);
                  const Space v222_3 = routine_26(c, v222_2, p1, p0, v218_2, v221_3_tail);
                  v221_3_outputs.push_back(v222_3);
                }
                const Space v221_3 = join_outputs(std::move(v221_3_outputs));
                v220_3_outputs.push_back(v221_3);
              }
              const Space v220_3 = join_outputs(std::move(v220_3_outputs));
              v219_2_outputs.push_back(v220_3);
            }
            const Space v219_2 = join_outputs(std::move(v219_2_outputs));
            v218_3_outputs.push_back(v219_2);
          }
          const Space v218_3 = join_outputs(std::move(v218_3_outputs));
          v217_3_outputs.push_back(v218_3);
        }
        const Space v217_3 = join_outputs(std::move(v217_3_outputs));
        v216_3_outputs.push_back(v217_3);
      }
      const Space v216_3 = join_outputs(std::move(v216_3_outputs));
      v215_2_outputs.push_back(v216_3);
    }
    const Space v215_2 = join_outputs(std::move(v215_2_outputs));
    v214_3_outputs.push_back(v215_2);
  }
  const Space v214_3 = join_outputs(std::move(v214_3_outputs));
  return v214_3;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v223_3_branches = branches(c,s0);
  std::vector<Space> v223_3_outputs;
  v223_3_outputs.reserve(v223_3_branches.size());
  for (const auto& v223_3_branch : v223_3_branches) {
    const Path v223_3_head{v223_3_branch.first};
    const Space& v223_3_tail = v223_3_branch.second;
    const auto v224_2_branches = branches(c,v223_3_tail);
    std::vector<Space> v224_2_outputs;
    v224_2_outputs.reserve(v224_2_branches.size());
    for (const auto& v224_2_branch : v224_2_branches) {
      const Path v224_2_head{v224_2_branch.first};
      const Space& v224_2_tail = v224_2_branch.second;
      const Path v225_2 = concat_path(v223_3_head,v224_2_head);
      const auto v225_3_branches = branches(c,v224_2_tail);
      std::vector<Space> v225_3_outputs;
      v225_3_outputs.reserve(v225_3_branches.size());
      for (const auto& v225_3_branch : v225_3_branches) {
        const Path v225_3_head{v225_3_branch.first};
        const Space& v225_3_tail = v225_3_branch.second;
        const Path v226_2 = concat_path(v225_2,v225_3_head);
        const auto v226_3_branches = branches(c,v225_3_tail);
        std::vector<Space> v226_3_outputs;
        v226_3_outputs.reserve(v226_3_branches.size());
        for (const auto& v226_3_branch : v226_3_branches) {
          const Path v226_3_head{v226_3_branch.first};
          const Space& v226_3_tail = v226_3_branch.second;
          const Path v227_2 = concat_path(v226_2,v226_3_head);
          const auto v227_3_branches = branches(c,v226_3_tail);
          std::vector<Space> v227_3_outputs;
          v227_3_outputs.reserve(v227_3_branches.size());
          for (const auto& v227_3_branch : v227_3_branches) {
            const Path v227_3_head{v227_3_branch.first};
            const Space& v227_3_tail = v227_3_branch.second;
            const auto v228_2_branches = branches(c,v227_3_tail);
            std::vector<Space> v228_2_outputs;
            v228_2_outputs.reserve(v228_2_branches.size());
            for (const auto& v228_2_branch : v228_2_branches) {
              const Path v228_2_head{v228_2_branch.first};
              const Space& v228_2_tail = v228_2_branch.second;
              const Path v229_2 = concat_path(v227_3_head,v228_2_head);
              const auto v229_3_branches = branches(c,v228_2_tail);
              std::vector<Space> v229_3_outputs;
              v229_3_outputs.reserve(v229_3_branches.size());
              for (const auto& v229_3_branch : v229_3_branches) {
                const Path v229_3_head{v229_3_branch.first};
                const Space& v229_3_tail = v229_3_branch.second;
                const Path v230_2 = concat_path(v229_2,v229_3_head);
                const auto v230_3_branches = branches(c,v229_3_tail);
                std::vector<Space> v230_3_outputs;
                v230_3_outputs.reserve(v230_3_branches.size());
                for (const auto& v230_3_branch : v230_3_branches) {
                  const Path v230_3_head{v230_3_branch.first};
                  const Space& v230_3_tail = v230_3_branch.second;
                  const Path v231_2 = concat_path(v230_2,v230_3_head);
                  const Space v231_3 = routine_27(c, v231_2, p1, p0, v227_2, v230_3_tail);
                  v230_3_outputs.push_back(v231_3);
                }
                const Space v230_3 = join_outputs(std::move(v230_3_outputs));
                v229_3_outputs.push_back(v230_3);
              }
              const Space v229_3 = join_outputs(std::move(v229_3_outputs));
              v228_2_outputs.push_back(v229_3);
            }
            const Space v228_2 = join_outputs(std::move(v228_2_outputs));
            v227_3_outputs.push_back(v228_2);
          }
          const Space v227_3 = join_outputs(std::move(v227_3_outputs));
          v226_3_outputs.push_back(v227_3);
        }
        const Space v226_3 = join_outputs(std::move(v226_3_outputs));
        v225_3_outputs.push_back(v226_3);
      }
      const Space v225_3 = join_outputs(std::move(v225_3_outputs));
      v224_2_outputs.push_back(v225_3);
    }
    const Space v224_2 = join_outputs(std::move(v224_2_outputs));
    v223_3_outputs.push_back(v224_2);
  }
  const Space v223_3 = join_outputs(std::move(v223_3_outputs));
  return v223_3;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v232_3_branches = branches(c,s0);
  std::vector<Space> v232_3_outputs;
  v232_3_outputs.reserve(v232_3_branches.size());
  for (const auto& v232_3_branch : v232_3_branches) {
    const Path v232_3_head{v232_3_branch.first};
    const Space& v232_3_tail = v232_3_branch.second;
    const auto v233_2_branches = branches(c,v232_3_tail);
    std::vector<Space> v233_2_outputs;
    v233_2_outputs.reserve(v233_2_branches.size());
    for (const auto& v233_2_branch : v233_2_branches) {
      const Path v233_2_head{v233_2_branch.first};
      const Space& v233_2_tail = v233_2_branch.second;
      const Path v234_2 = concat_path(v232_3_head,v233_2_head);
      const auto v234_3_branches = branches(c,v233_2_tail);
      std::vector<Space> v234_3_outputs;
      v234_3_outputs.reserve(v234_3_branches.size());
      for (const auto& v234_3_branch : v234_3_branches) {
        const Path v234_3_head{v234_3_branch.first};
        const Space& v234_3_tail = v234_3_branch.second;
        const Path v235_2 = concat_path(v234_2,v234_3_head);
        const auto v235_3_branches = branches(c,v234_3_tail);
        std::vector<Space> v235_3_outputs;
        v235_3_outputs.reserve(v235_3_branches.size());
        for (const auto& v235_3_branch : v235_3_branches) {
          const Path v235_3_head{v235_3_branch.first};
          const Space& v235_3_tail = v235_3_branch.second;
          const Path v236_2 = concat_path(v235_2,v235_3_head);
          const auto v236_3_branches = branches(c,v235_3_tail);
          std::vector<Space> v236_3_outputs;
          v236_3_outputs.reserve(v236_3_branches.size());
          for (const auto& v236_3_branch : v236_3_branches) {
            const Path v236_3_head{v236_3_branch.first};
            const Space& v236_3_tail = v236_3_branch.second;
            const auto v237_2_branches = branches(c,v236_3_tail);
            std::vector<Space> v237_2_outputs;
            v237_2_outputs.reserve(v237_2_branches.size());
            for (const auto& v237_2_branch : v237_2_branches) {
              const Path v237_2_head{v237_2_branch.first};
              const Space& v237_2_tail = v237_2_branch.second;
              const Path v238_2 = concat_path(v236_3_head,v237_2_head);
              const auto v238_3_branches = branches(c,v237_2_tail);
              std::vector<Space> v238_3_outputs;
              v238_3_outputs.reserve(v238_3_branches.size());
              for (const auto& v238_3_branch : v238_3_branches) {
                const Path v238_3_head{v238_3_branch.first};
                const Space& v238_3_tail = v238_3_branch.second;
                const Path v239_2 = concat_path(v238_2,v238_3_head);
                const auto v239_3_branches = branches(c,v238_3_tail);
                std::vector<Space> v239_3_outputs;
                v239_3_outputs.reserve(v239_3_branches.size());
                for (const auto& v239_3_branch : v239_3_branches) {
                  const Path v239_3_head{v239_3_branch.first};
                  const Space& v239_3_tail = v239_3_branch.second;
                  const Path v240_2 = concat_path(v239_2,v239_3_head);
                  const Space v240_3 = routine_28(c, v240_2, p1, p0, v236_2, v239_3_tail);
                  v239_3_outputs.push_back(v240_3);
                }
                const Space v239_3 = join_outputs(std::move(v239_3_outputs));
                v238_3_outputs.push_back(v239_3);
              }
              const Space v238_3 = join_outputs(std::move(v238_3_outputs));
              v237_2_outputs.push_back(v238_3);
            }
            const Space v237_2 = join_outputs(std::move(v237_2_outputs));
            v236_3_outputs.push_back(v237_2);
          }
          const Space v236_3 = join_outputs(std::move(v236_3_outputs));
          v235_3_outputs.push_back(v236_3);
        }
        const Space v235_3 = join_outputs(std::move(v235_3_outputs));
        v234_3_outputs.push_back(v235_3);
      }
      const Space v234_3 = join_outputs(std::move(v234_3_outputs));
      v233_2_outputs.push_back(v234_3);
    }
    const Space v233_2 = join_outputs(std::move(v233_2_outputs));
    v232_3_outputs.push_back(v233_2);
  }
  const Space v232_3 = join_outputs(std::move(v232_3_outputs));
  return v232_3;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v241_4_branches = branches(c,s0);
  std::vector<Space> v241_4_outputs;
  v241_4_outputs.reserve(v241_4_branches.size());
  for (const auto& v241_4_branch : v241_4_branches) {
    const Path v241_4_head{v241_4_branch.first};
    const Space& v241_4_tail = v241_4_branch.second;
    const auto v242_2_branches = branches(c,v241_4_tail);
    std::vector<Space> v242_2_outputs;
    v242_2_outputs.reserve(v242_2_branches.size());
    for (const auto& v242_2_branch : v242_2_branches) {
      const Path v242_2_head{v242_2_branch.first};
      const Space& v242_2_tail = v242_2_branch.second;
      const Path v243_2 = concat_path(v241_4_head,v242_2_head);
      const auto v243_3_branches = branches(c,v242_2_tail);
      std::vector<Space> v243_3_outputs;
      v243_3_outputs.reserve(v243_3_branches.size());
      for (const auto& v243_3_branch : v243_3_branches) {
        const Path v243_3_head{v243_3_branch.first};
        const Space& v243_3_tail = v243_3_branch.second;
        const Space v244_2 = head_space(v243_3_tail,256);
        const Path v244_3 = concat_path(v243_2,v243_3_head);
        const Space v244_4 = wrap(v244_2,v244_3);
        v243_3_outputs.push_back(v244_4);
      }
      const Space v243_3 = join_outputs(std::move(v243_3_outputs));
      v242_2_outputs.push_back(v243_3);
    }
    const Space v242_2 = join_outputs(std::move(v242_2_outputs));
    v241_4_outputs.push_back(v242_2);
  }
  const Space v241_4 = join_outputs(std::move(v241_4_outputs));
  const Space v241_5 = raffine(constant_72,v241_4);
  const Space v241_6 = unite(v241_5,s0);
  const Path v241_7 = concat_path(p1,p0);
  const Space v241_8 = wrap(v241_6,v241_7);
  return v241_8;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v245_4_branches = branches(c,s0);
  std::vector<Space> v245_4_outputs;
  v245_4_outputs.reserve(v245_4_branches.size());
  for (const auto& v245_4_branch : v245_4_branches) {
    const Path v245_4_head{v245_4_branch.first};
    const Space& v245_4_tail = v245_4_branch.second;
    const auto v246_2_branches = branches(c,v245_4_tail);
    std::vector<Space> v246_2_outputs;
    v246_2_outputs.reserve(v246_2_branches.size());
    for (const auto& v246_2_branch : v246_2_branches) {
      const Path v246_2_head{v246_2_branch.first};
      const Space& v246_2_tail = v246_2_branch.second;
      const Path v247_2 = concat_path(v245_4_head,v246_2_head);
      const auto v247_3_branches = branches(c,v246_2_tail);
      std::vector<Space> v247_3_outputs;
      v247_3_outputs.reserve(v247_3_branches.size());
      for (const auto& v247_3_branch : v247_3_branches) {
        const Path v247_3_head{v247_3_branch.first};
        const Space& v247_3_tail = v247_3_branch.second;
        const Space v248_2 = head_space(v247_3_tail,256);
        const Path v248_3 = concat_path(v247_2,v247_3_head);
        const Space v248_4 = wrap(v248_2,v248_3);
        v247_3_outputs.push_back(v248_4);
      }
      const Space v247_3 = join_outputs(std::move(v247_3_outputs));
      v246_2_outputs.push_back(v247_3);
    }
    const Space v246_2 = join_outputs(std::move(v246_2_outputs));
    v245_4_outputs.push_back(v246_2);
  }
  const Space v245_4 = join_outputs(std::move(v245_4_outputs));
  const Space v245_5 = raffine(constant_72,v245_4);
  const Space v245_6 = unite(v245_5,s0);
  const Path v245_7 = concat_path(p1,p0);
  const Space v245_8 = wrap(v245_6,v245_7);
  return v245_8;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  const Space v249_3 = singleton(p0);
  const Space v249_4 = intersect(constant_47,v249_3);
  const Space v249_6 = unwrap(s0,constant_3);
  const Space v249_8 = unwrap(s0,constant_5);
  const Space v249_9 = compose(v249_6,v249_8);
  const Space v249_11 = unwrap(s0,constant_7);
  const Space v249_12 = compose(v249_9,v249_11);
  const Space v249_14 = unwrap(s0,constant_9);
  const Space v249_15 = compose(v249_12,v249_14);
  const Space v249_17 = unwrap(s0,constant_11);
  const Space v249_18 = compose(v249_15,v249_17);
  const Space v249_20 = unwrap(s0,constant_13);
  const Space v249_21 = compose(v249_18,v249_20);
  const Space v249_23 = unwrap(s0,constant_15);
  const Space v249_24 = compose(v249_21,v249_23);
  const Space v249_26 = unwrap(s0,constant_17);
  const Space v249_27 = compose(v249_24,v249_26);
  const Space v249_28 = compose(v249_4,v249_27);
  const Space v249_30 = intersect(constant_48,v249_3);
  const Space v249_32 = unwrap(s0,constant_1);
  const Space v249_33 = compose(v249_32,v249_8);
  const Space v249_34 = compose(v249_33,v249_11);
  const Space v249_35 = compose(v249_34,v249_14);
  const Space v249_36 = compose(v249_35,v249_17);
  const Space v249_37 = compose(v249_36,v249_20);
  const Space v249_38 = compose(v249_37,v249_23);
  const Space v249_39 = compose(v249_38,v249_26);
  const Space v249_40 = compose(v249_30,v249_39);
  const Space v249_41 = unite(v249_28,v249_40);
  const Space v249_43 = intersect(constant_49,v249_3);
  const Space v249_44 = compose(v249_32,v249_6);
  const Space v249_45 = compose(v249_44,v249_11);
  const Space v249_46 = compose(v249_45,v249_14);
  const Space v249_47 = compose(v249_46,v249_17);
  const Space v249_48 = compose(v249_47,v249_20);
  const Space v249_49 = compose(v249_48,v249_23);
  const Space v249_50 = compose(v249_49,v249_26);
  const Space v249_51 = compose(v249_43,v249_50);
  const Space v249_52 = unite(v249_41,v249_51);
  const Space v249_54 = intersect(constant_50,v249_3);
  const Space v249_55 = compose(v249_44,v249_8);
  const Space v249_56 = compose(v249_55,v249_14);
  const Space v249_57 = compose(v249_56,v249_17);
  const Space v249_58 = compose(v249_57,v249_20);
  const Space v249_59 = compose(v249_58,v249_23);
  const Space v249_60 = compose(v249_59,v249_26);
  const Space v249_61 = compose(v249_54,v249_60);
  const Space v249_62 = unite(v249_52,v249_61);
  const Space v249_64 = intersect(constant_51,v249_3);
  const Space v249_65 = compose(v249_55,v249_11);
  const Space v249_66 = compose(v249_65,v249_17);
  const Space v249_67 = compose(v249_66,v249_20);
  const Space v249_68 = compose(v249_67,v249_23);
  const Space v249_69 = compose(v249_68,v249_26);
  const Space v249_70 = compose(v249_64,v249_69);
  const Space v249_71 = unite(v249_62,v249_70);
  const Space v249_73 = intersect(constant_52,v249_3);
  const Space v249_74 = compose(v249_65,v249_14);
  const Space v249_75 = compose(v249_74,v249_20);
  const Space v249_76 = compose(v249_75,v249_23);
  const Space v249_77 = compose(v249_76,v249_26);
  const Space v249_78 = compose(v249_73,v249_77);
  const Space v249_79 = unite(v249_71,v249_78);
  const Space v249_81 = intersect(constant_53,v249_3);
  const Space v249_82 = compose(v249_74,v249_17);
  const Space v249_83 = compose(v249_82,v249_23);
  const Space v249_84 = compose(v249_83,v249_26);
  const Space v249_85 = compose(v249_81,v249_84);
  const Space v249_86 = unite(v249_79,v249_85);
  const Space v249_88 = intersect(constant_54,v249_3);
  const Space v249_89 = compose(v249_82,v249_20);
  const Space v249_90 = compose(v249_89,v249_26);
  const Space v249_91 = compose(v249_88,v249_90);
  const Space v249_92 = unite(v249_86,v249_91);
  const Space v249_94 = intersect(constant_55,v249_3);
  const Space v249_95 = compose(v249_89,v249_23);
  const Space v249_96 = compose(v249_94,v249_95);
  const Space v249_97 = unite(v249_92,v249_96);
  return v249_97;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v250_5_branches = branches(c,s0);
  std::vector<Space> v250_5_outputs;
  v250_5_outputs.reserve(v250_5_branches.size());
  for (const auto& v250_5_branch : v250_5_branches) {
    const Path v250_5_head{v250_5_branch.first};
    const Space& v250_5_tail = v250_5_branch.second;
    const auto v251_2_branches = branches(c,v250_5_tail);
    std::vector<Space> v251_2_outputs;
    v251_2_outputs.reserve(v251_2_branches.size());
    for (const auto& v251_2_branch : v251_2_branches) {
      const Path v251_2_head{v251_2_branch.first};
      const Space& v251_2_tail = v251_2_branch.second;
      const Path v252_2 = concat_path(v250_5_head,v251_2_head);
      const auto v252_3_branches = branches(c,v251_2_tail);
      std::vector<Space> v252_3_outputs;
      v252_3_outputs.reserve(v252_3_branches.size());
      for (const auto& v252_3_branch : v252_3_branches) {
        const Path v252_3_head{v252_3_branch.first};
        const Space& v252_3_tail = v252_3_branch.second;
        const Path v253_2 = concat_path(v252_2,v252_3_head);
        const auto v253_3_branches = branches(c,v252_3_tail);
        std::vector<Space> v253_3_outputs;
        v253_3_outputs.reserve(v253_3_branches.size());
        for (const auto& v253_3_branch : v253_3_branches) {
          const Path v253_3_head{v253_3_branch.first};
          const Space& v253_3_tail = v253_3_branch.second;
          const Path v254_2 = concat_path(v253_2,v253_3_head);
          const auto v254_3_branches = branches(c,v253_3_tail);
          std::vector<Space> v254_3_outputs;
          v254_3_outputs.reserve(v254_3_branches.size());
          for (const auto& v254_3_branch : v254_3_branches) {
            const Path v254_3_head{v254_3_branch.first};
            const Space& v254_3_tail = v254_3_branch.second;
            const auto v255_2_branches = branches(c,v254_3_tail);
            std::vector<Space> v255_2_outputs;
            v255_2_outputs.reserve(v255_2_branches.size());
            for (const auto& v255_2_branch : v255_2_branches) {
              const Path v255_2_head{v255_2_branch.first};
              const Space& v255_2_tail = v255_2_branch.second;
              const Path v256_2 = concat_path(v254_3_head,v255_2_head);
              const auto v256_3_branches = branches(c,v255_2_tail);
              std::vector<Space> v256_3_outputs;
              v256_3_outputs.reserve(v256_3_branches.size());
              for (const auto& v256_3_branch : v256_3_branches) {
                const Path v256_3_head{v256_3_branch.first};
                const Space& v256_3_tail = v256_3_branch.second;
                const Path v257_2 = concat_path(v256_2,v256_3_head);
                const auto v257_3_branches = branches(c,v256_3_tail);
                std::vector<Space> v257_3_outputs;
                v257_3_outputs.reserve(v257_3_branches.size());
                for (const auto& v257_3_branch : v257_3_branches) {
                  const Path v257_3_head{v257_3_branch.first};
                  const Space& v257_3_tail = v257_3_branch.second;
                  const Path v258_2 = concat_path(v257_2,v257_3_head);
                  const Space v258_3 = routine_29(c, v258_2, p1, p2, p3, p0, v254_2, v257_3_tail);
                  v257_3_outputs.push_back(v258_3);
                }
                const Space v257_3 = join_outputs(std::move(v257_3_outputs));
                v256_3_outputs.push_back(v257_3);
              }
              const Space v256_3 = join_outputs(std::move(v256_3_outputs));
              v255_2_outputs.push_back(v256_3);
            }
            const Space v255_2 = join_outputs(std::move(v255_2_outputs));
            v254_3_outputs.push_back(v255_2);
          }
          const Space v254_3 = join_outputs(std::move(v254_3_outputs));
          v253_3_outputs.push_back(v254_3);
        }
        const Space v253_3 = join_outputs(std::move(v253_3_outputs));
        v252_3_outputs.push_back(v253_3);
      }
      const Space v252_3 = join_outputs(std::move(v252_3_outputs));
      v251_2_outputs.push_back(v252_3);
    }
    const Space v251_2 = join_outputs(std::move(v251_2_outputs));
    v250_5_outputs.push_back(v251_2);
  }
  const Space v250_5 = join_outputs(std::move(v250_5_outputs));
  return v250_5;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v259_5_branches = branches(c,s0);
  std::vector<Space> v259_5_outputs;
  v259_5_outputs.reserve(v259_5_branches.size());
  for (const auto& v259_5_branch : v259_5_branches) {
    const Path v259_5_head{v259_5_branch.first};
    const Space& v259_5_tail = v259_5_branch.second;
    const auto v260_2_branches = branches(c,v259_5_tail);
    std::vector<Space> v260_2_outputs;
    v260_2_outputs.reserve(v260_2_branches.size());
    for (const auto& v260_2_branch : v260_2_branches) {
      const Path v260_2_head{v260_2_branch.first};
      const Space& v260_2_tail = v260_2_branch.second;
      const Path v261_2 = concat_path(v259_5_head,v260_2_head);
      const auto v261_3_branches = branches(c,v260_2_tail);
      std::vector<Space> v261_3_outputs;
      v261_3_outputs.reserve(v261_3_branches.size());
      for (const auto& v261_3_branch : v261_3_branches) {
        const Path v261_3_head{v261_3_branch.first};
        const Space& v261_3_tail = v261_3_branch.second;
        const Path v262_2 = concat_path(v261_2,v261_3_head);
        const auto v262_3_branches = branches(c,v261_3_tail);
        std::vector<Space> v262_3_outputs;
        v262_3_outputs.reserve(v262_3_branches.size());
        for (const auto& v262_3_branch : v262_3_branches) {
          const Path v262_3_head{v262_3_branch.first};
          const Space& v262_3_tail = v262_3_branch.second;
          const Path v263_2 = concat_path(v262_2,v262_3_head);
          const auto v263_3_branches = branches(c,v262_3_tail);
          std::vector<Space> v263_3_outputs;
          v263_3_outputs.reserve(v263_3_branches.size());
          for (const auto& v263_3_branch : v263_3_branches) {
            const Path v263_3_head{v263_3_branch.first};
            const Space& v263_3_tail = v263_3_branch.second;
            const auto v264_2_branches = branches(c,v263_3_tail);
            std::vector<Space> v264_2_outputs;
            v264_2_outputs.reserve(v264_2_branches.size());
            for (const auto& v264_2_branch : v264_2_branches) {
              const Path v264_2_head{v264_2_branch.first};
              const Space& v264_2_tail = v264_2_branch.second;
              const Path v265_2 = concat_path(v263_3_head,v264_2_head);
              const auto v265_3_branches = branches(c,v264_2_tail);
              std::vector<Space> v265_3_outputs;
              v265_3_outputs.reserve(v265_3_branches.size());
              for (const auto& v265_3_branch : v265_3_branches) {
                const Path v265_3_head{v265_3_branch.first};
                const Space& v265_3_tail = v265_3_branch.second;
                const Path v266_2 = concat_path(v265_2,v265_3_head);
                const auto v266_3_branches = branches(c,v265_3_tail);
                std::vector<Space> v266_3_outputs;
                v266_3_outputs.reserve(v266_3_branches.size());
                for (const auto& v266_3_branch : v266_3_branches) {
                  const Path v266_3_head{v266_3_branch.first};
                  const Space& v266_3_tail = v266_3_branch.second;
                  const Path v267_2 = concat_path(v266_2,v266_3_head);
                  const Space v267_3 = routine_30(c, v267_2, p1, p2, p3, p0, v263_2, v266_3_tail);
                  v266_3_outputs.push_back(v267_3);
                }
                const Space v266_3 = join_outputs(std::move(v266_3_outputs));
                v265_3_outputs.push_back(v266_3);
              }
              const Space v265_3 = join_outputs(std::move(v265_3_outputs));
              v264_2_outputs.push_back(v265_3);
            }
            const Space v264_2 = join_outputs(std::move(v264_2_outputs));
            v263_3_outputs.push_back(v264_2);
          }
          const Space v263_3 = join_outputs(std::move(v263_3_outputs));
          v262_3_outputs.push_back(v263_3);
        }
        const Space v262_3 = join_outputs(std::move(v262_3_outputs));
        v261_3_outputs.push_back(v262_3);
      }
      const Space v261_3 = join_outputs(std::move(v261_3_outputs));
      v260_2_outputs.push_back(v261_3);
    }
    const Space v260_2 = join_outputs(std::move(v260_2_outputs));
    v259_5_outputs.push_back(v260_2);
  }
  const Space v259_5 = join_outputs(std::move(v259_5_outputs));
  return v259_5;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v268_5_branches = branches(c,s0);
  std::vector<Space> v268_5_outputs;
  v268_5_outputs.reserve(v268_5_branches.size());
  for (const auto& v268_5_branch : v268_5_branches) {
    const Path v268_5_head{v268_5_branch.first};
    const Space& v268_5_tail = v268_5_branch.second;
    const auto v269_2_branches = branches(c,v268_5_tail);
    std::vector<Space> v269_2_outputs;
    v269_2_outputs.reserve(v269_2_branches.size());
    for (const auto& v269_2_branch : v269_2_branches) {
      const Path v269_2_head{v269_2_branch.first};
      const Space& v269_2_tail = v269_2_branch.second;
      const Path v270_2 = concat_path(v268_5_head,v269_2_head);
      const auto v270_3_branches = branches(c,v269_2_tail);
      std::vector<Space> v270_3_outputs;
      v270_3_outputs.reserve(v270_3_branches.size());
      for (const auto& v270_3_branch : v270_3_branches) {
        const Path v270_3_head{v270_3_branch.first};
        const Space& v270_3_tail = v270_3_branch.second;
        const Path v271_2 = concat_path(v270_2,v270_3_head);
        const auto v271_3_branches = branches(c,v270_3_tail);
        std::vector<Space> v271_3_outputs;
        v271_3_outputs.reserve(v271_3_branches.size());
        for (const auto& v271_3_branch : v271_3_branches) {
          const Path v271_3_head{v271_3_branch.first};
          const Space& v271_3_tail = v271_3_branch.second;
          const Path v272_2 = concat_path(v271_2,v271_3_head);
          const auto v272_3_branches = branches(c,v271_3_tail);
          std::vector<Space> v272_3_outputs;
          v272_3_outputs.reserve(v272_3_branches.size());
          for (const auto& v272_3_branch : v272_3_branches) {
            const Path v272_3_head{v272_3_branch.first};
            const Space& v272_3_tail = v272_3_branch.second;
            const auto v273_2_branches = branches(c,v272_3_tail);
            std::vector<Space> v273_2_outputs;
            v273_2_outputs.reserve(v273_2_branches.size());
            for (const auto& v273_2_branch : v273_2_branches) {
              const Path v273_2_head{v273_2_branch.first};
              const Space& v273_2_tail = v273_2_branch.second;
              const Path v274_2 = concat_path(v272_3_head,v273_2_head);
              const auto v274_3_branches = branches(c,v273_2_tail);
              std::vector<Space> v274_3_outputs;
              v274_3_outputs.reserve(v274_3_branches.size());
              for (const auto& v274_3_branch : v274_3_branches) {
                const Path v274_3_head{v274_3_branch.first};
                const Space& v274_3_tail = v274_3_branch.second;
                const Path v275_2 = concat_path(v274_2,v274_3_head);
                const auto v275_3_branches = branches(c,v274_3_tail);
                std::vector<Space> v275_3_outputs;
                v275_3_outputs.reserve(v275_3_branches.size());
                for (const auto& v275_3_branch : v275_3_branches) {
                  const Path v275_3_head{v275_3_branch.first};
                  const Space& v275_3_tail = v275_3_branch.second;
                  const Path v276_2 = concat_path(v275_2,v275_3_head);
                  const Space v276_3 = routine_31(c, v276_2, p1, p2, p3, p0, v272_2, v275_3_tail);
                  v275_3_outputs.push_back(v276_3);
                }
                const Space v275_3 = join_outputs(std::move(v275_3_outputs));
                v274_3_outputs.push_back(v275_3);
              }
              const Space v274_3 = join_outputs(std::move(v274_3_outputs));
              v273_2_outputs.push_back(v274_3);
            }
            const Space v273_2 = join_outputs(std::move(v273_2_outputs));
            v272_3_outputs.push_back(v273_2);
          }
          const Space v272_3 = join_outputs(std::move(v272_3_outputs));
          v271_3_outputs.push_back(v272_3);
        }
        const Space v271_3 = join_outputs(std::move(v271_3_outputs));
        v270_3_outputs.push_back(v271_3);
      }
      const Space v270_3 = join_outputs(std::move(v270_3_outputs));
      v269_2_outputs.push_back(v270_3);
    }
    const Space v269_2 = join_outputs(std::move(v269_2_outputs));
    v268_5_outputs.push_back(v269_2);
  }
  const Space v268_5 = join_outputs(std::move(v268_5_outputs));
  return v268_5;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v277_5_branches = branches(c,s0);
  std::vector<Space> v277_5_outputs;
  v277_5_outputs.reserve(v277_5_branches.size());
  for (const auto& v277_5_branch : v277_5_branches) {
    const Path v277_5_head{v277_5_branch.first};
    const Space& v277_5_tail = v277_5_branch.second;
    const auto v278_2_branches = branches(c,v277_5_tail);
    std::vector<Space> v278_2_outputs;
    v278_2_outputs.reserve(v278_2_branches.size());
    for (const auto& v278_2_branch : v278_2_branches) {
      const Path v278_2_head{v278_2_branch.first};
      const Space& v278_2_tail = v278_2_branch.second;
      const Path v279_2 = concat_path(v277_5_head,v278_2_head);
      const auto v279_3_branches = branches(c,v278_2_tail);
      std::vector<Space> v279_3_outputs;
      v279_3_outputs.reserve(v279_3_branches.size());
      for (const auto& v279_3_branch : v279_3_branches) {
        const Path v279_3_head{v279_3_branch.first};
        const Space& v279_3_tail = v279_3_branch.second;
        const Path v280_2 = concat_path(v279_2,v279_3_head);
        const auto v280_3_branches = branches(c,v279_3_tail);
        std::vector<Space> v280_3_outputs;
        v280_3_outputs.reserve(v280_3_branches.size());
        for (const auto& v280_3_branch : v280_3_branches) {
          const Path v280_3_head{v280_3_branch.first};
          const Space& v280_3_tail = v280_3_branch.second;
          const Path v281_2 = concat_path(v280_2,v280_3_head);
          const auto v281_3_branches = branches(c,v280_3_tail);
          std::vector<Space> v281_3_outputs;
          v281_3_outputs.reserve(v281_3_branches.size());
          for (const auto& v281_3_branch : v281_3_branches) {
            const Path v281_3_head{v281_3_branch.first};
            const Space& v281_3_tail = v281_3_branch.second;
            const auto v282_2_branches = branches(c,v281_3_tail);
            std::vector<Space> v282_2_outputs;
            v282_2_outputs.reserve(v282_2_branches.size());
            for (const auto& v282_2_branch : v282_2_branches) {
              const Path v282_2_head{v282_2_branch.first};
              const Space& v282_2_tail = v282_2_branch.second;
              const Path v283_2 = concat_path(v281_3_head,v282_2_head);
              const auto v283_3_branches = branches(c,v282_2_tail);
              std::vector<Space> v283_3_outputs;
              v283_3_outputs.reserve(v283_3_branches.size());
              for (const auto& v283_3_branch : v283_3_branches) {
                const Path v283_3_head{v283_3_branch.first};
                const Space& v283_3_tail = v283_3_branch.second;
                const Path v284_2 = concat_path(v283_2,v283_3_head);
                const auto v284_3_branches = branches(c,v283_3_tail);
                std::vector<Space> v284_3_outputs;
                v284_3_outputs.reserve(v284_3_branches.size());
                for (const auto& v284_3_branch : v284_3_branches) {
                  const Path v284_3_head{v284_3_branch.first};
                  const Space& v284_3_tail = v284_3_branch.second;
                  const Path v285_2 = concat_path(v284_2,v284_3_head);
                  const Space v285_3 = routine_32(c, v285_2, p1, p2, p3, p0, v281_2, v284_3_tail);
                  v284_3_outputs.push_back(v285_3);
                }
                const Space v284_3 = join_outputs(std::move(v284_3_outputs));
                v283_3_outputs.push_back(v284_3);
              }
              const Space v283_3 = join_outputs(std::move(v283_3_outputs));
              v282_2_outputs.push_back(v283_3);
            }
            const Space v282_2 = join_outputs(std::move(v282_2_outputs));
            v281_3_outputs.push_back(v282_2);
          }
          const Space v281_3 = join_outputs(std::move(v281_3_outputs));
          v280_3_outputs.push_back(v281_3);
        }
        const Space v280_3 = join_outputs(std::move(v280_3_outputs));
        v279_3_outputs.push_back(v280_3);
      }
      const Space v279_3 = join_outputs(std::move(v279_3_outputs));
      v278_2_outputs.push_back(v279_3);
    }
    const Space v278_2 = join_outputs(std::move(v278_2_outputs));
    v277_5_outputs.push_back(v278_2);
  }
  const Space v277_5 = join_outputs(std::move(v277_5_outputs));
  return v277_5;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v286_5_branches = branches(c,s0);
  std::vector<Space> v286_5_outputs;
  v286_5_outputs.reserve(v286_5_branches.size());
  for (const auto& v286_5_branch : v286_5_branches) {
    const Path v286_5_head{v286_5_branch.first};
    const Space& v286_5_tail = v286_5_branch.second;
    const auto v287_2_branches = branches(c,v286_5_tail);
    std::vector<Space> v287_2_outputs;
    v287_2_outputs.reserve(v287_2_branches.size());
    for (const auto& v287_2_branch : v287_2_branches) {
      const Path v287_2_head{v287_2_branch.first};
      const Space& v287_2_tail = v287_2_branch.second;
      const Path v288_2 = concat_path(v286_5_head,v287_2_head);
      const auto v288_3_branches = branches(c,v287_2_tail);
      std::vector<Space> v288_3_outputs;
      v288_3_outputs.reserve(v288_3_branches.size());
      for (const auto& v288_3_branch : v288_3_branches) {
        const Path v288_3_head{v288_3_branch.first};
        const Space& v288_3_tail = v288_3_branch.second;
        const Path v289_2 = concat_path(v288_2,v288_3_head);
        const auto v289_3_branches = branches(c,v288_3_tail);
        std::vector<Space> v289_3_outputs;
        v289_3_outputs.reserve(v289_3_branches.size());
        for (const auto& v289_3_branch : v289_3_branches) {
          const Path v289_3_head{v289_3_branch.first};
          const Space& v289_3_tail = v289_3_branch.second;
          const Path v290_2 = concat_path(v289_2,v289_3_head);
          const auto v290_3_branches = branches(c,v289_3_tail);
          std::vector<Space> v290_3_outputs;
          v290_3_outputs.reserve(v290_3_branches.size());
          for (const auto& v290_3_branch : v290_3_branches) {
            const Path v290_3_head{v290_3_branch.first};
            const Space& v290_3_tail = v290_3_branch.second;
            const auto v291_2_branches = branches(c,v290_3_tail);
            std::vector<Space> v291_2_outputs;
            v291_2_outputs.reserve(v291_2_branches.size());
            for (const auto& v291_2_branch : v291_2_branches) {
              const Path v291_2_head{v291_2_branch.first};
              const Space& v291_2_tail = v291_2_branch.second;
              const Path v292_2 = concat_path(v290_3_head,v291_2_head);
              const auto v292_3_branches = branches(c,v291_2_tail);
              std::vector<Space> v292_3_outputs;
              v292_3_outputs.reserve(v292_3_branches.size());
              for (const auto& v292_3_branch : v292_3_branches) {
                const Path v292_3_head{v292_3_branch.first};
                const Space& v292_3_tail = v292_3_branch.second;
                const Path v293_2 = concat_path(v292_2,v292_3_head);
                const auto v293_3_branches = branches(c,v292_3_tail);
                std::vector<Space> v293_3_outputs;
                v293_3_outputs.reserve(v293_3_branches.size());
                for (const auto& v293_3_branch : v293_3_branches) {
                  const Path v293_3_head{v293_3_branch.first};
                  const Space& v293_3_tail = v293_3_branch.second;
                  const Path v294_2 = concat_path(v293_2,v293_3_head);
                  const Space v294_3 = routine_33(c, v294_2, p1, p2, p3, p0, v290_2, v293_3_tail);
                  v293_3_outputs.push_back(v294_3);
                }
                const Space v293_3 = join_outputs(std::move(v293_3_outputs));
                v292_3_outputs.push_back(v293_3);
              }
              const Space v292_3 = join_outputs(std::move(v292_3_outputs));
              v291_2_outputs.push_back(v292_3);
            }
            const Space v291_2 = join_outputs(std::move(v291_2_outputs));
            v290_3_outputs.push_back(v291_2);
          }
          const Space v290_3 = join_outputs(std::move(v290_3_outputs));
          v289_3_outputs.push_back(v290_3);
        }
        const Space v289_3 = join_outputs(std::move(v289_3_outputs));
        v288_3_outputs.push_back(v289_3);
      }
      const Space v288_3 = join_outputs(std::move(v288_3_outputs));
      v287_2_outputs.push_back(v288_3);
    }
    const Space v287_2 = join_outputs(std::move(v287_2_outputs));
    v286_5_outputs.push_back(v287_2);
  }
  const Space v286_5 = join_outputs(std::move(v286_5_outputs));
  return v286_5;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v295_5_branches = branches(c,s0);
  std::vector<Space> v295_5_outputs;
  v295_5_outputs.reserve(v295_5_branches.size());
  for (const auto& v295_5_branch : v295_5_branches) {
    const Path v295_5_head{v295_5_branch.first};
    const Space& v295_5_tail = v295_5_branch.second;
    const auto v296_2_branches = branches(c,v295_5_tail);
    std::vector<Space> v296_2_outputs;
    v296_2_outputs.reserve(v296_2_branches.size());
    for (const auto& v296_2_branch : v296_2_branches) {
      const Path v296_2_head{v296_2_branch.first};
      const Space& v296_2_tail = v296_2_branch.second;
      const Path v297_2 = concat_path(v295_5_head,v296_2_head);
      const auto v297_3_branches = branches(c,v296_2_tail);
      std::vector<Space> v297_3_outputs;
      v297_3_outputs.reserve(v297_3_branches.size());
      for (const auto& v297_3_branch : v297_3_branches) {
        const Path v297_3_head{v297_3_branch.first};
        const Space& v297_3_tail = v297_3_branch.second;
        const Path v298_2 = concat_path(v297_2,v297_3_head);
        const auto v298_3_branches = branches(c,v297_3_tail);
        std::vector<Space> v298_3_outputs;
        v298_3_outputs.reserve(v298_3_branches.size());
        for (const auto& v298_3_branch : v298_3_branches) {
          const Path v298_3_head{v298_3_branch.first};
          const Space& v298_3_tail = v298_3_branch.second;
          const Path v299_2 = concat_path(v298_2,v298_3_head);
          const auto v299_3_branches = branches(c,v298_3_tail);
          std::vector<Space> v299_3_outputs;
          v299_3_outputs.reserve(v299_3_branches.size());
          for (const auto& v299_3_branch : v299_3_branches) {
            const Path v299_3_head{v299_3_branch.first};
            const Space& v299_3_tail = v299_3_branch.second;
            const auto v300_2_branches = branches(c,v299_3_tail);
            std::vector<Space> v300_2_outputs;
            v300_2_outputs.reserve(v300_2_branches.size());
            for (const auto& v300_2_branch : v300_2_branches) {
              const Path v300_2_head{v300_2_branch.first};
              const Space& v300_2_tail = v300_2_branch.second;
              const Path v301_2 = concat_path(v299_3_head,v300_2_head);
              const auto v301_3_branches = branches(c,v300_2_tail);
              std::vector<Space> v301_3_outputs;
              v301_3_outputs.reserve(v301_3_branches.size());
              for (const auto& v301_3_branch : v301_3_branches) {
                const Path v301_3_head{v301_3_branch.first};
                const Space& v301_3_tail = v301_3_branch.second;
                const Path v302_2 = concat_path(v301_2,v301_3_head);
                const auto v302_3_branches = branches(c,v301_3_tail);
                std::vector<Space> v302_3_outputs;
                v302_3_outputs.reserve(v302_3_branches.size());
                for (const auto& v302_3_branch : v302_3_branches) {
                  const Path v302_3_head{v302_3_branch.first};
                  const Space& v302_3_tail = v302_3_branch.second;
                  const Path v303_2 = concat_path(v302_2,v302_3_head);
                  const Space v303_3 = routine_34(c, v303_2, p1, p2, p3, p0, v299_2, v302_3_tail);
                  v302_3_outputs.push_back(v303_3);
                }
                const Space v302_3 = join_outputs(std::move(v302_3_outputs));
                v301_3_outputs.push_back(v302_3);
              }
              const Space v301_3 = join_outputs(std::move(v301_3_outputs));
              v300_2_outputs.push_back(v301_3);
            }
            const Space v300_2 = join_outputs(std::move(v300_2_outputs));
            v299_3_outputs.push_back(v300_2);
          }
          const Space v299_3 = join_outputs(std::move(v299_3_outputs));
          v298_3_outputs.push_back(v299_3);
        }
        const Space v298_3 = join_outputs(std::move(v298_3_outputs));
        v297_3_outputs.push_back(v298_3);
      }
      const Space v297_3 = join_outputs(std::move(v297_3_outputs));
      v296_2_outputs.push_back(v297_3);
    }
    const Space v296_2 = join_outputs(std::move(v296_2_outputs));
    v295_5_outputs.push_back(v296_2);
  }
  const Space v295_5 = join_outputs(std::move(v295_5_outputs));
  return v295_5;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v304_5_branches = branches(c,s0);
  std::vector<Space> v304_5_outputs;
  v304_5_outputs.reserve(v304_5_branches.size());
  for (const auto& v304_5_branch : v304_5_branches) {
    const Path v304_5_head{v304_5_branch.first};
    const Space& v304_5_tail = v304_5_branch.second;
    const auto v305_2_branches = branches(c,v304_5_tail);
    std::vector<Space> v305_2_outputs;
    v305_2_outputs.reserve(v305_2_branches.size());
    for (const auto& v305_2_branch : v305_2_branches) {
      const Path v305_2_head{v305_2_branch.first};
      const Space& v305_2_tail = v305_2_branch.second;
      const Path v306_2 = concat_path(v304_5_head,v305_2_head);
      const auto v306_3_branches = branches(c,v305_2_tail);
      std::vector<Space> v306_3_outputs;
      v306_3_outputs.reserve(v306_3_branches.size());
      for (const auto& v306_3_branch : v306_3_branches) {
        const Path v306_3_head{v306_3_branch.first};
        const Space& v306_3_tail = v306_3_branch.second;
        const Path v307_2 = concat_path(v306_2,v306_3_head);
        const auto v307_3_branches = branches(c,v306_3_tail);
        std::vector<Space> v307_3_outputs;
        v307_3_outputs.reserve(v307_3_branches.size());
        for (const auto& v307_3_branch : v307_3_branches) {
          const Path v307_3_head{v307_3_branch.first};
          const Space& v307_3_tail = v307_3_branch.second;
          const Path v308_2 = concat_path(v307_2,v307_3_head);
          const auto v308_3_branches = branches(c,v307_3_tail);
          std::vector<Space> v308_3_outputs;
          v308_3_outputs.reserve(v308_3_branches.size());
          for (const auto& v308_3_branch : v308_3_branches) {
            const Path v308_3_head{v308_3_branch.first};
            const Space& v308_3_tail = v308_3_branch.second;
            const auto v309_2_branches = branches(c,v308_3_tail);
            std::vector<Space> v309_2_outputs;
            v309_2_outputs.reserve(v309_2_branches.size());
            for (const auto& v309_2_branch : v309_2_branches) {
              const Path v309_2_head{v309_2_branch.first};
              const Space& v309_2_tail = v309_2_branch.second;
              const Path v310_2 = concat_path(v308_3_head,v309_2_head);
              const auto v310_3_branches = branches(c,v309_2_tail);
              std::vector<Space> v310_3_outputs;
              v310_3_outputs.reserve(v310_3_branches.size());
              for (const auto& v310_3_branch : v310_3_branches) {
                const Path v310_3_head{v310_3_branch.first};
                const Space& v310_3_tail = v310_3_branch.second;
                const Path v311_2 = concat_path(v310_2,v310_3_head);
                const auto v311_3_branches = branches(c,v310_3_tail);
                std::vector<Space> v311_3_outputs;
                v311_3_outputs.reserve(v311_3_branches.size());
                for (const auto& v311_3_branch : v311_3_branches) {
                  const Path v311_3_head{v311_3_branch.first};
                  const Space& v311_3_tail = v311_3_branch.second;
                  const Path v312_2 = concat_path(v311_2,v311_3_head);
                  const Space v312_3 = routine_35(c, v312_2, p1, p2, p3, p0, v308_2, v311_3_tail);
                  v311_3_outputs.push_back(v312_3);
                }
                const Space v311_3 = join_outputs(std::move(v311_3_outputs));
                v310_3_outputs.push_back(v311_3);
              }
              const Space v310_3 = join_outputs(std::move(v310_3_outputs));
              v309_2_outputs.push_back(v310_3);
            }
            const Space v309_2 = join_outputs(std::move(v309_2_outputs));
            v308_3_outputs.push_back(v309_2);
          }
          const Space v308_3 = join_outputs(std::move(v308_3_outputs));
          v307_3_outputs.push_back(v308_3);
        }
        const Space v307_3 = join_outputs(std::move(v307_3_outputs));
        v306_3_outputs.push_back(v307_3);
      }
      const Space v306_3 = join_outputs(std::move(v306_3_outputs));
      v305_2_outputs.push_back(v306_3);
    }
    const Space v305_2 = join_outputs(std::move(v305_2_outputs));
    v304_5_outputs.push_back(v305_2);
  }
  const Space v304_5 = join_outputs(std::move(v304_5_outputs));
  return v304_5;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v313_5_branches = branches(c,s0);
  std::vector<Space> v313_5_outputs;
  v313_5_outputs.reserve(v313_5_branches.size());
  for (const auto& v313_5_branch : v313_5_branches) {
    const Path v313_5_head{v313_5_branch.first};
    const Space& v313_5_tail = v313_5_branch.second;
    const auto v314_2_branches = branches(c,v313_5_tail);
    std::vector<Space> v314_2_outputs;
    v314_2_outputs.reserve(v314_2_branches.size());
    for (const auto& v314_2_branch : v314_2_branches) {
      const Path v314_2_head{v314_2_branch.first};
      const Space& v314_2_tail = v314_2_branch.second;
      const Path v315_2 = concat_path(v313_5_head,v314_2_head);
      const auto v315_3_branches = branches(c,v314_2_tail);
      std::vector<Space> v315_3_outputs;
      v315_3_outputs.reserve(v315_3_branches.size());
      for (const auto& v315_3_branch : v315_3_branches) {
        const Path v315_3_head{v315_3_branch.first};
        const Space& v315_3_tail = v315_3_branch.second;
        const Path v316_2 = concat_path(v315_2,v315_3_head);
        const auto v316_3_branches = branches(c,v315_3_tail);
        std::vector<Space> v316_3_outputs;
        v316_3_outputs.reserve(v316_3_branches.size());
        for (const auto& v316_3_branch : v316_3_branches) {
          const Path v316_3_head{v316_3_branch.first};
          const Space& v316_3_tail = v316_3_branch.second;
          const Path v317_2 = concat_path(v316_2,v316_3_head);
          const auto v317_3_branches = branches(c,v316_3_tail);
          std::vector<Space> v317_3_outputs;
          v317_3_outputs.reserve(v317_3_branches.size());
          for (const auto& v317_3_branch : v317_3_branches) {
            const Path v317_3_head{v317_3_branch.first};
            const Space& v317_3_tail = v317_3_branch.second;
            const auto v318_2_branches = branches(c,v317_3_tail);
            std::vector<Space> v318_2_outputs;
            v318_2_outputs.reserve(v318_2_branches.size());
            for (const auto& v318_2_branch : v318_2_branches) {
              const Path v318_2_head{v318_2_branch.first};
              const Space& v318_2_tail = v318_2_branch.second;
              const Path v319_2 = concat_path(v317_3_head,v318_2_head);
              const auto v319_3_branches = branches(c,v318_2_tail);
              std::vector<Space> v319_3_outputs;
              v319_3_outputs.reserve(v319_3_branches.size());
              for (const auto& v319_3_branch : v319_3_branches) {
                const Path v319_3_head{v319_3_branch.first};
                const Space& v319_3_tail = v319_3_branch.second;
                const Path v320_2 = concat_path(v319_2,v319_3_head);
                const auto v320_3_branches = branches(c,v319_3_tail);
                std::vector<Space> v320_3_outputs;
                v320_3_outputs.reserve(v320_3_branches.size());
                for (const auto& v320_3_branch : v320_3_branches) {
                  const Path v320_3_head{v320_3_branch.first};
                  const Space& v320_3_tail = v320_3_branch.second;
                  const Path v321_2 = concat_path(v320_2,v320_3_head);
                  const Space v321_3 = routine_36(c, v321_2, p1, p2, p3, p0, v317_2, v320_3_tail);
                  v320_3_outputs.push_back(v321_3);
                }
                const Space v320_3 = join_outputs(std::move(v320_3_outputs));
                v319_3_outputs.push_back(v320_3);
              }
              const Space v319_3 = join_outputs(std::move(v319_3_outputs));
              v318_2_outputs.push_back(v319_3);
            }
            const Space v318_2 = join_outputs(std::move(v318_2_outputs));
            v317_3_outputs.push_back(v318_2);
          }
          const Space v317_3 = join_outputs(std::move(v317_3_outputs));
          v316_3_outputs.push_back(v317_3);
        }
        const Space v316_3 = join_outputs(std::move(v316_3_outputs));
        v315_3_outputs.push_back(v316_3);
      }
      const Space v315_3 = join_outputs(std::move(v315_3_outputs));
      v314_2_outputs.push_back(v315_3);
    }
    const Space v314_2 = join_outputs(std::move(v314_2_outputs));
    v313_5_outputs.push_back(v314_2);
  }
  const Space v313_5 = join_outputs(std::move(v313_5_outputs));
  return v313_5;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v322_5_branches = branches(c,s0);
  std::vector<Space> v322_5_outputs;
  v322_5_outputs.reserve(v322_5_branches.size());
  for (const auto& v322_5_branch : v322_5_branches) {
    const Path v322_5_head{v322_5_branch.first};
    const Space& v322_5_tail = v322_5_branch.second;
    const auto v323_2_branches = branches(c,v322_5_tail);
    std::vector<Space> v323_2_outputs;
    v323_2_outputs.reserve(v323_2_branches.size());
    for (const auto& v323_2_branch : v323_2_branches) {
      const Path v323_2_head{v323_2_branch.first};
      const Space& v323_2_tail = v323_2_branch.second;
      const Path v324_2 = concat_path(v322_5_head,v323_2_head);
      const auto v324_3_branches = branches(c,v323_2_tail);
      std::vector<Space> v324_3_outputs;
      v324_3_outputs.reserve(v324_3_branches.size());
      for (const auto& v324_3_branch : v324_3_branches) {
        const Path v324_3_head{v324_3_branch.first};
        const Space& v324_3_tail = v324_3_branch.second;
        const Path v325_2 = concat_path(v324_2,v324_3_head);
        const auto v325_3_branches = branches(c,v324_3_tail);
        std::vector<Space> v325_3_outputs;
        v325_3_outputs.reserve(v325_3_branches.size());
        for (const auto& v325_3_branch : v325_3_branches) {
          const Path v325_3_head{v325_3_branch.first};
          const Space& v325_3_tail = v325_3_branch.second;
          const Path v326_2 = concat_path(v325_2,v325_3_head);
          const auto v326_3_branches = branches(c,v325_3_tail);
          std::vector<Space> v326_3_outputs;
          v326_3_outputs.reserve(v326_3_branches.size());
          for (const auto& v326_3_branch : v326_3_branches) {
            const Path v326_3_head{v326_3_branch.first};
            const Space& v326_3_tail = v326_3_branch.second;
            const auto v327_2_branches = branches(c,v326_3_tail);
            std::vector<Space> v327_2_outputs;
            v327_2_outputs.reserve(v327_2_branches.size());
            for (const auto& v327_2_branch : v327_2_branches) {
              const Path v327_2_head{v327_2_branch.first};
              const Space& v327_2_tail = v327_2_branch.second;
              const Path v328_2 = concat_path(v326_3_head,v327_2_head);
              const auto v328_3_branches = branches(c,v327_2_tail);
              std::vector<Space> v328_3_outputs;
              v328_3_outputs.reserve(v328_3_branches.size());
              for (const auto& v328_3_branch : v328_3_branches) {
                const Path v328_3_head{v328_3_branch.first};
                const Space& v328_3_tail = v328_3_branch.second;
                const Path v329_2 = concat_path(v328_2,v328_3_head);
                const auto v329_3_branches = branches(c,v328_3_tail);
                std::vector<Space> v329_3_outputs;
                v329_3_outputs.reserve(v329_3_branches.size());
                for (const auto& v329_3_branch : v329_3_branches) {
                  const Path v329_3_head{v329_3_branch.first};
                  const Space& v329_3_tail = v329_3_branch.second;
                  const Path v330_2 = concat_path(v329_2,v329_3_head);
                  const Space v330_3 = routine_37(c, v330_2, p1, p2, p3, p0, v326_2, v329_3_tail);
                  v329_3_outputs.push_back(v330_3);
                }
                const Space v329_3 = join_outputs(std::move(v329_3_outputs));
                v328_3_outputs.push_back(v329_3);
              }
              const Space v328_3 = join_outputs(std::move(v328_3_outputs));
              v327_2_outputs.push_back(v328_3);
            }
            const Space v327_2 = join_outputs(std::move(v327_2_outputs));
            v326_3_outputs.push_back(v327_2);
          }
          const Space v326_3 = join_outputs(std::move(v326_3_outputs));
          v325_3_outputs.push_back(v326_3);
        }
        const Space v325_3 = join_outputs(std::move(v325_3_outputs));
        v324_3_outputs.push_back(v325_3);
      }
      const Space v324_3 = join_outputs(std::move(v324_3_outputs));
      v323_2_outputs.push_back(v324_3);
    }
    const Space v323_2 = join_outputs(std::move(v323_2_outputs));
    v322_5_outputs.push_back(v323_2);
  }
  const Space v322_5 = join_outputs(std::move(v322_5_outputs));
  return v322_5;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v331_7_branches = branches(c,s0);
  std::vector<Space> v331_7_outputs;
  v331_7_outputs.reserve(v331_7_branches.size());
  for (const auto& v331_7_branch : v331_7_branches) {
    const Path v331_7_head{v331_7_branch.first};
    const Space& v331_7_tail = v331_7_branch.second;
    const auto v332_2_branches = branches(c,v331_7_tail);
    std::vector<Space> v332_2_outputs;
    v332_2_outputs.reserve(v332_2_branches.size());
    for (const auto& v332_2_branch : v332_2_branches) {
      const Path v332_2_head{v332_2_branch.first};
      const Space& v332_2_tail = v332_2_branch.second;
      const Path v333_2 = concat_path(v331_7_head,v332_2_head);
      const auto v333_3_branches = branches(c,v332_2_tail);
      std::vector<Space> v333_3_outputs;
      v333_3_outputs.reserve(v333_3_branches.size());
      for (const auto& v333_3_branch : v333_3_branches) {
        const Path v333_3_head{v333_3_branch.first};
        const Space& v333_3_tail = v333_3_branch.second;
        const Path v334_2 = concat_path(v333_2,v333_3_head);
        const auto v334_3_branches = branches(c,v333_3_tail);
        std::vector<Space> v334_3_outputs;
        v334_3_outputs.reserve(v334_3_branches.size());
        for (const auto& v334_3_branch : v334_3_branches) {
          const Path v334_3_head{v334_3_branch.first};
          const Space& v334_3_tail = v334_3_branch.second;
          const Path v335_2 = concat_path(v334_2,v334_3_head);
          const auto v335_3_branches = branches(c,v334_3_tail);
          std::vector<Space> v335_3_outputs;
          v335_3_outputs.reserve(v335_3_branches.size());
          for (const auto& v335_3_branch : v335_3_branches) {
            const Path v335_3_head{v335_3_branch.first};
            const Space& v335_3_tail = v335_3_branch.second;
            const auto v336_2_branches = branches(c,v335_3_tail);
            std::vector<Space> v336_2_outputs;
            v336_2_outputs.reserve(v336_2_branches.size());
            for (const auto& v336_2_branch : v336_2_branches) {
              const Path v336_2_head{v336_2_branch.first};
              const Space& v336_2_tail = v336_2_branch.second;
              const Path v337_2 = concat_path(v335_3_head,v336_2_head);
              const auto v337_3_branches = branches(c,v336_2_tail);
              std::vector<Space> v337_3_outputs;
              v337_3_outputs.reserve(v337_3_branches.size());
              for (const auto& v337_3_branch : v337_3_branches) {
                const Path v337_3_head{v337_3_branch.first};
                const Space& v337_3_tail = v337_3_branch.second;
                const Path v338_2 = concat_path(v337_2,v337_3_head);
                const auto v338_3_branches = branches(c,v337_3_tail);
                std::vector<Space> v338_3_outputs;
                v338_3_outputs.reserve(v338_3_branches.size());
                for (const auto& v338_3_branch : v338_3_branches) {
                  const Path v338_3_head{v338_3_branch.first};
                  const Space& v338_3_tail = v338_3_branch.second;
                  const Path v339_2 = concat_path(v338_2,v338_3_head);
                  const Space v339_3 = routine_38(c, v339_2, p1, p2, p3, p4, p5, p0, v335_2, v338_3_tail);
                  v338_3_outputs.push_back(v339_3);
                }
                const Space v338_3 = join_outputs(std::move(v338_3_outputs));
                v337_3_outputs.push_back(v338_3);
              }
              const Space v337_3 = join_outputs(std::move(v337_3_outputs));
              v336_2_outputs.push_back(v337_3);
            }
            const Space v336_2 = join_outputs(std::move(v336_2_outputs));
            v335_3_outputs.push_back(v336_2);
          }
          const Space v335_3 = join_outputs(std::move(v335_3_outputs));
          v334_3_outputs.push_back(v335_3);
        }
        const Space v334_3 = join_outputs(std::move(v334_3_outputs));
        v333_3_outputs.push_back(v334_3);
      }
      const Space v333_3 = join_outputs(std::move(v333_3_outputs));
      v332_2_outputs.push_back(v333_3);
    }
    const Space v332_2 = join_outputs(std::move(v332_2_outputs));
    v331_7_outputs.push_back(v332_2);
  }
  const Space v331_7 = join_outputs(std::move(v331_7_outputs));
  return v331_7;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v340_7_branches = branches(c,s0);
  std::vector<Space> v340_7_outputs;
  v340_7_outputs.reserve(v340_7_branches.size());
  for (const auto& v340_7_branch : v340_7_branches) {
    const Path v340_7_head{v340_7_branch.first};
    const Space& v340_7_tail = v340_7_branch.second;
    const auto v341_2_branches = branches(c,v340_7_tail);
    std::vector<Space> v341_2_outputs;
    v341_2_outputs.reserve(v341_2_branches.size());
    for (const auto& v341_2_branch : v341_2_branches) {
      const Path v341_2_head{v341_2_branch.first};
      const Space& v341_2_tail = v341_2_branch.second;
      const Path v342_2 = concat_path(v340_7_head,v341_2_head);
      const auto v342_3_branches = branches(c,v341_2_tail);
      std::vector<Space> v342_3_outputs;
      v342_3_outputs.reserve(v342_3_branches.size());
      for (const auto& v342_3_branch : v342_3_branches) {
        const Path v342_3_head{v342_3_branch.first};
        const Space& v342_3_tail = v342_3_branch.second;
        const Path v343_2 = concat_path(v342_2,v342_3_head);
        const auto v343_3_branches = branches(c,v342_3_tail);
        std::vector<Space> v343_3_outputs;
        v343_3_outputs.reserve(v343_3_branches.size());
        for (const auto& v343_3_branch : v343_3_branches) {
          const Path v343_3_head{v343_3_branch.first};
          const Space& v343_3_tail = v343_3_branch.second;
          const Path v344_2 = concat_path(v343_2,v343_3_head);
          const auto v344_3_branches = branches(c,v343_3_tail);
          std::vector<Space> v344_3_outputs;
          v344_3_outputs.reserve(v344_3_branches.size());
          for (const auto& v344_3_branch : v344_3_branches) {
            const Path v344_3_head{v344_3_branch.first};
            const Space& v344_3_tail = v344_3_branch.second;
            const auto v345_2_branches = branches(c,v344_3_tail);
            std::vector<Space> v345_2_outputs;
            v345_2_outputs.reserve(v345_2_branches.size());
            for (const auto& v345_2_branch : v345_2_branches) {
              const Path v345_2_head{v345_2_branch.first};
              const Space& v345_2_tail = v345_2_branch.second;
              const Path v346_2 = concat_path(v344_3_head,v345_2_head);
              const auto v346_3_branches = branches(c,v345_2_tail);
              std::vector<Space> v346_3_outputs;
              v346_3_outputs.reserve(v346_3_branches.size());
              for (const auto& v346_3_branch : v346_3_branches) {
                const Path v346_3_head{v346_3_branch.first};
                const Space& v346_3_tail = v346_3_branch.second;
                const Path v347_2 = concat_path(v346_2,v346_3_head);
                const auto v347_3_branches = branches(c,v346_3_tail);
                std::vector<Space> v347_3_outputs;
                v347_3_outputs.reserve(v347_3_branches.size());
                for (const auto& v347_3_branch : v347_3_branches) {
                  const Path v347_3_head{v347_3_branch.first};
                  const Space& v347_3_tail = v347_3_branch.second;
                  const Path v348_2 = concat_path(v347_2,v347_3_head);
                  const Space v348_3 = routine_39(c, v348_2, p1, p2, p3, p4, p5, p0, v344_2, v347_3_tail);
                  v347_3_outputs.push_back(v348_3);
                }
                const Space v347_3 = join_outputs(std::move(v347_3_outputs));
                v346_3_outputs.push_back(v347_3);
              }
              const Space v346_3 = join_outputs(std::move(v346_3_outputs));
              v345_2_outputs.push_back(v346_3);
            }
            const Space v345_2 = join_outputs(std::move(v345_2_outputs));
            v344_3_outputs.push_back(v345_2);
          }
          const Space v344_3 = join_outputs(std::move(v344_3_outputs));
          v343_3_outputs.push_back(v344_3);
        }
        const Space v343_3 = join_outputs(std::move(v343_3_outputs));
        v342_3_outputs.push_back(v343_3);
      }
      const Space v342_3 = join_outputs(std::move(v342_3_outputs));
      v341_2_outputs.push_back(v342_3);
    }
    const Space v341_2 = join_outputs(std::move(v341_2_outputs));
    v340_7_outputs.push_back(v341_2);
  }
  const Space v340_7 = join_outputs(std::move(v340_7_outputs));
  return v340_7;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v349_7_branches = branches(c,s0);
  std::vector<Space> v349_7_outputs;
  v349_7_outputs.reserve(v349_7_branches.size());
  for (const auto& v349_7_branch : v349_7_branches) {
    const Path v349_7_head{v349_7_branch.first};
    const Space& v349_7_tail = v349_7_branch.second;
    const auto v350_2_branches = branches(c,v349_7_tail);
    std::vector<Space> v350_2_outputs;
    v350_2_outputs.reserve(v350_2_branches.size());
    for (const auto& v350_2_branch : v350_2_branches) {
      const Path v350_2_head{v350_2_branch.first};
      const Space& v350_2_tail = v350_2_branch.second;
      const Path v351_2 = concat_path(v349_7_head,v350_2_head);
      const auto v351_3_branches = branches(c,v350_2_tail);
      std::vector<Space> v351_3_outputs;
      v351_3_outputs.reserve(v351_3_branches.size());
      for (const auto& v351_3_branch : v351_3_branches) {
        const Path v351_3_head{v351_3_branch.first};
        const Space& v351_3_tail = v351_3_branch.second;
        const Path v352_2 = concat_path(v351_2,v351_3_head);
        const auto v352_3_branches = branches(c,v351_3_tail);
        std::vector<Space> v352_3_outputs;
        v352_3_outputs.reserve(v352_3_branches.size());
        for (const auto& v352_3_branch : v352_3_branches) {
          const Path v352_3_head{v352_3_branch.first};
          const Space& v352_3_tail = v352_3_branch.second;
          const Path v353_2 = concat_path(v352_2,v352_3_head);
          const auto v353_3_branches = branches(c,v352_3_tail);
          std::vector<Space> v353_3_outputs;
          v353_3_outputs.reserve(v353_3_branches.size());
          for (const auto& v353_3_branch : v353_3_branches) {
            const Path v353_3_head{v353_3_branch.first};
            const Space& v353_3_tail = v353_3_branch.second;
            const auto v354_2_branches = branches(c,v353_3_tail);
            std::vector<Space> v354_2_outputs;
            v354_2_outputs.reserve(v354_2_branches.size());
            for (const auto& v354_2_branch : v354_2_branches) {
              const Path v354_2_head{v354_2_branch.first};
              const Space& v354_2_tail = v354_2_branch.second;
              const Path v355_2 = concat_path(v353_3_head,v354_2_head);
              const auto v355_3_branches = branches(c,v354_2_tail);
              std::vector<Space> v355_3_outputs;
              v355_3_outputs.reserve(v355_3_branches.size());
              for (const auto& v355_3_branch : v355_3_branches) {
                const Path v355_3_head{v355_3_branch.first};
                const Space& v355_3_tail = v355_3_branch.second;
                const Path v356_2 = concat_path(v355_2,v355_3_head);
                const auto v356_3_branches = branches(c,v355_3_tail);
                std::vector<Space> v356_3_outputs;
                v356_3_outputs.reserve(v356_3_branches.size());
                for (const auto& v356_3_branch : v356_3_branches) {
                  const Path v356_3_head{v356_3_branch.first};
                  const Space& v356_3_tail = v356_3_branch.second;
                  const Path v357_2 = concat_path(v356_2,v356_3_head);
                  const Space v357_3 = routine_40(c, v357_2, p1, p2, p3, p4, p5, p0, v353_2, v356_3_tail);
                  v356_3_outputs.push_back(v357_3);
                }
                const Space v356_3 = join_outputs(std::move(v356_3_outputs));
                v355_3_outputs.push_back(v356_3);
              }
              const Space v355_3 = join_outputs(std::move(v355_3_outputs));
              v354_2_outputs.push_back(v355_3);
            }
            const Space v354_2 = join_outputs(std::move(v354_2_outputs));
            v353_3_outputs.push_back(v354_2);
          }
          const Space v353_3 = join_outputs(std::move(v353_3_outputs));
          v352_3_outputs.push_back(v353_3);
        }
        const Space v352_3 = join_outputs(std::move(v352_3_outputs));
        v351_3_outputs.push_back(v352_3);
      }
      const Space v351_3 = join_outputs(std::move(v351_3_outputs));
      v350_2_outputs.push_back(v351_3);
    }
    const Space v350_2 = join_outputs(std::move(v350_2_outputs));
    v349_7_outputs.push_back(v350_2);
  }
  const Space v349_7 = join_outputs(std::move(v349_7_outputs));
  return v349_7;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v358_7_branches = branches(c,s0);
  std::vector<Space> v358_7_outputs;
  v358_7_outputs.reserve(v358_7_branches.size());
  for (const auto& v358_7_branch : v358_7_branches) {
    const Path v358_7_head{v358_7_branch.first};
    const Space& v358_7_tail = v358_7_branch.second;
    const auto v359_2_branches = branches(c,v358_7_tail);
    std::vector<Space> v359_2_outputs;
    v359_2_outputs.reserve(v359_2_branches.size());
    for (const auto& v359_2_branch : v359_2_branches) {
      const Path v359_2_head{v359_2_branch.first};
      const Space& v359_2_tail = v359_2_branch.second;
      const Path v360_2 = concat_path(v358_7_head,v359_2_head);
      const auto v360_3_branches = branches(c,v359_2_tail);
      std::vector<Space> v360_3_outputs;
      v360_3_outputs.reserve(v360_3_branches.size());
      for (const auto& v360_3_branch : v360_3_branches) {
        const Path v360_3_head{v360_3_branch.first};
        const Space& v360_3_tail = v360_3_branch.second;
        const Path v361_2 = concat_path(v360_2,v360_3_head);
        const auto v361_3_branches = branches(c,v360_3_tail);
        std::vector<Space> v361_3_outputs;
        v361_3_outputs.reserve(v361_3_branches.size());
        for (const auto& v361_3_branch : v361_3_branches) {
          const Path v361_3_head{v361_3_branch.first};
          const Space& v361_3_tail = v361_3_branch.second;
          const Path v362_2 = concat_path(v361_2,v361_3_head);
          const auto v362_3_branches = branches(c,v361_3_tail);
          std::vector<Space> v362_3_outputs;
          v362_3_outputs.reserve(v362_3_branches.size());
          for (const auto& v362_3_branch : v362_3_branches) {
            const Path v362_3_head{v362_3_branch.first};
            const Space& v362_3_tail = v362_3_branch.second;
            const auto v363_2_branches = branches(c,v362_3_tail);
            std::vector<Space> v363_2_outputs;
            v363_2_outputs.reserve(v363_2_branches.size());
            for (const auto& v363_2_branch : v363_2_branches) {
              const Path v363_2_head{v363_2_branch.first};
              const Space& v363_2_tail = v363_2_branch.second;
              const Path v364_2 = concat_path(v362_3_head,v363_2_head);
              const auto v364_3_branches = branches(c,v363_2_tail);
              std::vector<Space> v364_3_outputs;
              v364_3_outputs.reserve(v364_3_branches.size());
              for (const auto& v364_3_branch : v364_3_branches) {
                const Path v364_3_head{v364_3_branch.first};
                const Space& v364_3_tail = v364_3_branch.second;
                const Path v365_2 = concat_path(v364_2,v364_3_head);
                const auto v365_3_branches = branches(c,v364_3_tail);
                std::vector<Space> v365_3_outputs;
                v365_3_outputs.reserve(v365_3_branches.size());
                for (const auto& v365_3_branch : v365_3_branches) {
                  const Path v365_3_head{v365_3_branch.first};
                  const Space& v365_3_tail = v365_3_branch.second;
                  const Path v366_2 = concat_path(v365_2,v365_3_head);
                  const Space v366_3 = routine_41(c, v366_2, p1, p2, p3, p4, p5, p0, v362_2, v365_3_tail);
                  v365_3_outputs.push_back(v366_3);
                }
                const Space v365_3 = join_outputs(std::move(v365_3_outputs));
                v364_3_outputs.push_back(v365_3);
              }
              const Space v364_3 = join_outputs(std::move(v364_3_outputs));
              v363_2_outputs.push_back(v364_3);
            }
            const Space v363_2 = join_outputs(std::move(v363_2_outputs));
            v362_3_outputs.push_back(v363_2);
          }
          const Space v362_3 = join_outputs(std::move(v362_3_outputs));
          v361_3_outputs.push_back(v362_3);
        }
        const Space v361_3 = join_outputs(std::move(v361_3_outputs));
        v360_3_outputs.push_back(v361_3);
      }
      const Space v360_3 = join_outputs(std::move(v360_3_outputs));
      v359_2_outputs.push_back(v360_3);
    }
    const Space v359_2 = join_outputs(std::move(v359_2_outputs));
    v358_7_outputs.push_back(v359_2);
  }
  const Space v358_7 = join_outputs(std::move(v358_7_outputs));
  return v358_7;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v367_7_branches = branches(c,s0);
  std::vector<Space> v367_7_outputs;
  v367_7_outputs.reserve(v367_7_branches.size());
  for (const auto& v367_7_branch : v367_7_branches) {
    const Path v367_7_head{v367_7_branch.first};
    const Space& v367_7_tail = v367_7_branch.second;
    const auto v368_2_branches = branches(c,v367_7_tail);
    std::vector<Space> v368_2_outputs;
    v368_2_outputs.reserve(v368_2_branches.size());
    for (const auto& v368_2_branch : v368_2_branches) {
      const Path v368_2_head{v368_2_branch.first};
      const Space& v368_2_tail = v368_2_branch.second;
      const Path v369_2 = concat_path(v367_7_head,v368_2_head);
      const auto v369_3_branches = branches(c,v368_2_tail);
      std::vector<Space> v369_3_outputs;
      v369_3_outputs.reserve(v369_3_branches.size());
      for (const auto& v369_3_branch : v369_3_branches) {
        const Path v369_3_head{v369_3_branch.first};
        const Space& v369_3_tail = v369_3_branch.second;
        const Path v370_2 = concat_path(v369_2,v369_3_head);
        const auto v370_3_branches = branches(c,v369_3_tail);
        std::vector<Space> v370_3_outputs;
        v370_3_outputs.reserve(v370_3_branches.size());
        for (const auto& v370_3_branch : v370_3_branches) {
          const Path v370_3_head{v370_3_branch.first};
          const Space& v370_3_tail = v370_3_branch.second;
          const Path v371_2 = concat_path(v370_2,v370_3_head);
          const auto v371_3_branches = branches(c,v370_3_tail);
          std::vector<Space> v371_3_outputs;
          v371_3_outputs.reserve(v371_3_branches.size());
          for (const auto& v371_3_branch : v371_3_branches) {
            const Path v371_3_head{v371_3_branch.first};
            const Space& v371_3_tail = v371_3_branch.second;
            const auto v372_2_branches = branches(c,v371_3_tail);
            std::vector<Space> v372_2_outputs;
            v372_2_outputs.reserve(v372_2_branches.size());
            for (const auto& v372_2_branch : v372_2_branches) {
              const Path v372_2_head{v372_2_branch.first};
              const Space& v372_2_tail = v372_2_branch.second;
              const Path v373_2 = concat_path(v371_3_head,v372_2_head);
              const auto v373_3_branches = branches(c,v372_2_tail);
              std::vector<Space> v373_3_outputs;
              v373_3_outputs.reserve(v373_3_branches.size());
              for (const auto& v373_3_branch : v373_3_branches) {
                const Path v373_3_head{v373_3_branch.first};
                const Space& v373_3_tail = v373_3_branch.second;
                const Path v374_2 = concat_path(v373_2,v373_3_head);
                const auto v374_3_branches = branches(c,v373_3_tail);
                std::vector<Space> v374_3_outputs;
                v374_3_outputs.reserve(v374_3_branches.size());
                for (const auto& v374_3_branch : v374_3_branches) {
                  const Path v374_3_head{v374_3_branch.first};
                  const Space& v374_3_tail = v374_3_branch.second;
                  const Path v375_2 = concat_path(v374_2,v374_3_head);
                  const Space v375_3 = routine_42(c, v375_2, p1, p2, p3, p4, p5, p0, v371_2, v374_3_tail);
                  v374_3_outputs.push_back(v375_3);
                }
                const Space v374_3 = join_outputs(std::move(v374_3_outputs));
                v373_3_outputs.push_back(v374_3);
              }
              const Space v373_3 = join_outputs(std::move(v373_3_outputs));
              v372_2_outputs.push_back(v373_3);
            }
            const Space v372_2 = join_outputs(std::move(v372_2_outputs));
            v371_3_outputs.push_back(v372_2);
          }
          const Space v371_3 = join_outputs(std::move(v371_3_outputs));
          v370_3_outputs.push_back(v371_3);
        }
        const Space v370_3 = join_outputs(std::move(v370_3_outputs));
        v369_3_outputs.push_back(v370_3);
      }
      const Space v369_3 = join_outputs(std::move(v369_3_outputs));
      v368_2_outputs.push_back(v369_3);
    }
    const Space v368_2 = join_outputs(std::move(v368_2_outputs));
    v367_7_outputs.push_back(v368_2);
  }
  const Space v367_7 = join_outputs(std::move(v367_7_outputs));
  return v367_7;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v376_7_branches = branches(c,s0);
  std::vector<Space> v376_7_outputs;
  v376_7_outputs.reserve(v376_7_branches.size());
  for (const auto& v376_7_branch : v376_7_branches) {
    const Path v376_7_head{v376_7_branch.first};
    const Space& v376_7_tail = v376_7_branch.second;
    const auto v377_2_branches = branches(c,v376_7_tail);
    std::vector<Space> v377_2_outputs;
    v377_2_outputs.reserve(v377_2_branches.size());
    for (const auto& v377_2_branch : v377_2_branches) {
      const Path v377_2_head{v377_2_branch.first};
      const Space& v377_2_tail = v377_2_branch.second;
      const Path v378_2 = concat_path(v376_7_head,v377_2_head);
      const auto v378_3_branches = branches(c,v377_2_tail);
      std::vector<Space> v378_3_outputs;
      v378_3_outputs.reserve(v378_3_branches.size());
      for (const auto& v378_3_branch : v378_3_branches) {
        const Path v378_3_head{v378_3_branch.first};
        const Space& v378_3_tail = v378_3_branch.second;
        const Path v379_2 = concat_path(v378_2,v378_3_head);
        const auto v379_3_branches = branches(c,v378_3_tail);
        std::vector<Space> v379_3_outputs;
        v379_3_outputs.reserve(v379_3_branches.size());
        for (const auto& v379_3_branch : v379_3_branches) {
          const Path v379_3_head{v379_3_branch.first};
          const Space& v379_3_tail = v379_3_branch.second;
          const Path v380_2 = concat_path(v379_2,v379_3_head);
          const auto v380_3_branches = branches(c,v379_3_tail);
          std::vector<Space> v380_3_outputs;
          v380_3_outputs.reserve(v380_3_branches.size());
          for (const auto& v380_3_branch : v380_3_branches) {
            const Path v380_3_head{v380_3_branch.first};
            const Space& v380_3_tail = v380_3_branch.second;
            const auto v381_2_branches = branches(c,v380_3_tail);
            std::vector<Space> v381_2_outputs;
            v381_2_outputs.reserve(v381_2_branches.size());
            for (const auto& v381_2_branch : v381_2_branches) {
              const Path v381_2_head{v381_2_branch.first};
              const Space& v381_2_tail = v381_2_branch.second;
              const Path v382_2 = concat_path(v380_3_head,v381_2_head);
              const auto v382_3_branches = branches(c,v381_2_tail);
              std::vector<Space> v382_3_outputs;
              v382_3_outputs.reserve(v382_3_branches.size());
              for (const auto& v382_3_branch : v382_3_branches) {
                const Path v382_3_head{v382_3_branch.first};
                const Space& v382_3_tail = v382_3_branch.second;
                const Path v383_2 = concat_path(v382_2,v382_3_head);
                const auto v383_3_branches = branches(c,v382_3_tail);
                std::vector<Space> v383_3_outputs;
                v383_3_outputs.reserve(v383_3_branches.size());
                for (const auto& v383_3_branch : v383_3_branches) {
                  const Path v383_3_head{v383_3_branch.first};
                  const Space& v383_3_tail = v383_3_branch.second;
                  const Path v384_2 = concat_path(v383_2,v383_3_head);
                  const Space v384_3 = routine_43(c, v384_2, p1, p2, p3, p4, p5, p0, v380_2, v383_3_tail);
                  v383_3_outputs.push_back(v384_3);
                }
                const Space v383_3 = join_outputs(std::move(v383_3_outputs));
                v382_3_outputs.push_back(v383_3);
              }
              const Space v382_3 = join_outputs(std::move(v382_3_outputs));
              v381_2_outputs.push_back(v382_3);
            }
            const Space v381_2 = join_outputs(std::move(v381_2_outputs));
            v380_3_outputs.push_back(v381_2);
          }
          const Space v380_3 = join_outputs(std::move(v380_3_outputs));
          v379_3_outputs.push_back(v380_3);
        }
        const Space v379_3 = join_outputs(std::move(v379_3_outputs));
        v378_3_outputs.push_back(v379_3);
      }
      const Space v378_3 = join_outputs(std::move(v378_3_outputs));
      v377_2_outputs.push_back(v378_3);
    }
    const Space v377_2 = join_outputs(std::move(v377_2_outputs));
    v376_7_outputs.push_back(v377_2);
  }
  const Space v376_7 = join_outputs(std::move(v376_7_outputs));
  return v376_7;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v385_7_branches = branches(c,s0);
  std::vector<Space> v385_7_outputs;
  v385_7_outputs.reserve(v385_7_branches.size());
  for (const auto& v385_7_branch : v385_7_branches) {
    const Path v385_7_head{v385_7_branch.first};
    const Space& v385_7_tail = v385_7_branch.second;
    const auto v386_2_branches = branches(c,v385_7_tail);
    std::vector<Space> v386_2_outputs;
    v386_2_outputs.reserve(v386_2_branches.size());
    for (const auto& v386_2_branch : v386_2_branches) {
      const Path v386_2_head{v386_2_branch.first};
      const Space& v386_2_tail = v386_2_branch.second;
      const Path v387_2 = concat_path(v385_7_head,v386_2_head);
      const auto v387_3_branches = branches(c,v386_2_tail);
      std::vector<Space> v387_3_outputs;
      v387_3_outputs.reserve(v387_3_branches.size());
      for (const auto& v387_3_branch : v387_3_branches) {
        const Path v387_3_head{v387_3_branch.first};
        const Space& v387_3_tail = v387_3_branch.second;
        const Path v388_2 = concat_path(v387_2,v387_3_head);
        const auto v388_3_branches = branches(c,v387_3_tail);
        std::vector<Space> v388_3_outputs;
        v388_3_outputs.reserve(v388_3_branches.size());
        for (const auto& v388_3_branch : v388_3_branches) {
          const Path v388_3_head{v388_3_branch.first};
          const Space& v388_3_tail = v388_3_branch.second;
          const Path v389_2 = concat_path(v388_2,v388_3_head);
          const auto v389_3_branches = branches(c,v388_3_tail);
          std::vector<Space> v389_3_outputs;
          v389_3_outputs.reserve(v389_3_branches.size());
          for (const auto& v389_3_branch : v389_3_branches) {
            const Path v389_3_head{v389_3_branch.first};
            const Space& v389_3_tail = v389_3_branch.second;
            const auto v390_2_branches = branches(c,v389_3_tail);
            std::vector<Space> v390_2_outputs;
            v390_2_outputs.reserve(v390_2_branches.size());
            for (const auto& v390_2_branch : v390_2_branches) {
              const Path v390_2_head{v390_2_branch.first};
              const Space& v390_2_tail = v390_2_branch.second;
              const Path v391_2 = concat_path(v389_3_head,v390_2_head);
              const auto v391_3_branches = branches(c,v390_2_tail);
              std::vector<Space> v391_3_outputs;
              v391_3_outputs.reserve(v391_3_branches.size());
              for (const auto& v391_3_branch : v391_3_branches) {
                const Path v391_3_head{v391_3_branch.first};
                const Space& v391_3_tail = v391_3_branch.second;
                const Path v392_2 = concat_path(v391_2,v391_3_head);
                const auto v392_3_branches = branches(c,v391_3_tail);
                std::vector<Space> v392_3_outputs;
                v392_3_outputs.reserve(v392_3_branches.size());
                for (const auto& v392_3_branch : v392_3_branches) {
                  const Path v392_3_head{v392_3_branch.first};
                  const Space& v392_3_tail = v392_3_branch.second;
                  const Path v393_2 = concat_path(v392_2,v392_3_head);
                  const Space v393_3 = routine_44(c, v393_2, p1, p2, p3, p4, p5, p0, v389_2, v392_3_tail);
                  v392_3_outputs.push_back(v393_3);
                }
                const Space v392_3 = join_outputs(std::move(v392_3_outputs));
                v391_3_outputs.push_back(v392_3);
              }
              const Space v391_3 = join_outputs(std::move(v391_3_outputs));
              v390_2_outputs.push_back(v391_3);
            }
            const Space v390_2 = join_outputs(std::move(v390_2_outputs));
            v389_3_outputs.push_back(v390_2);
          }
          const Space v389_3 = join_outputs(std::move(v389_3_outputs));
          v388_3_outputs.push_back(v389_3);
        }
        const Space v388_3 = join_outputs(std::move(v388_3_outputs));
        v387_3_outputs.push_back(v388_3);
      }
      const Space v387_3 = join_outputs(std::move(v387_3_outputs));
      v386_2_outputs.push_back(v387_3);
    }
    const Space v386_2 = join_outputs(std::move(v386_2_outputs));
    v385_7_outputs.push_back(v386_2);
  }
  const Space v385_7 = join_outputs(std::move(v385_7_outputs));
  return v385_7;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v394_7_branches = branches(c,s0);
  std::vector<Space> v394_7_outputs;
  v394_7_outputs.reserve(v394_7_branches.size());
  for (const auto& v394_7_branch : v394_7_branches) {
    const Path v394_7_head{v394_7_branch.first};
    const Space& v394_7_tail = v394_7_branch.second;
    const auto v395_2_branches = branches(c,v394_7_tail);
    std::vector<Space> v395_2_outputs;
    v395_2_outputs.reserve(v395_2_branches.size());
    for (const auto& v395_2_branch : v395_2_branches) {
      const Path v395_2_head{v395_2_branch.first};
      const Space& v395_2_tail = v395_2_branch.second;
      const Path v396_2 = concat_path(v394_7_head,v395_2_head);
      const auto v396_3_branches = branches(c,v395_2_tail);
      std::vector<Space> v396_3_outputs;
      v396_3_outputs.reserve(v396_3_branches.size());
      for (const auto& v396_3_branch : v396_3_branches) {
        const Path v396_3_head{v396_3_branch.first};
        const Space& v396_3_tail = v396_3_branch.second;
        const Path v397_2 = concat_path(v396_2,v396_3_head);
        const auto v397_3_branches = branches(c,v396_3_tail);
        std::vector<Space> v397_3_outputs;
        v397_3_outputs.reserve(v397_3_branches.size());
        for (const auto& v397_3_branch : v397_3_branches) {
          const Path v397_3_head{v397_3_branch.first};
          const Space& v397_3_tail = v397_3_branch.second;
          const Path v398_2 = concat_path(v397_2,v397_3_head);
          const auto v398_3_branches = branches(c,v397_3_tail);
          std::vector<Space> v398_3_outputs;
          v398_3_outputs.reserve(v398_3_branches.size());
          for (const auto& v398_3_branch : v398_3_branches) {
            const Path v398_3_head{v398_3_branch.first};
            const Space& v398_3_tail = v398_3_branch.second;
            const auto v399_2_branches = branches(c,v398_3_tail);
            std::vector<Space> v399_2_outputs;
            v399_2_outputs.reserve(v399_2_branches.size());
            for (const auto& v399_2_branch : v399_2_branches) {
              const Path v399_2_head{v399_2_branch.first};
              const Space& v399_2_tail = v399_2_branch.second;
              const Path v400_2 = concat_path(v398_3_head,v399_2_head);
              const auto v400_3_branches = branches(c,v399_2_tail);
              std::vector<Space> v400_3_outputs;
              v400_3_outputs.reserve(v400_3_branches.size());
              for (const auto& v400_3_branch : v400_3_branches) {
                const Path v400_3_head{v400_3_branch.first};
                const Space& v400_3_tail = v400_3_branch.second;
                const Path v401_2 = concat_path(v400_2,v400_3_head);
                const auto v401_3_branches = branches(c,v400_3_tail);
                std::vector<Space> v401_3_outputs;
                v401_3_outputs.reserve(v401_3_branches.size());
                for (const auto& v401_3_branch : v401_3_branches) {
                  const Path v401_3_head{v401_3_branch.first};
                  const Space& v401_3_tail = v401_3_branch.second;
                  const Path v402_2 = concat_path(v401_2,v401_3_head);
                  const Space v402_3 = routine_45(c, v402_2, p1, p2, p3, p4, p5, p0, v398_2, v401_3_tail);
                  v401_3_outputs.push_back(v402_3);
                }
                const Space v401_3 = join_outputs(std::move(v401_3_outputs));
                v400_3_outputs.push_back(v401_3);
              }
              const Space v400_3 = join_outputs(std::move(v400_3_outputs));
              v399_2_outputs.push_back(v400_3);
            }
            const Space v399_2 = join_outputs(std::move(v399_2_outputs));
            v398_3_outputs.push_back(v399_2);
          }
          const Space v398_3 = join_outputs(std::move(v398_3_outputs));
          v397_3_outputs.push_back(v398_3);
        }
        const Space v397_3 = join_outputs(std::move(v397_3_outputs));
        v396_3_outputs.push_back(v397_3);
      }
      const Space v396_3 = join_outputs(std::move(v396_3_outputs));
      v395_2_outputs.push_back(v396_3);
    }
    const Space v395_2 = join_outputs(std::move(v395_2_outputs));
    v394_7_outputs.push_back(v395_2);
  }
  const Space v394_7 = join_outputs(std::move(v394_7_outputs));
  return v394_7;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v403_7_branches = branches(c,s0);
  std::vector<Space> v403_7_outputs;
  v403_7_outputs.reserve(v403_7_branches.size());
  for (const auto& v403_7_branch : v403_7_branches) {
    const Path v403_7_head{v403_7_branch.first};
    const Space& v403_7_tail = v403_7_branch.second;
    const auto v404_2_branches = branches(c,v403_7_tail);
    std::vector<Space> v404_2_outputs;
    v404_2_outputs.reserve(v404_2_branches.size());
    for (const auto& v404_2_branch : v404_2_branches) {
      const Path v404_2_head{v404_2_branch.first};
      const Space& v404_2_tail = v404_2_branch.second;
      const Path v405_2 = concat_path(v403_7_head,v404_2_head);
      const auto v405_3_branches = branches(c,v404_2_tail);
      std::vector<Space> v405_3_outputs;
      v405_3_outputs.reserve(v405_3_branches.size());
      for (const auto& v405_3_branch : v405_3_branches) {
        const Path v405_3_head{v405_3_branch.first};
        const Space& v405_3_tail = v405_3_branch.second;
        const Path v406_2 = concat_path(v405_2,v405_3_head);
        const auto v406_3_branches = branches(c,v405_3_tail);
        std::vector<Space> v406_3_outputs;
        v406_3_outputs.reserve(v406_3_branches.size());
        for (const auto& v406_3_branch : v406_3_branches) {
          const Path v406_3_head{v406_3_branch.first};
          const Space& v406_3_tail = v406_3_branch.second;
          const Path v407_2 = concat_path(v406_2,v406_3_head);
          const auto v407_3_branches = branches(c,v406_3_tail);
          std::vector<Space> v407_3_outputs;
          v407_3_outputs.reserve(v407_3_branches.size());
          for (const auto& v407_3_branch : v407_3_branches) {
            const Path v407_3_head{v407_3_branch.first};
            const Space& v407_3_tail = v407_3_branch.second;
            const auto v408_2_branches = branches(c,v407_3_tail);
            std::vector<Space> v408_2_outputs;
            v408_2_outputs.reserve(v408_2_branches.size());
            for (const auto& v408_2_branch : v408_2_branches) {
              const Path v408_2_head{v408_2_branch.first};
              const Space& v408_2_tail = v408_2_branch.second;
              const Path v409_2 = concat_path(v407_3_head,v408_2_head);
              const auto v409_3_branches = branches(c,v408_2_tail);
              std::vector<Space> v409_3_outputs;
              v409_3_outputs.reserve(v409_3_branches.size());
              for (const auto& v409_3_branch : v409_3_branches) {
                const Path v409_3_head{v409_3_branch.first};
                const Space& v409_3_tail = v409_3_branch.second;
                const Path v410_2 = concat_path(v409_2,v409_3_head);
                const auto v410_3_branches = branches(c,v409_3_tail);
                std::vector<Space> v410_3_outputs;
                v410_3_outputs.reserve(v410_3_branches.size());
                for (const auto& v410_3_branch : v410_3_branches) {
                  const Path v410_3_head{v410_3_branch.first};
                  const Space& v410_3_tail = v410_3_branch.second;
                  const Path v411_2 = concat_path(v410_2,v410_3_head);
                  const Space v411_3 = routine_46(c, v411_2, p1, p2, p3, p4, p5, p0, v407_2, v410_3_tail);
                  v410_3_outputs.push_back(v411_3);
                }
                const Space v410_3 = join_outputs(std::move(v410_3_outputs));
                v409_3_outputs.push_back(v410_3);
              }
              const Space v409_3 = join_outputs(std::move(v409_3_outputs));
              v408_2_outputs.push_back(v409_3);
            }
            const Space v408_2 = join_outputs(std::move(v408_2_outputs));
            v407_3_outputs.push_back(v408_2);
          }
          const Space v407_3 = join_outputs(std::move(v407_3_outputs));
          v406_3_outputs.push_back(v407_3);
        }
        const Space v406_3 = join_outputs(std::move(v406_3_outputs));
        v405_3_outputs.push_back(v406_3);
      }
      const Space v405_3 = join_outputs(std::move(v405_3_outputs));
      v404_2_outputs.push_back(v405_3);
    }
    const Space v404_2 = join_outputs(std::move(v404_2_outputs));
    v403_7_outputs.push_back(v404_2);
  }
  const Space v403_7 = join_outputs(std::move(v403_7_outputs));
  return v403_7;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v412_11 = concat_path(constant_3,p1);
  const Space v412_12 = singleton(v412_11);
  const Space v412_13 = unite(constant_73,v412_12);
  const Path v412_15 = concat_path(constant_5,p2);
  const Space v412_16 = singleton(v412_15);
  const Space v412_17 = unite(v412_13,v412_16);
  const Path v412_19 = concat_path(constant_7,p3);
  const Space v412_20 = singleton(v412_19);
  const Space v412_21 = unite(v412_17,v412_20);
  const Path v412_23 = concat_path(constant_9,p4);
  const Space v412_24 = singleton(v412_23);
  const Space v412_25 = unite(v412_21,v412_24);
  const Path v412_27 = concat_path(constant_11,p5);
  const Space v412_28 = singleton(v412_27);
  const Space v412_29 = unite(v412_25,v412_28);
  const Path v412_31 = concat_path(constant_13,p6);
  const Space v412_32 = singleton(v412_31);
  const Space v412_33 = unite(v412_29,v412_32);
  const Path v412_35 = concat_path(constant_15,p7);
  const Space v412_36 = singleton(v412_35);
  const Space v412_37 = unite(v412_33,v412_36);
  const Path v412_39 = concat_path(constant_17,p0);
  const Space v412_40 = singleton(v412_39);
  const Space v412_41 = unite(v412_37,v412_40);
  return v412_41;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v413_11 = concat_path(constant_1,p1);
  const Space v413_12 = singleton(v413_11);
  const Space v413_13 = unite(constant_74,v413_12);
  const Path v413_15 = concat_path(constant_5,p2);
  const Space v413_16 = singleton(v413_15);
  const Space v413_17 = unite(v413_13,v413_16);
  const Path v413_19 = concat_path(constant_7,p3);
  const Space v413_20 = singleton(v413_19);
  const Space v413_21 = unite(v413_17,v413_20);
  const Path v413_23 = concat_path(constant_9,p4);
  const Space v413_24 = singleton(v413_23);
  const Space v413_25 = unite(v413_21,v413_24);
  const Path v413_27 = concat_path(constant_11,p5);
  const Space v413_28 = singleton(v413_27);
  const Space v413_29 = unite(v413_25,v413_28);
  const Path v413_31 = concat_path(constant_13,p6);
  const Space v413_32 = singleton(v413_31);
  const Space v413_33 = unite(v413_29,v413_32);
  const Path v413_35 = concat_path(constant_15,p7);
  const Space v413_36 = singleton(v413_35);
  const Space v413_37 = unite(v413_33,v413_36);
  const Path v413_39 = concat_path(constant_17,p0);
  const Space v413_40 = singleton(v413_39);
  const Space v413_41 = unite(v413_37,v413_40);
  return v413_41;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v414_11 = concat_path(constant_1,p1);
  const Space v414_12 = singleton(v414_11);
  const Space v414_13 = unite(constant_75,v414_12);
  const Path v414_15 = concat_path(constant_3,p2);
  const Space v414_16 = singleton(v414_15);
  const Space v414_17 = unite(v414_13,v414_16);
  const Path v414_19 = concat_path(constant_7,p3);
  const Space v414_20 = singleton(v414_19);
  const Space v414_21 = unite(v414_17,v414_20);
  const Path v414_23 = concat_path(constant_9,p4);
  const Space v414_24 = singleton(v414_23);
  const Space v414_25 = unite(v414_21,v414_24);
  const Path v414_27 = concat_path(constant_11,p5);
  const Space v414_28 = singleton(v414_27);
  const Space v414_29 = unite(v414_25,v414_28);
  const Path v414_31 = concat_path(constant_13,p6);
  const Space v414_32 = singleton(v414_31);
  const Space v414_33 = unite(v414_29,v414_32);
  const Path v414_35 = concat_path(constant_15,p7);
  const Space v414_36 = singleton(v414_35);
  const Space v414_37 = unite(v414_33,v414_36);
  const Path v414_39 = concat_path(constant_17,p0);
  const Space v414_40 = singleton(v414_39);
  const Space v414_41 = unite(v414_37,v414_40);
  return v414_41;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v415_11 = concat_path(constant_1,p1);
  const Space v415_12 = singleton(v415_11);
  const Space v415_13 = unite(constant_76,v415_12);
  const Path v415_15 = concat_path(constant_3,p2);
  const Space v415_16 = singleton(v415_15);
  const Space v415_17 = unite(v415_13,v415_16);
  const Path v415_19 = concat_path(constant_5,p3);
  const Space v415_20 = singleton(v415_19);
  const Space v415_21 = unite(v415_17,v415_20);
  const Path v415_23 = concat_path(constant_9,p4);
  const Space v415_24 = singleton(v415_23);
  const Space v415_25 = unite(v415_21,v415_24);
  const Path v415_27 = concat_path(constant_11,p5);
  const Space v415_28 = singleton(v415_27);
  const Space v415_29 = unite(v415_25,v415_28);
  const Path v415_31 = concat_path(constant_13,p6);
  const Space v415_32 = singleton(v415_31);
  const Space v415_33 = unite(v415_29,v415_32);
  const Path v415_35 = concat_path(constant_15,p7);
  const Space v415_36 = singleton(v415_35);
  const Space v415_37 = unite(v415_33,v415_36);
  const Path v415_39 = concat_path(constant_17,p0);
  const Space v415_40 = singleton(v415_39);
  const Space v415_41 = unite(v415_37,v415_40);
  return v415_41;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v416_11 = concat_path(constant_1,p1);
  const Space v416_12 = singleton(v416_11);
  const Space v416_13 = unite(constant_77,v416_12);
  const Path v416_15 = concat_path(constant_3,p2);
  const Space v416_16 = singleton(v416_15);
  const Space v416_17 = unite(v416_13,v416_16);
  const Path v416_19 = concat_path(constant_5,p3);
  const Space v416_20 = singleton(v416_19);
  const Space v416_21 = unite(v416_17,v416_20);
  const Path v416_23 = concat_path(constant_7,p4);
  const Space v416_24 = singleton(v416_23);
  const Space v416_25 = unite(v416_21,v416_24);
  const Path v416_27 = concat_path(constant_11,p5);
  const Space v416_28 = singleton(v416_27);
  const Space v416_29 = unite(v416_25,v416_28);
  const Path v416_31 = concat_path(constant_13,p6);
  const Space v416_32 = singleton(v416_31);
  const Space v416_33 = unite(v416_29,v416_32);
  const Path v416_35 = concat_path(constant_15,p7);
  const Space v416_36 = singleton(v416_35);
  const Space v416_37 = unite(v416_33,v416_36);
  const Path v416_39 = concat_path(constant_17,p0);
  const Space v416_40 = singleton(v416_39);
  const Space v416_41 = unite(v416_37,v416_40);
  return v416_41;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v417_11 = concat_path(constant_1,p1);
  const Space v417_12 = singleton(v417_11);
  const Space v417_13 = unite(constant_78,v417_12);
  const Path v417_15 = concat_path(constant_3,p2);
  const Space v417_16 = singleton(v417_15);
  const Space v417_17 = unite(v417_13,v417_16);
  const Path v417_19 = concat_path(constant_5,p3);
  const Space v417_20 = singleton(v417_19);
  const Space v417_21 = unite(v417_17,v417_20);
  const Path v417_23 = concat_path(constant_7,p4);
  const Space v417_24 = singleton(v417_23);
  const Space v417_25 = unite(v417_21,v417_24);
  const Path v417_27 = concat_path(constant_9,p5);
  const Space v417_28 = singleton(v417_27);
  const Space v417_29 = unite(v417_25,v417_28);
  const Path v417_31 = concat_path(constant_13,p6);
  const Space v417_32 = singleton(v417_31);
  const Space v417_33 = unite(v417_29,v417_32);
  const Path v417_35 = concat_path(constant_15,p7);
  const Space v417_36 = singleton(v417_35);
  const Space v417_37 = unite(v417_33,v417_36);
  const Path v417_39 = concat_path(constant_17,p0);
  const Space v417_40 = singleton(v417_39);
  const Space v417_41 = unite(v417_37,v417_40);
  return v417_41;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v418_11 = concat_path(constant_1,p1);
  const Space v418_12 = singleton(v418_11);
  const Space v418_13 = unite(constant_79,v418_12);
  const Path v418_15 = concat_path(constant_3,p2);
  const Space v418_16 = singleton(v418_15);
  const Space v418_17 = unite(v418_13,v418_16);
  const Path v418_19 = concat_path(constant_5,p3);
  const Space v418_20 = singleton(v418_19);
  const Space v418_21 = unite(v418_17,v418_20);
  const Path v418_23 = concat_path(constant_7,p4);
  const Space v418_24 = singleton(v418_23);
  const Space v418_25 = unite(v418_21,v418_24);
  const Path v418_27 = concat_path(constant_9,p5);
  const Space v418_28 = singleton(v418_27);
  const Space v418_29 = unite(v418_25,v418_28);
  const Path v418_31 = concat_path(constant_11,p6);
  const Space v418_32 = singleton(v418_31);
  const Space v418_33 = unite(v418_29,v418_32);
  const Path v418_35 = concat_path(constant_15,p7);
  const Space v418_36 = singleton(v418_35);
  const Space v418_37 = unite(v418_33,v418_36);
  const Path v418_39 = concat_path(constant_17,p0);
  const Space v418_40 = singleton(v418_39);
  const Space v418_41 = unite(v418_37,v418_40);
  return v418_41;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v419_11 = concat_path(constant_1,p1);
  const Space v419_12 = singleton(v419_11);
  const Space v419_13 = unite(constant_80,v419_12);
  const Path v419_15 = concat_path(constant_3,p2);
  const Space v419_16 = singleton(v419_15);
  const Space v419_17 = unite(v419_13,v419_16);
  const Path v419_19 = concat_path(constant_5,p3);
  const Space v419_20 = singleton(v419_19);
  const Space v419_21 = unite(v419_17,v419_20);
  const Path v419_23 = concat_path(constant_7,p4);
  const Space v419_24 = singleton(v419_23);
  const Space v419_25 = unite(v419_21,v419_24);
  const Path v419_27 = concat_path(constant_9,p5);
  const Space v419_28 = singleton(v419_27);
  const Space v419_29 = unite(v419_25,v419_28);
  const Path v419_31 = concat_path(constant_11,p6);
  const Space v419_32 = singleton(v419_31);
  const Space v419_33 = unite(v419_29,v419_32);
  const Path v419_35 = concat_path(constant_13,p7);
  const Space v419_36 = singleton(v419_35);
  const Space v419_37 = unite(v419_33,v419_36);
  const Path v419_39 = concat_path(constant_17,p0);
  const Space v419_40 = singleton(v419_39);
  const Space v419_41 = unite(v419_37,v419_40);
  return v419_41;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v420_11 = concat_path(constant_1,p1);
  const Space v420_12 = singleton(v420_11);
  const Space v420_13 = unite(constant_81,v420_12);
  const Path v420_15 = concat_path(constant_3,p2);
  const Space v420_16 = singleton(v420_15);
  const Space v420_17 = unite(v420_13,v420_16);
  const Path v420_19 = concat_path(constant_5,p3);
  const Space v420_20 = singleton(v420_19);
  const Space v420_21 = unite(v420_17,v420_20);
  const Path v420_23 = concat_path(constant_7,p4);
  const Space v420_24 = singleton(v420_23);
  const Space v420_25 = unite(v420_21,v420_24);
  const Path v420_27 = concat_path(constant_9,p5);
  const Space v420_28 = singleton(v420_27);
  const Space v420_29 = unite(v420_25,v420_28);
  const Path v420_31 = concat_path(constant_11,p6);
  const Space v420_32 = singleton(v420_31);
  const Space v420_33 = unite(v420_29,v420_32);
  const Path v420_35 = concat_path(constant_13,p7);
  const Space v420_36 = singleton(v420_35);
  const Space v420_37 = unite(v420_33,v420_36);
  const Path v420_39 = concat_path(constant_15,p0);
  const Space v420_40 = singleton(v420_39);
  const Space v420_41 = unite(v420_37,v420_40);
  return v420_41;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
