#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{2,2};
static const Space constant_1 = literal_text("1 0 ");
static const Space constant_2 = literal_text("1 1 2");
static const Space constant_3 = singleton(Path{});
static const Path constant_4 = Path{2,1,2,1,1,1,1,1,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  Space v0_12_result;
  for (int v0_12_label = 1; v0_12_label <= 2; ++v0_12_label) {
    const Space v0_12_tail = child(v0_2,v0_12_label);
    if (v0_12_tail.empty()) continue;
    const Path v0_12_head{v0_12_label};
    const Space v1_2 = singleton(v0_12_head);
    const Space v1_3 = intersect(constant_2,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_3 : Space{});
    const Space v1_5 = subtract(constant_1,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_12_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_2,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_3 : Space{});
        const Space v3_5 = subtract(constant_1,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_12_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail, bound_space(s0));
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_2,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_3 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_12_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail, bound_space(s0));
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_2,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_3 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_12_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_2,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_3 : Space{});
        const Space v7_5 = subtract(constant_1,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_12_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail, bound_space(s0));
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_2,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_3 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_12_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail, bound_space(s0));
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_12_result = unite(v0_12_result,v1_12);
  }
  const Space v0_12 = std::move(v0_12_result);
  const Space v0_14 = wrap(v0_12,constant_4);
  return v0_14;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v10_12_result;
  for (int v10_12_label = 1; v10_12_label <= 2; ++v10_12_label) {
    const Space v10_12_tail = child(s0,v10_12_label);
    if (v10_12_tail.empty()) continue;
    const Path v10_12_head{v10_12_label};
    const Space v11_2 = singleton(v10_12_head);
    const Space v11_3 = intersect(constant_2,v11_2);
    const Space v11_4 = (has_head(v11_3) ? constant_3 : Space{});
    const Space v11_5 = subtract(constant_1,v11_4);
    Space v11_8;
    if (!v11_5.empty()) {
      const Path v12_6 = concat_path(p0,v10_12_head);
      Space v12_7_result;
      for (int v12_7_label = 1; v12_7_label <= 2; ++v12_7_label) {
        const Space v12_7_tail = child(v10_12_tail,v12_7_label);
        if (v12_7_tail.empty()) continue;
        const Path v12_7_head{v12_7_label};
        const Space v13_2 = singleton(v12_7_head);
        const Space v13_3 = intersect(constant_2,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_3 : Space{});
        const Space v13_5 = subtract(constant_1,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_7_head);
          const Space v14_7 = routine_4(c, v14_6, v12_7_tail, s1);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_2,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_3 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_7_head);
          const Space v15_11 = routine_5(c, v15_6, v12_7_tail, s1);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_7_result = unite(v12_7_result,v13_13);
      }
      const Space v12_7 = std::move(v12_7_result);
      v11_8 = compose(v11_5,v12_7);
    }
    const Space v11_9 = intersect(constant_2,v11_2);
    const Space v11_10 = (has_head(v11_9) ? constant_3 : Space{});
    Space v11_12;
    if (!v11_10.empty()) {
      const Path v16_6 = concat_path(p0,v10_12_head);
      Space v16_11_result;
      for (int v16_11_label = 1; v16_11_label <= 2; ++v16_11_label) {
        const Space v16_11_tail = child(v10_12_tail,v16_11_label);
        if (v16_11_tail.empty()) continue;
        const Path v16_11_head{v16_11_label};
        const Space v17_2 = singleton(v16_11_head);
        const Space v17_3 = intersect(constant_2,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_3 : Space{});
        const Space v17_5 = subtract(constant_1,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_11_head);
          const Space v18_7 = routine_4(c, v18_6, v16_11_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_2,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_3 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_11_head);
          const Space v19_11 = routine_3(c, v19_6, v16_11_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_11_result = unite(v16_11_result,v17_13);
      }
      const Space v16_11 = std::move(v16_11_result);
      v11_12 = compose(v11_10,v16_11);
    }
    const Space v11_13 = unite(v11_8,v11_12);
    v10_12_result = unite(v10_12_result,v11_13);
  }
  const Space v10_12 = std::move(v10_12_result);
  return v10_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v20_12_result;
  for (int v20_12_label = 1; v20_12_label <= 2; ++v20_12_label) {
    const Space v20_12_tail = child(s0,v20_12_label);
    if (v20_12_tail.empty()) continue;
    const Path v20_12_head{v20_12_label};
    const Space v21_2 = singleton(v20_12_head);
    const Space v21_3 = intersect(constant_2,v21_2);
    const Space v21_4 = (has_head(v21_3) ? constant_3 : Space{});
    const Space v21_5 = subtract(constant_1,v21_4);
    Space v21_8;
    if (!v21_5.empty()) {
      const Path v22_6 = concat_path(p0,v20_12_head);
      Space v22_7_result;
      for (int v22_7_label = 1; v22_7_label <= 2; ++v22_7_label) {
        const Space v22_7_tail = child(v20_12_tail,v22_7_label);
        if (v22_7_tail.empty()) continue;
        const Path v22_7_head{v22_7_label};
        const Space v23_2 = singleton(v22_7_head);
        const Space v23_3 = intersect(constant_2,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_3 : Space{});
        const Space v23_5 = subtract(constant_1,v23_4);
        Space v23_8;
        if (!v23_5.empty()) {
          const Path v24_6 = concat_path(v22_6,v22_7_head);
          const Space v24_7 = routine_4(c, v24_6, v22_7_tail, s1);
          v23_8 = compose(v23_5,v24_7);
        }
        const Space v23_9 = intersect(constant_2,v23_2);
        const Space v23_10 = (has_head(v23_9) ? constant_3 : Space{});
        Space v23_12;
        if (!v23_10.empty()) {
          const Path v25_6 = concat_path(v22_6,v22_7_head);
          const Space v25_11 = routine_5(c, v25_6, v22_7_tail, s1);
          v23_12 = compose(v23_10,v25_11);
        }
        const Space v23_13 = unite(v23_8,v23_12);
        v22_7_result = unite(v22_7_result,v23_13);
      }
      const Space v22_7 = std::move(v22_7_result);
      v21_8 = compose(v21_5,v22_7);
    }
    const Space v21_9 = intersect(constant_2,v21_2);
    const Space v21_10 = (has_head(v21_9) ? constant_3 : Space{});
    Space v21_12;
    if (!v21_10.empty()) {
      const Path v26_6 = concat_path(p0,v20_12_head);
      Space v26_11_result;
      for (int v26_11_label = 1; v26_11_label <= 2; ++v26_11_label) {
        const Space v26_11_tail = child(v20_12_tail,v26_11_label);
        if (v26_11_tail.empty()) continue;
        const Path v26_11_head{v26_11_label};
        const Space v27_2 = singleton(v26_11_head);
        const Space v27_3 = intersect(constant_2,v27_2);
        const Space v27_4 = (has_head(v27_3) ? constant_3 : Space{});
        const Space v27_5 = subtract(constant_1,v27_4);
        Space v27_7;
        if (!v27_5.empty()) {
          const Space v28_6 = routine_6(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_7 = compose(v27_5,v28_6);
        }
        const Space v27_8 = intersect(constant_2,v27_2);
        const Space v27_9 = (has_head(v27_8) ? constant_3 : Space{});
        Space v27_11;
        if (!v27_9.empty()) {
          const Space v29_10 = routine_7(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_11 = compose(v27_9,v29_10);
        }
        const Space v27_12 = unite(v27_7,v27_11);
        v26_11_result = unite(v26_11_result,v27_12);
      }
      const Space v26_11 = std::move(v26_11_result);
      v21_12 = compose(v21_10,v26_11);
    }
    const Space v21_13 = unite(v21_8,v21_12);
    v20_12_result = unite(v20_12_result,v21_13);
  }
  const Space v20_12 = std::move(v20_12_result);
  return v20_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v30_12_result;
  for (int v30_12_label = 1; v30_12_label <= 2; ++v30_12_label) {
    const Space v30_12_tail = child(s0,v30_12_label);
    if (v30_12_tail.empty()) continue;
    const Path v30_12_head{v30_12_label};
    const Space v31_2 = singleton(v30_12_head);
    const Space v31_3 = intersect(constant_2,v31_2);
    const Space v31_4 = (has_head(v31_3) ? constant_3 : Space{});
    const Space v31_5 = subtract(constant_1,v31_4);
    Space v31_7;
    if (!v31_5.empty()) {
      Space v32_6_result;
      for (int v32_6_label = 1; v32_6_label <= 2; ++v32_6_label) {
        const Space v32_6_tail = child(v30_12_tail,v32_6_label);
        if (v32_6_tail.empty()) continue;
        const Path v32_6_head{v32_6_label};
        const Space v33_2 = singleton(v32_6_head);
        const Space v33_3 = intersect(constant_2,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_3 : Space{});
        const Space v33_5 = subtract(constant_1,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v30_12_head,v32_6_head);
          const Space v34_7 = routine_8(c, v34_6, p0, v32_6_tail, s1);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_2,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_3 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v30_12_head,v32_6_head);
          const Space v35_11 = routine_9(c, v35_6, p0, v32_6_tail, s1);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_6_result = unite(v32_6_result,v33_13);
      }
      const Space v32_6 = std::move(v32_6_result);
      v31_7 = compose(v31_5,v32_6);
    }
    const Space v31_8 = intersect(constant_2,v31_2);
    const Space v31_9 = (has_head(v31_8) ? constant_3 : Space{});
    Space v31_11;
    if (!v31_9.empty()) {
      Space v36_10_result;
      for (int v36_10_label = 1; v36_10_label <= 2; ++v36_10_label) {
        const Space v36_10_tail = child(v30_12_tail,v36_10_label);
        if (v36_10_tail.empty()) continue;
        const Path v36_10_head{v36_10_label};
        const Space v37_2 = singleton(v36_10_head);
        const Space v37_3 = intersect(constant_2,v37_2);
        const Space v37_4 = (has_head(v37_3) ? constant_3 : Space{});
        const Space v37_5 = subtract(constant_1,v37_4);
        Space v37_8;
        if (!v37_5.empty()) {
          const Path v38_6 = concat_path(v30_12_head,v36_10_head);
          const Space v38_7 = routine_8(c, v38_6, p0, v36_10_tail, s1);
          v37_8 = compose(v37_5,v38_7);
        }
        const Space v37_9 = intersect(constant_2,v37_2);
        const Space v37_10 = (has_head(v37_9) ? constant_3 : Space{});
        Space v37_12;
        if (!v37_10.empty()) {
          const Path v39_6 = concat_path(v30_12_head,v36_10_head);
          const Space v39_11 = routine_10(c, v39_6, p0, v36_10_tail, s1);
          v37_12 = compose(v37_10,v39_11);
        }
        const Space v37_13 = unite(v37_8,v37_12);
        v36_10_result = unite(v36_10_result,v37_13);
      }
      const Space v36_10 = std::move(v36_10_result);
      v31_11 = compose(v31_9,v36_10);
    }
    const Space v31_12 = unite(v31_7,v31_11);
    v30_12_result = unite(v30_12_result,v31_12);
  }
  const Space v30_12 = std::move(v30_12_result);
  return v30_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v40_12_result;
  for (int v40_12_label = 1; v40_12_label <= 2; ++v40_12_label) {
    const Space v40_12_tail = child(s0,v40_12_label);
    if (v40_12_tail.empty()) continue;
    const Path v40_12_head{v40_12_label};
    const Space v41_2 = singleton(v40_12_head);
    const Space v41_3 = intersect(constant_2,v41_2);
    const Space v41_4 = (has_head(v41_3) ? constant_3 : Space{});
    const Space v41_5 = subtract(constant_1,v41_4);
    Space v41_8;
    if (!v41_5.empty()) {
      const Path v42_6 = concat_path(p0,v40_12_head);
      Space v42_7_result;
      for (int v42_7_label = 1; v42_7_label <= 2; ++v42_7_label) {
        const Space v42_7_tail = child(v40_12_tail,v42_7_label);
        if (v42_7_tail.empty()) continue;
        const Path v42_7_head{v42_7_label};
        const Space v43_2 = singleton(v42_7_head);
        const Space v43_3 = intersect(constant_2,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_3 : Space{});
        const Space v43_5 = subtract(constant_1,v43_4);
        Space v43_8;
        if (!v43_5.empty()) {
          const Path v44_6 = concat_path(v42_6,v42_7_head);
          const Space v44_7 = routine_11(c, v44_6, v42_7_tail, s1);
          v43_8 = compose(v43_5,v44_7);
        }
        const Space v43_9 = intersect(constant_2,v43_2);
        const Space v43_10 = (has_head(v43_9) ? constant_3 : Space{});
        Space v43_12;
        if (!v43_10.empty()) {
          const Path v45_6 = concat_path(v42_6,v42_7_head);
          const Space v45_11 = routine_12(c, v45_6, v42_7_tail, s1);
          v43_12 = compose(v43_10,v45_11);
        }
        const Space v43_13 = unite(v43_8,v43_12);
        v42_7_result = unite(v42_7_result,v43_13);
      }
      const Space v42_7 = std::move(v42_7_result);
      v41_8 = compose(v41_5,v42_7);
    }
    const Space v41_9 = intersect(constant_2,v41_2);
    const Space v41_10 = (has_head(v41_9) ? constant_3 : Space{});
    Space v41_12;
    if (!v41_10.empty()) {
      const Path v46_6 = concat_path(p0,v40_12_head);
      Space v46_11_result;
      for (int v46_11_label = 1; v46_11_label <= 2; ++v46_11_label) {
        const Space v46_11_tail = child(v40_12_tail,v46_11_label);
        if (v46_11_tail.empty()) continue;
        const Path v46_11_head{v46_11_label};
        const Space v47_2 = singleton(v46_11_head);
        const Space v47_3 = intersect(constant_2,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_3 : Space{});
        const Space v47_5 = subtract(constant_1,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_11_head);
          const Space v48_7 = routine_11(c, v48_6, v46_11_tail, s1);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_2,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_3 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_11_head);
          const Space v49_11 = routine_3(c, v49_6, v46_11_tail, s1);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_11_result = unite(v46_11_result,v47_13);
      }
      const Space v46_11 = std::move(v46_11_result);
      v41_12 = compose(v41_10,v46_11);
    }
    const Space v41_13 = unite(v41_8,v41_12);
    v40_12_result = unite(v40_12_result,v41_13);
  }
  const Space v40_12 = std::move(v40_12_result);
  return v40_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v50_12_result;
  for (int v50_12_label = 1; v50_12_label <= 2; ++v50_12_label) {
    const Space v50_12_tail = child(s0,v50_12_label);
    if (v50_12_tail.empty()) continue;
    const Path v50_12_head{v50_12_label};
    const Space v51_2 = singleton(v50_12_head);
    const Space v51_3 = intersect(constant_2,v51_2);
    const Space v51_4 = (has_head(v51_3) ? constant_3 : Space{});
    const Space v51_5 = subtract(constant_1,v51_4);
    Space v51_8;
    if (!v51_5.empty()) {
      const Path v52_6 = concat_path(p0,v50_12_head);
      Space v52_7_result;
      for (int v52_7_label = 1; v52_7_label <= 2; ++v52_7_label) {
        const Space v52_7_tail = child(v50_12_tail,v52_7_label);
        if (v52_7_tail.empty()) continue;
        const Path v52_7_head{v52_7_label};
        const Space v53_2 = singleton(v52_7_head);
        const Space v53_3 = intersect(constant_2,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_3 : Space{});
        const Space v53_5 = subtract(constant_1,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_7_head);
          const Space v54_7 = routine_11(c, v54_6, v52_7_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_2,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_3 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_7_head);
          const Space v55_11 = routine_12(c, v55_6, v52_7_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_7_result = unite(v52_7_result,v53_13);
      }
      const Space v52_7 = std::move(v52_7_result);
      v51_8 = compose(v51_5,v52_7);
    }
    const Space v51_9 = intersect(constant_2,v51_2);
    const Space v51_10 = (has_head(v51_9) ? constant_3 : Space{});
    Space v51_12;
    if (!v51_10.empty()) {
      const Path v56_6 = concat_path(p0,v50_12_head);
      Space v56_11_result;
      for (int v56_11_label = 1; v56_11_label <= 2; ++v56_11_label) {
        const Space v56_11_tail = child(v50_12_tail,v56_11_label);
        if (v56_11_tail.empty()) continue;
        const Path v56_11_head{v56_11_label};
        const Space v57_2 = singleton(v56_11_head);
        const Space v57_3 = intersect(constant_2,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_3 : Space{});
        const Space v57_5 = subtract(constant_1,v57_4);
        Space v57_7;
        if (!v57_5.empty()) {
          const Space v58_6 = routine_6(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_7 = compose(v57_5,v58_6);
        }
        const Space v57_8 = intersect(constant_2,v57_2);
        const Space v57_9 = (has_head(v57_8) ? constant_3 : Space{});
        Space v57_11;
        if (!v57_9.empty()) {
          const Space v59_10 = routine_7(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_11 = compose(v57_9,v59_10);
        }
        const Space v57_12 = unite(v57_7,v57_11);
        v56_11_result = unite(v56_11_result,v57_12);
      }
      const Space v56_11 = std::move(v56_11_result);
      v51_12 = compose(v51_10,v56_11);
    }
    const Space v51_13 = unite(v51_8,v51_12);
    v50_12_result = unite(v50_12_result,v51_13);
  }
  const Space v50_12 = std::move(v50_12_result);
  return v50_12;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v60_13_result;
  for (int v60_13_label = 1; v60_13_label <= 2; ++v60_13_label) {
    const Space v60_13_tail = child(s0,v60_13_label);
    if (v60_13_tail.empty()) continue;
    const Path v60_13_head{v60_13_label};
    const Space v61_2 = singleton(v60_13_head);
    const Space v61_3 = intersect(constant_2,v61_2);
    const Space v61_4 = (has_head(v61_3) ? constant_3 : Space{});
    const Space v61_5 = subtract(constant_1,v61_4);
    Space v61_8;
    if (!v61_5.empty()) {
      const Path v62_6 = concat_path(p0,v60_13_head);
      Space v62_7_result;
      for (int v62_7_label = 1; v62_7_label <= 2; ++v62_7_label) {
        const Space v62_7_tail = child(v60_13_tail,v62_7_label);
        if (v62_7_tail.empty()) continue;
        const Path v62_7_head{v62_7_label};
        const Space v63_2 = singleton(v62_7_head);
        const Space v63_3 = intersect(constant_2,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_3 : Space{});
        const Space v63_5 = subtract(constant_1,v63_4);
        Space v63_8;
        if (!v63_5.empty()) {
          const Path v64_6 = concat_path(v62_6,v62_7_head);
          const Space v64_7 = routine_13(c, v64_6, p1, v62_7_tail, s1);
          v63_8 = compose(v63_5,v64_7);
        }
        const Space v63_9 = intersect(constant_2,v63_2);
        const Space v63_10 = (has_head(v63_9) ? constant_3 : Space{});
        Space v63_12;
        if (!v63_10.empty()) {
          const Path v65_6 = concat_path(v62_6,v62_7_head);
          const Space v65_11 = routine_14(c, v65_6, p1, v62_7_tail, s1);
          v63_12 = compose(v63_10,v65_11);
        }
        const Space v63_13 = unite(v63_8,v63_12);
        v62_7_result = unite(v62_7_result,v63_13);
      }
      const Space v62_7 = std::move(v62_7_result);
      v61_8 = compose(v61_5,v62_7);
    }
    const Space v61_9 = intersect(constant_2,v61_2);
    const Space v61_10 = (has_head(v61_9) ? constant_3 : Space{});
    Space v61_12;
    if (!v61_10.empty()) {
      const Path v66_6 = concat_path(p0,v60_13_head);
      Space v66_11_result;
      for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
        const Space v66_11_tail = child(v60_13_tail,v66_11_label);
        if (v66_11_tail.empty()) continue;
        const Path v66_11_head{v66_11_label};
        const Space v67_2 = singleton(v66_11_head);
        const Space v67_3 = intersect(constant_2,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_3 : Space{});
        const Space v67_5 = subtract(constant_1,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_11_head);
          const Space v68_7 = routine_13(c, v68_6, p1, v66_11_tail, s1);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_2,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_3 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_11_head);
          const Space v69_11 = routine_10(c, v69_6, p1, v66_11_tail, s1);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_11_result = unite(v66_11_result,v67_13);
      }
      const Space v66_11 = std::move(v66_11_result);
      v61_12 = compose(v61_10,v66_11);
    }
    const Space v61_13 = unite(v61_8,v61_12);
    v60_13_result = unite(v60_13_result,v61_13);
  }
  const Space v60_13 = std::move(v60_13_result);
  return v60_13;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v70_8 = unwrap(s1,constant_0);
  const Space v70_9 = unwrap(v70_8,p0);
  Space v70_13_result;
  for (int v70_13_label = 1; v70_13_label <= 2; ++v70_13_label) {
    const Space v70_13_tail = child(s0,v70_13_label);
    if (v70_13_tail.empty()) continue;
    const Path v70_13_head{v70_13_label};
    const Space v71_2 = singleton(v70_13_head);
    const Space v71_3 = intersect(constant_2,v71_2);
    const Space v71_4 = (has_head(v71_3) ? constant_3 : Space{});
    const Space v71_5 = subtract(constant_1,v71_4);
    Space v71_8;
    if (!v71_5.empty()) {
      const Path v72_6 = concat_path(p0,v70_13_head);
      Space v72_7_result;
      for (int v72_7_label = 1; v72_7_label <= 2; ++v72_7_label) {
        const Space v72_7_tail = child(v70_13_tail,v72_7_label);
        if (v72_7_tail.empty()) continue;
        const Path v72_7_head{v72_7_label};
        const Space v73_2 = singleton(v72_7_head);
        const Space v73_3 = intersect(constant_2,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_3 : Space{});
        const Space v73_5 = subtract(constant_1,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_7_head);
          const Space v74_7 = routine_13(c, v74_6, p1, v72_7_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_2,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_3 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_7_head);
          const Space v75_11 = routine_14(c, v75_6, p1, v72_7_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_7_result = unite(v72_7_result,v73_13);
      }
      const Space v72_7 = std::move(v72_7_result);
      v71_8 = compose(v71_5,v72_7);
    }
    const Space v71_9 = intersect(constant_2,v71_2);
    const Space v71_10 = (has_head(v71_9) ? constant_3 : Space{});
    const Space v71_11 = unwrap(v70_9,v70_13_head);
    const Space v71_12 = unwrap(v71_11,p1);
    const Space v71_13 = compose(v71_10,v71_12);
    const Path v76_6 = concat_path(p0,v70_13_head);
    const Space v71_14 = wrap(v71_13,v76_6);
    const Space v71_15 = wrap(v71_14,p1);
    const Space v71_16 = unite(v71_8,v71_15);
    v70_13_result = unite(v70_13_result,v71_16);
  }
  const Space v70_13 = std::move(v70_13_result);
  return v70_13;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v77_13_result;
  for (int v77_13_label = 1; v77_13_label <= 2; ++v77_13_label) {
    const Space v77_13_tail = child(s0,v77_13_label);
    if (v77_13_tail.empty()) continue;
    const Path v77_13_head{v77_13_label};
    const Space v78_2 = singleton(v77_13_head);
    const Space v78_3 = intersect(constant_2,v78_2);
    const Space v78_4 = (has_head(v78_3) ? constant_3 : Space{});
    const Space v78_5 = subtract(constant_1,v78_4);
    Space v78_8;
    if (!v78_5.empty()) {
      const Path v79_6 = concat_path(p0,v77_13_head);
      Space v79_7_result;
      for (int v79_7_label = 1; v79_7_label <= 2; ++v79_7_label) {
        const Space v79_7_tail = child(v77_13_tail,v79_7_label);
        if (v79_7_tail.empty()) continue;
        const Path v79_7_head{v79_7_label};
        const Space v80_2 = singleton(v79_7_head);
        const Space v80_3 = intersect(constant_2,v80_2);
        const Space v80_4 = (has_head(v80_3) ? constant_3 : Space{});
        const Space v80_5 = subtract(constant_1,v80_4);
        Space v80_8;
        if (!v80_5.empty()) {
          const Path v81_6 = concat_path(v79_6,v79_7_head);
          const Space v81_7 = routine_15(c, v81_6, p1, v79_7_tail, s1);
          v80_8 = compose(v80_5,v81_7);
        }
        const Space v80_9 = intersect(constant_2,v80_2);
        const Space v80_10 = (has_head(v80_9) ? constant_3 : Space{});
        Space v80_12;
        if (!v80_10.empty()) {
          const Path v82_6 = concat_path(v79_6,v79_7_head);
          const Space v82_11 = routine_16(c, v82_6, p1, v79_7_tail, s1);
          v80_12 = compose(v80_10,v82_11);
        }
        const Space v80_13 = unite(v80_8,v80_12);
        v79_7_result = unite(v79_7_result,v80_13);
      }
      const Space v79_7 = std::move(v79_7_result);
      v78_8 = compose(v78_5,v79_7);
    }
    const Space v78_9 = intersect(constant_2,v78_2);
    const Space v78_10 = (has_head(v78_9) ? constant_3 : Space{});
    Space v78_12;
    if (!v78_10.empty()) {
      const Path v83_6 = concat_path(p0,v77_13_head);
      Space v83_11_result;
      for (int v83_11_label = 1; v83_11_label <= 2; ++v83_11_label) {
        const Space v83_11_tail = child(v77_13_tail,v83_11_label);
        if (v83_11_tail.empty()) continue;
        const Path v83_11_head{v83_11_label};
        const Space v84_2 = singleton(v83_11_head);
        const Space v84_3 = intersect(constant_2,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_3 : Space{});
        const Space v84_5 = subtract(constant_1,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_11_head);
          const Space v85_7 = routine_15(c, v85_6, p1, v83_11_tail, s1);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_2,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_3 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_11_head);
          const Space v86_11 = routine_10(c, v86_6, p1, v83_11_tail, s1);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_11_result = unite(v83_11_result,v84_13);
      }
      const Space v83_11 = std::move(v83_11_result);
      v78_12 = compose(v78_10,v83_11);
    }
    const Space v78_13 = unite(v78_8,v78_12);
    v77_13_result = unite(v77_13_result,v78_13);
  }
  const Space v77_13 = std::move(v77_13_result);
  return v77_13;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v87_8 = unwrap(s1,constant_0);
  const Space v87_9 = unwrap(v87_8,p0);
  Space v87_13_result;
  for (int v87_13_label = 1; v87_13_label <= 2; ++v87_13_label) {
    const Space v87_13_tail = child(s0,v87_13_label);
    if (v87_13_tail.empty()) continue;
    const Path v87_13_head{v87_13_label};
    const Space v88_2 = singleton(v87_13_head);
    const Space v88_3 = intersect(constant_2,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_3 : Space{});
    const Space v88_5 = subtract(constant_1,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_13_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_13_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_2,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_3 : Space{});
        const Space v90_5 = subtract(constant_1,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_15(c, v91_6, p1, v89_7_tail, s1);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_2,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_3 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_16(c, v92_6, p1, v89_7_tail, s1);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_2,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_3 : Space{});
    const Space v88_11 = unwrap(v87_9,v87_13_head);
    const Space v88_12 = unwrap(v88_11,p1);
    const Space v88_13 = compose(v88_10,v88_12);
    const Path v93_6 = concat_path(p0,v87_13_head);
    const Space v88_14 = wrap(v88_13,v93_6);
    const Space v88_15 = wrap(v88_14,p1);
    const Space v88_16 = unite(v88_8,v88_15);
    v87_13_result = unite(v87_13_result,v88_16);
  }
  const Space v87_13 = std::move(v87_13_result);
  return v87_13;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v94_5 = unwrap(s1,constant_0);
  const Space v94_6 = unwrap(v94_5,p0);
  const Space v94_7 = unwrap(v94_6,p1);
  const Space v94_8 = wrap(v94_7,p0);
  const Space v94_9 = wrap(v94_8,p1);
  return v94_9;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v95_12_result;
  for (int v95_12_label = 1; v95_12_label <= 2; ++v95_12_label) {
    const Space v95_12_tail = child(s0,v95_12_label);
    if (v95_12_tail.empty()) continue;
    const Path v95_12_head{v95_12_label};
    const Space v96_2 = singleton(v95_12_head);
    const Space v96_3 = intersect(constant_2,v96_2);
    const Space v96_4 = (has_head(v96_3) ? constant_3 : Space{});
    const Space v96_5 = subtract(constant_1,v96_4);
    Space v96_8;
    if (!v96_5.empty()) {
      const Path v97_6 = concat_path(p0,v95_12_head);
      Space v97_7_result;
      for (int v97_7_label = 1; v97_7_label <= 2; ++v97_7_label) {
        const Space v97_7_tail = child(v95_12_tail,v97_7_label);
        if (v97_7_tail.empty()) continue;
        const Path v97_7_head{v97_7_label};
        const Space v98_2 = singleton(v97_7_head);
        const Space v98_3 = intersect(constant_2,v98_2);
        const Space v98_4 = (has_head(v98_3) ? constant_3 : Space{});
        const Space v98_5 = subtract(constant_1,v98_4);
        Space v98_8;
        if (!v98_5.empty()) {
          const Path v99_6 = concat_path(v97_6,v97_7_head);
          const Space v99_7 = routine_17(c, v99_6, v97_7_tail, s1);
          v98_8 = compose(v98_5,v99_7);
        }
        const Space v98_9 = intersect(constant_2,v98_2);
        const Space v98_10 = (has_head(v98_9) ? constant_3 : Space{});
        Space v98_12;
        if (!v98_10.empty()) {
          const Path v100_6 = concat_path(v97_6,v97_7_head);
          const Space v100_11 = routine_18(c, v100_6, v97_7_tail, s1);
          v98_12 = compose(v98_10,v100_11);
        }
        const Space v98_13 = unite(v98_8,v98_12);
        v97_7_result = unite(v97_7_result,v98_13);
      }
      const Space v97_7 = std::move(v97_7_result);
      v96_8 = compose(v96_5,v97_7);
    }
    const Space v96_9 = intersect(constant_2,v96_2);
    const Space v96_10 = (has_head(v96_9) ? constant_3 : Space{});
    Space v96_12;
    if (!v96_10.empty()) {
      const Path v101_6 = concat_path(p0,v95_12_head);
      Space v101_11_result;
      for (int v101_11_label = 1; v101_11_label <= 2; ++v101_11_label) {
        const Space v101_11_tail = child(v95_12_tail,v101_11_label);
        if (v101_11_tail.empty()) continue;
        const Path v101_11_head{v101_11_label};
        const Space v102_2 = singleton(v101_11_head);
        const Space v102_3 = intersect(constant_2,v102_2);
        const Space v102_4 = (has_head(v102_3) ? constant_3 : Space{});
        const Space v102_5 = subtract(constant_1,v102_4);
        Space v102_8;
        if (!v102_5.empty()) {
          const Path v103_6 = concat_path(v101_6,v101_11_head);
          const Space v103_7 = routine_17(c, v103_6, v101_11_tail, s1);
          v102_8 = compose(v102_5,v103_7);
        }
        const Space v102_9 = intersect(constant_2,v102_2);
        const Space v102_10 = (has_head(v102_9) ? constant_3 : Space{});
        Space v102_12;
        if (!v102_10.empty()) {
          const Path v104_6 = concat_path(v101_6,v101_11_head);
          const Space v104_11 = routine_3(c, v104_6, v101_11_tail, s1);
          v102_12 = compose(v102_10,v104_11);
        }
        const Space v102_13 = unite(v102_8,v102_12);
        v101_11_result = unite(v101_11_result,v102_13);
      }
      const Space v101_11 = std::move(v101_11_result);
      v96_12 = compose(v96_10,v101_11);
    }
    const Space v96_13 = unite(v96_8,v96_12);
    v95_12_result = unite(v95_12_result,v96_13);
  }
  const Space v95_12 = std::move(v95_12_result);
  return v95_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v105_12_result;
  for (int v105_12_label = 1; v105_12_label <= 2; ++v105_12_label) {
    const Space v105_12_tail = child(s0,v105_12_label);
    if (v105_12_tail.empty()) continue;
    const Path v105_12_head{v105_12_label};
    const Space v106_2 = singleton(v105_12_head);
    const Space v106_3 = intersect(constant_2,v106_2);
    const Space v106_4 = (has_head(v106_3) ? constant_3 : Space{});
    const Space v106_5 = subtract(constant_1,v106_4);
    Space v106_8;
    if (!v106_5.empty()) {
      const Path v107_6 = concat_path(p0,v105_12_head);
      Space v107_7_result;
      for (int v107_7_label = 1; v107_7_label <= 2; ++v107_7_label) {
        const Space v107_7_tail = child(v105_12_tail,v107_7_label);
        if (v107_7_tail.empty()) continue;
        const Path v107_7_head{v107_7_label};
        const Space v108_2 = singleton(v107_7_head);
        const Space v108_3 = intersect(constant_2,v108_2);
        const Space v108_4 = (has_head(v108_3) ? constant_3 : Space{});
        const Space v108_5 = subtract(constant_1,v108_4);
        Space v108_8;
        if (!v108_5.empty()) {
          const Path v109_6 = concat_path(v107_6,v107_7_head);
          const Space v109_7 = routine_17(c, v109_6, v107_7_tail, s1);
          v108_8 = compose(v108_5,v109_7);
        }
        const Space v108_9 = intersect(constant_2,v108_2);
        const Space v108_10 = (has_head(v108_9) ? constant_3 : Space{});
        Space v108_12;
        if (!v108_10.empty()) {
          const Path v110_6 = concat_path(v107_6,v107_7_head);
          const Space v110_11 = routine_18(c, v110_6, v107_7_tail, s1);
          v108_12 = compose(v108_10,v110_11);
        }
        const Space v108_13 = unite(v108_8,v108_12);
        v107_7_result = unite(v107_7_result,v108_13);
      }
      const Space v107_7 = std::move(v107_7_result);
      v106_8 = compose(v106_5,v107_7);
    }
    const Space v106_9 = intersect(constant_2,v106_2);
    const Space v106_10 = (has_head(v106_9) ? constant_3 : Space{});
    Space v106_12;
    if (!v106_10.empty()) {
      const Path v111_6 = concat_path(p0,v105_12_head);
      Space v111_11_result;
      for (int v111_11_label = 1; v111_11_label <= 2; ++v111_11_label) {
        const Space v111_11_tail = child(v105_12_tail,v111_11_label);
        if (v111_11_tail.empty()) continue;
        const Path v111_11_head{v111_11_label};
        const Space v112_2 = singleton(v111_11_head);
        const Space v112_3 = intersect(constant_2,v112_2);
        const Space v112_4 = (has_head(v112_3) ? constant_3 : Space{});
        const Space v112_5 = subtract(constant_1,v112_4);
        Space v112_7;
        if (!v112_5.empty()) {
          const Space v113_6 = routine_6(c, v111_11_head, v111_6, v111_11_tail, s1);
          v112_7 = compose(v112_5,v113_6);
        }
        const Space v112_8 = intersect(constant_2,v112_2);
        const Space v112_9 = (has_head(v112_8) ? constant_3 : Space{});
        Space v112_11;
        if (!v112_9.empty()) {
          const Space v114_10 = routine_7(c, v111_11_head, v111_6, v111_11_tail, s1);
          v112_11 = compose(v112_9,v114_10);
        }
        const Space v112_12 = unite(v112_7,v112_11);
        v111_11_result = unite(v111_11_result,v112_12);
      }
      const Space v111_11 = std::move(v111_11_result);
      v106_12 = compose(v106_10,v111_11);
    }
    const Space v106_13 = unite(v106_8,v106_12);
    v105_12_result = unite(v105_12_result,v106_13);
  }
  const Space v105_12 = std::move(v105_12_result);
  return v105_12;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v115_13_result;
  for (int v115_13_label = 1; v115_13_label <= 2; ++v115_13_label) {
    const Space v115_13_tail = child(s0,v115_13_label);
    if (v115_13_tail.empty()) continue;
    const Path v115_13_head{v115_13_label};
    const Space v116_2 = singleton(v115_13_head);
    const Space v116_3 = intersect(constant_2,v116_2);
    const Space v116_4 = (has_head(v116_3) ? constant_3 : Space{});
    const Space v116_5 = subtract(constant_1,v116_4);
    Space v116_8;
    if (!v116_5.empty()) {
      const Path v117_6 = concat_path(p0,v115_13_head);
      Space v117_7_result;
      for (int v117_7_label = 1; v117_7_label <= 2; ++v117_7_label) {
        const Space v117_7_tail = child(v115_13_tail,v117_7_label);
        if (v117_7_tail.empty()) continue;
        const Path v117_7_head{v117_7_label};
        const Space v118_2 = singleton(v117_7_head);
        const Space v118_3 = intersect(constant_2,v118_2);
        const Space v118_4 = (has_head(v118_3) ? constant_3 : Space{});
        const Space v118_5 = subtract(constant_1,v118_4);
        Space v118_8;
        if (!v118_5.empty()) {
          const Path v119_6 = concat_path(v117_6,v117_7_head);
          const Space v119_7 = routine_19(c, v119_6, p1, v117_7_tail, s1);
          v118_8 = compose(v118_5,v119_7);
        }
        const Space v118_9 = intersect(constant_2,v118_2);
        const Space v118_10 = (has_head(v118_9) ? constant_3 : Space{});
        Space v118_12;
        if (!v118_10.empty()) {
          const Path v120_6 = concat_path(v117_6,v117_7_head);
          const Space v120_11 = routine_20(c, v120_6, p1, v117_7_tail, s1);
          v118_12 = compose(v118_10,v120_11);
        }
        const Space v118_13 = unite(v118_8,v118_12);
        v117_7_result = unite(v117_7_result,v118_13);
      }
      const Space v117_7 = std::move(v117_7_result);
      v116_8 = compose(v116_5,v117_7);
    }
    const Space v116_9 = intersect(constant_2,v116_2);
    const Space v116_10 = (has_head(v116_9) ? constant_3 : Space{});
    Space v116_12;
    if (!v116_10.empty()) {
      const Path v121_6 = concat_path(p0,v115_13_head);
      Space v121_11_result;
      for (int v121_11_label = 1; v121_11_label <= 2; ++v121_11_label) {
        const Space v121_11_tail = child(v115_13_tail,v121_11_label);
        if (v121_11_tail.empty()) continue;
        const Path v121_11_head{v121_11_label};
        const Space v122_2 = singleton(v121_11_head);
        const Space v122_3 = intersect(constant_2,v122_2);
        const Space v122_4 = (has_head(v122_3) ? constant_3 : Space{});
        const Space v122_5 = subtract(constant_1,v122_4);
        Space v122_8;
        if (!v122_5.empty()) {
          const Path v123_6 = concat_path(v121_6,v121_11_head);
          const Space v123_7 = routine_19(c, v123_6, p1, v121_11_tail, s1);
          v122_8 = compose(v122_5,v123_7);
        }
        const Space v122_9 = intersect(constant_2,v122_2);
        const Space v122_10 = (has_head(v122_9) ? constant_3 : Space{});
        Space v122_12;
        if (!v122_10.empty()) {
          const Path v124_6 = concat_path(v121_6,v121_11_head);
          const Space v124_11 = routine_10(c, v124_6, p1, v121_11_tail, s1);
          v122_12 = compose(v122_10,v124_11);
        }
        const Space v122_13 = unite(v122_8,v122_12);
        v121_11_result = unite(v121_11_result,v122_13);
      }
      const Space v121_11 = std::move(v121_11_result);
      v116_12 = compose(v116_10,v121_11);
    }
    const Space v116_13 = unite(v116_8,v116_12);
    v115_13_result = unite(v115_13_result,v116_13);
  }
  const Space v115_13 = std::move(v115_13_result);
  return v115_13;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v125_8 = unwrap(s1,constant_0);
  const Space v125_9 = unwrap(v125_8,p0);
  Space v125_13_result;
  for (int v125_13_label = 1; v125_13_label <= 2; ++v125_13_label) {
    const Space v125_13_tail = child(s0,v125_13_label);
    if (v125_13_tail.empty()) continue;
    const Path v125_13_head{v125_13_label};
    const Space v126_2 = singleton(v125_13_head);
    const Space v126_3 = intersect(constant_2,v126_2);
    const Space v126_4 = (has_head(v126_3) ? constant_3 : Space{});
    const Space v126_5 = subtract(constant_1,v126_4);
    Space v126_8;
    if (!v126_5.empty()) {
      const Path v127_6 = concat_path(p0,v125_13_head);
      Space v127_7_result;
      for (int v127_7_label = 1; v127_7_label <= 2; ++v127_7_label) {
        const Space v127_7_tail = child(v125_13_tail,v127_7_label);
        if (v127_7_tail.empty()) continue;
        const Path v127_7_head{v127_7_label};
        const Space v128_2 = singleton(v127_7_head);
        const Space v128_3 = intersect(constant_2,v128_2);
        const Space v128_4 = (has_head(v128_3) ? constant_3 : Space{});
        const Space v128_5 = subtract(constant_1,v128_4);
        Space v128_8;
        if (!v128_5.empty()) {
          const Path v129_6 = concat_path(v127_6,v127_7_head);
          const Space v129_7 = routine_19(c, v129_6, p1, v127_7_tail, s1);
          v128_8 = compose(v128_5,v129_7);
        }
        const Space v128_9 = intersect(constant_2,v128_2);
        const Space v128_10 = (has_head(v128_9) ? constant_3 : Space{});
        Space v128_12;
        if (!v128_10.empty()) {
          const Path v130_6 = concat_path(v127_6,v127_7_head);
          const Space v130_11 = routine_20(c, v130_6, p1, v127_7_tail, s1);
          v128_12 = compose(v128_10,v130_11);
        }
        const Space v128_13 = unite(v128_8,v128_12);
        v127_7_result = unite(v127_7_result,v128_13);
      }
      const Space v127_7 = std::move(v127_7_result);
      v126_8 = compose(v126_5,v127_7);
    }
    const Space v126_9 = intersect(constant_2,v126_2);
    const Space v126_10 = (has_head(v126_9) ? constant_3 : Space{});
    const Space v126_11 = unwrap(v125_9,v125_13_head);
    const Space v126_12 = unwrap(v126_11,p1);
    const Space v126_13 = compose(v126_10,v126_12);
    const Path v131_6 = concat_path(p0,v125_13_head);
    const Space v126_14 = wrap(v126_13,v131_6);
    const Space v126_15 = wrap(v126_14,p1);
    const Space v126_16 = unite(v126_8,v126_15);
    v125_13_result = unite(v125_13_result,v126_16);
  }
  const Space v125_13 = std::move(v125_13_result);
  return v125_13;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v132_13_result;
  for (int v132_13_label = 1; v132_13_label <= 2; ++v132_13_label) {
    const Space v132_13_tail = child(s0,v132_13_label);
    if (v132_13_tail.empty()) continue;
    const Path v132_13_head{v132_13_label};
    const Space v133_2 = singleton(v132_13_head);
    const Space v133_3 = intersect(constant_2,v133_2);
    const Space v133_4 = (has_head(v133_3) ? constant_3 : Space{});
    const Space v133_5 = subtract(constant_1,v133_4);
    Space v133_8;
    if (!v133_5.empty()) {
      const Path v134_6 = concat_path(p0,v132_13_head);
      Space v134_7_result;
      for (int v134_7_label = 1; v134_7_label <= 2; ++v134_7_label) {
        const Space v134_7_tail = child(v132_13_tail,v134_7_label);
        if (v134_7_tail.empty()) continue;
        const Path v134_7_head{v134_7_label};
        const Space v135_2 = singleton(v134_7_head);
        const Space v135_3 = intersect(constant_2,v135_2);
        const Space v135_4 = (has_head(v135_3) ? constant_3 : Space{});
        const Space v135_5 = subtract(constant_1,v135_4);
        Space v135_8;
        if (!v135_5.empty()) {
          const Path v136_6 = concat_path(v134_6,v134_7_head);
          const Space v136_7 = routine_21(c, v136_6, p1, v134_7_tail, s1);
          v135_8 = compose(v135_5,v136_7);
        }
        const Space v135_9 = intersect(constant_2,v135_2);
        const Space v135_10 = (has_head(v135_9) ? constant_3 : Space{});
        Space v135_12;
        if (!v135_10.empty()) {
          const Path v137_6 = concat_path(v134_6,v134_7_head);
          const Space v137_11 = routine_22(c, v137_6, p1, v134_7_tail, s1);
          v135_12 = compose(v135_10,v137_11);
        }
        const Space v135_13 = unite(v135_8,v135_12);
        v134_7_result = unite(v134_7_result,v135_13);
      }
      const Space v134_7 = std::move(v134_7_result);
      v133_8 = compose(v133_5,v134_7);
    }
    const Space v133_9 = intersect(constant_2,v133_2);
    const Space v133_10 = (has_head(v133_9) ? constant_3 : Space{});
    Space v133_12;
    if (!v133_10.empty()) {
      const Path v138_6 = concat_path(p0,v132_13_head);
      Space v138_11_result;
      for (int v138_11_label = 1; v138_11_label <= 2; ++v138_11_label) {
        const Space v138_11_tail = child(v132_13_tail,v138_11_label);
        if (v138_11_tail.empty()) continue;
        const Path v138_11_head{v138_11_label};
        const Space v139_2 = singleton(v138_11_head);
        const Space v139_3 = intersect(constant_2,v139_2);
        const Space v139_4 = (has_head(v139_3) ? constant_3 : Space{});
        const Space v139_5 = subtract(constant_1,v139_4);
        Space v139_8;
        if (!v139_5.empty()) {
          const Path v140_6 = concat_path(v138_6,v138_11_head);
          const Space v140_7 = routine_21(c, v140_6, p1, v138_11_tail, s1);
          v139_8 = compose(v139_5,v140_7);
        }
        const Space v139_9 = intersect(constant_2,v139_2);
        const Space v139_10 = (has_head(v139_9) ? constant_3 : Space{});
        Space v139_12;
        if (!v139_10.empty()) {
          const Path v141_6 = concat_path(v138_6,v138_11_head);
          const Space v141_11 = routine_10(c, v141_6, p1, v138_11_tail, s1);
          v139_12 = compose(v139_10,v141_11);
        }
        const Space v139_13 = unite(v139_8,v139_12);
        v138_11_result = unite(v138_11_result,v139_13);
      }
      const Space v138_11 = std::move(v138_11_result);
      v133_12 = compose(v133_10,v138_11);
    }
    const Space v133_13 = unite(v133_8,v133_12);
    v132_13_result = unite(v132_13_result,v133_13);
  }
  const Space v132_13 = std::move(v132_13_result);
  return v132_13;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v142_8 = unwrap(s1,constant_0);
  const Space v142_9 = unwrap(v142_8,p0);
  Space v142_13_result;
  for (int v142_13_label = 1; v142_13_label <= 2; ++v142_13_label) {
    const Space v142_13_tail = child(s0,v142_13_label);
    if (v142_13_tail.empty()) continue;
    const Path v142_13_head{v142_13_label};
    const Space v143_2 = singleton(v142_13_head);
    const Space v143_3 = intersect(constant_2,v143_2);
    const Space v143_4 = (has_head(v143_3) ? constant_3 : Space{});
    const Space v143_5 = subtract(constant_1,v143_4);
    Space v143_8;
    if (!v143_5.empty()) {
      const Path v144_6 = concat_path(p0,v142_13_head);
      Space v144_7_result;
      for (int v144_7_label = 1; v144_7_label <= 2; ++v144_7_label) {
        const Space v144_7_tail = child(v142_13_tail,v144_7_label);
        if (v144_7_tail.empty()) continue;
        const Path v144_7_head{v144_7_label};
        const Space v145_2 = singleton(v144_7_head);
        const Space v145_3 = intersect(constant_2,v145_2);
        const Space v145_4 = (has_head(v145_3) ? constant_3 : Space{});
        const Space v145_5 = subtract(constant_1,v145_4);
        Space v145_8;
        if (!v145_5.empty()) {
          const Path v146_6 = concat_path(v144_6,v144_7_head);
          const Space v146_7 = routine_21(c, v146_6, p1, v144_7_tail, s1);
          v145_8 = compose(v145_5,v146_7);
        }
        const Space v145_9 = intersect(constant_2,v145_2);
        const Space v145_10 = (has_head(v145_9) ? constant_3 : Space{});
        Space v145_12;
        if (!v145_10.empty()) {
          const Path v147_6 = concat_path(v144_6,v144_7_head);
          const Space v147_11 = routine_22(c, v147_6, p1, v144_7_tail, s1);
          v145_12 = compose(v145_10,v147_11);
        }
        const Space v145_13 = unite(v145_8,v145_12);
        v144_7_result = unite(v144_7_result,v145_13);
      }
      const Space v144_7 = std::move(v144_7_result);
      v143_8 = compose(v143_5,v144_7);
    }
    const Space v143_9 = intersect(constant_2,v143_2);
    const Space v143_10 = (has_head(v143_9) ? constant_3 : Space{});
    const Space v143_11 = unwrap(v142_9,v142_13_head);
    const Space v143_12 = unwrap(v143_11,p1);
    const Space v143_13 = compose(v143_10,v143_12);
    const Path v148_6 = concat_path(p0,v142_13_head);
    const Space v143_14 = wrap(v143_13,v148_6);
    const Space v143_15 = wrap(v143_14,p1);
    const Space v143_16 = unite(v143_8,v143_15);
    v142_13_result = unite(v142_13_result,v143_16);
  }
  const Space v142_13 = std::move(v142_13_result);
  return v142_13;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v149_12_result;
  for (int v149_12_label = 1; v149_12_label <= 2; ++v149_12_label) {
    const Space v149_12_tail = child(s0,v149_12_label);
    if (v149_12_tail.empty()) continue;
    const Path v149_12_head{v149_12_label};
    const Space v150_2 = singleton(v149_12_head);
    const Space v150_3 = intersect(constant_2,v150_2);
    const Space v150_4 = (has_head(v150_3) ? constant_3 : Space{});
    const Space v150_5 = subtract(constant_1,v150_4);
    Space v150_8;
    if (!v150_5.empty()) {
      const Path v151_6 = concat_path(p0,v149_12_head);
      Space v151_7_result;
      for (int v151_7_label = 1; v151_7_label <= 2; ++v151_7_label) {
        const Space v151_7_tail = child(v149_12_tail,v151_7_label);
        if (v151_7_tail.empty()) continue;
        const Path v151_7_head{v151_7_label};
        const Space v152_2 = singleton(v151_7_head);
        const Space v152_3 = intersect(constant_2,v152_2);
        const Space v152_4 = (has_head(v152_3) ? constant_3 : Space{});
        const Space v152_5 = subtract(constant_1,v152_4);
        Space v152_8;
        if (!v152_5.empty()) {
          const Path v153_6 = concat_path(v151_6,v151_7_head);
          const Space v153_7 = routine_23(c, v153_6, v151_7_tail, s1);
          v152_8 = compose(v152_5,v153_7);
        }
        const Space v152_9 = intersect(constant_2,v152_2);
        const Space v152_10 = (has_head(v152_9) ? constant_3 : Space{});
        Space v152_12;
        if (!v152_10.empty()) {
          const Path v154_6 = concat_path(v151_6,v151_7_head);
          const Space v154_11 = routine_24(c, v154_6, v151_7_tail, s1);
          v152_12 = compose(v152_10,v154_11);
        }
        const Space v152_13 = unite(v152_8,v152_12);
        v151_7_result = unite(v151_7_result,v152_13);
      }
      const Space v151_7 = std::move(v151_7_result);
      v150_8 = compose(v150_5,v151_7);
    }
    const Space v150_9 = intersect(constant_2,v150_2);
    const Space v150_10 = (has_head(v150_9) ? constant_3 : Space{});
    Space v150_12;
    if (!v150_10.empty()) {
      const Path v155_6 = concat_path(p0,v149_12_head);
      Space v155_11_result;
      for (int v155_11_label = 1; v155_11_label <= 2; ++v155_11_label) {
        const Space v155_11_tail = child(v149_12_tail,v155_11_label);
        if (v155_11_tail.empty()) continue;
        const Path v155_11_head{v155_11_label};
        const Space v156_2 = singleton(v155_11_head);
        const Space v156_3 = intersect(constant_2,v156_2);
        const Space v156_4 = (has_head(v156_3) ? constant_3 : Space{});
        const Space v156_5 = subtract(constant_1,v156_4);
        Space v156_8;
        if (!v156_5.empty()) {
          const Path v157_6 = concat_path(v155_6,v155_11_head);
          const Space v157_7 = routine_23(c, v157_6, v155_11_tail, s1);
          v156_8 = compose(v156_5,v157_7);
        }
        const Space v156_9 = intersect(constant_2,v156_2);
        const Space v156_10 = (has_head(v156_9) ? constant_3 : Space{});
        Space v156_12;
        if (!v156_10.empty()) {
          const Path v158_6 = concat_path(v155_6,v155_11_head);
          const Space v158_11 = routine_3(c, v158_6, v155_11_tail, s1);
          v156_12 = compose(v156_10,v158_11);
        }
        const Space v156_13 = unite(v156_8,v156_12);
        v155_11_result = unite(v155_11_result,v156_13);
      }
      const Space v155_11 = std::move(v155_11_result);
      v150_12 = compose(v150_10,v155_11);
    }
    const Space v150_13 = unite(v150_8,v150_12);
    v149_12_result = unite(v149_12_result,v150_13);
  }
  const Space v149_12 = std::move(v149_12_result);
  return v149_12;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v159_12_result;
  for (int v159_12_label = 1; v159_12_label <= 2; ++v159_12_label) {
    const Space v159_12_tail = child(s0,v159_12_label);
    if (v159_12_tail.empty()) continue;
    const Path v159_12_head{v159_12_label};
    const Space v160_2 = singleton(v159_12_head);
    const Space v160_3 = intersect(constant_2,v160_2);
    const Space v160_4 = (has_head(v160_3) ? constant_3 : Space{});
    const Space v160_5 = subtract(constant_1,v160_4);
    Space v160_8;
    if (!v160_5.empty()) {
      const Path v161_6 = concat_path(p0,v159_12_head);
      Space v161_7_result;
      for (int v161_7_label = 1; v161_7_label <= 2; ++v161_7_label) {
        const Space v161_7_tail = child(v159_12_tail,v161_7_label);
        if (v161_7_tail.empty()) continue;
        const Path v161_7_head{v161_7_label};
        const Space v162_2 = singleton(v161_7_head);
        const Space v162_3 = intersect(constant_2,v162_2);
        const Space v162_4 = (has_head(v162_3) ? constant_3 : Space{});
        const Space v162_5 = subtract(constant_1,v162_4);
        Space v162_8;
        if (!v162_5.empty()) {
          const Path v163_6 = concat_path(v161_6,v161_7_head);
          const Space v163_7 = routine_23(c, v163_6, v161_7_tail, s1);
          v162_8 = compose(v162_5,v163_7);
        }
        const Space v162_9 = intersect(constant_2,v162_2);
        const Space v162_10 = (has_head(v162_9) ? constant_3 : Space{});
        Space v162_12;
        if (!v162_10.empty()) {
          const Path v164_6 = concat_path(v161_6,v161_7_head);
          const Space v164_11 = routine_24(c, v164_6, v161_7_tail, s1);
          v162_12 = compose(v162_10,v164_11);
        }
        const Space v162_13 = unite(v162_8,v162_12);
        v161_7_result = unite(v161_7_result,v162_13);
      }
      const Space v161_7 = std::move(v161_7_result);
      v160_8 = compose(v160_5,v161_7);
    }
    const Space v160_9 = intersect(constant_2,v160_2);
    const Space v160_10 = (has_head(v160_9) ? constant_3 : Space{});
    Space v160_12;
    if (!v160_10.empty()) {
      const Path v165_6 = concat_path(p0,v159_12_head);
      Space v165_11_result;
      for (int v165_11_label = 1; v165_11_label <= 2; ++v165_11_label) {
        const Space v165_11_tail = child(v159_12_tail,v165_11_label);
        if (v165_11_tail.empty()) continue;
        const Path v165_11_head{v165_11_label};
        const Space v166_2 = singleton(v165_11_head);
        const Space v166_3 = intersect(constant_2,v166_2);
        const Space v166_4 = (has_head(v166_3) ? constant_3 : Space{});
        const Space v166_5 = subtract(constant_1,v166_4);
        Space v166_7;
        if (!v166_5.empty()) {
          const Space v167_6 = routine_6(c, v165_11_head, v165_6, v165_11_tail, s1);
          v166_7 = compose(v166_5,v167_6);
        }
        const Space v166_8 = intersect(constant_2,v166_2);
        const Space v166_9 = (has_head(v166_8) ? constant_3 : Space{});
        Space v166_11;
        if (!v166_9.empty()) {
          const Space v168_10 = routine_7(c, v165_11_head, v165_6, v165_11_tail, s1);
          v166_11 = compose(v166_9,v168_10);
        }
        const Space v166_12 = unite(v166_7,v166_11);
        v165_11_result = unite(v165_11_result,v166_12);
      }
      const Space v165_11 = std::move(v165_11_result);
      v160_12 = compose(v160_10,v165_11);
    }
    const Space v160_13 = unite(v160_8,v160_12);
    v159_12_result = unite(v159_12_result,v160_13);
  }
  const Space v159_12 = std::move(v159_12_result);
  return v159_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v169_13_result;
  for (int v169_13_label = 1; v169_13_label <= 2; ++v169_13_label) {
    const Space v169_13_tail = child(s0,v169_13_label);
    if (v169_13_tail.empty()) continue;
    const Path v169_13_head{v169_13_label};
    const Space v170_2 = singleton(v169_13_head);
    const Space v170_3 = intersect(constant_2,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_3 : Space{});
    const Space v170_5 = subtract(constant_1,v170_4);
    Space v170_8;
    if (!v170_5.empty()) {
      const Path v171_6 = concat_path(p0,v169_13_head);
      Space v171_7_result;
      for (int v171_7_label = 1; v171_7_label <= 2; ++v171_7_label) {
        const Space v171_7_tail = child(v169_13_tail,v171_7_label);
        if (v171_7_tail.empty()) continue;
        const Path v171_7_head{v171_7_label};
        const Space v172_2 = singleton(v171_7_head);
        const Space v172_3 = intersect(constant_2,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_3 : Space{});
        const Space v172_5 = subtract(constant_1,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v171_6,v171_7_head);
          const Space v173_7 = routine_25(c, v173_6, p1, v171_7_tail, s1);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_2,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_3 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v171_6,v171_7_head);
          const Space v174_11 = routine_26(c, v174_6, p1, v171_7_tail, s1);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_7_result = unite(v171_7_result,v172_13);
      }
      const Space v171_7 = std::move(v171_7_result);
      v170_8 = compose(v170_5,v171_7);
    }
    const Space v170_9 = intersect(constant_2,v170_2);
    const Space v170_10 = (has_head(v170_9) ? constant_3 : Space{});
    Space v170_12;
    if (!v170_10.empty()) {
      const Path v175_6 = concat_path(p0,v169_13_head);
      Space v175_11_result;
      for (int v175_11_label = 1; v175_11_label <= 2; ++v175_11_label) {
        const Space v175_11_tail = child(v169_13_tail,v175_11_label);
        if (v175_11_tail.empty()) continue;
        const Path v175_11_head{v175_11_label};
        const Space v176_2 = singleton(v175_11_head);
        const Space v176_3 = intersect(constant_2,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_3 : Space{});
        const Space v176_5 = subtract(constant_1,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_11_head);
          const Space v177_7 = routine_25(c, v177_6, p1, v175_11_tail, s1);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_2,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_3 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_11_head);
          const Space v178_11 = routine_10(c, v178_6, p1, v175_11_tail, s1);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_11_result = unite(v175_11_result,v176_13);
      }
      const Space v175_11 = std::move(v175_11_result);
      v170_12 = compose(v170_10,v175_11);
    }
    const Space v170_13 = unite(v170_8,v170_12);
    v169_13_result = unite(v169_13_result,v170_13);
  }
  const Space v169_13 = std::move(v169_13_result);
  return v169_13;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v179_8 = unwrap(s1,constant_0);
  const Space v179_9 = unwrap(v179_8,p0);
  Space v179_13_result;
  for (int v179_13_label = 1; v179_13_label <= 2; ++v179_13_label) {
    const Space v179_13_tail = child(s0,v179_13_label);
    if (v179_13_tail.empty()) continue;
    const Path v179_13_head{v179_13_label};
    const Space v180_2 = singleton(v179_13_head);
    const Space v180_3 = intersect(constant_2,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_3 : Space{});
    const Space v180_5 = subtract(constant_1,v180_4);
    Space v180_8;
    if (!v180_5.empty()) {
      const Path v181_6 = concat_path(p0,v179_13_head);
      Space v181_7_result;
      for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
        const Space v181_7_tail = child(v179_13_tail,v181_7_label);
        if (v181_7_tail.empty()) continue;
        const Path v181_7_head{v181_7_label};
        const Space v182_2 = singleton(v181_7_head);
        const Space v182_3 = intersect(constant_2,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_3 : Space{});
        const Space v182_5 = subtract(constant_1,v182_4);
        Space v182_8;
        if (!v182_5.empty()) {
          const Path v183_6 = concat_path(v181_6,v181_7_head);
          const Space v183_7 = routine_25(c, v183_6, p1, v181_7_tail, s1);
          v182_8 = compose(v182_5,v183_7);
        }
        const Space v182_9 = intersect(constant_2,v182_2);
        const Space v182_10 = (has_head(v182_9) ? constant_3 : Space{});
        Space v182_12;
        if (!v182_10.empty()) {
          const Path v184_6 = concat_path(v181_6,v181_7_head);
          const Space v184_11 = routine_26(c, v184_6, p1, v181_7_tail, s1);
          v182_12 = compose(v182_10,v184_11);
        }
        const Space v182_13 = unite(v182_8,v182_12);
        v181_7_result = unite(v181_7_result,v182_13);
      }
      const Space v181_7 = std::move(v181_7_result);
      v180_8 = compose(v180_5,v181_7);
    }
    const Space v180_9 = intersect(constant_2,v180_2);
    const Space v180_10 = (has_head(v180_9) ? constant_3 : Space{});
    const Space v180_11 = unwrap(v179_9,v179_13_head);
    const Space v180_12 = unwrap(v180_11,p1);
    const Space v180_13 = compose(v180_10,v180_12);
    const Path v185_6 = concat_path(p0,v179_13_head);
    const Space v180_14 = wrap(v180_13,v185_6);
    const Space v180_15 = wrap(v180_14,p1);
    const Space v180_16 = unite(v180_8,v180_15);
    v179_13_result = unite(v179_13_result,v180_16);
  }
  const Space v179_13 = std::move(v179_13_result);
  return v179_13;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v186_13_result;
  for (int v186_13_label = 1; v186_13_label <= 2; ++v186_13_label) {
    const Space v186_13_tail = child(s0,v186_13_label);
    if (v186_13_tail.empty()) continue;
    const Path v186_13_head{v186_13_label};
    const Space v187_2 = singleton(v186_13_head);
    const Space v187_3 = intersect(constant_2,v187_2);
    const Space v187_4 = (has_head(v187_3) ? constant_3 : Space{});
    const Space v187_5 = subtract(constant_1,v187_4);
    Space v187_8;
    if (!v187_5.empty()) {
      const Path v188_6 = concat_path(p0,v186_13_head);
      Space v188_7_result;
      for (int v188_7_label = 1; v188_7_label <= 2; ++v188_7_label) {
        const Space v188_7_tail = child(v186_13_tail,v188_7_label);
        if (v188_7_tail.empty()) continue;
        const Path v188_7_head{v188_7_label};
        const Space v189_2 = singleton(v188_7_head);
        const Space v189_3 = intersect(constant_2,v189_2);
        const Space v189_4 = (has_head(v189_3) ? constant_3 : Space{});
        const Space v189_5 = subtract(constant_1,v189_4);
        Space v189_8;
        if (!v189_5.empty()) {
          const Path v190_6 = concat_path(v188_6,v188_7_head);
          const Space v190_7 = routine_27(c, v190_6, p1, v188_7_tail, s1);
          v189_8 = compose(v189_5,v190_7);
        }
        const Space v189_9 = intersect(constant_2,v189_2);
        const Space v189_10 = (has_head(v189_9) ? constant_3 : Space{});
        Space v189_12;
        if (!v189_10.empty()) {
          const Path v191_6 = concat_path(v188_6,v188_7_head);
          const Space v191_11 = routine_28(c, v191_6, p1, v188_7_tail, s1);
          v189_12 = compose(v189_10,v191_11);
        }
        const Space v189_13 = unite(v189_8,v189_12);
        v188_7_result = unite(v188_7_result,v189_13);
      }
      const Space v188_7 = std::move(v188_7_result);
      v187_8 = compose(v187_5,v188_7);
    }
    const Space v187_9 = intersect(constant_2,v187_2);
    const Space v187_10 = (has_head(v187_9) ? constant_3 : Space{});
    Space v187_12;
    if (!v187_10.empty()) {
      const Path v192_6 = concat_path(p0,v186_13_head);
      Space v192_11_result;
      for (int v192_11_label = 1; v192_11_label <= 2; ++v192_11_label) {
        const Space v192_11_tail = child(v186_13_tail,v192_11_label);
        if (v192_11_tail.empty()) continue;
        const Path v192_11_head{v192_11_label};
        const Space v193_2 = singleton(v192_11_head);
        const Space v193_3 = intersect(constant_2,v193_2);
        const Space v193_4 = (has_head(v193_3) ? constant_3 : Space{});
        const Space v193_5 = subtract(constant_1,v193_4);
        Space v193_8;
        if (!v193_5.empty()) {
          const Path v194_6 = concat_path(v192_6,v192_11_head);
          const Space v194_7 = routine_27(c, v194_6, p1, v192_11_tail, s1);
          v193_8 = compose(v193_5,v194_7);
        }
        const Space v193_9 = intersect(constant_2,v193_2);
        const Space v193_10 = (has_head(v193_9) ? constant_3 : Space{});
        Space v193_12;
        if (!v193_10.empty()) {
          const Path v195_6 = concat_path(v192_6,v192_11_head);
          const Space v195_11 = routine_10(c, v195_6, p1, v192_11_tail, s1);
          v193_12 = compose(v193_10,v195_11);
        }
        const Space v193_13 = unite(v193_8,v193_12);
        v192_11_result = unite(v192_11_result,v193_13);
      }
      const Space v192_11 = std::move(v192_11_result);
      v187_12 = compose(v187_10,v192_11);
    }
    const Space v187_13 = unite(v187_8,v187_12);
    v186_13_result = unite(v186_13_result,v187_13);
  }
  const Space v186_13 = std::move(v186_13_result);
  return v186_13;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v196_8 = unwrap(s1,constant_0);
  const Space v196_9 = unwrap(v196_8,p0);
  Space v196_13_result;
  for (int v196_13_label = 1; v196_13_label <= 2; ++v196_13_label) {
    const Space v196_13_tail = child(s0,v196_13_label);
    if (v196_13_tail.empty()) continue;
    const Path v196_13_head{v196_13_label};
    const Space v197_2 = singleton(v196_13_head);
    const Space v197_3 = intersect(constant_2,v197_2);
    const Space v197_4 = (has_head(v197_3) ? constant_3 : Space{});
    const Space v197_5 = subtract(constant_1,v197_4);
    Space v197_8;
    if (!v197_5.empty()) {
      const Path v198_6 = concat_path(p0,v196_13_head);
      Space v198_7_result;
      for (int v198_7_label = 1; v198_7_label <= 2; ++v198_7_label) {
        const Space v198_7_tail = child(v196_13_tail,v198_7_label);
        if (v198_7_tail.empty()) continue;
        const Path v198_7_head{v198_7_label};
        const Space v199_2 = singleton(v198_7_head);
        const Space v199_3 = intersect(constant_2,v199_2);
        const Space v199_4 = (has_head(v199_3) ? constant_3 : Space{});
        const Space v199_5 = subtract(constant_1,v199_4);
        Space v199_8;
        if (!v199_5.empty()) {
          const Path v200_6 = concat_path(v198_6,v198_7_head);
          const Space v200_7 = routine_27(c, v200_6, p1, v198_7_tail, s1);
          v199_8 = compose(v199_5,v200_7);
        }
        const Space v199_9 = intersect(constant_2,v199_2);
        const Space v199_10 = (has_head(v199_9) ? constant_3 : Space{});
        Space v199_12;
        if (!v199_10.empty()) {
          const Path v201_6 = concat_path(v198_6,v198_7_head);
          const Space v201_11 = routine_28(c, v201_6, p1, v198_7_tail, s1);
          v199_12 = compose(v199_10,v201_11);
        }
        const Space v199_13 = unite(v199_8,v199_12);
        v198_7_result = unite(v198_7_result,v199_13);
      }
      const Space v198_7 = std::move(v198_7_result);
      v197_8 = compose(v197_5,v198_7);
    }
    const Space v197_9 = intersect(constant_2,v197_2);
    const Space v197_10 = (has_head(v197_9) ? constant_3 : Space{});
    const Space v197_11 = unwrap(v196_9,v196_13_head);
    const Space v197_12 = unwrap(v197_11,p1);
    const Space v197_13 = compose(v197_10,v197_12);
    const Path v202_6 = concat_path(p0,v196_13_head);
    const Space v197_14 = wrap(v197_13,v202_6);
    const Space v197_15 = wrap(v197_14,p1);
    const Space v197_16 = unite(v197_8,v197_15);
    v196_13_result = unite(v196_13_result,v197_16);
  }
  const Space v196_13 = std::move(v196_13_result);
  return v196_13;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v203_3_result;
  for (int v203_3_label = 1; v203_3_label <= 2; ++v203_3_label) {
    const Space v203_3_tail = child(s0,v203_3_label);
    if (v203_3_tail.empty()) continue;
    const Path v203_3_head{v203_3_label};
    const Space v204_2 = Space{};
    v203_3_result = unite(v203_3_result,v204_2);
  }
  const Space v203_3 = std::move(v203_3_result);
  return v203_3;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v205_7_result;
  for (int v205_7_label = 1; v205_7_label <= 2; ++v205_7_label) {
    const Space v205_7_tail = child(s0,v205_7_label);
    if (v205_7_tail.empty()) continue;
    const Path v205_7_head{v205_7_label};
    const Space v206_2 = singleton(v205_7_head);
    const Space v206_3 = intersect(constant_2,v206_2);
    const Space v206_4 = (has_head(v206_3) ? constant_3 : Space{});
    Space v206_7;
    if (!v206_4.empty()) {
      const Path v207_5 = concat_path(p0,v205_7_head);
      Space v207_6_result;
      for (int v207_6_label = 1; v207_6_label <= 2; ++v207_6_label) {
        const Space v207_6_tail = child(v205_7_tail,v207_6_label);
        if (v207_6_tail.empty()) continue;
        const Path v207_6_head{v207_6_label};
        const Space v208_2 = singleton(v207_6_head);
        const Space v208_3 = intersect(constant_2,v208_2);
        const Space v208_4 = (has_head(v208_3) ? constant_3 : Space{});
        const Space v208_5 = subtract(constant_1,v208_4);
        Space v208_7;
        if (!v208_5.empty()) {
          const Space v209_6 = routine_6(c, v207_6_head, v207_5, v207_6_tail, s1);
          v208_7 = compose(v208_5,v209_6);
        }
        const Space v208_8 = intersect(constant_2,v208_2);
        const Space v208_9 = (has_head(v208_8) ? constant_3 : Space{});
        Space v208_11;
        if (!v208_9.empty()) {
          const Space v210_10 = routine_7(c, v207_6_head, v207_5, v207_6_tail, s1);
          v208_11 = compose(v208_9,v210_10);
        }
        const Space v208_12 = unite(v208_7,v208_11);
        v207_6_result = unite(v207_6_result,v208_12);
      }
      const Space v207_6 = std::move(v207_6_result);
      v206_7 = compose(v206_4,v207_6);
    }
    v205_7_result = unite(v205_7_result,v206_7);
  }
  const Space v205_7 = std::move(v205_7_result);
  return v205_7;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v211_13_result;
  for (int v211_13_label = 1; v211_13_label <= 2; ++v211_13_label) {
    const Space v211_13_tail = child(s0,v211_13_label);
    if (v211_13_tail.empty()) continue;
    const Path v211_13_head{v211_13_label};
    const Space v212_2 = singleton(v211_13_head);
    const Space v212_3 = intersect(constant_2,v212_2);
    const Space v212_4 = (has_head(v212_3) ? constant_3 : Space{});
    const Space v212_5 = subtract(constant_1,v212_4);
    Space v212_8;
    if (!v212_5.empty()) {
      const Path v213_6 = concat_path(p0,v211_13_head);
      Space v213_7_result;
      for (int v213_7_label = 1; v213_7_label <= 2; ++v213_7_label) {
        const Space v213_7_tail = child(v211_13_tail,v213_7_label);
        if (v213_7_tail.empty()) continue;
        const Path v213_7_head{v213_7_label};
        const Space v214_2 = singleton(v213_7_head);
        const Space v214_3 = intersect(constant_2,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_3 : Space{});
        const Space v214_5 = subtract(constant_1,v214_4);
        Space v214_8;
        if (!v214_5.empty()) {
          const Path v215_6 = concat_path(v213_6,v213_7_head);
          const Space v215_7 = routine_29(c, v215_6, p1, v213_7_tail, s1);
          v214_8 = compose(v214_5,v215_7);
        }
        const Space v214_9 = intersect(constant_2,v214_2);
        const Space v214_10 = (has_head(v214_9) ? constant_3 : Space{});
        Space v214_12;
        if (!v214_10.empty()) {
          const Path v216_6 = concat_path(v213_6,v213_7_head);
          const Space v216_11 = routine_30(c, v216_6, p1, v213_7_tail, s1);
          v214_12 = compose(v214_10,v216_11);
        }
        const Space v214_13 = unite(v214_8,v214_12);
        v213_7_result = unite(v213_7_result,v214_13);
      }
      const Space v213_7 = std::move(v213_7_result);
      v212_8 = compose(v212_5,v213_7);
    }
    const Space v212_9 = intersect(constant_2,v212_2);
    const Space v212_10 = (has_head(v212_9) ? constant_3 : Space{});
    Space v212_12;
    if (!v212_10.empty()) {
      const Path v217_6 = concat_path(p0,v211_13_head);
      Space v217_11_result;
      for (int v217_11_label = 1; v217_11_label <= 2; ++v217_11_label) {
        const Space v217_11_tail = child(v211_13_tail,v217_11_label);
        if (v217_11_tail.empty()) continue;
        const Path v217_11_head{v217_11_label};
        const Space v218_2 = singleton(v217_11_head);
        const Space v218_3 = intersect(constant_2,v218_2);
        const Space v218_4 = (has_head(v218_3) ? constant_3 : Space{});
        const Space v218_5 = subtract(constant_1,v218_4);
        Space v218_8;
        if (!v218_5.empty()) {
          const Path v219_6 = concat_path(v217_6,v217_11_head);
          const Space v219_7 = routine_29(c, v219_6, p1, v217_11_tail, s1);
          v218_8 = compose(v218_5,v219_7);
        }
        const Space v218_9 = intersect(constant_2,v218_2);
        const Space v218_10 = (has_head(v218_9) ? constant_3 : Space{});
        Space v218_12;
        if (!v218_10.empty()) {
          const Path v220_6 = concat_path(v217_6,v217_11_head);
          const Space v220_11 = routine_10(c, v220_6, p1, v217_11_tail, s1);
          v218_12 = compose(v218_10,v220_11);
        }
        const Space v218_13 = unite(v218_8,v218_12);
        v217_11_result = unite(v217_11_result,v218_13);
      }
      const Space v217_11 = std::move(v217_11_result);
      v212_12 = compose(v212_10,v217_11);
    }
    const Space v212_13 = unite(v212_8,v212_12);
    v211_13_result = unite(v211_13_result,v212_13);
  }
  const Space v211_13 = std::move(v211_13_result);
  return v211_13;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v221_8 = unwrap(s1,constant_0);
  const Space v221_9 = unwrap(v221_8,p0);
  Space v221_13_result;
  for (int v221_13_label = 1; v221_13_label <= 2; ++v221_13_label) {
    const Space v221_13_tail = child(s0,v221_13_label);
    if (v221_13_tail.empty()) continue;
    const Path v221_13_head{v221_13_label};
    const Space v222_2 = singleton(v221_13_head);
    const Space v222_3 = intersect(constant_2,v222_2);
    const Space v222_4 = (has_head(v222_3) ? constant_3 : Space{});
    const Space v222_5 = subtract(constant_1,v222_4);
    Space v222_8;
    if (!v222_5.empty()) {
      const Path v223_6 = concat_path(p0,v221_13_head);
      Space v223_7_result;
      for (int v223_7_label = 1; v223_7_label <= 2; ++v223_7_label) {
        const Space v223_7_tail = child(v221_13_tail,v223_7_label);
        if (v223_7_tail.empty()) continue;
        const Path v223_7_head{v223_7_label};
        const Space v224_2 = singleton(v223_7_head);
        const Space v224_3 = intersect(constant_2,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_3 : Space{});
        const Space v224_5 = subtract(constant_1,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_7_head);
          const Space v225_7 = routine_29(c, v225_6, p1, v223_7_tail, s1);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_2,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_3 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_7_head);
          const Space v226_11 = routine_30(c, v226_6, p1, v223_7_tail, s1);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_7_result = unite(v223_7_result,v224_13);
      }
      const Space v223_7 = std::move(v223_7_result);
      v222_8 = compose(v222_5,v223_7);
    }
    const Space v222_9 = intersect(constant_2,v222_2);
    const Space v222_10 = (has_head(v222_9) ? constant_3 : Space{});
    const Space v222_11 = unwrap(v221_9,v221_13_head);
    const Space v222_12 = unwrap(v222_11,p1);
    const Space v222_13 = compose(v222_10,v222_12);
    const Path v227_6 = concat_path(p0,v221_13_head);
    const Space v222_14 = wrap(v222_13,v227_6);
    const Space v222_15 = wrap(v222_14,p1);
    const Space v222_16 = unite(v222_8,v222_15);
    v221_13_result = unite(v221_13_result,v222_16);
  }
  const Space v221_13 = std::move(v221_13_result);
  return v221_13;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v228_13_result;
  for (int v228_13_label = 1; v228_13_label <= 2; ++v228_13_label) {
    const Space v228_13_tail = child(s0,v228_13_label);
    if (v228_13_tail.empty()) continue;
    const Path v228_13_head{v228_13_label};
    const Space v229_2 = singleton(v228_13_head);
    const Space v229_3 = intersect(constant_2,v229_2);
    const Space v229_4 = (has_head(v229_3) ? constant_3 : Space{});
    const Space v229_5 = subtract(constant_1,v229_4);
    Space v229_8;
    if (!v229_5.empty()) {
      const Path v230_6 = concat_path(p0,v228_13_head);
      Space v230_7_result;
      for (int v230_7_label = 1; v230_7_label <= 2; ++v230_7_label) {
        const Space v230_7_tail = child(v228_13_tail,v230_7_label);
        if (v230_7_tail.empty()) continue;
        const Path v230_7_head{v230_7_label};
        const Space v231_2 = singleton(v230_7_head);
        const Space v231_3 = intersect(constant_2,v231_2);
        const Space v231_4 = (has_head(v231_3) ? constant_3 : Space{});
        const Space v231_5 = subtract(constant_1,v231_4);
        Space v231_8;
        if (!v231_5.empty()) {
          const Path v232_6 = concat_path(v230_6,v230_7_head);
          const Space v232_7 = routine_31(c, v232_6, p1, v230_7_tail, s1);
          v231_8 = compose(v231_5,v232_7);
        }
        const Space v231_9 = intersect(constant_2,v231_2);
        const Space v231_10 = (has_head(v231_9) ? constant_3 : Space{});
        Space v231_12;
        if (!v231_10.empty()) {
          const Path v233_6 = concat_path(v230_6,v230_7_head);
          const Space v233_11 = routine_32(c, v233_6, p1, v230_7_tail, s1);
          v231_12 = compose(v231_10,v233_11);
        }
        const Space v231_13 = unite(v231_8,v231_12);
        v230_7_result = unite(v230_7_result,v231_13);
      }
      const Space v230_7 = std::move(v230_7_result);
      v229_8 = compose(v229_5,v230_7);
    }
    const Space v229_9 = intersect(constant_2,v229_2);
    const Space v229_10 = (has_head(v229_9) ? constant_3 : Space{});
    Space v229_12;
    if (!v229_10.empty()) {
      const Path v234_6 = concat_path(p0,v228_13_head);
      Space v234_11_result;
      for (int v234_11_label = 1; v234_11_label <= 2; ++v234_11_label) {
        const Space v234_11_tail = child(v228_13_tail,v234_11_label);
        if (v234_11_tail.empty()) continue;
        const Path v234_11_head{v234_11_label};
        const Space v235_2 = singleton(v234_11_head);
        const Space v235_3 = intersect(constant_2,v235_2);
        const Space v235_4 = (has_head(v235_3) ? constant_3 : Space{});
        const Space v235_5 = subtract(constant_1,v235_4);
        Space v235_8;
        if (!v235_5.empty()) {
          const Path v236_6 = concat_path(v234_6,v234_11_head);
          const Space v236_7 = routine_31(c, v236_6, p1, v234_11_tail, s1);
          v235_8 = compose(v235_5,v236_7);
        }
        const Space v235_9 = intersect(constant_2,v235_2);
        const Space v235_10 = (has_head(v235_9) ? constant_3 : Space{});
        Space v235_12;
        if (!v235_10.empty()) {
          const Path v237_6 = concat_path(v234_6,v234_11_head);
          const Space v237_11 = routine_10(c, v237_6, p1, v234_11_tail, s1);
          v235_12 = compose(v235_10,v237_11);
        }
        const Space v235_13 = unite(v235_8,v235_12);
        v234_11_result = unite(v234_11_result,v235_13);
      }
      const Space v234_11 = std::move(v234_11_result);
      v229_12 = compose(v229_10,v234_11);
    }
    const Space v229_13 = unite(v229_8,v229_12);
    v228_13_result = unite(v228_13_result,v229_13);
  }
  const Space v228_13 = std::move(v228_13_result);
  return v228_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v238_8 = unwrap(s1,constant_0);
  const Space v238_9 = unwrap(v238_8,p0);
  Space v238_13_result;
  for (int v238_13_label = 1; v238_13_label <= 2; ++v238_13_label) {
    const Space v238_13_tail = child(s0,v238_13_label);
    if (v238_13_tail.empty()) continue;
    const Path v238_13_head{v238_13_label};
    const Space v239_2 = singleton(v238_13_head);
    const Space v239_3 = intersect(constant_2,v239_2);
    const Space v239_4 = (has_head(v239_3) ? constant_3 : Space{});
    const Space v239_5 = subtract(constant_1,v239_4);
    Space v239_8;
    if (!v239_5.empty()) {
      const Path v240_6 = concat_path(p0,v238_13_head);
      Space v240_7_result;
      for (int v240_7_label = 1; v240_7_label <= 2; ++v240_7_label) {
        const Space v240_7_tail = child(v238_13_tail,v240_7_label);
        if (v240_7_tail.empty()) continue;
        const Path v240_7_head{v240_7_label};
        const Space v241_2 = singleton(v240_7_head);
        const Space v241_3 = intersect(constant_2,v241_2);
        const Space v241_4 = (has_head(v241_3) ? constant_3 : Space{});
        const Space v241_5 = subtract(constant_1,v241_4);
        Space v241_8;
        if (!v241_5.empty()) {
          const Path v242_6 = concat_path(v240_6,v240_7_head);
          const Space v242_7 = routine_31(c, v242_6, p1, v240_7_tail, s1);
          v241_8 = compose(v241_5,v242_7);
        }
        const Space v241_9 = intersect(constant_2,v241_2);
        const Space v241_10 = (has_head(v241_9) ? constant_3 : Space{});
        Space v241_12;
        if (!v241_10.empty()) {
          const Path v243_6 = concat_path(v240_6,v240_7_head);
          const Space v243_11 = routine_32(c, v243_6, p1, v240_7_tail, s1);
          v241_12 = compose(v241_10,v243_11);
        }
        const Space v241_13 = unite(v241_8,v241_12);
        v240_7_result = unite(v240_7_result,v241_13);
      }
      const Space v240_7 = std::move(v240_7_result);
      v239_8 = compose(v239_5,v240_7);
    }
    const Space v239_9 = intersect(constant_2,v239_2);
    const Space v239_10 = (has_head(v239_9) ? constant_3 : Space{});
    const Space v239_11 = unwrap(v238_9,v238_13_head);
    const Space v239_12 = unwrap(v239_11,p1);
    const Space v239_13 = compose(v239_10,v239_12);
    const Path v244_6 = concat_path(p0,v238_13_head);
    const Space v239_14 = wrap(v239_13,v244_6);
    const Space v239_15 = wrap(v239_14,p1);
    const Space v239_16 = unite(v239_8,v239_15);
    v238_13_result = unite(v238_13_result,v239_16);
  }
  const Space v238_13 = std::move(v238_13_result);
  return v238_13;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v245_8_result;
  for (int v245_8_label = 1; v245_8_label <= 2; ++v245_8_label) {
    const Space v245_8_tail = child(s0,v245_8_label);
    if (v245_8_tail.empty()) continue;
    const Path v245_8_head{v245_8_label};
    const Space v246_2 = singleton(v245_8_head);
    const Space v246_3 = intersect(constant_2,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_3 : Space{});
    const Space v246_5 = subtract(constant_1,v246_4);
    Space v246_6_result;
    for (int v246_6_label = 1; v246_6_label <= 2; ++v246_6_label) {
      const Space v246_6_tail = child(v245_8_tail,v246_6_label);
      if (v246_6_tail.empty()) continue;
      const Path v246_6_head{v246_6_label};
      const Space v247_2 = Space{};
      v246_6_result = unite(v246_6_result,v247_2);
    }
    const Space v246_6 = std::move(v246_6_result);
    const Space v246_7 = compose(v246_5,v246_6);
    const Space v246_8 = intersect(constant_2,v246_2);
    const Space v246_9 = (has_head(v246_8) ? constant_3 : Space{});
    Space v246_12;
    if (!v246_9.empty()) {
      const Path v248_10 = concat_path(p0,v245_8_head);
      Space v248_11_result;
      for (int v248_11_label = 1; v248_11_label <= 2; ++v248_11_label) {
        const Space v248_11_tail = child(v245_8_tail,v248_11_label);
        if (v248_11_tail.empty()) continue;
        const Path v248_11_head{v248_11_label};
        const Space v249_2 = singleton(v248_11_head);
        const Space v249_3 = intersect(constant_2,v249_2);
        const Space v249_4 = (has_head(v249_3) ? constant_3 : Space{});
        Space v249_7;
        if (!v249_4.empty()) {
          const Path v250_5 = concat_path(v248_10,v248_11_head);
          const Space v250_6 = routine_10(c, v250_5, p1, v248_11_tail, s1);
          v249_7 = compose(v249_4,v250_6);
        }
        v248_11_result = unite(v248_11_result,v249_7);
      }
      const Space v248_11 = std::move(v248_11_result);
      v246_12 = compose(v246_9,v248_11);
    }
    const Space v246_13 = unite(v246_7,v246_12);
    v245_8_result = unite(v245_8_result,v246_13);
  }
  const Space v245_8 = std::move(v245_8_result);
  return v245_8;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v251_8 = unwrap(s1,constant_0);
  const Space v251_9 = unwrap(v251_8,p0);
  Space v251_10_result;
  for (int v251_10_label = 1; v251_10_label <= 2; ++v251_10_label) {
    const Space v251_10_tail = child(s0,v251_10_label);
    if (v251_10_tail.empty()) continue;
    const Path v251_10_head{v251_10_label};
    const Space v252_2 = singleton(v251_10_head);
    const Space v252_3 = intersect(constant_2,v252_2);
    const Space v252_4 = (has_head(v252_3) ? constant_3 : Space{});
    const Space v252_5 = subtract(constant_1,v252_4);
    Space v252_6_result;
    for (int v252_6_label = 1; v252_6_label <= 2; ++v252_6_label) {
      const Space v252_6_tail = child(v251_10_tail,v252_6_label);
      if (v252_6_tail.empty()) continue;
      const Path v252_6_head{v252_6_label};
      const Space v253_2 = Space{};
      v252_6_result = unite(v252_6_result,v253_2);
    }
    const Space v252_6 = std::move(v252_6_result);
    const Space v252_7 = compose(v252_5,v252_6);
    const Space v252_8 = intersect(constant_2,v252_2);
    const Space v252_9 = (has_head(v252_8) ? constant_3 : Space{});
    const Space v252_10 = unwrap(v251_9,v251_10_head);
    const Space v252_11 = unwrap(v252_10,p1);
    const Space v252_12 = compose(v252_9,v252_11);
    const Path v252_13 = concat_path(p0,v251_10_head);
    const Space v252_14 = wrap(v252_12,v252_13);
    const Space v252_15 = wrap(v252_14,p1);
    const Space v252_16 = unite(v252_7,v252_15);
    v251_10_result = unite(v251_10_result,v252_16);
  }
  const Space v251_10 = std::move(v251_10_result);
  return v251_10;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v254_4_result;
  for (int v254_4_label = 1; v254_4_label <= 2; ++v254_4_label) {
    const Space v254_4_tail = child(s0,v254_4_label);
    if (v254_4_tail.empty()) continue;
    const Path v254_4_head{v254_4_label};
    const Space v255_2 = Space{};
    v254_4_result = unite(v254_4_result,v255_2);
  }
  const Space v254_4 = std::move(v254_4_result);
  return v254_4;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v256_6 = unwrap(s1,constant_0);
  const Space v256_7 = unwrap(v256_6,p0);
  Space v256_8_result;
  for (int v256_8_label = 1; v256_8_label <= 2; ++v256_8_label) {
    const Space v256_8_tail = child(s0,v256_8_label);
    if (v256_8_tail.empty()) continue;
    const Path v256_8_head{v256_8_label};
    const Space v257_2 = singleton(v256_8_head);
    const Space v257_3 = intersect(constant_2,v257_2);
    const Space v257_4 = (has_head(v257_3) ? constant_3 : Space{});
    const Space v257_5 = unwrap(v256_7,v256_8_head);
    const Space v257_6 = unwrap(v257_5,p1);
    const Space v257_7 = compose(v257_4,v257_6);
    const Path v257_8 = concat_path(p0,v256_8_head);
    const Space v257_9 = wrap(v257_7,v257_8);
    v256_8_result = unite(v256_8_result,v257_9);
  }
  const Space v256_8 = std::move(v256_8_result);
  const Space v256_9 = wrap(v256_8,p1);
  return v256_9;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
