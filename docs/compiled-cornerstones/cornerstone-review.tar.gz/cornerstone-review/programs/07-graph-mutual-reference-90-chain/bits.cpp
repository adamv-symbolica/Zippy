#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Path n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Path n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Path n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_10(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Path n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Path n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_8(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Path n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Path n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Path n64(Context&, const Env&);
static ZIPPY_NOINLINE Path n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_44(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Path n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Path n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Path n94(Context&, const Env&);
static ZIPPY_NOINLINE Path n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_12(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Path n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Path n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Space n110(Context&, const Env&);
static ZIPPY_NOINLINE Path n111(Context&, const Env&);
static ZIPPY_NOINLINE Path n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Space n114(Context&, const Env&);
static ZIPPY_NOINLINE Space n115(Context&, const Env&);
static ZIPPY_NOINLINE Space n116(Context&, const Env&);
static ZIPPY_NOINLINE Space n117(Context&, const Env&);
static ZIPPY_NOINLINE Space n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_15(Context&, const Env&);
static ZIPPY_NOINLINE Space n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Space n127(Context&, const Env&);
static ZIPPY_NOINLINE Space n128(Context&, const Env&);
static ZIPPY_NOINLINE Path n129(Context&, const Env&);
static ZIPPY_NOINLINE Space n130(Context&, const Env&);
static ZIPPY_NOINLINE Path n131(Context&, const Env&);
static ZIPPY_NOINLINE Space n132(Context&, const Env&);
static ZIPPY_NOINLINE Space n133(Context&, const Env&);
static ZIPPY_NOINLINE Path n134(Context&, const Env&);
static ZIPPY_NOINLINE Path n135(Context&, const Env&);
static ZIPPY_NOINLINE Path n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Space n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Space n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Space n143(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_11(Context&, const Env&);
static ZIPPY_NOINLINE Space n144(Context&, const Env&);
static ZIPPY_NOINLINE Space n145(Context&, const Env&);
static ZIPPY_NOINLINE Space n146(Context&, const Env&);
static ZIPPY_NOINLINE Space n147(Context&, const Env&);
static ZIPPY_NOINLINE Space n148(Context&, const Env&);
static ZIPPY_NOINLINE Space n149(Context&, const Env&);
static ZIPPY_NOINLINE Space n150(Context&, const Env&);
static ZIPPY_NOINLINE Space n151(Context&, const Env&);
static ZIPPY_NOINLINE Path n152(Context&, const Env&);
static ZIPPY_NOINLINE Space n153(Context&, const Env&);
static ZIPPY_NOINLINE Path n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Path n157(Context&, const Env&);
static ZIPPY_NOINLINE Path n158(Context&, const Env&);
static ZIPPY_NOINLINE Path n159(Context&, const Env&);
static ZIPPY_NOINLINE Path n160(Context&, const Env&);
static ZIPPY_NOINLINE Space n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Space n164(Context&, const Env&);
static ZIPPY_NOINLINE Space n165(Context&, const Env&);
static ZIPPY_NOINLINE Path n166(Context&, const Env&);
static ZIPPY_NOINLINE Space n167(Context&, const Env&);
static ZIPPY_NOINLINE Space n168(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_9(Context&, const Env&);
static ZIPPY_NOINLINE Space n169(Context&, const Env&);
static ZIPPY_NOINLINE Space n170(Context&, const Env&);
static ZIPPY_NOINLINE Space n171(Context&, const Env&);
static ZIPPY_NOINLINE Space n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Space n174(Context&, const Env&);
static ZIPPY_NOINLINE Space n175(Context&, const Env&);
static ZIPPY_NOINLINE Space n176(Context&, const Env&);
static ZIPPY_NOINLINE Path n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Path n179(Context&, const Env&);
static ZIPPY_NOINLINE Space n180(Context&, const Env&);
static ZIPPY_NOINLINE Space n181(Context&, const Env&);
static ZIPPY_NOINLINE Path n182(Context&, const Env&);
static ZIPPY_NOINLINE Path n183(Context&, const Env&);
static ZIPPY_NOINLINE Path n184(Context&, const Env&);
static ZIPPY_NOINLINE Path n185(Context&, const Env&);
static ZIPPY_NOINLINE Space n186(Context&, const Env&);
static ZIPPY_NOINLINE Space n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Space n189(Context&, const Env&);
static ZIPPY_NOINLINE Space n190(Context&, const Env&);
static ZIPPY_NOINLINE Path n191(Context&, const Env&);
static ZIPPY_NOINLINE Space n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_19(Context&, const Env&);
static ZIPPY_NOINLINE Space n194(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Space n196(Context&, const Env&);
static ZIPPY_NOINLINE Space n197(Context&, const Env&);
static ZIPPY_NOINLINE Space n198(Context&, const Env&);
static ZIPPY_NOINLINE Space n199(Context&, const Env&);
static ZIPPY_NOINLINE Space n200(Context&, const Env&);
static ZIPPY_NOINLINE Space n201(Context&, const Env&);
static ZIPPY_NOINLINE Path n202(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Path n204(Context&, const Env&);
static ZIPPY_NOINLINE Space n205(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Path n207(Context&, const Env&);
static ZIPPY_NOINLINE Path n208(Context&, const Env&);
static ZIPPY_NOINLINE Path n209(Context&, const Env&);
static ZIPPY_NOINLINE Space n210(Context&, const Env&);
static ZIPPY_NOINLINE Space n211(Context&, const Env&);
static ZIPPY_NOINLINE Space n212(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Space n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_17(Context&, const Env&);
static ZIPPY_NOINLINE Space n217(Context&, const Env&);
static ZIPPY_NOINLINE Space n218(Context&, const Env&);
static ZIPPY_NOINLINE Space n219(Context&, const Env&);
static ZIPPY_NOINLINE Space n220(Context&, const Env&);
static ZIPPY_NOINLINE Space n221(Context&, const Env&);
static ZIPPY_NOINLINE Space n222(Context&, const Env&);
static ZIPPY_NOINLINE Space n223(Context&, const Env&);
static ZIPPY_NOINLINE Space n224(Context&, const Env&);
static ZIPPY_NOINLINE Path n225(Context&, const Env&);
static ZIPPY_NOINLINE Space n226(Context&, const Env&);
static ZIPPY_NOINLINE Path n227(Context&, const Env&);
static ZIPPY_NOINLINE Space n228(Context&, const Env&);
static ZIPPY_NOINLINE Space n229(Context&, const Env&);
static ZIPPY_NOINLINE Path n230(Context&, const Env&);
static ZIPPY_NOINLINE Path n231(Context&, const Env&);
static ZIPPY_NOINLINE Path n232(Context&, const Env&);
static ZIPPY_NOINLINE Space n233(Context&, const Env&);
static ZIPPY_NOINLINE Space n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Space n236(Context&, const Env&);
static ZIPPY_NOINLINE Space n237(Context&, const Env&);
static ZIPPY_NOINLINE Space n238(Context&, const Env&);
static ZIPPY_NOINLINE Space n239(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_45(Context&, const Env&);
static ZIPPY_NOINLINE Space n240(Context&, const Env&);
static ZIPPY_NOINLINE Path n241(Context&, const Env&);
static ZIPPY_NOINLINE Space n242(Context&, const Env&);
static ZIPPY_NOINLINE Path n243(Context&, const Env&);
static ZIPPY_NOINLINE Space n244(Context&, const Env&);
static ZIPPY_NOINLINE Path n245(Context&, const Env&);
static ZIPPY_NOINLINE Space n246(Context&, const Env&);
static ZIPPY_NOINLINE Path n247(Context&, const Env&);
static ZIPPY_NOINLINE Space n248(Context&, const Env&);
static ZIPPY_NOINLINE Path n249(Context&, const Env&);
static ZIPPY_NOINLINE Space n250(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_13(Context&, const Env&);
static ZIPPY_NOINLINE Space n251(Context&, const Env&);
static ZIPPY_NOINLINE Space n252(Context&, const Env&);
static ZIPPY_NOINLINE Space n253(Context&, const Env&);
static ZIPPY_NOINLINE Space n254(Context&, const Env&);
static ZIPPY_NOINLINE Space n255(Context&, const Env&);
static ZIPPY_NOINLINE Space n256(Context&, const Env&);
static ZIPPY_NOINLINE Space n257(Context&, const Env&);
static ZIPPY_NOINLINE Space n258(Context&, const Env&);
static ZIPPY_NOINLINE Path n259(Context&, const Env&);
static ZIPPY_NOINLINE Space n260(Context&, const Env&);
static ZIPPY_NOINLINE Path n261(Context&, const Env&);
static ZIPPY_NOINLINE Space n262(Context&, const Env&);
static ZIPPY_NOINLINE Space n263(Context&, const Env&);
static ZIPPY_NOINLINE Path n264(Context&, const Env&);
static ZIPPY_NOINLINE Path n265(Context&, const Env&);
static ZIPPY_NOINLINE Path n266(Context&, const Env&);
static ZIPPY_NOINLINE Path n267(Context&, const Env&);
static ZIPPY_NOINLINE Space n268(Context&, const Env&);
static ZIPPY_NOINLINE Space n269(Context&, const Env&);
static ZIPPY_NOINLINE Space n270(Context&, const Env&);
static ZIPPY_NOINLINE Space n271(Context&, const Env&);
static ZIPPY_NOINLINE Space n272(Context&, const Env&);
static ZIPPY_NOINLINE Path n273(Context&, const Env&);
static ZIPPY_NOINLINE Space n274(Context&, const Env&);
static ZIPPY_NOINLINE Space n275(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_14(Context&, const Env&);
static ZIPPY_NOINLINE Space n276(Context&, const Env&);
static ZIPPY_NOINLINE Space n277(Context&, const Env&);
static ZIPPY_NOINLINE Space n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Space n280(Context&, const Env&);
static ZIPPY_NOINLINE Space n281(Context&, const Env&);
static ZIPPY_NOINLINE Space n282(Context&, const Env&);
static ZIPPY_NOINLINE Space n283(Context&, const Env&);
static ZIPPY_NOINLINE Path n284(Context&, const Env&);
static ZIPPY_NOINLINE Space n285(Context&, const Env&);
static ZIPPY_NOINLINE Path n286(Context&, const Env&);
static ZIPPY_NOINLINE Space n287(Context&, const Env&);
static ZIPPY_NOINLINE Space n288(Context&, const Env&);
static ZIPPY_NOINLINE Path n289(Context&, const Env&);
static ZIPPY_NOINLINE Path n290(Context&, const Env&);
static ZIPPY_NOINLINE Path n291(Context&, const Env&);
static ZIPPY_NOINLINE Path n292(Context&, const Env&);
static ZIPPY_NOINLINE Space n293(Context&, const Env&);
static ZIPPY_NOINLINE Space n294(Context&, const Env&);
static ZIPPY_NOINLINE Space n295(Context&, const Env&);
static ZIPPY_NOINLINE Space n296(Context&, const Env&);
static ZIPPY_NOINLINE Space n297(Context&, const Env&);
static ZIPPY_NOINLINE Path n298(Context&, const Env&);
static ZIPPY_NOINLINE Space n299(Context&, const Env&);
static ZIPPY_NOINLINE Space n300(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_21(Context&, const Env&);
static ZIPPY_NOINLINE Space n301(Context&, const Env&);
static ZIPPY_NOINLINE Space n302(Context&, const Env&);
static ZIPPY_NOINLINE Space n303(Context&, const Env&);
static ZIPPY_NOINLINE Space n304(Context&, const Env&);
static ZIPPY_NOINLINE Space n305(Context&, const Env&);
static ZIPPY_NOINLINE Space n306(Context&, const Env&);
static ZIPPY_NOINLINE Space n307(Context&, const Env&);
static ZIPPY_NOINLINE Space n308(Context&, const Env&);
static ZIPPY_NOINLINE Path n309(Context&, const Env&);
static ZIPPY_NOINLINE Space n310(Context&, const Env&);
static ZIPPY_NOINLINE Path n311(Context&, const Env&);
static ZIPPY_NOINLINE Space n312(Context&, const Env&);
static ZIPPY_NOINLINE Space n313(Context&, const Env&);
static ZIPPY_NOINLINE Path n314(Context&, const Env&);
static ZIPPY_NOINLINE Path n315(Context&, const Env&);
static ZIPPY_NOINLINE Path n316(Context&, const Env&);
static ZIPPY_NOINLINE Space n317(Context&, const Env&);
static ZIPPY_NOINLINE Space n318(Context&, const Env&);
static ZIPPY_NOINLINE Space n319(Context&, const Env&);
static ZIPPY_NOINLINE Space n320(Context&, const Env&);
static ZIPPY_NOINLINE Space n321(Context&, const Env&);
static ZIPPY_NOINLINE Space n322(Context&, const Env&);
static ZIPPY_NOINLINE Space n323(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_22(Context&, const Env&);
static ZIPPY_NOINLINE Space n324(Context&, const Env&);
static ZIPPY_NOINLINE Space n325(Context&, const Env&);
static ZIPPY_NOINLINE Space n326(Context&, const Env&);
static ZIPPY_NOINLINE Space n327(Context&, const Env&);
static ZIPPY_NOINLINE Space n328(Context&, const Env&);
static ZIPPY_NOINLINE Space n329(Context&, const Env&);
static ZIPPY_NOINLINE Space n330(Context&, const Env&);
static ZIPPY_NOINLINE Space n331(Context&, const Env&);
static ZIPPY_NOINLINE Path n332(Context&, const Env&);
static ZIPPY_NOINLINE Space n333(Context&, const Env&);
static ZIPPY_NOINLINE Path n334(Context&, const Env&);
static ZIPPY_NOINLINE Space n335(Context&, const Env&);
static ZIPPY_NOINLINE Space n336(Context&, const Env&);
static ZIPPY_NOINLINE Path n337(Context&, const Env&);
static ZIPPY_NOINLINE Path n338(Context&, const Env&);
static ZIPPY_NOINLINE Path n339(Context&, const Env&);
static ZIPPY_NOINLINE Space n340(Context&, const Env&);
static ZIPPY_NOINLINE Space n341(Context&, const Env&);
static ZIPPY_NOINLINE Space n342(Context&, const Env&);
static ZIPPY_NOINLINE Space n343(Context&, const Env&);
static ZIPPY_NOINLINE Space n344(Context&, const Env&);
static ZIPPY_NOINLINE Space n345(Context&, const Env&);
static ZIPPY_NOINLINE Space n346(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_18(Context&, const Env&);
static ZIPPY_NOINLINE Space n347(Context&, const Env&);
static ZIPPY_NOINLINE Space n348(Context&, const Env&);
static ZIPPY_NOINLINE Space n349(Context&, const Env&);
static ZIPPY_NOINLINE Space n350(Context&, const Env&);
static ZIPPY_NOINLINE Space n351(Context&, const Env&);
static ZIPPY_NOINLINE Space n352(Context&, const Env&);
static ZIPPY_NOINLINE Space n353(Context&, const Env&);
static ZIPPY_NOINLINE Space n354(Context&, const Env&);
static ZIPPY_NOINLINE Path n355(Context&, const Env&);
static ZIPPY_NOINLINE Space n356(Context&, const Env&);
static ZIPPY_NOINLINE Path n357(Context&, const Env&);
static ZIPPY_NOINLINE Space n358(Context&, const Env&);
static ZIPPY_NOINLINE Space n359(Context&, const Env&);
static ZIPPY_NOINLINE Path n360(Context&, const Env&);
static ZIPPY_NOINLINE Path n361(Context&, const Env&);
static ZIPPY_NOINLINE Path n362(Context&, const Env&);
static ZIPPY_NOINLINE Path n363(Context&, const Env&);
static ZIPPY_NOINLINE Space n364(Context&, const Env&);
static ZIPPY_NOINLINE Space n365(Context&, const Env&);
static ZIPPY_NOINLINE Space n366(Context&, const Env&);
static ZIPPY_NOINLINE Space n367(Context&, const Env&);
static ZIPPY_NOINLINE Space n368(Context&, const Env&);
static ZIPPY_NOINLINE Path n369(Context&, const Env&);
static ZIPPY_NOINLINE Space n370(Context&, const Env&);
static ZIPPY_NOINLINE Space n371(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_16(Context&, const Env&);
static ZIPPY_NOINLINE Space n372(Context&, const Env&);
static ZIPPY_NOINLINE Space n373(Context&, const Env&);
static ZIPPY_NOINLINE Space n374(Context&, const Env&);
static ZIPPY_NOINLINE Space n375(Context&, const Env&);
static ZIPPY_NOINLINE Space n376(Context&, const Env&);
static ZIPPY_NOINLINE Space n377(Context&, const Env&);
static ZIPPY_NOINLINE Space n378(Context&, const Env&);
static ZIPPY_NOINLINE Space n379(Context&, const Env&);
static ZIPPY_NOINLINE Path n380(Context&, const Env&);
static ZIPPY_NOINLINE Space n381(Context&, const Env&);
static ZIPPY_NOINLINE Path n382(Context&, const Env&);
static ZIPPY_NOINLINE Space n383(Context&, const Env&);
static ZIPPY_NOINLINE Space n384(Context&, const Env&);
static ZIPPY_NOINLINE Path n385(Context&, const Env&);
static ZIPPY_NOINLINE Path n386(Context&, const Env&);
static ZIPPY_NOINLINE Path n387(Context&, const Env&);
static ZIPPY_NOINLINE Path n388(Context&, const Env&);
static ZIPPY_NOINLINE Space n389(Context&, const Env&);
static ZIPPY_NOINLINE Space n390(Context&, const Env&);
static ZIPPY_NOINLINE Space n391(Context&, const Env&);
static ZIPPY_NOINLINE Space n392(Context&, const Env&);
static ZIPPY_NOINLINE Space n393(Context&, const Env&);
static ZIPPY_NOINLINE Path n394(Context&, const Env&);
static ZIPPY_NOINLINE Space n395(Context&, const Env&);
static ZIPPY_NOINLINE Space n396(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_26(Context&, const Env&);
static ZIPPY_NOINLINE Space n397(Context&, const Env&);
static ZIPPY_NOINLINE Space n398(Context&, const Env&);
static ZIPPY_NOINLINE Space n399(Context&, const Env&);
static ZIPPY_NOINLINE Space n400(Context&, const Env&);
static ZIPPY_NOINLINE Space n401(Context&, const Env&);
static ZIPPY_NOINLINE Space n402(Context&, const Env&);
static ZIPPY_NOINLINE Space n403(Context&, const Env&);
static ZIPPY_NOINLINE Space n404(Context&, const Env&);
static ZIPPY_NOINLINE Path n405(Context&, const Env&);
static ZIPPY_NOINLINE Space n406(Context&, const Env&);
static ZIPPY_NOINLINE Path n407(Context&, const Env&);
static ZIPPY_NOINLINE Space n408(Context&, const Env&);
static ZIPPY_NOINLINE Space n409(Context&, const Env&);
static ZIPPY_NOINLINE Path n410(Context&, const Env&);
static ZIPPY_NOINLINE Path n411(Context&, const Env&);
static ZIPPY_NOINLINE Path n412(Context&, const Env&);
static ZIPPY_NOINLINE Space n413(Context&, const Env&);
static ZIPPY_NOINLINE Space n414(Context&, const Env&);
static ZIPPY_NOINLINE Space n415(Context&, const Env&);
static ZIPPY_NOINLINE Space n416(Context&, const Env&);
static ZIPPY_NOINLINE Space n417(Context&, const Env&);
static ZIPPY_NOINLINE Space n418(Context&, const Env&);
static ZIPPY_NOINLINE Space n419(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_24(Context&, const Env&);
static ZIPPY_NOINLINE Space n420(Context&, const Env&);
static ZIPPY_NOINLINE Space n421(Context&, const Env&);
static ZIPPY_NOINLINE Space n422(Context&, const Env&);
static ZIPPY_NOINLINE Space n423(Context&, const Env&);
static ZIPPY_NOINLINE Space n424(Context&, const Env&);
static ZIPPY_NOINLINE Space n425(Context&, const Env&);
static ZIPPY_NOINLINE Space n426(Context&, const Env&);
static ZIPPY_NOINLINE Space n427(Context&, const Env&);
static ZIPPY_NOINLINE Path n428(Context&, const Env&);
static ZIPPY_NOINLINE Space n429(Context&, const Env&);
static ZIPPY_NOINLINE Path n430(Context&, const Env&);
static ZIPPY_NOINLINE Space n431(Context&, const Env&);
static ZIPPY_NOINLINE Space n432(Context&, const Env&);
static ZIPPY_NOINLINE Path n433(Context&, const Env&);
static ZIPPY_NOINLINE Path n434(Context&, const Env&);
static ZIPPY_NOINLINE Path n435(Context&, const Env&);
static ZIPPY_NOINLINE Space n436(Context&, const Env&);
static ZIPPY_NOINLINE Space n437(Context&, const Env&);
static ZIPPY_NOINLINE Space n438(Context&, const Env&);
static ZIPPY_NOINLINE Space n439(Context&, const Env&);
static ZIPPY_NOINLINE Space n440(Context&, const Env&);
static ZIPPY_NOINLINE Space n441(Context&, const Env&);
static ZIPPY_NOINLINE Space n442(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_20(Context&, const Env&);
static ZIPPY_NOINLINE Space n443(Context&, const Env&);
static ZIPPY_NOINLINE Space n444(Context&, const Env&);
static ZIPPY_NOINLINE Space n445(Context&, const Env&);
static ZIPPY_NOINLINE Space n446(Context&, const Env&);
static ZIPPY_NOINLINE Space n447(Context&, const Env&);
static ZIPPY_NOINLINE Space n448(Context&, const Env&);
static ZIPPY_NOINLINE Space n449(Context&, const Env&);
static ZIPPY_NOINLINE Space n450(Context&, const Env&);
static ZIPPY_NOINLINE Path n451(Context&, const Env&);
static ZIPPY_NOINLINE Space n452(Context&, const Env&);
static ZIPPY_NOINLINE Path n453(Context&, const Env&);
static ZIPPY_NOINLINE Space n454(Context&, const Env&);
static ZIPPY_NOINLINE Space n455(Context&, const Env&);
static ZIPPY_NOINLINE Path n456(Context&, const Env&);
static ZIPPY_NOINLINE Path n457(Context&, const Env&);
static ZIPPY_NOINLINE Path n458(Context&, const Env&);
static ZIPPY_NOINLINE Path n459(Context&, const Env&);
static ZIPPY_NOINLINE Space n460(Context&, const Env&);
static ZIPPY_NOINLINE Space n461(Context&, const Env&);
static ZIPPY_NOINLINE Space n462(Context&, const Env&);
static ZIPPY_NOINLINE Space n463(Context&, const Env&);
static ZIPPY_NOINLINE Space n464(Context&, const Env&);
static ZIPPY_NOINLINE Path n465(Context&, const Env&);
static ZIPPY_NOINLINE Space n466(Context&, const Env&);
static ZIPPY_NOINLINE Space n467(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_23(Context&, const Env&);
static ZIPPY_NOINLINE Space n468(Context&, const Env&);
static ZIPPY_NOINLINE Space n469(Context&, const Env&);
static ZIPPY_NOINLINE Space n470(Context&, const Env&);
static ZIPPY_NOINLINE Space n471(Context&, const Env&);
static ZIPPY_NOINLINE Space n472(Context&, const Env&);
static ZIPPY_NOINLINE Space n473(Context&, const Env&);
static ZIPPY_NOINLINE Space n474(Context&, const Env&);
static ZIPPY_NOINLINE Space n475(Context&, const Env&);
static ZIPPY_NOINLINE Path n476(Context&, const Env&);
static ZIPPY_NOINLINE Space n477(Context&, const Env&);
static ZIPPY_NOINLINE Path n478(Context&, const Env&);
static ZIPPY_NOINLINE Space n479(Context&, const Env&);
static ZIPPY_NOINLINE Space n480(Context&, const Env&);
static ZIPPY_NOINLINE Path n481(Context&, const Env&);
static ZIPPY_NOINLINE Path n482(Context&, const Env&);
static ZIPPY_NOINLINE Path n483(Context&, const Env&);
static ZIPPY_NOINLINE Path n484(Context&, const Env&);
static ZIPPY_NOINLINE Space n485(Context&, const Env&);
static ZIPPY_NOINLINE Space n486(Context&, const Env&);
static ZIPPY_NOINLINE Space n487(Context&, const Env&);
static ZIPPY_NOINLINE Space n488(Context&, const Env&);
static ZIPPY_NOINLINE Space n489(Context&, const Env&);
static ZIPPY_NOINLINE Path n490(Context&, const Env&);
static ZIPPY_NOINLINE Space n491(Context&, const Env&);
static ZIPPY_NOINLINE Space n492(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_28(Context&, const Env&);
static ZIPPY_NOINLINE Space n493(Context&, const Env&);
static ZIPPY_NOINLINE Space n494(Context&, const Env&);
static ZIPPY_NOINLINE Space n495(Context&, const Env&);
static ZIPPY_NOINLINE Space n496(Context&, const Env&);
static ZIPPY_NOINLINE Space n497(Context&, const Env&);
static ZIPPY_NOINLINE Space n498(Context&, const Env&);
static ZIPPY_NOINLINE Space n499(Context&, const Env&);
static ZIPPY_NOINLINE Space n500(Context&, const Env&);
static ZIPPY_NOINLINE Path n501(Context&, const Env&);
static ZIPPY_NOINLINE Space n502(Context&, const Env&);
static ZIPPY_NOINLINE Path n503(Context&, const Env&);
static ZIPPY_NOINLINE Space n504(Context&, const Env&);
static ZIPPY_NOINLINE Space n505(Context&, const Env&);
static ZIPPY_NOINLINE Path n506(Context&, const Env&);
static ZIPPY_NOINLINE Path n507(Context&, const Env&);
static ZIPPY_NOINLINE Path n508(Context&, const Env&);
static ZIPPY_NOINLINE Space n509(Context&, const Env&);
static ZIPPY_NOINLINE Space n510(Context&, const Env&);
static ZIPPY_NOINLINE Space n511(Context&, const Env&);
static ZIPPY_NOINLINE Space n512(Context&, const Env&);
static ZIPPY_NOINLINE Space n513(Context&, const Env&);
static ZIPPY_NOINLINE Space n514(Context&, const Env&);
static ZIPPY_NOINLINE Space n515(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_30(Context&, const Env&);
static ZIPPY_NOINLINE Space n516(Context&, const Env&);
static ZIPPY_NOINLINE Space n517(Context&, const Env&);
static ZIPPY_NOINLINE Space n518(Context&, const Env&);
static ZIPPY_NOINLINE Space n519(Context&, const Env&);
static ZIPPY_NOINLINE Space n520(Context&, const Env&);
static ZIPPY_NOINLINE Space n521(Context&, const Env&);
static ZIPPY_NOINLINE Space n522(Context&, const Env&);
static ZIPPY_NOINLINE Space n523(Context&, const Env&);
static ZIPPY_NOINLINE Path n524(Context&, const Env&);
static ZIPPY_NOINLINE Space n525(Context&, const Env&);
static ZIPPY_NOINLINE Path n526(Context&, const Env&);
static ZIPPY_NOINLINE Space n527(Context&, const Env&);
static ZIPPY_NOINLINE Space n528(Context&, const Env&);
static ZIPPY_NOINLINE Path n529(Context&, const Env&);
static ZIPPY_NOINLINE Path n530(Context&, const Env&);
static ZIPPY_NOINLINE Path n531(Context&, const Env&);
static ZIPPY_NOINLINE Space n532(Context&, const Env&);
static ZIPPY_NOINLINE Space n533(Context&, const Env&);
static ZIPPY_NOINLINE Space n534(Context&, const Env&);
static ZIPPY_NOINLINE Space n535(Context&, const Env&);
static ZIPPY_NOINLINE Space n536(Context&, const Env&);
static ZIPPY_NOINLINE Space n537(Context&, const Env&);
static ZIPPY_NOINLINE Space n538(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_27(Context&, const Env&);
static ZIPPY_NOINLINE Space n539(Context&, const Env&);
static ZIPPY_NOINLINE Space n540(Context&, const Env&);
static ZIPPY_NOINLINE Space n541(Context&, const Env&);
static ZIPPY_NOINLINE Space n542(Context&, const Env&);
static ZIPPY_NOINLINE Space n543(Context&, const Env&);
static ZIPPY_NOINLINE Space n544(Context&, const Env&);
static ZIPPY_NOINLINE Space n545(Context&, const Env&);
static ZIPPY_NOINLINE Space n546(Context&, const Env&);
static ZIPPY_NOINLINE Path n547(Context&, const Env&);
static ZIPPY_NOINLINE Space n548(Context&, const Env&);
static ZIPPY_NOINLINE Path n549(Context&, const Env&);
static ZIPPY_NOINLINE Space n550(Context&, const Env&);
static ZIPPY_NOINLINE Space n551(Context&, const Env&);
static ZIPPY_NOINLINE Path n552(Context&, const Env&);
static ZIPPY_NOINLINE Path n553(Context&, const Env&);
static ZIPPY_NOINLINE Path n554(Context&, const Env&);
static ZIPPY_NOINLINE Path n555(Context&, const Env&);
static ZIPPY_NOINLINE Space n556(Context&, const Env&);
static ZIPPY_NOINLINE Space n557(Context&, const Env&);
static ZIPPY_NOINLINE Space n558(Context&, const Env&);
static ZIPPY_NOINLINE Space n559(Context&, const Env&);
static ZIPPY_NOINLINE Space n560(Context&, const Env&);
static ZIPPY_NOINLINE Path n561(Context&, const Env&);
static ZIPPY_NOINLINE Space n562(Context&, const Env&);
static ZIPPY_NOINLINE Space n563(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_25(Context&, const Env&);
static ZIPPY_NOINLINE Space n564(Context&, const Env&);
static ZIPPY_NOINLINE Space n565(Context&, const Env&);
static ZIPPY_NOINLINE Space n566(Context&, const Env&);
static ZIPPY_NOINLINE Space n567(Context&, const Env&);
static ZIPPY_NOINLINE Space n568(Context&, const Env&);
static ZIPPY_NOINLINE Space n569(Context&, const Env&);
static ZIPPY_NOINLINE Space n570(Context&, const Env&);
static ZIPPY_NOINLINE Space n571(Context&, const Env&);
static ZIPPY_NOINLINE Path n572(Context&, const Env&);
static ZIPPY_NOINLINE Space n573(Context&, const Env&);
static ZIPPY_NOINLINE Path n574(Context&, const Env&);
static ZIPPY_NOINLINE Space n575(Context&, const Env&);
static ZIPPY_NOINLINE Space n576(Context&, const Env&);
static ZIPPY_NOINLINE Path n577(Context&, const Env&);
static ZIPPY_NOINLINE Path n578(Context&, const Env&);
static ZIPPY_NOINLINE Path n579(Context&, const Env&);
static ZIPPY_NOINLINE Path n580(Context&, const Env&);
static ZIPPY_NOINLINE Space n581(Context&, const Env&);
static ZIPPY_NOINLINE Space n582(Context&, const Env&);
static ZIPPY_NOINLINE Space n583(Context&, const Env&);
static ZIPPY_NOINLINE Space n584(Context&, const Env&);
static ZIPPY_NOINLINE Space n585(Context&, const Env&);
static ZIPPY_NOINLINE Path n586(Context&, const Env&);
static ZIPPY_NOINLINE Space n587(Context&, const Env&);
static ZIPPY_NOINLINE Space n588(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_34(Context&, const Env&);
static ZIPPY_NOINLINE Space n589(Context&, const Env&);
static ZIPPY_NOINLINE Space n590(Context&, const Env&);
static ZIPPY_NOINLINE Space n591(Context&, const Env&);
static ZIPPY_NOINLINE Space n592(Context&, const Env&);
static ZIPPY_NOINLINE Space n593(Context&, const Env&);
static ZIPPY_NOINLINE Space n594(Context&, const Env&);
static ZIPPY_NOINLINE Space n595(Context&, const Env&);
static ZIPPY_NOINLINE Space n596(Context&, const Env&);
static ZIPPY_NOINLINE Path n597(Context&, const Env&);
static ZIPPY_NOINLINE Space n598(Context&, const Env&);
static ZIPPY_NOINLINE Path n599(Context&, const Env&);
static ZIPPY_NOINLINE Space n600(Context&, const Env&);
static ZIPPY_NOINLINE Space n601(Context&, const Env&);
static ZIPPY_NOINLINE Path n602(Context&, const Env&);
static ZIPPY_NOINLINE Path n603(Context&, const Env&);
static ZIPPY_NOINLINE Path n604(Context&, const Env&);
static ZIPPY_NOINLINE Space n605(Context&, const Env&);
static ZIPPY_NOINLINE Space n606(Context&, const Env&);
static ZIPPY_NOINLINE Space n607(Context&, const Env&);
static ZIPPY_NOINLINE Space n608(Context&, const Env&);
static ZIPPY_NOINLINE Space n609(Context&, const Env&);
static ZIPPY_NOINLINE Space n610(Context&, const Env&);
static ZIPPY_NOINLINE Space n611(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_32(Context&, const Env&);
static ZIPPY_NOINLINE Space n612(Context&, const Env&);
static ZIPPY_NOINLINE Space n613(Context&, const Env&);
static ZIPPY_NOINLINE Space n614(Context&, const Env&);
static ZIPPY_NOINLINE Space n615(Context&, const Env&);
static ZIPPY_NOINLINE Space n616(Context&, const Env&);
static ZIPPY_NOINLINE Space n617(Context&, const Env&);
static ZIPPY_NOINLINE Space n618(Context&, const Env&);
static ZIPPY_NOINLINE Space n619(Context&, const Env&);
static ZIPPY_NOINLINE Path n620(Context&, const Env&);
static ZIPPY_NOINLINE Space n621(Context&, const Env&);
static ZIPPY_NOINLINE Path n622(Context&, const Env&);
static ZIPPY_NOINLINE Space n623(Context&, const Env&);
static ZIPPY_NOINLINE Space n624(Context&, const Env&);
static ZIPPY_NOINLINE Path n625(Context&, const Env&);
static ZIPPY_NOINLINE Path n626(Context&, const Env&);
static ZIPPY_NOINLINE Path n627(Context&, const Env&);
static ZIPPY_NOINLINE Space n628(Context&, const Env&);
static ZIPPY_NOINLINE Space n629(Context&, const Env&);
static ZIPPY_NOINLINE Space n630(Context&, const Env&);
static ZIPPY_NOINLINE Space n631(Context&, const Env&);
static ZIPPY_NOINLINE Space n632(Context&, const Env&);
static ZIPPY_NOINLINE Space n633(Context&, const Env&);
static ZIPPY_NOINLINE Space n634(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_29(Context&, const Env&);
static ZIPPY_NOINLINE Space n635(Context&, const Env&);
static ZIPPY_NOINLINE Space n636(Context&, const Env&);
static ZIPPY_NOINLINE Space n637(Context&, const Env&);
static ZIPPY_NOINLINE Space n638(Context&, const Env&);
static ZIPPY_NOINLINE Space n639(Context&, const Env&);
static ZIPPY_NOINLINE Space n640(Context&, const Env&);
static ZIPPY_NOINLINE Space n641(Context&, const Env&);
static ZIPPY_NOINLINE Space n642(Context&, const Env&);
static ZIPPY_NOINLINE Path n643(Context&, const Env&);
static ZIPPY_NOINLINE Space n644(Context&, const Env&);
static ZIPPY_NOINLINE Path n645(Context&, const Env&);
static ZIPPY_NOINLINE Space n646(Context&, const Env&);
static ZIPPY_NOINLINE Space n647(Context&, const Env&);
static ZIPPY_NOINLINE Path n648(Context&, const Env&);
static ZIPPY_NOINLINE Path n649(Context&, const Env&);
static ZIPPY_NOINLINE Path n650(Context&, const Env&);
static ZIPPY_NOINLINE Path n651(Context&, const Env&);
static ZIPPY_NOINLINE Space n652(Context&, const Env&);
static ZIPPY_NOINLINE Space n653(Context&, const Env&);
static ZIPPY_NOINLINE Space n654(Context&, const Env&);
static ZIPPY_NOINLINE Space n655(Context&, const Env&);
static ZIPPY_NOINLINE Space n656(Context&, const Env&);
static ZIPPY_NOINLINE Path n657(Context&, const Env&);
static ZIPPY_NOINLINE Space n658(Context&, const Env&);
static ZIPPY_NOINLINE Space n659(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_31(Context&, const Env&);
static ZIPPY_NOINLINE Space n660(Context&, const Env&);
static ZIPPY_NOINLINE Space n661(Context&, const Env&);
static ZIPPY_NOINLINE Space n662(Context&, const Env&);
static ZIPPY_NOINLINE Space n663(Context&, const Env&);
static ZIPPY_NOINLINE Space n664(Context&, const Env&);
static ZIPPY_NOINLINE Space n665(Context&, const Env&);
static ZIPPY_NOINLINE Space n666(Context&, const Env&);
static ZIPPY_NOINLINE Space n667(Context&, const Env&);
static ZIPPY_NOINLINE Path n668(Context&, const Env&);
static ZIPPY_NOINLINE Space n669(Context&, const Env&);
static ZIPPY_NOINLINE Path n670(Context&, const Env&);
static ZIPPY_NOINLINE Space n671(Context&, const Env&);
static ZIPPY_NOINLINE Space n672(Context&, const Env&);
static ZIPPY_NOINLINE Path n673(Context&, const Env&);
static ZIPPY_NOINLINE Path n674(Context&, const Env&);
static ZIPPY_NOINLINE Path n675(Context&, const Env&);
static ZIPPY_NOINLINE Path n676(Context&, const Env&);
static ZIPPY_NOINLINE Space n677(Context&, const Env&);
static ZIPPY_NOINLINE Space n678(Context&, const Env&);
static ZIPPY_NOINLINE Space n679(Context&, const Env&);
static ZIPPY_NOINLINE Space n680(Context&, const Env&);
static ZIPPY_NOINLINE Space n681(Context&, const Env&);
static ZIPPY_NOINLINE Path n682(Context&, const Env&);
static ZIPPY_NOINLINE Space n683(Context&, const Env&);
static ZIPPY_NOINLINE Space n684(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_36(Context&, const Env&);
static ZIPPY_NOINLINE Space n685(Context&, const Env&);
static ZIPPY_NOINLINE Space n686(Context&, const Env&);
static ZIPPY_NOINLINE Space n687(Context&, const Env&);
static ZIPPY_NOINLINE Space n688(Context&, const Env&);
static ZIPPY_NOINLINE Space n689(Context&, const Env&);
static ZIPPY_NOINLINE Space n690(Context&, const Env&);
static ZIPPY_NOINLINE Space n691(Context&, const Env&);
static ZIPPY_NOINLINE Space n692(Context&, const Env&);
static ZIPPY_NOINLINE Path n693(Context&, const Env&);
static ZIPPY_NOINLINE Space n694(Context&, const Env&);
static ZIPPY_NOINLINE Path n695(Context&, const Env&);
static ZIPPY_NOINLINE Space n696(Context&, const Env&);
static ZIPPY_NOINLINE Space n697(Context&, const Env&);
static ZIPPY_NOINLINE Path n698(Context&, const Env&);
static ZIPPY_NOINLINE Path n699(Context&, const Env&);
static ZIPPY_NOINLINE Path n700(Context&, const Env&);
static ZIPPY_NOINLINE Space n701(Context&, const Env&);
static ZIPPY_NOINLINE Space n702(Context&, const Env&);
static ZIPPY_NOINLINE Space n703(Context&, const Env&);
static ZIPPY_NOINLINE Space n704(Context&, const Env&);
static ZIPPY_NOINLINE Space n705(Context&, const Env&);
static ZIPPY_NOINLINE Space n706(Context&, const Env&);
static ZIPPY_NOINLINE Space n707(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_38(Context&, const Env&);
static ZIPPY_NOINLINE Space n708(Context&, const Env&);
static ZIPPY_NOINLINE Space n709(Context&, const Env&);
static ZIPPY_NOINLINE Space n710(Context&, const Env&);
static ZIPPY_NOINLINE Space n711(Context&, const Env&);
static ZIPPY_NOINLINE Space n712(Context&, const Env&);
static ZIPPY_NOINLINE Space n713(Context&, const Env&);
static ZIPPY_NOINLINE Space n714(Context&, const Env&);
static ZIPPY_NOINLINE Space n715(Context&, const Env&);
static ZIPPY_NOINLINE Path n716(Context&, const Env&);
static ZIPPY_NOINLINE Space n717(Context&, const Env&);
static ZIPPY_NOINLINE Path n718(Context&, const Env&);
static ZIPPY_NOINLINE Space n719(Context&, const Env&);
static ZIPPY_NOINLINE Space n720(Context&, const Env&);
static ZIPPY_NOINLINE Path n721(Context&, const Env&);
static ZIPPY_NOINLINE Path n722(Context&, const Env&);
static ZIPPY_NOINLINE Path n723(Context&, const Env&);
static ZIPPY_NOINLINE Space n724(Context&, const Env&);
static ZIPPY_NOINLINE Space n725(Context&, const Env&);
static ZIPPY_NOINLINE Space n726(Context&, const Env&);
static ZIPPY_NOINLINE Space n727(Context&, const Env&);
static ZIPPY_NOINLINE Space n728(Context&, const Env&);
static ZIPPY_NOINLINE Space n729(Context&, const Env&);
static ZIPPY_NOINLINE Space n730(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_35(Context&, const Env&);
static ZIPPY_NOINLINE Space n731(Context&, const Env&);
static ZIPPY_NOINLINE Space n732(Context&, const Env&);
static ZIPPY_NOINLINE Space n733(Context&, const Env&);
static ZIPPY_NOINLINE Space n734(Context&, const Env&);
static ZIPPY_NOINLINE Space n735(Context&, const Env&);
static ZIPPY_NOINLINE Space n736(Context&, const Env&);
static ZIPPY_NOINLINE Space n737(Context&, const Env&);
static ZIPPY_NOINLINE Space n738(Context&, const Env&);
static ZIPPY_NOINLINE Path n739(Context&, const Env&);
static ZIPPY_NOINLINE Space n740(Context&, const Env&);
static ZIPPY_NOINLINE Path n741(Context&, const Env&);
static ZIPPY_NOINLINE Space n742(Context&, const Env&);
static ZIPPY_NOINLINE Space n743(Context&, const Env&);
static ZIPPY_NOINLINE Path n744(Context&, const Env&);
static ZIPPY_NOINLINE Path n745(Context&, const Env&);
static ZIPPY_NOINLINE Path n746(Context&, const Env&);
static ZIPPY_NOINLINE Path n747(Context&, const Env&);
static ZIPPY_NOINLINE Space n748(Context&, const Env&);
static ZIPPY_NOINLINE Space n749(Context&, const Env&);
static ZIPPY_NOINLINE Space n750(Context&, const Env&);
static ZIPPY_NOINLINE Space n751(Context&, const Env&);
static ZIPPY_NOINLINE Space n752(Context&, const Env&);
static ZIPPY_NOINLINE Path n753(Context&, const Env&);
static ZIPPY_NOINLINE Space n754(Context&, const Env&);
static ZIPPY_NOINLINE Space n755(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_33(Context&, const Env&);
static ZIPPY_NOINLINE Space n756(Context&, const Env&);
static ZIPPY_NOINLINE Space n757(Context&, const Env&);
static ZIPPY_NOINLINE Space n758(Context&, const Env&);
static ZIPPY_NOINLINE Space n759(Context&, const Env&);
static ZIPPY_NOINLINE Space n760(Context&, const Env&);
static ZIPPY_NOINLINE Space n761(Context&, const Env&);
static ZIPPY_NOINLINE Space n762(Context&, const Env&);
static ZIPPY_NOINLINE Space n763(Context&, const Env&);
static ZIPPY_NOINLINE Path n764(Context&, const Env&);
static ZIPPY_NOINLINE Space n765(Context&, const Env&);
static ZIPPY_NOINLINE Path n766(Context&, const Env&);
static ZIPPY_NOINLINE Space n767(Context&, const Env&);
static ZIPPY_NOINLINE Space n768(Context&, const Env&);
static ZIPPY_NOINLINE Path n769(Context&, const Env&);
static ZIPPY_NOINLINE Path n770(Context&, const Env&);
static ZIPPY_NOINLINE Path n771(Context&, const Env&);
static ZIPPY_NOINLINE Path n772(Context&, const Env&);
static ZIPPY_NOINLINE Space n773(Context&, const Env&);
static ZIPPY_NOINLINE Space n774(Context&, const Env&);
static ZIPPY_NOINLINE Space n775(Context&, const Env&);
static ZIPPY_NOINLINE Space n776(Context&, const Env&);
static ZIPPY_NOINLINE Space n777(Context&, const Env&);
static ZIPPY_NOINLINE Path n778(Context&, const Env&);
static ZIPPY_NOINLINE Space n779(Context&, const Env&);
static ZIPPY_NOINLINE Space n780(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_42(Context&, const Env&);
static ZIPPY_NOINLINE Space n781(Context&, const Env&);
static ZIPPY_NOINLINE Space n782(Context&, const Env&);
static ZIPPY_NOINLINE Space n783(Context&, const Env&);
static ZIPPY_NOINLINE Space n784(Context&, const Env&);
static ZIPPY_NOINLINE Space n785(Context&, const Env&);
static ZIPPY_NOINLINE Space n786(Context&, const Env&);
static ZIPPY_NOINLINE Space n787(Context&, const Env&);
static ZIPPY_NOINLINE Space n788(Context&, const Env&);
static ZIPPY_NOINLINE Path n789(Context&, const Env&);
static ZIPPY_NOINLINE Space n790(Context&, const Env&);
static ZIPPY_NOINLINE Path n791(Context&, const Env&);
static ZIPPY_NOINLINE Space n792(Context&, const Env&);
static ZIPPY_NOINLINE Space n793(Context&, const Env&);
static ZIPPY_NOINLINE Path n794(Context&, const Env&);
static ZIPPY_NOINLINE Path n795(Context&, const Env&);
static ZIPPY_NOINLINE Path n796(Context&, const Env&);
static ZIPPY_NOINLINE Space n797(Context&, const Env&);
static ZIPPY_NOINLINE Space n798(Context&, const Env&);
static ZIPPY_NOINLINE Space n799(Context&, const Env&);
static ZIPPY_NOINLINE Space n800(Context&, const Env&);
static ZIPPY_NOINLINE Space n801(Context&, const Env&);
static ZIPPY_NOINLINE Space n802(Context&, const Env&);
static ZIPPY_NOINLINE Space n803(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_40(Context&, const Env&);
static ZIPPY_NOINLINE Space n804(Context&, const Env&);
static ZIPPY_NOINLINE Space n805(Context&, const Env&);
static ZIPPY_NOINLINE Space n806(Context&, const Env&);
static ZIPPY_NOINLINE Space n807(Context&, const Env&);
static ZIPPY_NOINLINE Space n808(Context&, const Env&);
static ZIPPY_NOINLINE Space n809(Context&, const Env&);
static ZIPPY_NOINLINE Space n810(Context&, const Env&);
static ZIPPY_NOINLINE Space n811(Context&, const Env&);
static ZIPPY_NOINLINE Path n812(Context&, const Env&);
static ZIPPY_NOINLINE Space n813(Context&, const Env&);
static ZIPPY_NOINLINE Path n814(Context&, const Env&);
static ZIPPY_NOINLINE Space n815(Context&, const Env&);
static ZIPPY_NOINLINE Space n816(Context&, const Env&);
static ZIPPY_NOINLINE Path n817(Context&, const Env&);
static ZIPPY_NOINLINE Path n818(Context&, const Env&);
static ZIPPY_NOINLINE Path n819(Context&, const Env&);
static ZIPPY_NOINLINE Space n820(Context&, const Env&);
static ZIPPY_NOINLINE Space n821(Context&, const Env&);
static ZIPPY_NOINLINE Space n822(Context&, const Env&);
static ZIPPY_NOINLINE Space n823(Context&, const Env&);
static ZIPPY_NOINLINE Space n824(Context&, const Env&);
static ZIPPY_NOINLINE Space n825(Context&, const Env&);
static ZIPPY_NOINLINE Space n826(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_37(Context&, const Env&);
static ZIPPY_NOINLINE Space n827(Context&, const Env&);
static ZIPPY_NOINLINE Space n828(Context&, const Env&);
static ZIPPY_NOINLINE Space n829(Context&, const Env&);
static ZIPPY_NOINLINE Space n830(Context&, const Env&);
static ZIPPY_NOINLINE Space n831(Context&, const Env&);
static ZIPPY_NOINLINE Space n832(Context&, const Env&);
static ZIPPY_NOINLINE Space n833(Context&, const Env&);
static ZIPPY_NOINLINE Space n834(Context&, const Env&);
static ZIPPY_NOINLINE Path n835(Context&, const Env&);
static ZIPPY_NOINLINE Space n836(Context&, const Env&);
static ZIPPY_NOINLINE Path n837(Context&, const Env&);
static ZIPPY_NOINLINE Space n838(Context&, const Env&);
static ZIPPY_NOINLINE Space n839(Context&, const Env&);
static ZIPPY_NOINLINE Path n840(Context&, const Env&);
static ZIPPY_NOINLINE Path n841(Context&, const Env&);
static ZIPPY_NOINLINE Path n842(Context&, const Env&);
static ZIPPY_NOINLINE Path n843(Context&, const Env&);
static ZIPPY_NOINLINE Space n844(Context&, const Env&);
static ZIPPY_NOINLINE Space n845(Context&, const Env&);
static ZIPPY_NOINLINE Space n846(Context&, const Env&);
static ZIPPY_NOINLINE Space n847(Context&, const Env&);
static ZIPPY_NOINLINE Space n848(Context&, const Env&);
static ZIPPY_NOINLINE Path n849(Context&, const Env&);
static ZIPPY_NOINLINE Space n850(Context&, const Env&);
static ZIPPY_NOINLINE Space n851(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_39(Context&, const Env&);
static ZIPPY_NOINLINE Space n852(Context&, const Env&);
static ZIPPY_NOINLINE Space n853(Context&, const Env&);
static ZIPPY_NOINLINE Space n854(Context&, const Env&);
static ZIPPY_NOINLINE Space n855(Context&, const Env&);
static ZIPPY_NOINLINE Space n856(Context&, const Env&);
static ZIPPY_NOINLINE Space n857(Context&, const Env&);
static ZIPPY_NOINLINE Space n858(Context&, const Env&);
static ZIPPY_NOINLINE Space n859(Context&, const Env&);
static ZIPPY_NOINLINE Path n860(Context&, const Env&);
static ZIPPY_NOINLINE Space n861(Context&, const Env&);
static ZIPPY_NOINLINE Path n862(Context&, const Env&);
static ZIPPY_NOINLINE Space n863(Context&, const Env&);
static ZIPPY_NOINLINE Space n864(Context&, const Env&);
static ZIPPY_NOINLINE Path n865(Context&, const Env&);
static ZIPPY_NOINLINE Path n866(Context&, const Env&);
static ZIPPY_NOINLINE Path n867(Context&, const Env&);
static ZIPPY_NOINLINE Path n868(Context&, const Env&);
static ZIPPY_NOINLINE Space n869(Context&, const Env&);
static ZIPPY_NOINLINE Space n870(Context&, const Env&);
static ZIPPY_NOINLINE Space n871(Context&, const Env&);
static ZIPPY_NOINLINE Space n872(Context&, const Env&);
static ZIPPY_NOINLINE Space n873(Context&, const Env&);
static ZIPPY_NOINLINE Path n874(Context&, const Env&);
static ZIPPY_NOINLINE Space n875(Context&, const Env&);
static ZIPPY_NOINLINE Space n876(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_4(Context&, const Env&);
static ZIPPY_NOINLINE Space n877(Context&, const Env&);
static ZIPPY_NOINLINE Space n878(Context&, const Env&);
static ZIPPY_NOINLINE Space n879(Context&, const Env&);
static ZIPPY_NOINLINE Space n880(Context&, const Env&);
static ZIPPY_NOINLINE Space n881(Context&, const Env&);
static ZIPPY_NOINLINE Space n882(Context&, const Env&);
static ZIPPY_NOINLINE Space n883(Context&, const Env&);
static ZIPPY_NOINLINE Space n884(Context&, const Env&);
static ZIPPY_NOINLINE Path n885(Context&, const Env&);
static ZIPPY_NOINLINE Space n886(Context&, const Env&);
static ZIPPY_NOINLINE Path n887(Context&, const Env&);
static ZIPPY_NOINLINE Space n888(Context&, const Env&);
static ZIPPY_NOINLINE Space n889(Context&, const Env&);
static ZIPPY_NOINLINE Space n890(Context&, const Env&);
static ZIPPY_NOINLINE Space n891(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_6(Context&, const Env&);
static ZIPPY_NOINLINE Space n892(Context&, const Env&);
static ZIPPY_NOINLINE Space n893(Context&, const Env&);
static ZIPPY_NOINLINE Space n894(Context&, const Env&);
static ZIPPY_NOINLINE Space n895(Context&, const Env&);
static ZIPPY_NOINLINE Space n896(Context&, const Env&);
static ZIPPY_NOINLINE Space n897(Context&, const Env&);
static ZIPPY_NOINLINE Space n898(Context&, const Env&);
static ZIPPY_NOINLINE Space n899(Context&, const Env&);
static ZIPPY_NOINLINE Path n900(Context&, const Env&);
static ZIPPY_NOINLINE Space n901(Context&, const Env&);
static ZIPPY_NOINLINE Path n902(Context&, const Env&);
static ZIPPY_NOINLINE Space n903(Context&, const Env&);
static ZIPPY_NOINLINE Space n904(Context&, const Env&);
static ZIPPY_NOINLINE Path n905(Context&, const Env&);
static ZIPPY_NOINLINE Path n906(Context&, const Env&);
static ZIPPY_NOINLINE Path n907(Context&, const Env&);
static ZIPPY_NOINLINE Space n908(Context&, const Env&);
static ZIPPY_NOINLINE Space n909(Context&, const Env&);
static ZIPPY_NOINLINE Space n910(Context&, const Env&);
static ZIPPY_NOINLINE Space n911(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_43(Context&, const Env&);
static ZIPPY_NOINLINE Space n912(Context&, const Env&);
static ZIPPY_NOINLINE Space n913(Context&, const Env&);
static ZIPPY_NOINLINE Space n914(Context&, const Env&);
static ZIPPY_NOINLINE Space n915(Context&, const Env&);
static ZIPPY_NOINLINE Space n916(Context&, const Env&);
static ZIPPY_NOINLINE Space n917(Context&, const Env&);
static ZIPPY_NOINLINE Space n918(Context&, const Env&);
static ZIPPY_NOINLINE Space n919(Context&, const Env&);
static ZIPPY_NOINLINE Path n920(Context&, const Env&);
static ZIPPY_NOINLINE Space n921(Context&, const Env&);
static ZIPPY_NOINLINE Path n922(Context&, const Env&);
static ZIPPY_NOINLINE Space n923(Context&, const Env&);
static ZIPPY_NOINLINE Space n924(Context&, const Env&);
static ZIPPY_NOINLINE Path n925(Context&, const Env&);
static ZIPPY_NOINLINE Path n926(Context&, const Env&);
static ZIPPY_NOINLINE Path n927(Context&, const Env&);
static ZIPPY_NOINLINE Path n928(Context&, const Env&);
static ZIPPY_NOINLINE Space n929(Context&, const Env&);
static ZIPPY_NOINLINE Space n930(Context&, const Env&);
static ZIPPY_NOINLINE Space n931(Context&, const Env&);
static ZIPPY_NOINLINE Space n932(Context&, const Env&);
static ZIPPY_NOINLINE Space n933(Context&, const Env&);
static ZIPPY_NOINLINE Path n934(Context&, const Env&);
static ZIPPY_NOINLINE Space n935(Context&, const Env&);
static ZIPPY_NOINLINE Space n936(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_41(Context&, const Env&);
static ZIPPY_NOINLINE Space n937(Context&, const Env&);
static ZIPPY_NOINLINE Space n938(Context&, const Env&);
static ZIPPY_NOINLINE Space n939(Context&, const Env&);
static ZIPPY_NOINLINE Space n940(Context&, const Env&);
static ZIPPY_NOINLINE Space n941(Context&, const Env&);
static ZIPPY_NOINLINE Space n942(Context&, const Env&);
static ZIPPY_NOINLINE Space n943(Context&, const Env&);
static ZIPPY_NOINLINE Space n944(Context&, const Env&);
static ZIPPY_NOINLINE Path n945(Context&, const Env&);
static ZIPPY_NOINLINE Space n946(Context&, const Env&);
static ZIPPY_NOINLINE Path n947(Context&, const Env&);
static ZIPPY_NOINLINE Space n948(Context&, const Env&);
static ZIPPY_NOINLINE Space n949(Context&, const Env&);
static ZIPPY_NOINLINE Path n950(Context&, const Env&);
static ZIPPY_NOINLINE Path n951(Context&, const Env&);
static ZIPPY_NOINLINE Path n952(Context&, const Env&);
static ZIPPY_NOINLINE Path n953(Context&, const Env&);
static ZIPPY_NOINLINE Space n954(Context&, const Env&);
static ZIPPY_NOINLINE Space n955(Context&, const Env&);
static ZIPPY_NOINLINE Space n956(Context&, const Env&);
static ZIPPY_NOINLINE Space n957(Context&, const Env&);
static ZIPPY_NOINLINE Space n958(Context&, const Env&);
static ZIPPY_NOINLINE Path n959(Context&, const Env&);
static ZIPPY_NOINLINE Space n960(Context&, const Env&);
static ZIPPY_NOINLINE Space n961(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_5(Context&, const Env&);
static ZIPPY_NOINLINE Space n962(Context&, const Env&);
static ZIPPY_NOINLINE Space n963(Context&, const Env&);
static ZIPPY_NOINLINE Space n964(Context&, const Env&);
static ZIPPY_NOINLINE Space n965(Context&, const Env&);
static ZIPPY_NOINLINE Space n966(Context&, const Env&);
static ZIPPY_NOINLINE Space n967(Context&, const Env&);
static ZIPPY_NOINLINE Space n968(Context&, const Env&);
static ZIPPY_NOINLINE Space n969(Context&, const Env&);
static ZIPPY_NOINLINE Path n970(Context&, const Env&);
static ZIPPY_NOINLINE Space n971(Context&, const Env&);
static ZIPPY_NOINLINE Path n972(Context&, const Env&);
static ZIPPY_NOINLINE Space n973(Context&, const Env&);
static ZIPPY_NOINLINE Space n974(Context&, const Env&);
static ZIPPY_NOINLINE Space n975(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_7(Context&, const Env&);
static ZIPPY_NOINLINE Space n976(Context&, const Env&);
static ZIPPY_NOINLINE Space n977(Context&, const Env&);
static ZIPPY_NOINLINE Space n978(Context&, const Env&);
static ZIPPY_NOINLINE Space n979(Context&, const Env&);
static ZIPPY_NOINLINE Space n980(Context&, const Env&);
static ZIPPY_NOINLINE Space n981(Context&, const Env&);
static ZIPPY_NOINLINE Space n982(Context&, const Env&);
static ZIPPY_NOINLINE Space n983(Context&, const Env&);
static ZIPPY_NOINLINE Path n984(Context&, const Env&);
static ZIPPY_NOINLINE Space n985(Context&, const Env&);
static ZIPPY_NOINLINE Path n986(Context&, const Env&);
static ZIPPY_NOINLINE Space n987(Context&, const Env&);
static ZIPPY_NOINLINE Space n988(Context&, const Env&);
static ZIPPY_NOINLINE Path n989(Context&, const Env&);
static ZIPPY_NOINLINE Path n990(Context&, const Env&);
static ZIPPY_NOINLINE Path n991(Context&, const Env&);
static ZIPPY_NOINLINE Path n992(Context&, const Env&);
static ZIPPY_NOINLINE Space n993(Context&, const Env&);
static ZIPPY_NOINLINE Space n994(Context&, const Env&);
static ZIPPY_NOINLINE Space n995(Context&, const Env&);
static ZIPPY_NOINLINE Space n996(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context& c, const Env& e) { return Path{2,1,2,1,1,1,1,1,1,2,2}; }
static ZIPPY_NOINLINE Path n4(Context& c, const Env& e) { return Path{2,2}; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto p=n4(c,e); return unwrap(n5(c,e),p); }
static ZIPPY_NOINLINE Path n12(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return singleton(n12(c,e)); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { return singleton(n14(c,e)); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto a=n11(c,e); auto b=n13(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { return singleton(n16(c,e)); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { auto a=n10(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { return iterate(c,e,n10(c,e),1,2,n15); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { auto a=n9(c,e); auto b=n17(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { std::vector<Path> pv{n19(c,e)}; std::vector<Space> sv{n20(c,e),n21(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_10(c,n); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto a=n8(c,e); if(a.empty()) return a; return compose(a,n18(c,e)); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto a=n15(c,e); auto b=n8(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n25(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { std::vector<Path> pv{n25(c,e)}; std::vector<Space> sv{n26(c,e),n27(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_8(c,n); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { auto a=n23(c,e); if(a.empty()) return a; return compose(a,n24(c,e)); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { auto a=n7(c,e); auto b=n22(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),0,1,n6); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto p=n1(c,e); return wrap(n2(c,e),p); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return singleton(n36(c,e)); }
static ZIPPY_NOINLINE Path n38(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return singleton(n38(c,e)); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { auto a=n35(c,e); auto b=n37(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { auto a=n34(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return iterate(c,e,n34(c,e),4,5,n15); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { auto a=n33(c,e); auto b=n39(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n42(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { auto a=n42(c,e); auto b=n43(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { std::vector<Path> pv{n41(c,e)}; std::vector<Space> sv{n44(c,e),n45(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto a=n32(c,e); if(a.empty()) return a; return compose(a,n40(c,e)); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { auto a=n15(c,e); auto b=n32(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { std::vector<Path> pv{n41(c,e)}; std::vector<Space> sv{n49(c,e),n50(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_12(c,n); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { auto a=n47(c,e); if(a.empty()) return a; return compose(a,n48(c,e)); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto a=n31(c,e); auto b=n46(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return iterate(c,e,n29(c,e),3,4,n30); }
static ZIPPY_NOINLINE Space routine_10(Context& c,const Env& e) { return n28(c,e); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n59(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return singleton(n59(c,e)); }
static ZIPPY_NOINLINE Path n61(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { return singleton(n61(c,e)); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { auto a=n58(c,e); auto b=n60(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { auto a=n57(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return iterate(c,e,n57(c,e),7,8,n15); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { auto a=n56(c,e); auto b=n62(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n65(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n64(Context& c, const Env& e) { auto a=n65(c,e); auto b=n66(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { std::vector<Path> pv{n64(c,e)}; std::vector<Space> sv{n67(c,e),n68(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { auto a=n55(c,e); if(a.empty()) return a; return compose(a,n63(c,e)); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { auto a=n15(c,e); auto b=n55(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { std::vector<Path> pv{n64(c,e)}; std::vector<Space> sv{n72(c,e),n73(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_12(c,n); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { auto a=n70(c,e); if(a.empty()) return a; return compose(a,n71(c,e)); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { auto a=n54(c,e); auto b=n69(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { return iterate(c,e,n52(c,e),6,7,n53); }
static ZIPPY_NOINLINE Space routine_8(Context& c,const Env& e) { return n51(c,e); }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { return singleton(n82(c,e)); }
static ZIPPY_NOINLINE Path n84(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return singleton(n84(c,e)); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { auto a=n81(c,e); auto b=n83(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { auto a=n80(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return iterate(c,e,n80(c,e),9,10,n15); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { auto a=n79(c,e); auto b=n85(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n88(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { std::vector<Path> pv{n87(c,e),n88(c,e)}; std::vector<Space> sv{n89(c,e),n90(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_11(c,n); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { auto a=n78(c,e); if(a.empty()) return a; return compose(a,n86(c,e)); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { auto a=n15(c,e); auto b=n78(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n94(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n95(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { std::vector<Path> pv{n94(c,e),n95(c,e)}; std::vector<Space> sv{n96(c,e),n97(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_9(c,n); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { auto a=n92(c,e); if(a.empty()) return a; return compose(a,n93(c,e)); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { auto a=n77(c,e); auto b=n91(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { return iterate(c,e,n75(c,e),8,9,n76); }
static ZIPPY_NOINLINE Space routine_44(Context& c,const Env& e) { return n74(c,e); }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n106(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { return singleton(n106(c,e)); }
static ZIPPY_NOINLINE Path n108(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { return singleton(n108(c,e)); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { auto a=n105(c,e); auto b=n107(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { auto a=n104(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { return iterate(c,e,n104(c,e),12,13,n15); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { auto a=n103(c,e); auto b=n109(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n112(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n111(Context& c, const Env& e) { auto a=n112(c,e); auto b=n113(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n114(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n115(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n110(Context& c, const Env& e) { std::vector<Path> pv{n111(c,e)}; std::vector<Space> sv{n114(c,e),n115(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_19(c,n); }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { auto a=n102(c,e); if(a.empty()) return a; return compose(a,n110(c,e)); }
static ZIPPY_NOINLINE Space n117(Context& c, const Env& e) { auto a=n15(c,e); auto b=n102(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n119(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n118(Context& c, const Env& e) { std::vector<Path> pv{n111(c,e)}; std::vector<Space> sv{n119(c,e),n120(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_17(c,n); }
static ZIPPY_NOINLINE Space n116(Context& c, const Env& e) { auto a=n117(c,e); if(a.empty()) return a; return compose(a,n118(c,e)); }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { auto a=n101(c,e); auto b=n116(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { return iterate(c,e,n99(c,e),11,12,n100); }
static ZIPPY_NOINLINE Space routine_12(Context& c,const Env& e) { return n98(c,e); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n129(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Space n128(Context& c, const Env& e) { return singleton(n129(c,e)); }
static ZIPPY_NOINLINE Path n131(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n130(Context& c, const Env& e) { return singleton(n131(c,e)); }
static ZIPPY_NOINLINE Space n127(Context& c, const Env& e) { auto a=n128(c,e); auto b=n130(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { auto a=n127(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n132(Context& c, const Env& e) { return iterate(c,e,n127(c,e),14,15,n15); }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { auto a=n126(c,e); auto b=n132(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n135(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n136(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n134(Context& c, const Env& e) { auto a=n135(c,e); auto b=n136(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n138(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n133(Context& c, const Env& e) { std::vector<Path> pv{n134(c,e)}; std::vector<Space> sv{n137(c,e),n138(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { auto a=n125(c,e); if(a.empty()) return a; return compose(a,n133(c,e)); }
static ZIPPY_NOINLINE Space n140(Context& c, const Env& e) { auto a=n15(c,e); auto b=n125(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n143(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { std::vector<Path> pv{n134(c,e)}; std::vector<Space> sv{n142(c,e),n143(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_17(c,n); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { auto a=n140(c,e); if(a.empty()) return a; return compose(a,n141(c,e)); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { auto a=n124(c,e); auto b=n139(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n121(Context& c, const Env& e) { return iterate(c,e,n122(c,e),13,14,n123); }
static ZIPPY_NOINLINE Space routine_15(Context& c,const Env& e) { return n121(c,e); }
static ZIPPY_NOINLINE Space n145(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n152(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Space n151(Context& c, const Env& e) { return singleton(n152(c,e)); }
static ZIPPY_NOINLINE Path n154(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n153(Context& c, const Env& e) { return singleton(n154(c,e)); }
static ZIPPY_NOINLINE Space n150(Context& c, const Env& e) { auto a=n151(c,e); auto b=n153(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n149(Context& c, const Env& e) { auto a=n150(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { return iterate(c,e,n150(c,e),16,17,n15); }
static ZIPPY_NOINLINE Space n148(Context& c, const Env& e) { auto a=n149(c,e); auto b=n155(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n158(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n159(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n157(Context& c, const Env& e) { auto a=n158(c,e); auto b=n159(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n160(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n161(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { std::vector<Path> pv{n157(c,e),n160(c,e)}; std::vector<Space> sv{n161(c,e),n162(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n147(Context& c, const Env& e) { auto a=n148(c,e); if(a.empty()) return a; return compose(a,n156(c,e)); }
static ZIPPY_NOINLINE Space n164(Context& c, const Env& e) { auto a=n15(c,e); auto b=n148(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n166(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n167(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n168(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n165(Context& c, const Env& e) { std::vector<Path> pv{n157(c,e),n166(c,e)}; std::vector<Space> sv{n167(c,e),n168(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_13(c,n); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { auto a=n164(c,e); if(a.empty()) return a; return compose(a,n165(c,e)); }
static ZIPPY_NOINLINE Space n146(Context& c, const Env& e) { auto a=n147(c,e); auto b=n163(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n144(Context& c, const Env& e) { return iterate(c,e,n145(c,e),15,16,n146); }
static ZIPPY_NOINLINE Space routine_11(Context& c,const Env& e) { return n144(c,e); }
static ZIPPY_NOINLINE Space n170(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n177(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Space n176(Context& c, const Env& e) { return singleton(n177(c,e)); }
static ZIPPY_NOINLINE Path n179(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { return singleton(n179(c,e)); }
static ZIPPY_NOINLINE Space n175(Context& c, const Env& e) { auto a=n176(c,e); auto b=n178(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n174(Context& c, const Env& e) { auto a=n175(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n180(Context& c, const Env& e) { return iterate(c,e,n175(c,e),19,20,n15); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { auto a=n174(c,e); auto b=n180(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n183(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n184(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n182(Context& c, const Env& e) { auto a=n183(c,e); auto b=n184(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n185(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n186(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n187(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n181(Context& c, const Env& e) { std::vector<Path> pv{n182(c,e),n185(c,e)}; std::vector<Space> sv{n186(c,e),n187(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_14(c,n); }
static ZIPPY_NOINLINE Space n172(Context& c, const Env& e) { auto a=n173(c,e); if(a.empty()) return a; return compose(a,n181(c,e)); }
static ZIPPY_NOINLINE Space n189(Context& c, const Env& e) { auto a=n15(c,e); auto b=n173(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n191(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n192(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n190(Context& c, const Env& e) { std::vector<Path> pv{n182(c,e),n191(c,e)}; std::vector<Space> sv{n192(c,e),n193(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_13(c,n); }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { auto a=n189(c,e); if(a.empty()) return a; return compose(a,n190(c,e)); }
static ZIPPY_NOINLINE Space n171(Context& c, const Env& e) { auto a=n172(c,e); auto b=n188(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n169(Context& c, const Env& e) { return iterate(c,e,n170(c,e),18,19,n171); }
static ZIPPY_NOINLINE Space routine_9(Context& c,const Env& e) { return n169(c,e); }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n202(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Space n201(Context& c, const Env& e) { return singleton(n202(c,e)); }
static ZIPPY_NOINLINE Path n204(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { return singleton(n204(c,e)); }
static ZIPPY_NOINLINE Space n200(Context& c, const Env& e) { auto a=n201(c,e); auto b=n203(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n199(Context& c, const Env& e) { auto a=n200(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n205(Context& c, const Env& e) { return iterate(c,e,n200(c,e),21,22,n15); }
static ZIPPY_NOINLINE Space n198(Context& c, const Env& e) { auto a=n199(c,e); auto b=n205(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n208(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n209(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n207(Context& c, const Env& e) { auto a=n208(c,e); auto b=n209(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n210(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n211(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { std::vector<Path> pv{n207(c,e)}; std::vector<Space> sv{n210(c,e),n211(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n197(Context& c, const Env& e) { auto a=n198(c,e); if(a.empty()) return a; return compose(a,n206(c,e)); }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { auto a=n15(c,e); auto b=n198(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n214(Context& c, const Env& e) { std::vector<Path> pv{n207(c,e)}; std::vector<Space> sv{n215(c,e),n216(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_21(c,n); }
static ZIPPY_NOINLINE Space n212(Context& c, const Env& e) { auto a=n213(c,e); if(a.empty()) return a; return compose(a,n214(c,e)); }
static ZIPPY_NOINLINE Space n196(Context& c, const Env& e) { auto a=n197(c,e); auto b=n212(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n194(Context& c, const Env& e) { return iterate(c,e,n195(c,e),20,21,n196); }
static ZIPPY_NOINLINE Space routine_19(Context& c,const Env& e) { return n194(c,e); }
static ZIPPY_NOINLINE Space n218(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n225(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Space n224(Context& c, const Env& e) { return singleton(n225(c,e)); }
static ZIPPY_NOINLINE Path n227(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n226(Context& c, const Env& e) { return singleton(n227(c,e)); }
static ZIPPY_NOINLINE Space n223(Context& c, const Env& e) { auto a=n224(c,e); auto b=n226(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n222(Context& c, const Env& e) { auto a=n223(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n228(Context& c, const Env& e) { return iterate(c,e,n223(c,e),23,24,n15); }
static ZIPPY_NOINLINE Space n221(Context& c, const Env& e) { auto a=n222(c,e); auto b=n228(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n231(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n232(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n230(Context& c, const Env& e) { auto a=n231(c,e); auto b=n232(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n233(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Space n234(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n229(Context& c, const Env& e) { std::vector<Path> pv{n230(c,e)}; std::vector<Space> sv{n233(c,e),n234(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_22(c,n); }
static ZIPPY_NOINLINE Space n220(Context& c, const Env& e) { auto a=n221(c,e); if(a.empty()) return a; return compose(a,n229(c,e)); }
static ZIPPY_NOINLINE Space n236(Context& c, const Env& e) { auto a=n15(c,e); auto b=n221(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n238(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Space n239(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n237(Context& c, const Env& e) { std::vector<Path> pv{n230(c,e)}; std::vector<Space> sv{n238(c,e),n239(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_21(c,n); }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { auto a=n236(c,e); if(a.empty()) return a; return compose(a,n237(c,e)); }
static ZIPPY_NOINLINE Space n219(Context& c, const Env& e) { auto a=n220(c,e); auto b=n235(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n217(Context& c, const Env& e) { return iterate(c,e,n218(c,e),22,23,n219); }
static ZIPPY_NOINLINE Space routine_17(Context& c,const Env& e) { return n217(c,e); }
static ZIPPY_NOINLINE Path n241(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n243(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n245(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n247(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n249(Context& c, const Env& e) { return Path{2,2}; }
static ZIPPY_NOINLINE Space n250(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n248(Context& c, const Env& e) { auto p=n249(c,e); return unwrap(n250(c,e),p); }
static ZIPPY_NOINLINE Space n246(Context& c, const Env& e) { auto p=n247(c,e); return unwrap(n248(c,e),p); }
static ZIPPY_NOINLINE Space n244(Context& c, const Env& e) { auto p=n245(c,e); return unwrap(n246(c,e),p); }
static ZIPPY_NOINLINE Space n242(Context& c, const Env& e) { auto p=n243(c,e); return wrap(n244(c,e),p); }
static ZIPPY_NOINLINE Space n240(Context& c, const Env& e) { auto p=n241(c,e); return wrap(n242(c,e),p); }
static ZIPPY_NOINLINE Space routine_45(Context& c,const Env& e) { return n240(c,e); }
static ZIPPY_NOINLINE Space n252(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n259(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n258(Context& c, const Env& e) { return singleton(n259(c,e)); }
static ZIPPY_NOINLINE Path n261(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n260(Context& c, const Env& e) { return singleton(n261(c,e)); }
static ZIPPY_NOINLINE Space n257(Context& c, const Env& e) { auto a=n258(c,e); auto b=n260(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n256(Context& c, const Env& e) { auto a=n257(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n262(Context& c, const Env& e) { return iterate(c,e,n257(c,e),25,26,n15); }
static ZIPPY_NOINLINE Space n255(Context& c, const Env& e) { auto a=n256(c,e); auto b=n262(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n265(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n266(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n264(Context& c, const Env& e) { auto a=n265(c,e); auto b=n266(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n267(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n268(Context& c, const Env& e) { return e.spaces.at(25); }
static ZIPPY_NOINLINE Space n269(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n263(Context& c, const Env& e) { std::vector<Path> pv{n264(c,e),n267(c,e)}; std::vector<Space> sv{n268(c,e),n269(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_18(c,n); }
static ZIPPY_NOINLINE Space n254(Context& c, const Env& e) { auto a=n255(c,e); if(a.empty()) return a; return compose(a,n263(c,e)); }
static ZIPPY_NOINLINE Space n271(Context& c, const Env& e) { auto a=n15(c,e); auto b=n255(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n273(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n274(Context& c, const Env& e) { return e.spaces.at(25); }
static ZIPPY_NOINLINE Space n275(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n272(Context& c, const Env& e) { std::vector<Path> pv{n264(c,e),n273(c,e)}; std::vector<Space> sv{n274(c,e),n275(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n270(Context& c, const Env& e) { auto a=n271(c,e); if(a.empty()) return a; return compose(a,n272(c,e)); }
static ZIPPY_NOINLINE Space n253(Context& c, const Env& e) { auto a=n254(c,e); auto b=n270(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n251(Context& c, const Env& e) { return iterate(c,e,n252(c,e),24,25,n253); }
static ZIPPY_NOINLINE Space routine_13(Context& c,const Env& e) { return n251(c,e); }
static ZIPPY_NOINLINE Space n277(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n284(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Space n283(Context& c, const Env& e) { return singleton(n284(c,e)); }
static ZIPPY_NOINLINE Path n286(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n285(Context& c, const Env& e) { return singleton(n286(c,e)); }
static ZIPPY_NOINLINE Space n282(Context& c, const Env& e) { auto a=n283(c,e); auto b=n285(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n281(Context& c, const Env& e) { auto a=n282(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n287(Context& c, const Env& e) { return iterate(c,e,n282(c,e),27,28,n15); }
static ZIPPY_NOINLINE Space n280(Context& c, const Env& e) { auto a=n281(c,e); auto b=n287(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n290(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n291(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n289(Context& c, const Env& e) { auto a=n290(c,e); auto b=n291(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n292(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n293(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n294(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n288(Context& c, const Env& e) { std::vector<Path> pv{n289(c,e),n292(c,e)}; std::vector<Space> sv{n293(c,e),n294(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { auto a=n280(c,e); if(a.empty()) return a; return compose(a,n288(c,e)); }
static ZIPPY_NOINLINE Space n296(Context& c, const Env& e) { auto a=n15(c,e); auto b=n280(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n298(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n299(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n300(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n297(Context& c, const Env& e) { std::vector<Path> pv{n289(c,e),n298(c,e)}; std::vector<Space> sv{n299(c,e),n300(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n295(Context& c, const Env& e) { auto a=n296(c,e); if(a.empty()) return a; return compose(a,n297(c,e)); }
static ZIPPY_NOINLINE Space n278(Context& c, const Env& e) { auto a=n279(c,e); auto b=n295(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n276(Context& c, const Env& e) { return iterate(c,e,n277(c,e),26,27,n278); }
static ZIPPY_NOINLINE Space routine_14(Context& c,const Env& e) { return n276(c,e); }
static ZIPPY_NOINLINE Space n302(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n309(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Space n308(Context& c, const Env& e) { return singleton(n309(c,e)); }
static ZIPPY_NOINLINE Path n311(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n310(Context& c, const Env& e) { return singleton(n311(c,e)); }
static ZIPPY_NOINLINE Space n307(Context& c, const Env& e) { auto a=n308(c,e); auto b=n310(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n306(Context& c, const Env& e) { auto a=n307(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n312(Context& c, const Env& e) { return iterate(c,e,n307(c,e),29,30,n15); }
static ZIPPY_NOINLINE Space n305(Context& c, const Env& e) { auto a=n306(c,e); auto b=n312(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n315(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n316(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n314(Context& c, const Env& e) { auto a=n315(c,e); auto b=n316(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n317(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n318(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n313(Context& c, const Env& e) { std::vector<Path> pv{n314(c,e)}; std::vector<Space> sv{n317(c,e),n318(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_26(c,n); }
static ZIPPY_NOINLINE Space n304(Context& c, const Env& e) { auto a=n305(c,e); if(a.empty()) return a; return compose(a,n313(c,e)); }
static ZIPPY_NOINLINE Space n320(Context& c, const Env& e) { auto a=n15(c,e); auto b=n305(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n322(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n323(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n321(Context& c, const Env& e) { std::vector<Path> pv{n314(c,e)}; std::vector<Space> sv{n322(c,e),n323(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_24(c,n); }
static ZIPPY_NOINLINE Space n319(Context& c, const Env& e) { auto a=n320(c,e); if(a.empty()) return a; return compose(a,n321(c,e)); }
static ZIPPY_NOINLINE Space n303(Context& c, const Env& e) { auto a=n304(c,e); auto b=n319(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n301(Context& c, const Env& e) { return iterate(c,e,n302(c,e),28,29,n303); }
static ZIPPY_NOINLINE Space routine_21(Context& c,const Env& e) { return n301(c,e); }
static ZIPPY_NOINLINE Space n325(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n332(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Space n331(Context& c, const Env& e) { return singleton(n332(c,e)); }
static ZIPPY_NOINLINE Path n334(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n333(Context& c, const Env& e) { return singleton(n334(c,e)); }
static ZIPPY_NOINLINE Space n330(Context& c, const Env& e) { auto a=n331(c,e); auto b=n333(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n329(Context& c, const Env& e) { auto a=n330(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n335(Context& c, const Env& e) { return iterate(c,e,n330(c,e),31,32,n15); }
static ZIPPY_NOINLINE Space n328(Context& c, const Env& e) { auto a=n329(c,e); auto b=n335(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n338(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n339(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Path n337(Context& c, const Env& e) { auto a=n338(c,e); auto b=n339(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n340(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Space n341(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n336(Context& c, const Env& e) { std::vector<Path> pv{n337(c,e)}; std::vector<Space> sv{n340(c,e),n341(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n327(Context& c, const Env& e) { auto a=n328(c,e); if(a.empty()) return a; return compose(a,n336(c,e)); }
static ZIPPY_NOINLINE Space n343(Context& c, const Env& e) { auto a=n15(c,e); auto b=n328(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n345(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Space n346(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n344(Context& c, const Env& e) { std::vector<Path> pv{n337(c,e)}; std::vector<Space> sv{n345(c,e),n346(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_24(c,n); }
static ZIPPY_NOINLINE Space n342(Context& c, const Env& e) { auto a=n343(c,e); if(a.empty()) return a; return compose(a,n344(c,e)); }
static ZIPPY_NOINLINE Space n326(Context& c, const Env& e) { auto a=n327(c,e); auto b=n342(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n324(Context& c, const Env& e) { return iterate(c,e,n325(c,e),30,31,n326); }
static ZIPPY_NOINLINE Space routine_22(Context& c,const Env& e) { return n324(c,e); }
static ZIPPY_NOINLINE Space n348(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n355(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Space n354(Context& c, const Env& e) { return singleton(n355(c,e)); }
static ZIPPY_NOINLINE Path n357(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n356(Context& c, const Env& e) { return singleton(n357(c,e)); }
static ZIPPY_NOINLINE Space n353(Context& c, const Env& e) { auto a=n354(c,e); auto b=n356(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n352(Context& c, const Env& e) { auto a=n353(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n358(Context& c, const Env& e) { return iterate(c,e,n353(c,e),33,34,n15); }
static ZIPPY_NOINLINE Space n351(Context& c, const Env& e) { auto a=n352(c,e); auto b=n358(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n361(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n362(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n360(Context& c, const Env& e) { auto a=n361(c,e); auto b=n362(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n363(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n364(Context& c, const Env& e) { return e.spaces.at(33); }
static ZIPPY_NOINLINE Space n365(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n359(Context& c, const Env& e) { std::vector<Path> pv{n360(c,e),n363(c,e)}; std::vector<Space> sv{n364(c,e),n365(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n350(Context& c, const Env& e) { auto a=n351(c,e); if(a.empty()) return a; return compose(a,n359(c,e)); }
static ZIPPY_NOINLINE Space n367(Context& c, const Env& e) { auto a=n15(c,e); auto b=n351(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n369(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n370(Context& c, const Env& e) { return e.spaces.at(33); }
static ZIPPY_NOINLINE Space n371(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n368(Context& c, const Env& e) { std::vector<Path> pv{n360(c,e),n369(c,e)}; std::vector<Space> sv{n370(c,e),n371(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_20(c,n); }
static ZIPPY_NOINLINE Space n366(Context& c, const Env& e) { auto a=n367(c,e); if(a.empty()) return a; return compose(a,n368(c,e)); }
static ZIPPY_NOINLINE Space n349(Context& c, const Env& e) { auto a=n350(c,e); auto b=n366(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n347(Context& c, const Env& e) { return iterate(c,e,n348(c,e),32,33,n349); }
static ZIPPY_NOINLINE Space routine_18(Context& c,const Env& e) { return n347(c,e); }
static ZIPPY_NOINLINE Space n373(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n380(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Space n379(Context& c, const Env& e) { return singleton(n380(c,e)); }
static ZIPPY_NOINLINE Path n382(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n381(Context& c, const Env& e) { return singleton(n382(c,e)); }
static ZIPPY_NOINLINE Space n378(Context& c, const Env& e) { auto a=n379(c,e); auto b=n381(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n377(Context& c, const Env& e) { auto a=n378(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n383(Context& c, const Env& e) { return iterate(c,e,n378(c,e),35,36,n15); }
static ZIPPY_NOINLINE Space n376(Context& c, const Env& e) { auto a=n377(c,e); auto b=n383(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n386(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n387(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Path n385(Context& c, const Env& e) { auto a=n386(c,e); auto b=n387(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n388(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n389(Context& c, const Env& e) { return e.spaces.at(35); }
static ZIPPY_NOINLINE Space n390(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n384(Context& c, const Env& e) { std::vector<Path> pv{n385(c,e),n388(c,e)}; std::vector<Space> sv{n389(c,e),n390(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_23(c,n); }
static ZIPPY_NOINLINE Space n375(Context& c, const Env& e) { auto a=n376(c,e); if(a.empty()) return a; return compose(a,n384(c,e)); }
static ZIPPY_NOINLINE Space n392(Context& c, const Env& e) { auto a=n15(c,e); auto b=n376(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n394(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n395(Context& c, const Env& e) { return e.spaces.at(35); }
static ZIPPY_NOINLINE Space n396(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n393(Context& c, const Env& e) { std::vector<Path> pv{n385(c,e),n394(c,e)}; std::vector<Space> sv{n395(c,e),n396(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_20(c,n); }
static ZIPPY_NOINLINE Space n391(Context& c, const Env& e) { auto a=n392(c,e); if(a.empty()) return a; return compose(a,n393(c,e)); }
static ZIPPY_NOINLINE Space n374(Context& c, const Env& e) { auto a=n375(c,e); auto b=n391(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n372(Context& c, const Env& e) { return iterate(c,e,n373(c,e),34,35,n374); }
static ZIPPY_NOINLINE Space routine_16(Context& c,const Env& e) { return n372(c,e); }
static ZIPPY_NOINLINE Space n398(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n405(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Space n404(Context& c, const Env& e) { return singleton(n405(c,e)); }
static ZIPPY_NOINLINE Path n407(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n406(Context& c, const Env& e) { return singleton(n407(c,e)); }
static ZIPPY_NOINLINE Space n403(Context& c, const Env& e) { auto a=n404(c,e); auto b=n406(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n402(Context& c, const Env& e) { auto a=n403(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n408(Context& c, const Env& e) { return iterate(c,e,n403(c,e),37,38,n15); }
static ZIPPY_NOINLINE Space n401(Context& c, const Env& e) { auto a=n402(c,e); auto b=n408(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n411(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n412(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Path n410(Context& c, const Env& e) { auto a=n411(c,e); auto b=n412(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n413(Context& c, const Env& e) { return e.spaces.at(37); }
static ZIPPY_NOINLINE Space n414(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n409(Context& c, const Env& e) { std::vector<Path> pv{n410(c,e)}; std::vector<Space> sv{n413(c,e),n414(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n400(Context& c, const Env& e) { auto a=n401(c,e); if(a.empty()) return a; return compose(a,n409(c,e)); }
static ZIPPY_NOINLINE Space n416(Context& c, const Env& e) { auto a=n15(c,e); auto b=n401(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n418(Context& c, const Env& e) { return e.spaces.at(37); }
static ZIPPY_NOINLINE Space n419(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n417(Context& c, const Env& e) { std::vector<Path> pv{n410(c,e)}; std::vector<Space> sv{n418(c,e),n419(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_28(c,n); }
static ZIPPY_NOINLINE Space n415(Context& c, const Env& e) { auto a=n416(c,e); if(a.empty()) return a; return compose(a,n417(c,e)); }
static ZIPPY_NOINLINE Space n399(Context& c, const Env& e) { auto a=n400(c,e); auto b=n415(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n397(Context& c, const Env& e) { return iterate(c,e,n398(c,e),36,37,n399); }
static ZIPPY_NOINLINE Space routine_26(Context& c,const Env& e) { return n397(c,e); }
static ZIPPY_NOINLINE Space n421(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n428(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Space n427(Context& c, const Env& e) { return singleton(n428(c,e)); }
static ZIPPY_NOINLINE Path n430(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n429(Context& c, const Env& e) { return singleton(n430(c,e)); }
static ZIPPY_NOINLINE Space n426(Context& c, const Env& e) { auto a=n427(c,e); auto b=n429(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n425(Context& c, const Env& e) { auto a=n426(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n431(Context& c, const Env& e) { return iterate(c,e,n426(c,e),39,40,n15); }
static ZIPPY_NOINLINE Space n424(Context& c, const Env& e) { auto a=n425(c,e); auto b=n431(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n434(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n435(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Path n433(Context& c, const Env& e) { auto a=n434(c,e); auto b=n435(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n436(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n437(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n432(Context& c, const Env& e) { std::vector<Path> pv{n433(c,e)}; std::vector<Space> sv{n436(c,e),n437(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_30(c,n); }
static ZIPPY_NOINLINE Space n423(Context& c, const Env& e) { auto a=n424(c,e); if(a.empty()) return a; return compose(a,n432(c,e)); }
static ZIPPY_NOINLINE Space n439(Context& c, const Env& e) { auto a=n15(c,e); auto b=n424(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n441(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n442(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n440(Context& c, const Env& e) { std::vector<Path> pv{n433(c,e)}; std::vector<Space> sv{n441(c,e),n442(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_28(c,n); }
static ZIPPY_NOINLINE Space n438(Context& c, const Env& e) { auto a=n439(c,e); if(a.empty()) return a; return compose(a,n440(c,e)); }
static ZIPPY_NOINLINE Space n422(Context& c, const Env& e) { auto a=n423(c,e); auto b=n438(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n420(Context& c, const Env& e) { return iterate(c,e,n421(c,e),38,39,n422); }
static ZIPPY_NOINLINE Space routine_24(Context& c,const Env& e) { return n420(c,e); }
static ZIPPY_NOINLINE Space n444(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n451(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Space n450(Context& c, const Env& e) { return singleton(n451(c,e)); }
static ZIPPY_NOINLINE Path n453(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n452(Context& c, const Env& e) { return singleton(n453(c,e)); }
static ZIPPY_NOINLINE Space n449(Context& c, const Env& e) { auto a=n450(c,e); auto b=n452(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n448(Context& c, const Env& e) { auto a=n449(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n454(Context& c, const Env& e) { return iterate(c,e,n449(c,e),41,42,n15); }
static ZIPPY_NOINLINE Space n447(Context& c, const Env& e) { auto a=n448(c,e); auto b=n454(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n457(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n458(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n456(Context& c, const Env& e) { auto a=n457(c,e); auto b=n458(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n459(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n460(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n461(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n455(Context& c, const Env& e) { std::vector<Path> pv{n456(c,e),n459(c,e)}; std::vector<Space> sv{n460(c,e),n461(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_27(c,n); }
static ZIPPY_NOINLINE Space n446(Context& c, const Env& e) { auto a=n447(c,e); if(a.empty()) return a; return compose(a,n455(c,e)); }
static ZIPPY_NOINLINE Space n463(Context& c, const Env& e) { auto a=n15(c,e); auto b=n447(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n465(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n466(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n467(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n464(Context& c, const Env& e) { std::vector<Path> pv{n456(c,e),n465(c,e)}; std::vector<Space> sv{n466(c,e),n467(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_25(c,n); }
static ZIPPY_NOINLINE Space n462(Context& c, const Env& e) { auto a=n463(c,e); if(a.empty()) return a; return compose(a,n464(c,e)); }
static ZIPPY_NOINLINE Space n445(Context& c, const Env& e) { auto a=n446(c,e); auto b=n462(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n443(Context& c, const Env& e) { return iterate(c,e,n444(c,e),40,41,n445); }
static ZIPPY_NOINLINE Space routine_20(Context& c,const Env& e) { return n443(c,e); }
static ZIPPY_NOINLINE Space n469(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n476(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Space n475(Context& c, const Env& e) { return singleton(n476(c,e)); }
static ZIPPY_NOINLINE Path n478(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n477(Context& c, const Env& e) { return singleton(n478(c,e)); }
static ZIPPY_NOINLINE Space n474(Context& c, const Env& e) { auto a=n475(c,e); auto b=n477(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n473(Context& c, const Env& e) { auto a=n474(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n479(Context& c, const Env& e) { return iterate(c,e,n474(c,e),43,44,n15); }
static ZIPPY_NOINLINE Space n472(Context& c, const Env& e) { auto a=n473(c,e); auto b=n479(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n482(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n483(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Path n481(Context& c, const Env& e) { auto a=n482(c,e); auto b=n483(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n484(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n485(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n486(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n480(Context& c, const Env& e) { std::vector<Path> pv{n481(c,e),n484(c,e)}; std::vector<Space> sv{n485(c,e),n486(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n471(Context& c, const Env& e) { auto a=n472(c,e); if(a.empty()) return a; return compose(a,n480(c,e)); }
static ZIPPY_NOINLINE Space n488(Context& c, const Env& e) { auto a=n15(c,e); auto b=n472(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n490(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n491(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n492(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n489(Context& c, const Env& e) { std::vector<Path> pv{n481(c,e),n490(c,e)}; std::vector<Space> sv{n491(c,e),n492(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_25(c,n); }
static ZIPPY_NOINLINE Space n487(Context& c, const Env& e) { auto a=n488(c,e); if(a.empty()) return a; return compose(a,n489(c,e)); }
static ZIPPY_NOINLINE Space n470(Context& c, const Env& e) { auto a=n471(c,e); auto b=n487(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n468(Context& c, const Env& e) { return iterate(c,e,n469(c,e),42,43,n470); }
static ZIPPY_NOINLINE Space routine_23(Context& c,const Env& e) { return n468(c,e); }
static ZIPPY_NOINLINE Space n494(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n501(Context& c, const Env& e) { return e.paths.at(44); }
static ZIPPY_NOINLINE Space n500(Context& c, const Env& e) { return singleton(n501(c,e)); }
static ZIPPY_NOINLINE Path n503(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n502(Context& c, const Env& e) { return singleton(n503(c,e)); }
static ZIPPY_NOINLINE Space n499(Context& c, const Env& e) { auto a=n500(c,e); auto b=n502(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n498(Context& c, const Env& e) { auto a=n499(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n504(Context& c, const Env& e) { return iterate(c,e,n499(c,e),45,46,n15); }
static ZIPPY_NOINLINE Space n497(Context& c, const Env& e) { auto a=n498(c,e); auto b=n504(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n507(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n508(Context& c, const Env& e) { return e.paths.at(44); }
static ZIPPY_NOINLINE Path n506(Context& c, const Env& e) { auto a=n507(c,e); auto b=n508(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n509(Context& c, const Env& e) { return e.spaces.at(45); }
static ZIPPY_NOINLINE Space n510(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n505(Context& c, const Env& e) { std::vector<Path> pv{n506(c,e)}; std::vector<Space> sv{n509(c,e),n510(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_34(c,n); }
static ZIPPY_NOINLINE Space n496(Context& c, const Env& e) { auto a=n497(c,e); if(a.empty()) return a; return compose(a,n505(c,e)); }
static ZIPPY_NOINLINE Space n512(Context& c, const Env& e) { auto a=n15(c,e); auto b=n497(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n514(Context& c, const Env& e) { return e.spaces.at(45); }
static ZIPPY_NOINLINE Space n515(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n513(Context& c, const Env& e) { std::vector<Path> pv{n506(c,e)}; std::vector<Space> sv{n514(c,e),n515(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_32(c,n); }
static ZIPPY_NOINLINE Space n511(Context& c, const Env& e) { auto a=n512(c,e); if(a.empty()) return a; return compose(a,n513(c,e)); }
static ZIPPY_NOINLINE Space n495(Context& c, const Env& e) { auto a=n496(c,e); auto b=n511(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n493(Context& c, const Env& e) { return iterate(c,e,n494(c,e),44,45,n495); }
static ZIPPY_NOINLINE Space routine_28(Context& c,const Env& e) { return n493(c,e); }
static ZIPPY_NOINLINE Space n517(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n524(Context& c, const Env& e) { return e.paths.at(46); }
static ZIPPY_NOINLINE Space n523(Context& c, const Env& e) { return singleton(n524(c,e)); }
static ZIPPY_NOINLINE Path n526(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n525(Context& c, const Env& e) { return singleton(n526(c,e)); }
static ZIPPY_NOINLINE Space n522(Context& c, const Env& e) { auto a=n523(c,e); auto b=n525(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n521(Context& c, const Env& e) { auto a=n522(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n527(Context& c, const Env& e) { return iterate(c,e,n522(c,e),47,48,n15); }
static ZIPPY_NOINLINE Space n520(Context& c, const Env& e) { auto a=n521(c,e); auto b=n527(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n530(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n531(Context& c, const Env& e) { return e.paths.at(46); }
static ZIPPY_NOINLINE Path n529(Context& c, const Env& e) { auto a=n530(c,e); auto b=n531(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n532(Context& c, const Env& e) { return e.spaces.at(47); }
static ZIPPY_NOINLINE Space n533(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n528(Context& c, const Env& e) { std::vector<Path> pv{n529(c,e)}; std::vector<Space> sv{n532(c,e),n533(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n519(Context& c, const Env& e) { auto a=n520(c,e); if(a.empty()) return a; return compose(a,n528(c,e)); }
static ZIPPY_NOINLINE Space n535(Context& c, const Env& e) { auto a=n15(c,e); auto b=n520(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n537(Context& c, const Env& e) { return e.spaces.at(47); }
static ZIPPY_NOINLINE Space n538(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n536(Context& c, const Env& e) { std::vector<Path> pv{n529(c,e)}; std::vector<Space> sv{n537(c,e),n538(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_32(c,n); }
static ZIPPY_NOINLINE Space n534(Context& c, const Env& e) { auto a=n535(c,e); if(a.empty()) return a; return compose(a,n536(c,e)); }
static ZIPPY_NOINLINE Space n518(Context& c, const Env& e) { auto a=n519(c,e); auto b=n534(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n516(Context& c, const Env& e) { return iterate(c,e,n517(c,e),46,47,n518); }
static ZIPPY_NOINLINE Space routine_30(Context& c,const Env& e) { return n516(c,e); }
static ZIPPY_NOINLINE Space n540(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n547(Context& c, const Env& e) { return e.paths.at(48); }
static ZIPPY_NOINLINE Space n546(Context& c, const Env& e) { return singleton(n547(c,e)); }
static ZIPPY_NOINLINE Path n549(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n548(Context& c, const Env& e) { return singleton(n549(c,e)); }
static ZIPPY_NOINLINE Space n545(Context& c, const Env& e) { auto a=n546(c,e); auto b=n548(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n544(Context& c, const Env& e) { auto a=n545(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n550(Context& c, const Env& e) { return iterate(c,e,n545(c,e),49,50,n15); }
static ZIPPY_NOINLINE Space n543(Context& c, const Env& e) { auto a=n544(c,e); auto b=n550(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n553(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n554(Context& c, const Env& e) { return e.paths.at(48); }
static ZIPPY_NOINLINE Path n552(Context& c, const Env& e) { auto a=n553(c,e); auto b=n554(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n555(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n556(Context& c, const Env& e) { return e.spaces.at(49); }
static ZIPPY_NOINLINE Space n557(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n551(Context& c, const Env& e) { std::vector<Path> pv{n552(c,e),n555(c,e)}; std::vector<Space> sv{n556(c,e),n557(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n542(Context& c, const Env& e) { auto a=n543(c,e); if(a.empty()) return a; return compose(a,n551(c,e)); }
static ZIPPY_NOINLINE Space n559(Context& c, const Env& e) { auto a=n15(c,e); auto b=n543(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n561(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n562(Context& c, const Env& e) { return e.spaces.at(49); }
static ZIPPY_NOINLINE Space n563(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n560(Context& c, const Env& e) { std::vector<Path> pv{n552(c,e),n561(c,e)}; std::vector<Space> sv{n562(c,e),n563(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_29(c,n); }
static ZIPPY_NOINLINE Space n558(Context& c, const Env& e) { auto a=n559(c,e); if(a.empty()) return a; return compose(a,n560(c,e)); }
static ZIPPY_NOINLINE Space n541(Context& c, const Env& e) { auto a=n542(c,e); auto b=n558(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n539(Context& c, const Env& e) { return iterate(c,e,n540(c,e),48,49,n541); }
static ZIPPY_NOINLINE Space routine_27(Context& c,const Env& e) { return n539(c,e); }
static ZIPPY_NOINLINE Space n565(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n572(Context& c, const Env& e) { return e.paths.at(50); }
static ZIPPY_NOINLINE Space n571(Context& c, const Env& e) { return singleton(n572(c,e)); }
static ZIPPY_NOINLINE Path n574(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n573(Context& c, const Env& e) { return singleton(n574(c,e)); }
static ZIPPY_NOINLINE Space n570(Context& c, const Env& e) { auto a=n571(c,e); auto b=n573(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n569(Context& c, const Env& e) { auto a=n570(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n575(Context& c, const Env& e) { return iterate(c,e,n570(c,e),51,52,n15); }
static ZIPPY_NOINLINE Space n568(Context& c, const Env& e) { auto a=n569(c,e); auto b=n575(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n578(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n579(Context& c, const Env& e) { return e.paths.at(50); }
static ZIPPY_NOINLINE Path n577(Context& c, const Env& e) { auto a=n578(c,e); auto b=n579(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n580(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n581(Context& c, const Env& e) { return e.spaces.at(51); }
static ZIPPY_NOINLINE Space n582(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n576(Context& c, const Env& e) { std::vector<Path> pv{n577(c,e),n580(c,e)}; std::vector<Space> sv{n581(c,e),n582(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_31(c,n); }
static ZIPPY_NOINLINE Space n567(Context& c, const Env& e) { auto a=n568(c,e); if(a.empty()) return a; return compose(a,n576(c,e)); }
static ZIPPY_NOINLINE Space n584(Context& c, const Env& e) { auto a=n15(c,e); auto b=n568(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n586(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n587(Context& c, const Env& e) { return e.spaces.at(51); }
static ZIPPY_NOINLINE Space n588(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n585(Context& c, const Env& e) { std::vector<Path> pv{n577(c,e),n586(c,e)}; std::vector<Space> sv{n587(c,e),n588(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_29(c,n); }
static ZIPPY_NOINLINE Space n583(Context& c, const Env& e) { auto a=n584(c,e); if(a.empty()) return a; return compose(a,n585(c,e)); }
static ZIPPY_NOINLINE Space n566(Context& c, const Env& e) { auto a=n567(c,e); auto b=n583(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n564(Context& c, const Env& e) { return iterate(c,e,n565(c,e),50,51,n566); }
static ZIPPY_NOINLINE Space routine_25(Context& c,const Env& e) { return n564(c,e); }
static ZIPPY_NOINLINE Space n590(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n597(Context& c, const Env& e) { return e.paths.at(52); }
static ZIPPY_NOINLINE Space n596(Context& c, const Env& e) { return singleton(n597(c,e)); }
static ZIPPY_NOINLINE Path n599(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n598(Context& c, const Env& e) { return singleton(n599(c,e)); }
static ZIPPY_NOINLINE Space n595(Context& c, const Env& e) { auto a=n596(c,e); auto b=n598(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n594(Context& c, const Env& e) { auto a=n595(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n600(Context& c, const Env& e) { return iterate(c,e,n595(c,e),53,54,n15); }
static ZIPPY_NOINLINE Space n593(Context& c, const Env& e) { auto a=n594(c,e); auto b=n600(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n603(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n604(Context& c, const Env& e) { return e.paths.at(52); }
static ZIPPY_NOINLINE Path n602(Context& c, const Env& e) { auto a=n603(c,e); auto b=n604(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n605(Context& c, const Env& e) { return e.spaces.at(53); }
static ZIPPY_NOINLINE Space n606(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n601(Context& c, const Env& e) { std::vector<Path> pv{n602(c,e)}; std::vector<Space> sv{n605(c,e),n606(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n592(Context& c, const Env& e) { auto a=n593(c,e); if(a.empty()) return a; return compose(a,n601(c,e)); }
static ZIPPY_NOINLINE Space n608(Context& c, const Env& e) { auto a=n15(c,e); auto b=n593(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n610(Context& c, const Env& e) { return e.spaces.at(53); }
static ZIPPY_NOINLINE Space n611(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n609(Context& c, const Env& e) { std::vector<Path> pv{n602(c,e)}; std::vector<Space> sv{n610(c,e),n611(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_36(c,n); }
static ZIPPY_NOINLINE Space n607(Context& c, const Env& e) { auto a=n608(c,e); if(a.empty()) return a; return compose(a,n609(c,e)); }
static ZIPPY_NOINLINE Space n591(Context& c, const Env& e) { auto a=n592(c,e); auto b=n607(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n589(Context& c, const Env& e) { return iterate(c,e,n590(c,e),52,53,n591); }
static ZIPPY_NOINLINE Space routine_34(Context& c,const Env& e) { return n589(c,e); }
static ZIPPY_NOINLINE Space n613(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n620(Context& c, const Env& e) { return e.paths.at(54); }
static ZIPPY_NOINLINE Space n619(Context& c, const Env& e) { return singleton(n620(c,e)); }
static ZIPPY_NOINLINE Path n622(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n621(Context& c, const Env& e) { return singleton(n622(c,e)); }
static ZIPPY_NOINLINE Space n618(Context& c, const Env& e) { auto a=n619(c,e); auto b=n621(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n617(Context& c, const Env& e) { auto a=n618(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n623(Context& c, const Env& e) { return iterate(c,e,n618(c,e),55,56,n15); }
static ZIPPY_NOINLINE Space n616(Context& c, const Env& e) { auto a=n617(c,e); auto b=n623(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n626(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n627(Context& c, const Env& e) { return e.paths.at(54); }
static ZIPPY_NOINLINE Path n625(Context& c, const Env& e) { auto a=n626(c,e); auto b=n627(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n628(Context& c, const Env& e) { return e.spaces.at(55); }
static ZIPPY_NOINLINE Space n629(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n624(Context& c, const Env& e) { std::vector<Path> pv{n625(c,e)}; std::vector<Space> sv{n628(c,e),n629(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_38(c,n); }
static ZIPPY_NOINLINE Space n615(Context& c, const Env& e) { auto a=n616(c,e); if(a.empty()) return a; return compose(a,n624(c,e)); }
static ZIPPY_NOINLINE Space n631(Context& c, const Env& e) { auto a=n15(c,e); auto b=n616(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n633(Context& c, const Env& e) { return e.spaces.at(55); }
static ZIPPY_NOINLINE Space n634(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n632(Context& c, const Env& e) { std::vector<Path> pv{n625(c,e)}; std::vector<Space> sv{n633(c,e),n634(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_36(c,n); }
static ZIPPY_NOINLINE Space n630(Context& c, const Env& e) { auto a=n631(c,e); if(a.empty()) return a; return compose(a,n632(c,e)); }
static ZIPPY_NOINLINE Space n614(Context& c, const Env& e) { auto a=n615(c,e); auto b=n630(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n612(Context& c, const Env& e) { return iterate(c,e,n613(c,e),54,55,n614); }
static ZIPPY_NOINLINE Space routine_32(Context& c,const Env& e) { return n612(c,e); }
static ZIPPY_NOINLINE Space n636(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n643(Context& c, const Env& e) { return e.paths.at(56); }
static ZIPPY_NOINLINE Space n642(Context& c, const Env& e) { return singleton(n643(c,e)); }
static ZIPPY_NOINLINE Path n645(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n644(Context& c, const Env& e) { return singleton(n645(c,e)); }
static ZIPPY_NOINLINE Space n641(Context& c, const Env& e) { auto a=n642(c,e); auto b=n644(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n640(Context& c, const Env& e) { auto a=n641(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n646(Context& c, const Env& e) { return iterate(c,e,n641(c,e),57,58,n15); }
static ZIPPY_NOINLINE Space n639(Context& c, const Env& e) { auto a=n640(c,e); auto b=n646(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n649(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n650(Context& c, const Env& e) { return e.paths.at(56); }
static ZIPPY_NOINLINE Path n648(Context& c, const Env& e) { auto a=n649(c,e); auto b=n650(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n651(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n652(Context& c, const Env& e) { return e.spaces.at(57); }
static ZIPPY_NOINLINE Space n653(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n647(Context& c, const Env& e) { std::vector<Path> pv{n648(c,e),n651(c,e)}; std::vector<Space> sv{n652(c,e),n653(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_35(c,n); }
static ZIPPY_NOINLINE Space n638(Context& c, const Env& e) { auto a=n639(c,e); if(a.empty()) return a; return compose(a,n647(c,e)); }
static ZIPPY_NOINLINE Space n655(Context& c, const Env& e) { auto a=n15(c,e); auto b=n639(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n657(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n658(Context& c, const Env& e) { return e.spaces.at(57); }
static ZIPPY_NOINLINE Space n659(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n656(Context& c, const Env& e) { std::vector<Path> pv{n648(c,e),n657(c,e)}; std::vector<Space> sv{n658(c,e),n659(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_33(c,n); }
static ZIPPY_NOINLINE Space n654(Context& c, const Env& e) { auto a=n655(c,e); if(a.empty()) return a; return compose(a,n656(c,e)); }
static ZIPPY_NOINLINE Space n637(Context& c, const Env& e) { auto a=n638(c,e); auto b=n654(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n635(Context& c, const Env& e) { return iterate(c,e,n636(c,e),56,57,n637); }
static ZIPPY_NOINLINE Space routine_29(Context& c,const Env& e) { return n635(c,e); }
static ZIPPY_NOINLINE Space n661(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n668(Context& c, const Env& e) { return e.paths.at(58); }
static ZIPPY_NOINLINE Space n667(Context& c, const Env& e) { return singleton(n668(c,e)); }
static ZIPPY_NOINLINE Path n670(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n669(Context& c, const Env& e) { return singleton(n670(c,e)); }
static ZIPPY_NOINLINE Space n666(Context& c, const Env& e) { auto a=n667(c,e); auto b=n669(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n665(Context& c, const Env& e) { auto a=n666(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n671(Context& c, const Env& e) { return iterate(c,e,n666(c,e),59,60,n15); }
static ZIPPY_NOINLINE Space n664(Context& c, const Env& e) { auto a=n665(c,e); auto b=n671(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n674(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n675(Context& c, const Env& e) { return e.paths.at(58); }
static ZIPPY_NOINLINE Path n673(Context& c, const Env& e) { auto a=n674(c,e); auto b=n675(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n676(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n677(Context& c, const Env& e) { return e.spaces.at(59); }
static ZIPPY_NOINLINE Space n678(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n672(Context& c, const Env& e) { std::vector<Path> pv{n673(c,e),n676(c,e)}; std::vector<Space> sv{n677(c,e),n678(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n663(Context& c, const Env& e) { auto a=n664(c,e); if(a.empty()) return a; return compose(a,n672(c,e)); }
static ZIPPY_NOINLINE Space n680(Context& c, const Env& e) { auto a=n15(c,e); auto b=n664(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n682(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n683(Context& c, const Env& e) { return e.spaces.at(59); }
static ZIPPY_NOINLINE Space n684(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n681(Context& c, const Env& e) { std::vector<Path> pv{n673(c,e),n682(c,e)}; std::vector<Space> sv{n683(c,e),n684(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_33(c,n); }
static ZIPPY_NOINLINE Space n679(Context& c, const Env& e) { auto a=n680(c,e); if(a.empty()) return a; return compose(a,n681(c,e)); }
static ZIPPY_NOINLINE Space n662(Context& c, const Env& e) { auto a=n663(c,e); auto b=n679(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n660(Context& c, const Env& e) { return iterate(c,e,n661(c,e),58,59,n662); }
static ZIPPY_NOINLINE Space routine_31(Context& c,const Env& e) { return n660(c,e); }
static ZIPPY_NOINLINE Space n686(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n693(Context& c, const Env& e) { return e.paths.at(60); }
static ZIPPY_NOINLINE Space n692(Context& c, const Env& e) { return singleton(n693(c,e)); }
static ZIPPY_NOINLINE Path n695(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n694(Context& c, const Env& e) { return singleton(n695(c,e)); }
static ZIPPY_NOINLINE Space n691(Context& c, const Env& e) { auto a=n692(c,e); auto b=n694(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n690(Context& c, const Env& e) { auto a=n691(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n696(Context& c, const Env& e) { return iterate(c,e,n691(c,e),61,62,n15); }
static ZIPPY_NOINLINE Space n689(Context& c, const Env& e) { auto a=n690(c,e); auto b=n696(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n699(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n700(Context& c, const Env& e) { return e.paths.at(60); }
static ZIPPY_NOINLINE Path n698(Context& c, const Env& e) { auto a=n699(c,e); auto b=n700(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n701(Context& c, const Env& e) { return e.spaces.at(61); }
static ZIPPY_NOINLINE Space n702(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n697(Context& c, const Env& e) { std::vector<Path> pv{n698(c,e)}; std::vector<Space> sv{n701(c,e),n702(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_42(c,n); }
static ZIPPY_NOINLINE Space n688(Context& c, const Env& e) { auto a=n689(c,e); if(a.empty()) return a; return compose(a,n697(c,e)); }
static ZIPPY_NOINLINE Space n704(Context& c, const Env& e) { auto a=n15(c,e); auto b=n689(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n706(Context& c, const Env& e) { return e.spaces.at(61); }
static ZIPPY_NOINLINE Space n707(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n705(Context& c, const Env& e) { std::vector<Path> pv{n698(c,e)}; std::vector<Space> sv{n706(c,e),n707(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_40(c,n); }
static ZIPPY_NOINLINE Space n703(Context& c, const Env& e) { auto a=n704(c,e); if(a.empty()) return a; return compose(a,n705(c,e)); }
static ZIPPY_NOINLINE Space n687(Context& c, const Env& e) { auto a=n688(c,e); auto b=n703(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n685(Context& c, const Env& e) { return iterate(c,e,n686(c,e),60,61,n687); }
static ZIPPY_NOINLINE Space routine_36(Context& c,const Env& e) { return n685(c,e); }
static ZIPPY_NOINLINE Space n709(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n716(Context& c, const Env& e) { return e.paths.at(62); }
static ZIPPY_NOINLINE Space n715(Context& c, const Env& e) { return singleton(n716(c,e)); }
static ZIPPY_NOINLINE Path n718(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n717(Context& c, const Env& e) { return singleton(n718(c,e)); }
static ZIPPY_NOINLINE Space n714(Context& c, const Env& e) { auto a=n715(c,e); auto b=n717(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n713(Context& c, const Env& e) { auto a=n714(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n719(Context& c, const Env& e) { return iterate(c,e,n714(c,e),63,64,n15); }
static ZIPPY_NOINLINE Space n712(Context& c, const Env& e) { auto a=n713(c,e); auto b=n719(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n722(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n723(Context& c, const Env& e) { return e.paths.at(62); }
static ZIPPY_NOINLINE Path n721(Context& c, const Env& e) { auto a=n722(c,e); auto b=n723(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n724(Context& c, const Env& e) { return e.spaces.at(63); }
static ZIPPY_NOINLINE Space n725(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n720(Context& c, const Env& e) { std::vector<Path> pv{n721(c,e)}; std::vector<Space> sv{n724(c,e),n725(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n711(Context& c, const Env& e) { auto a=n712(c,e); if(a.empty()) return a; return compose(a,n720(c,e)); }
static ZIPPY_NOINLINE Space n727(Context& c, const Env& e) { auto a=n15(c,e); auto b=n712(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n729(Context& c, const Env& e) { return e.spaces.at(63); }
static ZIPPY_NOINLINE Space n730(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n728(Context& c, const Env& e) { std::vector<Path> pv{n721(c,e)}; std::vector<Space> sv{n729(c,e),n730(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_40(c,n); }
static ZIPPY_NOINLINE Space n726(Context& c, const Env& e) { auto a=n727(c,e); if(a.empty()) return a; return compose(a,n728(c,e)); }
static ZIPPY_NOINLINE Space n710(Context& c, const Env& e) { auto a=n711(c,e); auto b=n726(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n708(Context& c, const Env& e) { return iterate(c,e,n709(c,e),62,63,n710); }
static ZIPPY_NOINLINE Space routine_38(Context& c,const Env& e) { return n708(c,e); }
static ZIPPY_NOINLINE Space n732(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n739(Context& c, const Env& e) { return e.paths.at(64); }
static ZIPPY_NOINLINE Space n738(Context& c, const Env& e) { return singleton(n739(c,e)); }
static ZIPPY_NOINLINE Path n741(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n740(Context& c, const Env& e) { return singleton(n741(c,e)); }
static ZIPPY_NOINLINE Space n737(Context& c, const Env& e) { auto a=n738(c,e); auto b=n740(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n736(Context& c, const Env& e) { auto a=n737(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n742(Context& c, const Env& e) { return iterate(c,e,n737(c,e),65,66,n15); }
static ZIPPY_NOINLINE Space n735(Context& c, const Env& e) { auto a=n736(c,e); auto b=n742(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n745(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n746(Context& c, const Env& e) { return e.paths.at(64); }
static ZIPPY_NOINLINE Path n744(Context& c, const Env& e) { auto a=n745(c,e); auto b=n746(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n747(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n748(Context& c, const Env& e) { return e.spaces.at(65); }
static ZIPPY_NOINLINE Space n749(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n743(Context& c, const Env& e) { std::vector<Path> pv{n744(c,e),n747(c,e)}; std::vector<Space> sv{n748(c,e),n749(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n734(Context& c, const Env& e) { auto a=n735(c,e); if(a.empty()) return a; return compose(a,n743(c,e)); }
static ZIPPY_NOINLINE Space n751(Context& c, const Env& e) { auto a=n15(c,e); auto b=n735(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n753(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n754(Context& c, const Env& e) { return e.spaces.at(65); }
static ZIPPY_NOINLINE Space n755(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n752(Context& c, const Env& e) { std::vector<Path> pv{n744(c,e),n753(c,e)}; std::vector<Space> sv{n754(c,e),n755(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_37(c,n); }
static ZIPPY_NOINLINE Space n750(Context& c, const Env& e) { auto a=n751(c,e); if(a.empty()) return a; return compose(a,n752(c,e)); }
static ZIPPY_NOINLINE Space n733(Context& c, const Env& e) { auto a=n734(c,e); auto b=n750(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n731(Context& c, const Env& e) { return iterate(c,e,n732(c,e),64,65,n733); }
static ZIPPY_NOINLINE Space routine_35(Context& c,const Env& e) { return n731(c,e); }
static ZIPPY_NOINLINE Space n757(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n764(Context& c, const Env& e) { return e.paths.at(66); }
static ZIPPY_NOINLINE Space n763(Context& c, const Env& e) { return singleton(n764(c,e)); }
static ZIPPY_NOINLINE Path n766(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n765(Context& c, const Env& e) { return singleton(n766(c,e)); }
static ZIPPY_NOINLINE Space n762(Context& c, const Env& e) { auto a=n763(c,e); auto b=n765(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n761(Context& c, const Env& e) { auto a=n762(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n767(Context& c, const Env& e) { return iterate(c,e,n762(c,e),67,68,n15); }
static ZIPPY_NOINLINE Space n760(Context& c, const Env& e) { auto a=n761(c,e); auto b=n767(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n770(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n771(Context& c, const Env& e) { return e.paths.at(66); }
static ZIPPY_NOINLINE Path n769(Context& c, const Env& e) { auto a=n770(c,e); auto b=n771(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n772(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n773(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n774(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n768(Context& c, const Env& e) { std::vector<Path> pv{n769(c,e),n772(c,e)}; std::vector<Space> sv{n773(c,e),n774(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_39(c,n); }
static ZIPPY_NOINLINE Space n759(Context& c, const Env& e) { auto a=n760(c,e); if(a.empty()) return a; return compose(a,n768(c,e)); }
static ZIPPY_NOINLINE Space n776(Context& c, const Env& e) { auto a=n15(c,e); auto b=n760(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n778(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n779(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n780(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n777(Context& c, const Env& e) { std::vector<Path> pv{n769(c,e),n778(c,e)}; std::vector<Space> sv{n779(c,e),n780(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_37(c,n); }
static ZIPPY_NOINLINE Space n775(Context& c, const Env& e) { auto a=n776(c,e); if(a.empty()) return a; return compose(a,n777(c,e)); }
static ZIPPY_NOINLINE Space n758(Context& c, const Env& e) { auto a=n759(c,e); auto b=n775(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n756(Context& c, const Env& e) { return iterate(c,e,n757(c,e),66,67,n758); }
static ZIPPY_NOINLINE Space routine_33(Context& c,const Env& e) { return n756(c,e); }
static ZIPPY_NOINLINE Space n782(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n789(Context& c, const Env& e) { return e.paths.at(68); }
static ZIPPY_NOINLINE Space n788(Context& c, const Env& e) { return singleton(n789(c,e)); }
static ZIPPY_NOINLINE Path n791(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n790(Context& c, const Env& e) { return singleton(n791(c,e)); }
static ZIPPY_NOINLINE Space n787(Context& c, const Env& e) { auto a=n788(c,e); auto b=n790(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n786(Context& c, const Env& e) { auto a=n787(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n792(Context& c, const Env& e) { return iterate(c,e,n787(c,e),69,70,n15); }
static ZIPPY_NOINLINE Space n785(Context& c, const Env& e) { auto a=n786(c,e); auto b=n792(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n795(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n796(Context& c, const Env& e) { return e.paths.at(68); }
static ZIPPY_NOINLINE Path n794(Context& c, const Env& e) { auto a=n795(c,e); auto b=n796(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n797(Context& c, const Env& e) { return e.spaces.at(69); }
static ZIPPY_NOINLINE Space n798(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n793(Context& c, const Env& e) { std::vector<Path> pv{n794(c,e)}; std::vector<Space> sv{n797(c,e),n798(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n784(Context& c, const Env& e) { auto a=n785(c,e); if(a.empty()) return a; return compose(a,n793(c,e)); }
static ZIPPY_NOINLINE Space n800(Context& c, const Env& e) { auto a=n15(c,e); auto b=n785(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n802(Context& c, const Env& e) { return e.spaces.at(69); }
static ZIPPY_NOINLINE Space n803(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n801(Context& c, const Env& e) { std::vector<Path> pv{n794(c,e)}; std::vector<Space> sv{n802(c,e),n803(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n799(Context& c, const Env& e) { auto a=n800(c,e); if(a.empty()) return a; return compose(a,n801(c,e)); }
static ZIPPY_NOINLINE Space n783(Context& c, const Env& e) { auto a=n784(c,e); auto b=n799(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n781(Context& c, const Env& e) { return iterate(c,e,n782(c,e),68,69,n783); }
static ZIPPY_NOINLINE Space routine_42(Context& c,const Env& e) { return n781(c,e); }
static ZIPPY_NOINLINE Space n805(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n812(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Space n811(Context& c, const Env& e) { return singleton(n812(c,e)); }
static ZIPPY_NOINLINE Path n814(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n813(Context& c, const Env& e) { return singleton(n814(c,e)); }
static ZIPPY_NOINLINE Space n810(Context& c, const Env& e) { auto a=n811(c,e); auto b=n813(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n809(Context& c, const Env& e) { auto a=n810(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n815(Context& c, const Env& e) { return iterate(c,e,n810(c,e),71,72,n15); }
static ZIPPY_NOINLINE Space n808(Context& c, const Env& e) { auto a=n809(c,e); auto b=n815(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n818(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n819(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Path n817(Context& c, const Env& e) { auto a=n818(c,e); auto b=n819(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n820(Context& c, const Env& e) { return e.spaces.at(71); }
static ZIPPY_NOINLINE Space n821(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n816(Context& c, const Env& e) { std::vector<Path> pv{n817(c,e)}; std::vector<Space> sv{n820(c,e),n821(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n807(Context& c, const Env& e) { auto a=n808(c,e); if(a.empty()) return a; return compose(a,n816(c,e)); }
static ZIPPY_NOINLINE Space n823(Context& c, const Env& e) { auto a=n15(c,e); auto b=n808(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n825(Context& c, const Env& e) { return e.spaces.at(71); }
static ZIPPY_NOINLINE Space n826(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n824(Context& c, const Env& e) { std::vector<Path> pv{n817(c,e)}; std::vector<Space> sv{n825(c,e),n826(c,e)}; Env n; n.paths[2]=pv[0];n.spaces[3]=sv[0];n.spaces[0]=sv[1];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n822(Context& c, const Env& e) { auto a=n823(c,e); if(a.empty()) return a; return compose(a,n824(c,e)); }
static ZIPPY_NOINLINE Space n806(Context& c, const Env& e) { auto a=n807(c,e); auto b=n822(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n804(Context& c, const Env& e) { return iterate(c,e,n805(c,e),70,71,n806); }
static ZIPPY_NOINLINE Space routine_40(Context& c,const Env& e) { return n804(c,e); }
static ZIPPY_NOINLINE Space n828(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n835(Context& c, const Env& e) { return e.paths.at(72); }
static ZIPPY_NOINLINE Space n834(Context& c, const Env& e) { return singleton(n835(c,e)); }
static ZIPPY_NOINLINE Path n837(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n836(Context& c, const Env& e) { return singleton(n837(c,e)); }
static ZIPPY_NOINLINE Space n833(Context& c, const Env& e) { auto a=n834(c,e); auto b=n836(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n832(Context& c, const Env& e) { auto a=n833(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n838(Context& c, const Env& e) { return iterate(c,e,n833(c,e),73,74,n15); }
static ZIPPY_NOINLINE Space n831(Context& c, const Env& e) { auto a=n832(c,e); auto b=n838(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n841(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n842(Context& c, const Env& e) { return e.paths.at(72); }
static ZIPPY_NOINLINE Path n840(Context& c, const Env& e) { auto a=n841(c,e); auto b=n842(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n843(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n844(Context& c, const Env& e) { return e.spaces.at(73); }
static ZIPPY_NOINLINE Space n845(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n839(Context& c, const Env& e) { std::vector<Path> pv{n840(c,e),n843(c,e)}; std::vector<Space> sv{n844(c,e),n845(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_43(c,n); }
static ZIPPY_NOINLINE Space n830(Context& c, const Env& e) { auto a=n831(c,e); if(a.empty()) return a; return compose(a,n839(c,e)); }
static ZIPPY_NOINLINE Space n847(Context& c, const Env& e) { auto a=n15(c,e); auto b=n831(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n849(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n850(Context& c, const Env& e) { return e.spaces.at(73); }
static ZIPPY_NOINLINE Space n851(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n848(Context& c, const Env& e) { std::vector<Path> pv{n840(c,e),n849(c,e)}; std::vector<Space> sv{n850(c,e),n851(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_41(c,n); }
static ZIPPY_NOINLINE Space n846(Context& c, const Env& e) { auto a=n847(c,e); if(a.empty()) return a; return compose(a,n848(c,e)); }
static ZIPPY_NOINLINE Space n829(Context& c, const Env& e) { auto a=n830(c,e); auto b=n846(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n827(Context& c, const Env& e) { return iterate(c,e,n828(c,e),72,73,n829); }
static ZIPPY_NOINLINE Space routine_37(Context& c,const Env& e) { return n827(c,e); }
static ZIPPY_NOINLINE Space n853(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n860(Context& c, const Env& e) { return e.paths.at(74); }
static ZIPPY_NOINLINE Space n859(Context& c, const Env& e) { return singleton(n860(c,e)); }
static ZIPPY_NOINLINE Path n862(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n861(Context& c, const Env& e) { return singleton(n862(c,e)); }
static ZIPPY_NOINLINE Space n858(Context& c, const Env& e) { auto a=n859(c,e); auto b=n861(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n857(Context& c, const Env& e) { auto a=n858(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n863(Context& c, const Env& e) { return iterate(c,e,n858(c,e),75,76,n15); }
static ZIPPY_NOINLINE Space n856(Context& c, const Env& e) { auto a=n857(c,e); auto b=n863(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n866(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n867(Context& c, const Env& e) { return e.paths.at(74); }
static ZIPPY_NOINLINE Path n865(Context& c, const Env& e) { auto a=n866(c,e); auto b=n867(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n868(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n869(Context& c, const Env& e) { return e.spaces.at(75); }
static ZIPPY_NOINLINE Space n870(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n864(Context& c, const Env& e) { std::vector<Path> pv{n865(c,e),n868(c,e)}; std::vector<Space> sv{n869(c,e),n870(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n855(Context& c, const Env& e) { auto a=n856(c,e); if(a.empty()) return a; return compose(a,n864(c,e)); }
static ZIPPY_NOINLINE Space n872(Context& c, const Env& e) { auto a=n15(c,e); auto b=n856(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n874(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n875(Context& c, const Env& e) { return e.spaces.at(75); }
static ZIPPY_NOINLINE Space n876(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n873(Context& c, const Env& e) { std::vector<Path> pv{n865(c,e),n874(c,e)}; std::vector<Space> sv{n875(c,e),n876(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_41(c,n); }
static ZIPPY_NOINLINE Space n871(Context& c, const Env& e) { auto a=n872(c,e); if(a.empty()) return a; return compose(a,n873(c,e)); }
static ZIPPY_NOINLINE Space n854(Context& c, const Env& e) { auto a=n855(c,e); auto b=n871(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n852(Context& c, const Env& e) { return iterate(c,e,n853(c,e),74,75,n854); }
static ZIPPY_NOINLINE Space routine_39(Context& c,const Env& e) { return n852(c,e); }
static ZIPPY_NOINLINE Space n878(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n885(Context& c, const Env& e) { return e.paths.at(76); }
static ZIPPY_NOINLINE Space n884(Context& c, const Env& e) { return singleton(n885(c,e)); }
static ZIPPY_NOINLINE Path n887(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n886(Context& c, const Env& e) { return singleton(n887(c,e)); }
static ZIPPY_NOINLINE Space n883(Context& c, const Env& e) { auto a=n884(c,e); auto b=n886(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n882(Context& c, const Env& e) { auto a=n883(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n888(Context& c, const Env& e) { return iterate(c,e,n883(c,e),77,78,n15); }
static ZIPPY_NOINLINE Space n881(Context& c, const Env& e) { auto a=n882(c,e); auto b=n888(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n889(Context& c, const Env& e) { return Space(); }
static ZIPPY_NOINLINE Space n880(Context& c, const Env& e) { auto a=n881(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n891(Context& c, const Env& e) { auto a=n15(c,e); auto b=n881(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n890(Context& c, const Env& e) { auto a=n891(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n879(Context& c, const Env& e) { auto a=n880(c,e); auto b=n890(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n877(Context& c, const Env& e) { return iterate(c,e,n878(c,e),76,77,n879); }
static ZIPPY_NOINLINE Space routine_4(Context& c,const Env& e) { return n877(c,e); }
static ZIPPY_NOINLINE Space n893(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n900(Context& c, const Env& e) { return e.paths.at(78); }
static ZIPPY_NOINLINE Space n899(Context& c, const Env& e) { return singleton(n900(c,e)); }
static ZIPPY_NOINLINE Path n902(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n901(Context& c, const Env& e) { return singleton(n902(c,e)); }
static ZIPPY_NOINLINE Space n898(Context& c, const Env& e) { auto a=n899(c,e); auto b=n901(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n897(Context& c, const Env& e) { auto a=n898(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n903(Context& c, const Env& e) { return iterate(c,e,n898(c,e),79,80,n15); }
static ZIPPY_NOINLINE Space n896(Context& c, const Env& e) { auto a=n897(c,e); auto b=n903(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n906(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n907(Context& c, const Env& e) { return e.paths.at(78); }
static ZIPPY_NOINLINE Path n905(Context& c, const Env& e) { auto a=n906(c,e); auto b=n907(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n908(Context& c, const Env& e) { return e.spaces.at(79); }
static ZIPPY_NOINLINE Space n909(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n904(Context& c, const Env& e) { std::vector<Path> pv{n905(c,e)}; std::vector<Space> sv{n908(c,e),n909(c,e)}; Env n; n.paths[5]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_44(c,n); }
static ZIPPY_NOINLINE Space n895(Context& c, const Env& e) { auto a=n896(c,e); if(a.empty()) return a; return compose(a,n904(c,e)); }
static ZIPPY_NOINLINE Space n911(Context& c, const Env& e) { auto a=n15(c,e); auto b=n896(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n910(Context& c, const Env& e) { auto a=n911(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n894(Context& c, const Env& e) { auto a=n895(c,e); auto b=n910(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n892(Context& c, const Env& e) { return iterate(c,e,n893(c,e),78,79,n894); }
static ZIPPY_NOINLINE Space routine_6(Context& c,const Env& e) { return n892(c,e); }
static ZIPPY_NOINLINE Space n913(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n920(Context& c, const Env& e) { return e.paths.at(80); }
static ZIPPY_NOINLINE Space n919(Context& c, const Env& e) { return singleton(n920(c,e)); }
static ZIPPY_NOINLINE Path n922(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n921(Context& c, const Env& e) { return singleton(n922(c,e)); }
static ZIPPY_NOINLINE Space n918(Context& c, const Env& e) { auto a=n919(c,e); auto b=n921(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n917(Context& c, const Env& e) { auto a=n918(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n923(Context& c, const Env& e) { return iterate(c,e,n918(c,e),81,82,n15); }
static ZIPPY_NOINLINE Space n916(Context& c, const Env& e) { auto a=n917(c,e); auto b=n923(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n926(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n927(Context& c, const Env& e) { return e.paths.at(80); }
static ZIPPY_NOINLINE Path n925(Context& c, const Env& e) { auto a=n926(c,e); auto b=n927(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n928(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n929(Context& c, const Env& e) { return e.spaces.at(81); }
static ZIPPY_NOINLINE Space n930(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n924(Context& c, const Env& e) { std::vector<Path> pv{n925(c,e),n928(c,e)}; std::vector<Space> sv{n929(c,e),n930(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n915(Context& c, const Env& e) { auto a=n916(c,e); if(a.empty()) return a; return compose(a,n924(c,e)); }
static ZIPPY_NOINLINE Space n932(Context& c, const Env& e) { auto a=n15(c,e); auto b=n916(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n934(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n935(Context& c, const Env& e) { return e.spaces.at(81); }
static ZIPPY_NOINLINE Space n936(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n933(Context& c, const Env& e) { std::vector<Path> pv{n925(c,e),n934(c,e)}; std::vector<Space> sv{n935(c,e),n936(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_5(c,n); }
static ZIPPY_NOINLINE Space n931(Context& c, const Env& e) { auto a=n932(c,e); if(a.empty()) return a; return compose(a,n933(c,e)); }
static ZIPPY_NOINLINE Space n914(Context& c, const Env& e) { auto a=n915(c,e); auto b=n931(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n912(Context& c, const Env& e) { return iterate(c,e,n913(c,e),80,81,n914); }
static ZIPPY_NOINLINE Space routine_43(Context& c,const Env& e) { return n912(c,e); }
static ZIPPY_NOINLINE Space n938(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n945(Context& c, const Env& e) { return e.paths.at(82); }
static ZIPPY_NOINLINE Space n944(Context& c, const Env& e) { return singleton(n945(c,e)); }
static ZIPPY_NOINLINE Path n947(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n946(Context& c, const Env& e) { return singleton(n947(c,e)); }
static ZIPPY_NOINLINE Space n943(Context& c, const Env& e) { auto a=n944(c,e); auto b=n946(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n942(Context& c, const Env& e) { auto a=n943(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n948(Context& c, const Env& e) { return iterate(c,e,n943(c,e),83,84,n15); }
static ZIPPY_NOINLINE Space n941(Context& c, const Env& e) { auto a=n942(c,e); auto b=n948(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n951(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n952(Context& c, const Env& e) { return e.paths.at(82); }
static ZIPPY_NOINLINE Path n950(Context& c, const Env& e) { auto a=n951(c,e); auto b=n952(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n953(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n954(Context& c, const Env& e) { return e.spaces.at(83); }
static ZIPPY_NOINLINE Space n955(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n949(Context& c, const Env& e) { std::vector<Path> pv{n950(c,e),n953(c,e)}; std::vector<Space> sv{n954(c,e),n955(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_7(c,n); }
static ZIPPY_NOINLINE Space n940(Context& c, const Env& e) { auto a=n941(c,e); if(a.empty()) return a; return compose(a,n949(c,e)); }
static ZIPPY_NOINLINE Space n957(Context& c, const Env& e) { auto a=n15(c,e); auto b=n941(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n959(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n960(Context& c, const Env& e) { return e.spaces.at(83); }
static ZIPPY_NOINLINE Space n961(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n958(Context& c, const Env& e) { std::vector<Path> pv{n950(c,e),n959(c,e)}; std::vector<Space> sv{n960(c,e),n961(c,e)}; Env n; n.paths[10]=pv[0];n.paths[5]=pv[1];n.spaces[11]=sv[0];n.spaces[0]=sv[1];  return routine_5(c,n); }
static ZIPPY_NOINLINE Space n956(Context& c, const Env& e) { auto a=n957(c,e); if(a.empty()) return a; return compose(a,n958(c,e)); }
static ZIPPY_NOINLINE Space n939(Context& c, const Env& e) { auto a=n940(c,e); auto b=n956(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n937(Context& c, const Env& e) { return iterate(c,e,n938(c,e),82,83,n939); }
static ZIPPY_NOINLINE Space routine_41(Context& c,const Env& e) { return n937(c,e); }
static ZIPPY_NOINLINE Space n963(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n970(Context& c, const Env& e) { return e.paths.at(84); }
static ZIPPY_NOINLINE Space n969(Context& c, const Env& e) { return singleton(n970(c,e)); }
static ZIPPY_NOINLINE Path n972(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n971(Context& c, const Env& e) { return singleton(n972(c,e)); }
static ZIPPY_NOINLINE Space n968(Context& c, const Env& e) { auto a=n969(c,e); auto b=n971(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n967(Context& c, const Env& e) { auto a=n968(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n973(Context& c, const Env& e) { return iterate(c,e,n968(c,e),85,86,n15); }
static ZIPPY_NOINLINE Space n966(Context& c, const Env& e) { auto a=n967(c,e); auto b=n973(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n965(Context& c, const Env& e) { auto a=n966(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n975(Context& c, const Env& e) { auto a=n15(c,e); auto b=n966(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n974(Context& c, const Env& e) { auto a=n975(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n964(Context& c, const Env& e) { auto a=n965(c,e); auto b=n974(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n962(Context& c, const Env& e) { return iterate(c,e,n963(c,e),84,85,n964); }
static ZIPPY_NOINLINE Space routine_5(Context& c,const Env& e) { return n962(c,e); }
static ZIPPY_NOINLINE Space n977(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Path n984(Context& c, const Env& e) { return e.paths.at(86); }
static ZIPPY_NOINLINE Space n983(Context& c, const Env& e) { return singleton(n984(c,e)); }
static ZIPPY_NOINLINE Path n986(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n985(Context& c, const Env& e) { return singleton(n986(c,e)); }
static ZIPPY_NOINLINE Space n982(Context& c, const Env& e) { auto a=n983(c,e); auto b=n985(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n981(Context& c, const Env& e) { auto a=n982(c,e); auto b=n15(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n987(Context& c, const Env& e) { return iterate(c,e,n982(c,e),87,88,n15); }
static ZIPPY_NOINLINE Space n980(Context& c, const Env& e) { auto a=n981(c,e); auto b=n987(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n990(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n991(Context& c, const Env& e) { return e.paths.at(86); }
static ZIPPY_NOINLINE Path n989(Context& c, const Env& e) { auto a=n990(c,e); auto b=n991(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n992(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n993(Context& c, const Env& e) { return e.spaces.at(87); }
static ZIPPY_NOINLINE Space n994(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n988(Context& c, const Env& e) { std::vector<Path> pv{n989(c,e),n992(c,e)}; std::vector<Space> sv{n993(c,e),n994(c,e)}; Env n; n.paths[17]=pv[0];n.paths[5]=pv[1];n.spaces[18]=sv[0];n.spaces[0]=sv[1];  return routine_45(c,n); }
static ZIPPY_NOINLINE Space n979(Context& c, const Env& e) { auto a=n980(c,e); if(a.empty()) return a; return compose(a,n988(c,e)); }
static ZIPPY_NOINLINE Space n996(Context& c, const Env& e) { auto a=n15(c,e); auto b=n980(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n995(Context& c, const Env& e) { auto a=n996(c,e); if(a.empty()) return a; return compose(a,n889(c,e)); }
static ZIPPY_NOINLINE Space n978(Context& c, const Env& e) { auto a=n979(c,e); auto b=n995(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n976(Context& c, const Env& e) { return iterate(c,e,n977(c,e),86,87,n978); }
static ZIPPY_NOINLINE Space routine_7(Context& c,const Env& e) { return n976(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
