#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Path n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Path n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Path n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n4(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto p=n4(c,e); return unwrap(n5(c,e),p); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n9(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n11(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { auto p=n17(c,e); return unwrap(n18(c,e),p); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto p=n15(c,e); return unwrap(n16(c,e),p); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto p=n13(c,e); return unwrap(n14(c,e),p); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto p=n11(c,e); return wrap(n12(c,e),p); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { auto p=n9(c,e); return wrap(n10(c,e),p); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),1,2,n8); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),0,1,n6); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto p=n1(c,e); return wrap(n2(c,e),p); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"2 1 6 77 117 116 117 97 108 2 4 101 100 103 101"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
