#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{2,2};
static const Space constant_1 = literal_text("1 0 ");
static const Space constant_2 = literal_text("1 1 2");
static const Space constant_3 = singleton(Path{});
static const Path constant_4 = Path{2,1,2,1,1,1,1,1,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  Space v0_12_result;
  for (int v0_12_label = 1; v0_12_label <= 2; ++v0_12_label) {
    const Space v0_12_tail = child(v0_2,v0_12_label);
    if (v0_12_tail.empty()) continue;
    const Path v0_12_head{v0_12_label};
    const Space v1_2 = singleton(v0_12_head);
    const Space v1_3 = intersect(constant_2,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_3 : Space{});
    const Space v1_5 = subtract(constant_1,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_12_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_2,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_3 : Space{});
        const Space v3_5 = subtract(constant_1,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_12_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail, bound_space(s0));
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_2,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_3 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_12_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail, bound_space(s0));
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_2,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_3 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_12_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_2,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_3 : Space{});
        const Space v7_5 = subtract(constant_1,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_12_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail, bound_space(s0));
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_2,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_3 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_12_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail, bound_space(s0));
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_12_result = unite(v0_12_result,v1_12);
  }
  const Space v0_12 = std::move(v0_12_result);
  const Space v0_14 = wrap(v0_12,constant_4);
  return v0_14;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v10_12_result;
  for (int v10_12_label = 1; v10_12_label <= 2; ++v10_12_label) {
    const Space v10_12_tail = child(s0,v10_12_label);
    if (v10_12_tail.empty()) continue;
    const Path v10_12_head{v10_12_label};
    const Space v11_2 = singleton(v10_12_head);
    const Space v11_3 = intersect(constant_2,v11_2);
    const Space v11_4 = (has_head(v11_3) ? constant_3 : Space{});
    const Space v11_5 = subtract(constant_1,v11_4);
    Space v11_8;
    if (!v11_5.empty()) {
      const Path v12_6 = concat_path(p0,v10_12_head);
      Space v12_7_result;
      for (int v12_7_label = 1; v12_7_label <= 2; ++v12_7_label) {
        const Space v12_7_tail = child(v10_12_tail,v12_7_label);
        if (v12_7_tail.empty()) continue;
        const Path v12_7_head{v12_7_label};
        const Space v13_2 = singleton(v12_7_head);
        const Space v13_3 = intersect(constant_2,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_3 : Space{});
        const Space v13_5 = subtract(constant_1,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_7_head);
          const Space v14_7 = routine_4(c, v14_6, v12_7_tail, s1);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_2,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_3 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_7_head);
          const Space v15_11 = routine_5(c, v15_6, v12_7_tail, s1);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_7_result = unite(v12_7_result,v13_13);
      }
      const Space v12_7 = std::move(v12_7_result);
      v11_8 = compose(v11_5,v12_7);
    }
    const Space v11_9 = intersect(constant_2,v11_2);
    const Space v11_10 = (has_head(v11_9) ? constant_3 : Space{});
    Space v11_12;
    if (!v11_10.empty()) {
      const Path v16_6 = concat_path(p0,v10_12_head);
      Space v16_11_result;
      for (int v16_11_label = 1; v16_11_label <= 2; ++v16_11_label) {
        const Space v16_11_tail = child(v10_12_tail,v16_11_label);
        if (v16_11_tail.empty()) continue;
        const Path v16_11_head{v16_11_label};
        const Space v17_2 = singleton(v16_11_head);
        const Space v17_3 = intersect(constant_2,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_3 : Space{});
        const Space v17_5 = subtract(constant_1,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_11_head);
          const Space v18_7 = routine_4(c, v18_6, v16_11_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_2,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_3 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_11_head);
          const Space v19_11 = routine_3(c, v19_6, v16_11_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_11_result = unite(v16_11_result,v17_13);
      }
      const Space v16_11 = std::move(v16_11_result);
      v11_12 = compose(v11_10,v16_11);
    }
    const Space v11_13 = unite(v11_8,v11_12);
    v10_12_result = unite(v10_12_result,v11_13);
  }
  const Space v10_12 = std::move(v10_12_result);
  return v10_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v20_12_result;
  for (int v20_12_label = 1; v20_12_label <= 2; ++v20_12_label) {
    const Space v20_12_tail = child(s0,v20_12_label);
    if (v20_12_tail.empty()) continue;
    const Path v20_12_head{v20_12_label};
    const Space v21_2 = singleton(v20_12_head);
    const Space v21_3 = intersect(constant_2,v21_2);
    const Space v21_4 = (has_head(v21_3) ? constant_3 : Space{});
    const Space v21_5 = subtract(constant_1,v21_4);
    Space v21_8;
    if (!v21_5.empty()) {
      const Path v22_6 = concat_path(p0,v20_12_head);
      Space v22_7_result;
      for (int v22_7_label = 1; v22_7_label <= 2; ++v22_7_label) {
        const Space v22_7_tail = child(v20_12_tail,v22_7_label);
        if (v22_7_tail.empty()) continue;
        const Path v22_7_head{v22_7_label};
        const Space v23_2 = singleton(v22_7_head);
        const Space v23_3 = intersect(constant_2,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_3 : Space{});
        const Space v23_5 = subtract(constant_1,v23_4);
        Space v23_8;
        if (!v23_5.empty()) {
          const Path v24_6 = concat_path(v22_6,v22_7_head);
          const Space v24_7 = routine_4(c, v24_6, v22_7_tail, s1);
          v23_8 = compose(v23_5,v24_7);
        }
        const Space v23_9 = intersect(constant_2,v23_2);
        const Space v23_10 = (has_head(v23_9) ? constant_3 : Space{});
        Space v23_12;
        if (!v23_10.empty()) {
          const Path v25_6 = concat_path(v22_6,v22_7_head);
          const Space v25_11 = routine_5(c, v25_6, v22_7_tail, s1);
          v23_12 = compose(v23_10,v25_11);
        }
        const Space v23_13 = unite(v23_8,v23_12);
        v22_7_result = unite(v22_7_result,v23_13);
      }
      const Space v22_7 = std::move(v22_7_result);
      v21_8 = compose(v21_5,v22_7);
    }
    const Space v21_9 = intersect(constant_2,v21_2);
    const Space v21_10 = (has_head(v21_9) ? constant_3 : Space{});
    Space v21_12;
    if (!v21_10.empty()) {
      const Path v26_6 = concat_path(p0,v20_12_head);
      Space v26_11_result;
      for (int v26_11_label = 1; v26_11_label <= 2; ++v26_11_label) {
        const Space v26_11_tail = child(v20_12_tail,v26_11_label);
        if (v26_11_tail.empty()) continue;
        const Path v26_11_head{v26_11_label};
        const Space v27_2 = singleton(v26_11_head);
        const Space v27_3 = intersect(constant_2,v27_2);
        const Space v27_4 = (has_head(v27_3) ? constant_3 : Space{});
        const Space v27_5 = subtract(constant_1,v27_4);
        Space v27_7;
        if (!v27_5.empty()) {
          const Space v28_6 = routine_6(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_7 = compose(v27_5,v28_6);
        }
        const Space v27_8 = intersect(constant_2,v27_2);
        const Space v27_9 = (has_head(v27_8) ? constant_3 : Space{});
        Space v27_11;
        if (!v27_9.empty()) {
          const Space v29_10 = routine_7(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_11 = compose(v27_9,v29_10);
        }
        const Space v27_12 = unite(v27_7,v27_11);
        v26_11_result = unite(v26_11_result,v27_12);
      }
      const Space v26_11 = std::move(v26_11_result);
      v21_12 = compose(v21_10,v26_11);
    }
    const Space v21_13 = unite(v21_8,v21_12);
    v20_12_result = unite(v20_12_result,v21_13);
  }
  const Space v20_12 = std::move(v20_12_result);
  return v20_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v30_12_result;
  for (int v30_12_label = 1; v30_12_label <= 2; ++v30_12_label) {
    const Space v30_12_tail = child(s0,v30_12_label);
    if (v30_12_tail.empty()) continue;
    const Path v30_12_head{v30_12_label};
    const Space v31_2 = singleton(v30_12_head);
    const Space v31_3 = intersect(constant_2,v31_2);
    const Space v31_4 = (has_head(v31_3) ? constant_3 : Space{});
    const Space v31_5 = subtract(constant_1,v31_4);
    Space v31_7;
    if (!v31_5.empty()) {
      Space v32_6_result;
      for (int v32_6_label = 1; v32_6_label <= 2; ++v32_6_label) {
        const Space v32_6_tail = child(v30_12_tail,v32_6_label);
        if (v32_6_tail.empty()) continue;
        const Path v32_6_head{v32_6_label};
        const Space v33_2 = singleton(v32_6_head);
        const Space v33_3 = intersect(constant_2,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_3 : Space{});
        const Space v33_5 = subtract(constant_1,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v30_12_head,v32_6_head);
          const Space v34_7 = routine_8(c, v34_6, p0, v32_6_tail, s1);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_2,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_3 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v30_12_head,v32_6_head);
          const Space v35_11 = routine_9(c, v35_6, p0, v32_6_tail, s1);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_6_result = unite(v32_6_result,v33_13);
      }
      const Space v32_6 = std::move(v32_6_result);
      v31_7 = compose(v31_5,v32_6);
    }
    const Space v31_8 = intersect(constant_2,v31_2);
    const Space v31_9 = (has_head(v31_8) ? constant_3 : Space{});
    Space v31_11;
    if (!v31_9.empty()) {
      Space v36_10_result;
      for (int v36_10_label = 1; v36_10_label <= 2; ++v36_10_label) {
        const Space v36_10_tail = child(v30_12_tail,v36_10_label);
        if (v36_10_tail.empty()) continue;
        const Path v36_10_head{v36_10_label};
        const Space v37_2 = singleton(v36_10_head);
        const Space v37_3 = intersect(constant_2,v37_2);
        const Space v37_4 = (has_head(v37_3) ? constant_3 : Space{});
        const Space v37_5 = subtract(constant_1,v37_4);
        Space v37_8;
        if (!v37_5.empty()) {
          const Path v38_6 = concat_path(v30_12_head,v36_10_head);
          const Space v38_7 = routine_8(c, v38_6, p0, v36_10_tail, s1);
          v37_8 = compose(v37_5,v38_7);
        }
        const Space v37_9 = intersect(constant_2,v37_2);
        const Space v37_10 = (has_head(v37_9) ? constant_3 : Space{});
        Space v37_12;
        if (!v37_10.empty()) {
          const Path v39_6 = concat_path(v30_12_head,v36_10_head);
          const Space v39_11 = routine_10(c, v39_6, p0, v36_10_tail, s1);
          v37_12 = compose(v37_10,v39_11);
        }
        const Space v37_13 = unite(v37_8,v37_12);
        v36_10_result = unite(v36_10_result,v37_13);
      }
      const Space v36_10 = std::move(v36_10_result);
      v31_11 = compose(v31_9,v36_10);
    }
    const Space v31_12 = unite(v31_7,v31_11);
    v30_12_result = unite(v30_12_result,v31_12);
  }
  const Space v30_12 = std::move(v30_12_result);
  return v30_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v40_12_result;
  for (int v40_12_label = 1; v40_12_label <= 2; ++v40_12_label) {
    const Space v40_12_tail = child(s0,v40_12_label);
    if (v40_12_tail.empty()) continue;
    const Path v40_12_head{v40_12_label};
    const Space v41_2 = singleton(v40_12_head);
    const Space v41_3 = intersect(constant_2,v41_2);
    const Space v41_4 = (has_head(v41_3) ? constant_3 : Space{});
    const Space v41_5 = subtract(constant_1,v41_4);
    Space v41_8;
    if (!v41_5.empty()) {
      const Path v42_6 = concat_path(p0,v40_12_head);
      Space v42_7_result;
      for (int v42_7_label = 1; v42_7_label <= 2; ++v42_7_label) {
        const Space v42_7_tail = child(v40_12_tail,v42_7_label);
        if (v42_7_tail.empty()) continue;
        const Path v42_7_head{v42_7_label};
        const Space v43_2 = singleton(v42_7_head);
        const Space v43_3 = intersect(constant_2,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_3 : Space{});
        const Space v43_5 = subtract(constant_1,v43_4);
        Space v43_8;
        if (!v43_5.empty()) {
          const Path v44_6 = concat_path(v42_6,v42_7_head);
          const Space v44_7 = routine_11(c, v44_6, v42_7_tail, s1);
          v43_8 = compose(v43_5,v44_7);
        }
        const Space v43_9 = intersect(constant_2,v43_2);
        const Space v43_10 = (has_head(v43_9) ? constant_3 : Space{});
        Space v43_12;
        if (!v43_10.empty()) {
          const Path v45_6 = concat_path(v42_6,v42_7_head);
          const Space v45_11 = routine_12(c, v45_6, v42_7_tail, s1);
          v43_12 = compose(v43_10,v45_11);
        }
        const Space v43_13 = unite(v43_8,v43_12);
        v42_7_result = unite(v42_7_result,v43_13);
      }
      const Space v42_7 = std::move(v42_7_result);
      v41_8 = compose(v41_5,v42_7);
    }
    const Space v41_9 = intersect(constant_2,v41_2);
    const Space v41_10 = (has_head(v41_9) ? constant_3 : Space{});
    Space v41_12;
    if (!v41_10.empty()) {
      const Path v46_6 = concat_path(p0,v40_12_head);
      Space v46_11_result;
      for (int v46_11_label = 1; v46_11_label <= 2; ++v46_11_label) {
        const Space v46_11_tail = child(v40_12_tail,v46_11_label);
        if (v46_11_tail.empty()) continue;
        const Path v46_11_head{v46_11_label};
        const Space v47_2 = singleton(v46_11_head);
        const Space v47_3 = intersect(constant_2,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_3 : Space{});
        const Space v47_5 = subtract(constant_1,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_11_head);
          const Space v48_7 = routine_11(c, v48_6, v46_11_tail, s1);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_2,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_3 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_11_head);
          const Space v49_11 = routine_3(c, v49_6, v46_11_tail, s1);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_11_result = unite(v46_11_result,v47_13);
      }
      const Space v46_11 = std::move(v46_11_result);
      v41_12 = compose(v41_10,v46_11);
    }
    const Space v41_13 = unite(v41_8,v41_12);
    v40_12_result = unite(v40_12_result,v41_13);
  }
  const Space v40_12 = std::move(v40_12_result);
  return v40_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v50_12_result;
  for (int v50_12_label = 1; v50_12_label <= 2; ++v50_12_label) {
    const Space v50_12_tail = child(s0,v50_12_label);
    if (v50_12_tail.empty()) continue;
    const Path v50_12_head{v50_12_label};
    const Space v51_2 = singleton(v50_12_head);
    const Space v51_3 = intersect(constant_2,v51_2);
    const Space v51_4 = (has_head(v51_3) ? constant_3 : Space{});
    const Space v51_5 = subtract(constant_1,v51_4);
    Space v51_8;
    if (!v51_5.empty()) {
      const Path v52_6 = concat_path(p0,v50_12_head);
      Space v52_7_result;
      for (int v52_7_label = 1; v52_7_label <= 2; ++v52_7_label) {
        const Space v52_7_tail = child(v50_12_tail,v52_7_label);
        if (v52_7_tail.empty()) continue;
        const Path v52_7_head{v52_7_label};
        const Space v53_2 = singleton(v52_7_head);
        const Space v53_3 = intersect(constant_2,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_3 : Space{});
        const Space v53_5 = subtract(constant_1,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_7_head);
          const Space v54_7 = routine_11(c, v54_6, v52_7_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_2,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_3 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_7_head);
          const Space v55_11 = routine_12(c, v55_6, v52_7_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_7_result = unite(v52_7_result,v53_13);
      }
      const Space v52_7 = std::move(v52_7_result);
      v51_8 = compose(v51_5,v52_7);
    }
    const Space v51_9 = intersect(constant_2,v51_2);
    const Space v51_10 = (has_head(v51_9) ? constant_3 : Space{});
    Space v51_12;
    if (!v51_10.empty()) {
      const Path v56_6 = concat_path(p0,v50_12_head);
      Space v56_11_result;
      for (int v56_11_label = 1; v56_11_label <= 2; ++v56_11_label) {
        const Space v56_11_tail = child(v50_12_tail,v56_11_label);
        if (v56_11_tail.empty()) continue;
        const Path v56_11_head{v56_11_label};
        const Space v57_2 = singleton(v56_11_head);
        const Space v57_3 = intersect(constant_2,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_3 : Space{});
        const Space v57_5 = subtract(constant_1,v57_4);
        Space v57_7;
        if (!v57_5.empty()) {
          const Space v58_6 = routine_6(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_7 = compose(v57_5,v58_6);
        }
        const Space v57_8 = intersect(constant_2,v57_2);
        const Space v57_9 = (has_head(v57_8) ? constant_3 : Space{});
        Space v57_11;
        if (!v57_9.empty()) {
          const Space v59_10 = routine_7(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_11 = compose(v57_9,v59_10);
        }
        const Space v57_12 = unite(v57_7,v57_11);
        v56_11_result = unite(v56_11_result,v57_12);
      }
      const Space v56_11 = std::move(v56_11_result);
      v51_12 = compose(v51_10,v56_11);
    }
    const Space v51_13 = unite(v51_8,v51_12);
    v50_12_result = unite(v50_12_result,v51_13);
  }
  const Space v50_12 = std::move(v50_12_result);
  return v50_12;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v60_13_result;
  for (int v60_13_label = 1; v60_13_label <= 2; ++v60_13_label) {
    const Space v60_13_tail = child(s0,v60_13_label);
    if (v60_13_tail.empty()) continue;
    const Path v60_13_head{v60_13_label};
    const Space v61_2 = singleton(v60_13_head);
    const Space v61_3 = intersect(constant_2,v61_2);
    const Space v61_4 = (has_head(v61_3) ? constant_3 : Space{});
    const Space v61_5 = subtract(constant_1,v61_4);
    Space v61_8;
    if (!v61_5.empty()) {
      const Path v62_6 = concat_path(p0,v60_13_head);
      Space v62_7_result;
      for (int v62_7_label = 1; v62_7_label <= 2; ++v62_7_label) {
        const Space v62_7_tail = child(v60_13_tail,v62_7_label);
        if (v62_7_tail.empty()) continue;
        const Path v62_7_head{v62_7_label};
        const Space v63_2 = singleton(v62_7_head);
        const Space v63_3 = intersect(constant_2,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_3 : Space{});
        const Space v63_5 = subtract(constant_1,v63_4);
        Space v63_8;
        if (!v63_5.empty()) {
          const Path v64_6 = concat_path(v62_6,v62_7_head);
          const Space v64_7 = routine_13(c, v64_6, p1, v62_7_tail, s1);
          v63_8 = compose(v63_5,v64_7);
        }
        const Space v63_9 = intersect(constant_2,v63_2);
        const Space v63_10 = (has_head(v63_9) ? constant_3 : Space{});
        Space v63_12;
        if (!v63_10.empty()) {
          const Path v65_6 = concat_path(v62_6,v62_7_head);
          const Space v65_11 = routine_14(c, v65_6, p1, v62_7_tail, s1);
          v63_12 = compose(v63_10,v65_11);
        }
        const Space v63_13 = unite(v63_8,v63_12);
        v62_7_result = unite(v62_7_result,v63_13);
      }
      const Space v62_7 = std::move(v62_7_result);
      v61_8 = compose(v61_5,v62_7);
    }
    const Space v61_9 = intersect(constant_2,v61_2);
    const Space v61_10 = (has_head(v61_9) ? constant_3 : Space{});
    Space v61_12;
    if (!v61_10.empty()) {
      const Path v66_6 = concat_path(p0,v60_13_head);
      Space v66_11_result;
      for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
        const Space v66_11_tail = child(v60_13_tail,v66_11_label);
        if (v66_11_tail.empty()) continue;
        const Path v66_11_head{v66_11_label};
        const Space v67_2 = singleton(v66_11_head);
        const Space v67_3 = intersect(constant_2,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_3 : Space{});
        const Space v67_5 = subtract(constant_1,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_11_head);
          const Space v68_7 = routine_13(c, v68_6, p1, v66_11_tail, s1);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_2,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_3 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_11_head);
          const Space v69_11 = routine_10(c, v69_6, p1, v66_11_tail, s1);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_11_result = unite(v66_11_result,v67_13);
      }
      const Space v66_11 = std::move(v66_11_result);
      v61_12 = compose(v61_10,v66_11);
    }
    const Space v61_13 = unite(v61_8,v61_12);
    v60_13_result = unite(v60_13_result,v61_13);
  }
  const Space v60_13 = std::move(v60_13_result);
  return v60_13;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v70_8 = unwrap(s1,constant_0);
  const Space v70_9 = unwrap(v70_8,p0);
  Space v70_16_result;
  for (int v70_16_label = 1; v70_16_label <= 2; ++v70_16_label) {
    const Space v70_16_tail = child(s0,v70_16_label);
    if (v70_16_tail.empty()) continue;
    const Path v70_16_head{v70_16_label};
    const Space v71_2 = singleton(v70_16_head);
    const Space v71_3 = intersect(constant_2,v71_2);
    const Space v71_4 = (has_head(v71_3) ? constant_3 : Space{});
    const Space v71_5 = subtract(constant_1,v71_4);
    Space v71_8;
    if (!v71_5.empty()) {
      const Path v72_6 = concat_path(p0,v70_16_head);
      Space v72_7_result;
      for (int v72_7_label = 1; v72_7_label <= 2; ++v72_7_label) {
        const Space v72_7_tail = child(v70_16_tail,v72_7_label);
        if (v72_7_tail.empty()) continue;
        const Path v72_7_head{v72_7_label};
        const Space v73_2 = singleton(v72_7_head);
        const Space v73_3 = intersect(constant_2,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_3 : Space{});
        const Space v73_5 = subtract(constant_1,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_7_head);
          const Space v74_7 = routine_13(c, v74_6, p1, v72_7_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_2,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_3 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_7_head);
          const Space v75_11 = routine_14(c, v75_6, p1, v72_7_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_7_result = unite(v72_7_result,v73_13);
      }
      const Space v72_7 = std::move(v72_7_result);
      v71_8 = compose(v71_5,v72_7);
    }
    const Space v71_9 = intersect(constant_2,v71_2);
    const Space v71_10 = (has_head(v71_9) ? constant_3 : Space{});
    Space v71_13;
    if (!v71_10.empty()) {
      const Space v76_11 = unwrap(v70_9,v70_16_head);
      Space v76_12_result;
      for (int v76_12_label = 1; v76_12_label <= 2; ++v76_12_label) {
        const Space v76_12_tail = child(v76_11,v76_12_label);
        if (v76_12_tail.empty()) continue;
        const Path v76_12_head{v76_12_label};
        const Space v77_2 = singleton(v76_12_head);
        const Space v77_3 = intersect(constant_2,v77_2);
        const Space v77_4 = (has_head(v77_3) ? constant_3 : Space{});
        const Space v77_5 = subtract(constant_1,v77_4);
        Space v77_7;
        if (!v77_5.empty()) {
          const Space v78_6 = routine_15(c, v76_12_head, p1, v76_12_tail);
          v77_7 = compose(v77_5,v78_6);
        }
        const Space v77_8 = intersect(constant_2,v77_2);
        const Space v77_9 = (has_head(v77_8) ? constant_3 : Space{});
        Space v77_11;
        if (!v77_9.empty()) {
          const Space v79_10 = routine_16(c, v76_12_head, p1, v76_12_tail);
          v77_11 = compose(v77_9,v79_10);
        }
        const Space v77_12 = unite(v77_7,v77_11);
        v76_12_result = unite(v76_12_result,v77_12);
      }
      const Space v76_12 = std::move(v76_12_result);
      v71_13 = compose(v71_10,v76_12);
    }
    const Space v71_14 = unite(v71_8,v71_13);
    v70_16_result = unite(v70_16_result,v71_14);
  }
  const Space v70_16 = std::move(v70_16_result);
  return v70_16;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v80_13_result;
  for (int v80_13_label = 1; v80_13_label <= 2; ++v80_13_label) {
    const Space v80_13_tail = child(s0,v80_13_label);
    if (v80_13_tail.empty()) continue;
    const Path v80_13_head{v80_13_label};
    const Space v81_2 = singleton(v80_13_head);
    const Space v81_3 = intersect(constant_2,v81_2);
    const Space v81_4 = (has_head(v81_3) ? constant_3 : Space{});
    const Space v81_5 = subtract(constant_1,v81_4);
    Space v81_8;
    if (!v81_5.empty()) {
      const Path v82_6 = concat_path(p0,v80_13_head);
      Space v82_7_result;
      for (int v82_7_label = 1; v82_7_label <= 2; ++v82_7_label) {
        const Space v82_7_tail = child(v80_13_tail,v82_7_label);
        if (v82_7_tail.empty()) continue;
        const Path v82_7_head{v82_7_label};
        const Space v83_2 = singleton(v82_7_head);
        const Space v83_3 = intersect(constant_2,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_3 : Space{});
        const Space v83_5 = subtract(constant_1,v83_4);
        Space v83_8;
        if (!v83_5.empty()) {
          const Path v84_6 = concat_path(v82_6,v82_7_head);
          const Space v84_7 = routine_17(c, v84_6, p1, v82_7_tail, s1);
          v83_8 = compose(v83_5,v84_7);
        }
        const Space v83_9 = intersect(constant_2,v83_2);
        const Space v83_10 = (has_head(v83_9) ? constant_3 : Space{});
        Space v83_12;
        if (!v83_10.empty()) {
          const Path v85_6 = concat_path(v82_6,v82_7_head);
          const Space v85_11 = routine_18(c, v85_6, p1, v82_7_tail, s1);
          v83_12 = compose(v83_10,v85_11);
        }
        const Space v83_13 = unite(v83_8,v83_12);
        v82_7_result = unite(v82_7_result,v83_13);
      }
      const Space v82_7 = std::move(v82_7_result);
      v81_8 = compose(v81_5,v82_7);
    }
    const Space v81_9 = intersect(constant_2,v81_2);
    const Space v81_10 = (has_head(v81_9) ? constant_3 : Space{});
    Space v81_12;
    if (!v81_10.empty()) {
      const Path v86_6 = concat_path(p0,v80_13_head);
      Space v86_11_result;
      for (int v86_11_label = 1; v86_11_label <= 2; ++v86_11_label) {
        const Space v86_11_tail = child(v80_13_tail,v86_11_label);
        if (v86_11_tail.empty()) continue;
        const Path v86_11_head{v86_11_label};
        const Space v87_2 = singleton(v86_11_head);
        const Space v87_3 = intersect(constant_2,v87_2);
        const Space v87_4 = (has_head(v87_3) ? constant_3 : Space{});
        const Space v87_5 = subtract(constant_1,v87_4);
        Space v87_8;
        if (!v87_5.empty()) {
          const Path v88_6 = concat_path(v86_6,v86_11_head);
          const Space v88_7 = routine_17(c, v88_6, p1, v86_11_tail, s1);
          v87_8 = compose(v87_5,v88_7);
        }
        const Space v87_9 = intersect(constant_2,v87_2);
        const Space v87_10 = (has_head(v87_9) ? constant_3 : Space{});
        Space v87_12;
        if (!v87_10.empty()) {
          const Path v89_6 = concat_path(v86_6,v86_11_head);
          const Space v89_11 = routine_10(c, v89_6, p1, v86_11_tail, s1);
          v87_12 = compose(v87_10,v89_11);
        }
        const Space v87_13 = unite(v87_8,v87_12);
        v86_11_result = unite(v86_11_result,v87_13);
      }
      const Space v86_11 = std::move(v86_11_result);
      v81_12 = compose(v81_10,v86_11);
    }
    const Space v81_13 = unite(v81_8,v81_12);
    v80_13_result = unite(v80_13_result,v81_13);
  }
  const Space v80_13 = std::move(v80_13_result);
  return v80_13;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v90_8 = unwrap(s1,constant_0);
  const Space v90_9 = unwrap(v90_8,p0);
  Space v90_16_result;
  for (int v90_16_label = 1; v90_16_label <= 2; ++v90_16_label) {
    const Space v90_16_tail = child(s0,v90_16_label);
    if (v90_16_tail.empty()) continue;
    const Path v90_16_head{v90_16_label};
    const Space v91_2 = singleton(v90_16_head);
    const Space v91_3 = intersect(constant_2,v91_2);
    const Space v91_4 = (has_head(v91_3) ? constant_3 : Space{});
    const Space v91_5 = subtract(constant_1,v91_4);
    Space v91_8;
    if (!v91_5.empty()) {
      const Path v92_6 = concat_path(p0,v90_16_head);
      Space v92_7_result;
      for (int v92_7_label = 1; v92_7_label <= 2; ++v92_7_label) {
        const Space v92_7_tail = child(v90_16_tail,v92_7_label);
        if (v92_7_tail.empty()) continue;
        const Path v92_7_head{v92_7_label};
        const Space v93_2 = singleton(v92_7_head);
        const Space v93_3 = intersect(constant_2,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_3 : Space{});
        const Space v93_5 = subtract(constant_1,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v92_6,v92_7_head);
          const Space v94_7 = routine_17(c, v94_6, p1, v92_7_tail, s1);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_2,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_3 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v92_6,v92_7_head);
          const Space v95_11 = routine_18(c, v95_6, p1, v92_7_tail, s1);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_7_result = unite(v92_7_result,v93_13);
      }
      const Space v92_7 = std::move(v92_7_result);
      v91_8 = compose(v91_5,v92_7);
    }
    const Space v91_9 = intersect(constant_2,v91_2);
    const Space v91_10 = (has_head(v91_9) ? constant_3 : Space{});
    Space v91_13;
    if (!v91_10.empty()) {
      const Space v96_11 = unwrap(v90_9,v90_16_head);
      Space v96_12_result;
      for (int v96_12_label = 1; v96_12_label <= 2; ++v96_12_label) {
        const Space v96_12_tail = child(v96_11,v96_12_label);
        if (v96_12_tail.empty()) continue;
        const Path v96_12_head{v96_12_label};
        const Space v97_2 = singleton(v96_12_head);
        const Space v97_3 = intersect(constant_2,v97_2);
        const Space v97_4 = (has_head(v97_3) ? constant_3 : Space{});
        const Space v97_5 = subtract(constant_1,v97_4);
        Space v97_7;
        if (!v97_5.empty()) {
          const Space v98_6 = routine_15(c, v96_12_head, p1, v96_12_tail);
          v97_7 = compose(v97_5,v98_6);
        }
        const Space v97_8 = intersect(constant_2,v97_2);
        const Space v97_9 = (has_head(v97_8) ? constant_3 : Space{});
        Space v97_11;
        if (!v97_9.empty()) {
          const Space v99_10 = routine_16(c, v96_12_head, p1, v96_12_tail);
          v97_11 = compose(v97_9,v99_10);
        }
        const Space v97_12 = unite(v97_7,v97_11);
        v96_12_result = unite(v96_12_result,v97_12);
      }
      const Space v96_12 = std::move(v96_12_result);
      v91_13 = compose(v91_10,v96_12);
    }
    const Space v91_14 = unite(v91_8,v91_13);
    v90_16_result = unite(v90_16_result,v91_14);
  }
  const Space v90_16 = std::move(v90_16_result);
  return v90_16;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v100_5 = unwrap(s1,constant_0);
  const Space v100_6 = unwrap(v100_5,p0);
  Space v100_16_result;
  for (int v100_16_label = 1; v100_16_label <= 2; ++v100_16_label) {
    const Space v100_16_tail = child(v100_6,v100_16_label);
    if (v100_16_tail.empty()) continue;
    const Path v100_16_head{v100_16_label};
    const Space v101_2 = singleton(v100_16_head);
    const Space v101_3 = intersect(constant_2,v101_2);
    const Space v101_4 = (has_head(v101_3) ? constant_3 : Space{});
    const Space v101_5 = subtract(constant_1,v101_4);
    Space v101_7;
    if (!v101_5.empty()) {
      Space v102_6_result;
      for (int v102_6_label = 1; v102_6_label <= 2; ++v102_6_label) {
        const Space v102_6_tail = child(v100_16_tail,v102_6_label);
        if (v102_6_tail.empty()) continue;
        const Path v102_6_head{v102_6_label};
        const Space v103_2 = singleton(v102_6_head);
        const Space v103_3 = intersect(constant_2,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_3 : Space{});
        const Space v103_5 = subtract(constant_1,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v100_16_head,v102_6_head);
          const Space v104_7 = routine_19(c, v104_6, p1, v102_6_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_2,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_3 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v100_16_head,v102_6_head);
          const Space v105_11 = routine_20(c, v105_6, p1, v102_6_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_6_result = unite(v102_6_result,v103_13);
      }
      const Space v102_6 = std::move(v102_6_result);
      v101_7 = compose(v101_5,v102_6);
    }
    const Space v101_8 = intersect(constant_2,v101_2);
    const Space v101_9 = (has_head(v101_8) ? constant_3 : Space{});
    Space v101_11;
    if (!v101_9.empty()) {
      Space v106_10_result;
      for (int v106_10_label = 1; v106_10_label <= 2; ++v106_10_label) {
        const Space v106_10_tail = child(v100_16_tail,v106_10_label);
        if (v106_10_tail.empty()) continue;
        const Path v106_10_head{v106_10_label};
        const Space v107_2 = singleton(v106_10_head);
        const Space v107_3 = intersect(constant_2,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_3 : Space{});
        const Space v107_5 = subtract(constant_1,v107_4);
        Space v107_8;
        if (!v107_5.empty()) {
          const Path v108_6 = concat_path(v100_16_head,v106_10_head);
          const Space v108_7 = routine_19(c, v108_6, p1, v106_10_tail);
          v107_8 = compose(v107_5,v108_7);
        }
        const Space v107_9 = intersect(constant_2,v107_2);
        const Space v107_10 = (has_head(v107_9) ? constant_3 : Space{});
        Space v107_12;
        if (!v107_10.empty()) {
          const Path v109_6 = concat_path(v100_16_head,v106_10_head);
          const Space v109_11 = routine_21(c, v109_6, p1, v106_10_tail);
          v107_12 = compose(v107_10,v109_11);
        }
        const Space v107_13 = unite(v107_8,v107_12);
        v106_10_result = unite(v106_10_result,v107_13);
      }
      const Space v106_10 = std::move(v106_10_result);
      v101_11 = compose(v101_9,v106_10);
    }
    const Space v101_12 = unite(v101_7,v101_11);
    v100_16_result = unite(v100_16_result,v101_12);
  }
  const Space v100_16 = std::move(v100_16_result);
  return v100_16;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v110_12_result;
  for (int v110_12_label = 1; v110_12_label <= 2; ++v110_12_label) {
    const Space v110_12_tail = child(s0,v110_12_label);
    if (v110_12_tail.empty()) continue;
    const Path v110_12_head{v110_12_label};
    const Space v111_2 = singleton(v110_12_head);
    const Space v111_3 = intersect(constant_2,v111_2);
    const Space v111_4 = (has_head(v111_3) ? constant_3 : Space{});
    const Space v111_5 = subtract(constant_1,v111_4);
    Space v111_8;
    if (!v111_5.empty()) {
      const Path v112_6 = concat_path(p0,v110_12_head);
      Space v112_7_result;
      for (int v112_7_label = 1; v112_7_label <= 2; ++v112_7_label) {
        const Space v112_7_tail = child(v110_12_tail,v112_7_label);
        if (v112_7_tail.empty()) continue;
        const Path v112_7_head{v112_7_label};
        const Space v113_2 = singleton(v112_7_head);
        const Space v113_3 = intersect(constant_2,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_3 : Space{});
        const Space v113_5 = subtract(constant_1,v113_4);
        Space v113_8;
        if (!v113_5.empty()) {
          const Path v114_6 = concat_path(v112_6,v112_7_head);
          const Space v114_7 = routine_22(c, v114_6, v112_7_tail, s1);
          v113_8 = compose(v113_5,v114_7);
        }
        const Space v113_9 = intersect(constant_2,v113_2);
        const Space v113_10 = (has_head(v113_9) ? constant_3 : Space{});
        Space v113_12;
        if (!v113_10.empty()) {
          const Path v115_6 = concat_path(v112_6,v112_7_head);
          const Space v115_11 = routine_23(c, v115_6, v112_7_tail, s1);
          v113_12 = compose(v113_10,v115_11);
        }
        const Space v113_13 = unite(v113_8,v113_12);
        v112_7_result = unite(v112_7_result,v113_13);
      }
      const Space v112_7 = std::move(v112_7_result);
      v111_8 = compose(v111_5,v112_7);
    }
    const Space v111_9 = intersect(constant_2,v111_2);
    const Space v111_10 = (has_head(v111_9) ? constant_3 : Space{});
    Space v111_12;
    if (!v111_10.empty()) {
      const Path v116_6 = concat_path(p0,v110_12_head);
      Space v116_11_result;
      for (int v116_11_label = 1; v116_11_label <= 2; ++v116_11_label) {
        const Space v116_11_tail = child(v110_12_tail,v116_11_label);
        if (v116_11_tail.empty()) continue;
        const Path v116_11_head{v116_11_label};
        const Space v117_2 = singleton(v116_11_head);
        const Space v117_3 = intersect(constant_2,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_3 : Space{});
        const Space v117_5 = subtract(constant_1,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v116_6,v116_11_head);
          const Space v118_7 = routine_22(c, v118_6, v116_11_tail, s1);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_2,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_3 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v116_6,v116_11_head);
          const Space v119_11 = routine_3(c, v119_6, v116_11_tail, s1);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_11_result = unite(v116_11_result,v117_13);
      }
      const Space v116_11 = std::move(v116_11_result);
      v111_12 = compose(v111_10,v116_11);
    }
    const Space v111_13 = unite(v111_8,v111_12);
    v110_12_result = unite(v110_12_result,v111_13);
  }
  const Space v110_12 = std::move(v110_12_result);
  return v110_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v120_12_result;
  for (int v120_12_label = 1; v120_12_label <= 2; ++v120_12_label) {
    const Space v120_12_tail = child(s0,v120_12_label);
    if (v120_12_tail.empty()) continue;
    const Path v120_12_head{v120_12_label};
    const Space v121_2 = singleton(v120_12_head);
    const Space v121_3 = intersect(constant_2,v121_2);
    const Space v121_4 = (has_head(v121_3) ? constant_3 : Space{});
    const Space v121_5 = subtract(constant_1,v121_4);
    Space v121_8;
    if (!v121_5.empty()) {
      const Path v122_6 = concat_path(p0,v120_12_head);
      Space v122_7_result;
      for (int v122_7_label = 1; v122_7_label <= 2; ++v122_7_label) {
        const Space v122_7_tail = child(v120_12_tail,v122_7_label);
        if (v122_7_tail.empty()) continue;
        const Path v122_7_head{v122_7_label};
        const Space v123_2 = singleton(v122_7_head);
        const Space v123_3 = intersect(constant_2,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_3 : Space{});
        const Space v123_5 = subtract(constant_1,v123_4);
        Space v123_8;
        if (!v123_5.empty()) {
          const Path v124_6 = concat_path(v122_6,v122_7_head);
          const Space v124_7 = routine_22(c, v124_6, v122_7_tail, s1);
          v123_8 = compose(v123_5,v124_7);
        }
        const Space v123_9 = intersect(constant_2,v123_2);
        const Space v123_10 = (has_head(v123_9) ? constant_3 : Space{});
        Space v123_12;
        if (!v123_10.empty()) {
          const Path v125_6 = concat_path(v122_6,v122_7_head);
          const Space v125_11 = routine_23(c, v125_6, v122_7_tail, s1);
          v123_12 = compose(v123_10,v125_11);
        }
        const Space v123_13 = unite(v123_8,v123_12);
        v122_7_result = unite(v122_7_result,v123_13);
      }
      const Space v122_7 = std::move(v122_7_result);
      v121_8 = compose(v121_5,v122_7);
    }
    const Space v121_9 = intersect(constant_2,v121_2);
    const Space v121_10 = (has_head(v121_9) ? constant_3 : Space{});
    Space v121_12;
    if (!v121_10.empty()) {
      const Path v126_6 = concat_path(p0,v120_12_head);
      Space v126_11_result;
      for (int v126_11_label = 1; v126_11_label <= 2; ++v126_11_label) {
        const Space v126_11_tail = child(v120_12_tail,v126_11_label);
        if (v126_11_tail.empty()) continue;
        const Path v126_11_head{v126_11_label};
        const Space v127_2 = singleton(v126_11_head);
        const Space v127_3 = intersect(constant_2,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_3 : Space{});
        const Space v127_5 = subtract(constant_1,v127_4);
        Space v127_7;
        if (!v127_5.empty()) {
          const Space v128_6 = routine_6(c, v126_11_head, v126_6, v126_11_tail, s1);
          v127_7 = compose(v127_5,v128_6);
        }
        const Space v127_8 = intersect(constant_2,v127_2);
        const Space v127_9 = (has_head(v127_8) ? constant_3 : Space{});
        Space v127_11;
        if (!v127_9.empty()) {
          const Space v129_10 = routine_7(c, v126_11_head, v126_6, v126_11_tail, s1);
          v127_11 = compose(v127_9,v129_10);
        }
        const Space v127_12 = unite(v127_7,v127_11);
        v126_11_result = unite(v126_11_result,v127_12);
      }
      const Space v126_11 = std::move(v126_11_result);
      v121_12 = compose(v121_10,v126_11);
    }
    const Space v121_13 = unite(v121_8,v121_12);
    v120_12_result = unite(v120_12_result,v121_13);
  }
  const Space v120_12 = std::move(v120_12_result);
  return v120_12;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v130_13_result;
  for (int v130_13_label = 1; v130_13_label <= 2; ++v130_13_label) {
    const Space v130_13_tail = child(s0,v130_13_label);
    if (v130_13_tail.empty()) continue;
    const Path v130_13_head{v130_13_label};
    const Space v131_2 = singleton(v130_13_head);
    const Space v131_3 = intersect(constant_2,v131_2);
    const Space v131_4 = (has_head(v131_3) ? constant_3 : Space{});
    const Space v131_5 = subtract(constant_1,v131_4);
    Space v131_8;
    if (!v131_5.empty()) {
      const Path v132_6 = concat_path(p0,v130_13_head);
      Space v132_7_result;
      for (int v132_7_label = 1; v132_7_label <= 2; ++v132_7_label) {
        const Space v132_7_tail = child(v130_13_tail,v132_7_label);
        if (v132_7_tail.empty()) continue;
        const Path v132_7_head{v132_7_label};
        const Space v133_2 = singleton(v132_7_head);
        const Space v133_3 = intersect(constant_2,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_3 : Space{});
        const Space v133_5 = subtract(constant_1,v133_4);
        Space v133_8;
        if (!v133_5.empty()) {
          const Path v134_6 = concat_path(v132_6,v132_7_head);
          const Space v134_7 = routine_24(c, v134_6, p1, v132_7_tail, s1);
          v133_8 = compose(v133_5,v134_7);
        }
        const Space v133_9 = intersect(constant_2,v133_2);
        const Space v133_10 = (has_head(v133_9) ? constant_3 : Space{});
        Space v133_12;
        if (!v133_10.empty()) {
          const Path v135_6 = concat_path(v132_6,v132_7_head);
          const Space v135_11 = routine_25(c, v135_6, p1, v132_7_tail, s1);
          v133_12 = compose(v133_10,v135_11);
        }
        const Space v133_13 = unite(v133_8,v133_12);
        v132_7_result = unite(v132_7_result,v133_13);
      }
      const Space v132_7 = std::move(v132_7_result);
      v131_8 = compose(v131_5,v132_7);
    }
    const Space v131_9 = intersect(constant_2,v131_2);
    const Space v131_10 = (has_head(v131_9) ? constant_3 : Space{});
    Space v131_12;
    if (!v131_10.empty()) {
      const Path v136_6 = concat_path(p0,v130_13_head);
      Space v136_11_result;
      for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
        const Space v136_11_tail = child(v130_13_tail,v136_11_label);
        if (v136_11_tail.empty()) continue;
        const Path v136_11_head{v136_11_label};
        const Space v137_2 = singleton(v136_11_head);
        const Space v137_3 = intersect(constant_2,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_3 : Space{});
        const Space v137_5 = subtract(constant_1,v137_4);
        Space v137_8;
        if (!v137_5.empty()) {
          const Path v138_6 = concat_path(v136_6,v136_11_head);
          const Space v138_7 = routine_24(c, v138_6, p1, v136_11_tail, s1);
          v137_8 = compose(v137_5,v138_7);
        }
        const Space v137_9 = intersect(constant_2,v137_2);
        const Space v137_10 = (has_head(v137_9) ? constant_3 : Space{});
        Space v137_12;
        if (!v137_10.empty()) {
          const Path v139_6 = concat_path(v136_6,v136_11_head);
          const Space v139_11 = routine_10(c, v139_6, p1, v136_11_tail, s1);
          v137_12 = compose(v137_10,v139_11);
        }
        const Space v137_13 = unite(v137_8,v137_12);
        v136_11_result = unite(v136_11_result,v137_13);
      }
      const Space v136_11 = std::move(v136_11_result);
      v131_12 = compose(v131_10,v136_11);
    }
    const Space v131_13 = unite(v131_8,v131_12);
    v130_13_result = unite(v130_13_result,v131_13);
  }
  const Space v130_13 = std::move(v130_13_result);
  return v130_13;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v140_8 = unwrap(s1,constant_0);
  const Space v140_9 = unwrap(v140_8,p0);
  Space v140_16_result;
  for (int v140_16_label = 1; v140_16_label <= 2; ++v140_16_label) {
    const Space v140_16_tail = child(s0,v140_16_label);
    if (v140_16_tail.empty()) continue;
    const Path v140_16_head{v140_16_label};
    const Space v141_2 = singleton(v140_16_head);
    const Space v141_3 = intersect(constant_2,v141_2);
    const Space v141_4 = (has_head(v141_3) ? constant_3 : Space{});
    const Space v141_5 = subtract(constant_1,v141_4);
    Space v141_8;
    if (!v141_5.empty()) {
      const Path v142_6 = concat_path(p0,v140_16_head);
      Space v142_7_result;
      for (int v142_7_label = 1; v142_7_label <= 2; ++v142_7_label) {
        const Space v142_7_tail = child(v140_16_tail,v142_7_label);
        if (v142_7_tail.empty()) continue;
        const Path v142_7_head{v142_7_label};
        const Space v143_2 = singleton(v142_7_head);
        const Space v143_3 = intersect(constant_2,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_3 : Space{});
        const Space v143_5 = subtract(constant_1,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v142_6,v142_7_head);
          const Space v144_7 = routine_24(c, v144_6, p1, v142_7_tail, s1);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_2,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_3 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v142_6,v142_7_head);
          const Space v145_11 = routine_25(c, v145_6, p1, v142_7_tail, s1);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_7_result = unite(v142_7_result,v143_13);
      }
      const Space v142_7 = std::move(v142_7_result);
      v141_8 = compose(v141_5,v142_7);
    }
    const Space v141_9 = intersect(constant_2,v141_2);
    const Space v141_10 = (has_head(v141_9) ? constant_3 : Space{});
    Space v141_13;
    if (!v141_10.empty()) {
      const Space v146_11 = unwrap(v140_9,v140_16_head);
      Space v146_12_result;
      for (int v146_12_label = 1; v146_12_label <= 2; ++v146_12_label) {
        const Space v146_12_tail = child(v146_11,v146_12_label);
        if (v146_12_tail.empty()) continue;
        const Path v146_12_head{v146_12_label};
        const Space v147_2 = singleton(v146_12_head);
        const Space v147_3 = intersect(constant_2,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_3 : Space{});
        const Space v147_5 = subtract(constant_1,v147_4);
        Space v147_7;
        if (!v147_5.empty()) {
          const Space v148_6 = routine_15(c, v146_12_head, p1, v146_12_tail);
          v147_7 = compose(v147_5,v148_6);
        }
        const Space v147_8 = intersect(constant_2,v147_2);
        const Space v147_9 = (has_head(v147_8) ? constant_3 : Space{});
        Space v147_11;
        if (!v147_9.empty()) {
          const Space v149_10 = routine_16(c, v146_12_head, p1, v146_12_tail);
          v147_11 = compose(v147_9,v149_10);
        }
        const Space v147_12 = unite(v147_7,v147_11);
        v146_12_result = unite(v146_12_result,v147_12);
      }
      const Space v146_12 = std::move(v146_12_result);
      v141_13 = compose(v141_10,v146_12);
    }
    const Space v141_14 = unite(v141_8,v141_13);
    v140_16_result = unite(v140_16_result,v141_14);
  }
  const Space v140_16 = std::move(v140_16_result);
  return v140_16;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v150_12_result;
  for (int v150_12_label = 1; v150_12_label <= 2; ++v150_12_label) {
    const Space v150_12_tail = child(s0,v150_12_label);
    if (v150_12_tail.empty()) continue;
    const Path v150_12_head{v150_12_label};
    const Space v151_2 = singleton(v150_12_head);
    const Space v151_3 = intersect(constant_2,v151_2);
    const Space v151_4 = (has_head(v151_3) ? constant_3 : Space{});
    const Space v151_5 = subtract(constant_1,v151_4);
    Space v151_8;
    if (!v151_5.empty()) {
      const Path v152_6 = concat_path(p0,v150_12_head);
      Space v152_7_result;
      for (int v152_7_label = 1; v152_7_label <= 2; ++v152_7_label) {
        const Space v152_7_tail = child(v150_12_tail,v152_7_label);
        if (v152_7_tail.empty()) continue;
        const Path v152_7_head{v152_7_label};
        const Space v153_2 = singleton(v152_7_head);
        const Space v153_3 = intersect(constant_2,v153_2);
        const Space v153_4 = (has_head(v153_3) ? constant_3 : Space{});
        const Space v153_5 = subtract(constant_1,v153_4);
        Space v153_8;
        if (!v153_5.empty()) {
          const Path v154_6 = concat_path(v152_6,v152_7_head);
          const Space v154_7 = routine_26(c, v154_6, p1, v152_7_tail);
          v153_8 = compose(v153_5,v154_7);
        }
        const Space v153_9 = intersect(constant_2,v153_2);
        const Space v153_10 = (has_head(v153_9) ? constant_3 : Space{});
        Space v153_12;
        if (!v153_10.empty()) {
          const Path v155_6 = concat_path(v152_6,v152_7_head);
          const Space v155_11 = routine_27(c, v155_6, p1, v152_7_tail);
          v153_12 = compose(v153_10,v155_11);
        }
        const Space v153_13 = unite(v153_8,v153_12);
        v152_7_result = unite(v152_7_result,v153_13);
      }
      const Space v152_7 = std::move(v152_7_result);
      v151_8 = compose(v151_5,v152_7);
    }
    const Space v151_9 = intersect(constant_2,v151_2);
    const Space v151_10 = (has_head(v151_9) ? constant_3 : Space{});
    Space v151_12;
    if (!v151_10.empty()) {
      const Path v156_6 = concat_path(p0,v150_12_head);
      Space v156_11_result;
      for (int v156_11_label = 1; v156_11_label <= 2; ++v156_11_label) {
        const Space v156_11_tail = child(v150_12_tail,v156_11_label);
        if (v156_11_tail.empty()) continue;
        const Path v156_11_head{v156_11_label};
        const Space v157_2 = singleton(v156_11_head);
        const Space v157_3 = intersect(constant_2,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_3 : Space{});
        const Space v157_5 = subtract(constant_1,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_11_head);
          const Space v158_7 = routine_26(c, v158_6, p1, v156_11_tail);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_2,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_3 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_11_head);
          const Space v159_11 = routine_21(c, v159_6, p1, v156_11_tail);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_11_result = unite(v156_11_result,v157_13);
      }
      const Space v156_11 = std::move(v156_11_result);
      v151_12 = compose(v151_10,v156_11);
    }
    const Space v151_13 = unite(v151_8,v151_12);
    v150_12_result = unite(v150_12_result,v151_13);
  }
  const Space v150_12 = std::move(v150_12_result);
  return v150_12;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v160_9_result;
  for (int v160_9_label = 1; v160_9_label <= 2; ++v160_9_label) {
    const Space v160_9_tail = child(s0,v160_9_label);
    if (v160_9_tail.empty()) continue;
    const Path v160_9_head{v160_9_label};
    const Space v161_2 = singleton(v160_9_head);
    const Space v161_3 = intersect(constant_2,v161_2);
    const Space v161_4 = (has_head(v161_3) ? constant_3 : Space{});
    const Space v161_5 = subtract(constant_1,v161_4);
    Space v161_8;
    if (!v161_5.empty()) {
      const Path v162_6 = concat_path(p0,v160_9_head);
      Space v162_7_result;
      for (int v162_7_label = 1; v162_7_label <= 2; ++v162_7_label) {
        const Space v162_7_tail = child(v160_9_tail,v162_7_label);
        if (v162_7_tail.empty()) continue;
        const Path v162_7_head{v162_7_label};
        const Space v163_2 = singleton(v162_7_head);
        const Space v163_3 = intersect(constant_2,v163_2);
        const Space v163_4 = (has_head(v163_3) ? constant_3 : Space{});
        const Space v163_5 = subtract(constant_1,v163_4);
        Space v163_8;
        if (!v163_5.empty()) {
          const Path v164_6 = concat_path(v162_6,v162_7_head);
          const Space v164_7 = routine_26(c, v164_6, p1, v162_7_tail);
          v163_8 = compose(v163_5,v164_7);
        }
        const Space v163_9 = intersect(constant_2,v163_2);
        const Space v163_10 = (has_head(v163_9) ? constant_3 : Space{});
        Space v163_12;
        if (!v163_10.empty()) {
          const Path v165_6 = concat_path(v162_6,v162_7_head);
          const Space v165_11 = routine_27(c, v165_6, p1, v162_7_tail);
          v163_12 = compose(v163_10,v165_11);
        }
        const Space v163_13 = unite(v163_8,v163_12);
        v162_7_result = unite(v162_7_result,v163_13);
      }
      const Space v162_7 = std::move(v162_7_result);
      v161_8 = compose(v161_5,v162_7);
    }
    const Space v161_9 = intersect(constant_2,v161_2);
    const Space v161_10 = (has_head(v161_9) ? constant_3 : Space{});
    const Space v161_11 = compose(v161_10,v160_9_tail);
    const Path v166_6 = concat_path(p0,v160_9_head);
    const Space v161_12 = wrap(v161_11,v166_6);
    const Space v161_13 = wrap(v161_12,p1);
    const Space v161_14 = unite(v161_8,v161_13);
    v160_9_result = unite(v160_9_result,v161_14);
  }
  const Space v160_9 = std::move(v160_9_result);
  return v160_9;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v167_13_result;
  for (int v167_13_label = 1; v167_13_label <= 2; ++v167_13_label) {
    const Space v167_13_tail = child(s0,v167_13_label);
    if (v167_13_tail.empty()) continue;
    const Path v167_13_head{v167_13_label};
    const Space v168_2 = singleton(v167_13_head);
    const Space v168_3 = intersect(constant_2,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_3 : Space{});
    const Space v168_5 = subtract(constant_1,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_13_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_13_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_2,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_3 : Space{});
        const Space v170_5 = subtract(constant_1,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_28(c, v171_6, p1, v169_7_tail, s1);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_2,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_3 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_29(c, v172_6, p1, v169_7_tail, s1);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_2,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_3 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_13_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_13_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_2,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_3 : Space{});
        const Space v174_5 = subtract(constant_1,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_28(c, v175_6, p1, v173_11_tail, s1);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_2,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_3 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_10(c, v176_6, p1, v173_11_tail, s1);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_13_result = unite(v167_13_result,v168_13);
  }
  const Space v167_13 = std::move(v167_13_result);
  return v167_13;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v177_8 = unwrap(s1,constant_0);
  const Space v177_9 = unwrap(v177_8,p0);
  Space v177_16_result;
  for (int v177_16_label = 1; v177_16_label <= 2; ++v177_16_label) {
    const Space v177_16_tail = child(s0,v177_16_label);
    if (v177_16_tail.empty()) continue;
    const Path v177_16_head{v177_16_label};
    const Space v178_2 = singleton(v177_16_head);
    const Space v178_3 = intersect(constant_2,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_3 : Space{});
    const Space v178_5 = subtract(constant_1,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_16_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_16_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_2,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_3 : Space{});
        const Space v180_5 = subtract(constant_1,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_28(c, v181_6, p1, v179_7_tail, s1);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_2,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_3 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_29(c, v182_6, p1, v179_7_tail, s1);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_2,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_3 : Space{});
    Space v178_13;
    if (!v178_10.empty()) {
      const Space v183_11 = unwrap(v177_9,v177_16_head);
      Space v183_12_result;
      for (int v183_12_label = 1; v183_12_label <= 2; ++v183_12_label) {
        const Space v183_12_tail = child(v183_11,v183_12_label);
        if (v183_12_tail.empty()) continue;
        const Path v183_12_head{v183_12_label};
        const Space v184_2 = singleton(v183_12_head);
        const Space v184_3 = intersect(constant_2,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_3 : Space{});
        const Space v184_5 = subtract(constant_1,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_15(c, v183_12_head, p1, v183_12_tail);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_2,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_3 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_16(c, v183_12_head, p1, v183_12_tail);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_12_result = unite(v183_12_result,v184_12);
      }
      const Space v183_12 = std::move(v183_12_result);
      v178_13 = compose(v178_10,v183_12);
    }
    const Space v178_14 = unite(v178_8,v178_13);
    v177_16_result = unite(v177_16_result,v178_14);
  }
  const Space v177_16 = std::move(v177_16_result);
  return v177_16;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v187_12_result;
  for (int v187_12_label = 1; v187_12_label <= 2; ++v187_12_label) {
    const Space v187_12_tail = child(s0,v187_12_label);
    if (v187_12_tail.empty()) continue;
    const Path v187_12_head{v187_12_label};
    const Space v188_2 = singleton(v187_12_head);
    const Space v188_3 = intersect(constant_2,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_3 : Space{});
    const Space v188_5 = subtract(constant_1,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_12_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_12_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_2,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_3 : Space{});
        const Space v190_5 = subtract(constant_1,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_30(c, v191_6, p1, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_2,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_3 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_31(c, v192_6, p1, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_2,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_3 : Space{});
    Space v188_12;
    if (!v188_10.empty()) {
      const Path v193_6 = concat_path(p0,v187_12_head);
      Space v193_11_result;
      for (int v193_11_label = 1; v193_11_label <= 2; ++v193_11_label) {
        const Space v193_11_tail = child(v187_12_tail,v193_11_label);
        if (v193_11_tail.empty()) continue;
        const Path v193_11_head{v193_11_label};
        const Space v194_2 = singleton(v193_11_head);
        const Space v194_3 = intersect(constant_2,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_3 : Space{});
        const Space v194_5 = subtract(constant_1,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v193_6,v193_11_head);
          const Space v195_7 = routine_30(c, v195_6, p1, v193_11_tail);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_2,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_3 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v193_6,v193_11_head);
          const Space v196_11 = routine_21(c, v196_6, p1, v193_11_tail);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_11_result = unite(v193_11_result,v194_13);
      }
      const Space v193_11 = std::move(v193_11_result);
      v188_12 = compose(v188_10,v193_11);
    }
    const Space v188_13 = unite(v188_8,v188_12);
    v187_12_result = unite(v187_12_result,v188_13);
  }
  const Space v187_12 = std::move(v187_12_result);
  return v187_12;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v197_9_result;
  for (int v197_9_label = 1; v197_9_label <= 2; ++v197_9_label) {
    const Space v197_9_tail = child(s0,v197_9_label);
    if (v197_9_tail.empty()) continue;
    const Path v197_9_head{v197_9_label};
    const Space v198_2 = singleton(v197_9_head);
    const Space v198_3 = intersect(constant_2,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_3 : Space{});
    const Space v198_5 = subtract(constant_1,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_9_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_9_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_2,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_3 : Space{});
        const Space v200_5 = subtract(constant_1,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_30(c, v201_6, p1, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_2,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_3 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_31(c, v202_6, p1, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_2,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_3 : Space{});
    const Space v198_11 = compose(v198_10,v197_9_tail);
    const Path v203_6 = concat_path(p0,v197_9_head);
    const Space v198_12 = wrap(v198_11,v203_6);
    const Space v198_13 = wrap(v198_12,p1);
    const Space v198_14 = unite(v198_8,v198_13);
    v197_9_result = unite(v197_9_result,v198_14);
  }
  const Space v197_9 = std::move(v197_9_result);
  return v197_9;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v204_3 = wrap(s0,p0);
  const Space v204_4 = wrap(v204_3,p1);
  return v204_4;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v205_12_result;
  for (int v205_12_label = 1; v205_12_label <= 2; ++v205_12_label) {
    const Space v205_12_tail = child(s0,v205_12_label);
    if (v205_12_tail.empty()) continue;
    const Path v205_12_head{v205_12_label};
    const Space v206_2 = singleton(v205_12_head);
    const Space v206_3 = intersect(constant_2,v206_2);
    const Space v206_4 = (has_head(v206_3) ? constant_3 : Space{});
    const Space v206_5 = subtract(constant_1,v206_4);
    Space v206_8;
    if (!v206_5.empty()) {
      const Path v207_6 = concat_path(p0,v205_12_head);
      Space v207_7_result;
      for (int v207_7_label = 1; v207_7_label <= 2; ++v207_7_label) {
        const Space v207_7_tail = child(v205_12_tail,v207_7_label);
        if (v207_7_tail.empty()) continue;
        const Path v207_7_head{v207_7_label};
        const Space v208_2 = singleton(v207_7_head);
        const Space v208_3 = intersect(constant_2,v208_2);
        const Space v208_4 = (has_head(v208_3) ? constant_3 : Space{});
        const Space v208_5 = subtract(constant_1,v208_4);
        Space v208_8;
        if (!v208_5.empty()) {
          const Path v209_6 = concat_path(v207_6,v207_7_head);
          const Space v209_7 = routine_32(c, v209_6, v207_7_tail, s1);
          v208_8 = compose(v208_5,v209_7);
        }
        const Space v208_9 = intersect(constant_2,v208_2);
        const Space v208_10 = (has_head(v208_9) ? constant_3 : Space{});
        Space v208_12;
        if (!v208_10.empty()) {
          const Path v210_6 = concat_path(v207_6,v207_7_head);
          const Space v210_11 = routine_33(c, v210_6, v207_7_tail, s1);
          v208_12 = compose(v208_10,v210_11);
        }
        const Space v208_13 = unite(v208_8,v208_12);
        v207_7_result = unite(v207_7_result,v208_13);
      }
      const Space v207_7 = std::move(v207_7_result);
      v206_8 = compose(v206_5,v207_7);
    }
    const Space v206_9 = intersect(constant_2,v206_2);
    const Space v206_10 = (has_head(v206_9) ? constant_3 : Space{});
    Space v206_12;
    if (!v206_10.empty()) {
      const Path v211_6 = concat_path(p0,v205_12_head);
      Space v211_11_result;
      for (int v211_11_label = 1; v211_11_label <= 2; ++v211_11_label) {
        const Space v211_11_tail = child(v205_12_tail,v211_11_label);
        if (v211_11_tail.empty()) continue;
        const Path v211_11_head{v211_11_label};
        const Space v212_2 = singleton(v211_11_head);
        const Space v212_3 = intersect(constant_2,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_3 : Space{});
        const Space v212_5 = subtract(constant_1,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_11_head);
          const Space v213_7 = routine_32(c, v213_6, v211_11_tail, s1);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_2,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_3 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_11_head);
          const Space v214_11 = routine_3(c, v214_6, v211_11_tail, s1);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_11_result = unite(v211_11_result,v212_13);
      }
      const Space v211_11 = std::move(v211_11_result);
      v206_12 = compose(v206_10,v211_11);
    }
    const Space v206_13 = unite(v206_8,v206_12);
    v205_12_result = unite(v205_12_result,v206_13);
  }
  const Space v205_12 = std::move(v205_12_result);
  return v205_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v215_12_result;
  for (int v215_12_label = 1; v215_12_label <= 2; ++v215_12_label) {
    const Space v215_12_tail = child(s0,v215_12_label);
    if (v215_12_tail.empty()) continue;
    const Path v215_12_head{v215_12_label};
    const Space v216_2 = singleton(v215_12_head);
    const Space v216_3 = intersect(constant_2,v216_2);
    const Space v216_4 = (has_head(v216_3) ? constant_3 : Space{});
    const Space v216_5 = subtract(constant_1,v216_4);
    Space v216_8;
    if (!v216_5.empty()) {
      const Path v217_6 = concat_path(p0,v215_12_head);
      Space v217_7_result;
      for (int v217_7_label = 1; v217_7_label <= 2; ++v217_7_label) {
        const Space v217_7_tail = child(v215_12_tail,v217_7_label);
        if (v217_7_tail.empty()) continue;
        const Path v217_7_head{v217_7_label};
        const Space v218_2 = singleton(v217_7_head);
        const Space v218_3 = intersect(constant_2,v218_2);
        const Space v218_4 = (has_head(v218_3) ? constant_3 : Space{});
        const Space v218_5 = subtract(constant_1,v218_4);
        Space v218_8;
        if (!v218_5.empty()) {
          const Path v219_6 = concat_path(v217_6,v217_7_head);
          const Space v219_7 = routine_32(c, v219_6, v217_7_tail, s1);
          v218_8 = compose(v218_5,v219_7);
        }
        const Space v218_9 = intersect(constant_2,v218_2);
        const Space v218_10 = (has_head(v218_9) ? constant_3 : Space{});
        Space v218_12;
        if (!v218_10.empty()) {
          const Path v220_6 = concat_path(v217_6,v217_7_head);
          const Space v220_11 = routine_33(c, v220_6, v217_7_tail, s1);
          v218_12 = compose(v218_10,v220_11);
        }
        const Space v218_13 = unite(v218_8,v218_12);
        v217_7_result = unite(v217_7_result,v218_13);
      }
      const Space v217_7 = std::move(v217_7_result);
      v216_8 = compose(v216_5,v217_7);
    }
    const Space v216_9 = intersect(constant_2,v216_2);
    const Space v216_10 = (has_head(v216_9) ? constant_3 : Space{});
    Space v216_12;
    if (!v216_10.empty()) {
      const Path v221_6 = concat_path(p0,v215_12_head);
      Space v221_11_result;
      for (int v221_11_label = 1; v221_11_label <= 2; ++v221_11_label) {
        const Space v221_11_tail = child(v215_12_tail,v221_11_label);
        if (v221_11_tail.empty()) continue;
        const Path v221_11_head{v221_11_label};
        const Space v222_2 = singleton(v221_11_head);
        const Space v222_3 = intersect(constant_2,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_3 : Space{});
        const Space v222_5 = subtract(constant_1,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_6(c, v221_11_head, v221_6, v221_11_tail, s1);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_2,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_3 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_7(c, v221_11_head, v221_6, v221_11_tail, s1);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v221_11_result = unite(v221_11_result,v222_12);
      }
      const Space v221_11 = std::move(v221_11_result);
      v216_12 = compose(v216_10,v221_11);
    }
    const Space v216_13 = unite(v216_8,v216_12);
    v215_12_result = unite(v215_12_result,v216_13);
  }
  const Space v215_12 = std::move(v215_12_result);
  return v215_12;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v225_13_result;
  for (int v225_13_label = 1; v225_13_label <= 2; ++v225_13_label) {
    const Space v225_13_tail = child(s0,v225_13_label);
    if (v225_13_tail.empty()) continue;
    const Path v225_13_head{v225_13_label};
    const Space v226_2 = singleton(v225_13_head);
    const Space v226_3 = intersect(constant_2,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_3 : Space{});
    const Space v226_5 = subtract(constant_1,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_13_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_13_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_2,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_3 : Space{});
        const Space v228_5 = subtract(constant_1,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_34(c, v229_6, p1, v227_7_tail, s1);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_2,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_3 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_35(c, v230_6, p1, v227_7_tail, s1);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_2,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_3 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_13_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_13_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_2,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_3 : Space{});
        const Space v232_5 = subtract(constant_1,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_34(c, v233_6, p1, v231_11_tail, s1);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_2,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_3 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_10(c, v234_6, p1, v231_11_tail, s1);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_13_result = unite(v225_13_result,v226_13);
  }
  const Space v225_13 = std::move(v225_13_result);
  return v225_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v235_8 = unwrap(s1,constant_0);
  const Space v235_9 = unwrap(v235_8,p0);
  Space v235_16_result;
  for (int v235_16_label = 1; v235_16_label <= 2; ++v235_16_label) {
    const Space v235_16_tail = child(s0,v235_16_label);
    if (v235_16_tail.empty()) continue;
    const Path v235_16_head{v235_16_label};
    const Space v236_2 = singleton(v235_16_head);
    const Space v236_3 = intersect(constant_2,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_3 : Space{});
    const Space v236_5 = subtract(constant_1,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_16_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_16_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_2,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_3 : Space{});
        const Space v238_5 = subtract(constant_1,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_34(c, v239_6, p1, v237_7_tail, s1);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_2,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_3 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_35(c, v240_6, p1, v237_7_tail, s1);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_2,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_3 : Space{});
    Space v236_13;
    if (!v236_10.empty()) {
      const Space v241_11 = unwrap(v235_9,v235_16_head);
      Space v241_12_result;
      for (int v241_12_label = 1; v241_12_label <= 2; ++v241_12_label) {
        const Space v241_12_tail = child(v241_11,v241_12_label);
        if (v241_12_tail.empty()) continue;
        const Path v241_12_head{v241_12_label};
        const Space v242_2 = singleton(v241_12_head);
        const Space v242_3 = intersect(constant_2,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_3 : Space{});
        const Space v242_5 = subtract(constant_1,v242_4);
        Space v242_7;
        if (!v242_5.empty()) {
          const Space v243_6 = routine_15(c, v241_12_head, p1, v241_12_tail);
          v242_7 = compose(v242_5,v243_6);
        }
        const Space v242_8 = intersect(constant_2,v242_2);
        const Space v242_9 = (has_head(v242_8) ? constant_3 : Space{});
        Space v242_11;
        if (!v242_9.empty()) {
          const Space v244_10 = routine_16(c, v241_12_head, p1, v241_12_tail);
          v242_11 = compose(v242_9,v244_10);
        }
        const Space v242_12 = unite(v242_7,v242_11);
        v241_12_result = unite(v241_12_result,v242_12);
      }
      const Space v241_12 = std::move(v241_12_result);
      v236_13 = compose(v236_10,v241_12);
    }
    const Space v236_14 = unite(v236_8,v236_13);
    v235_16_result = unite(v235_16_result,v236_14);
  }
  const Space v235_16 = std::move(v235_16_result);
  return v235_16;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v245_12_result;
  for (int v245_12_label = 1; v245_12_label <= 2; ++v245_12_label) {
    const Space v245_12_tail = child(s0,v245_12_label);
    if (v245_12_tail.empty()) continue;
    const Path v245_12_head{v245_12_label};
    const Space v246_2 = singleton(v245_12_head);
    const Space v246_3 = intersect(constant_2,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_3 : Space{});
    const Space v246_5 = subtract(constant_1,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_12_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_12_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_2,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_3 : Space{});
        const Space v248_5 = subtract(constant_1,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_36(c, v249_6, p1, v247_7_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_2,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_3 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_37(c, v250_6, p1, v247_7_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_2,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_3 : Space{});
    Space v246_12;
    if (!v246_10.empty()) {
      const Path v251_6 = concat_path(p0,v245_12_head);
      Space v251_11_result;
      for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
        const Space v251_11_tail = child(v245_12_tail,v251_11_label);
        if (v251_11_tail.empty()) continue;
        const Path v251_11_head{v251_11_label};
        const Space v252_2 = singleton(v251_11_head);
        const Space v252_3 = intersect(constant_2,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_3 : Space{});
        const Space v252_5 = subtract(constant_1,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_11_head);
          const Space v253_7 = routine_36(c, v253_6, p1, v251_11_tail);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_2,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_3 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_11_head);
          const Space v254_11 = routine_21(c, v254_6, p1, v251_11_tail);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_11_result = unite(v251_11_result,v252_13);
      }
      const Space v251_11 = std::move(v251_11_result);
      v246_12 = compose(v246_10,v251_11);
    }
    const Space v246_13 = unite(v246_8,v246_12);
    v245_12_result = unite(v245_12_result,v246_13);
  }
  const Space v245_12 = std::move(v245_12_result);
  return v245_12;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v255_9_result;
  for (int v255_9_label = 1; v255_9_label <= 2; ++v255_9_label) {
    const Space v255_9_tail = child(s0,v255_9_label);
    if (v255_9_tail.empty()) continue;
    const Path v255_9_head{v255_9_label};
    const Space v256_2 = singleton(v255_9_head);
    const Space v256_3 = intersect(constant_2,v256_2);
    const Space v256_4 = (has_head(v256_3) ? constant_3 : Space{});
    const Space v256_5 = subtract(constant_1,v256_4);
    Space v256_8;
    if (!v256_5.empty()) {
      const Path v257_6 = concat_path(p0,v255_9_head);
      Space v257_7_result;
      for (int v257_7_label = 1; v257_7_label <= 2; ++v257_7_label) {
        const Space v257_7_tail = child(v255_9_tail,v257_7_label);
        if (v257_7_tail.empty()) continue;
        const Path v257_7_head{v257_7_label};
        const Space v258_2 = singleton(v257_7_head);
        const Space v258_3 = intersect(constant_2,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_3 : Space{});
        const Space v258_5 = subtract(constant_1,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_7_head);
          const Space v259_7 = routine_36(c, v259_6, p1, v257_7_tail);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_2,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_3 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_7_head);
          const Space v260_11 = routine_37(c, v260_6, p1, v257_7_tail);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_7_result = unite(v257_7_result,v258_13);
      }
      const Space v257_7 = std::move(v257_7_result);
      v256_8 = compose(v256_5,v257_7);
    }
    const Space v256_9 = intersect(constant_2,v256_2);
    const Space v256_10 = (has_head(v256_9) ? constant_3 : Space{});
    const Space v256_11 = compose(v256_10,v255_9_tail);
    const Path v261_6 = concat_path(p0,v255_9_head);
    const Space v256_12 = wrap(v256_11,v261_6);
    const Space v256_13 = wrap(v256_12,p1);
    const Space v256_14 = unite(v256_8,v256_13);
    v255_9_result = unite(v255_9_result,v256_14);
  }
  const Space v255_9 = std::move(v255_9_result);
  return v255_9;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v262_13_result;
  for (int v262_13_label = 1; v262_13_label <= 2; ++v262_13_label) {
    const Space v262_13_tail = child(s0,v262_13_label);
    if (v262_13_tail.empty()) continue;
    const Path v262_13_head{v262_13_label};
    const Space v263_2 = singleton(v262_13_head);
    const Space v263_3 = intersect(constant_2,v263_2);
    const Space v263_4 = (has_head(v263_3) ? constant_3 : Space{});
    const Space v263_5 = subtract(constant_1,v263_4);
    Space v263_8;
    if (!v263_5.empty()) {
      const Path v264_6 = concat_path(p0,v262_13_head);
      Space v264_7_result;
      for (int v264_7_label = 1; v264_7_label <= 2; ++v264_7_label) {
        const Space v264_7_tail = child(v262_13_tail,v264_7_label);
        if (v264_7_tail.empty()) continue;
        const Path v264_7_head{v264_7_label};
        const Space v265_2 = singleton(v264_7_head);
        const Space v265_3 = intersect(constant_2,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_3 : Space{});
        const Space v265_5 = subtract(constant_1,v265_4);
        Space v265_8;
        if (!v265_5.empty()) {
          const Path v266_6 = concat_path(v264_6,v264_7_head);
          const Space v266_7 = routine_38(c, v266_6, p1, v264_7_tail, s1);
          v265_8 = compose(v265_5,v266_7);
        }
        const Space v265_9 = intersect(constant_2,v265_2);
        const Space v265_10 = (has_head(v265_9) ? constant_3 : Space{});
        Space v265_12;
        if (!v265_10.empty()) {
          const Path v267_6 = concat_path(v264_6,v264_7_head);
          const Space v267_11 = routine_39(c, v267_6, p1, v264_7_tail, s1);
          v265_12 = compose(v265_10,v267_11);
        }
        const Space v265_13 = unite(v265_8,v265_12);
        v264_7_result = unite(v264_7_result,v265_13);
      }
      const Space v264_7 = std::move(v264_7_result);
      v263_8 = compose(v263_5,v264_7);
    }
    const Space v263_9 = intersect(constant_2,v263_2);
    const Space v263_10 = (has_head(v263_9) ? constant_3 : Space{});
    Space v263_12;
    if (!v263_10.empty()) {
      const Path v268_6 = concat_path(p0,v262_13_head);
      Space v268_11_result;
      for (int v268_11_label = 1; v268_11_label <= 2; ++v268_11_label) {
        const Space v268_11_tail = child(v262_13_tail,v268_11_label);
        if (v268_11_tail.empty()) continue;
        const Path v268_11_head{v268_11_label};
        const Space v269_2 = singleton(v268_11_head);
        const Space v269_3 = intersect(constant_2,v269_2);
        const Space v269_4 = (has_head(v269_3) ? constant_3 : Space{});
        const Space v269_5 = subtract(constant_1,v269_4);
        Space v269_8;
        if (!v269_5.empty()) {
          const Path v270_6 = concat_path(v268_6,v268_11_head);
          const Space v270_7 = routine_38(c, v270_6, p1, v268_11_tail, s1);
          v269_8 = compose(v269_5,v270_7);
        }
        const Space v269_9 = intersect(constant_2,v269_2);
        const Space v269_10 = (has_head(v269_9) ? constant_3 : Space{});
        Space v269_12;
        if (!v269_10.empty()) {
          const Path v271_6 = concat_path(v268_6,v268_11_head);
          const Space v271_11 = routine_10(c, v271_6, p1, v268_11_tail, s1);
          v269_12 = compose(v269_10,v271_11);
        }
        const Space v269_13 = unite(v269_8,v269_12);
        v268_11_result = unite(v268_11_result,v269_13);
      }
      const Space v268_11 = std::move(v268_11_result);
      v263_12 = compose(v263_10,v268_11);
    }
    const Space v263_13 = unite(v263_8,v263_12);
    v262_13_result = unite(v262_13_result,v263_13);
  }
  const Space v262_13 = std::move(v262_13_result);
  return v262_13;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v272_8 = unwrap(s1,constant_0);
  const Space v272_9 = unwrap(v272_8,p0);
  Space v272_16_result;
  for (int v272_16_label = 1; v272_16_label <= 2; ++v272_16_label) {
    const Space v272_16_tail = child(s0,v272_16_label);
    if (v272_16_tail.empty()) continue;
    const Path v272_16_head{v272_16_label};
    const Space v273_2 = singleton(v272_16_head);
    const Space v273_3 = intersect(constant_2,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_3 : Space{});
    const Space v273_5 = subtract(constant_1,v273_4);
    Space v273_8;
    if (!v273_5.empty()) {
      const Path v274_6 = concat_path(p0,v272_16_head);
      Space v274_7_result;
      for (int v274_7_label = 1; v274_7_label <= 2; ++v274_7_label) {
        const Space v274_7_tail = child(v272_16_tail,v274_7_label);
        if (v274_7_tail.empty()) continue;
        const Path v274_7_head{v274_7_label};
        const Space v275_2 = singleton(v274_7_head);
        const Space v275_3 = intersect(constant_2,v275_2);
        const Space v275_4 = (has_head(v275_3) ? constant_3 : Space{});
        const Space v275_5 = subtract(constant_1,v275_4);
        Space v275_8;
        if (!v275_5.empty()) {
          const Path v276_6 = concat_path(v274_6,v274_7_head);
          const Space v276_7 = routine_38(c, v276_6, p1, v274_7_tail, s1);
          v275_8 = compose(v275_5,v276_7);
        }
        const Space v275_9 = intersect(constant_2,v275_2);
        const Space v275_10 = (has_head(v275_9) ? constant_3 : Space{});
        Space v275_12;
        if (!v275_10.empty()) {
          const Path v277_6 = concat_path(v274_6,v274_7_head);
          const Space v277_11 = routine_39(c, v277_6, p1, v274_7_tail, s1);
          v275_12 = compose(v275_10,v277_11);
        }
        const Space v275_13 = unite(v275_8,v275_12);
        v274_7_result = unite(v274_7_result,v275_13);
      }
      const Space v274_7 = std::move(v274_7_result);
      v273_8 = compose(v273_5,v274_7);
    }
    const Space v273_9 = intersect(constant_2,v273_2);
    const Space v273_10 = (has_head(v273_9) ? constant_3 : Space{});
    Space v273_13;
    if (!v273_10.empty()) {
      const Space v278_11 = unwrap(v272_9,v272_16_head);
      Space v278_12_result;
      for (int v278_12_label = 1; v278_12_label <= 2; ++v278_12_label) {
        const Space v278_12_tail = child(v278_11,v278_12_label);
        if (v278_12_tail.empty()) continue;
        const Path v278_12_head{v278_12_label};
        const Space v279_2 = singleton(v278_12_head);
        const Space v279_3 = intersect(constant_2,v279_2);
        const Space v279_4 = (has_head(v279_3) ? constant_3 : Space{});
        const Space v279_5 = subtract(constant_1,v279_4);
        Space v279_7;
        if (!v279_5.empty()) {
          const Space v280_6 = routine_15(c, v278_12_head, p1, v278_12_tail);
          v279_7 = compose(v279_5,v280_6);
        }
        const Space v279_8 = intersect(constant_2,v279_2);
        const Space v279_9 = (has_head(v279_8) ? constant_3 : Space{});
        Space v279_11;
        if (!v279_9.empty()) {
          const Space v281_10 = routine_16(c, v278_12_head, p1, v278_12_tail);
          v279_11 = compose(v279_9,v281_10);
        }
        const Space v279_12 = unite(v279_7,v279_11);
        v278_12_result = unite(v278_12_result,v279_12);
      }
      const Space v278_12 = std::move(v278_12_result);
      v273_13 = compose(v273_10,v278_12);
    }
    const Space v273_14 = unite(v273_8,v273_13);
    v272_16_result = unite(v272_16_result,v273_14);
  }
  const Space v272_16 = std::move(v272_16_result);
  return v272_16;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v282_12_result;
  for (int v282_12_label = 1; v282_12_label <= 2; ++v282_12_label) {
    const Space v282_12_tail = child(s0,v282_12_label);
    if (v282_12_tail.empty()) continue;
    const Path v282_12_head{v282_12_label};
    const Space v283_2 = singleton(v282_12_head);
    const Space v283_3 = intersect(constant_2,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_3 : Space{});
    const Space v283_5 = subtract(constant_1,v283_4);
    Space v283_8;
    if (!v283_5.empty()) {
      const Path v284_6 = concat_path(p0,v282_12_head);
      Space v284_7_result;
      for (int v284_7_label = 1; v284_7_label <= 2; ++v284_7_label) {
        const Space v284_7_tail = child(v282_12_tail,v284_7_label);
        if (v284_7_tail.empty()) continue;
        const Path v284_7_head{v284_7_label};
        const Space v285_2 = singleton(v284_7_head);
        const Space v285_3 = intersect(constant_2,v285_2);
        const Space v285_4 = (has_head(v285_3) ? constant_3 : Space{});
        const Space v285_5 = subtract(constant_1,v285_4);
        Space v285_8;
        if (!v285_5.empty()) {
          const Path v286_6 = concat_path(v284_6,v284_7_head);
          const Space v286_7 = routine_40(c, v286_6, p1, v284_7_tail);
          v285_8 = compose(v285_5,v286_7);
        }
        const Space v285_9 = intersect(constant_2,v285_2);
        const Space v285_10 = (has_head(v285_9) ? constant_3 : Space{});
        Space v285_12;
        if (!v285_10.empty()) {
          const Path v287_6 = concat_path(v284_6,v284_7_head);
          const Space v287_11 = routine_41(c, v287_6, p1, v284_7_tail);
          v285_12 = compose(v285_10,v287_11);
        }
        const Space v285_13 = unite(v285_8,v285_12);
        v284_7_result = unite(v284_7_result,v285_13);
      }
      const Space v284_7 = std::move(v284_7_result);
      v283_8 = compose(v283_5,v284_7);
    }
    const Space v283_9 = intersect(constant_2,v283_2);
    const Space v283_10 = (has_head(v283_9) ? constant_3 : Space{});
    Space v283_12;
    if (!v283_10.empty()) {
      const Path v288_6 = concat_path(p0,v282_12_head);
      Space v288_11_result;
      for (int v288_11_label = 1; v288_11_label <= 2; ++v288_11_label) {
        const Space v288_11_tail = child(v282_12_tail,v288_11_label);
        if (v288_11_tail.empty()) continue;
        const Path v288_11_head{v288_11_label};
        const Space v289_2 = singleton(v288_11_head);
        const Space v289_3 = intersect(constant_2,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_3 : Space{});
        const Space v289_5 = subtract(constant_1,v289_4);
        Space v289_8;
        if (!v289_5.empty()) {
          const Path v290_6 = concat_path(v288_6,v288_11_head);
          const Space v290_7 = routine_40(c, v290_6, p1, v288_11_tail);
          v289_8 = compose(v289_5,v290_7);
        }
        const Space v289_9 = intersect(constant_2,v289_2);
        const Space v289_10 = (has_head(v289_9) ? constant_3 : Space{});
        Space v289_12;
        if (!v289_10.empty()) {
          const Path v291_6 = concat_path(v288_6,v288_11_head);
          const Space v291_11 = routine_21(c, v291_6, p1, v288_11_tail);
          v289_12 = compose(v289_10,v291_11);
        }
        const Space v289_13 = unite(v289_8,v289_12);
        v288_11_result = unite(v288_11_result,v289_13);
      }
      const Space v288_11 = std::move(v288_11_result);
      v283_12 = compose(v283_10,v288_11);
    }
    const Space v283_13 = unite(v283_8,v283_12);
    v282_12_result = unite(v282_12_result,v283_13);
  }
  const Space v282_12 = std::move(v282_12_result);
  return v282_12;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v292_9_result;
  for (int v292_9_label = 1; v292_9_label <= 2; ++v292_9_label) {
    const Space v292_9_tail = child(s0,v292_9_label);
    if (v292_9_tail.empty()) continue;
    const Path v292_9_head{v292_9_label};
    const Space v293_2 = singleton(v292_9_head);
    const Space v293_3 = intersect(constant_2,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_3 : Space{});
    const Space v293_5 = subtract(constant_1,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_9_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_9_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_2,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_3 : Space{});
        const Space v295_5 = subtract(constant_1,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_40(c, v296_6, p1, v294_7_tail);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_2,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_3 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_41(c, v297_6, p1, v294_7_tail);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_2,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_3 : Space{});
    const Space v293_11 = compose(v293_10,v292_9_tail);
    const Path v298_6 = concat_path(p0,v292_9_head);
    const Space v293_12 = wrap(v293_11,v298_6);
    const Space v293_13 = wrap(v293_12,p1);
    const Space v293_14 = unite(v293_8,v293_13);
    v292_9_result = unite(v292_9_result,v293_14);
  }
  const Space v292_9 = std::move(v292_9_result);
  return v292_9;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v299_3_result;
  for (int v299_3_label = 1; v299_3_label <= 2; ++v299_3_label) {
    const Space v299_3_tail = child(s0,v299_3_label);
    if (v299_3_tail.empty()) continue;
    const Path v299_3_head{v299_3_label};
    const Space v300_2 = Space{};
    v299_3_result = unite(v299_3_result,v300_2);
  }
  const Space v299_3 = std::move(v299_3_result);
  return v299_3;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v301_7_result;
  for (int v301_7_label = 1; v301_7_label <= 2; ++v301_7_label) {
    const Space v301_7_tail = child(s0,v301_7_label);
    if (v301_7_tail.empty()) continue;
    const Path v301_7_head{v301_7_label};
    const Space v302_2 = singleton(v301_7_head);
    const Space v302_3 = intersect(constant_2,v302_2);
    const Space v302_4 = (has_head(v302_3) ? constant_3 : Space{});
    Space v302_7;
    if (!v302_4.empty()) {
      const Path v303_5 = concat_path(p0,v301_7_head);
      Space v303_6_result;
      for (int v303_6_label = 1; v303_6_label <= 2; ++v303_6_label) {
        const Space v303_6_tail = child(v301_7_tail,v303_6_label);
        if (v303_6_tail.empty()) continue;
        const Path v303_6_head{v303_6_label};
        const Space v304_2 = singleton(v303_6_head);
        const Space v304_3 = intersect(constant_2,v304_2);
        const Space v304_4 = (has_head(v304_3) ? constant_3 : Space{});
        const Space v304_5 = subtract(constant_1,v304_4);
        Space v304_7;
        if (!v304_5.empty()) {
          const Space v305_6 = routine_6(c, v303_6_head, v303_5, v303_6_tail, s1);
          v304_7 = compose(v304_5,v305_6);
        }
        const Space v304_8 = intersect(constant_2,v304_2);
        const Space v304_9 = (has_head(v304_8) ? constant_3 : Space{});
        Space v304_11;
        if (!v304_9.empty()) {
          const Space v306_10 = routine_7(c, v303_6_head, v303_5, v303_6_tail, s1);
          v304_11 = compose(v304_9,v306_10);
        }
        const Space v304_12 = unite(v304_7,v304_11);
        v303_6_result = unite(v303_6_result,v304_12);
      }
      const Space v303_6 = std::move(v303_6_result);
      v302_7 = compose(v302_4,v303_6);
    }
    v301_7_result = unite(v301_7_result,v302_7);
  }
  const Space v301_7 = std::move(v301_7_result);
  return v301_7;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v307_13_result;
  for (int v307_13_label = 1; v307_13_label <= 2; ++v307_13_label) {
    const Space v307_13_tail = child(s0,v307_13_label);
    if (v307_13_tail.empty()) continue;
    const Path v307_13_head{v307_13_label};
    const Space v308_2 = singleton(v307_13_head);
    const Space v308_3 = intersect(constant_2,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_3 : Space{});
    const Space v308_5 = subtract(constant_1,v308_4);
    Space v308_8;
    if (!v308_5.empty()) {
      const Path v309_6 = concat_path(p0,v307_13_head);
      Space v309_7_result;
      for (int v309_7_label = 1; v309_7_label <= 2; ++v309_7_label) {
        const Space v309_7_tail = child(v307_13_tail,v309_7_label);
        if (v309_7_tail.empty()) continue;
        const Path v309_7_head{v309_7_label};
        const Space v310_2 = singleton(v309_7_head);
        const Space v310_3 = intersect(constant_2,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_3 : Space{});
        const Space v310_5 = subtract(constant_1,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v309_6,v309_7_head);
          const Space v311_7 = routine_42(c, v311_6, p1, v309_7_tail, s1);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_2,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_3 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v309_6,v309_7_head);
          const Space v312_11 = routine_43(c, v312_6, p1, v309_7_tail, s1);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_7_result = unite(v309_7_result,v310_13);
      }
      const Space v309_7 = std::move(v309_7_result);
      v308_8 = compose(v308_5,v309_7);
    }
    const Space v308_9 = intersect(constant_2,v308_2);
    const Space v308_10 = (has_head(v308_9) ? constant_3 : Space{});
    Space v308_12;
    if (!v308_10.empty()) {
      const Path v313_6 = concat_path(p0,v307_13_head);
      Space v313_11_result;
      for (int v313_11_label = 1; v313_11_label <= 2; ++v313_11_label) {
        const Space v313_11_tail = child(v307_13_tail,v313_11_label);
        if (v313_11_tail.empty()) continue;
        const Path v313_11_head{v313_11_label};
        const Space v314_2 = singleton(v313_11_head);
        const Space v314_3 = intersect(constant_2,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_3 : Space{});
        const Space v314_5 = subtract(constant_1,v314_4);
        Space v314_8;
        if (!v314_5.empty()) {
          const Path v315_6 = concat_path(v313_6,v313_11_head);
          const Space v315_7 = routine_42(c, v315_6, p1, v313_11_tail, s1);
          v314_8 = compose(v314_5,v315_7);
        }
        const Space v314_9 = intersect(constant_2,v314_2);
        const Space v314_10 = (has_head(v314_9) ? constant_3 : Space{});
        Space v314_12;
        if (!v314_10.empty()) {
          const Path v316_6 = concat_path(v313_6,v313_11_head);
          const Space v316_11 = routine_10(c, v316_6, p1, v313_11_tail, s1);
          v314_12 = compose(v314_10,v316_11);
        }
        const Space v314_13 = unite(v314_8,v314_12);
        v313_11_result = unite(v313_11_result,v314_13);
      }
      const Space v313_11 = std::move(v313_11_result);
      v308_12 = compose(v308_10,v313_11);
    }
    const Space v308_13 = unite(v308_8,v308_12);
    v307_13_result = unite(v307_13_result,v308_13);
  }
  const Space v307_13 = std::move(v307_13_result);
  return v307_13;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v317_8 = unwrap(s1,constant_0);
  const Space v317_9 = unwrap(v317_8,p0);
  Space v317_16_result;
  for (int v317_16_label = 1; v317_16_label <= 2; ++v317_16_label) {
    const Space v317_16_tail = child(s0,v317_16_label);
    if (v317_16_tail.empty()) continue;
    const Path v317_16_head{v317_16_label};
    const Space v318_2 = singleton(v317_16_head);
    const Space v318_3 = intersect(constant_2,v318_2);
    const Space v318_4 = (has_head(v318_3) ? constant_3 : Space{});
    const Space v318_5 = subtract(constant_1,v318_4);
    Space v318_8;
    if (!v318_5.empty()) {
      const Path v319_6 = concat_path(p0,v317_16_head);
      Space v319_7_result;
      for (int v319_7_label = 1; v319_7_label <= 2; ++v319_7_label) {
        const Space v319_7_tail = child(v317_16_tail,v319_7_label);
        if (v319_7_tail.empty()) continue;
        const Path v319_7_head{v319_7_label};
        const Space v320_2 = singleton(v319_7_head);
        const Space v320_3 = intersect(constant_2,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_3 : Space{});
        const Space v320_5 = subtract(constant_1,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_7_head);
          const Space v321_7 = routine_42(c, v321_6, p1, v319_7_tail, s1);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_2,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_3 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_7_head);
          const Space v322_11 = routine_43(c, v322_6, p1, v319_7_tail, s1);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_7_result = unite(v319_7_result,v320_13);
      }
      const Space v319_7 = std::move(v319_7_result);
      v318_8 = compose(v318_5,v319_7);
    }
    const Space v318_9 = intersect(constant_2,v318_2);
    const Space v318_10 = (has_head(v318_9) ? constant_3 : Space{});
    Space v318_13;
    if (!v318_10.empty()) {
      const Space v323_11 = unwrap(v317_9,v317_16_head);
      Space v323_12_result;
      for (int v323_12_label = 1; v323_12_label <= 2; ++v323_12_label) {
        const Space v323_12_tail = child(v323_11,v323_12_label);
        if (v323_12_tail.empty()) continue;
        const Path v323_12_head{v323_12_label};
        const Space v324_2 = singleton(v323_12_head);
        const Space v324_3 = intersect(constant_2,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_3 : Space{});
        const Space v324_5 = subtract(constant_1,v324_4);
        Space v324_7;
        if (!v324_5.empty()) {
          const Space v325_6 = routine_15(c, v323_12_head, p1, v323_12_tail);
          v324_7 = compose(v324_5,v325_6);
        }
        const Space v324_8 = intersect(constant_2,v324_2);
        const Space v324_9 = (has_head(v324_8) ? constant_3 : Space{});
        Space v324_11;
        if (!v324_9.empty()) {
          const Space v326_10 = routine_16(c, v323_12_head, p1, v323_12_tail);
          v324_11 = compose(v324_9,v326_10);
        }
        const Space v324_12 = unite(v324_7,v324_11);
        v323_12_result = unite(v323_12_result,v324_12);
      }
      const Space v323_12 = std::move(v323_12_result);
      v318_13 = compose(v318_10,v323_12);
    }
    const Space v318_14 = unite(v318_8,v318_13);
    v317_16_result = unite(v317_16_result,v318_14);
  }
  const Space v317_16 = std::move(v317_16_result);
  return v317_16;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v327_12_result;
  for (int v327_12_label = 1; v327_12_label <= 2; ++v327_12_label) {
    const Space v327_12_tail = child(s0,v327_12_label);
    if (v327_12_tail.empty()) continue;
    const Path v327_12_head{v327_12_label};
    const Space v328_2 = singleton(v327_12_head);
    const Space v328_3 = intersect(constant_2,v328_2);
    const Space v328_4 = (has_head(v328_3) ? constant_3 : Space{});
    const Space v328_5 = subtract(constant_1,v328_4);
    Space v328_8;
    if (!v328_5.empty()) {
      const Path v329_6 = concat_path(p0,v327_12_head);
      Space v329_7_result;
      for (int v329_7_label = 1; v329_7_label <= 2; ++v329_7_label) {
        const Space v329_7_tail = child(v327_12_tail,v329_7_label);
        if (v329_7_tail.empty()) continue;
        const Path v329_7_head{v329_7_label};
        const Space v330_2 = singleton(v329_7_head);
        const Space v330_3 = intersect(constant_2,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_3 : Space{});
        const Space v330_5 = subtract(constant_1,v330_4);
        Space v330_8;
        if (!v330_5.empty()) {
          const Path v331_6 = concat_path(v329_6,v329_7_head);
          const Space v331_7 = routine_44(c, v331_6, p1, v329_7_tail);
          v330_8 = compose(v330_5,v331_7);
        }
        const Space v330_9 = intersect(constant_2,v330_2);
        const Space v330_10 = (has_head(v330_9) ? constant_3 : Space{});
        Space v330_12;
        if (!v330_10.empty()) {
          const Path v332_6 = concat_path(v329_6,v329_7_head);
          const Space v332_11 = routine_45(c, v332_6, p1, v329_7_tail);
          v330_12 = compose(v330_10,v332_11);
        }
        const Space v330_13 = unite(v330_8,v330_12);
        v329_7_result = unite(v329_7_result,v330_13);
      }
      const Space v329_7 = std::move(v329_7_result);
      v328_8 = compose(v328_5,v329_7);
    }
    const Space v328_9 = intersect(constant_2,v328_2);
    const Space v328_10 = (has_head(v328_9) ? constant_3 : Space{});
    Space v328_12;
    if (!v328_10.empty()) {
      const Path v333_6 = concat_path(p0,v327_12_head);
      Space v333_11_result;
      for (int v333_11_label = 1; v333_11_label <= 2; ++v333_11_label) {
        const Space v333_11_tail = child(v327_12_tail,v333_11_label);
        if (v333_11_tail.empty()) continue;
        const Path v333_11_head{v333_11_label};
        const Space v334_2 = singleton(v333_11_head);
        const Space v334_3 = intersect(constant_2,v334_2);
        const Space v334_4 = (has_head(v334_3) ? constant_3 : Space{});
        const Space v334_5 = subtract(constant_1,v334_4);
        Space v334_8;
        if (!v334_5.empty()) {
          const Path v335_6 = concat_path(v333_6,v333_11_head);
          const Space v335_7 = routine_44(c, v335_6, p1, v333_11_tail);
          v334_8 = compose(v334_5,v335_7);
        }
        const Space v334_9 = intersect(constant_2,v334_2);
        const Space v334_10 = (has_head(v334_9) ? constant_3 : Space{});
        Space v334_12;
        if (!v334_10.empty()) {
          const Path v336_6 = concat_path(v333_6,v333_11_head);
          const Space v336_11 = routine_21(c, v336_6, p1, v333_11_tail);
          v334_12 = compose(v334_10,v336_11);
        }
        const Space v334_13 = unite(v334_8,v334_12);
        v333_11_result = unite(v333_11_result,v334_13);
      }
      const Space v333_11 = std::move(v333_11_result);
      v328_12 = compose(v328_10,v333_11);
    }
    const Space v328_13 = unite(v328_8,v328_12);
    v327_12_result = unite(v327_12_result,v328_13);
  }
  const Space v327_12 = std::move(v327_12_result);
  return v327_12;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v337_9_result;
  for (int v337_9_label = 1; v337_9_label <= 2; ++v337_9_label) {
    const Space v337_9_tail = child(s0,v337_9_label);
    if (v337_9_tail.empty()) continue;
    const Path v337_9_head{v337_9_label};
    const Space v338_2 = singleton(v337_9_head);
    const Space v338_3 = intersect(constant_2,v338_2);
    const Space v338_4 = (has_head(v338_3) ? constant_3 : Space{});
    const Space v338_5 = subtract(constant_1,v338_4);
    Space v338_8;
    if (!v338_5.empty()) {
      const Path v339_6 = concat_path(p0,v337_9_head);
      Space v339_7_result;
      for (int v339_7_label = 1; v339_7_label <= 2; ++v339_7_label) {
        const Space v339_7_tail = child(v337_9_tail,v339_7_label);
        if (v339_7_tail.empty()) continue;
        const Path v339_7_head{v339_7_label};
        const Space v340_2 = singleton(v339_7_head);
        const Space v340_3 = intersect(constant_2,v340_2);
        const Space v340_4 = (has_head(v340_3) ? constant_3 : Space{});
        const Space v340_5 = subtract(constant_1,v340_4);
        Space v340_8;
        if (!v340_5.empty()) {
          const Path v341_6 = concat_path(v339_6,v339_7_head);
          const Space v341_7 = routine_44(c, v341_6, p1, v339_7_tail);
          v340_8 = compose(v340_5,v341_7);
        }
        const Space v340_9 = intersect(constant_2,v340_2);
        const Space v340_10 = (has_head(v340_9) ? constant_3 : Space{});
        Space v340_12;
        if (!v340_10.empty()) {
          const Path v342_6 = concat_path(v339_6,v339_7_head);
          const Space v342_11 = routine_45(c, v342_6, p1, v339_7_tail);
          v340_12 = compose(v340_10,v342_11);
        }
        const Space v340_13 = unite(v340_8,v340_12);
        v339_7_result = unite(v339_7_result,v340_13);
      }
      const Space v339_7 = std::move(v339_7_result);
      v338_8 = compose(v338_5,v339_7);
    }
    const Space v338_9 = intersect(constant_2,v338_2);
    const Space v338_10 = (has_head(v338_9) ? constant_3 : Space{});
    const Space v338_11 = compose(v338_10,v337_9_tail);
    const Path v343_6 = concat_path(p0,v337_9_head);
    const Space v338_12 = wrap(v338_11,v343_6);
    const Space v338_13 = wrap(v338_12,p1);
    const Space v338_14 = unite(v338_8,v338_13);
    v337_9_result = unite(v337_9_result,v338_14);
  }
  const Space v337_9 = std::move(v337_9_result);
  return v337_9;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v344_13_result;
  for (int v344_13_label = 1; v344_13_label <= 2; ++v344_13_label) {
    const Space v344_13_tail = child(s0,v344_13_label);
    if (v344_13_tail.empty()) continue;
    const Path v344_13_head{v344_13_label};
    const Space v345_2 = singleton(v344_13_head);
    const Space v345_3 = intersect(constant_2,v345_2);
    const Space v345_4 = (has_head(v345_3) ? constant_3 : Space{});
    const Space v345_5 = subtract(constant_1,v345_4);
    Space v345_8;
    if (!v345_5.empty()) {
      const Path v346_6 = concat_path(p0,v344_13_head);
      Space v346_7_result;
      for (int v346_7_label = 1; v346_7_label <= 2; ++v346_7_label) {
        const Space v346_7_tail = child(v344_13_tail,v346_7_label);
        if (v346_7_tail.empty()) continue;
        const Path v346_7_head{v346_7_label};
        const Space v347_2 = singleton(v346_7_head);
        const Space v347_3 = intersect(constant_2,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_3 : Space{});
        const Space v347_5 = subtract(constant_1,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v346_6,v346_7_head);
          const Space v348_7 = routine_46(c, v348_6, p1, v346_7_tail, s1);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_2,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_3 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v346_6,v346_7_head);
          const Space v349_11 = routine_47(c, v349_6, p1, v346_7_tail, s1);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_7_result = unite(v346_7_result,v347_13);
      }
      const Space v346_7 = std::move(v346_7_result);
      v345_8 = compose(v345_5,v346_7);
    }
    const Space v345_9 = intersect(constant_2,v345_2);
    const Space v345_10 = (has_head(v345_9) ? constant_3 : Space{});
    Space v345_12;
    if (!v345_10.empty()) {
      const Path v350_6 = concat_path(p0,v344_13_head);
      Space v350_11_result;
      for (int v350_11_label = 1; v350_11_label <= 2; ++v350_11_label) {
        const Space v350_11_tail = child(v344_13_tail,v350_11_label);
        if (v350_11_tail.empty()) continue;
        const Path v350_11_head{v350_11_label};
        const Space v351_2 = singleton(v350_11_head);
        const Space v351_3 = intersect(constant_2,v351_2);
        const Space v351_4 = (has_head(v351_3) ? constant_3 : Space{});
        const Space v351_5 = subtract(constant_1,v351_4);
        Space v351_8;
        if (!v351_5.empty()) {
          const Path v352_6 = concat_path(v350_6,v350_11_head);
          const Space v352_7 = routine_46(c, v352_6, p1, v350_11_tail, s1);
          v351_8 = compose(v351_5,v352_7);
        }
        const Space v351_9 = intersect(constant_2,v351_2);
        const Space v351_10 = (has_head(v351_9) ? constant_3 : Space{});
        Space v351_12;
        if (!v351_10.empty()) {
          const Path v353_6 = concat_path(v350_6,v350_11_head);
          const Space v353_11 = routine_10(c, v353_6, p1, v350_11_tail, s1);
          v351_12 = compose(v351_10,v353_11);
        }
        const Space v351_13 = unite(v351_8,v351_12);
        v350_11_result = unite(v350_11_result,v351_13);
      }
      const Space v350_11 = std::move(v350_11_result);
      v345_12 = compose(v345_10,v350_11);
    }
    const Space v345_13 = unite(v345_8,v345_12);
    v344_13_result = unite(v344_13_result,v345_13);
  }
  const Space v344_13 = std::move(v344_13_result);
  return v344_13;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v354_8 = unwrap(s1,constant_0);
  const Space v354_9 = unwrap(v354_8,p0);
  Space v354_16_result;
  for (int v354_16_label = 1; v354_16_label <= 2; ++v354_16_label) {
    const Space v354_16_tail = child(s0,v354_16_label);
    if (v354_16_tail.empty()) continue;
    const Path v354_16_head{v354_16_label};
    const Space v355_2 = singleton(v354_16_head);
    const Space v355_3 = intersect(constant_2,v355_2);
    const Space v355_4 = (has_head(v355_3) ? constant_3 : Space{});
    const Space v355_5 = subtract(constant_1,v355_4);
    Space v355_8;
    if (!v355_5.empty()) {
      const Path v356_6 = concat_path(p0,v354_16_head);
      Space v356_7_result;
      for (int v356_7_label = 1; v356_7_label <= 2; ++v356_7_label) {
        const Space v356_7_tail = child(v354_16_tail,v356_7_label);
        if (v356_7_tail.empty()) continue;
        const Path v356_7_head{v356_7_label};
        const Space v357_2 = singleton(v356_7_head);
        const Space v357_3 = intersect(constant_2,v357_2);
        const Space v357_4 = (has_head(v357_3) ? constant_3 : Space{});
        const Space v357_5 = subtract(constant_1,v357_4);
        Space v357_8;
        if (!v357_5.empty()) {
          const Path v358_6 = concat_path(v356_6,v356_7_head);
          const Space v358_7 = routine_46(c, v358_6, p1, v356_7_tail, s1);
          v357_8 = compose(v357_5,v358_7);
        }
        const Space v357_9 = intersect(constant_2,v357_2);
        const Space v357_10 = (has_head(v357_9) ? constant_3 : Space{});
        Space v357_12;
        if (!v357_10.empty()) {
          const Path v359_6 = concat_path(v356_6,v356_7_head);
          const Space v359_11 = routine_47(c, v359_6, p1, v356_7_tail, s1);
          v357_12 = compose(v357_10,v359_11);
        }
        const Space v357_13 = unite(v357_8,v357_12);
        v356_7_result = unite(v356_7_result,v357_13);
      }
      const Space v356_7 = std::move(v356_7_result);
      v355_8 = compose(v355_5,v356_7);
    }
    const Space v355_9 = intersect(constant_2,v355_2);
    const Space v355_10 = (has_head(v355_9) ? constant_3 : Space{});
    Space v355_13;
    if (!v355_10.empty()) {
      const Space v360_11 = unwrap(v354_9,v354_16_head);
      Space v360_12_result;
      for (int v360_12_label = 1; v360_12_label <= 2; ++v360_12_label) {
        const Space v360_12_tail = child(v360_11,v360_12_label);
        if (v360_12_tail.empty()) continue;
        const Path v360_12_head{v360_12_label};
        const Space v361_2 = singleton(v360_12_head);
        const Space v361_3 = intersect(constant_2,v361_2);
        const Space v361_4 = (has_head(v361_3) ? constant_3 : Space{});
        const Space v361_5 = subtract(constant_1,v361_4);
        Space v361_7;
        if (!v361_5.empty()) {
          const Space v362_6 = routine_15(c, v360_12_head, p1, v360_12_tail);
          v361_7 = compose(v361_5,v362_6);
        }
        const Space v361_8 = intersect(constant_2,v361_2);
        const Space v361_9 = (has_head(v361_8) ? constant_3 : Space{});
        Space v361_11;
        if (!v361_9.empty()) {
          const Space v363_10 = routine_16(c, v360_12_head, p1, v360_12_tail);
          v361_11 = compose(v361_9,v363_10);
        }
        const Space v361_12 = unite(v361_7,v361_11);
        v360_12_result = unite(v360_12_result,v361_12);
      }
      const Space v360_12 = std::move(v360_12_result);
      v355_13 = compose(v355_10,v360_12);
    }
    const Space v355_14 = unite(v355_8,v355_13);
    v354_16_result = unite(v354_16_result,v355_14);
  }
  const Space v354_16 = std::move(v354_16_result);
  return v354_16;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v364_12_result;
  for (int v364_12_label = 1; v364_12_label <= 2; ++v364_12_label) {
    const Space v364_12_tail = child(s0,v364_12_label);
    if (v364_12_tail.empty()) continue;
    const Path v364_12_head{v364_12_label};
    const Space v365_2 = singleton(v364_12_head);
    const Space v365_3 = intersect(constant_2,v365_2);
    const Space v365_4 = (has_head(v365_3) ? constant_3 : Space{});
    const Space v365_5 = subtract(constant_1,v365_4);
    Space v365_8;
    if (!v365_5.empty()) {
      const Path v366_6 = concat_path(p0,v364_12_head);
      Space v366_7_result;
      for (int v366_7_label = 1; v366_7_label <= 2; ++v366_7_label) {
        const Space v366_7_tail = child(v364_12_tail,v366_7_label);
        if (v366_7_tail.empty()) continue;
        const Path v366_7_head{v366_7_label};
        const Space v367_2 = singleton(v366_7_head);
        const Space v367_3 = intersect(constant_2,v367_2);
        const Space v367_4 = (has_head(v367_3) ? constant_3 : Space{});
        const Space v367_5 = subtract(constant_1,v367_4);
        Space v367_8;
        if (!v367_5.empty()) {
          const Path v368_6 = concat_path(v366_6,v366_7_head);
          const Space v368_7 = routine_48(c, v368_6, p1, v366_7_tail);
          v367_8 = compose(v367_5,v368_7);
        }
        const Space v367_9 = intersect(constant_2,v367_2);
        const Space v367_10 = (has_head(v367_9) ? constant_3 : Space{});
        Space v367_12;
        if (!v367_10.empty()) {
          const Path v369_6 = concat_path(v366_6,v366_7_head);
          const Space v369_11 = routine_49(c, v369_6, p1, v366_7_tail);
          v367_12 = compose(v367_10,v369_11);
        }
        const Space v367_13 = unite(v367_8,v367_12);
        v366_7_result = unite(v366_7_result,v367_13);
      }
      const Space v366_7 = std::move(v366_7_result);
      v365_8 = compose(v365_5,v366_7);
    }
    const Space v365_9 = intersect(constant_2,v365_2);
    const Space v365_10 = (has_head(v365_9) ? constant_3 : Space{});
    Space v365_12;
    if (!v365_10.empty()) {
      const Path v370_6 = concat_path(p0,v364_12_head);
      Space v370_11_result;
      for (int v370_11_label = 1; v370_11_label <= 2; ++v370_11_label) {
        const Space v370_11_tail = child(v364_12_tail,v370_11_label);
        if (v370_11_tail.empty()) continue;
        const Path v370_11_head{v370_11_label};
        const Space v371_2 = singleton(v370_11_head);
        const Space v371_3 = intersect(constant_2,v371_2);
        const Space v371_4 = (has_head(v371_3) ? constant_3 : Space{});
        const Space v371_5 = subtract(constant_1,v371_4);
        Space v371_8;
        if (!v371_5.empty()) {
          const Path v372_6 = concat_path(v370_6,v370_11_head);
          const Space v372_7 = routine_48(c, v372_6, p1, v370_11_tail);
          v371_8 = compose(v371_5,v372_7);
        }
        const Space v371_9 = intersect(constant_2,v371_2);
        const Space v371_10 = (has_head(v371_9) ? constant_3 : Space{});
        Space v371_12;
        if (!v371_10.empty()) {
          const Path v373_6 = concat_path(v370_6,v370_11_head);
          const Space v373_11 = routine_21(c, v373_6, p1, v370_11_tail);
          v371_12 = compose(v371_10,v373_11);
        }
        const Space v371_13 = unite(v371_8,v371_12);
        v370_11_result = unite(v370_11_result,v371_13);
      }
      const Space v370_11 = std::move(v370_11_result);
      v365_12 = compose(v365_10,v370_11);
    }
    const Space v365_13 = unite(v365_8,v365_12);
    v364_12_result = unite(v364_12_result,v365_13);
  }
  const Space v364_12 = std::move(v364_12_result);
  return v364_12;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v374_9_result;
  for (int v374_9_label = 1; v374_9_label <= 2; ++v374_9_label) {
    const Space v374_9_tail = child(s0,v374_9_label);
    if (v374_9_tail.empty()) continue;
    const Path v374_9_head{v374_9_label};
    const Space v375_2 = singleton(v374_9_head);
    const Space v375_3 = intersect(constant_2,v375_2);
    const Space v375_4 = (has_head(v375_3) ? constant_3 : Space{});
    const Space v375_5 = subtract(constant_1,v375_4);
    Space v375_8;
    if (!v375_5.empty()) {
      const Path v376_6 = concat_path(p0,v374_9_head);
      Space v376_7_result;
      for (int v376_7_label = 1; v376_7_label <= 2; ++v376_7_label) {
        const Space v376_7_tail = child(v374_9_tail,v376_7_label);
        if (v376_7_tail.empty()) continue;
        const Path v376_7_head{v376_7_label};
        const Space v377_2 = singleton(v376_7_head);
        const Space v377_3 = intersect(constant_2,v377_2);
        const Space v377_4 = (has_head(v377_3) ? constant_3 : Space{});
        const Space v377_5 = subtract(constant_1,v377_4);
        Space v377_8;
        if (!v377_5.empty()) {
          const Path v378_6 = concat_path(v376_6,v376_7_head);
          const Space v378_7 = routine_48(c, v378_6, p1, v376_7_tail);
          v377_8 = compose(v377_5,v378_7);
        }
        const Space v377_9 = intersect(constant_2,v377_2);
        const Space v377_10 = (has_head(v377_9) ? constant_3 : Space{});
        Space v377_12;
        if (!v377_10.empty()) {
          const Path v379_6 = concat_path(v376_6,v376_7_head);
          const Space v379_11 = routine_49(c, v379_6, p1, v376_7_tail);
          v377_12 = compose(v377_10,v379_11);
        }
        const Space v377_13 = unite(v377_8,v377_12);
        v376_7_result = unite(v376_7_result,v377_13);
      }
      const Space v376_7 = std::move(v376_7_result);
      v375_8 = compose(v375_5,v376_7);
    }
    const Space v375_9 = intersect(constant_2,v375_2);
    const Space v375_10 = (has_head(v375_9) ? constant_3 : Space{});
    const Space v375_11 = compose(v375_10,v374_9_tail);
    const Path v380_6 = concat_path(p0,v374_9_head);
    const Space v375_12 = wrap(v375_11,v380_6);
    const Space v375_13 = wrap(v375_12,p1);
    const Space v375_14 = unite(v375_8,v375_13);
    v374_9_result = unite(v374_9_result,v375_14);
  }
  const Space v374_9 = std::move(v374_9_result);
  return v374_9;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v381_8_result;
  for (int v381_8_label = 1; v381_8_label <= 2; ++v381_8_label) {
    const Space v381_8_tail = child(s0,v381_8_label);
    if (v381_8_tail.empty()) continue;
    const Path v381_8_head{v381_8_label};
    const Space v382_2 = singleton(v381_8_head);
    const Space v382_3 = intersect(constant_2,v382_2);
    const Space v382_4 = (has_head(v382_3) ? constant_3 : Space{});
    const Space v382_5 = subtract(constant_1,v382_4);
    Space v382_6_result;
    for (int v382_6_label = 1; v382_6_label <= 2; ++v382_6_label) {
      const Space v382_6_tail = child(v381_8_tail,v382_6_label);
      if (v382_6_tail.empty()) continue;
      const Path v382_6_head{v382_6_label};
      const Space v383_2 = Space{};
      v382_6_result = unite(v382_6_result,v383_2);
    }
    const Space v382_6 = std::move(v382_6_result);
    const Space v382_7 = compose(v382_5,v382_6);
    const Space v382_8 = intersect(constant_2,v382_2);
    const Space v382_9 = (has_head(v382_8) ? constant_3 : Space{});
    Space v382_12;
    if (!v382_9.empty()) {
      const Path v384_10 = concat_path(p0,v381_8_head);
      Space v384_11_result;
      for (int v384_11_label = 1; v384_11_label <= 2; ++v384_11_label) {
        const Space v384_11_tail = child(v381_8_tail,v384_11_label);
        if (v384_11_tail.empty()) continue;
        const Path v384_11_head{v384_11_label};
        const Space v385_2 = singleton(v384_11_head);
        const Space v385_3 = intersect(constant_2,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_3 : Space{});
        Space v385_7;
        if (!v385_4.empty()) {
          const Path v386_5 = concat_path(v384_10,v384_11_head);
          const Space v386_6 = routine_10(c, v386_5, p1, v384_11_tail, s1);
          v385_7 = compose(v385_4,v386_6);
        }
        v384_11_result = unite(v384_11_result,v385_7);
      }
      const Space v384_11 = std::move(v384_11_result);
      v382_12 = compose(v382_9,v384_11);
    }
    const Space v382_13 = unite(v382_7,v382_12);
    v381_8_result = unite(v381_8_result,v382_13);
  }
  const Space v381_8 = std::move(v381_8_result);
  return v381_8;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v387_8 = unwrap(s1,constant_0);
  const Space v387_9 = unwrap(v387_8,p0);
  Space v387_13_result;
  for (int v387_13_label = 1; v387_13_label <= 2; ++v387_13_label) {
    const Space v387_13_tail = child(s0,v387_13_label);
    if (v387_13_tail.empty()) continue;
    const Path v387_13_head{v387_13_label};
    const Space v388_2 = singleton(v387_13_head);
    const Space v388_3 = intersect(constant_2,v388_2);
    const Space v388_4 = (has_head(v388_3) ? constant_3 : Space{});
    const Space v388_5 = subtract(constant_1,v388_4);
    Space v388_6_result;
    for (int v388_6_label = 1; v388_6_label <= 2; ++v388_6_label) {
      const Space v388_6_tail = child(v387_13_tail,v388_6_label);
      if (v388_6_tail.empty()) continue;
      const Path v388_6_head{v388_6_label};
      const Space v389_2 = Space{};
      v388_6_result = unite(v388_6_result,v389_2);
    }
    const Space v388_6 = std::move(v388_6_result);
    const Space v388_7 = compose(v388_5,v388_6);
    const Space v388_8 = intersect(constant_2,v388_2);
    const Space v388_9 = (has_head(v388_8) ? constant_3 : Space{});
    Space v388_12;
    if (!v388_9.empty()) {
      const Space v390_10 = unwrap(v387_9,v387_13_head);
      Space v390_11_result;
      for (int v390_11_label = 1; v390_11_label <= 2; ++v390_11_label) {
        const Space v390_11_tail = child(v390_10,v390_11_label);
        if (v390_11_tail.empty()) continue;
        const Path v390_11_head{v390_11_label};
        const Space v391_2 = singleton(v390_11_head);
        const Space v391_3 = intersect(constant_2,v391_2);
        const Space v391_4 = (has_head(v391_3) ? constant_3 : Space{});
        const Space v391_5 = subtract(constant_1,v391_4);
        Space v391_7;
        if (!v391_5.empty()) {
          const Space v392_6 = routine_15(c, v390_11_head, p1, v390_11_tail);
          v391_7 = compose(v391_5,v392_6);
        }
        const Space v391_8 = intersect(constant_2,v391_2);
        const Space v391_9 = (has_head(v391_8) ? constant_3 : Space{});
        Space v391_11;
        if (!v391_9.empty()) {
          const Space v393_10 = routine_16(c, v390_11_head, p1, v390_11_tail);
          v391_11 = compose(v391_9,v393_10);
        }
        const Space v391_12 = unite(v391_7,v391_11);
        v390_11_result = unite(v390_11_result,v391_12);
      }
      const Space v390_11 = std::move(v390_11_result);
      v388_12 = compose(v388_9,v390_11);
    }
    const Space v388_13 = unite(v388_7,v388_12);
    v387_13_result = unite(v387_13_result,v388_13);
  }
  const Space v387_13 = std::move(v387_13_result);
  return v387_13;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v394_12_result;
  for (int v394_12_label = 1; v394_12_label <= 2; ++v394_12_label) {
    const Space v394_12_tail = child(s0,v394_12_label);
    if (v394_12_tail.empty()) continue;
    const Path v394_12_head{v394_12_label};
    const Space v395_2 = singleton(v394_12_head);
    const Space v395_3 = intersect(constant_2,v395_2);
    const Space v395_4 = (has_head(v395_3) ? constant_3 : Space{});
    const Space v395_5 = subtract(constant_1,v395_4);
    Space v395_8;
    if (!v395_5.empty()) {
      const Path v396_6 = concat_path(p0,v394_12_head);
      Space v396_7_result;
      for (int v396_7_label = 1; v396_7_label <= 2; ++v396_7_label) {
        const Space v396_7_tail = child(v394_12_tail,v396_7_label);
        if (v396_7_tail.empty()) continue;
        const Path v396_7_head{v396_7_label};
        const Space v397_2 = singleton(v396_7_head);
        const Space v397_3 = intersect(constant_2,v397_2);
        const Space v397_4 = (has_head(v397_3) ? constant_3 : Space{});
        const Space v397_5 = subtract(constant_1,v397_4);
        Space v397_8;
        if (!v397_5.empty()) {
          const Path v398_6 = concat_path(v396_6,v396_7_head);
          const Space v398_7 = routine_50(c, v398_6, p1, v396_7_tail);
          v397_8 = compose(v397_5,v398_7);
        }
        const Space v397_9 = intersect(constant_2,v397_2);
        const Space v397_10 = (has_head(v397_9) ? constant_3 : Space{});
        Space v397_12;
        if (!v397_10.empty()) {
          const Path v399_6 = concat_path(v396_6,v396_7_head);
          const Space v399_11 = routine_51(c, v399_6, p1, v396_7_tail);
          v397_12 = compose(v397_10,v399_11);
        }
        const Space v397_13 = unite(v397_8,v397_12);
        v396_7_result = unite(v396_7_result,v397_13);
      }
      const Space v396_7 = std::move(v396_7_result);
      v395_8 = compose(v395_5,v396_7);
    }
    const Space v395_9 = intersect(constant_2,v395_2);
    const Space v395_10 = (has_head(v395_9) ? constant_3 : Space{});
    Space v395_12;
    if (!v395_10.empty()) {
      const Path v400_6 = concat_path(p0,v394_12_head);
      Space v400_11_result;
      for (int v400_11_label = 1; v400_11_label <= 2; ++v400_11_label) {
        const Space v400_11_tail = child(v394_12_tail,v400_11_label);
        if (v400_11_tail.empty()) continue;
        const Path v400_11_head{v400_11_label};
        const Space v401_2 = singleton(v400_11_head);
        const Space v401_3 = intersect(constant_2,v401_2);
        const Space v401_4 = (has_head(v401_3) ? constant_3 : Space{});
        const Space v401_5 = subtract(constant_1,v401_4);
        Space v401_8;
        if (!v401_5.empty()) {
          const Path v402_6 = concat_path(v400_6,v400_11_head);
          const Space v402_7 = routine_50(c, v402_6, p1, v400_11_tail);
          v401_8 = compose(v401_5,v402_7);
        }
        const Space v401_9 = intersect(constant_2,v401_2);
        const Space v401_10 = (has_head(v401_9) ? constant_3 : Space{});
        Space v401_12;
        if (!v401_10.empty()) {
          const Path v403_6 = concat_path(v400_6,v400_11_head);
          const Space v403_11 = routine_21(c, v403_6, p1, v400_11_tail);
          v401_12 = compose(v401_10,v403_11);
        }
        const Space v401_13 = unite(v401_8,v401_12);
        v400_11_result = unite(v400_11_result,v401_13);
      }
      const Space v400_11 = std::move(v400_11_result);
      v395_12 = compose(v395_10,v400_11);
    }
    const Space v395_13 = unite(v395_8,v395_12);
    v394_12_result = unite(v394_12_result,v395_13);
  }
  const Space v394_12 = std::move(v394_12_result);
  return v394_12;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v404_9_result;
  for (int v404_9_label = 1; v404_9_label <= 2; ++v404_9_label) {
    const Space v404_9_tail = child(s0,v404_9_label);
    if (v404_9_tail.empty()) continue;
    const Path v404_9_head{v404_9_label};
    const Space v405_2 = singleton(v404_9_head);
    const Space v405_3 = intersect(constant_2,v405_2);
    const Space v405_4 = (has_head(v405_3) ? constant_3 : Space{});
    const Space v405_5 = subtract(constant_1,v405_4);
    Space v405_8;
    if (!v405_5.empty()) {
      const Path v406_6 = concat_path(p0,v404_9_head);
      Space v406_7_result;
      for (int v406_7_label = 1; v406_7_label <= 2; ++v406_7_label) {
        const Space v406_7_tail = child(v404_9_tail,v406_7_label);
        if (v406_7_tail.empty()) continue;
        const Path v406_7_head{v406_7_label};
        const Space v407_2 = singleton(v406_7_head);
        const Space v407_3 = intersect(constant_2,v407_2);
        const Space v407_4 = (has_head(v407_3) ? constant_3 : Space{});
        const Space v407_5 = subtract(constant_1,v407_4);
        Space v407_8;
        if (!v407_5.empty()) {
          const Path v408_6 = concat_path(v406_6,v406_7_head);
          const Space v408_7 = routine_50(c, v408_6, p1, v406_7_tail);
          v407_8 = compose(v407_5,v408_7);
        }
        const Space v407_9 = intersect(constant_2,v407_2);
        const Space v407_10 = (has_head(v407_9) ? constant_3 : Space{});
        Space v407_12;
        if (!v407_10.empty()) {
          const Path v409_6 = concat_path(v406_6,v406_7_head);
          const Space v409_11 = routine_51(c, v409_6, p1, v406_7_tail);
          v407_12 = compose(v407_10,v409_11);
        }
        const Space v407_13 = unite(v407_8,v407_12);
        v406_7_result = unite(v406_7_result,v407_13);
      }
      const Space v406_7 = std::move(v406_7_result);
      v405_8 = compose(v405_5,v406_7);
    }
    const Space v405_9 = intersect(constant_2,v405_2);
    const Space v405_10 = (has_head(v405_9) ? constant_3 : Space{});
    const Space v405_11 = compose(v405_10,v404_9_tail);
    const Path v410_6 = concat_path(p0,v404_9_head);
    const Space v405_12 = wrap(v405_11,v410_6);
    const Space v405_13 = wrap(v405_12,p1);
    const Space v405_14 = unite(v405_8,v405_13);
    v404_9_result = unite(v404_9_result,v405_14);
  }
  const Space v404_9 = std::move(v404_9_result);
  return v404_9;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v411_4_result;
  for (int v411_4_label = 1; v411_4_label <= 2; ++v411_4_label) {
    const Space v411_4_tail = child(s0,v411_4_label);
    if (v411_4_tail.empty()) continue;
    const Path v411_4_head{v411_4_label};
    const Space v412_2 = Space{};
    v411_4_result = unite(v411_4_result,v412_2);
  }
  const Space v411_4 = std::move(v411_4_result);
  return v411_4;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v413_6 = unwrap(s1,constant_0);
  const Space v413_7 = unwrap(v413_6,p0);
  Space v413_11_result;
  for (int v413_11_label = 1; v413_11_label <= 2; ++v413_11_label) {
    const Space v413_11_tail = child(s0,v413_11_label);
    if (v413_11_tail.empty()) continue;
    const Path v413_11_head{v413_11_label};
    const Space v414_2 = singleton(v413_11_head);
    const Space v414_3 = intersect(constant_2,v414_2);
    const Space v414_4 = (has_head(v414_3) ? constant_3 : Space{});
    Space v414_7;
    if (!v414_4.empty()) {
      const Space v415_5 = unwrap(v413_7,v413_11_head);
      Space v415_6_result;
      for (int v415_6_label = 1; v415_6_label <= 2; ++v415_6_label) {
        const Space v415_6_tail = child(v415_5,v415_6_label);
        if (v415_6_tail.empty()) continue;
        const Path v415_6_head{v415_6_label};
        const Space v416_2 = singleton(v415_6_head);
        const Space v416_3 = intersect(constant_2,v416_2);
        const Space v416_4 = (has_head(v416_3) ? constant_3 : Space{});
        const Space v416_5 = subtract(constant_1,v416_4);
        Space v416_7;
        if (!v416_5.empty()) {
          const Space v417_6 = routine_15(c, v415_6_head, p1, v415_6_tail);
          v416_7 = compose(v416_5,v417_6);
        }
        const Space v416_8 = intersect(constant_2,v416_2);
        const Space v416_9 = (has_head(v416_8) ? constant_3 : Space{});
        Space v416_11;
        if (!v416_9.empty()) {
          const Space v418_10 = routine_16(c, v415_6_head, p1, v415_6_tail);
          v416_11 = compose(v416_9,v418_10);
        }
        const Space v416_12 = unite(v416_7,v416_11);
        v415_6_result = unite(v415_6_result,v416_12);
      }
      const Space v415_6 = std::move(v415_6_result);
      v414_7 = compose(v414_4,v415_6);
    }
    v413_11_result = unite(v413_11_result,v414_7);
  }
  const Space v413_11 = std::move(v413_11_result);
  return v413_11;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v419_12_result;
  for (int v419_12_label = 1; v419_12_label <= 2; ++v419_12_label) {
    const Space v419_12_tail = child(s0,v419_12_label);
    if (v419_12_tail.empty()) continue;
    const Path v419_12_head{v419_12_label};
    const Space v420_2 = singleton(v419_12_head);
    const Space v420_3 = intersect(constant_2,v420_2);
    const Space v420_4 = (has_head(v420_3) ? constant_3 : Space{});
    const Space v420_5 = subtract(constant_1,v420_4);
    Space v420_8;
    if (!v420_5.empty()) {
      const Path v421_6 = concat_path(p0,v419_12_head);
      Space v421_7_result;
      for (int v421_7_label = 1; v421_7_label <= 2; ++v421_7_label) {
        const Space v421_7_tail = child(v419_12_tail,v421_7_label);
        if (v421_7_tail.empty()) continue;
        const Path v421_7_head{v421_7_label};
        const Space v422_2 = singleton(v421_7_head);
        const Space v422_3 = intersect(constant_2,v422_2);
        const Space v422_4 = (has_head(v422_3) ? constant_3 : Space{});
        const Space v422_5 = subtract(constant_1,v422_4);
        Space v422_8;
        if (!v422_5.empty()) {
          const Path v423_6 = concat_path(v421_6,v421_7_head);
          const Space v423_7 = routine_52(c, v423_6, p1, v421_7_tail);
          v422_8 = compose(v422_5,v423_7);
        }
        const Space v422_9 = intersect(constant_2,v422_2);
        const Space v422_10 = (has_head(v422_9) ? constant_3 : Space{});
        Space v422_12;
        if (!v422_10.empty()) {
          const Path v424_6 = concat_path(v421_6,v421_7_head);
          const Space v424_11 = routine_53(c, v424_6, p1, v421_7_tail);
          v422_12 = compose(v422_10,v424_11);
        }
        const Space v422_13 = unite(v422_8,v422_12);
        v421_7_result = unite(v421_7_result,v422_13);
      }
      const Space v421_7 = std::move(v421_7_result);
      v420_8 = compose(v420_5,v421_7);
    }
    const Space v420_9 = intersect(constant_2,v420_2);
    const Space v420_10 = (has_head(v420_9) ? constant_3 : Space{});
    Space v420_12;
    if (!v420_10.empty()) {
      const Path v425_6 = concat_path(p0,v419_12_head);
      Space v425_11_result;
      for (int v425_11_label = 1; v425_11_label <= 2; ++v425_11_label) {
        const Space v425_11_tail = child(v419_12_tail,v425_11_label);
        if (v425_11_tail.empty()) continue;
        const Path v425_11_head{v425_11_label};
        const Space v426_2 = singleton(v425_11_head);
        const Space v426_3 = intersect(constant_2,v426_2);
        const Space v426_4 = (has_head(v426_3) ? constant_3 : Space{});
        const Space v426_5 = subtract(constant_1,v426_4);
        Space v426_8;
        if (!v426_5.empty()) {
          const Path v427_6 = concat_path(v425_6,v425_11_head);
          const Space v427_7 = routine_52(c, v427_6, p1, v425_11_tail);
          v426_8 = compose(v426_5,v427_7);
        }
        const Space v426_9 = intersect(constant_2,v426_2);
        const Space v426_10 = (has_head(v426_9) ? constant_3 : Space{});
        Space v426_12;
        if (!v426_10.empty()) {
          const Path v428_6 = concat_path(v425_6,v425_11_head);
          const Space v428_11 = routine_21(c, v428_6, p1, v425_11_tail);
          v426_12 = compose(v426_10,v428_11);
        }
        const Space v426_13 = unite(v426_8,v426_12);
        v425_11_result = unite(v425_11_result,v426_13);
      }
      const Space v425_11 = std::move(v425_11_result);
      v420_12 = compose(v420_10,v425_11);
    }
    const Space v420_13 = unite(v420_8,v420_12);
    v419_12_result = unite(v419_12_result,v420_13);
  }
  const Space v419_12 = std::move(v419_12_result);
  return v419_12;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v429_9_result;
  for (int v429_9_label = 1; v429_9_label <= 2; ++v429_9_label) {
    const Space v429_9_tail = child(s0,v429_9_label);
    if (v429_9_tail.empty()) continue;
    const Path v429_9_head{v429_9_label};
    const Space v430_2 = singleton(v429_9_head);
    const Space v430_3 = intersect(constant_2,v430_2);
    const Space v430_4 = (has_head(v430_3) ? constant_3 : Space{});
    const Space v430_5 = subtract(constant_1,v430_4);
    Space v430_8;
    if (!v430_5.empty()) {
      const Path v431_6 = concat_path(p0,v429_9_head);
      Space v431_7_result;
      for (int v431_7_label = 1; v431_7_label <= 2; ++v431_7_label) {
        const Space v431_7_tail = child(v429_9_tail,v431_7_label);
        if (v431_7_tail.empty()) continue;
        const Path v431_7_head{v431_7_label};
        const Space v432_2 = singleton(v431_7_head);
        const Space v432_3 = intersect(constant_2,v432_2);
        const Space v432_4 = (has_head(v432_3) ? constant_3 : Space{});
        const Space v432_5 = subtract(constant_1,v432_4);
        Space v432_8;
        if (!v432_5.empty()) {
          const Path v433_6 = concat_path(v431_6,v431_7_head);
          const Space v433_7 = routine_52(c, v433_6, p1, v431_7_tail);
          v432_8 = compose(v432_5,v433_7);
        }
        const Space v432_9 = intersect(constant_2,v432_2);
        const Space v432_10 = (has_head(v432_9) ? constant_3 : Space{});
        Space v432_12;
        if (!v432_10.empty()) {
          const Path v434_6 = concat_path(v431_6,v431_7_head);
          const Space v434_11 = routine_53(c, v434_6, p1, v431_7_tail);
          v432_12 = compose(v432_10,v434_11);
        }
        const Space v432_13 = unite(v432_8,v432_12);
        v431_7_result = unite(v431_7_result,v432_13);
      }
      const Space v431_7 = std::move(v431_7_result);
      v430_8 = compose(v430_5,v431_7);
    }
    const Space v430_9 = intersect(constant_2,v430_2);
    const Space v430_10 = (has_head(v430_9) ? constant_3 : Space{});
    const Space v430_11 = compose(v430_10,v429_9_tail);
    const Path v435_6 = concat_path(p0,v429_9_head);
    const Space v430_12 = wrap(v430_11,v435_6);
    const Space v430_13 = wrap(v430_12,p1);
    const Space v430_14 = unite(v430_8,v430_13);
    v429_9_result = unite(v429_9_result,v430_14);
  }
  const Space v429_9 = std::move(v429_9_result);
  return v429_9;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v436_7_result;
  for (int v436_7_label = 1; v436_7_label <= 2; ++v436_7_label) {
    const Space v436_7_tail = child(s0,v436_7_label);
    if (v436_7_tail.empty()) continue;
    const Path v436_7_head{v436_7_label};
    const Space v437_2 = singleton(v436_7_head);
    const Space v437_3 = intersect(constant_2,v437_2);
    const Space v437_4 = (has_head(v437_3) ? constant_3 : Space{});
    const Space v437_5 = subtract(constant_1,v437_4);
    Space v437_6_result;
    for (int v437_6_label = 1; v437_6_label <= 2; ++v437_6_label) {
      const Space v437_6_tail = child(v436_7_tail,v437_6_label);
      if (v437_6_tail.empty()) continue;
      const Path v437_6_head{v437_6_label};
      const Space v438_2 = Space{};
      v437_6_result = unite(v437_6_result,v438_2);
    }
    const Space v437_6 = std::move(v437_6_result);
    const Space v437_7 = compose(v437_5,v437_6);
    const Space v437_8 = intersect(constant_2,v437_2);
    const Space v437_9 = (has_head(v437_8) ? constant_3 : Space{});
    Space v437_12;
    if (!v437_9.empty()) {
      const Path v439_10 = concat_path(p0,v436_7_head);
      Space v439_11_result;
      for (int v439_11_label = 1; v439_11_label <= 2; ++v439_11_label) {
        const Space v439_11_tail = child(v436_7_tail,v439_11_label);
        if (v439_11_tail.empty()) continue;
        const Path v439_11_head{v439_11_label};
        const Space v440_2 = singleton(v439_11_head);
        const Space v440_3 = intersect(constant_2,v440_2);
        const Space v440_4 = (has_head(v440_3) ? constant_3 : Space{});
        Space v440_7;
        if (!v440_4.empty()) {
          const Path v441_5 = concat_path(v439_10,v439_11_head);
          const Space v441_6 = routine_21(c, v441_5, p1, v439_11_tail);
          v440_7 = compose(v440_4,v441_6);
        }
        v439_11_result = unite(v439_11_result,v440_7);
      }
      const Space v439_11 = std::move(v439_11_result);
      v437_12 = compose(v437_9,v439_11);
    }
    const Space v437_13 = unite(v437_7,v437_12);
    v436_7_result = unite(v436_7_result,v437_13);
  }
  const Space v436_7 = std::move(v436_7_result);
  return v436_7;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v442_6_result;
  for (int v442_6_label = 1; v442_6_label <= 2; ++v442_6_label) {
    const Space v442_6_tail = child(s0,v442_6_label);
    if (v442_6_tail.empty()) continue;
    const Path v442_6_head{v442_6_label};
    const Space v443_2 = singleton(v442_6_head);
    const Space v443_3 = intersect(constant_2,v443_2);
    const Space v443_4 = (has_head(v443_3) ? constant_3 : Space{});
    const Space v443_5 = subtract(constant_1,v443_4);
    Space v443_6_result;
    for (int v443_6_label = 1; v443_6_label <= 2; ++v443_6_label) {
      const Space v443_6_tail = child(v442_6_tail,v443_6_label);
      if (v443_6_tail.empty()) continue;
      const Path v443_6_head{v443_6_label};
      const Space v444_2 = Space{};
      v443_6_result = unite(v443_6_result,v444_2);
    }
    const Space v443_6 = std::move(v443_6_result);
    const Space v443_7 = compose(v443_5,v443_6);
    const Space v443_8 = intersect(constant_2,v443_2);
    const Space v443_9 = (has_head(v443_8) ? constant_3 : Space{});
    const Space v443_10 = compose(v443_9,v442_6_tail);
    const Path v443_11 = concat_path(p0,v442_6_head);
    const Space v443_12 = wrap(v443_10,v443_11);
    const Space v443_13 = wrap(v443_12,p1);
    const Space v443_14 = unite(v443_7,v443_13);
    v442_6_result = unite(v442_6_result,v443_14);
  }
  const Space v442_6 = std::move(v442_6_result);
  return v442_6;
}

static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v445_3_result;
  for (int v445_3_label = 1; v445_3_label <= 2; ++v445_3_label) {
    const Space v445_3_tail = child(s0,v445_3_label);
    if (v445_3_tail.empty()) continue;
    const Path v445_3_head{v445_3_label};
    const Space v446_2 = Space{};
    v445_3_result = unite(v445_3_result,v446_2);
  }
  const Space v445_3 = std::move(v445_3_result);
  return v445_3;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v447_4_result;
  for (int v447_4_label = 1; v447_4_label <= 2; ++v447_4_label) {
    const Space v447_4_tail = child(s0,v447_4_label);
    if (v447_4_tail.empty()) continue;
    const Path v447_4_head{v447_4_label};
    const Space v448_2 = singleton(v447_4_head);
    const Space v448_3 = intersect(constant_2,v448_2);
    const Space v448_4 = (has_head(v448_3) ? constant_3 : Space{});
    const Space v448_5 = compose(v448_4,v447_4_tail);
    const Path v448_6 = concat_path(p0,v447_4_head);
    const Space v448_7 = wrap(v448_5,v448_6);
    v447_4_result = unite(v447_4_result,v448_7);
  }
  const Space v447_4 = std::move(v447_4_result);
  const Space v447_5 = wrap(v447_4,p1);
  return v447_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
