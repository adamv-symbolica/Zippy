#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{1,1,2,1,2,1,1,1,2,2};
static const Path constant_4 = Path{2,1,1,1,2,1,1,1,2,2};
static const Path constant_5 = Path{2,2};
static const Path constant_6 = Path{1,2,2};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  Space v0_5_result;
  for (int v0_5_label = 1; v0_5_label <= 2; ++v0_5_label) {
    const Space v0_5_tail = child(bound_space(s1),v0_5_label);
    if (v0_5_tail.empty()) continue;
    const Path v0_5_head{v0_5_label};
    const Space v1_2 = singleton(v0_5_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_5_result = unite(v0_5_result,v1_12);
  }
  const Space v0_5 = std::move(v0_5_result);
  const Space v0_7 = wrap(v0_5,constant_3);
  return v0_7;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v4_12_result;
  for (int v4_12_label = 1; v4_12_label <= 2; ++v4_12_label) {
    const Space v4_12_tail = child(s0,v4_12_label);
    if (v4_12_tail.empty()) continue;
    const Path v4_12_head{v4_12_label};
    const Space v5_2 = singleton(v4_12_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_12_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_12_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail, s1);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail, s1);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_12_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_12_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail, s1);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail, s1);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_12_result = unite(v4_12_result,v5_13);
  }
  const Space v4_12 = std::move(v4_12_result);
  return v4_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v14_7 = unwrap(s1,constant_4);
  const Space v14_9 = unwrap(s1,constant_5);
  const Space v14_10 = unwrap(v14_9,p0);
  const Space v14_12 = unwrap(s1,constant_6);
  Space v14_22_result;
  for (int v14_22_label = 1; v14_22_label <= 2; ++v14_22_label) {
    const Space v14_22_tail = child(s0,v14_22_label);
    if (v14_22_tail.empty()) continue;
    const Path v14_22_head{v14_22_label};
    const Space v15_2 = singleton(v14_22_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_22_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_22_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_18;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_10,v14_22_head);
      const Space v20_12 = restrict_to(v14_9,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(v14_7,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = subtract(v20_15,v20_11);
      const Space v20_17 = intersect(v20_16,v14_12);
      v15_18 = compose(v15_10,v20_17);
    }
    const Path v27_6 = concat_path(p0,v14_22_head);
    const Space v15_19 = wrap(v15_18,v27_6);
    const Space v15_20 = unite(v15_8,v15_19);
    v14_22_result = unite(v14_22_result,v15_20);
  }
  const Space v14_22 = std::move(v14_22_result);
  return v14_22;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v28_12_result;
  for (int v28_12_label = 1; v28_12_label <= 2; ++v28_12_label) {
    const Space v28_12_tail = child(s0,v28_12_label);
    if (v28_12_tail.empty()) continue;
    const Path v28_12_head{v28_12_label};
    const Space v29_2 = singleton(v28_12_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_12_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_12_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail, s1);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail, s1);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_12_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_12_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail, s1);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail, s1);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_12_result = unite(v28_12_result,v29_13);
  }
  const Space v28_12 = std::move(v28_12_result);
  return v28_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v38_7 = unwrap(s1,constant_4);
  const Space v38_9 = unwrap(s1,constant_5);
  const Space v38_10 = unwrap(v38_9,p0);
  const Space v38_12 = unwrap(s1,constant_6);
  Space v38_22_result;
  for (int v38_22_label = 1; v38_22_label <= 2; ++v38_22_label) {
    const Space v38_22_tail = child(s0,v38_22_label);
    if (v38_22_tail.empty()) continue;
    const Path v38_22_head{v38_22_label};
    const Space v39_2 = singleton(v38_22_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_22_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_22_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail, s1);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail, s1);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_18;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_10,v38_22_head);
      const Space v44_12 = restrict_to(v38_9,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(v38_7,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = subtract(v44_15,v44_11);
      const Space v44_17 = intersect(v44_16,v38_12);
      v39_18 = compose(v39_10,v44_17);
    }
    const Path v51_6 = concat_path(p0,v38_22_head);
    const Space v39_19 = wrap(v39_18,v51_6);
    const Space v39_20 = unite(v39_8,v39_19);
    v38_22_result = unite(v38_22_result,v39_20);
  }
  const Space v38_22 = std::move(v38_22_result);
  return v38_22;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v52_4 = unwrap(s1,constant_4);
  const Space v52_6 = unwrap(s1,constant_5);
  const Space v52_7 = unwrap(v52_6,p0);
  const Space v52_8 = restrict_to(v52_6,v52_7);
  Space v52_18_result;
  for (int v52_18_label = 1; v52_18_label <= 2; ++v52_18_label) {
    const Space v52_18_tail = child(v52_8,v52_18_label);
    if (v52_18_tail.empty()) continue;
    const Path v52_18_head{v52_18_label};
    const Space v53_2 = singleton(v52_18_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_18_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_18_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_18_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_18_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_18_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_18_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_18_result = unite(v52_18_result,v53_12);
  }
  const Space v52_18 = std::move(v52_18_result);
  const Space v52_19 = restrict_to(v52_4,v52_18);
  Space v52_29_result;
  for (int v52_29_label = 1; v52_29_label <= 2; ++v52_29_label) {
    const Space v52_29_tail = child(v52_19,v52_29_label);
    if (v52_29_tail.empty()) continue;
    const Path v52_29_head{v52_29_label};
    const Space v62_2 = singleton(v52_29_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_29_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_29_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_29_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_29_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_29_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_29_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_29_result = unite(v52_29_result,v62_12);
  }
  const Space v52_29 = std::move(v52_29_result);
  const Space v52_30 = subtract(v52_29,v52_7);
  const Space v52_32 = unwrap(s1,constant_6);
  const Space v52_33 = intersect(v52_30,v52_32);
  const Space v52_34 = wrap(v52_33,p0);
  return v52_34;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v103_12_result;
  for (int v103_12_label = 1; v103_12_label <= 2; ++v103_12_label) {
    const Space v103_12_tail = child(s0,v103_12_label);
    if (v103_12_tail.empty()) continue;
    const Path v103_12_head{v103_12_label};
    const Space v104_2 = singleton(v103_12_head);
    const Space v104_3 = intersect(constant_1,v104_2);
    const Space v104_4 = (has_head(v104_3) ? constant_2 : Space{});
    const Space v104_5 = subtract(constant_0,v104_4);
    Space v104_8;
    if (!v104_5.empty()) {
      const Path v105_6 = concat_path(p0,v103_12_head);
      Space v105_7_result;
      for (int v105_7_label = 1; v105_7_label <= 2; ++v105_7_label) {
        const Space v105_7_tail = child(v103_12_tail,v105_7_label);
        if (v105_7_tail.empty()) continue;
        const Path v105_7_head{v105_7_label};
        const Space v106_2 = singleton(v105_7_head);
        const Space v106_3 = intersect(constant_1,v106_2);
        const Space v106_4 = (has_head(v106_3) ? constant_2 : Space{});
        const Space v106_5 = subtract(constant_0,v106_4);
        Space v106_8;
        if (!v106_5.empty()) {
          const Path v107_6 = concat_path(v105_6,v105_7_head);
          const Space v107_7 = routine_22(c, v107_6, v105_7_tail, s1);
          v106_8 = compose(v106_5,v107_7);
        }
        const Space v106_9 = intersect(constant_1,v106_2);
        const Space v106_10 = (has_head(v106_9) ? constant_2 : Space{});
        Space v106_12;
        if (!v106_10.empty()) {
          const Path v108_6 = concat_path(v105_6,v105_7_head);
          const Space v108_11 = routine_23(c, v108_6, v105_7_tail, s1);
          v106_12 = compose(v106_10,v108_11);
        }
        const Space v106_13 = unite(v106_8,v106_12);
        v105_7_result = unite(v105_7_result,v106_13);
      }
      const Space v105_7 = std::move(v105_7_result);
      v104_8 = compose(v104_5,v105_7);
    }
    const Space v104_9 = intersect(constant_1,v104_2);
    const Space v104_10 = (has_head(v104_9) ? constant_2 : Space{});
    Space v104_12;
    if (!v104_10.empty()) {
      const Path v109_6 = concat_path(p0,v103_12_head);
      Space v109_11_result;
      for (int v109_11_label = 1; v109_11_label <= 2; ++v109_11_label) {
        const Space v109_11_tail = child(v103_12_tail,v109_11_label);
        if (v109_11_tail.empty()) continue;
        const Path v109_11_head{v109_11_label};
        const Space v110_2 = singleton(v109_11_head);
        const Space v110_3 = intersect(constant_1,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_2 : Space{});
        const Space v110_5 = subtract(constant_0,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_11_head);
          const Space v111_7 = routine_22(c, v111_6, v109_11_tail, s1);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_1,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_2 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_11_head);
          const Space v112_11 = routine_5(c, v112_6, v109_11_tail, s1);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_11_result = unite(v109_11_result,v110_13);
      }
      const Space v109_11 = std::move(v109_11_result);
      v104_12 = compose(v104_10,v109_11);
    }
    const Space v104_13 = unite(v104_8,v104_12);
    v103_12_result = unite(v103_12_result,v104_13);
  }
  const Space v103_12 = std::move(v103_12_result);
  return v103_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v113_7 = unwrap(s1,constant_4);
  const Space v113_9 = unwrap(s1,constant_5);
  const Space v113_10 = unwrap(v113_9,p0);
  const Space v113_12 = unwrap(s1,constant_6);
  Space v113_22_result;
  for (int v113_22_label = 1; v113_22_label <= 2; ++v113_22_label) {
    const Space v113_22_tail = child(s0,v113_22_label);
    if (v113_22_tail.empty()) continue;
    const Path v113_22_head{v113_22_label};
    const Space v114_2 = singleton(v113_22_head);
    const Space v114_3 = intersect(constant_1,v114_2);
    const Space v114_4 = (has_head(v114_3) ? constant_2 : Space{});
    const Space v114_5 = subtract(constant_0,v114_4);
    Space v114_8;
    if (!v114_5.empty()) {
      const Path v115_6 = concat_path(p0,v113_22_head);
      Space v115_7_result;
      for (int v115_7_label = 1; v115_7_label <= 2; ++v115_7_label) {
        const Space v115_7_tail = child(v113_22_tail,v115_7_label);
        if (v115_7_tail.empty()) continue;
        const Path v115_7_head{v115_7_label};
        const Space v116_2 = singleton(v115_7_head);
        const Space v116_3 = intersect(constant_1,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_2 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_8;
        if (!v116_5.empty()) {
          const Path v117_6 = concat_path(v115_6,v115_7_head);
          const Space v117_7 = routine_22(c, v117_6, v115_7_tail, s1);
          v116_8 = compose(v116_5,v117_7);
        }
        const Space v116_9 = intersect(constant_1,v116_2);
        const Space v116_10 = (has_head(v116_9) ? constant_2 : Space{});
        Space v116_12;
        if (!v116_10.empty()) {
          const Path v118_6 = concat_path(v115_6,v115_7_head);
          const Space v118_11 = routine_23(c, v118_6, v115_7_tail, s1);
          v116_12 = compose(v116_10,v118_11);
        }
        const Space v116_13 = unite(v116_8,v116_12);
        v115_7_result = unite(v115_7_result,v116_13);
      }
      const Space v115_7 = std::move(v115_7_result);
      v114_8 = compose(v114_5,v115_7);
    }
    const Space v114_9 = intersect(constant_1,v114_2);
    const Space v114_10 = (has_head(v114_9) ? constant_2 : Space{});
    Space v114_18;
    if (!v114_10.empty()) {
      const Space v119_11 = unwrap(v113_10,v113_22_head);
      const Space v119_12 = restrict_to(v113_9,v119_11);
      Space v119_13_result;
      for (int v119_13_label = 1; v119_13_label <= 2; ++v119_13_label) {
        const Space v119_13_tail = child(v119_12,v119_13_label);
        if (v119_13_tail.empty()) continue;
        const Path v119_13_head{v119_13_label};
        const Space v120_2 = singleton(v119_13_head);
        const Space v120_3 = intersect(constant_1,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_7;
        if (!v120_5.empty()) {
          const Space v121_6 = routine_6(c, v119_13_head, v119_13_tail);
          v120_7 = compose(v120_5,v121_6);
        }
        const Space v120_8 = intersect(constant_1,v120_2);
        const Space v120_9 = (has_head(v120_8) ? constant_2 : Space{});
        Space v120_11;
        if (!v120_9.empty()) {
          const Space v122_10 = routine_7(c, v119_13_head, v119_13_tail);
          v120_11 = compose(v120_9,v122_10);
        }
        const Space v120_12 = unite(v120_7,v120_11);
        v119_13_result = unite(v119_13_result,v120_12);
      }
      const Space v119_13 = std::move(v119_13_result);
      const Space v119_14 = restrict_to(v113_7,v119_13);
      Space v119_15_result;
      for (int v119_15_label = 1; v119_15_label <= 2; ++v119_15_label) {
        const Space v119_15_tail = child(v119_14,v119_15_label);
        if (v119_15_tail.empty()) continue;
        const Path v119_15_head{v119_15_label};
        const Space v123_2 = singleton(v119_15_head);
        const Space v123_3 = intersect(constant_1,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_2 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_7;
        if (!v123_5.empty()) {
          const Space v124_6 = routine_8(c, v119_15_head, v119_15_tail);
          v123_7 = compose(v123_5,v124_6);
        }
        const Space v123_8 = intersect(constant_1,v123_2);
        const Space v123_9 = (has_head(v123_8) ? constant_2 : Space{});
        Space v123_11;
        if (!v123_9.empty()) {
          const Space v125_10 = routine_9(c, v119_15_head, v119_15_tail);
          v123_11 = compose(v123_9,v125_10);
        }
        const Space v123_12 = unite(v123_7,v123_11);
        v119_15_result = unite(v119_15_result,v123_12);
      }
      const Space v119_15 = std::move(v119_15_result);
      const Space v119_16 = subtract(v119_15,v119_11);
      const Space v119_17 = intersect(v119_16,v113_12);
      v114_18 = compose(v114_10,v119_17);
    }
    const Path v126_6 = concat_path(p0,v113_22_head);
    const Space v114_19 = wrap(v114_18,v126_6);
    const Space v114_20 = unite(v114_8,v114_19);
    v113_22_result = unite(v113_22_result,v114_20);
  }
  const Space v113_22 = std::move(v113_22_result);
  return v113_22;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v127_11_result;
  for (int v127_11_label = 1; v127_11_label <= 2; ++v127_11_label) {
    const Space v127_11_tail = child(s0,v127_11_label);
    if (v127_11_tail.empty()) continue;
    const Path v127_11_head{v127_11_label};
    const Space v128_2 = singleton(v127_11_head);
    const Space v128_3 = intersect(constant_1,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_2 : Space{});
    const Space v128_5 = subtract(constant_0,v128_4);
    Space v128_8;
    if (!v128_5.empty()) {
      const Path v129_6 = concat_path(p0,v127_11_head);
      Space v129_7_result;
      for (int v129_7_label = 1; v129_7_label <= 2; ++v129_7_label) {
        const Space v129_7_tail = child(v127_11_tail,v129_7_label);
        if (v129_7_tail.empty()) continue;
        const Path v129_7_head{v129_7_label};
        const Space v130_2 = singleton(v129_7_head);
        const Space v130_3 = intersect(constant_1,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_2 : Space{});
        const Space v130_5 = subtract(constant_0,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v129_6,v129_7_head);
          const Space v131_7 = routine_24(c, v131_6, v129_7_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_1,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_2 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v129_6,v129_7_head);
          const Space v132_11 = routine_25(c, v132_6, v129_7_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_7_result = unite(v129_7_result,v130_13);
      }
      const Space v129_7 = std::move(v129_7_result);
      v128_8 = compose(v128_5,v129_7);
    }
    const Space v128_9 = intersect(constant_1,v128_2);
    const Space v128_10 = (has_head(v128_9) ? constant_2 : Space{});
    Space v128_12;
    if (!v128_10.empty()) {
      const Path v133_6 = concat_path(p0,v127_11_head);
      Space v133_11_result;
      for (int v133_11_label = 1; v133_11_label <= 2; ++v133_11_label) {
        const Space v133_11_tail = child(v127_11_tail,v133_11_label);
        if (v133_11_tail.empty()) continue;
        const Path v133_11_head{v133_11_label};
        const Space v134_2 = singleton(v133_11_head);
        const Space v134_3 = intersect(constant_1,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_2 : Space{});
        const Space v134_5 = subtract(constant_0,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v133_6,v133_11_head);
          const Space v135_7 = routine_24(c, v135_6, v133_11_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_1,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_2 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v133_6,v133_11_head);
          const Space v136_11 = routine_14(c, v136_6, v133_11_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_11_result = unite(v133_11_result,v134_13);
      }
      const Space v133_11 = std::move(v133_11_result);
      v128_12 = compose(v128_10,v133_11);
    }
    const Space v128_13 = unite(v128_8,v128_12);
    v127_11_result = unite(v127_11_result,v128_13);
  }
  const Space v127_11 = std::move(v127_11_result);
  return v127_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v137_8_result;
  for (int v137_8_label = 1; v137_8_label <= 2; ++v137_8_label) {
    const Space v137_8_tail = child(s0,v137_8_label);
    if (v137_8_tail.empty()) continue;
    const Path v137_8_head{v137_8_label};
    const Space v138_2 = singleton(v137_8_head);
    const Space v138_3 = intersect(constant_1,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_2 : Space{});
    const Space v138_5 = subtract(constant_0,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_8_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_8_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_1,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_2 : Space{});
        const Space v140_5 = subtract(constant_0,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_24(c, v141_6, v139_7_tail);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_1,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_2 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_25(c, v142_6, v139_7_tail);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_1,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_2 : Space{});
    const Space v138_11 = compose(v138_10,v137_8_tail);
    const Space v138_12 = unite(v138_8,v138_11);
    v137_8_result = unite(v137_8_result,v138_12);
  }
  const Space v137_8 = std::move(v137_8_result);
  return v137_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v144_11_result;
  for (int v144_11_label = 1; v144_11_label <= 2; ++v144_11_label) {
    const Space v144_11_tail = child(s0,v144_11_label);
    if (v144_11_tail.empty()) continue;
    const Path v144_11_head{v144_11_label};
    const Space v145_2 = singleton(v144_11_head);
    const Space v145_3 = intersect(constant_1,v145_2);
    const Space v145_4 = (has_head(v145_3) ? constant_2 : Space{});
    const Space v145_5 = subtract(constant_0,v145_4);
    Space v145_8;
    if (!v145_5.empty()) {
      const Path v146_6 = concat_path(p0,v144_11_head);
      Space v146_7_result;
      for (int v146_7_label = 1; v146_7_label <= 2; ++v146_7_label) {
        const Space v146_7_tail = child(v144_11_tail,v146_7_label);
        if (v146_7_tail.empty()) continue;
        const Path v146_7_head{v146_7_label};
        const Space v147_2 = singleton(v146_7_head);
        const Space v147_3 = intersect(constant_1,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_2 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v146_6,v146_7_head);
          const Space v148_7 = routine_26(c, v148_6, v146_7_tail);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_1,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_2 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v146_6,v146_7_head);
          const Space v149_11 = routine_27(c, v149_6, v146_7_tail);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_7_result = unite(v146_7_result,v147_13);
      }
      const Space v146_7 = std::move(v146_7_result);
      v145_8 = compose(v145_5,v146_7);
    }
    const Space v145_9 = intersect(constant_1,v145_2);
    const Space v145_10 = (has_head(v145_9) ? constant_2 : Space{});
    Space v145_12;
    if (!v145_10.empty()) {
      const Path v150_6 = concat_path(p0,v144_11_head);
      Space v150_11_result;
      for (int v150_11_label = 1; v150_11_label <= 2; ++v150_11_label) {
        const Space v150_11_tail = child(v144_11_tail,v150_11_label);
        if (v150_11_tail.empty()) continue;
        const Path v150_11_head{v150_11_label};
        const Space v151_2 = singleton(v150_11_head);
        const Space v151_3 = intersect(constant_1,v151_2);
        const Space v151_4 = (has_head(v151_3) ? constant_2 : Space{});
        const Space v151_5 = subtract(constant_0,v151_4);
        Space v151_8;
        if (!v151_5.empty()) {
          const Path v152_6 = concat_path(v150_6,v150_11_head);
          const Space v152_7 = routine_26(c, v152_6, v150_11_tail);
          v151_8 = compose(v151_5,v152_7);
        }
        const Space v151_9 = intersect(constant_1,v151_2);
        const Space v151_10 = (has_head(v151_9) ? constant_2 : Space{});
        Space v151_12;
        if (!v151_10.empty()) {
          const Path v153_6 = concat_path(v150_6,v150_11_head);
          const Space v153_11 = routine_17(c, v153_6, v150_11_tail);
          v151_12 = compose(v151_10,v153_11);
        }
        const Space v151_13 = unite(v151_8,v151_12);
        v150_11_result = unite(v150_11_result,v151_13);
      }
      const Space v150_11 = std::move(v150_11_result);
      v145_12 = compose(v145_10,v150_11);
    }
    const Space v145_13 = unite(v145_8,v145_12);
    v144_11_result = unite(v144_11_result,v145_13);
  }
  const Space v144_11 = std::move(v144_11_result);
  return v144_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v154_8_result;
  for (int v154_8_label = 1; v154_8_label <= 2; ++v154_8_label) {
    const Space v154_8_tail = child(s0,v154_8_label);
    if (v154_8_tail.empty()) continue;
    const Path v154_8_head{v154_8_label};
    const Space v155_2 = singleton(v154_8_head);
    const Space v155_3 = intersect(constant_1,v155_2);
    const Space v155_4 = (has_head(v155_3) ? constant_2 : Space{});
    const Space v155_5 = subtract(constant_0,v155_4);
    Space v155_8;
    if (!v155_5.empty()) {
      const Path v156_6 = concat_path(p0,v154_8_head);
      Space v156_7_result;
      for (int v156_7_label = 1; v156_7_label <= 2; ++v156_7_label) {
        const Space v156_7_tail = child(v154_8_tail,v156_7_label);
        if (v156_7_tail.empty()) continue;
        const Path v156_7_head{v156_7_label};
        const Space v157_2 = singleton(v156_7_head);
        const Space v157_3 = intersect(constant_1,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_2 : Space{});
        const Space v157_5 = subtract(constant_0,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_7_head);
          const Space v158_7 = routine_26(c, v158_6, v156_7_tail);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_1,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_2 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_7_head);
          const Space v159_11 = routine_27(c, v159_6, v156_7_tail);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_7_result = unite(v156_7_result,v157_13);
      }
      const Space v156_7 = std::move(v156_7_result);
      v155_8 = compose(v155_5,v156_7);
    }
    const Space v155_9 = intersect(constant_1,v155_2);
    const Space v155_10 = (has_head(v155_9) ? constant_2 : Space{});
    const Space v155_11 = compose(v155_10,v154_8_tail);
    const Space v155_12 = unite(v155_8,v155_11);
    v154_8_result = unite(v154_8_result,v155_12);
  }
  const Space v154_8 = std::move(v154_8_result);
  return v154_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v161_11_result;
  for (int v161_11_label = 1; v161_11_label <= 2; ++v161_11_label) {
    const Space v161_11_tail = child(s0,v161_11_label);
    if (v161_11_tail.empty()) continue;
    const Path v161_11_head{v161_11_label};
    const Space v162_2 = singleton(v161_11_head);
    const Space v162_3 = intersect(constant_1,v162_2);
    const Space v162_4 = (has_head(v162_3) ? constant_2 : Space{});
    const Space v162_5 = subtract(constant_0,v162_4);
    Space v162_8;
    if (!v162_5.empty()) {
      const Path v163_6 = concat_path(p0,v161_11_head);
      Space v163_7_result;
      for (int v163_7_label = 1; v163_7_label <= 2; ++v163_7_label) {
        const Space v163_7_tail = child(v161_11_tail,v163_7_label);
        if (v163_7_tail.empty()) continue;
        const Path v163_7_head{v163_7_label};
        const Space v164_2 = singleton(v163_7_head);
        const Space v164_3 = intersect(constant_1,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
        const Space v164_5 = subtract(constant_0,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v163_6,v163_7_head);
          const Space v165_7 = routine_28(c, v165_6, v163_7_tail);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_1,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v163_6,v163_7_head);
          const Space v166_11 = routine_29(c, v166_6, v163_7_tail);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_7_result = unite(v163_7_result,v164_13);
      }
      const Space v163_7 = std::move(v163_7_result);
      v162_8 = compose(v162_5,v163_7);
    }
    const Space v162_9 = intersect(constant_1,v162_2);
    const Space v162_10 = (has_head(v162_9) ? constant_2 : Space{});
    Space v162_12;
    if (!v162_10.empty()) {
      const Path v167_6 = concat_path(p0,v161_11_head);
      Space v167_11_result;
      for (int v167_11_label = 1; v167_11_label <= 2; ++v167_11_label) {
        const Space v167_11_tail = child(v161_11_tail,v167_11_label);
        if (v167_11_tail.empty()) continue;
        const Path v167_11_head{v167_11_label};
        const Space v168_2 = singleton(v167_11_head);
        const Space v168_3 = intersect(constant_1,v168_2);
        const Space v168_4 = (has_head(v168_3) ? constant_2 : Space{});
        const Space v168_5 = subtract(constant_0,v168_4);
        Space v168_8;
        if (!v168_5.empty()) {
          const Path v169_6 = concat_path(v167_6,v167_11_head);
          const Space v169_7 = routine_28(c, v169_6, v167_11_tail);
          v168_8 = compose(v168_5,v169_7);
        }
        const Space v168_9 = intersect(constant_1,v168_2);
        const Space v168_10 = (has_head(v168_9) ? constant_2 : Space{});
        Space v168_12;
        if (!v168_10.empty()) {
          const Path v170_6 = concat_path(v167_6,v167_11_head);
          const Space v170_11 = routine_14(c, v170_6, v167_11_tail);
          v168_12 = compose(v168_10,v170_11);
        }
        const Space v168_13 = unite(v168_8,v168_12);
        v167_11_result = unite(v167_11_result,v168_13);
      }
      const Space v167_11 = std::move(v167_11_result);
      v162_12 = compose(v162_10,v167_11);
    }
    const Space v162_13 = unite(v162_8,v162_12);
    v161_11_result = unite(v161_11_result,v162_13);
  }
  const Space v161_11 = std::move(v161_11_result);
  return v161_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v171_8_result;
  for (int v171_8_label = 1; v171_8_label <= 2; ++v171_8_label) {
    const Space v171_8_tail = child(s0,v171_8_label);
    if (v171_8_tail.empty()) continue;
    const Path v171_8_head{v171_8_label};
    const Space v172_2 = singleton(v171_8_head);
    const Space v172_3 = intersect(constant_1,v172_2);
    const Space v172_4 = (has_head(v172_3) ? constant_2 : Space{});
    const Space v172_5 = subtract(constant_0,v172_4);
    Space v172_8;
    if (!v172_5.empty()) {
      const Path v173_6 = concat_path(p0,v171_8_head);
      Space v173_7_result;
      for (int v173_7_label = 1; v173_7_label <= 2; ++v173_7_label) {
        const Space v173_7_tail = child(v171_8_tail,v173_7_label);
        if (v173_7_tail.empty()) continue;
        const Path v173_7_head{v173_7_label};
        const Space v174_2 = singleton(v173_7_head);
        const Space v174_3 = intersect(constant_1,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_2 : Space{});
        const Space v174_5 = subtract(constant_0,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_7_head);
          const Space v175_7 = routine_28(c, v175_6, v173_7_tail);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_1,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_2 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_7_head);
          const Space v176_11 = routine_29(c, v176_6, v173_7_tail);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_7_result = unite(v173_7_result,v174_13);
      }
      const Space v173_7 = std::move(v173_7_result);
      v172_8 = compose(v172_5,v173_7);
    }
    const Space v172_9 = intersect(constant_1,v172_2);
    const Space v172_10 = (has_head(v172_9) ? constant_2 : Space{});
    const Space v172_11 = compose(v172_10,v171_8_tail);
    const Space v172_12 = unite(v172_8,v172_11);
    v171_8_result = unite(v171_8_result,v172_12);
  }
  const Space v171_8 = std::move(v171_8_result);
  return v171_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v177_11_result;
  for (int v177_11_label = 1; v177_11_label <= 2; ++v177_11_label) {
    const Space v177_11_tail = child(s0,v177_11_label);
    if (v177_11_tail.empty()) continue;
    const Path v177_11_head{v177_11_label};
    const Space v178_2 = singleton(v177_11_head);
    const Space v178_3 = intersect(constant_1,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_2 : Space{});
    const Space v178_5 = subtract(constant_0,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_11_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_11_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_1,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
        const Space v180_5 = subtract(constant_0,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_30(c, v181_6, v179_7_tail);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_1,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_2 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_31(c, v182_6, v179_7_tail);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_1,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_2 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_11_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_11_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_1,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_2 : Space{});
        const Space v184_5 = subtract(constant_0,v184_4);
        Space v184_8;
        if (!v184_5.empty()) {
          const Path v185_6 = concat_path(v183_6,v183_11_head);
          const Space v185_7 = routine_30(c, v185_6, v183_11_tail);
          v184_8 = compose(v184_5,v185_7);
        }
        const Space v184_9 = intersect(constant_1,v184_2);
        const Space v184_10 = (has_head(v184_9) ? constant_2 : Space{});
        Space v184_12;
        if (!v184_10.empty()) {
          const Path v186_6 = concat_path(v183_6,v183_11_head);
          const Space v186_11 = routine_17(c, v186_6, v183_11_tail);
          v184_12 = compose(v184_10,v186_11);
        }
        const Space v184_13 = unite(v184_8,v184_12);
        v183_11_result = unite(v183_11_result,v184_13);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_11_result = unite(v177_11_result,v178_13);
  }
  const Space v177_11 = std::move(v177_11_result);
  return v177_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v187_8_result;
  for (int v187_8_label = 1; v187_8_label <= 2; ++v187_8_label) {
    const Space v187_8_tail = child(s0,v187_8_label);
    if (v187_8_tail.empty()) continue;
    const Path v187_8_head{v187_8_label};
    const Space v188_2 = singleton(v187_8_head);
    const Space v188_3 = intersect(constant_1,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_2 : Space{});
    const Space v188_5 = subtract(constant_0,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_8_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_8_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_1,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_2 : Space{});
        const Space v190_5 = subtract(constant_0,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_30(c, v191_6, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_1,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_2 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_31(c, v192_6, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_1,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_2 : Space{});
    const Space v188_11 = compose(v188_10,v187_8_tail);
    const Space v188_12 = unite(v188_8,v188_11);
    v187_8_result = unite(v187_8_result,v188_12);
  }
  const Space v187_8 = std::move(v187_8_result);
  return v187_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v193_12_result;
  for (int v193_12_label = 1; v193_12_label <= 2; ++v193_12_label) {
    const Space v193_12_tail = child(s0,v193_12_label);
    if (v193_12_tail.empty()) continue;
    const Path v193_12_head{v193_12_label};
    const Space v194_2 = singleton(v193_12_head);
    const Space v194_3 = intersect(constant_1,v194_2);
    const Space v194_4 = (has_head(v194_3) ? constant_2 : Space{});
    const Space v194_5 = subtract(constant_0,v194_4);
    Space v194_8;
    if (!v194_5.empty()) {
      const Path v195_6 = concat_path(p0,v193_12_head);
      Space v195_7_result;
      for (int v195_7_label = 1; v195_7_label <= 2; ++v195_7_label) {
        const Space v195_7_tail = child(v193_12_tail,v195_7_label);
        if (v195_7_tail.empty()) continue;
        const Path v195_7_head{v195_7_label};
        const Space v196_2 = singleton(v195_7_head);
        const Space v196_3 = intersect(constant_1,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_2 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v195_6,v195_7_head);
          const Space v197_7 = routine_32(c, v197_6, v195_7_tail, s1);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_1,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_2 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v195_6,v195_7_head);
          const Space v198_11 = routine_33(c, v198_6, v195_7_tail, s1);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_7_result = unite(v195_7_result,v196_13);
      }
      const Space v195_7 = std::move(v195_7_result);
      v194_8 = compose(v194_5,v195_7);
    }
    const Space v194_9 = intersect(constant_1,v194_2);
    const Space v194_10 = (has_head(v194_9) ? constant_2 : Space{});
    Space v194_12;
    if (!v194_10.empty()) {
      const Path v199_6 = concat_path(p0,v193_12_head);
      Space v199_11_result;
      for (int v199_11_label = 1; v199_11_label <= 2; ++v199_11_label) {
        const Space v199_11_tail = child(v193_12_tail,v199_11_label);
        if (v199_11_tail.empty()) continue;
        const Path v199_11_head{v199_11_label};
        const Space v200_2 = singleton(v199_11_head);
        const Space v200_3 = intersect(constant_1,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_2 : Space{});
        const Space v200_5 = subtract(constant_0,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_11_head);
          const Space v201_7 = routine_32(c, v201_6, v199_11_tail, s1);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_1,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_2 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_11_head);
          const Space v202_11 = routine_5(c, v202_6, v199_11_tail, s1);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_11_result = unite(v199_11_result,v200_13);
      }
      const Space v199_11 = std::move(v199_11_result);
      v194_12 = compose(v194_10,v199_11);
    }
    const Space v194_13 = unite(v194_8,v194_12);
    v193_12_result = unite(v193_12_result,v194_13);
  }
  const Space v193_12 = std::move(v193_12_result);
  return v193_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v203_7 = unwrap(s1,constant_4);
  const Space v203_9 = unwrap(s1,constant_5);
  const Space v203_10 = unwrap(v203_9,p0);
  const Space v203_12 = unwrap(s1,constant_6);
  Space v203_22_result;
  for (int v203_22_label = 1; v203_22_label <= 2; ++v203_22_label) {
    const Space v203_22_tail = child(s0,v203_22_label);
    if (v203_22_tail.empty()) continue;
    const Path v203_22_head{v203_22_label};
    const Space v204_2 = singleton(v203_22_head);
    const Space v204_3 = intersect(constant_1,v204_2);
    const Space v204_4 = (has_head(v204_3) ? constant_2 : Space{});
    const Space v204_5 = subtract(constant_0,v204_4);
    Space v204_8;
    if (!v204_5.empty()) {
      const Path v205_6 = concat_path(p0,v203_22_head);
      Space v205_7_result;
      for (int v205_7_label = 1; v205_7_label <= 2; ++v205_7_label) {
        const Space v205_7_tail = child(v203_22_tail,v205_7_label);
        if (v205_7_tail.empty()) continue;
        const Path v205_7_head{v205_7_label};
        const Space v206_2 = singleton(v205_7_head);
        const Space v206_3 = intersect(constant_1,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_2 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_7_head);
          const Space v207_7 = routine_32(c, v207_6, v205_7_tail, s1);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_1,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_2 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_7_head);
          const Space v208_11 = routine_33(c, v208_6, v205_7_tail, s1);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_7_result = unite(v205_7_result,v206_13);
      }
      const Space v205_7 = std::move(v205_7_result);
      v204_8 = compose(v204_5,v205_7);
    }
    const Space v204_9 = intersect(constant_1,v204_2);
    const Space v204_10 = (has_head(v204_9) ? constant_2 : Space{});
    Space v204_18;
    if (!v204_10.empty()) {
      const Space v209_11 = unwrap(v203_10,v203_22_head);
      const Space v209_12 = restrict_to(v203_9,v209_11);
      Space v209_13_result;
      for (int v209_13_label = 1; v209_13_label <= 2; ++v209_13_label) {
        const Space v209_13_tail = child(v209_12,v209_13_label);
        if (v209_13_tail.empty()) continue;
        const Path v209_13_head{v209_13_label};
        const Space v210_2 = singleton(v209_13_head);
        const Space v210_3 = intersect(constant_1,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_2 : Space{});
        const Space v210_5 = subtract(constant_0,v210_4);
        Space v210_7;
        if (!v210_5.empty()) {
          const Space v211_6 = routine_6(c, v209_13_head, v209_13_tail);
          v210_7 = compose(v210_5,v211_6);
        }
        const Space v210_8 = intersect(constant_1,v210_2);
        const Space v210_9 = (has_head(v210_8) ? constant_2 : Space{});
        Space v210_11;
        if (!v210_9.empty()) {
          const Space v212_10 = routine_7(c, v209_13_head, v209_13_tail);
          v210_11 = compose(v210_9,v212_10);
        }
        const Space v210_12 = unite(v210_7,v210_11);
        v209_13_result = unite(v209_13_result,v210_12);
      }
      const Space v209_13 = std::move(v209_13_result);
      const Space v209_14 = restrict_to(v203_7,v209_13);
      Space v209_15_result;
      for (int v209_15_label = 1; v209_15_label <= 2; ++v209_15_label) {
        const Space v209_15_tail = child(v209_14,v209_15_label);
        if (v209_15_tail.empty()) continue;
        const Path v209_15_head{v209_15_label};
        const Space v213_2 = singleton(v209_15_head);
        const Space v213_3 = intersect(constant_1,v213_2);
        const Space v213_4 = (has_head(v213_3) ? constant_2 : Space{});
        const Space v213_5 = subtract(constant_0,v213_4);
        Space v213_7;
        if (!v213_5.empty()) {
          const Space v214_6 = routine_8(c, v209_15_head, v209_15_tail);
          v213_7 = compose(v213_5,v214_6);
        }
        const Space v213_8 = intersect(constant_1,v213_2);
        const Space v213_9 = (has_head(v213_8) ? constant_2 : Space{});
        Space v213_11;
        if (!v213_9.empty()) {
          const Space v215_10 = routine_9(c, v209_15_head, v209_15_tail);
          v213_11 = compose(v213_9,v215_10);
        }
        const Space v213_12 = unite(v213_7,v213_11);
        v209_15_result = unite(v209_15_result,v213_12);
      }
      const Space v209_15 = std::move(v209_15_result);
      const Space v209_16 = subtract(v209_15,v209_11);
      const Space v209_17 = intersect(v209_16,v203_12);
      v204_18 = compose(v204_10,v209_17);
    }
    const Path v216_6 = concat_path(p0,v203_22_head);
    const Space v204_19 = wrap(v204_18,v216_6);
    const Space v204_20 = unite(v204_8,v204_19);
    v203_22_result = unite(v203_22_result,v204_20);
  }
  const Space v203_22 = std::move(v203_22_result);
  return v203_22;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v217_11_result;
  for (int v217_11_label = 1; v217_11_label <= 2; ++v217_11_label) {
    const Space v217_11_tail = child(s0,v217_11_label);
    if (v217_11_tail.empty()) continue;
    const Path v217_11_head{v217_11_label};
    const Space v218_2 = singleton(v217_11_head);
    const Space v218_3 = intersect(constant_1,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_2 : Space{});
    const Space v218_5 = subtract(constant_0,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_11_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_11_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_1,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_2 : Space{});
        const Space v220_5 = subtract(constant_0,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_34(c, v221_6, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_1,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_2 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_35(c, v222_6, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_1,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_2 : Space{});
    Space v218_12;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_11_head);
      Space v223_11_result;
      for (int v223_11_label = 1; v223_11_label <= 2; ++v223_11_label) {
        const Space v223_11_tail = child(v217_11_tail,v223_11_label);
        if (v223_11_tail.empty()) continue;
        const Path v223_11_head{v223_11_label};
        const Space v224_2 = singleton(v223_11_head);
        const Space v224_3 = intersect(constant_1,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_2 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_11_head);
          const Space v225_7 = routine_34(c, v225_6, v223_11_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_1,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_2 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_11_head);
          const Space v226_11 = routine_14(c, v226_6, v223_11_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_11_result = unite(v223_11_result,v224_13);
      }
      const Space v223_11 = std::move(v223_11_result);
      v218_12 = compose(v218_10,v223_11);
    }
    const Space v218_13 = unite(v218_8,v218_12);
    v217_11_result = unite(v217_11_result,v218_13);
  }
  const Space v217_11 = std::move(v217_11_result);
  return v217_11;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v227_8_result;
  for (int v227_8_label = 1; v227_8_label <= 2; ++v227_8_label) {
    const Space v227_8_tail = child(s0,v227_8_label);
    if (v227_8_tail.empty()) continue;
    const Path v227_8_head{v227_8_label};
    const Space v228_2 = singleton(v227_8_head);
    const Space v228_3 = intersect(constant_1,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_2 : Space{});
    const Space v228_5 = subtract(constant_0,v228_4);
    Space v228_8;
    if (!v228_5.empty()) {
      const Path v229_6 = concat_path(p0,v227_8_head);
      Space v229_7_result;
      for (int v229_7_label = 1; v229_7_label <= 2; ++v229_7_label) {
        const Space v229_7_tail = child(v227_8_tail,v229_7_label);
        if (v229_7_tail.empty()) continue;
        const Path v229_7_head{v229_7_label};
        const Space v230_2 = singleton(v229_7_head);
        const Space v230_3 = intersect(constant_1,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_2 : Space{});
        const Space v230_5 = subtract(constant_0,v230_4);
        Space v230_8;
        if (!v230_5.empty()) {
          const Path v231_6 = concat_path(v229_6,v229_7_head);
          const Space v231_7 = routine_34(c, v231_6, v229_7_tail);
          v230_8 = compose(v230_5,v231_7);
        }
        const Space v230_9 = intersect(constant_1,v230_2);
        const Space v230_10 = (has_head(v230_9) ? constant_2 : Space{});
        Space v230_12;
        if (!v230_10.empty()) {
          const Path v232_6 = concat_path(v229_6,v229_7_head);
          const Space v232_11 = routine_35(c, v232_6, v229_7_tail);
          v230_12 = compose(v230_10,v232_11);
        }
        const Space v230_13 = unite(v230_8,v230_12);
        v229_7_result = unite(v229_7_result,v230_13);
      }
      const Space v229_7 = std::move(v229_7_result);
      v228_8 = compose(v228_5,v229_7);
    }
    const Space v228_9 = intersect(constant_1,v228_2);
    const Space v228_10 = (has_head(v228_9) ? constant_2 : Space{});
    const Space v228_11 = compose(v228_10,v227_8_tail);
    const Space v228_12 = unite(v228_8,v228_11);
    v227_8_result = unite(v227_8_result,v228_12);
  }
  const Space v227_8 = std::move(v227_8_result);
  return v227_8;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v233_11_result;
  for (int v233_11_label = 1; v233_11_label <= 2; ++v233_11_label) {
    const Space v233_11_tail = child(s0,v233_11_label);
    if (v233_11_tail.empty()) continue;
    const Path v233_11_head{v233_11_label};
    const Space v234_2 = singleton(v233_11_head);
    const Space v234_3 = intersect(constant_1,v234_2);
    const Space v234_4 = (has_head(v234_3) ? constant_2 : Space{});
    const Space v234_5 = subtract(constant_0,v234_4);
    Space v234_8;
    if (!v234_5.empty()) {
      const Path v235_6 = concat_path(p0,v233_11_head);
      Space v235_7_result;
      for (int v235_7_label = 1; v235_7_label <= 2; ++v235_7_label) {
        const Space v235_7_tail = child(v233_11_tail,v235_7_label);
        if (v235_7_tail.empty()) continue;
        const Path v235_7_head{v235_7_label};
        const Space v236_2 = singleton(v235_7_head);
        const Space v236_3 = intersect(constant_1,v236_2);
        const Space v236_4 = (has_head(v236_3) ? constant_2 : Space{});
        const Space v236_5 = subtract(constant_0,v236_4);
        Space v236_8;
        if (!v236_5.empty()) {
          const Path v237_6 = concat_path(v235_6,v235_7_head);
          const Space v237_7 = routine_36(c, v237_6, v235_7_tail);
          v236_8 = compose(v236_5,v237_7);
        }
        const Space v236_9 = intersect(constant_1,v236_2);
        const Space v236_10 = (has_head(v236_9) ? constant_2 : Space{});
        Space v236_12;
        if (!v236_10.empty()) {
          const Path v238_6 = concat_path(v235_6,v235_7_head);
          const Space v238_11 = routine_37(c, v238_6, v235_7_tail);
          v236_12 = compose(v236_10,v238_11);
        }
        const Space v236_13 = unite(v236_8,v236_12);
        v235_7_result = unite(v235_7_result,v236_13);
      }
      const Space v235_7 = std::move(v235_7_result);
      v234_8 = compose(v234_5,v235_7);
    }
    const Space v234_9 = intersect(constant_1,v234_2);
    const Space v234_10 = (has_head(v234_9) ? constant_2 : Space{});
    Space v234_12;
    if (!v234_10.empty()) {
      const Path v239_6 = concat_path(p0,v233_11_head);
      Space v239_11_result;
      for (int v239_11_label = 1; v239_11_label <= 2; ++v239_11_label) {
        const Space v239_11_tail = child(v233_11_tail,v239_11_label);
        if (v239_11_tail.empty()) continue;
        const Path v239_11_head{v239_11_label};
        const Space v240_2 = singleton(v239_11_head);
        const Space v240_3 = intersect(constant_1,v240_2);
        const Space v240_4 = (has_head(v240_3) ? constant_2 : Space{});
        const Space v240_5 = subtract(constant_0,v240_4);
        Space v240_8;
        if (!v240_5.empty()) {
          const Path v241_6 = concat_path(v239_6,v239_11_head);
          const Space v241_7 = routine_36(c, v241_6, v239_11_tail);
          v240_8 = compose(v240_5,v241_7);
        }
        const Space v240_9 = intersect(constant_1,v240_2);
        const Space v240_10 = (has_head(v240_9) ? constant_2 : Space{});
        Space v240_12;
        if (!v240_10.empty()) {
          const Path v242_6 = concat_path(v239_6,v239_11_head);
          const Space v242_11 = routine_17(c, v242_6, v239_11_tail);
          v240_12 = compose(v240_10,v242_11);
        }
        const Space v240_13 = unite(v240_8,v240_12);
        v239_11_result = unite(v239_11_result,v240_13);
      }
      const Space v239_11 = std::move(v239_11_result);
      v234_12 = compose(v234_10,v239_11);
    }
    const Space v234_13 = unite(v234_8,v234_12);
    v233_11_result = unite(v233_11_result,v234_13);
  }
  const Space v233_11 = std::move(v233_11_result);
  return v233_11;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v243_8_result;
  for (int v243_8_label = 1; v243_8_label <= 2; ++v243_8_label) {
    const Space v243_8_tail = child(s0,v243_8_label);
    if (v243_8_tail.empty()) continue;
    const Path v243_8_head{v243_8_label};
    const Space v244_2 = singleton(v243_8_head);
    const Space v244_3 = intersect(constant_1,v244_2);
    const Space v244_4 = (has_head(v244_3) ? constant_2 : Space{});
    const Space v244_5 = subtract(constant_0,v244_4);
    Space v244_8;
    if (!v244_5.empty()) {
      const Path v245_6 = concat_path(p0,v243_8_head);
      Space v245_7_result;
      for (int v245_7_label = 1; v245_7_label <= 2; ++v245_7_label) {
        const Space v245_7_tail = child(v243_8_tail,v245_7_label);
        if (v245_7_tail.empty()) continue;
        const Path v245_7_head{v245_7_label};
        const Space v246_2 = singleton(v245_7_head);
        const Space v246_3 = intersect(constant_1,v246_2);
        const Space v246_4 = (has_head(v246_3) ? constant_2 : Space{});
        const Space v246_5 = subtract(constant_0,v246_4);
        Space v246_8;
        if (!v246_5.empty()) {
          const Path v247_6 = concat_path(v245_6,v245_7_head);
          const Space v247_7 = routine_36(c, v247_6, v245_7_tail);
          v246_8 = compose(v246_5,v247_7);
        }
        const Space v246_9 = intersect(constant_1,v246_2);
        const Space v246_10 = (has_head(v246_9) ? constant_2 : Space{});
        Space v246_12;
        if (!v246_10.empty()) {
          const Path v248_6 = concat_path(v245_6,v245_7_head);
          const Space v248_11 = routine_37(c, v248_6, v245_7_tail);
          v246_12 = compose(v246_10,v248_11);
        }
        const Space v246_13 = unite(v246_8,v246_12);
        v245_7_result = unite(v245_7_result,v246_13);
      }
      const Space v245_7 = std::move(v245_7_result);
      v244_8 = compose(v244_5,v245_7);
    }
    const Space v244_9 = intersect(constant_1,v244_2);
    const Space v244_10 = (has_head(v244_9) ? constant_2 : Space{});
    const Space v244_11 = compose(v244_10,v243_8_tail);
    const Space v244_12 = unite(v244_8,v244_11);
    v243_8_result = unite(v243_8_result,v244_12);
  }
  const Space v243_8 = std::move(v243_8_result);
  return v243_8;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v249_11_result;
  for (int v249_11_label = 1; v249_11_label <= 2; ++v249_11_label) {
    const Space v249_11_tail = child(s0,v249_11_label);
    if (v249_11_tail.empty()) continue;
    const Path v249_11_head{v249_11_label};
    const Space v250_2 = singleton(v249_11_head);
    const Space v250_3 = intersect(constant_1,v250_2);
    const Space v250_4 = (has_head(v250_3) ? constant_2 : Space{});
    const Space v250_5 = subtract(constant_0,v250_4);
    Space v250_8;
    if (!v250_5.empty()) {
      const Path v251_6 = concat_path(p0,v249_11_head);
      Space v251_7_result;
      for (int v251_7_label = 1; v251_7_label <= 2; ++v251_7_label) {
        const Space v251_7_tail = child(v249_11_tail,v251_7_label);
        if (v251_7_tail.empty()) continue;
        const Path v251_7_head{v251_7_label};
        const Space v252_2 = singleton(v251_7_head);
        const Space v252_3 = intersect(constant_1,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_2 : Space{});
        const Space v252_5 = subtract(constant_0,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_7_head);
          const Space v253_7 = routine_38(c, v253_6, v251_7_tail);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_1,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_2 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_7_head);
          const Space v254_11 = routine_39(c, v254_6, v251_7_tail);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_7_result = unite(v251_7_result,v252_13);
      }
      const Space v251_7 = std::move(v251_7_result);
      v250_8 = compose(v250_5,v251_7);
    }
    const Space v250_9 = intersect(constant_1,v250_2);
    const Space v250_10 = (has_head(v250_9) ? constant_2 : Space{});
    Space v250_12;
    if (!v250_10.empty()) {
      const Path v255_6 = concat_path(p0,v249_11_head);
      Space v255_11_result;
      for (int v255_11_label = 1; v255_11_label <= 2; ++v255_11_label) {
        const Space v255_11_tail = child(v249_11_tail,v255_11_label);
        if (v255_11_tail.empty()) continue;
        const Path v255_11_head{v255_11_label};
        const Space v256_2 = singleton(v255_11_head);
        const Space v256_3 = intersect(constant_1,v256_2);
        const Space v256_4 = (has_head(v256_3) ? constant_2 : Space{});
        const Space v256_5 = subtract(constant_0,v256_4);
        Space v256_8;
        if (!v256_5.empty()) {
          const Path v257_6 = concat_path(v255_6,v255_11_head);
          const Space v257_7 = routine_38(c, v257_6, v255_11_tail);
          v256_8 = compose(v256_5,v257_7);
        }
        const Space v256_9 = intersect(constant_1,v256_2);
        const Space v256_10 = (has_head(v256_9) ? constant_2 : Space{});
        Space v256_12;
        if (!v256_10.empty()) {
          const Path v258_6 = concat_path(v255_6,v255_11_head);
          const Space v258_11 = routine_14(c, v258_6, v255_11_tail);
          v256_12 = compose(v256_10,v258_11);
        }
        const Space v256_13 = unite(v256_8,v256_12);
        v255_11_result = unite(v255_11_result,v256_13);
      }
      const Space v255_11 = std::move(v255_11_result);
      v250_12 = compose(v250_10,v255_11);
    }
    const Space v250_13 = unite(v250_8,v250_12);
    v249_11_result = unite(v249_11_result,v250_13);
  }
  const Space v249_11 = std::move(v249_11_result);
  return v249_11;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v259_8_result;
  for (int v259_8_label = 1; v259_8_label <= 2; ++v259_8_label) {
    const Space v259_8_tail = child(s0,v259_8_label);
    if (v259_8_tail.empty()) continue;
    const Path v259_8_head{v259_8_label};
    const Space v260_2 = singleton(v259_8_head);
    const Space v260_3 = intersect(constant_1,v260_2);
    const Space v260_4 = (has_head(v260_3) ? constant_2 : Space{});
    const Space v260_5 = subtract(constant_0,v260_4);
    Space v260_8;
    if (!v260_5.empty()) {
      const Path v261_6 = concat_path(p0,v259_8_head);
      Space v261_7_result;
      for (int v261_7_label = 1; v261_7_label <= 2; ++v261_7_label) {
        const Space v261_7_tail = child(v259_8_tail,v261_7_label);
        if (v261_7_tail.empty()) continue;
        const Path v261_7_head{v261_7_label};
        const Space v262_2 = singleton(v261_7_head);
        const Space v262_3 = intersect(constant_1,v262_2);
        const Space v262_4 = (has_head(v262_3) ? constant_2 : Space{});
        const Space v262_5 = subtract(constant_0,v262_4);
        Space v262_8;
        if (!v262_5.empty()) {
          const Path v263_6 = concat_path(v261_6,v261_7_head);
          const Space v263_7 = routine_38(c, v263_6, v261_7_tail);
          v262_8 = compose(v262_5,v263_7);
        }
        const Space v262_9 = intersect(constant_1,v262_2);
        const Space v262_10 = (has_head(v262_9) ? constant_2 : Space{});
        Space v262_12;
        if (!v262_10.empty()) {
          const Path v264_6 = concat_path(v261_6,v261_7_head);
          const Space v264_11 = routine_39(c, v264_6, v261_7_tail);
          v262_12 = compose(v262_10,v264_11);
        }
        const Space v262_13 = unite(v262_8,v262_12);
        v261_7_result = unite(v261_7_result,v262_13);
      }
      const Space v261_7 = std::move(v261_7_result);
      v260_8 = compose(v260_5,v261_7);
    }
    const Space v260_9 = intersect(constant_1,v260_2);
    const Space v260_10 = (has_head(v260_9) ? constant_2 : Space{});
    const Space v260_11 = compose(v260_10,v259_8_tail);
    const Space v260_12 = unite(v260_8,v260_11);
    v259_8_result = unite(v259_8_result,v260_12);
  }
  const Space v259_8 = std::move(v259_8_result);
  return v259_8;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v265_11_result;
  for (int v265_11_label = 1; v265_11_label <= 2; ++v265_11_label) {
    const Space v265_11_tail = child(s0,v265_11_label);
    if (v265_11_tail.empty()) continue;
    const Path v265_11_head{v265_11_label};
    const Space v266_2 = singleton(v265_11_head);
    const Space v266_3 = intersect(constant_1,v266_2);
    const Space v266_4 = (has_head(v266_3) ? constant_2 : Space{});
    const Space v266_5 = subtract(constant_0,v266_4);
    Space v266_8;
    if (!v266_5.empty()) {
      const Path v267_6 = concat_path(p0,v265_11_head);
      Space v267_7_result;
      for (int v267_7_label = 1; v267_7_label <= 2; ++v267_7_label) {
        const Space v267_7_tail = child(v265_11_tail,v267_7_label);
        if (v267_7_tail.empty()) continue;
        const Path v267_7_head{v267_7_label};
        const Space v268_2 = singleton(v267_7_head);
        const Space v268_3 = intersect(constant_1,v268_2);
        const Space v268_4 = (has_head(v268_3) ? constant_2 : Space{});
        const Space v268_5 = subtract(constant_0,v268_4);
        Space v268_8;
        if (!v268_5.empty()) {
          const Path v269_6 = concat_path(v267_6,v267_7_head);
          const Space v269_7 = routine_40(c, v269_6, v267_7_tail);
          v268_8 = compose(v268_5,v269_7);
        }
        const Space v268_9 = intersect(constant_1,v268_2);
        const Space v268_10 = (has_head(v268_9) ? constant_2 : Space{});
        Space v268_12;
        if (!v268_10.empty()) {
          const Path v270_6 = concat_path(v267_6,v267_7_head);
          const Space v270_11 = routine_41(c, v270_6, v267_7_tail);
          v268_12 = compose(v268_10,v270_11);
        }
        const Space v268_13 = unite(v268_8,v268_12);
        v267_7_result = unite(v267_7_result,v268_13);
      }
      const Space v267_7 = std::move(v267_7_result);
      v266_8 = compose(v266_5,v267_7);
    }
    const Space v266_9 = intersect(constant_1,v266_2);
    const Space v266_10 = (has_head(v266_9) ? constant_2 : Space{});
    Space v266_12;
    if (!v266_10.empty()) {
      const Path v271_6 = concat_path(p0,v265_11_head);
      Space v271_11_result;
      for (int v271_11_label = 1; v271_11_label <= 2; ++v271_11_label) {
        const Space v271_11_tail = child(v265_11_tail,v271_11_label);
        if (v271_11_tail.empty()) continue;
        const Path v271_11_head{v271_11_label};
        const Space v272_2 = singleton(v271_11_head);
        const Space v272_3 = intersect(constant_1,v272_2);
        const Space v272_4 = (has_head(v272_3) ? constant_2 : Space{});
        const Space v272_5 = subtract(constant_0,v272_4);
        Space v272_8;
        if (!v272_5.empty()) {
          const Path v273_6 = concat_path(v271_6,v271_11_head);
          const Space v273_7 = routine_40(c, v273_6, v271_11_tail);
          v272_8 = compose(v272_5,v273_7);
        }
        const Space v272_9 = intersect(constant_1,v272_2);
        const Space v272_10 = (has_head(v272_9) ? constant_2 : Space{});
        Space v272_12;
        if (!v272_10.empty()) {
          const Path v274_6 = concat_path(v271_6,v271_11_head);
          const Space v274_11 = routine_17(c, v274_6, v271_11_tail);
          v272_12 = compose(v272_10,v274_11);
        }
        const Space v272_13 = unite(v272_8,v272_12);
        v271_11_result = unite(v271_11_result,v272_13);
      }
      const Space v271_11 = std::move(v271_11_result);
      v266_12 = compose(v266_10,v271_11);
    }
    const Space v266_13 = unite(v266_8,v266_12);
    v265_11_result = unite(v265_11_result,v266_13);
  }
  const Space v265_11 = std::move(v265_11_result);
  return v265_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v275_8_result;
  for (int v275_8_label = 1; v275_8_label <= 2; ++v275_8_label) {
    const Space v275_8_tail = child(s0,v275_8_label);
    if (v275_8_tail.empty()) continue;
    const Path v275_8_head{v275_8_label};
    const Space v276_2 = singleton(v275_8_head);
    const Space v276_3 = intersect(constant_1,v276_2);
    const Space v276_4 = (has_head(v276_3) ? constant_2 : Space{});
    const Space v276_5 = subtract(constant_0,v276_4);
    Space v276_8;
    if (!v276_5.empty()) {
      const Path v277_6 = concat_path(p0,v275_8_head);
      Space v277_7_result;
      for (int v277_7_label = 1; v277_7_label <= 2; ++v277_7_label) {
        const Space v277_7_tail = child(v275_8_tail,v277_7_label);
        if (v277_7_tail.empty()) continue;
        const Path v277_7_head{v277_7_label};
        const Space v278_2 = singleton(v277_7_head);
        const Space v278_3 = intersect(constant_1,v278_2);
        const Space v278_4 = (has_head(v278_3) ? constant_2 : Space{});
        const Space v278_5 = subtract(constant_0,v278_4);
        Space v278_8;
        if (!v278_5.empty()) {
          const Path v279_6 = concat_path(v277_6,v277_7_head);
          const Space v279_7 = routine_40(c, v279_6, v277_7_tail);
          v278_8 = compose(v278_5,v279_7);
        }
        const Space v278_9 = intersect(constant_1,v278_2);
        const Space v278_10 = (has_head(v278_9) ? constant_2 : Space{});
        Space v278_12;
        if (!v278_10.empty()) {
          const Path v280_6 = concat_path(v277_6,v277_7_head);
          const Space v280_11 = routine_41(c, v280_6, v277_7_tail);
          v278_12 = compose(v278_10,v280_11);
        }
        const Space v278_13 = unite(v278_8,v278_12);
        v277_7_result = unite(v277_7_result,v278_13);
      }
      const Space v277_7 = std::move(v277_7_result);
      v276_8 = compose(v276_5,v277_7);
    }
    const Space v276_9 = intersect(constant_1,v276_2);
    const Space v276_10 = (has_head(v276_9) ? constant_2 : Space{});
    const Space v276_11 = compose(v276_10,v275_8_tail);
    const Space v276_12 = unite(v276_8,v276_11);
    v275_8_result = unite(v275_8_result,v276_12);
  }
  const Space v275_8 = std::move(v275_8_result);
  return v275_8;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v281_3_result;
  for (int v281_3_label = 1; v281_3_label <= 2; ++v281_3_label) {
    const Space v281_3_tail = child(s0,v281_3_label);
    if (v281_3_tail.empty()) continue;
    const Path v281_3_head{v281_3_label};
    const Space v282_2 = Space{};
    v281_3_result = unite(v281_3_result,v282_2);
  }
  const Space v281_3 = std::move(v281_3_result);
  return v281_3;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v283_5 = unwrap(s1,constant_4);
  const Space v283_7 = unwrap(s1,constant_5);
  const Space v283_8 = unwrap(v283_7,p0);
  const Space v283_10 = unwrap(s1,constant_6);
  Space v283_17_result;
  for (int v283_17_label = 1; v283_17_label <= 2; ++v283_17_label) {
    const Space v283_17_tail = child(s0,v283_17_label);
    if (v283_17_tail.empty()) continue;
    const Path v283_17_head{v283_17_label};
    const Space v284_2 = singleton(v283_17_head);
    const Space v284_3 = intersect(constant_1,v284_2);
    const Space v284_4 = (has_head(v284_3) ? constant_2 : Space{});
    Space v284_12;
    if (!v284_4.empty()) {
      const Space v285_5 = unwrap(v283_8,v283_17_head);
      const Space v285_6 = restrict_to(v283_7,v285_5);
      Space v285_7_result;
      for (int v285_7_label = 1; v285_7_label <= 2; ++v285_7_label) {
        const Space v285_7_tail = child(v285_6,v285_7_label);
        if (v285_7_tail.empty()) continue;
        const Path v285_7_head{v285_7_label};
        const Space v286_2 = singleton(v285_7_head);
        const Space v286_3 = intersect(constant_1,v286_2);
        const Space v286_4 = (has_head(v286_3) ? constant_2 : Space{});
        const Space v286_5 = subtract(constant_0,v286_4);
        Space v286_7;
        if (!v286_5.empty()) {
          const Space v287_6 = routine_6(c, v285_7_head, v285_7_tail);
          v286_7 = compose(v286_5,v287_6);
        }
        const Space v286_8 = intersect(constant_1,v286_2);
        const Space v286_9 = (has_head(v286_8) ? constant_2 : Space{});
        Space v286_11;
        if (!v286_9.empty()) {
          const Space v288_10 = routine_7(c, v285_7_head, v285_7_tail);
          v286_11 = compose(v286_9,v288_10);
        }
        const Space v286_12 = unite(v286_7,v286_11);
        v285_7_result = unite(v285_7_result,v286_12);
      }
      const Space v285_7 = std::move(v285_7_result);
      const Space v285_8 = restrict_to(v283_5,v285_7);
      Space v285_9_result;
      for (int v285_9_label = 1; v285_9_label <= 2; ++v285_9_label) {
        const Space v285_9_tail = child(v285_8,v285_9_label);
        if (v285_9_tail.empty()) continue;
        const Path v285_9_head{v285_9_label};
        const Space v289_2 = singleton(v285_9_head);
        const Space v289_3 = intersect(constant_1,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_2 : Space{});
        const Space v289_5 = subtract(constant_0,v289_4);
        Space v289_7;
        if (!v289_5.empty()) {
          const Space v290_6 = routine_8(c, v285_9_head, v285_9_tail);
          v289_7 = compose(v289_5,v290_6);
        }
        const Space v289_8 = intersect(constant_1,v289_2);
        const Space v289_9 = (has_head(v289_8) ? constant_2 : Space{});
        Space v289_11;
        if (!v289_9.empty()) {
          const Space v291_10 = routine_9(c, v285_9_head, v285_9_tail);
          v289_11 = compose(v289_9,v291_10);
        }
        const Space v289_12 = unite(v289_7,v289_11);
        v285_9_result = unite(v285_9_result,v289_12);
      }
      const Space v285_9 = std::move(v285_9_result);
      const Space v285_10 = subtract(v285_9,v285_5);
      const Space v285_11 = intersect(v285_10,v283_10);
      v284_12 = compose(v284_4,v285_11);
    }
    const Path v284_13 = concat_path(p0,v283_17_head);
    const Space v284_14 = wrap(v284_12,v284_13);
    v283_17_result = unite(v283_17_result,v284_14);
  }
  const Space v283_17 = std::move(v283_17_result);
  return v283_17;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  Space v292_11_result;
  for (int v292_11_label = 1; v292_11_label <= 2; ++v292_11_label) {
    const Space v292_11_tail = child(s0,v292_11_label);
    if (v292_11_tail.empty()) continue;
    const Path v292_11_head{v292_11_label};
    const Space v293_2 = singleton(v292_11_head);
    const Space v293_3 = intersect(constant_1,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_2 : Space{});
    const Space v293_5 = subtract(constant_0,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_11_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_11_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_1,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_2 : Space{});
        const Space v295_5 = subtract(constant_0,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_42(c, v296_6, v294_7_tail);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_1,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_2 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_43(c, v297_6, v294_7_tail);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_1,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_2 : Space{});
    Space v293_12;
    if (!v293_10.empty()) {
      const Path v298_6 = concat_path(p0,v292_11_head);
      Space v298_11_result;
      for (int v298_11_label = 1; v298_11_label <= 2; ++v298_11_label) {
        const Space v298_11_tail = child(v292_11_tail,v298_11_label);
        if (v298_11_tail.empty()) continue;
        const Path v298_11_head{v298_11_label};
        const Space v299_2 = singleton(v298_11_head);
        const Space v299_3 = intersect(constant_1,v299_2);
        const Space v299_4 = (has_head(v299_3) ? constant_2 : Space{});
        const Space v299_5 = subtract(constant_0,v299_4);
        Space v299_8;
        if (!v299_5.empty()) {
          const Path v300_6 = concat_path(v298_6,v298_11_head);
          const Space v300_7 = routine_42(c, v300_6, v298_11_tail);
          v299_8 = compose(v299_5,v300_7);
        }
        const Space v299_9 = intersect(constant_1,v299_2);
        const Space v299_10 = (has_head(v299_9) ? constant_2 : Space{});
        Space v299_12;
        if (!v299_10.empty()) {
          const Path v301_6 = concat_path(v298_6,v298_11_head);
          const Space v301_11 = routine_14(c, v301_6, v298_11_tail);
          v299_12 = compose(v299_10,v301_11);
        }
        const Space v299_13 = unite(v299_8,v299_12);
        v298_11_result = unite(v298_11_result,v299_13);
      }
      const Space v298_11 = std::move(v298_11_result);
      v293_12 = compose(v293_10,v298_11);
    }
    const Space v293_13 = unite(v293_8,v293_12);
    v292_11_result = unite(v292_11_result,v293_13);
  }
  const Space v292_11 = std::move(v292_11_result);
  return v292_11;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  Space v302_8_result;
  for (int v302_8_label = 1; v302_8_label <= 2; ++v302_8_label) {
    const Space v302_8_tail = child(s0,v302_8_label);
    if (v302_8_tail.empty()) continue;
    const Path v302_8_head{v302_8_label};
    const Space v303_2 = singleton(v302_8_head);
    const Space v303_3 = intersect(constant_1,v303_2);
    const Space v303_4 = (has_head(v303_3) ? constant_2 : Space{});
    const Space v303_5 = subtract(constant_0,v303_4);
    Space v303_8;
    if (!v303_5.empty()) {
      const Path v304_6 = concat_path(p0,v302_8_head);
      Space v304_7_result;
      for (int v304_7_label = 1; v304_7_label <= 2; ++v304_7_label) {
        const Space v304_7_tail = child(v302_8_tail,v304_7_label);
        if (v304_7_tail.empty()) continue;
        const Path v304_7_head{v304_7_label};
        const Space v305_2 = singleton(v304_7_head);
        const Space v305_3 = intersect(constant_1,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_2 : Space{});
        const Space v305_5 = subtract(constant_0,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v304_6,v304_7_head);
          const Space v306_7 = routine_42(c, v306_6, v304_7_tail);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_1,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_2 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v304_6,v304_7_head);
          const Space v307_11 = routine_43(c, v307_6, v304_7_tail);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_7_result = unite(v304_7_result,v305_13);
      }
      const Space v304_7 = std::move(v304_7_result);
      v303_8 = compose(v303_5,v304_7);
    }
    const Space v303_9 = intersect(constant_1,v303_2);
    const Space v303_10 = (has_head(v303_9) ? constant_2 : Space{});
    const Space v303_11 = compose(v303_10,v302_8_tail);
    const Space v303_12 = unite(v303_8,v303_11);
    v302_8_result = unite(v302_8_result,v303_12);
  }
  const Space v302_8 = std::move(v302_8_result);
  return v302_8;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  Space v308_11_result;
  for (int v308_11_label = 1; v308_11_label <= 2; ++v308_11_label) {
    const Space v308_11_tail = child(s0,v308_11_label);
    if (v308_11_tail.empty()) continue;
    const Path v308_11_head{v308_11_label};
    const Space v309_2 = singleton(v308_11_head);
    const Space v309_3 = intersect(constant_1,v309_2);
    const Space v309_4 = (has_head(v309_3) ? constant_2 : Space{});
    const Space v309_5 = subtract(constant_0,v309_4);
    Space v309_8;
    if (!v309_5.empty()) {
      const Path v310_6 = concat_path(p0,v308_11_head);
      Space v310_7_result;
      for (int v310_7_label = 1; v310_7_label <= 2; ++v310_7_label) {
        const Space v310_7_tail = child(v308_11_tail,v310_7_label);
        if (v310_7_tail.empty()) continue;
        const Path v310_7_head{v310_7_label};
        const Space v311_2 = singleton(v310_7_head);
        const Space v311_3 = intersect(constant_1,v311_2);
        const Space v311_4 = (has_head(v311_3) ? constant_2 : Space{});
        const Space v311_5 = subtract(constant_0,v311_4);
        Space v311_8;
        if (!v311_5.empty()) {
          const Path v312_6 = concat_path(v310_6,v310_7_head);
          const Space v312_7 = routine_44(c, v312_6, v310_7_tail);
          v311_8 = compose(v311_5,v312_7);
        }
        const Space v311_9 = intersect(constant_1,v311_2);
        const Space v311_10 = (has_head(v311_9) ? constant_2 : Space{});
        Space v311_12;
        if (!v311_10.empty()) {
          const Path v313_6 = concat_path(v310_6,v310_7_head);
          const Space v313_11 = routine_45(c, v313_6, v310_7_tail);
          v311_12 = compose(v311_10,v313_11);
        }
        const Space v311_13 = unite(v311_8,v311_12);
        v310_7_result = unite(v310_7_result,v311_13);
      }
      const Space v310_7 = std::move(v310_7_result);
      v309_8 = compose(v309_5,v310_7);
    }
    const Space v309_9 = intersect(constant_1,v309_2);
    const Space v309_10 = (has_head(v309_9) ? constant_2 : Space{});
    Space v309_12;
    if (!v309_10.empty()) {
      const Path v314_6 = concat_path(p0,v308_11_head);
      Space v314_11_result;
      for (int v314_11_label = 1; v314_11_label <= 2; ++v314_11_label) {
        const Space v314_11_tail = child(v308_11_tail,v314_11_label);
        if (v314_11_tail.empty()) continue;
        const Path v314_11_head{v314_11_label};
        const Space v315_2 = singleton(v314_11_head);
        const Space v315_3 = intersect(constant_1,v315_2);
        const Space v315_4 = (has_head(v315_3) ? constant_2 : Space{});
        const Space v315_5 = subtract(constant_0,v315_4);
        Space v315_8;
        if (!v315_5.empty()) {
          const Path v316_6 = concat_path(v314_6,v314_11_head);
          const Space v316_7 = routine_44(c, v316_6, v314_11_tail);
          v315_8 = compose(v315_5,v316_7);
        }
        const Space v315_9 = intersect(constant_1,v315_2);
        const Space v315_10 = (has_head(v315_9) ? constant_2 : Space{});
        Space v315_12;
        if (!v315_10.empty()) {
          const Path v317_6 = concat_path(v314_6,v314_11_head);
          const Space v317_11 = routine_17(c, v317_6, v314_11_tail);
          v315_12 = compose(v315_10,v317_11);
        }
        const Space v315_13 = unite(v315_8,v315_12);
        v314_11_result = unite(v314_11_result,v315_13);
      }
      const Space v314_11 = std::move(v314_11_result);
      v309_12 = compose(v309_10,v314_11);
    }
    const Space v309_13 = unite(v309_8,v309_12);
    v308_11_result = unite(v308_11_result,v309_13);
  }
  const Space v308_11 = std::move(v308_11_result);
  return v308_11;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v318_8_result;
  for (int v318_8_label = 1; v318_8_label <= 2; ++v318_8_label) {
    const Space v318_8_tail = child(s0,v318_8_label);
    if (v318_8_tail.empty()) continue;
    const Path v318_8_head{v318_8_label};
    const Space v319_2 = singleton(v318_8_head);
    const Space v319_3 = intersect(constant_1,v319_2);
    const Space v319_4 = (has_head(v319_3) ? constant_2 : Space{});
    const Space v319_5 = subtract(constant_0,v319_4);
    Space v319_8;
    if (!v319_5.empty()) {
      const Path v320_6 = concat_path(p0,v318_8_head);
      Space v320_7_result;
      for (int v320_7_label = 1; v320_7_label <= 2; ++v320_7_label) {
        const Space v320_7_tail = child(v318_8_tail,v320_7_label);
        if (v320_7_tail.empty()) continue;
        const Path v320_7_head{v320_7_label};
        const Space v321_2 = singleton(v320_7_head);
        const Space v321_3 = intersect(constant_1,v321_2);
        const Space v321_4 = (has_head(v321_3) ? constant_2 : Space{});
        const Space v321_5 = subtract(constant_0,v321_4);
        Space v321_8;
        if (!v321_5.empty()) {
          const Path v322_6 = concat_path(v320_6,v320_7_head);
          const Space v322_7 = routine_44(c, v322_6, v320_7_tail);
          v321_8 = compose(v321_5,v322_7);
        }
        const Space v321_9 = intersect(constant_1,v321_2);
        const Space v321_10 = (has_head(v321_9) ? constant_2 : Space{});
        Space v321_12;
        if (!v321_10.empty()) {
          const Path v323_6 = concat_path(v320_6,v320_7_head);
          const Space v323_11 = routine_45(c, v323_6, v320_7_tail);
          v321_12 = compose(v321_10,v323_11);
        }
        const Space v321_13 = unite(v321_8,v321_12);
        v320_7_result = unite(v320_7_result,v321_13);
      }
      const Space v320_7 = std::move(v320_7_result);
      v319_8 = compose(v319_5,v320_7);
    }
    const Space v319_9 = intersect(constant_1,v319_2);
    const Space v319_10 = (has_head(v319_9) ? constant_2 : Space{});
    const Space v319_11 = compose(v319_10,v318_8_tail);
    const Space v319_12 = unite(v319_8,v319_11);
    v318_8_result = unite(v318_8_result,v319_12);
  }
  const Space v318_8 = std::move(v318_8_result);
  return v318_8;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  Space v324_11_result;
  for (int v324_11_label = 1; v324_11_label <= 2; ++v324_11_label) {
    const Space v324_11_tail = child(s0,v324_11_label);
    if (v324_11_tail.empty()) continue;
    const Path v324_11_head{v324_11_label};
    const Space v325_2 = singleton(v324_11_head);
    const Space v325_3 = intersect(constant_1,v325_2);
    const Space v325_4 = (has_head(v325_3) ? constant_2 : Space{});
    const Space v325_5 = subtract(constant_0,v325_4);
    Space v325_8;
    if (!v325_5.empty()) {
      const Path v326_6 = concat_path(p0,v324_11_head);
      Space v326_7_result;
      for (int v326_7_label = 1; v326_7_label <= 2; ++v326_7_label) {
        const Space v326_7_tail = child(v324_11_tail,v326_7_label);
        if (v326_7_tail.empty()) continue;
        const Path v326_7_head{v326_7_label};
        const Space v327_2 = singleton(v326_7_head);
        const Space v327_3 = intersect(constant_1,v327_2);
        const Space v327_4 = (has_head(v327_3) ? constant_2 : Space{});
        const Space v327_5 = subtract(constant_0,v327_4);
        Space v327_8;
        if (!v327_5.empty()) {
          const Path v328_6 = concat_path(v326_6,v326_7_head);
          const Space v328_7 = routine_46(c, v328_6, v326_7_tail);
          v327_8 = compose(v327_5,v328_7);
        }
        const Space v327_9 = intersect(constant_1,v327_2);
        const Space v327_10 = (has_head(v327_9) ? constant_2 : Space{});
        Space v327_12;
        if (!v327_10.empty()) {
          const Path v329_6 = concat_path(v326_6,v326_7_head);
          const Space v329_11 = routine_47(c, v329_6, v326_7_tail);
          v327_12 = compose(v327_10,v329_11);
        }
        const Space v327_13 = unite(v327_8,v327_12);
        v326_7_result = unite(v326_7_result,v327_13);
      }
      const Space v326_7 = std::move(v326_7_result);
      v325_8 = compose(v325_5,v326_7);
    }
    const Space v325_9 = intersect(constant_1,v325_2);
    const Space v325_10 = (has_head(v325_9) ? constant_2 : Space{});
    Space v325_12;
    if (!v325_10.empty()) {
      const Path v330_6 = concat_path(p0,v324_11_head);
      Space v330_11_result;
      for (int v330_11_label = 1; v330_11_label <= 2; ++v330_11_label) {
        const Space v330_11_tail = child(v324_11_tail,v330_11_label);
        if (v330_11_tail.empty()) continue;
        const Path v330_11_head{v330_11_label};
        const Space v331_2 = singleton(v330_11_head);
        const Space v331_3 = intersect(constant_1,v331_2);
        const Space v331_4 = (has_head(v331_3) ? constant_2 : Space{});
        const Space v331_5 = subtract(constant_0,v331_4);
        Space v331_8;
        if (!v331_5.empty()) {
          const Path v332_6 = concat_path(v330_6,v330_11_head);
          const Space v332_7 = routine_46(c, v332_6, v330_11_tail);
          v331_8 = compose(v331_5,v332_7);
        }
        const Space v331_9 = intersect(constant_1,v331_2);
        const Space v331_10 = (has_head(v331_9) ? constant_2 : Space{});
        Space v331_12;
        if (!v331_10.empty()) {
          const Path v333_6 = concat_path(v330_6,v330_11_head);
          const Space v333_11 = routine_14(c, v333_6, v330_11_tail);
          v331_12 = compose(v331_10,v333_11);
        }
        const Space v331_13 = unite(v331_8,v331_12);
        v330_11_result = unite(v330_11_result,v331_13);
      }
      const Space v330_11 = std::move(v330_11_result);
      v325_12 = compose(v325_10,v330_11);
    }
    const Space v325_13 = unite(v325_8,v325_12);
    v324_11_result = unite(v324_11_result,v325_13);
  }
  const Space v324_11 = std::move(v324_11_result);
  return v324_11;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  Space v334_8_result;
  for (int v334_8_label = 1; v334_8_label <= 2; ++v334_8_label) {
    const Space v334_8_tail = child(s0,v334_8_label);
    if (v334_8_tail.empty()) continue;
    const Path v334_8_head{v334_8_label};
    const Space v335_2 = singleton(v334_8_head);
    const Space v335_3 = intersect(constant_1,v335_2);
    const Space v335_4 = (has_head(v335_3) ? constant_2 : Space{});
    const Space v335_5 = subtract(constant_0,v335_4);
    Space v335_8;
    if (!v335_5.empty()) {
      const Path v336_6 = concat_path(p0,v334_8_head);
      Space v336_7_result;
      for (int v336_7_label = 1; v336_7_label <= 2; ++v336_7_label) {
        const Space v336_7_tail = child(v334_8_tail,v336_7_label);
        if (v336_7_tail.empty()) continue;
        const Path v336_7_head{v336_7_label};
        const Space v337_2 = singleton(v336_7_head);
        const Space v337_3 = intersect(constant_1,v337_2);
        const Space v337_4 = (has_head(v337_3) ? constant_2 : Space{});
        const Space v337_5 = subtract(constant_0,v337_4);
        Space v337_8;
        if (!v337_5.empty()) {
          const Path v338_6 = concat_path(v336_6,v336_7_head);
          const Space v338_7 = routine_46(c, v338_6, v336_7_tail);
          v337_8 = compose(v337_5,v338_7);
        }
        const Space v337_9 = intersect(constant_1,v337_2);
        const Space v337_10 = (has_head(v337_9) ? constant_2 : Space{});
        Space v337_12;
        if (!v337_10.empty()) {
          const Path v339_6 = concat_path(v336_6,v336_7_head);
          const Space v339_11 = routine_47(c, v339_6, v336_7_tail);
          v337_12 = compose(v337_10,v339_11);
        }
        const Space v337_13 = unite(v337_8,v337_12);
        v336_7_result = unite(v336_7_result,v337_13);
      }
      const Space v336_7 = std::move(v336_7_result);
      v335_8 = compose(v335_5,v336_7);
    }
    const Space v335_9 = intersect(constant_1,v335_2);
    const Space v335_10 = (has_head(v335_9) ? constant_2 : Space{});
    const Space v335_11 = compose(v335_10,v334_8_tail);
    const Space v335_12 = unite(v335_8,v335_11);
    v334_8_result = unite(v334_8_result,v335_12);
  }
  const Space v334_8 = std::move(v334_8_result);
  return v334_8;
}

static Space routine_40(Context& c, const Path& p0, const Space& s0) {
  Space v340_11_result;
  for (int v340_11_label = 1; v340_11_label <= 2; ++v340_11_label) {
    const Space v340_11_tail = child(s0,v340_11_label);
    if (v340_11_tail.empty()) continue;
    const Path v340_11_head{v340_11_label};
    const Space v341_2 = singleton(v340_11_head);
    const Space v341_3 = intersect(constant_1,v341_2);
    const Space v341_4 = (has_head(v341_3) ? constant_2 : Space{});
    const Space v341_5 = subtract(constant_0,v341_4);
    Space v341_8;
    if (!v341_5.empty()) {
      const Path v342_6 = concat_path(p0,v340_11_head);
      Space v342_7_result;
      for (int v342_7_label = 1; v342_7_label <= 2; ++v342_7_label) {
        const Space v342_7_tail = child(v340_11_tail,v342_7_label);
        if (v342_7_tail.empty()) continue;
        const Path v342_7_head{v342_7_label};
        const Space v343_2 = singleton(v342_7_head);
        const Space v343_3 = intersect(constant_1,v343_2);
        const Space v343_4 = (has_head(v343_3) ? constant_2 : Space{});
        const Space v343_5 = subtract(constant_0,v343_4);
        Space v343_8;
        if (!v343_5.empty()) {
          const Path v344_6 = concat_path(v342_6,v342_7_head);
          const Space v344_7 = routine_48(c, v344_6, v342_7_tail);
          v343_8 = compose(v343_5,v344_7);
        }
        const Space v343_9 = intersect(constant_1,v343_2);
        const Space v343_10 = (has_head(v343_9) ? constant_2 : Space{});
        Space v343_12;
        if (!v343_10.empty()) {
          const Path v345_6 = concat_path(v342_6,v342_7_head);
          const Space v345_11 = routine_49(c, v345_6, v342_7_tail);
          v343_12 = compose(v343_10,v345_11);
        }
        const Space v343_13 = unite(v343_8,v343_12);
        v342_7_result = unite(v342_7_result,v343_13);
      }
      const Space v342_7 = std::move(v342_7_result);
      v341_8 = compose(v341_5,v342_7);
    }
    const Space v341_9 = intersect(constant_1,v341_2);
    const Space v341_10 = (has_head(v341_9) ? constant_2 : Space{});
    Space v341_12;
    if (!v341_10.empty()) {
      const Path v346_6 = concat_path(p0,v340_11_head);
      Space v346_11_result;
      for (int v346_11_label = 1; v346_11_label <= 2; ++v346_11_label) {
        const Space v346_11_tail = child(v340_11_tail,v346_11_label);
        if (v346_11_tail.empty()) continue;
        const Path v346_11_head{v346_11_label};
        const Space v347_2 = singleton(v346_11_head);
        const Space v347_3 = intersect(constant_1,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_2 : Space{});
        const Space v347_5 = subtract(constant_0,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v346_6,v346_11_head);
          const Space v348_7 = routine_48(c, v348_6, v346_11_tail);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_1,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_2 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v346_6,v346_11_head);
          const Space v349_11 = routine_17(c, v349_6, v346_11_tail);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_11_result = unite(v346_11_result,v347_13);
      }
      const Space v346_11 = std::move(v346_11_result);
      v341_12 = compose(v341_10,v346_11);
    }
    const Space v341_13 = unite(v341_8,v341_12);
    v340_11_result = unite(v340_11_result,v341_13);
  }
  const Space v340_11 = std::move(v340_11_result);
  return v340_11;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0) {
  Space v350_8_result;
  for (int v350_8_label = 1; v350_8_label <= 2; ++v350_8_label) {
    const Space v350_8_tail = child(s0,v350_8_label);
    if (v350_8_tail.empty()) continue;
    const Path v350_8_head{v350_8_label};
    const Space v351_2 = singleton(v350_8_head);
    const Space v351_3 = intersect(constant_1,v351_2);
    const Space v351_4 = (has_head(v351_3) ? constant_2 : Space{});
    const Space v351_5 = subtract(constant_0,v351_4);
    Space v351_8;
    if (!v351_5.empty()) {
      const Path v352_6 = concat_path(p0,v350_8_head);
      Space v352_7_result;
      for (int v352_7_label = 1; v352_7_label <= 2; ++v352_7_label) {
        const Space v352_7_tail = child(v350_8_tail,v352_7_label);
        if (v352_7_tail.empty()) continue;
        const Path v352_7_head{v352_7_label};
        const Space v353_2 = singleton(v352_7_head);
        const Space v353_3 = intersect(constant_1,v353_2);
        const Space v353_4 = (has_head(v353_3) ? constant_2 : Space{});
        const Space v353_5 = subtract(constant_0,v353_4);
        Space v353_8;
        if (!v353_5.empty()) {
          const Path v354_6 = concat_path(v352_6,v352_7_head);
          const Space v354_7 = routine_48(c, v354_6, v352_7_tail);
          v353_8 = compose(v353_5,v354_7);
        }
        const Space v353_9 = intersect(constant_1,v353_2);
        const Space v353_10 = (has_head(v353_9) ? constant_2 : Space{});
        Space v353_12;
        if (!v353_10.empty()) {
          const Path v355_6 = concat_path(v352_6,v352_7_head);
          const Space v355_11 = routine_49(c, v355_6, v352_7_tail);
          v353_12 = compose(v353_10,v355_11);
        }
        const Space v353_13 = unite(v353_8,v353_12);
        v352_7_result = unite(v352_7_result,v353_13);
      }
      const Space v352_7 = std::move(v352_7_result);
      v351_8 = compose(v351_5,v352_7);
    }
    const Space v351_9 = intersect(constant_1,v351_2);
    const Space v351_10 = (has_head(v351_9) ? constant_2 : Space{});
    const Space v351_11 = compose(v351_10,v350_8_tail);
    const Space v351_12 = unite(v351_8,v351_11);
    v350_8_result = unite(v350_8_result,v351_12);
  }
  const Space v350_8 = std::move(v350_8_result);
  return v350_8;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0) {
  Space v356_6_result;
  for (int v356_6_label = 1; v356_6_label <= 2; ++v356_6_label) {
    const Space v356_6_tail = child(s0,v356_6_label);
    if (v356_6_tail.empty()) continue;
    const Path v356_6_head{v356_6_label};
    const Space v357_2 = singleton(v356_6_head);
    const Space v357_3 = intersect(constant_1,v357_2);
    const Space v357_4 = (has_head(v357_3) ? constant_2 : Space{});
    const Space v357_5 = subtract(constant_0,v357_4);
    Space v357_6_result;
    for (int v357_6_label = 1; v357_6_label <= 2; ++v357_6_label) {
      const Space v357_6_tail = child(v356_6_tail,v357_6_label);
      if (v357_6_tail.empty()) continue;
      const Path v357_6_head{v357_6_label};
      const Space v358_2 = Space{};
      v357_6_result = unite(v357_6_result,v358_2);
    }
    const Space v357_6 = std::move(v357_6_result);
    const Space v357_7 = compose(v357_5,v357_6);
    const Space v357_8 = intersect(constant_1,v357_2);
    const Space v357_9 = (has_head(v357_8) ? constant_2 : Space{});
    Space v357_12;
    if (!v357_9.empty()) {
      const Path v359_10 = concat_path(p0,v356_6_head);
      Space v359_11_result;
      for (int v359_11_label = 1; v359_11_label <= 2; ++v359_11_label) {
        const Space v359_11_tail = child(v356_6_tail,v359_11_label);
        if (v359_11_tail.empty()) continue;
        const Path v359_11_head{v359_11_label};
        const Space v360_2 = singleton(v359_11_head);
        const Space v360_3 = intersect(constant_1,v360_2);
        const Space v360_4 = (has_head(v360_3) ? constant_2 : Space{});
        Space v360_7;
        if (!v360_4.empty()) {
          const Path v361_5 = concat_path(v359_10,v359_11_head);
          const Space v361_6 = routine_14(c, v361_5, v359_11_tail);
          v360_7 = compose(v360_4,v361_6);
        }
        v359_11_result = unite(v359_11_result,v360_7);
      }
      const Space v359_11 = std::move(v359_11_result);
      v357_12 = compose(v357_9,v359_11);
    }
    const Space v357_13 = unite(v357_7,v357_12);
    v356_6_result = unite(v356_6_result,v357_13);
  }
  const Space v356_6 = std::move(v356_6_result);
  return v356_6;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0) {
  Space v362_5_result;
  for (int v362_5_label = 1; v362_5_label <= 2; ++v362_5_label) {
    const Space v362_5_tail = child(s0,v362_5_label);
    if (v362_5_tail.empty()) continue;
    const Path v362_5_head{v362_5_label};
    const Space v363_2 = singleton(v362_5_head);
    const Space v363_3 = intersect(constant_1,v363_2);
    const Space v363_4 = (has_head(v363_3) ? constant_2 : Space{});
    const Space v363_5 = subtract(constant_0,v363_4);
    Space v363_6_result;
    for (int v363_6_label = 1; v363_6_label <= 2; ++v363_6_label) {
      const Space v363_6_tail = child(v362_5_tail,v363_6_label);
      if (v363_6_tail.empty()) continue;
      const Path v363_6_head{v363_6_label};
      const Space v364_2 = Space{};
      v363_6_result = unite(v363_6_result,v364_2);
    }
    const Space v363_6 = std::move(v363_6_result);
    const Space v363_7 = compose(v363_5,v363_6);
    const Space v363_8 = intersect(constant_1,v363_2);
    const Space v363_9 = (has_head(v363_8) ? constant_2 : Space{});
    const Space v363_10 = compose(v363_9,v362_5_tail);
    const Space v363_11 = unite(v363_7,v363_10);
    v362_5_result = unite(v362_5_result,v363_11);
  }
  const Space v362_5 = std::move(v362_5_result);
  return v362_5;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  Space v365_6_result;
  for (int v365_6_label = 1; v365_6_label <= 2; ++v365_6_label) {
    const Space v365_6_tail = child(s0,v365_6_label);
    if (v365_6_tail.empty()) continue;
    const Path v365_6_head{v365_6_label};
    const Space v366_2 = singleton(v365_6_head);
    const Space v366_3 = intersect(constant_1,v366_2);
    const Space v366_4 = (has_head(v366_3) ? constant_2 : Space{});
    const Space v366_5 = subtract(constant_0,v366_4);
    Space v366_6_result;
    for (int v366_6_label = 1; v366_6_label <= 2; ++v366_6_label) {
      const Space v366_6_tail = child(v365_6_tail,v366_6_label);
      if (v366_6_tail.empty()) continue;
      const Path v366_6_head{v366_6_label};
      const Space v367_2 = Space{};
      v366_6_result = unite(v366_6_result,v367_2);
    }
    const Space v366_6 = std::move(v366_6_result);
    const Space v366_7 = compose(v366_5,v366_6);
    const Space v366_8 = intersect(constant_1,v366_2);
    const Space v366_9 = (has_head(v366_8) ? constant_2 : Space{});
    Space v366_12;
    if (!v366_9.empty()) {
      const Path v368_10 = concat_path(p0,v365_6_head);
      Space v368_11_result;
      for (int v368_11_label = 1; v368_11_label <= 2; ++v368_11_label) {
        const Space v368_11_tail = child(v365_6_tail,v368_11_label);
        if (v368_11_tail.empty()) continue;
        const Path v368_11_head{v368_11_label};
        const Space v369_2 = singleton(v368_11_head);
        const Space v369_3 = intersect(constant_1,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_2 : Space{});
        Space v369_7;
        if (!v369_4.empty()) {
          const Path v370_5 = concat_path(v368_10,v368_11_head);
          const Space v370_6 = routine_17(c, v370_5, v368_11_tail);
          v369_7 = compose(v369_4,v370_6);
        }
        v368_11_result = unite(v368_11_result,v369_7);
      }
      const Space v368_11 = std::move(v368_11_result);
      v366_12 = compose(v366_9,v368_11);
    }
    const Space v366_13 = unite(v366_7,v366_12);
    v365_6_result = unite(v365_6_result,v366_13);
  }
  const Space v365_6 = std::move(v365_6_result);
  return v365_6;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0) {
  Space v371_5_result;
  for (int v371_5_label = 1; v371_5_label <= 2; ++v371_5_label) {
    const Space v371_5_tail = child(s0,v371_5_label);
    if (v371_5_tail.empty()) continue;
    const Path v371_5_head{v371_5_label};
    const Space v372_2 = singleton(v371_5_head);
    const Space v372_3 = intersect(constant_1,v372_2);
    const Space v372_4 = (has_head(v372_3) ? constant_2 : Space{});
    const Space v372_5 = subtract(constant_0,v372_4);
    Space v372_6_result;
    for (int v372_6_label = 1; v372_6_label <= 2; ++v372_6_label) {
      const Space v372_6_tail = child(v371_5_tail,v372_6_label);
      if (v372_6_tail.empty()) continue;
      const Path v372_6_head{v372_6_label};
      const Space v373_2 = Space{};
      v372_6_result = unite(v372_6_result,v373_2);
    }
    const Space v372_6 = std::move(v372_6_result);
    const Space v372_7 = compose(v372_5,v372_6);
    const Space v372_8 = intersect(constant_1,v372_2);
    const Space v372_9 = (has_head(v372_8) ? constant_2 : Space{});
    const Space v372_10 = compose(v372_9,v371_5_tail);
    const Space v372_11 = unite(v372_7,v372_10);
    v371_5_result = unite(v371_5_result,v372_11);
  }
  const Space v371_5 = std::move(v371_5_result);
  return v371_5;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0) {
  Space v374_2_result;
  for (int v374_2_label = 1; v374_2_label <= 2; ++v374_2_label) {
    const Space v374_2_tail = child(s0,v374_2_label);
    if (v374_2_tail.empty()) continue;
    const Path v374_2_head{v374_2_label};
    const Space v375_2 = Space{};
    v374_2_result = unite(v374_2_result,v375_2);
  }
  const Space v374_2 = std::move(v374_2_result);
  return v374_2;
}

static Space routine_47(Context& c, const Path& p0, const Space& s0) {
  Space v376_3_result;
  for (int v376_3_label = 1; v376_3_label <= 2; ++v376_3_label) {
    const Space v376_3_tail = child(s0,v376_3_label);
    if (v376_3_tail.empty()) continue;
    const Path v376_3_head{v376_3_label};
    const Space v377_2 = singleton(v376_3_head);
    const Space v377_3 = intersect(constant_1,v377_2);
    const Space v377_4 = (has_head(v377_3) ? constant_2 : Space{});
    const Space v377_5 = compose(v377_4,v376_3_tail);
    v376_3_result = unite(v376_3_result,v377_5);
  }
  const Space v376_3 = std::move(v376_3_result);
  return v376_3;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v378_2_result;
  for (int v378_2_label = 1; v378_2_label <= 2; ++v378_2_label) {
    const Space v378_2_tail = child(s0,v378_2_label);
    if (v378_2_tail.empty()) continue;
    const Path v378_2_head{v378_2_label};
    const Space v379_2 = Space{};
    v378_2_result = unite(v378_2_result,v379_2);
  }
  const Space v378_2 = std::move(v378_2_result);
  return v378_2;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v380_3_result;
  for (int v380_3_label = 1; v380_3_label <= 2; ++v380_3_label) {
    const Space v380_3_tail = child(s0,v380_3_label);
    if (v380_3_tail.empty()) continue;
    const Path v380_3_head{v380_3_label};
    const Space v381_2 = singleton(v380_3_head);
    const Space v381_3 = intersect(constant_1,v381_2);
    const Space v381_4 = (has_head(v381_3) ? constant_2 : Space{});
    const Space v381_5 = compose(v381_4,v380_3_tail);
    v380_3_result = unite(v380_3_result,v381_5);
  }
  const Space v380_3 = std::move(v380_3_result);
  return v380_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
