# Cornerstone compiled-code review bundle

22 cornerstone variants and 14 supplementary large cases, each with complete C++ for the symbolic, Fibonacci-bit, and fixed-four-byte dialects (108 translation units).
These are emitted directly from the same case factories and encodings used by the recorded OpenFst benchmarks.
No native compilation or new timing measurement is performed by this exporter.
The retained benchmark evidence was collected on the Symba h4d on 2026-10-29; code is regenerated from the current checkout.
Fresh residual routine identifiers and C++ function numbering can differ between exports.

Start with a case's `symbolic.zippy`, then its `symbols.cpp`, `bits.cpp`, and `bytes.cpp`.
`manifest.json` records file hashes, sizes, and whether each program needs host callbacks.
The shared OpenFst implementation is copied once into [runtime/](runtime/).
Per-example benchmark tables are in [benchmarks/README.md](benchmarks/README.md).

## Build one translation unit

Install OpenFst and its dependencies, then from this bundle:

```sh
cmake -S runtime -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF \
  -DZIPPY_PROGRAM="$PWD/programs/<case>/symbols.cpp"
cmake --build build -j 8
ZIPPY_STACK_MIB=256 build/zippy_program < programs/<case>/symbols.input.txt
```

For very large generated units use `-DCMAKE_CXX_FLAGS_RELEASE="-O0"`;
this review build setting is separate from the recorded benchmark settings.
Only programs marked standalone run directly with these input files. Others emit callback requests and require
`OpenFstBackend.Session` or supplied native grounded functions. Callbacks are explicitly counted per artifact.

| Family | Example | Variant | Files |
|---|---|---|---|
| programs | aunt | reference | [source directory](programs/01-aunt-reference/README.md) |
 programs | aunt | process-sc static family | [source directory](programs/02-aunt-process-sc-static-family/README.md) |
 programs | aunt synthetic | reference 60 people | [source directory](programs/03-aunt-synthetic-reference-60-people/README.md) |
 programs | aunt royal92 | reference royal92_simple.metta fallback | [source directory](programs/04-aunt-royal92-reference-royal92-simple-metta-fallback/README.md) |
 programs | aunt synthetic | process-sc static family 24 people | [source directory](programs/05-aunt-synthetic-process-sc-static-family-24-people/README.md) |
 programs | graph two-hop | reference 90-chain | [source directory](programs/06-graph-two-hop-reference-90-chain/README.md) |
 programs | graph mutual | reference 90-chain | [source directory](programs/07-graph-mutual-reference-90-chain/README.md) |
 programs | scc | paper divide-and-conquer | [source directory](programs/08-scc-paper-divide-and-conquer/README.md) |
 programs | datalog semi-naive | reference 24-chain | [source directory](programs/09-datalog-semi-naive-reference-24-chain/README.md) |
 programs | datalog semi-naive | process-sc 24-chain | [source directory](programs/10-datalog-semi-naive-process-sc-24-chain/README.md) |
 programs | life | reference random 24x24 | [source directory](programs/11-life-reference-random-24x24/README.md) |
 programs | life | compile-pass random 24x24 | [source directory](programs/12-life-compile-pass-random-24x24/README.md) |
 programs | life | compile-pass random 24x24 initial literal | [source directory](programs/13-life-compile-pass-random-24x24-initial-literal/README.md) |
 programs | temperature | NOAA committed slice | [source directory](programs/14-temperature-noaa-committed-slice/README.md) |
 programs | temperature | synthetic 32x64 | [source directory](programs/15-temperature-synthetic-32x64/README.md) |
 programs | sliding puzzle | 2x2 pure source full frontier step | [source directory](programs/16-sliding-puzzle-2x2-pure-source-full-frontier-step/README.md) |
 programs | sliding puzzle | 2x2 pure compile-pass full frontier step | [source directory](programs/17-sliding-puzzle-2x2-pure-compile-pass-full-frontier-step/README.md) |
 programs | sliding puzzle | 3x3 pure source depth-8 step | [source directory](programs/18-sliding-puzzle-3x3-pure-source-depth-8-step/README.md) |
 programs | sliding puzzle | 3x3 pure compile-pass depth-8 step | [source directory](programs/19-sliding-puzzle-3x3-pure-compile-pass-depth-8-step/README.md) |
 programs | sliding puzzle | 4x4 pure source depth-5 step | [source directory](programs/20-sliding-puzzle-4x4-pure-source-depth-5-step/README.md) |
 programs | n-queens | MORKL 8x8 source | [source directory](programs/21-n-queens-morkl-8x8-source/README.md) |
 programs | n-queens | MORKL 8x8 compile-pass | [source directory](programs/22-n-queens-morkl-8x8-compile-pass/README.md) |
 large | nonrecursive graph two-hop | 180 nodes, 359 edge facts | [source directory](large/23-nonrecursive-graph-two-hop-180-nodes-359-edge-facts/README.md) |
 large | nonrecursive graph two-hop | 360 nodes, 719 edge facts | [source directory](large/24-nonrecursive-graph-two-hop-360-nodes-719-edge-facts/README.md) |
 large | nonrecursive graph two-hop | 720 nodes, 1439 edge facts | [source directory](large/25-nonrecursive-graph-two-hop-720-nodes-1439-edge-facts/README.md) |
 large | product intersected by one exact path | 2000 x 2000 product, 1 result path | [source directory](large/26-product-intersected-by-one-exact-path-2000-x-2000-product-1-result-path/README.md) |
 large | product intersected by one exact path | 10000 x 10000 product, 1 result path | [source directory](large/27-product-intersected-by-one-exact-path-10000-x-10000-product-1-result-path/README.md) |
 large | product intersected by one exact path | 30000 x 30000 product, 1 result path | [source directory](large/28-product-intersected-by-one-exact-path-30000-x-30000-product-1-result-path/README.md) |
 large | product restricted by one first-level prefix | 2000 x 2000 product, 2000 result paths | [source directory](large/29-product-restricted-by-one-first-level-prefix-2000-x-2000-product-2000-result-paths/README.md) |
 large | product restricted by one first-level prefix | 10000 x 10000 product, 10000 result paths | [source directory](large/30-product-restricted-by-one-first-level-prefix-10000-x-10000-product-10000-result-paths/README.md) |
 large | product restricted by one first-level prefix | 30000 x 30000 product, 30000 result paths | [source directory](large/31-product-restricted-by-one-first-level-prefix-30000-x-30000-product-30000-result-paths/README.md) |
 large | aunt query over large generated family, one queried person | 9 generations x 80 people (2720 facts) | [source directory](large/32-aunt-query-over-large-generated-family-one-queried-person-9-generations-x-80-people-2720-facts/README.md) |
 large | aunt query over large generated family, one queried person | 11 generations x 160 people (6720 facts) | [source directory](large/33-aunt-query-over-large-generated-family-one-queried-person-11-generations-x-160-people-6720-facts/README.md) |
 large | SCC divide-and-conquer | 6 directed edges, 2 representative/member pairs | [source directory](large/34-scc-divide-and-conquer-6-directed-edges-2-representative-member-pairs/README.md) |
 large | semi-naive datalog over generated chain graph | 40 nodes, 79 edge facts | [source directory](large/35-semi-naive-datalog-over-generated-chain-graph-40-nodes-79-edge-facts/README.md) |
 large | semi-naive datalog over generated chain graph | 80 nodes, 159 edge facts | [source directory](large/36-semi-naive-datalog-over-generated-chain-graph-80-nodes-159-edge-facts/README.md) |
