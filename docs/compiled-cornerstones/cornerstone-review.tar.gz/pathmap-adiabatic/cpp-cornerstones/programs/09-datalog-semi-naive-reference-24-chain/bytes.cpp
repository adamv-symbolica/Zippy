#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,3};
static const Path constant_1 = Path{1,1,1,2};
static const Space constant_2 = literal_text("1 0 ");
static const Path constant_3 = Path{1,1,1,4};
static const Path constant_4 = Path{1,1,1,5};
static const Path constant_5 = Path{1,1,1,6};
static const Path constant_6 = Path{1,1,1,25};
static const Path constant_7 = Path{1,1,1,26};
static const Path constant_8 = Path{1,1,1,7};
static const Path constant_9 = Path{1,1,1,8};
static const Path constant_10 = Path{1,1,1,9};
static const Path constant_11 = Path{1,1,1,10};
static const Path constant_12 = Path{1,1,1,11};
static const Path constant_13 = Path{1,1,1,12};
static const Path constant_14 = Path{1,1,1,13};
static const Path constant_15 = Path{1,1,1,14};
static const Path constant_16 = Path{1,1,1,15};
static const Path constant_17 = Path{1,1,1,16};
static const Path constant_18 = Path{1,1,1,17};
static const Path constant_19 = Path{1,1,1,18};
static const Path constant_20 = Path{1,1,1,19};
static const Path constant_21 = Path{1,1,1,20};
static const Path constant_22 = Path{1,1,1,21};
static const Path constant_23 = Path{1,1,1,22};
static const Path constant_24 = Path{1,1,1,23};
static const Path constant_25 = Path{1,1,1,24};
static const Path constant_26 = Path{1,1,1,28};
static const Space constant_27 = literal_text("47 16 1 1 1 29 1 1 1 1 1 1 1 2 1 1 1 3 16 1 1 1 29 1 1 1 1 1 1 1 2 1 1 1 4 16 1 1 1 29 1 1 1 1 1 1 1 3 1 1 1 4 16 1 1 1 29 1 1 1 1 1 1 1 3 1 1 1 5 16 1 1 1 29 1 1 1 1 1 1 1 4 1 1 1 5 16 1 1 1 29 1 1 1 1 1 1 1 4 1 1 1 18 16 1 1 1 29 1 1 1 1 1 1 1 5 1 1 1 18 16 1 1 1 29 1 1 1 1 1 1 1 5 1 1 1 22 16 1 1 1 29 1 1 1 1 1 1 1 6 1 1 1 7 16 1 1 1 29 1 1 1 1 1 1 1 6 1 1 1 8 16 1 1 1 29 1 1 1 1 1 1 1 7 1 1 1 8 16 1 1 1 29 1 1 1 1 1 1 1 7 1 1 1 9 16 1 1 1 29 1 1 1 1 1 1 1 8 1 1 1 9 16 1 1 1 29 1 1 1 1 1 1 1 8 1 1 1 10 16 1 1 1 29 1 1 1 1 1 1 1 9 1 1 1 10 16 1 1 1 29 1 1 1 1 1 1 1 9 1 1 1 11 16 1 1 1 29 1 1 1 1 1 1 1 10 1 1 1 11 16 1 1 1 29 1 1 1 1 1 1 1 10 1 1 1 12 16 1 1 1 29 1 1 1 1 1 1 1 11 1 1 1 12 16 1 1 1 29 1 1 1 1 1 1 1 11 1 1 1 13 16 1 1 1 29 1 1 1 1 1 1 1 12 1 1 1 13 16 1 1 1 29 1 1 1 1 1 1 1 12 1 1 1 14 16 1 1 1 29 1 1 1 1 1 1 1 13 1 1 1 14 16 1 1 1 29 1 1 1 1 1 1 1 13 1 1 1 15 16 1 1 1 29 1 1 1 1 1 1 1 14 1 1 1 15 16 1 1 1 29 1 1 1 1 1 1 1 14 1 1 1 16 16 1 1 1 29 1 1 1 1 1 1 1 15 1 1 1 16 16 1 1 1 29 1 1 1 1 1 1 1 15 1 1 1 17 16 1 1 1 29 1 1 1 1 1 1 1 16 1 1 1 17 16 1 1 1 29 1 1 1 1 1 1 1 16 1 1 1 19 16 1 1 1 29 1 1 1 1 1 1 1 17 1 1 1 19 16 1 1 1 29 1 1 1 1 1 1 1 17 1 1 1 20 16 1 1 1 29 1 1 1 1 1 1 1 18 1 1 1 22 16 1 1 1 29 1 1 1 1 1 1 1 18 1 1 1 23 16 1 1 1 29 1 1 1 1 1 1 1 19 1 1 1 20 16 1 1 1 29 1 1 1 1 1 1 1 19 1 1 1 21 16 1 1 1 29 1 1 1 1 1 1 1 20 1 1 1 21 16 1 1 1 29 1 1 1 1 1 1 1 22 1 1 1 23 16 1 1 1 29 1 1 1 1 1 1 1 22 1 1 1 24 16 1 1 1 29 1 1 1 1 1 1 1 23 1 1 1 24 16 1 1 1 29 1 1 1 1 1 1 1 23 1 1 1 25 16 1 1 1 29 1 1 1 1 1 1 1 24 1 1 1 25 16 1 1 1 29 1 1 1 1 1 1 1 24 1 1 1 26 16 1 1 1 29 1 1 1 1 1 1 1 25 1 1 1 6 16 1 1 1 29 1 1 1 1 1 1 1 25 1 1 1 26 16 1 1 1 29 1 1 1 1 1 1 1 26 1 1 1 6 16 1 1 1 29 1 1 1 1 1 1 1 26 1 1 1 7");
static const Path constant_28 = Path{1,1,1,27};
static const Path constant_29 = Path{1,1,1,29};
static const Path constant_30 = Path{1,1,1,1};
static const Path constant_31 = Path{1,1,1,28,1,1,1,27};
static const Path constant_32 = Path{1,1,1,29,1,1,1,27};
static Space routine_0(Context& c);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_6 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_7 = unite(v0_3,v0_6);
  const Space v0_9 = routine_1(c, constant_3, constant_0, constant_2);
  const Space v0_10 = unite(v0_7,v0_9);
  const Space v0_13 = routine_1(c, constant_4, constant_0, constant_2);
  const Space v0_14 = unite(v0_10,v0_13);
  const Space v0_16 = routine_1(c, constant_4, constant_3, constant_2);
  const Space v0_17 = unite(v0_14,v0_16);
  const Space v0_21 = routine_1(c, constant_5, constant_6, constant_2);
  const Space v0_22 = unite(v0_17,v0_21);
  const Space v0_25 = routine_1(c, constant_5, constant_7, constant_2);
  const Space v0_26 = unite(v0_22,v0_25);
  const Space v0_29 = routine_1(c, constant_8, constant_5, constant_2);
  const Space v0_30 = unite(v0_26,v0_29);
  const Space v0_32 = routine_1(c, constant_8, constant_7, constant_2);
  const Space v0_33 = unite(v0_30,v0_32);
  const Space v0_36 = routine_1(c, constant_9, constant_5, constant_2);
  const Space v0_37 = unite(v0_33,v0_36);
  const Space v0_39 = routine_1(c, constant_9, constant_8, constant_2);
  const Space v0_40 = unite(v0_37,v0_39);
  const Space v0_43 = routine_1(c, constant_10, constant_8, constant_2);
  const Space v0_44 = unite(v0_40,v0_43);
  const Space v0_46 = routine_1(c, constant_10, constant_9, constant_2);
  const Space v0_47 = unite(v0_44,v0_46);
  const Space v0_50 = routine_1(c, constant_11, constant_9, constant_2);
  const Space v0_51 = unite(v0_47,v0_50);
  const Space v0_53 = routine_1(c, constant_11, constant_10, constant_2);
  const Space v0_54 = unite(v0_51,v0_53);
  const Space v0_57 = routine_1(c, constant_12, constant_10, constant_2);
  const Space v0_58 = unite(v0_54,v0_57);
  const Space v0_60 = routine_1(c, constant_12, constant_11, constant_2);
  const Space v0_61 = unite(v0_58,v0_60);
  const Space v0_64 = routine_1(c, constant_13, constant_11, constant_2);
  const Space v0_65 = unite(v0_61,v0_64);
  const Space v0_67 = routine_1(c, constant_13, constant_12, constant_2);
  const Space v0_68 = unite(v0_65,v0_67);
  const Space v0_71 = routine_1(c, constant_14, constant_12, constant_2);
  const Space v0_72 = unite(v0_68,v0_71);
  const Space v0_74 = routine_1(c, constant_14, constant_13, constant_2);
  const Space v0_75 = unite(v0_72,v0_74);
  const Space v0_78 = routine_1(c, constant_15, constant_13, constant_2);
  const Space v0_79 = unite(v0_75,v0_78);
  const Space v0_81 = routine_1(c, constant_15, constant_14, constant_2);
  const Space v0_82 = unite(v0_79,v0_81);
  const Space v0_85 = routine_1(c, constant_16, constant_14, constant_2);
  const Space v0_86 = unite(v0_82,v0_85);
  const Space v0_88 = routine_1(c, constant_16, constant_15, constant_2);
  const Space v0_89 = unite(v0_86,v0_88);
  const Space v0_92 = routine_1(c, constant_17, constant_15, constant_2);
  const Space v0_93 = unite(v0_89,v0_92);
  const Space v0_95 = routine_1(c, constant_17, constant_16, constant_2);
  const Space v0_96 = unite(v0_93,v0_95);
  const Space v0_99 = routine_1(c, constant_18, constant_16, constant_2);
  const Space v0_100 = unite(v0_96,v0_99);
  const Space v0_102 = routine_1(c, constant_18, constant_17, constant_2);
  const Space v0_103 = unite(v0_100,v0_102);
  const Space v0_106 = routine_1(c, constant_19, constant_3, constant_2);
  const Space v0_107 = unite(v0_103,v0_106);
  const Space v0_109 = routine_1(c, constant_19, constant_4, constant_2);
  const Space v0_110 = unite(v0_107,v0_109);
  const Space v0_113 = routine_1(c, constant_20, constant_17, constant_2);
  const Space v0_114 = unite(v0_110,v0_113);
  const Space v0_116 = routine_1(c, constant_20, constant_18, constant_2);
  const Space v0_117 = unite(v0_114,v0_116);
  const Space v0_120 = routine_1(c, constant_21, constant_18, constant_2);
  const Space v0_121 = unite(v0_117,v0_120);
  const Space v0_123 = routine_1(c, constant_21, constant_20, constant_2);
  const Space v0_124 = unite(v0_121,v0_123);
  const Space v0_127 = routine_1(c, constant_22, constant_20, constant_2);
  const Space v0_128 = unite(v0_124,v0_127);
  const Space v0_130 = routine_1(c, constant_22, constant_21, constant_2);
  const Space v0_131 = unite(v0_128,v0_130);
  const Space v0_134 = routine_1(c, constant_23, constant_4, constant_2);
  const Space v0_135 = unite(v0_131,v0_134);
  const Space v0_137 = routine_1(c, constant_23, constant_19, constant_2);
  const Space v0_138 = unite(v0_135,v0_137);
  const Space v0_141 = routine_1(c, constant_24, constant_19, constant_2);
  const Space v0_142 = unite(v0_138,v0_141);
  const Space v0_144 = routine_1(c, constant_24, constant_23, constant_2);
  const Space v0_145 = unite(v0_142,v0_144);
  const Space v0_148 = routine_1(c, constant_25, constant_23, constant_2);
  const Space v0_149 = unite(v0_145,v0_148);
  const Space v0_151 = routine_1(c, constant_25, constant_24, constant_2);
  const Space v0_152 = unite(v0_149,v0_151);
  const Space v0_154 = routine_1(c, constant_6, constant_24, constant_2);
  const Space v0_155 = unite(v0_152,v0_154);
  const Space v0_157 = routine_1(c, constant_6, constant_25, constant_2);
  const Space v0_158 = unite(v0_155,v0_157);
  const Space v0_160 = routine_1(c, constant_7, constant_25, constant_2);
  const Space v0_161 = unite(v0_158,v0_160);
  const Space v0_163 = routine_1(c, constant_7, constant_6, constant_2);
  const Space v0_164 = unite(v0_161,v0_163);
  const Space v0_166 = wrap(v0_164,constant_26);
  const Space v0_168 = unite(v0_166,constant_27);
  Space v0_174 = v0_168;
  for (;;) {
    const Space v1_1 = unwrap(v0_174,constant_26);
    const Space v1_2 = unwrap(v1_1,constant_28);
    const auto v1_3_branches = branches(c,v1_2);
    std::vector<Space> v1_3_outputs;
    v1_3_outputs.reserve(v1_3_branches.size());
    for (const auto& v1_3_branch : v1_3_branches) {
      const Path v1_3_head{v1_3_branch.first};
      const Space& v1_3_tail = v1_3_branch.second;
      const auto v2_2_branches = branches(c,v1_3_tail);
      std::vector<Space> v2_2_outputs;
      v2_2_outputs.reserve(v2_2_branches.size());
      for (const auto& v2_2_branch : v2_2_branches) {
        const Path v2_2_head{v2_2_branch.first};
        const Space& v2_2_tail = v2_2_branch.second;
        const Path v3_2 = concat_path(v1_3_head,v2_2_head);
        const auto v3_3_branches = branches(c,v2_2_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const auto v4_3_branches = branches(c,v3_3_tail);
          std::vector<Space> v4_3_outputs;
          v4_3_outputs.reserve(v4_3_branches.size());
          for (const auto& v4_3_branch : v4_3_branches) {
            const Path v4_3_head{v4_3_branch.first};
            const Space& v4_3_tail = v4_3_branch.second;
            const Path v5_2 = concat_path(v4_2,v4_3_head);
            const auto v5_3_branches = branches(c,v4_3_tail);
            std::vector<Space> v5_3_outputs;
            v5_3_outputs.reserve(v5_3_branches.size());
            for (const auto& v5_3_branch : v5_3_branches) {
              const Path v5_3_head{v5_3_branch.first};
              const Space& v5_3_tail = v5_3_branch.second;
              const auto v6_2_branches = branches(c,v5_3_tail);
              std::vector<Space> v6_2_outputs;
              v6_2_outputs.reserve(v6_2_branches.size());
              for (const auto& v6_2_branch : v6_2_branches) {
                const Path v6_2_head{v6_2_branch.first};
                const Space& v6_2_tail = v6_2_branch.second;
                const Path v7_2 = concat_path(v5_3_head,v6_2_head);
                const auto v7_3_branches = branches(c,v6_2_tail);
                std::vector<Space> v7_3_outputs;
                v7_3_outputs.reserve(v7_3_branches.size());
                for (const auto& v7_3_branch : v7_3_branches) {
                  const Path v7_3_head{v7_3_branch.first};
                  const Space& v7_3_tail = v7_3_branch.second;
                  const Path v8_2 = concat_path(v7_2,v7_3_head);
                  const auto v8_3_branches = branches(c,v7_3_tail);
                  std::vector<Space> v8_3_outputs;
                  v8_3_outputs.reserve(v8_3_branches.size());
                  for (const auto& v8_3_branch : v8_3_branches) {
                    const Path v8_3_head{v8_3_branch.first};
                    const Space& v8_3_tail = v8_3_branch.second;
                    const Path v9_2 = concat_path(v8_2,v8_3_head);
                    const Space v9_3 = routine_2(c, v9_2, v5_2, v8_3_tail, v0_174);
                    v8_3_outputs.push_back(v9_3);
                  }
                  const Space v8_3 = join_outputs(std::move(v8_3_outputs));
                  v7_3_outputs.push_back(v8_3);
                }
                const Space v7_3 = join_outputs(std::move(v7_3_outputs));
                v6_2_outputs.push_back(v7_3);
              }
              const Space v6_2 = join_outputs(std::move(v6_2_outputs));
              v5_3_outputs.push_back(v6_2);
            }
            const Space v5_3 = join_outputs(std::move(v5_3_outputs));
            v4_3_outputs.push_back(v5_3);
          }
          const Space v4_3 = join_outputs(std::move(v4_3_outputs));
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_2_outputs.push_back(v3_3);
      }
      const Space v2_2 = join_outputs(std::move(v2_2_outputs));
      v1_3_outputs.push_back(v2_2);
    }
    const Space v1_3 = join_outputs(std::move(v1_3_outputs));
    const auto v1_4_branches = branches(c,v1_2);
    std::vector<Space> v1_4_outputs;
    v1_4_outputs.reserve(v1_4_branches.size());
    for (const auto& v1_4_branch : v1_4_branches) {
      const Path v1_4_head{v1_4_branch.first};
      const Space& v1_4_tail = v1_4_branch.second;
      const auto v10_2_branches = branches(c,v1_4_tail);
      std::vector<Space> v10_2_outputs;
      v10_2_outputs.reserve(v10_2_branches.size());
      for (const auto& v10_2_branch : v10_2_branches) {
        const Path v10_2_head{v10_2_branch.first};
        const Space& v10_2_tail = v10_2_branch.second;
        const Path v11_2 = concat_path(v1_4_head,v10_2_head);
        const auto v11_3_branches = branches(c,v10_2_tail);
        std::vector<Space> v11_3_outputs;
        v11_3_outputs.reserve(v11_3_branches.size());
        for (const auto& v11_3_branch : v11_3_branches) {
          const Path v11_3_head{v11_3_branch.first};
          const Space& v11_3_tail = v11_3_branch.second;
          const Path v12_2 = concat_path(v11_2,v11_3_head);
          const auto v12_3_branches = branches(c,v11_3_tail);
          std::vector<Space> v12_3_outputs;
          v12_3_outputs.reserve(v12_3_branches.size());
          for (const auto& v12_3_branch : v12_3_branches) {
            const Path v12_3_head{v12_3_branch.first};
            const Space& v12_3_tail = v12_3_branch.second;
            const Path v13_2 = concat_path(v12_2,v12_3_head);
            const auto v13_3_branches = branches(c,v12_3_tail);
            std::vector<Space> v13_3_outputs;
            v13_3_outputs.reserve(v13_3_branches.size());
            for (const auto& v13_3_branch : v13_3_branches) {
              const Path v13_3_head{v13_3_branch.first};
              const Space& v13_3_tail = v13_3_branch.second;
              const auto v14_2_branches = branches(c,v13_3_tail);
              std::vector<Space> v14_2_outputs;
              v14_2_outputs.reserve(v14_2_branches.size());
              for (const auto& v14_2_branch : v14_2_branches) {
                const Path v14_2_head{v14_2_branch.first};
                const Space& v14_2_tail = v14_2_branch.second;
                const Path v15_2 = concat_path(v13_3_head,v14_2_head);
                const auto v15_3_branches = branches(c,v14_2_tail);
                std::vector<Space> v15_3_outputs;
                v15_3_outputs.reserve(v15_3_branches.size());
                for (const auto& v15_3_branch : v15_3_branches) {
                  const Path v15_3_head{v15_3_branch.first};
                  const Space& v15_3_tail = v15_3_branch.second;
                  const Path v16_2 = concat_path(v15_2,v15_3_head);
                  const auto v16_3_branches = branches(c,v15_3_tail);
                  std::vector<Space> v16_3_outputs;
                  v16_3_outputs.reserve(v16_3_branches.size());
                  for (const auto& v16_3_branch : v16_3_branches) {
                    const Path v16_3_head{v16_3_branch.first};
                    const Space& v16_3_tail = v16_3_branch.second;
                    const Path v17_2 = concat_path(v16_2,v16_3_head);
                    const Space v17_3 = routine_3(c, v17_2, v13_2, v16_3_tail, v0_174);
                    v16_3_outputs.push_back(v17_3);
                  }
                  const Space v16_3 = join_outputs(std::move(v16_3_outputs));
                  v15_3_outputs.push_back(v16_3);
                }
                const Space v15_3 = join_outputs(std::move(v15_3_outputs));
                v14_2_outputs.push_back(v15_3);
              }
              const Space v14_2 = join_outputs(std::move(v14_2_outputs));
              v13_3_outputs.push_back(v14_2);
            }
            const Space v13_3 = join_outputs(std::move(v13_3_outputs));
            v12_3_outputs.push_back(v13_3);
          }
          const Space v12_3 = join_outputs(std::move(v12_3_outputs));
          v11_3_outputs.push_back(v12_3);
        }
        const Space v11_3 = join_outputs(std::move(v11_3_outputs));
        v10_2_outputs.push_back(v11_3);
      }
      const Space v10_2 = join_outputs(std::move(v10_2_outputs));
      v1_4_outputs.push_back(v10_2);
    }
    const Space v1_4 = join_outputs(std::move(v1_4_outputs));
    const Space v1_5 = unite(v1_3,v1_4);
    const Space v1_6 = unwrap(v0_174,constant_29);
    const Space v1_7 = unwrap(v1_6,constant_30);
    const auto v1_8_branches = branches(c,v1_7);
    std::vector<Space> v1_8_outputs;
    v1_8_outputs.reserve(v1_8_branches.size());
    for (const auto& v1_8_branch : v1_8_branches) {
      const Path v1_8_head{v1_8_branch.first};
      const Space& v1_8_tail = v1_8_branch.second;
      const auto v18_2_branches = branches(c,v1_8_tail);
      std::vector<Space> v18_2_outputs;
      v18_2_outputs.reserve(v18_2_branches.size());
      for (const auto& v18_2_branch : v18_2_branches) {
        const Path v18_2_head{v18_2_branch.first};
        const Space& v18_2_tail = v18_2_branch.second;
        const Path v19_2 = concat_path(v1_8_head,v18_2_head);
        const auto v19_3_branches = branches(c,v18_2_tail);
        std::vector<Space> v19_3_outputs;
        v19_3_outputs.reserve(v19_3_branches.size());
        for (const auto& v19_3_branch : v19_3_branches) {
          const Path v19_3_head{v19_3_branch.first};
          const Space& v19_3_tail = v19_3_branch.second;
          const Path v20_2 = concat_path(v19_2,v19_3_head);
          const auto v20_3_branches = branches(c,v19_3_tail);
          std::vector<Space> v20_3_outputs;
          v20_3_outputs.reserve(v20_3_branches.size());
          for (const auto& v20_3_branch : v20_3_branches) {
            const Path v20_3_head{v20_3_branch.first};
            const Space& v20_3_tail = v20_3_branch.second;
            const Path v21_2 = concat_path(v20_2,v20_3_head);
            const auto v21_3_branches = branches(c,v20_3_tail);
            std::vector<Space> v21_3_outputs;
            v21_3_outputs.reserve(v21_3_branches.size());
            for (const auto& v21_3_branch : v21_3_branches) {
              const Path v21_3_head{v21_3_branch.first};
              const Space& v21_3_tail = v21_3_branch.second;
              const auto v22_2_branches = branches(c,v21_3_tail);
              std::vector<Space> v22_2_outputs;
              v22_2_outputs.reserve(v22_2_branches.size());
              for (const auto& v22_2_branch : v22_2_branches) {
                const Path v22_2_head{v22_2_branch.first};
                const Space& v22_2_tail = v22_2_branch.second;
                const Path v23_2 = concat_path(v21_3_head,v22_2_head);
                const auto v23_3_branches = branches(c,v22_2_tail);
                std::vector<Space> v23_3_outputs;
                v23_3_outputs.reserve(v23_3_branches.size());
                for (const auto& v23_3_branch : v23_3_branches) {
                  const Path v23_3_head{v23_3_branch.first};
                  const Space& v23_3_tail = v23_3_branch.second;
                  const Path v24_2 = concat_path(v23_2,v23_3_head);
                  const auto v24_3_branches = branches(c,v23_3_tail);
                  std::vector<Space> v24_3_outputs;
                  v24_3_outputs.reserve(v24_3_branches.size());
                  for (const auto& v24_3_branch : v24_3_branches) {
                    const Path v24_3_head{v24_3_branch.first};
                    const Space& v24_3_tail = v24_3_branch.second;
                    const Path v25_2 = concat_path(v24_2,v24_3_head);
                    const Space v25_3 = routine_4(c, v25_2, v21_2, v24_3_tail);
                    v24_3_outputs.push_back(v25_3);
                  }
                  const Space v24_3 = join_outputs(std::move(v24_3_outputs));
                  v23_3_outputs.push_back(v24_3);
                }
                const Space v23_3 = join_outputs(std::move(v23_3_outputs));
                v22_2_outputs.push_back(v23_3);
              }
              const Space v22_2 = join_outputs(std::move(v22_2_outputs));
              v21_3_outputs.push_back(v22_2);
            }
            const Space v21_3 = join_outputs(std::move(v21_3_outputs));
            v20_3_outputs.push_back(v21_3);
          }
          const Space v20_3 = join_outputs(std::move(v20_3_outputs));
          v19_3_outputs.push_back(v20_3);
        }
        const Space v19_3 = join_outputs(std::move(v19_3_outputs));
        v18_2_outputs.push_back(v19_3);
      }
      const Space v18_2 = join_outputs(std::move(v18_2_outputs));
      v1_8_outputs.push_back(v18_2);
    }
    const Space v1_8 = join_outputs(std::move(v1_8_outputs));
    const Space v1_9 = unite(v1_5,v1_8);
    const Space v1_10 = unwrap(v1_6,constant_28);
    const auto v1_11_branches = branches(c,v1_10);
    std::vector<Space> v1_11_outputs;
    v1_11_outputs.reserve(v1_11_branches.size());
    for (const auto& v1_11_branch : v1_11_branches) {
      const Path v1_11_head{v1_11_branch.first};
      const Space& v1_11_tail = v1_11_branch.second;
      const auto v26_2_branches = branches(c,v1_11_tail);
      std::vector<Space> v26_2_outputs;
      v26_2_outputs.reserve(v26_2_branches.size());
      for (const auto& v26_2_branch : v26_2_branches) {
        const Path v26_2_head{v26_2_branch.first};
        const Space& v26_2_tail = v26_2_branch.second;
        const Path v27_2 = concat_path(v1_11_head,v26_2_head);
        const auto v27_3_branches = branches(c,v26_2_tail);
        std::vector<Space> v27_3_outputs;
        v27_3_outputs.reserve(v27_3_branches.size());
        for (const auto& v27_3_branch : v27_3_branches) {
          const Path v27_3_head{v27_3_branch.first};
          const Space& v27_3_tail = v27_3_branch.second;
          const Path v28_2 = concat_path(v27_2,v27_3_head);
          const auto v28_3_branches = branches(c,v27_3_tail);
          std::vector<Space> v28_3_outputs;
          v28_3_outputs.reserve(v28_3_branches.size());
          for (const auto& v28_3_branch : v28_3_branches) {
            const Path v28_3_head{v28_3_branch.first};
            const Space& v28_3_tail = v28_3_branch.second;
            const Path v29_2 = concat_path(v28_2,v28_3_head);
            const auto v29_3_branches = branches(c,v28_3_tail);
            std::vector<Space> v29_3_outputs;
            v29_3_outputs.reserve(v29_3_branches.size());
            for (const auto& v29_3_branch : v29_3_branches) {
              const Path v29_3_head{v29_3_branch.first};
              const Space& v29_3_tail = v29_3_branch.second;
              const auto v30_2_branches = branches(c,v29_3_tail);
              std::vector<Space> v30_2_outputs;
              v30_2_outputs.reserve(v30_2_branches.size());
              for (const auto& v30_2_branch : v30_2_branches) {
                const Path v30_2_head{v30_2_branch.first};
                const Space& v30_2_tail = v30_2_branch.second;
                const Path v31_2 = concat_path(v29_3_head,v30_2_head);
                const auto v31_3_branches = branches(c,v30_2_tail);
                std::vector<Space> v31_3_outputs;
                v31_3_outputs.reserve(v31_3_branches.size());
                for (const auto& v31_3_branch : v31_3_branches) {
                  const Path v31_3_head{v31_3_branch.first};
                  const Space& v31_3_tail = v31_3_branch.second;
                  const Path v32_2 = concat_path(v31_2,v31_3_head);
                  const auto v32_3_branches = branches(c,v31_3_tail);
                  std::vector<Space> v32_3_outputs;
                  v32_3_outputs.reserve(v32_3_branches.size());
                  for (const auto& v32_3_branch : v32_3_branches) {
                    const Path v32_3_head{v32_3_branch.first};
                    const Space& v32_3_tail = v32_3_branch.second;
                    const Path v33_2 = concat_path(v32_2,v32_3_head);
                    const Space v33_3 = routine_5(c, v33_2, v29_2, v32_3_tail, v0_174);
                    v32_3_outputs.push_back(v33_3);
                  }
                  const Space v32_3 = join_outputs(std::move(v32_3_outputs));
                  v31_3_outputs.push_back(v32_3);
                }
                const Space v31_3 = join_outputs(std::move(v31_3_outputs));
                v30_2_outputs.push_back(v31_3);
              }
              const Space v30_2 = join_outputs(std::move(v30_2_outputs));
              v29_3_outputs.push_back(v30_2);
            }
            const Space v29_3 = join_outputs(std::move(v29_3_outputs));
            v28_3_outputs.push_back(v29_3);
          }
          const Space v28_3 = join_outputs(std::move(v28_3_outputs));
          v27_3_outputs.push_back(v28_3);
        }
        const Space v27_3 = join_outputs(std::move(v27_3_outputs));
        v26_2_outputs.push_back(v27_3);
      }
      const Space v26_2 = join_outputs(std::move(v26_2_outputs));
      v1_11_outputs.push_back(v26_2);
    }
    const Space v1_11 = join_outputs(std::move(v1_11_outputs));
    const Space v1_12 = unite(v1_9,v1_11);
    const Space v1_13 = unwrap(v0_174,constant_31);
    const Space v1_14 = subtract(v1_12,v1_13);
    const Space v1_15 = unwrap(v0_174,constant_32);
    const Space v1_16 = subtract(v1_14,v1_15);
    const Space v1_17 = wrap(v1_16,constant_31);
    const Space v1_18 = unite(v1_1,v1_6);
    const Space v1_19 = wrap(v1_18,constant_29);
    const Space v1_20 = unite(v1_17,v1_19);
    const Space v1_21 = unite(v1_20,v0_174);
    Space v0_174_next = unite(v0_174,v1_21);
    if (equal(v0_174_next,v0_174)) break;
    v0_174 = std::move(v0_174_next);
  }
  const Space v0_175 = unwrap(v0_174,constant_32);
  return v0_175;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v34_3 = wrap(s0,p0);
  const Space v34_4 = wrap(v34_3,p1);
  const Space v34_6 = wrap(v34_4,constant_28);
  return v34_6;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v35_5 = unwrap(s1,constant_29);
  const Space v35_7 = unwrap(v35_5,constant_28);
  const Space v35_8 = unwrap(v35_7,p0);
  const auto v35_10_branches = branches(c,v35_8);
  std::vector<Space> v35_10_outputs;
  v35_10_outputs.reserve(v35_10_branches.size());
  for (const auto& v35_10_branch : v35_10_branches) {
    const Path v35_10_head{v35_10_branch.first};
    const Space& v35_10_tail = v35_10_branch.second;
    const auto v36_2_branches = branches(c,v35_10_tail);
    std::vector<Space> v36_2_outputs;
    v36_2_outputs.reserve(v36_2_branches.size());
    for (const auto& v36_2_branch : v36_2_branches) {
      const Path v36_2_head{v36_2_branch.first};
      const Space& v36_2_tail = v36_2_branch.second;
      const Path v37_2 = concat_path(v35_10_head,v36_2_head);
      const auto v37_3_branches = branches(c,v36_2_tail);
      std::vector<Space> v37_3_outputs;
      v37_3_outputs.reserve(v37_3_branches.size());
      for (const auto& v37_3_branch : v37_3_branches) {
        const Path v37_3_head{v37_3_branch.first};
        const Space& v37_3_tail = v37_3_branch.second;
        const Space v38_2 = subtract(v37_3_tail,constant_2);
        const Path v38_3 = concat_path(v37_2,v37_3_head);
        const Space v38_4 = wrap(v38_2,v38_3);
        v37_3_outputs.push_back(v38_4);
      }
      const Space v37_3 = join_outputs(std::move(v37_3_outputs));
      v36_2_outputs.push_back(v37_3);
    }
    const Space v36_2 = join_outputs(std::move(v36_2_outputs));
    v35_10_outputs.push_back(v36_2);
  }
  const Space v35_10 = join_outputs(std::move(v35_10_outputs));
  const Space v35_11 = wrap(v35_10,p1);
  return v35_11;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v39_5 = unwrap(s1,constant_26);
  const Space v39_7 = unwrap(v39_5,constant_28);
  const Space v39_8 = unwrap(v39_7,p0);
  const auto v39_10_branches = branches(c,v39_8);
  std::vector<Space> v39_10_outputs;
  v39_10_outputs.reserve(v39_10_branches.size());
  for (const auto& v39_10_branch : v39_10_branches) {
    const Path v39_10_head{v39_10_branch.first};
    const Space& v39_10_tail = v39_10_branch.second;
    const auto v40_2_branches = branches(c,v39_10_tail);
    std::vector<Space> v40_2_outputs;
    v40_2_outputs.reserve(v40_2_branches.size());
    for (const auto& v40_2_branch : v40_2_branches) {
      const Path v40_2_head{v40_2_branch.first};
      const Space& v40_2_tail = v40_2_branch.second;
      const Path v41_2 = concat_path(v39_10_head,v40_2_head);
      const auto v41_3_branches = branches(c,v40_2_tail);
      std::vector<Space> v41_3_outputs;
      v41_3_outputs.reserve(v41_3_branches.size());
      for (const auto& v41_3_branch : v41_3_branches) {
        const Path v41_3_head{v41_3_branch.first};
        const Space& v41_3_tail = v41_3_branch.second;
        const Space v42_2 = subtract(v41_3_tail,constant_2);
        const Path v42_3 = concat_path(v41_2,v41_3_head);
        const Space v42_4 = wrap(v42_2,v42_3);
        v41_3_outputs.push_back(v42_4);
      }
      const Space v41_3 = join_outputs(std::move(v41_3_outputs));
      v40_2_outputs.push_back(v41_3);
    }
    const Space v40_2 = join_outputs(std::move(v40_2_outputs));
    v39_10_outputs.push_back(v40_2);
  }
  const Space v39_10 = join_outputs(std::move(v39_10_outputs));
  const Space v39_11 = wrap(v39_10,p1);
  return v39_11;
}

static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v43_3 = wrap(s0,p0);
  const Space v43_4 = wrap(v43_3,p1);
  return v43_4;
}

static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v44_5 = unwrap(s1,constant_26);
  const Space v44_7 = unwrap(v44_5,constant_28);
  const Space v44_8 = unwrap(v44_7,p0);
  const auto v44_10_branches = branches(c,v44_8);
  std::vector<Space> v44_10_outputs;
  v44_10_outputs.reserve(v44_10_branches.size());
  for (const auto& v44_10_branch : v44_10_branches) {
    const Path v44_10_head{v44_10_branch.first};
    const Space& v44_10_tail = v44_10_branch.second;
    const auto v45_2_branches = branches(c,v44_10_tail);
    std::vector<Space> v45_2_outputs;
    v45_2_outputs.reserve(v45_2_branches.size());
    for (const auto& v45_2_branch : v45_2_branches) {
      const Path v45_2_head{v45_2_branch.first};
      const Space& v45_2_tail = v45_2_branch.second;
      const Path v46_2 = concat_path(v44_10_head,v45_2_head);
      const auto v46_3_branches = branches(c,v45_2_tail);
      std::vector<Space> v46_3_outputs;
      v46_3_outputs.reserve(v46_3_branches.size());
      for (const auto& v46_3_branch : v46_3_branches) {
        const Path v46_3_head{v46_3_branch.first};
        const Space& v46_3_tail = v46_3_branch.second;
        const Space v47_2 = subtract(v46_3_tail,constant_2);
        const Path v47_3 = concat_path(v46_2,v46_3_head);
        const Space v47_4 = wrap(v47_2,v47_3);
        v46_3_outputs.push_back(v47_4);
      }
      const Space v46_3 = join_outputs(std::move(v46_3_outputs));
      v45_2_outputs.push_back(v46_3);
    }
    const Space v45_2 = join_outputs(std::move(v45_2_outputs));
    v44_10_outputs.push_back(v45_2);
  }
  const Space v44_10 = join_outputs(std::move(v44_10_outputs));
  const Space v44_11 = wrap(v44_10,p1);
  return v44_11;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
