#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("18 12 1 1 1 2 2 1 2 1 1 1 2 2 12 1 1 1 2 2 2 1 1 1 1 2 2 10 1 1 2 2 1 2 1 1 2 2 10 1 1 2 2 2 1 1 1 2 2 11 1 2 1 1 2 2 1 2 1 2 2 11 1 2 1 1 2 2 2 1 1 2 2 13 1 2 1 2 2 1 2 1 1 1 1 2 2 13 1 2 1 2 2 2 1 1 1 1 1 2 2 10 1 2 2 1 1 1 2 1 2 2 11 1 2 2 2 1 1 1 1 1 2 2 14 2 1 1 1 2 2 1 1 1 2 1 1 2 2 14 2 1 1 1 2 2 2 1 2 1 1 1 2 2 12 2 1 1 2 2 2 1 1 2 1 2 2 12 2 1 1 2 2 2 1 2 1 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 10 2 1 2 2 2 1 2 1 2 2 7 2 2 1 1 1 2 2 6 2 2 2 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("18 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 2 2 1 2 1 1 1 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 1 2 1 1 1 2 2 10 1 1 2 2 1 1 2 1 2 2 10 1 1 2 2 1 2 1 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 12 1 2 1 2 2 1 2 1 2 1 2 2 9 1 2 2 1 1 1 1 2 2 8 1 2 2 1 2 1 2 2 14 2 1 1 1 2 2 1 1 1 2 1 1 2 2 11 2 1 1 1 2 2 2 1 1 2 2 12 2 1 1 2 2 1 2 1 2 1 2 2 12 2 1 1 2 2 2 1 1 2 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 11 2 1 2 2 2 1 1 1 1 2 2 9 2 2 1 1 1 2 1 2 2 7 2 2 1 1 1 2 2");
static const Path constant_5 = Path{1,2};
static const Space constant_6 = literal_text("11 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 2 2 2 1 2 1 1 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 2 1 2 1 1 2 2 10 1 1 2 2 1 1 2 1 2 2 10 1 1 2 2 2 1 2 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 9 1 2 2 1 1 1 1 2 2 9 1 2 2 2 1 1 1 2 2 5 2 1 1 2 2 5 2 2 1 2 2");
static const Path constant_7 = Path{1,2,1,2,1,1,2,2};
static const Space constant_8 = literal_text("47 24 1 1 1 1 2 1 2 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 1 2 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 1 2 2 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 1 2 2 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 1 2 2 2 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 2 2 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 2 2 1 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 2 2 1 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 2 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 2 1 2 2 2 1 2 1 2 2 19 1 1 1 1 2 1 2 2 2 2 1 1 2 2 1 1 1 2 2 18 1 1 1 1 2 1 2 2 2 2 1 1 2 2 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 2 1 1 2 2 1 1 2 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 2 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 2 1 2 1 2 2 1 1 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 1 2 1 2 2 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 1 2 1 2 2 2 1 1 1 2 2 17 1 1 1 1 2 1 2 2 2 2 1 2 2 1 1 2 2 17 1 1 1 1 2 1 2 2 2 2 1 2 2 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 2 1 1 1 2 2 1 1 2 1 2 2 22 1 1 1 1 2 1 2 2 2 2 2 1 1 1 2 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 2 1 2 2 1 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 2 2 2 1 1 2 2 1 1 1 1 2 2 20 1 1 1 1 2 1 2 2 2 2 2 1 1 2 2 1 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 1 2 2 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 2 2 1 2 1 2 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 2 1 2 2 1 1 1 2 1 2 2 19 1 1 1 1 2 1 2 2 2 2 2 1 2 2 1 1 1 2 2");
static const Path constant_9 = Path{1,1,1,1,2,1,2,2};
static const Path constant_10 = Path{2,1,1,2,1,1,2,2};
static const Path constant_11 = Path{2,2};
static const Path constant_12 = Path{1,1,1,1,2,1,2,2,2,1,1,2,1,1,2,2};
static const Path constant_13 = Path{1,2,1,2,1,1,2,2,2,1,1,2,1,1,2,2};
static const Space constant_14 = literal_text("1 1 2");
static const Space constant_15 = singleton(Path{});
static Space routine_0(Context& c);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_84(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_0(Context& c) {
  Space v0_14;
  if (!constant_0.empty()) {
    Space v1_13;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_6);
      const Space v2_12 = unite(v2_8,v2_11);
      v1_13 = compose(constant_0,v2_12);
    }
    v0_14 = compose(constant_0,v1_13);
  }
  const Space v0_16 = wrap(v0_14,constant_7);
  const Space v0_18 = unite(v0_16,constant_8);
  Space v0_60 = v0_18;
  for (;;) {
    const Space v3_1 = unwrap(v0_60,constant_9);
    const Space v3_2 = unwrap(v0_60,constant_7);
    const Space v3_3 = unite(v3_1,v3_2);
    const Space v3_4 = wrap(v3_3,constant_9);
    const Space v3_5 = unwrap(v3_1,constant_10);
    Space v3_6_result;
    for (int v3_6_label = 1; v3_6_label <= 2; ++v3_6_label) {
      const Space v3_6_tail = child(v3_5,v3_6_label);
      if (v3_6_tail.empty()) continue;
      const Path v3_6_head{v3_6_label};
      const Space v4_2 = singleton(v3_6_head);
      const Space v4_3 = intersect(constant_14,v4_2);
      const Space v4_4 = (has_head(v4_3) ? constant_15 : Space{});
      const Space v4_5 = subtract(constant_0,v4_4);
      Space v4_7;
      if (!v4_5.empty()) {
        Space v5_6_result;
        for (int v5_6_label = 1; v5_6_label <= 2; ++v5_6_label) {
          const Space v5_6_tail = child(v3_6_tail,v5_6_label);
          if (v5_6_tail.empty()) continue;
          const Path v5_6_head{v5_6_label};
          const Space v6_2 = singleton(v5_6_head);
          const Space v6_3 = intersect(constant_14,v6_2);
          const Space v6_4 = (has_head(v6_3) ? constant_15 : Space{});
          const Space v6_5 = subtract(constant_0,v6_4);
          Space v6_8;
          if (!v6_5.empty()) {
            const Path v7_6 = concat_path(v3_6_head,v5_6_head);
            const Space v7_7 = routine_3(c, v7_6, v5_6_tail, v0_60);
            v6_8 = compose(v6_5,v7_7);
          }
          const Space v6_9 = intersect(constant_14,v6_2);
          const Space v6_10 = (has_head(v6_9) ? constant_15 : Space{});
          Space v6_12;
          if (!v6_10.empty()) {
            const Path v8_6 = concat_path(v3_6_head,v5_6_head);
            const Space v8_11 = routine_4(c, v8_6, v5_6_tail, v0_60);
            v6_12 = compose(v6_10,v8_11);
          }
          const Space v6_13 = unite(v6_8,v6_12);
          v5_6_result = unite(v5_6_result,v6_13);
        }
        const Space v5_6 = std::move(v5_6_result);
        v4_7 = compose(v4_5,v5_6);
      }
      const Space v4_8 = intersect(constant_14,v4_2);
      const Space v4_9 = (has_head(v4_8) ? constant_15 : Space{});
      Space v4_11;
      if (!v4_9.empty()) {
        Space v9_10_result;
        for (int v9_10_label = 1; v9_10_label <= 2; ++v9_10_label) {
          const Space v9_10_tail = child(v3_6_tail,v9_10_label);
          if (v9_10_tail.empty()) continue;
          const Path v9_10_head{v9_10_label};
          const Space v10_2 = singleton(v9_10_head);
          const Space v10_3 = intersect(constant_14,v10_2);
          const Space v10_4 = (has_head(v10_3) ? constant_15 : Space{});
          const Space v10_5 = subtract(constant_0,v10_4);
          Space v10_8;
          if (!v10_5.empty()) {
            const Path v11_6 = concat_path(v3_6_head,v9_10_head);
            const Space v11_7 = routine_3(c, v11_6, v9_10_tail, v0_60);
            v10_8 = compose(v10_5,v11_7);
          }
          const Space v10_9 = intersect(constant_14,v10_2);
          const Space v10_10 = (has_head(v10_9) ? constant_15 : Space{});
          Space v10_12;
          if (!v10_10.empty()) {
            const Path v12_6 = concat_path(v3_6_head,v9_10_head);
            const Space v12_11 = routine_5(c, v12_6, v9_10_tail, v0_60);
            v10_12 = compose(v10_10,v12_11);
          }
          const Space v10_13 = unite(v10_8,v10_12);
          v9_10_result = unite(v9_10_result,v10_13);
        }
        const Space v9_10 = std::move(v9_10_result);
        v4_11 = compose(v4_9,v9_10);
      }
      const Space v4_12 = unite(v4_7,v4_11);
      v3_6_result = unite(v3_6_result,v4_12);
    }
    const Space v3_6 = std::move(v3_6_result);
    const Space v3_7 = unwrap(v3_1,constant_11);
    Space v3_8_result;
    for (int v3_8_label = 1; v3_8_label <= 2; ++v3_8_label) {
      const Space v3_8_tail = child(v3_7,v3_8_label);
      if (v3_8_tail.empty()) continue;
      const Path v3_8_head{v3_8_label};
      const Space v13_2 = singleton(v3_8_head);
      const Space v13_3 = intersect(constant_14,v13_2);
      const Space v13_4 = (has_head(v13_3) ? constant_15 : Space{});
      const Space v13_5 = subtract(constant_0,v13_4);
      Space v13_7;
      if (!v13_5.empty()) {
        Space v14_6_result;
        for (int v14_6_label = 1; v14_6_label <= 2; ++v14_6_label) {
          const Space v14_6_tail = child(v3_8_tail,v14_6_label);
          if (v14_6_tail.empty()) continue;
          const Path v14_6_head{v14_6_label};
          const Space v15_2 = singleton(v14_6_head);
          const Space v15_3 = intersect(constant_14,v15_2);
          const Space v15_4 = (has_head(v15_3) ? constant_15 : Space{});
          const Space v15_5 = subtract(constant_0,v15_4);
          Space v15_8;
          if (!v15_5.empty()) {
            const Path v16_6 = concat_path(v3_8_head,v14_6_head);
            const Space v16_7 = routine_6(c, v16_6, v14_6_tail);
            v15_8 = compose(v15_5,v16_7);
          }
          const Space v15_9 = intersect(constant_14,v15_2);
          const Space v15_10 = (has_head(v15_9) ? constant_15 : Space{});
          Space v15_12;
          if (!v15_10.empty()) {
            const Path v17_6 = concat_path(v3_8_head,v14_6_head);
            const Space v17_11 = routine_7(c, v17_6, v14_6_tail);
            v15_12 = compose(v15_10,v17_11);
          }
          const Space v15_13 = unite(v15_8,v15_12);
          v14_6_result = unite(v14_6_result,v15_13);
        }
        const Space v14_6 = std::move(v14_6_result);
        v13_7 = compose(v13_5,v14_6);
      }
      const Space v13_8 = intersect(constant_14,v13_2);
      const Space v13_9 = (has_head(v13_8) ? constant_15 : Space{});
      Space v13_11;
      if (!v13_9.empty()) {
        Space v18_10_result;
        for (int v18_10_label = 1; v18_10_label <= 2; ++v18_10_label) {
          const Space v18_10_tail = child(v3_8_tail,v18_10_label);
          if (v18_10_tail.empty()) continue;
          const Path v18_10_head{v18_10_label};
          const Space v19_2 = singleton(v18_10_head);
          const Space v19_3 = intersect(constant_14,v19_2);
          const Space v19_4 = (has_head(v19_3) ? constant_15 : Space{});
          const Space v19_5 = subtract(constant_0,v19_4);
          Space v19_8;
          if (!v19_5.empty()) {
            const Path v20_6 = concat_path(v3_8_head,v18_10_head);
            const Space v20_7 = routine_6(c, v20_6, v18_10_tail);
            v19_8 = compose(v19_5,v20_7);
          }
          const Space v19_9 = intersect(constant_14,v19_2);
          const Space v19_10 = (has_head(v19_9) ? constant_15 : Space{});
          Space v19_12;
          if (!v19_10.empty()) {
            const Path v21_6 = concat_path(v3_8_head,v18_10_head);
            const Space v21_11 = routine_8(c, v21_6, v18_10_tail);
            v19_12 = compose(v19_10,v21_11);
          }
          const Space v19_13 = unite(v19_8,v19_12);
          v18_10_result = unite(v18_10_result,v19_13);
        }
        const Space v18_10 = std::move(v18_10_result);
        v13_11 = compose(v13_9,v18_10);
      }
      const Space v13_12 = unite(v13_7,v13_11);
      v3_8_result = unite(v3_8_result,v13_12);
    }
    const Space v3_8 = std::move(v3_8_result);
    const Space v3_9 = unite(v3_6,v3_8);
    const Space v3_10 = unwrap(v3_2,constant_10);
    Space v3_11_result;
    for (int v3_11_label = 1; v3_11_label <= 2; ++v3_11_label) {
      const Space v3_11_tail = child(v3_10,v3_11_label);
      if (v3_11_tail.empty()) continue;
      const Path v3_11_head{v3_11_label};
      const Space v22_2 = singleton(v3_11_head);
      const Space v22_3 = intersect(constant_14,v22_2);
      const Space v22_4 = (has_head(v22_3) ? constant_15 : Space{});
      const Space v22_5 = subtract(constant_0,v22_4);
      Space v22_7;
      if (!v22_5.empty()) {
        Space v23_6_result;
        for (int v23_6_label = 1; v23_6_label <= 2; ++v23_6_label) {
          const Space v23_6_tail = child(v3_11_tail,v23_6_label);
          if (v23_6_tail.empty()) continue;
          const Path v23_6_head{v23_6_label};
          const Space v24_2 = singleton(v23_6_head);
          const Space v24_3 = intersect(constant_14,v24_2);
          const Space v24_4 = (has_head(v24_3) ? constant_15 : Space{});
          const Space v24_5 = subtract(constant_0,v24_4);
          Space v24_8;
          if (!v24_5.empty()) {
            const Path v25_6 = concat_path(v3_11_head,v23_6_head);
            const Space v25_7 = routine_9(c, v25_6, v23_6_tail, v0_60);
            v24_8 = compose(v24_5,v25_7);
          }
          const Space v24_9 = intersect(constant_14,v24_2);
          const Space v24_10 = (has_head(v24_9) ? constant_15 : Space{});
          Space v24_12;
          if (!v24_10.empty()) {
            const Path v26_6 = concat_path(v3_11_head,v23_6_head);
            const Space v26_11 = routine_10(c, v26_6, v23_6_tail, v0_60);
            v24_12 = compose(v24_10,v26_11);
          }
          const Space v24_13 = unite(v24_8,v24_12);
          v23_6_result = unite(v23_6_result,v24_13);
        }
        const Space v23_6 = std::move(v23_6_result);
        v22_7 = compose(v22_5,v23_6);
      }
      const Space v22_8 = intersect(constant_14,v22_2);
      const Space v22_9 = (has_head(v22_8) ? constant_15 : Space{});
      Space v22_11;
      if (!v22_9.empty()) {
        Space v27_10_result;
        for (int v27_10_label = 1; v27_10_label <= 2; ++v27_10_label) {
          const Space v27_10_tail = child(v3_11_tail,v27_10_label);
          if (v27_10_tail.empty()) continue;
          const Path v27_10_head{v27_10_label};
          const Space v28_2 = singleton(v27_10_head);
          const Space v28_3 = intersect(constant_14,v28_2);
          const Space v28_4 = (has_head(v28_3) ? constant_15 : Space{});
          const Space v28_5 = subtract(constant_0,v28_4);
          Space v28_8;
          if (!v28_5.empty()) {
            const Path v29_6 = concat_path(v3_11_head,v27_10_head);
            const Space v29_7 = routine_9(c, v29_6, v27_10_tail, v0_60);
            v28_8 = compose(v28_5,v29_7);
          }
          const Space v28_9 = intersect(constant_14,v28_2);
          const Space v28_10 = (has_head(v28_9) ? constant_15 : Space{});
          Space v28_12;
          if (!v28_10.empty()) {
            const Path v30_6 = concat_path(v3_11_head,v27_10_head);
            const Space v30_11 = routine_11(c, v30_6, v27_10_tail, v0_60);
            v28_12 = compose(v28_10,v30_11);
          }
          const Space v28_13 = unite(v28_8,v28_12);
          v27_10_result = unite(v27_10_result,v28_13);
        }
        const Space v27_10 = std::move(v27_10_result);
        v22_11 = compose(v22_9,v27_10);
      }
      const Space v22_12 = unite(v22_7,v22_11);
      v3_11_result = unite(v3_11_result,v22_12);
    }
    const Space v3_11 = std::move(v3_11_result);
    const Space v3_12 = unite(v3_9,v3_11);
    Space v3_13_result;
    for (int v3_13_label = 1; v3_13_label <= 2; ++v3_13_label) {
      const Space v3_13_tail = child(v3_10,v3_13_label);
      if (v3_13_tail.empty()) continue;
      const Path v3_13_head{v3_13_label};
      const Space v31_2 = singleton(v3_13_head);
      const Space v31_3 = intersect(constant_14,v31_2);
      const Space v31_4 = (has_head(v31_3) ? constant_15 : Space{});
      const Space v31_5 = subtract(constant_0,v31_4);
      Space v31_7;
      if (!v31_5.empty()) {
        Space v32_6_result;
        for (int v32_6_label = 1; v32_6_label <= 2; ++v32_6_label) {
          const Space v32_6_tail = child(v3_13_tail,v32_6_label);
          if (v32_6_tail.empty()) continue;
          const Path v32_6_head{v32_6_label};
          const Space v33_2 = singleton(v32_6_head);
          const Space v33_3 = intersect(constant_14,v33_2);
          const Space v33_4 = (has_head(v33_3) ? constant_15 : Space{});
          const Space v33_5 = subtract(constant_0,v33_4);
          Space v33_8;
          if (!v33_5.empty()) {
            const Path v34_6 = concat_path(v3_13_head,v32_6_head);
            const Space v34_7 = routine_12(c, v34_6, v32_6_tail, v0_60);
            v33_8 = compose(v33_5,v34_7);
          }
          const Space v33_9 = intersect(constant_14,v33_2);
          const Space v33_10 = (has_head(v33_9) ? constant_15 : Space{});
          Space v33_12;
          if (!v33_10.empty()) {
            const Path v35_6 = concat_path(v3_13_head,v32_6_head);
            const Space v35_11 = routine_13(c, v35_6, v32_6_tail, v0_60);
            v33_12 = compose(v33_10,v35_11);
          }
          const Space v33_13 = unite(v33_8,v33_12);
          v32_6_result = unite(v32_6_result,v33_13);
        }
        const Space v32_6 = std::move(v32_6_result);
        v31_7 = compose(v31_5,v32_6);
      }
      const Space v31_8 = intersect(constant_14,v31_2);
      const Space v31_9 = (has_head(v31_8) ? constant_15 : Space{});
      Space v31_11;
      if (!v31_9.empty()) {
        Space v36_10_result;
        for (int v36_10_label = 1; v36_10_label <= 2; ++v36_10_label) {
          const Space v36_10_tail = child(v3_13_tail,v36_10_label);
          if (v36_10_tail.empty()) continue;
          const Path v36_10_head{v36_10_label};
          const Space v37_2 = singleton(v36_10_head);
          const Space v37_3 = intersect(constant_14,v37_2);
          const Space v37_4 = (has_head(v37_3) ? constant_15 : Space{});
          const Space v37_5 = subtract(constant_0,v37_4);
          Space v37_8;
          if (!v37_5.empty()) {
            const Path v38_6 = concat_path(v3_13_head,v36_10_head);
            const Space v38_7 = routine_12(c, v38_6, v36_10_tail, v0_60);
            v37_8 = compose(v37_5,v38_7);
          }
          const Space v37_9 = intersect(constant_14,v37_2);
          const Space v37_10 = (has_head(v37_9) ? constant_15 : Space{});
          Space v37_12;
          if (!v37_10.empty()) {
            const Path v39_6 = concat_path(v3_13_head,v36_10_head);
            const Space v39_11 = routine_14(c, v39_6, v36_10_tail, v0_60);
            v37_12 = compose(v37_10,v39_11);
          }
          const Space v37_13 = unite(v37_8,v37_12);
          v36_10_result = unite(v36_10_result,v37_13);
        }
        const Space v36_10 = std::move(v36_10_result);
        v31_11 = compose(v31_9,v36_10);
      }
      const Space v31_12 = unite(v31_7,v31_11);
      v3_13_result = unite(v3_13_result,v31_12);
    }
    const Space v3_13 = std::move(v3_13_result);
    const Space v3_14 = unite(v3_12,v3_13);
    const Space v3_15 = unwrap(v0_60,constant_12);
    const Space v3_16 = subtract(v3_14,v3_15);
    const Space v3_17 = unwrap(v0_60,constant_13);
    const Space v3_18 = subtract(v3_16,v3_17);
    const Space v3_19 = wrap(v3_18,constant_13);
    const Space v3_20 = unite(v3_4,v3_19);
    const Space v3_21 = unite(v3_20,v0_60);
    Space v0_60_next = unite(v0_60,v3_21);
    if (equal(v0_60_next,v0_60)) break;
    v0_60 = std::move(v0_60_next);
  }
  const Space v0_61 = unwrap(v0_60,constant_12);
  return v0_61;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v40_11_result;
  for (int v40_11_label = 1; v40_11_label <= 2; ++v40_11_label) {
    const Space v40_11_tail = child(s0,v40_11_label);
    if (v40_11_tail.empty()) continue;
    const Path v40_11_head{v40_11_label};
    const Space v41_2 = singleton(v40_11_head);
    const Space v41_3 = intersect(constant_14,v41_2);
    const Space v41_4 = (has_head(v41_3) ? constant_15 : Space{});
    const Space v41_5 = subtract(constant_0,v41_4);
    Space v41_8;
    if (!v41_5.empty()) {
      const Path v42_6 = concat_path(p0,v40_11_head);
      Space v42_7_result;
      for (int v42_7_label = 1; v42_7_label <= 2; ++v42_7_label) {
        const Space v42_7_tail = child(v40_11_tail,v42_7_label);
        if (v42_7_tail.empty()) continue;
        const Path v42_7_head{v42_7_label};
        const Space v43_2 = singleton(v42_7_head);
        const Space v43_3 = intersect(constant_14,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_15 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_8;
        if (!v43_5.empty()) {
          const Path v44_6 = concat_path(v42_6,v42_7_head);
          const Space v44_7 = routine_15(c, v44_6, v42_7_tail);
          v43_8 = compose(v43_5,v44_7);
        }
        const Space v43_9 = intersect(constant_14,v43_2);
        const Space v43_10 = (has_head(v43_9) ? constant_15 : Space{});
        Space v43_12;
        if (!v43_10.empty()) {
          const Path v45_6 = concat_path(v42_6,v42_7_head);
          const Space v45_11 = routine_16(c, v45_6, v42_7_tail);
          v43_12 = compose(v43_10,v45_11);
        }
        const Space v43_13 = unite(v43_8,v43_12);
        v42_7_result = unite(v42_7_result,v43_13);
      }
      const Space v42_7 = std::move(v42_7_result);
      v41_8 = compose(v41_5,v42_7);
    }
    const Space v41_9 = intersect(constant_14,v41_2);
    const Space v41_10 = (has_head(v41_9) ? constant_15 : Space{});
    Space v41_12;
    if (!v41_10.empty()) {
      const Path v46_6 = concat_path(p0,v40_11_head);
      Space v46_11_result;
      for (int v46_11_label = 1; v46_11_label <= 2; ++v46_11_label) {
        const Space v46_11_tail = child(v40_11_tail,v46_11_label);
        if (v46_11_tail.empty()) continue;
        const Path v46_11_head{v46_11_label};
        const Space v47_2 = singleton(v46_11_head);
        const Space v47_3 = intersect(constant_14,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_15 : Space{});
        const Space v47_5 = subtract(constant_0,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_11_head);
          const Space v48_7 = routine_15(c, v48_6, v46_11_tail);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_14,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_15 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_11_head);
          const Space v49_11 = routine_17(c, v49_6, v46_11_tail);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_11_result = unite(v46_11_result,v47_13);
      }
      const Space v46_11 = std::move(v46_11_result);
      v41_12 = compose(v41_10,v46_11);
    }
    const Space v41_13 = unite(v41_8,v41_12);
    v40_11_result = unite(v40_11_result,v41_13);
  }
  const Space v40_11 = std::move(v40_11_result);
  return v40_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v50_11_result;
  for (int v50_11_label = 1; v50_11_label <= 2; ++v50_11_label) {
    const Space v50_11_tail = child(s0,v50_11_label);
    if (v50_11_tail.empty()) continue;
    const Path v50_11_head{v50_11_label};
    const Space v51_2 = singleton(v50_11_head);
    const Space v51_3 = intersect(constant_14,v51_2);
    const Space v51_4 = (has_head(v51_3) ? constant_15 : Space{});
    const Space v51_5 = subtract(constant_0,v51_4);
    Space v51_8;
    if (!v51_5.empty()) {
      const Path v52_6 = concat_path(p0,v50_11_head);
      Space v52_7_result;
      for (int v52_7_label = 1; v52_7_label <= 2; ++v52_7_label) {
        const Space v52_7_tail = child(v50_11_tail,v52_7_label);
        if (v52_7_tail.empty()) continue;
        const Path v52_7_head{v52_7_label};
        const Space v53_2 = singleton(v52_7_head);
        const Space v53_3 = intersect(constant_14,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_15 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_7_head);
          const Space v54_7 = routine_15(c, v54_6, v52_7_tail);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_14,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_15 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_7_head);
          const Space v55_11 = routine_16(c, v55_6, v52_7_tail);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_7_result = unite(v52_7_result,v53_13);
      }
      const Space v52_7 = std::move(v52_7_result);
      v51_8 = compose(v51_5,v52_7);
    }
    const Space v51_9 = intersect(constant_14,v51_2);
    const Space v51_10 = (has_head(v51_9) ? constant_15 : Space{});
    Space v51_12;
    if (!v51_10.empty()) {
      const Path v56_6 = concat_path(p0,v50_11_head);
      Space v56_11_result;
      for (int v56_11_label = 1; v56_11_label <= 2; ++v56_11_label) {
        const Space v56_11_tail = child(v50_11_tail,v56_11_label);
        if (v56_11_tail.empty()) continue;
        const Path v56_11_head{v56_11_label};
        const Space v57_2 = singleton(v56_11_head);
        const Space v57_3 = intersect(constant_14,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_15 : Space{});
        const Space v57_5 = subtract(constant_0,v57_4);
        Space v57_7;
        if (!v57_5.empty()) {
          const Space v58_6 = routine_18(c, v56_11_head, v56_6, v56_11_tail);
          v57_7 = compose(v57_5,v58_6);
        }
        const Space v57_8 = intersect(constant_14,v57_2);
        const Space v57_9 = (has_head(v57_8) ? constant_15 : Space{});
        Space v57_11;
        if (!v57_9.empty()) {
          const Space v59_10 = routine_19(c, v56_11_head, v56_6, v56_11_tail);
          v57_11 = compose(v57_9,v59_10);
        }
        const Space v57_12 = unite(v57_7,v57_11);
        v56_11_result = unite(v56_11_result,v57_12);
      }
      const Space v56_11 = std::move(v56_11_result);
      v51_12 = compose(v51_10,v56_11);
    }
    const Space v51_13 = unite(v51_8,v51_12);
    v50_11_result = unite(v50_11_result,v51_13);
  }
  const Space v50_11 = std::move(v50_11_result);
  return v50_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v60_12_result;
  for (int v60_12_label = 1; v60_12_label <= 2; ++v60_12_label) {
    const Space v60_12_tail = child(s0,v60_12_label);
    if (v60_12_tail.empty()) continue;
    const Path v60_12_head{v60_12_label};
    const Space v61_2 = singleton(v60_12_head);
    const Space v61_3 = intersect(constant_14,v61_2);
    const Space v61_4 = (has_head(v61_3) ? constant_15 : Space{});
    const Space v61_5 = subtract(constant_0,v61_4);
    Space v61_8;
    if (!v61_5.empty()) {
      const Path v62_6 = concat_path(p0,v60_12_head);
      Space v62_7_result;
      for (int v62_7_label = 1; v62_7_label <= 2; ++v62_7_label) {
        const Space v62_7_tail = child(v60_12_tail,v62_7_label);
        if (v62_7_tail.empty()) continue;
        const Path v62_7_head{v62_7_label};
        const Space v63_2 = singleton(v62_7_head);
        const Space v63_3 = intersect(constant_14,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_15 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_8;
        if (!v63_5.empty()) {
          const Path v64_6 = concat_path(v62_6,v62_7_head);
          const Space v64_7 = routine_20(c, v64_6, v62_7_tail, s1);
          v63_8 = compose(v63_5,v64_7);
        }
        const Space v63_9 = intersect(constant_14,v63_2);
        const Space v63_10 = (has_head(v63_9) ? constant_15 : Space{});
        Space v63_12;
        if (!v63_10.empty()) {
          const Path v65_6 = concat_path(v62_6,v62_7_head);
          const Space v65_11 = routine_21(c, v65_6, v62_7_tail, s1);
          v63_12 = compose(v63_10,v65_11);
        }
        const Space v63_13 = unite(v63_8,v63_12);
        v62_7_result = unite(v62_7_result,v63_13);
      }
      const Space v62_7 = std::move(v62_7_result);
      v61_8 = compose(v61_5,v62_7);
    }
    const Space v61_9 = intersect(constant_14,v61_2);
    const Space v61_10 = (has_head(v61_9) ? constant_15 : Space{});
    Space v61_12;
    if (!v61_10.empty()) {
      const Path v66_6 = concat_path(p0,v60_12_head);
      Space v66_11_result;
      for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
        const Space v66_11_tail = child(v60_12_tail,v66_11_label);
        if (v66_11_tail.empty()) continue;
        const Path v66_11_head{v66_11_label};
        const Space v67_2 = singleton(v66_11_head);
        const Space v67_3 = intersect(constant_14,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_15 : Space{});
        const Space v67_5 = subtract(constant_0,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_11_head);
          const Space v68_7 = routine_20(c, v68_6, v66_11_tail, s1);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_14,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_15 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_11_head);
          const Space v69_11 = routine_5(c, v69_6, v66_11_tail, s1);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_11_result = unite(v66_11_result,v67_13);
      }
      const Space v66_11 = std::move(v66_11_result);
      v61_12 = compose(v61_10,v66_11);
    }
    const Space v61_13 = unite(v61_8,v61_12);
    v60_12_result = unite(v60_12_result,v61_13);
  }
  const Space v60_12 = std::move(v60_12_result);
  return v60_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v70_12_result;
  for (int v70_12_label = 1; v70_12_label <= 2; ++v70_12_label) {
    const Space v70_12_tail = child(s0,v70_12_label);
    if (v70_12_tail.empty()) continue;
    const Path v70_12_head{v70_12_label};
    const Space v71_2 = singleton(v70_12_head);
    const Space v71_3 = intersect(constant_14,v71_2);
    const Space v71_4 = (has_head(v71_3) ? constant_15 : Space{});
    const Space v71_5 = subtract(constant_0,v71_4);
    Space v71_8;
    if (!v71_5.empty()) {
      const Path v72_6 = concat_path(p0,v70_12_head);
      Space v72_7_result;
      for (int v72_7_label = 1; v72_7_label <= 2; ++v72_7_label) {
        const Space v72_7_tail = child(v70_12_tail,v72_7_label);
        if (v72_7_tail.empty()) continue;
        const Path v72_7_head{v72_7_label};
        const Space v73_2 = singleton(v72_7_head);
        const Space v73_3 = intersect(constant_14,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_15 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_7_head);
          const Space v74_7 = routine_20(c, v74_6, v72_7_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_14,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_15 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_7_head);
          const Space v75_11 = routine_21(c, v75_6, v72_7_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_7_result = unite(v72_7_result,v73_13);
      }
      const Space v72_7 = std::move(v72_7_result);
      v71_8 = compose(v71_5,v72_7);
    }
    const Space v71_9 = intersect(constant_14,v71_2);
    const Space v71_10 = (has_head(v71_9) ? constant_15 : Space{});
    Space v71_12;
    if (!v71_10.empty()) {
      const Path v76_6 = concat_path(p0,v70_12_head);
      Space v76_11_result;
      for (int v76_11_label = 1; v76_11_label <= 2; ++v76_11_label) {
        const Space v76_11_tail = child(v70_12_tail,v76_11_label);
        if (v76_11_tail.empty()) continue;
        const Path v76_11_head{v76_11_label};
        const Space v77_2 = singleton(v76_11_head);
        const Space v77_3 = intersect(constant_14,v77_2);
        const Space v77_4 = (has_head(v77_3) ? constant_15 : Space{});
        const Space v77_5 = subtract(constant_0,v77_4);
        Space v77_7;
        if (!v77_5.empty()) {
          const Space v78_6 = routine_22(c, v76_11_head, v76_6, v76_11_tail, s1);
          v77_7 = compose(v77_5,v78_6);
        }
        const Space v77_8 = intersect(constant_14,v77_2);
        const Space v77_9 = (has_head(v77_8) ? constant_15 : Space{});
        Space v77_11;
        if (!v77_9.empty()) {
          const Space v79_10 = routine_23(c, v76_11_head, v76_6, v76_11_tail, s1);
          v77_11 = compose(v77_9,v79_10);
        }
        const Space v77_12 = unite(v77_7,v77_11);
        v76_11_result = unite(v76_11_result,v77_12);
      }
      const Space v76_11 = std::move(v76_11_result);
      v71_12 = compose(v71_10,v76_11);
    }
    const Space v71_13 = unite(v71_8,v71_12);
    v70_12_result = unite(v70_12_result,v71_13);
  }
  const Space v70_12 = std::move(v70_12_result);
  return v70_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v80_12_result;
  for (int v80_12_label = 1; v80_12_label <= 2; ++v80_12_label) {
    const Space v80_12_tail = child(s0,v80_12_label);
    if (v80_12_tail.empty()) continue;
    const Path v80_12_head{v80_12_label};
    const Space v81_2 = singleton(v80_12_head);
    const Space v81_3 = intersect(constant_14,v81_2);
    const Space v81_4 = (has_head(v81_3) ? constant_15 : Space{});
    const Space v81_5 = subtract(constant_0,v81_4);
    Space v81_7;
    if (!v81_5.empty()) {
      Space v82_6_result;
      for (int v82_6_label = 1; v82_6_label <= 2; ++v82_6_label) {
        const Space v82_6_tail = child(v80_12_tail,v82_6_label);
        if (v82_6_tail.empty()) continue;
        const Path v82_6_head{v82_6_label};
        const Space v83_2 = singleton(v82_6_head);
        const Space v83_3 = intersect(constant_14,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_15 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_8;
        if (!v83_5.empty()) {
          const Path v84_6 = concat_path(v80_12_head,v82_6_head);
          const Space v84_7 = routine_24(c, v84_6, p0, v82_6_tail, s1);
          v83_8 = compose(v83_5,v84_7);
        }
        const Space v83_9 = intersect(constant_14,v83_2);
        const Space v83_10 = (has_head(v83_9) ? constant_15 : Space{});
        Space v83_12;
        if (!v83_10.empty()) {
          const Path v85_6 = concat_path(v80_12_head,v82_6_head);
          const Space v85_11 = routine_25(c, v85_6, p0, v82_6_tail, s1);
          v83_12 = compose(v83_10,v85_11);
        }
        const Space v83_13 = unite(v83_8,v83_12);
        v82_6_result = unite(v82_6_result,v83_13);
      }
      const Space v82_6 = std::move(v82_6_result);
      v81_7 = compose(v81_5,v82_6);
    }
    const Space v81_8 = intersect(constant_14,v81_2);
    const Space v81_9 = (has_head(v81_8) ? constant_15 : Space{});
    Space v81_11;
    if (!v81_9.empty()) {
      Space v86_10_result;
      for (int v86_10_label = 1; v86_10_label <= 2; ++v86_10_label) {
        const Space v86_10_tail = child(v80_12_tail,v86_10_label);
        if (v86_10_tail.empty()) continue;
        const Path v86_10_head{v86_10_label};
        const Space v87_2 = singleton(v86_10_head);
        const Space v87_3 = intersect(constant_14,v87_2);
        const Space v87_4 = (has_head(v87_3) ? constant_15 : Space{});
        const Space v87_5 = subtract(constant_0,v87_4);
        Space v87_8;
        if (!v87_5.empty()) {
          const Path v88_6 = concat_path(v80_12_head,v86_10_head);
          const Space v88_7 = routine_24(c, v88_6, p0, v86_10_tail, s1);
          v87_8 = compose(v87_5,v88_7);
        }
        const Space v87_9 = intersect(constant_14,v87_2);
        const Space v87_10 = (has_head(v87_9) ? constant_15 : Space{});
        Space v87_12;
        if (!v87_10.empty()) {
          const Path v89_6 = concat_path(v80_12_head,v86_10_head);
          const Space v89_11 = routine_26(c, v89_6, p0, v86_10_tail, s1);
          v87_12 = compose(v87_10,v89_11);
        }
        const Space v87_13 = unite(v87_8,v87_12);
        v86_10_result = unite(v86_10_result,v87_13);
      }
      const Space v86_10 = std::move(v86_10_result);
      v81_11 = compose(v81_9,v86_10);
    }
    const Space v81_12 = unite(v81_7,v81_11);
    v80_12_result = unite(v80_12_result,v81_12);
  }
  const Space v80_12 = std::move(v80_12_result);
  return v80_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v90_11_result;
  for (int v90_11_label = 1; v90_11_label <= 2; ++v90_11_label) {
    const Space v90_11_tail = child(s0,v90_11_label);
    if (v90_11_tail.empty()) continue;
    const Path v90_11_head{v90_11_label};
    const Space v91_2 = singleton(v90_11_head);
    const Space v91_3 = intersect(constant_14,v91_2);
    const Space v91_4 = (has_head(v91_3) ? constant_15 : Space{});
    const Space v91_5 = subtract(constant_0,v91_4);
    Space v91_8;
    if (!v91_5.empty()) {
      const Path v92_6 = concat_path(p0,v90_11_head);
      Space v92_7_result;
      for (int v92_7_label = 1; v92_7_label <= 2; ++v92_7_label) {
        const Space v92_7_tail = child(v90_11_tail,v92_7_label);
        if (v92_7_tail.empty()) continue;
        const Path v92_7_head{v92_7_label};
        const Space v93_2 = singleton(v92_7_head);
        const Space v93_3 = intersect(constant_14,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_15 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v92_6,v92_7_head);
          const Space v94_7 = routine_27(c, v94_6, v92_7_tail);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_14,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_15 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v92_6,v92_7_head);
          const Space v95_11 = routine_28(c, v95_6, v92_7_tail);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_7_result = unite(v92_7_result,v93_13);
      }
      const Space v92_7 = std::move(v92_7_result);
      v91_8 = compose(v91_5,v92_7);
    }
    const Space v91_9 = intersect(constant_14,v91_2);
    const Space v91_10 = (has_head(v91_9) ? constant_15 : Space{});
    Space v91_12;
    if (!v91_10.empty()) {
      const Path v96_6 = concat_path(p0,v90_11_head);
      Space v96_11_result;
      for (int v96_11_label = 1; v96_11_label <= 2; ++v96_11_label) {
        const Space v96_11_tail = child(v90_11_tail,v96_11_label);
        if (v96_11_tail.empty()) continue;
        const Path v96_11_head{v96_11_label};
        const Space v97_2 = singleton(v96_11_head);
        const Space v97_3 = intersect(constant_14,v97_2);
        const Space v97_4 = (has_head(v97_3) ? constant_15 : Space{});
        const Space v97_5 = subtract(constant_0,v97_4);
        Space v97_8;
        if (!v97_5.empty()) {
          const Path v98_6 = concat_path(v96_6,v96_11_head);
          const Space v98_7 = routine_27(c, v98_6, v96_11_tail);
          v97_8 = compose(v97_5,v98_7);
        }
        const Space v97_9 = intersect(constant_14,v97_2);
        const Space v97_10 = (has_head(v97_9) ? constant_15 : Space{});
        Space v97_12;
        if (!v97_10.empty()) {
          const Path v99_6 = concat_path(v96_6,v96_11_head);
          const Space v99_11 = routine_8(c, v99_6, v96_11_tail);
          v97_12 = compose(v97_10,v99_11);
        }
        const Space v97_13 = unite(v97_8,v97_12);
        v96_11_result = unite(v96_11_result,v97_13);
      }
      const Space v96_11 = std::move(v96_11_result);
      v91_12 = compose(v91_10,v96_11);
    }
    const Space v91_13 = unite(v91_8,v91_12);
    v90_11_result = unite(v90_11_result,v91_13);
  }
  const Space v90_11 = std::move(v90_11_result);
  return v90_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v100_11_result;
  for (int v100_11_label = 1; v100_11_label <= 2; ++v100_11_label) {
    const Space v100_11_tail = child(s0,v100_11_label);
    if (v100_11_tail.empty()) continue;
    const Path v100_11_head{v100_11_label};
    const Space v101_2 = singleton(v100_11_head);
    const Space v101_3 = intersect(constant_14,v101_2);
    const Space v101_4 = (has_head(v101_3) ? constant_15 : Space{});
    const Space v101_5 = subtract(constant_0,v101_4);
    Space v101_8;
    if (!v101_5.empty()) {
      const Path v102_6 = concat_path(p0,v100_11_head);
      Space v102_7_result;
      for (int v102_7_label = 1; v102_7_label <= 2; ++v102_7_label) {
        const Space v102_7_tail = child(v100_11_tail,v102_7_label);
        if (v102_7_tail.empty()) continue;
        const Path v102_7_head{v102_7_label};
        const Space v103_2 = singleton(v102_7_head);
        const Space v103_3 = intersect(constant_14,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_15 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_7_head);
          const Space v104_7 = routine_27(c, v104_6, v102_7_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_14,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_15 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_7_head);
          const Space v105_11 = routine_28(c, v105_6, v102_7_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_7_result = unite(v102_7_result,v103_13);
      }
      const Space v102_7 = std::move(v102_7_result);
      v101_8 = compose(v101_5,v102_7);
    }
    const Space v101_9 = intersect(constant_14,v101_2);
    const Space v101_10 = (has_head(v101_9) ? constant_15 : Space{});
    Space v101_12;
    if (!v101_10.empty()) {
      const Path v106_6 = concat_path(p0,v100_11_head);
      Space v106_11_result;
      for (int v106_11_label = 1; v106_11_label <= 2; ++v106_11_label) {
        const Space v106_11_tail = child(v100_11_tail,v106_11_label);
        if (v106_11_tail.empty()) continue;
        const Path v106_11_head{v106_11_label};
        const Space v107_2 = singleton(v106_11_head);
        const Space v107_3 = intersect(constant_14,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_15 : Space{});
        const Space v107_5 = subtract(constant_0,v107_4);
        Space v107_7;
        if (!v107_5.empty()) {
          const Space v108_6 = routine_29(c, v106_11_head, v106_6, v106_11_tail);
          v107_7 = compose(v107_5,v108_6);
        }
        const Space v107_8 = intersect(constant_14,v107_2);
        const Space v107_9 = (has_head(v107_8) ? constant_15 : Space{});
        Space v107_11;
        if (!v107_9.empty()) {
          const Space v109_10 = routine_30(c, v106_11_head, v106_6, v106_11_tail);
          v107_11 = compose(v107_9,v109_10);
        }
        const Space v107_12 = unite(v107_7,v107_11);
        v106_11_result = unite(v106_11_result,v107_12);
      }
      const Space v106_11 = std::move(v106_11_result);
      v101_12 = compose(v101_10,v106_11);
    }
    const Space v101_13 = unite(v101_8,v101_12);
    v100_11_result = unite(v100_11_result,v101_13);
  }
  const Space v100_11 = std::move(v100_11_result);
  return v100_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v110_11_result;
  for (int v110_11_label = 1; v110_11_label <= 2; ++v110_11_label) {
    const Space v110_11_tail = child(s0,v110_11_label);
    if (v110_11_tail.empty()) continue;
    const Path v110_11_head{v110_11_label};
    const Space v111_2 = singleton(v110_11_head);
    const Space v111_3 = intersect(constant_14,v111_2);
    const Space v111_4 = (has_head(v111_3) ? constant_15 : Space{});
    const Space v111_5 = subtract(constant_0,v111_4);
    Space v111_7;
    if (!v111_5.empty()) {
      Space v112_6_result;
      for (int v112_6_label = 1; v112_6_label <= 2; ++v112_6_label) {
        const Space v112_6_tail = child(v110_11_tail,v112_6_label);
        if (v112_6_tail.empty()) continue;
        const Path v112_6_head{v112_6_label};
        const Space v113_2 = singleton(v112_6_head);
        const Space v113_3 = intersect(constant_14,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_15 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_8;
        if (!v113_5.empty()) {
          const Path v114_6 = concat_path(v110_11_head,v112_6_head);
          const Space v114_7 = routine_31(c, v114_6, p0, v112_6_tail);
          v113_8 = compose(v113_5,v114_7);
        }
        const Space v113_9 = intersect(constant_14,v113_2);
        const Space v113_10 = (has_head(v113_9) ? constant_15 : Space{});
        Space v113_12;
        if (!v113_10.empty()) {
          const Path v115_6 = concat_path(v110_11_head,v112_6_head);
          const Space v115_11 = routine_32(c, v115_6, p0, v112_6_tail);
          v113_12 = compose(v113_10,v115_11);
        }
        const Space v113_13 = unite(v113_8,v113_12);
        v112_6_result = unite(v112_6_result,v113_13);
      }
      const Space v112_6 = std::move(v112_6_result);
      v111_7 = compose(v111_5,v112_6);
    }
    const Space v111_8 = intersect(constant_14,v111_2);
    const Space v111_9 = (has_head(v111_8) ? constant_15 : Space{});
    Space v111_11;
    if (!v111_9.empty()) {
      Space v116_10_result;
      for (int v116_10_label = 1; v116_10_label <= 2; ++v116_10_label) {
        const Space v116_10_tail = child(v110_11_tail,v116_10_label);
        if (v116_10_tail.empty()) continue;
        const Path v116_10_head{v116_10_label};
        const Space v117_2 = singleton(v116_10_head);
        const Space v117_3 = intersect(constant_14,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_15 : Space{});
        const Space v117_5 = subtract(constant_0,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v110_11_head,v116_10_head);
          const Space v118_7 = routine_31(c, v118_6, p0, v116_10_tail);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_14,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_15 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v110_11_head,v116_10_head);
          const Space v119_11 = routine_33(c, v119_6, p0, v116_10_tail);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_10_result = unite(v116_10_result,v117_13);
      }
      const Space v116_10 = std::move(v116_10_result);
      v111_11 = compose(v111_9,v116_10);
    }
    const Space v111_12 = unite(v111_7,v111_11);
    v110_11_result = unite(v110_11_result,v111_12);
  }
  const Space v110_11 = std::move(v110_11_result);
  return v110_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v120_12_result;
  for (int v120_12_label = 1; v120_12_label <= 2; ++v120_12_label) {
    const Space v120_12_tail = child(s0,v120_12_label);
    if (v120_12_tail.empty()) continue;
    const Path v120_12_head{v120_12_label};
    const Space v121_2 = singleton(v120_12_head);
    const Space v121_3 = intersect(constant_14,v121_2);
    const Space v121_4 = (has_head(v121_3) ? constant_15 : Space{});
    const Space v121_5 = subtract(constant_0,v121_4);
    Space v121_8;
    if (!v121_5.empty()) {
      const Path v122_6 = concat_path(p0,v120_12_head);
      Space v122_7_result;
      for (int v122_7_label = 1; v122_7_label <= 2; ++v122_7_label) {
        const Space v122_7_tail = child(v120_12_tail,v122_7_label);
        if (v122_7_tail.empty()) continue;
        const Path v122_7_head{v122_7_label};
        const Space v123_2 = singleton(v122_7_head);
        const Space v123_3 = intersect(constant_14,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_15 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_8;
        if (!v123_5.empty()) {
          const Path v124_6 = concat_path(v122_6,v122_7_head);
          const Space v124_7 = routine_34(c, v124_6, v122_7_tail, s1);
          v123_8 = compose(v123_5,v124_7);
        }
        const Space v123_9 = intersect(constant_14,v123_2);
        const Space v123_10 = (has_head(v123_9) ? constant_15 : Space{});
        Space v123_12;
        if (!v123_10.empty()) {
          const Path v125_6 = concat_path(v122_6,v122_7_head);
          const Space v125_11 = routine_35(c, v125_6, v122_7_tail, s1);
          v123_12 = compose(v123_10,v125_11);
        }
        const Space v123_13 = unite(v123_8,v123_12);
        v122_7_result = unite(v122_7_result,v123_13);
      }
      const Space v122_7 = std::move(v122_7_result);
      v121_8 = compose(v121_5,v122_7);
    }
    const Space v121_9 = intersect(constant_14,v121_2);
    const Space v121_10 = (has_head(v121_9) ? constant_15 : Space{});
    Space v121_12;
    if (!v121_10.empty()) {
      const Path v126_6 = concat_path(p0,v120_12_head);
      Space v126_11_result;
      for (int v126_11_label = 1; v126_11_label <= 2; ++v126_11_label) {
        const Space v126_11_tail = child(v120_12_tail,v126_11_label);
        if (v126_11_tail.empty()) continue;
        const Path v126_11_head{v126_11_label};
        const Space v127_2 = singleton(v126_11_head);
        const Space v127_3 = intersect(constant_14,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_15 : Space{});
        const Space v127_5 = subtract(constant_0,v127_4);
        Space v127_8;
        if (!v127_5.empty()) {
          const Path v128_6 = concat_path(v126_6,v126_11_head);
          const Space v128_7 = routine_34(c, v128_6, v126_11_tail, s1);
          v127_8 = compose(v127_5,v128_7);
        }
        const Space v127_9 = intersect(constant_14,v127_2);
        const Space v127_10 = (has_head(v127_9) ? constant_15 : Space{});
        Space v127_12;
        if (!v127_10.empty()) {
          const Path v129_6 = concat_path(v126_6,v126_11_head);
          const Space v129_11 = routine_11(c, v129_6, v126_11_tail, s1);
          v127_12 = compose(v127_10,v129_11);
        }
        const Space v127_13 = unite(v127_8,v127_12);
        v126_11_result = unite(v126_11_result,v127_13);
      }
      const Space v126_11 = std::move(v126_11_result);
      v121_12 = compose(v121_10,v126_11);
    }
    const Space v121_13 = unite(v121_8,v121_12);
    v120_12_result = unite(v120_12_result,v121_13);
  }
  const Space v120_12 = std::move(v120_12_result);
  return v120_12;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v130_12_result;
  for (int v130_12_label = 1; v130_12_label <= 2; ++v130_12_label) {
    const Space v130_12_tail = child(s0,v130_12_label);
    if (v130_12_tail.empty()) continue;
    const Path v130_12_head{v130_12_label};
    const Space v131_2 = singleton(v130_12_head);
    const Space v131_3 = intersect(constant_14,v131_2);
    const Space v131_4 = (has_head(v131_3) ? constant_15 : Space{});
    const Space v131_5 = subtract(constant_0,v131_4);
    Space v131_8;
    if (!v131_5.empty()) {
      const Path v132_6 = concat_path(p0,v130_12_head);
      Space v132_7_result;
      for (int v132_7_label = 1; v132_7_label <= 2; ++v132_7_label) {
        const Space v132_7_tail = child(v130_12_tail,v132_7_label);
        if (v132_7_tail.empty()) continue;
        const Path v132_7_head{v132_7_label};
        const Space v133_2 = singleton(v132_7_head);
        const Space v133_3 = intersect(constant_14,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_15 : Space{});
        const Space v133_5 = subtract(constant_0,v133_4);
        Space v133_8;
        if (!v133_5.empty()) {
          const Path v134_6 = concat_path(v132_6,v132_7_head);
          const Space v134_7 = routine_34(c, v134_6, v132_7_tail, s1);
          v133_8 = compose(v133_5,v134_7);
        }
        const Space v133_9 = intersect(constant_14,v133_2);
        const Space v133_10 = (has_head(v133_9) ? constant_15 : Space{});
        Space v133_12;
        if (!v133_10.empty()) {
          const Path v135_6 = concat_path(v132_6,v132_7_head);
          const Space v135_11 = routine_35(c, v135_6, v132_7_tail, s1);
          v133_12 = compose(v133_10,v135_11);
        }
        const Space v133_13 = unite(v133_8,v133_12);
        v132_7_result = unite(v132_7_result,v133_13);
      }
      const Space v132_7 = std::move(v132_7_result);
      v131_8 = compose(v131_5,v132_7);
    }
    const Space v131_9 = intersect(constant_14,v131_2);
    const Space v131_10 = (has_head(v131_9) ? constant_15 : Space{});
    Space v131_12;
    if (!v131_10.empty()) {
      const Path v136_6 = concat_path(p0,v130_12_head);
      Space v136_11_result;
      for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
        const Space v136_11_tail = child(v130_12_tail,v136_11_label);
        if (v136_11_tail.empty()) continue;
        const Path v136_11_head{v136_11_label};
        const Space v137_2 = singleton(v136_11_head);
        const Space v137_3 = intersect(constant_14,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_15 : Space{});
        const Space v137_5 = subtract(constant_0,v137_4);
        Space v137_7;
        if (!v137_5.empty()) {
          const Space v138_6 = routine_36(c, v136_11_head, v136_6, v136_11_tail, s1);
          v137_7 = compose(v137_5,v138_6);
        }
        const Space v137_8 = intersect(constant_14,v137_2);
        const Space v137_9 = (has_head(v137_8) ? constant_15 : Space{});
        Space v137_11;
        if (!v137_9.empty()) {
          const Space v139_10 = routine_37(c, v136_11_head, v136_6, v136_11_tail, s1);
          v137_11 = compose(v137_9,v139_10);
        }
        const Space v137_12 = unite(v137_7,v137_11);
        v136_11_result = unite(v136_11_result,v137_12);
      }
      const Space v136_11 = std::move(v136_11_result);
      v131_12 = compose(v131_10,v136_11);
    }
    const Space v131_13 = unite(v131_8,v131_12);
    v130_12_result = unite(v130_12_result,v131_13);
  }
  const Space v130_12 = std::move(v130_12_result);
  return v130_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v140_12_result;
  for (int v140_12_label = 1; v140_12_label <= 2; ++v140_12_label) {
    const Space v140_12_tail = child(s0,v140_12_label);
    if (v140_12_tail.empty()) continue;
    const Path v140_12_head{v140_12_label};
    const Space v141_2 = singleton(v140_12_head);
    const Space v141_3 = intersect(constant_14,v141_2);
    const Space v141_4 = (has_head(v141_3) ? constant_15 : Space{});
    const Space v141_5 = subtract(constant_0,v141_4);
    Space v141_7;
    if (!v141_5.empty()) {
      Space v142_6_result;
      for (int v142_6_label = 1; v142_6_label <= 2; ++v142_6_label) {
        const Space v142_6_tail = child(v140_12_tail,v142_6_label);
        if (v142_6_tail.empty()) continue;
        const Path v142_6_head{v142_6_label};
        const Space v143_2 = singleton(v142_6_head);
        const Space v143_3 = intersect(constant_14,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_15 : Space{});
        const Space v143_5 = subtract(constant_0,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v140_12_head,v142_6_head);
          const Space v144_7 = routine_38(c, v144_6, p0, v142_6_tail, s1);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_14,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_15 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v140_12_head,v142_6_head);
          const Space v145_11 = routine_39(c, v145_6, p0, v142_6_tail, s1);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_6_result = unite(v142_6_result,v143_13);
      }
      const Space v142_6 = std::move(v142_6_result);
      v141_7 = compose(v141_5,v142_6);
    }
    const Space v141_8 = intersect(constant_14,v141_2);
    const Space v141_9 = (has_head(v141_8) ? constant_15 : Space{});
    Space v141_11;
    if (!v141_9.empty()) {
      Space v146_10_result;
      for (int v146_10_label = 1; v146_10_label <= 2; ++v146_10_label) {
        const Space v146_10_tail = child(v140_12_tail,v146_10_label);
        if (v146_10_tail.empty()) continue;
        const Path v146_10_head{v146_10_label};
        const Space v147_2 = singleton(v146_10_head);
        const Space v147_3 = intersect(constant_14,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_15 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v140_12_head,v146_10_head);
          const Space v148_7 = routine_38(c, v148_6, p0, v146_10_tail, s1);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_14,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_15 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v140_12_head,v146_10_head);
          const Space v149_11 = routine_40(c, v149_6, p0, v146_10_tail, s1);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_10_result = unite(v146_10_result,v147_13);
      }
      const Space v146_10 = std::move(v146_10_result);
      v141_11 = compose(v141_9,v146_10);
    }
    const Space v141_12 = unite(v141_7,v141_11);
    v140_12_result = unite(v140_12_result,v141_12);
  }
  const Space v140_12 = std::move(v140_12_result);
  return v140_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v150_12_result;
  for (int v150_12_label = 1; v150_12_label <= 2; ++v150_12_label) {
    const Space v150_12_tail = child(s0,v150_12_label);
    if (v150_12_tail.empty()) continue;
    const Path v150_12_head{v150_12_label};
    const Space v151_2 = singleton(v150_12_head);
    const Space v151_3 = intersect(constant_14,v151_2);
    const Space v151_4 = (has_head(v151_3) ? constant_15 : Space{});
    const Space v151_5 = subtract(constant_0,v151_4);
    Space v151_8;
    if (!v151_5.empty()) {
      const Path v152_6 = concat_path(p0,v150_12_head);
      Space v152_7_result;
      for (int v152_7_label = 1; v152_7_label <= 2; ++v152_7_label) {
        const Space v152_7_tail = child(v150_12_tail,v152_7_label);
        if (v152_7_tail.empty()) continue;
        const Path v152_7_head{v152_7_label};
        const Space v153_2 = singleton(v152_7_head);
        const Space v153_3 = intersect(constant_14,v153_2);
        const Space v153_4 = (has_head(v153_3) ? constant_15 : Space{});
        const Space v153_5 = subtract(constant_0,v153_4);
        Space v153_8;
        if (!v153_5.empty()) {
          const Path v154_6 = concat_path(v152_6,v152_7_head);
          const Space v154_7 = routine_41(c, v154_6, v152_7_tail, s1);
          v153_8 = compose(v153_5,v154_7);
        }
        const Space v153_9 = intersect(constant_14,v153_2);
        const Space v153_10 = (has_head(v153_9) ? constant_15 : Space{});
        Space v153_12;
        if (!v153_10.empty()) {
          const Path v155_6 = concat_path(v152_6,v152_7_head);
          const Space v155_11 = routine_42(c, v155_6, v152_7_tail, s1);
          v153_12 = compose(v153_10,v155_11);
        }
        const Space v153_13 = unite(v153_8,v153_12);
        v152_7_result = unite(v152_7_result,v153_13);
      }
      const Space v152_7 = std::move(v152_7_result);
      v151_8 = compose(v151_5,v152_7);
    }
    const Space v151_9 = intersect(constant_14,v151_2);
    const Space v151_10 = (has_head(v151_9) ? constant_15 : Space{});
    Space v151_12;
    if (!v151_10.empty()) {
      const Path v156_6 = concat_path(p0,v150_12_head);
      Space v156_11_result;
      for (int v156_11_label = 1; v156_11_label <= 2; ++v156_11_label) {
        const Space v156_11_tail = child(v150_12_tail,v156_11_label);
        if (v156_11_tail.empty()) continue;
        const Path v156_11_head{v156_11_label};
        const Space v157_2 = singleton(v156_11_head);
        const Space v157_3 = intersect(constant_14,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_15 : Space{});
        const Space v157_5 = subtract(constant_0,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_11_head);
          const Space v158_7 = routine_41(c, v158_6, v156_11_tail, s1);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_14,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_15 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_11_head);
          const Space v159_11 = routine_14(c, v159_6, v156_11_tail, s1);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_11_result = unite(v156_11_result,v157_13);
      }
      const Space v156_11 = std::move(v156_11_result);
      v151_12 = compose(v151_10,v156_11);
    }
    const Space v151_13 = unite(v151_8,v151_12);
    v150_12_result = unite(v150_12_result,v151_13);
  }
  const Space v150_12 = std::move(v150_12_result);
  return v150_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v160_12_result;
  for (int v160_12_label = 1; v160_12_label <= 2; ++v160_12_label) {
    const Space v160_12_tail = child(s0,v160_12_label);
    if (v160_12_tail.empty()) continue;
    const Path v160_12_head{v160_12_label};
    const Space v161_2 = singleton(v160_12_head);
    const Space v161_3 = intersect(constant_14,v161_2);
    const Space v161_4 = (has_head(v161_3) ? constant_15 : Space{});
    const Space v161_5 = subtract(constant_0,v161_4);
    Space v161_8;
    if (!v161_5.empty()) {
      const Path v162_6 = concat_path(p0,v160_12_head);
      Space v162_7_result;
      for (int v162_7_label = 1; v162_7_label <= 2; ++v162_7_label) {
        const Space v162_7_tail = child(v160_12_tail,v162_7_label);
        if (v162_7_tail.empty()) continue;
        const Path v162_7_head{v162_7_label};
        const Space v163_2 = singleton(v162_7_head);
        const Space v163_3 = intersect(constant_14,v163_2);
        const Space v163_4 = (has_head(v163_3) ? constant_15 : Space{});
        const Space v163_5 = subtract(constant_0,v163_4);
        Space v163_8;
        if (!v163_5.empty()) {
          const Path v164_6 = concat_path(v162_6,v162_7_head);
          const Space v164_7 = routine_41(c, v164_6, v162_7_tail, s1);
          v163_8 = compose(v163_5,v164_7);
        }
        const Space v163_9 = intersect(constant_14,v163_2);
        const Space v163_10 = (has_head(v163_9) ? constant_15 : Space{});
        Space v163_12;
        if (!v163_10.empty()) {
          const Path v165_6 = concat_path(v162_6,v162_7_head);
          const Space v165_11 = routine_42(c, v165_6, v162_7_tail, s1);
          v163_12 = compose(v163_10,v165_11);
        }
        const Space v163_13 = unite(v163_8,v163_12);
        v162_7_result = unite(v162_7_result,v163_13);
      }
      const Space v162_7 = std::move(v162_7_result);
      v161_8 = compose(v161_5,v162_7);
    }
    const Space v161_9 = intersect(constant_14,v161_2);
    const Space v161_10 = (has_head(v161_9) ? constant_15 : Space{});
    Space v161_12;
    if (!v161_10.empty()) {
      const Path v166_6 = concat_path(p0,v160_12_head);
      Space v166_11_result;
      for (int v166_11_label = 1; v166_11_label <= 2; ++v166_11_label) {
        const Space v166_11_tail = child(v160_12_tail,v166_11_label);
        if (v166_11_tail.empty()) continue;
        const Path v166_11_head{v166_11_label};
        const Space v167_2 = singleton(v166_11_head);
        const Space v167_3 = intersect(constant_14,v167_2);
        const Space v167_4 = (has_head(v167_3) ? constant_15 : Space{});
        const Space v167_5 = subtract(constant_0,v167_4);
        Space v167_7;
        if (!v167_5.empty()) {
          const Space v168_6 = routine_43(c, v166_11_head, v166_6, v166_11_tail, s1);
          v167_7 = compose(v167_5,v168_6);
        }
        const Space v167_8 = intersect(constant_14,v167_2);
        const Space v167_9 = (has_head(v167_8) ? constant_15 : Space{});
        Space v167_11;
        if (!v167_9.empty()) {
          const Space v169_10 = routine_44(c, v166_11_head, v166_6, v166_11_tail, s1);
          v167_11 = compose(v167_9,v169_10);
        }
        const Space v167_12 = unite(v167_7,v167_11);
        v166_11_result = unite(v166_11_result,v167_12);
      }
      const Space v166_11 = std::move(v166_11_result);
      v161_12 = compose(v161_10,v166_11);
    }
    const Space v161_13 = unite(v161_8,v161_12);
    v160_12_result = unite(v160_12_result,v161_13);
  }
  const Space v160_12 = std::move(v160_12_result);
  return v160_12;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v170_12_result;
  for (int v170_12_label = 1; v170_12_label <= 2; ++v170_12_label) {
    const Space v170_12_tail = child(s0,v170_12_label);
    if (v170_12_tail.empty()) continue;
    const Path v170_12_head{v170_12_label};
    const Space v171_2 = singleton(v170_12_head);
    const Space v171_3 = intersect(constant_14,v171_2);
    const Space v171_4 = (has_head(v171_3) ? constant_15 : Space{});
    const Space v171_5 = subtract(constant_0,v171_4);
    Space v171_7;
    if (!v171_5.empty()) {
      Space v172_6_result;
      for (int v172_6_label = 1; v172_6_label <= 2; ++v172_6_label) {
        const Space v172_6_tail = child(v170_12_tail,v172_6_label);
        if (v172_6_tail.empty()) continue;
        const Path v172_6_head{v172_6_label};
        const Space v173_2 = singleton(v172_6_head);
        const Space v173_3 = intersect(constant_14,v173_2);
        const Space v173_4 = (has_head(v173_3) ? constant_15 : Space{});
        const Space v173_5 = subtract(constant_0,v173_4);
        Space v173_8;
        if (!v173_5.empty()) {
          const Path v174_6 = concat_path(v170_12_head,v172_6_head);
          const Space v174_7 = routine_45(c, v174_6, p0, v172_6_tail, s1);
          v173_8 = compose(v173_5,v174_7);
        }
        const Space v173_9 = intersect(constant_14,v173_2);
        const Space v173_10 = (has_head(v173_9) ? constant_15 : Space{});
        Space v173_12;
        if (!v173_10.empty()) {
          const Path v175_6 = concat_path(v170_12_head,v172_6_head);
          const Space v175_11 = routine_46(c, v175_6, p0, v172_6_tail, s1);
          v173_12 = compose(v173_10,v175_11);
        }
        const Space v173_13 = unite(v173_8,v173_12);
        v172_6_result = unite(v172_6_result,v173_13);
      }
      const Space v172_6 = std::move(v172_6_result);
      v171_7 = compose(v171_5,v172_6);
    }
    const Space v171_8 = intersect(constant_14,v171_2);
    const Space v171_9 = (has_head(v171_8) ? constant_15 : Space{});
    Space v171_11;
    if (!v171_9.empty()) {
      Space v176_10_result;
      for (int v176_10_label = 1; v176_10_label <= 2; ++v176_10_label) {
        const Space v176_10_tail = child(v170_12_tail,v176_10_label);
        if (v176_10_tail.empty()) continue;
        const Path v176_10_head{v176_10_label};
        const Space v177_2 = singleton(v176_10_head);
        const Space v177_3 = intersect(constant_14,v177_2);
        const Space v177_4 = (has_head(v177_3) ? constant_15 : Space{});
        const Space v177_5 = subtract(constant_0,v177_4);
        Space v177_8;
        if (!v177_5.empty()) {
          const Path v178_6 = concat_path(v170_12_head,v176_10_head);
          const Space v178_7 = routine_45(c, v178_6, p0, v176_10_tail, s1);
          v177_8 = compose(v177_5,v178_7);
        }
        const Space v177_9 = intersect(constant_14,v177_2);
        const Space v177_10 = (has_head(v177_9) ? constant_15 : Space{});
        Space v177_12;
        if (!v177_10.empty()) {
          const Path v179_6 = concat_path(v170_12_head,v176_10_head);
          const Space v179_11 = routine_47(c, v179_6, p0, v176_10_tail, s1);
          v177_12 = compose(v177_10,v179_11);
        }
        const Space v177_13 = unite(v177_8,v177_12);
        v176_10_result = unite(v176_10_result,v177_13);
      }
      const Space v176_10 = std::move(v176_10_result);
      v171_11 = compose(v171_9,v176_10);
    }
    const Space v171_12 = unite(v171_7,v171_11);
    v170_12_result = unite(v170_12_result,v171_12);
  }
  const Space v170_12 = std::move(v170_12_result);
  return v170_12;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v180_11_result;
  for (int v180_11_label = 1; v180_11_label <= 2; ++v180_11_label) {
    const Space v180_11_tail = child(s0,v180_11_label);
    if (v180_11_tail.empty()) continue;
    const Path v180_11_head{v180_11_label};
    const Space v181_2 = singleton(v180_11_head);
    const Space v181_3 = intersect(constant_14,v181_2);
    const Space v181_4 = (has_head(v181_3) ? constant_15 : Space{});
    const Space v181_5 = subtract(constant_0,v181_4);
    Space v181_8;
    if (!v181_5.empty()) {
      const Path v182_6 = concat_path(p0,v180_11_head);
      Space v182_7_result;
      for (int v182_7_label = 1; v182_7_label <= 2; ++v182_7_label) {
        const Space v182_7_tail = child(v180_11_tail,v182_7_label);
        if (v182_7_tail.empty()) continue;
        const Path v182_7_head{v182_7_label};
        const Space v183_2 = singleton(v182_7_head);
        const Space v183_3 = intersect(constant_14,v183_2);
        const Space v183_4 = (has_head(v183_3) ? constant_15 : Space{});
        const Space v183_5 = subtract(constant_0,v183_4);
        Space v183_8;
        if (!v183_5.empty()) {
          const Path v184_6 = concat_path(v182_6,v182_7_head);
          const Space v184_7 = routine_48(c, v184_6, v182_7_tail);
          v183_8 = compose(v183_5,v184_7);
        }
        const Space v183_9 = intersect(constant_14,v183_2);
        const Space v183_10 = (has_head(v183_9) ? constant_15 : Space{});
        Space v183_12;
        if (!v183_10.empty()) {
          const Path v185_6 = concat_path(v182_6,v182_7_head);
          const Space v185_11 = routine_49(c, v185_6, v182_7_tail);
          v183_12 = compose(v183_10,v185_11);
        }
        const Space v183_13 = unite(v183_8,v183_12);
        v182_7_result = unite(v182_7_result,v183_13);
      }
      const Space v182_7 = std::move(v182_7_result);
      v181_8 = compose(v181_5,v182_7);
    }
    const Space v181_9 = intersect(constant_14,v181_2);
    const Space v181_10 = (has_head(v181_9) ? constant_15 : Space{});
    Space v181_12;
    if (!v181_10.empty()) {
      const Path v186_6 = concat_path(p0,v180_11_head);
      Space v186_11_result;
      for (int v186_11_label = 1; v186_11_label <= 2; ++v186_11_label) {
        const Space v186_11_tail = child(v180_11_tail,v186_11_label);
        if (v186_11_tail.empty()) continue;
        const Path v186_11_head{v186_11_label};
        const Space v187_2 = singleton(v186_11_head);
        const Space v187_3 = intersect(constant_14,v187_2);
        const Space v187_4 = (has_head(v187_3) ? constant_15 : Space{});
        const Space v187_5 = subtract(constant_0,v187_4);
        Space v187_8;
        if (!v187_5.empty()) {
          const Path v188_6 = concat_path(v186_6,v186_11_head);
          const Space v188_7 = routine_48(c, v188_6, v186_11_tail);
          v187_8 = compose(v187_5,v188_7);
        }
        const Space v187_9 = intersect(constant_14,v187_2);
        const Space v187_10 = (has_head(v187_9) ? constant_15 : Space{});
        Space v187_12;
        if (!v187_10.empty()) {
          const Path v189_6 = concat_path(v186_6,v186_11_head);
          const Space v189_11 = routine_17(c, v189_6, v186_11_tail);
          v187_12 = compose(v187_10,v189_11);
        }
        const Space v187_13 = unite(v187_8,v187_12);
        v186_11_result = unite(v186_11_result,v187_13);
      }
      const Space v186_11 = std::move(v186_11_result);
      v181_12 = compose(v181_10,v186_11);
    }
    const Space v181_13 = unite(v181_8,v181_12);
    v180_11_result = unite(v180_11_result,v181_13);
  }
  const Space v180_11 = std::move(v180_11_result);
  return v180_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v190_11_result;
  for (int v190_11_label = 1; v190_11_label <= 2; ++v190_11_label) {
    const Space v190_11_tail = child(s0,v190_11_label);
    if (v190_11_tail.empty()) continue;
    const Path v190_11_head{v190_11_label};
    const Space v191_2 = singleton(v190_11_head);
    const Space v191_3 = intersect(constant_14,v191_2);
    const Space v191_4 = (has_head(v191_3) ? constant_15 : Space{});
    const Space v191_5 = subtract(constant_0,v191_4);
    Space v191_8;
    if (!v191_5.empty()) {
      const Path v192_6 = concat_path(p0,v190_11_head);
      Space v192_7_result;
      for (int v192_7_label = 1; v192_7_label <= 2; ++v192_7_label) {
        const Space v192_7_tail = child(v190_11_tail,v192_7_label);
        if (v192_7_tail.empty()) continue;
        const Path v192_7_head{v192_7_label};
        const Space v193_2 = singleton(v192_7_head);
        const Space v193_3 = intersect(constant_14,v193_2);
        const Space v193_4 = (has_head(v193_3) ? constant_15 : Space{});
        const Space v193_5 = subtract(constant_0,v193_4);
        Space v193_8;
        if (!v193_5.empty()) {
          const Path v194_6 = concat_path(v192_6,v192_7_head);
          const Space v194_7 = routine_48(c, v194_6, v192_7_tail);
          v193_8 = compose(v193_5,v194_7);
        }
        const Space v193_9 = intersect(constant_14,v193_2);
        const Space v193_10 = (has_head(v193_9) ? constant_15 : Space{});
        Space v193_12;
        if (!v193_10.empty()) {
          const Path v195_6 = concat_path(v192_6,v192_7_head);
          const Space v195_11 = routine_49(c, v195_6, v192_7_tail);
          v193_12 = compose(v193_10,v195_11);
        }
        const Space v193_13 = unite(v193_8,v193_12);
        v192_7_result = unite(v192_7_result,v193_13);
      }
      const Space v192_7 = std::move(v192_7_result);
      v191_8 = compose(v191_5,v192_7);
    }
    const Space v191_9 = intersect(constant_14,v191_2);
    const Space v191_10 = (has_head(v191_9) ? constant_15 : Space{});
    Space v191_12;
    if (!v191_10.empty()) {
      const Path v196_6 = concat_path(p0,v190_11_head);
      Space v196_11_result;
      for (int v196_11_label = 1; v196_11_label <= 2; ++v196_11_label) {
        const Space v196_11_tail = child(v190_11_tail,v196_11_label);
        if (v196_11_tail.empty()) continue;
        const Path v196_11_head{v196_11_label};
        const Space v197_2 = singleton(v196_11_head);
        const Space v197_3 = intersect(constant_14,v197_2);
        const Space v197_4 = (has_head(v197_3) ? constant_15 : Space{});
        const Space v197_5 = subtract(constant_0,v197_4);
        Space v197_7;
        if (!v197_5.empty()) {
          const Space v198_6 = routine_18(c, v196_11_head, v196_6, v196_11_tail);
          v197_7 = compose(v197_5,v198_6);
        }
        const Space v197_8 = intersect(constant_14,v197_2);
        const Space v197_9 = (has_head(v197_8) ? constant_15 : Space{});
        Space v197_11;
        if (!v197_9.empty()) {
          const Space v199_10 = routine_19(c, v196_11_head, v196_6, v196_11_tail);
          v197_11 = compose(v197_9,v199_10);
        }
        const Space v197_12 = unite(v197_7,v197_11);
        v196_11_result = unite(v196_11_result,v197_12);
      }
      const Space v196_11 = std::move(v196_11_result);
      v191_12 = compose(v191_10,v196_11);
    }
    const Space v191_13 = unite(v191_8,v191_12);
    v190_11_result = unite(v190_11_result,v191_13);
  }
  const Space v190_11 = std::move(v190_11_result);
  return v190_11;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v200_11_result;
  for (int v200_11_label = 1; v200_11_label <= 2; ++v200_11_label) {
    const Space v200_11_tail = child(s0,v200_11_label);
    if (v200_11_tail.empty()) continue;
    const Path v200_11_head{v200_11_label};
    const Space v201_2 = singleton(v200_11_head);
    const Space v201_3 = intersect(constant_14,v201_2);
    const Space v201_4 = (has_head(v201_3) ? constant_15 : Space{});
    const Space v201_5 = subtract(constant_0,v201_4);
    Space v201_7;
    if (!v201_5.empty()) {
      Space v202_6_result;
      for (int v202_6_label = 1; v202_6_label <= 2; ++v202_6_label) {
        const Space v202_6_tail = child(v200_11_tail,v202_6_label);
        if (v202_6_tail.empty()) continue;
        const Path v202_6_head{v202_6_label};
        const Space v203_2 = singleton(v202_6_head);
        const Space v203_3 = intersect(constant_14,v203_2);
        const Space v203_4 = (has_head(v203_3) ? constant_15 : Space{});
        const Space v203_5 = subtract(constant_0,v203_4);
        Space v203_8;
        if (!v203_5.empty()) {
          const Path v204_6 = concat_path(v200_11_head,v202_6_head);
          const Space v204_7 = routine_50(c, v204_6, p0, v202_6_tail);
          v203_8 = compose(v203_5,v204_7);
        }
        const Space v203_9 = intersect(constant_14,v203_2);
        const Space v203_10 = (has_head(v203_9) ? constant_15 : Space{});
        Space v203_12;
        if (!v203_10.empty()) {
          const Path v205_6 = concat_path(v200_11_head,v202_6_head);
          const Space v205_11 = routine_51(c, v205_6, p0, v202_6_tail);
          v203_12 = compose(v203_10,v205_11);
        }
        const Space v203_13 = unite(v203_8,v203_12);
        v202_6_result = unite(v202_6_result,v203_13);
      }
      const Space v202_6 = std::move(v202_6_result);
      v201_7 = compose(v201_5,v202_6);
    }
    const Space v201_8 = intersect(constant_14,v201_2);
    const Space v201_9 = (has_head(v201_8) ? constant_15 : Space{});
    Space v201_11;
    if (!v201_9.empty()) {
      Space v206_10_result;
      for (int v206_10_label = 1; v206_10_label <= 2; ++v206_10_label) {
        const Space v206_10_tail = child(v200_11_tail,v206_10_label);
        if (v206_10_tail.empty()) continue;
        const Path v206_10_head{v206_10_label};
        const Space v207_2 = singleton(v206_10_head);
        const Space v207_3 = intersect(constant_14,v207_2);
        const Space v207_4 = (has_head(v207_3) ? constant_15 : Space{});
        const Space v207_5 = subtract(constant_0,v207_4);
        Space v207_8;
        if (!v207_5.empty()) {
          const Path v208_6 = concat_path(v200_11_head,v206_10_head);
          const Space v208_7 = routine_50(c, v208_6, p0, v206_10_tail);
          v207_8 = compose(v207_5,v208_7);
        }
        const Space v207_9 = intersect(constant_14,v207_2);
        const Space v207_10 = (has_head(v207_9) ? constant_15 : Space{});
        Space v207_12;
        if (!v207_10.empty()) {
          const Path v209_6 = concat_path(v200_11_head,v206_10_head);
          const Space v209_11 = routine_52(c, v209_6, p0, v206_10_tail);
          v207_12 = compose(v207_10,v209_11);
        }
        const Space v207_13 = unite(v207_8,v207_12);
        v206_10_result = unite(v206_10_result,v207_13);
      }
      const Space v206_10 = std::move(v206_10_result);
      v201_11 = compose(v201_9,v206_10);
    }
    const Space v201_12 = unite(v201_7,v201_11);
    v200_11_result = unite(v200_11_result,v201_12);
  }
  const Space v200_11 = std::move(v200_11_result);
  return v200_11;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v210_12_result;
  for (int v210_12_label = 1; v210_12_label <= 2; ++v210_12_label) {
    const Space v210_12_tail = child(s0,v210_12_label);
    if (v210_12_tail.empty()) continue;
    const Path v210_12_head{v210_12_label};
    const Space v211_2 = singleton(v210_12_head);
    const Space v211_3 = intersect(constant_14,v211_2);
    const Space v211_4 = (has_head(v211_3) ? constant_15 : Space{});
    const Space v211_5 = subtract(constant_0,v211_4);
    Space v211_8;
    if (!v211_5.empty()) {
      const Path v212_6 = concat_path(p0,v210_12_head);
      Space v212_7_result;
      for (int v212_7_label = 1; v212_7_label <= 2; ++v212_7_label) {
        const Space v212_7_tail = child(v210_12_tail,v212_7_label);
        if (v212_7_tail.empty()) continue;
        const Path v212_7_head{v212_7_label};
        const Space v213_2 = singleton(v212_7_head);
        const Space v213_3 = intersect(constant_14,v213_2);
        const Space v213_4 = (has_head(v213_3) ? constant_15 : Space{});
        const Space v213_5 = subtract(constant_0,v213_4);
        Space v213_8;
        if (!v213_5.empty()) {
          const Path v214_6 = concat_path(v212_6,v212_7_head);
          const Space v214_7 = routine_53(c, v214_6, p1, v212_7_tail);
          v213_8 = compose(v213_5,v214_7);
        }
        const Space v213_9 = intersect(constant_14,v213_2);
        const Space v213_10 = (has_head(v213_9) ? constant_15 : Space{});
        Space v213_12;
        if (!v213_10.empty()) {
          const Path v215_6 = concat_path(v212_6,v212_7_head);
          const Space v215_11 = routine_54(c, v215_6, p1, v212_7_tail);
          v213_12 = compose(v213_10,v215_11);
        }
        const Space v213_13 = unite(v213_8,v213_12);
        v212_7_result = unite(v212_7_result,v213_13);
      }
      const Space v212_7 = std::move(v212_7_result);
      v211_8 = compose(v211_5,v212_7);
    }
    const Space v211_9 = intersect(constant_14,v211_2);
    const Space v211_10 = (has_head(v211_9) ? constant_15 : Space{});
    Space v211_12;
    if (!v211_10.empty()) {
      const Path v216_6 = concat_path(p0,v210_12_head);
      Space v216_11_result;
      for (int v216_11_label = 1; v216_11_label <= 2; ++v216_11_label) {
        const Space v216_11_tail = child(v210_12_tail,v216_11_label);
        if (v216_11_tail.empty()) continue;
        const Path v216_11_head{v216_11_label};
        const Space v217_2 = singleton(v216_11_head);
        const Space v217_3 = intersect(constant_14,v217_2);
        const Space v217_4 = (has_head(v217_3) ? constant_15 : Space{});
        const Space v217_5 = subtract(constant_0,v217_4);
        Space v217_8;
        if (!v217_5.empty()) {
          const Path v218_6 = concat_path(v216_6,v216_11_head);
          const Space v218_7 = routine_53(c, v218_6, p1, v216_11_tail);
          v217_8 = compose(v217_5,v218_7);
        }
        const Space v217_9 = intersect(constant_14,v217_2);
        const Space v217_10 = (has_head(v217_9) ? constant_15 : Space{});
        Space v217_12;
        if (!v217_10.empty()) {
          const Path v219_6 = concat_path(v216_6,v216_11_head);
          const Space v219_11 = routine_52(c, v219_6, p1, v216_11_tail);
          v217_12 = compose(v217_10,v219_11);
        }
        const Space v217_13 = unite(v217_8,v217_12);
        v216_11_result = unite(v216_11_result,v217_13);
      }
      const Space v216_11 = std::move(v216_11_result);
      v211_12 = compose(v211_10,v216_11);
    }
    const Space v211_13 = unite(v211_8,v211_12);
    v210_12_result = unite(v210_12_result,v211_13);
  }
  const Space v210_12 = std::move(v210_12_result);
  return v210_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v220_10_result;
  for (int v220_10_label = 1; v220_10_label <= 2; ++v220_10_label) {
    const Space v220_10_tail = child(s0,v220_10_label);
    if (v220_10_tail.empty()) continue;
    const Path v220_10_head{v220_10_label};
    const Space v221_2 = singleton(v220_10_head);
    const Space v221_3 = intersect(constant_14,v221_2);
    const Space v221_4 = (has_head(v221_3) ? constant_15 : Space{});
    const Space v221_5 = compose(v221_4,v220_10_tail);
    const Path v222_6 = concat_path(p0,v220_10_head);
    const Space v221_7 = wrap(v221_5,v222_6);
    const Space v221_8 = wrap(v221_7,p1);
    const Space v221_9 = wrap(v221_8,constant_10);
    const Space v221_10 = intersect(constant_14,v221_2);
    const Space v221_11 = (has_head(v221_10) ? constant_15 : Space{});
    const Space v221_12 = subtract(constant_0,v221_11);
    Space v221_14;
    if (!v221_12.empty()) {
      Space v223_13_result;
      for (int v223_13_label = 1; v223_13_label <= 2; ++v223_13_label) {
        const Space v223_13_tail = child(v220_10_tail,v223_13_label);
        if (v223_13_tail.empty()) continue;
        const Path v223_13_head{v223_13_label};
        const Space v224_2 = singleton(v223_13_head);
        const Space v224_3 = intersect(constant_14,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_15 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v222_6,v223_13_head);
          const Space v225_7 = routine_53(c, v225_6, p1, v223_13_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_14,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_15 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v222_6,v223_13_head);
          const Space v226_11 = routine_54(c, v226_6, p1, v223_13_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_13_result = unite(v223_13_result,v224_13);
      }
      const Space v223_13 = std::move(v223_13_result);
      v221_14 = compose(v221_12,v223_13);
    }
    const Space v221_15 = unite(v221_9,v221_14);
    v220_10_result = unite(v220_10_result,v221_15);
  }
  const Space v220_10 = std::move(v220_10_result);
  return v220_10;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v227_12_result;
  for (int v227_12_label = 1; v227_12_label <= 2; ++v227_12_label) {
    const Space v227_12_tail = child(s0,v227_12_label);
    if (v227_12_tail.empty()) continue;
    const Path v227_12_head{v227_12_label};
    const Space v228_2 = singleton(v227_12_head);
    const Space v228_3 = intersect(constant_14,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_15 : Space{});
    const Space v228_5 = subtract(constant_0,v228_4);
    Space v228_8;
    if (!v228_5.empty()) {
      const Path v229_6 = concat_path(p0,v227_12_head);
      Space v229_7_result;
      for (int v229_7_label = 1; v229_7_label <= 2; ++v229_7_label) {
        const Space v229_7_tail = child(v227_12_tail,v229_7_label);
        if (v229_7_tail.empty()) continue;
        const Path v229_7_head{v229_7_label};
        const Space v230_2 = singleton(v229_7_head);
        const Space v230_3 = intersect(constant_14,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_15 : Space{});
        const Space v230_5 = subtract(constant_0,v230_4);
        Space v230_8;
        if (!v230_5.empty()) {
          const Path v231_6 = concat_path(v229_6,v229_7_head);
          const Space v231_7 = routine_55(c, v231_6, v229_7_tail, s1);
          v230_8 = compose(v230_5,v231_7);
        }
        const Space v230_9 = intersect(constant_14,v230_2);
        const Space v230_10 = (has_head(v230_9) ? constant_15 : Space{});
        Space v230_12;
        if (!v230_10.empty()) {
          const Path v232_6 = concat_path(v229_6,v229_7_head);
          const Space v232_11 = routine_56(c, v232_6, v229_7_tail, s1);
          v230_12 = compose(v230_10,v232_11);
        }
        const Space v230_13 = unite(v230_8,v230_12);
        v229_7_result = unite(v229_7_result,v230_13);
      }
      const Space v229_7 = std::move(v229_7_result);
      v228_8 = compose(v228_5,v229_7);
    }
    const Space v228_9 = intersect(constant_14,v228_2);
    const Space v228_10 = (has_head(v228_9) ? constant_15 : Space{});
    Space v228_12;
    if (!v228_10.empty()) {
      const Path v233_6 = concat_path(p0,v227_12_head);
      Space v233_11_result;
      for (int v233_11_label = 1; v233_11_label <= 2; ++v233_11_label) {
        const Space v233_11_tail = child(v227_12_tail,v233_11_label);
        if (v233_11_tail.empty()) continue;
        const Path v233_11_head{v233_11_label};
        const Space v234_2 = singleton(v233_11_head);
        const Space v234_3 = intersect(constant_14,v234_2);
        const Space v234_4 = (has_head(v234_3) ? constant_15 : Space{});
        const Space v234_5 = subtract(constant_0,v234_4);
        Space v234_8;
        if (!v234_5.empty()) {
          const Path v235_6 = concat_path(v233_6,v233_11_head);
          const Space v235_7 = routine_55(c, v235_6, v233_11_tail, s1);
          v234_8 = compose(v234_5,v235_7);
        }
        const Space v234_9 = intersect(constant_14,v234_2);
        const Space v234_10 = (has_head(v234_9) ? constant_15 : Space{});
        Space v234_12;
        if (!v234_10.empty()) {
          const Path v236_6 = concat_path(v233_6,v233_11_head);
          const Space v236_11 = routine_5(c, v236_6, v233_11_tail, s1);
          v234_12 = compose(v234_10,v236_11);
        }
        const Space v234_13 = unite(v234_8,v234_12);
        v233_11_result = unite(v233_11_result,v234_13);
      }
      const Space v233_11 = std::move(v233_11_result);
      v228_12 = compose(v228_10,v233_11);
    }
    const Space v228_13 = unite(v228_8,v228_12);
    v227_12_result = unite(v227_12_result,v228_13);
  }
  const Space v227_12 = std::move(v227_12_result);
  return v227_12;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v237_12_result;
  for (int v237_12_label = 1; v237_12_label <= 2; ++v237_12_label) {
    const Space v237_12_tail = child(s0,v237_12_label);
    if (v237_12_tail.empty()) continue;
    const Path v237_12_head{v237_12_label};
    const Space v238_2 = singleton(v237_12_head);
    const Space v238_3 = intersect(constant_14,v238_2);
    const Space v238_4 = (has_head(v238_3) ? constant_15 : Space{});
    const Space v238_5 = subtract(constant_0,v238_4);
    Space v238_8;
    if (!v238_5.empty()) {
      const Path v239_6 = concat_path(p0,v237_12_head);
      Space v239_7_result;
      for (int v239_7_label = 1; v239_7_label <= 2; ++v239_7_label) {
        const Space v239_7_tail = child(v237_12_tail,v239_7_label);
        if (v239_7_tail.empty()) continue;
        const Path v239_7_head{v239_7_label};
        const Space v240_2 = singleton(v239_7_head);
        const Space v240_3 = intersect(constant_14,v240_2);
        const Space v240_4 = (has_head(v240_3) ? constant_15 : Space{});
        const Space v240_5 = subtract(constant_0,v240_4);
        Space v240_8;
        if (!v240_5.empty()) {
          const Path v241_6 = concat_path(v239_6,v239_7_head);
          const Space v241_7 = routine_55(c, v241_6, v239_7_tail, s1);
          v240_8 = compose(v240_5,v241_7);
        }
        const Space v240_9 = intersect(constant_14,v240_2);
        const Space v240_10 = (has_head(v240_9) ? constant_15 : Space{});
        Space v240_12;
        if (!v240_10.empty()) {
          const Path v242_6 = concat_path(v239_6,v239_7_head);
          const Space v242_11 = routine_56(c, v242_6, v239_7_tail, s1);
          v240_12 = compose(v240_10,v242_11);
        }
        const Space v240_13 = unite(v240_8,v240_12);
        v239_7_result = unite(v239_7_result,v240_13);
      }
      const Space v239_7 = std::move(v239_7_result);
      v238_8 = compose(v238_5,v239_7);
    }
    const Space v238_9 = intersect(constant_14,v238_2);
    const Space v238_10 = (has_head(v238_9) ? constant_15 : Space{});
    Space v238_12;
    if (!v238_10.empty()) {
      const Path v243_6 = concat_path(p0,v237_12_head);
      Space v243_11_result;
      for (int v243_11_label = 1; v243_11_label <= 2; ++v243_11_label) {
        const Space v243_11_tail = child(v237_12_tail,v243_11_label);
        if (v243_11_tail.empty()) continue;
        const Path v243_11_head{v243_11_label};
        const Space v244_2 = singleton(v243_11_head);
        const Space v244_3 = intersect(constant_14,v244_2);
        const Space v244_4 = (has_head(v244_3) ? constant_15 : Space{});
        const Space v244_5 = subtract(constant_0,v244_4);
        Space v244_7;
        if (!v244_5.empty()) {
          const Space v245_6 = routine_22(c, v243_11_head, v243_6, v243_11_tail, s1);
          v244_7 = compose(v244_5,v245_6);
        }
        const Space v244_8 = intersect(constant_14,v244_2);
        const Space v244_9 = (has_head(v244_8) ? constant_15 : Space{});
        Space v244_11;
        if (!v244_9.empty()) {
          const Space v246_10 = routine_23(c, v243_11_head, v243_6, v243_11_tail, s1);
          v244_11 = compose(v244_9,v246_10);
        }
        const Space v244_12 = unite(v244_7,v244_11);
        v243_11_result = unite(v243_11_result,v244_12);
      }
      const Space v243_11 = std::move(v243_11_result);
      v238_12 = compose(v238_10,v243_11);
    }
    const Space v238_13 = unite(v238_8,v238_12);
    v237_12_result = unite(v237_12_result,v238_13);
  }
  const Space v237_12 = std::move(v237_12_result);
  return v237_12;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v247_13_result;
  for (int v247_13_label = 1; v247_13_label <= 2; ++v247_13_label) {
    const Space v247_13_tail = child(s0,v247_13_label);
    if (v247_13_tail.empty()) continue;
    const Path v247_13_head{v247_13_label};
    const Space v248_2 = singleton(v247_13_head);
    const Space v248_3 = intersect(constant_14,v248_2);
    const Space v248_4 = (has_head(v248_3) ? constant_15 : Space{});
    const Space v248_5 = subtract(constant_0,v248_4);
    Space v248_8;
    if (!v248_5.empty()) {
      const Path v249_6 = concat_path(p0,v247_13_head);
      Space v249_7_result;
      for (int v249_7_label = 1; v249_7_label <= 2; ++v249_7_label) {
        const Space v249_7_tail = child(v247_13_tail,v249_7_label);
        if (v249_7_tail.empty()) continue;
        const Path v249_7_head{v249_7_label};
        const Space v250_2 = singleton(v249_7_head);
        const Space v250_3 = intersect(constant_14,v250_2);
        const Space v250_4 = (has_head(v250_3) ? constant_15 : Space{});
        const Space v250_5 = subtract(constant_0,v250_4);
        Space v250_8;
        if (!v250_5.empty()) {
          const Path v251_6 = concat_path(v249_6,v249_7_head);
          const Space v251_7 = routine_57(c, v251_6, p1, v249_7_tail, s1);
          v250_8 = compose(v250_5,v251_7);
        }
        const Space v250_9 = intersect(constant_14,v250_2);
        const Space v250_10 = (has_head(v250_9) ? constant_15 : Space{});
        Space v250_12;
        if (!v250_10.empty()) {
          const Path v252_6 = concat_path(v249_6,v249_7_head);
          const Space v252_11 = routine_58(c, v252_6, p1, v249_7_tail, s1);
          v250_12 = compose(v250_10,v252_11);
        }
        const Space v250_13 = unite(v250_8,v250_12);
        v249_7_result = unite(v249_7_result,v250_13);
      }
      const Space v249_7 = std::move(v249_7_result);
      v248_8 = compose(v248_5,v249_7);
    }
    const Space v248_9 = intersect(constant_14,v248_2);
    const Space v248_10 = (has_head(v248_9) ? constant_15 : Space{});
    Space v248_12;
    if (!v248_10.empty()) {
      const Path v253_6 = concat_path(p0,v247_13_head);
      Space v253_11_result;
      for (int v253_11_label = 1; v253_11_label <= 2; ++v253_11_label) {
        const Space v253_11_tail = child(v247_13_tail,v253_11_label);
        if (v253_11_tail.empty()) continue;
        const Path v253_11_head{v253_11_label};
        const Space v254_2 = singleton(v253_11_head);
        const Space v254_3 = intersect(constant_14,v254_2);
        const Space v254_4 = (has_head(v254_3) ? constant_15 : Space{});
        const Space v254_5 = subtract(constant_0,v254_4);
        Space v254_8;
        if (!v254_5.empty()) {
          const Path v255_6 = concat_path(v253_6,v253_11_head);
          const Space v255_7 = routine_57(c, v255_6, p1, v253_11_tail, s1);
          v254_8 = compose(v254_5,v255_7);
        }
        const Space v254_9 = intersect(constant_14,v254_2);
        const Space v254_10 = (has_head(v254_9) ? constant_15 : Space{});
        Space v254_12;
        if (!v254_10.empty()) {
          const Path v256_6 = concat_path(v253_6,v253_11_head);
          const Space v256_11 = routine_26(c, v256_6, p1, v253_11_tail, s1);
          v254_12 = compose(v254_10,v256_11);
        }
        const Space v254_13 = unite(v254_8,v254_12);
        v253_11_result = unite(v253_11_result,v254_13);
      }
      const Space v253_11 = std::move(v253_11_result);
      v248_12 = compose(v248_10,v253_11);
    }
    const Space v248_13 = unite(v248_8,v248_12);
    v247_13_result = unite(v247_13_result,v248_13);
  }
  const Space v247_13 = std::move(v247_13_result);
  return v247_13;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v257_8 = unwrap(s1,constant_7);
  const Space v257_10 = unwrap(v257_8,constant_10);
  const Space v257_11 = unwrap(v257_10,p0);
  Space v257_18_result;
  for (int v257_18_label = 1; v257_18_label <= 2; ++v257_18_label) {
    const Space v257_18_tail = child(s0,v257_18_label);
    if (v257_18_tail.empty()) continue;
    const Path v257_18_head{v257_18_label};
    const Space v258_2 = singleton(v257_18_head);
    const Space v258_3 = intersect(constant_14,v258_2);
    const Space v258_4 = (has_head(v258_3) ? constant_15 : Space{});
    const Space v258_5 = subtract(constant_0,v258_4);
    Space v258_8;
    if (!v258_5.empty()) {
      const Path v259_6 = concat_path(p0,v257_18_head);
      Space v259_7_result;
      for (int v259_7_label = 1; v259_7_label <= 2; ++v259_7_label) {
        const Space v259_7_tail = child(v257_18_tail,v259_7_label);
        if (v259_7_tail.empty()) continue;
        const Path v259_7_head{v259_7_label};
        const Space v260_2 = singleton(v259_7_head);
        const Space v260_3 = intersect(constant_14,v260_2);
        const Space v260_4 = (has_head(v260_3) ? constant_15 : Space{});
        const Space v260_5 = subtract(constant_0,v260_4);
        Space v260_8;
        if (!v260_5.empty()) {
          const Path v261_6 = concat_path(v259_6,v259_7_head);
          const Space v261_7 = routine_57(c, v261_6, p1, v259_7_tail, s1);
          v260_8 = compose(v260_5,v261_7);
        }
        const Space v260_9 = intersect(constant_14,v260_2);
        const Space v260_10 = (has_head(v260_9) ? constant_15 : Space{});
        Space v260_12;
        if (!v260_10.empty()) {
          const Path v262_6 = concat_path(v259_6,v259_7_head);
          const Space v262_11 = routine_58(c, v262_6, p1, v259_7_tail, s1);
          v260_12 = compose(v260_10,v262_11);
        }
        const Space v260_13 = unite(v260_8,v260_12);
        v259_7_result = unite(v259_7_result,v260_13);
      }
      const Space v259_7 = std::move(v259_7_result);
      v258_8 = compose(v258_5,v259_7);
    }
    const Space v258_9 = intersect(constant_14,v258_2);
    const Space v258_10 = (has_head(v258_9) ? constant_15 : Space{});
    Space v258_13;
    if (!v258_10.empty()) {
      const Space v263_11 = unwrap(v257_11,v257_18_head);
      Space v263_12_result;
      for (int v263_12_label = 1; v263_12_label <= 2; ++v263_12_label) {
        const Space v263_12_tail = child(v263_11,v263_12_label);
        if (v263_12_tail.empty()) continue;
        const Path v263_12_head{v263_12_label};
        const Space v264_2 = singleton(v263_12_head);
        const Space v264_3 = intersect(constant_14,v264_2);
        const Space v264_4 = (has_head(v264_3) ? constant_15 : Space{});
        const Space v264_5 = subtract(constant_0,v264_4);
        Space v264_7;
        if (!v264_5.empty()) {
          const Space v265_6 = routine_59(c, v263_12_head, p1, v263_12_tail);
          v264_7 = compose(v264_5,v265_6);
        }
        const Space v264_8 = intersect(constant_14,v264_2);
        const Space v264_9 = (has_head(v264_8) ? constant_15 : Space{});
        Space v264_11;
        if (!v264_9.empty()) {
          const Space v266_10 = routine_60(c, v263_12_head, p1, v263_12_tail);
          v264_11 = compose(v264_9,v266_10);
        }
        const Space v264_12 = unite(v264_7,v264_11);
        v263_12_result = unite(v263_12_result,v264_12);
      }
      const Space v263_12 = std::move(v263_12_result);
      v258_13 = compose(v258_10,v263_12);
    }
    const Space v258_14 = unite(v258_8,v258_13);
    v257_18_result = unite(v257_18_result,v258_14);
  }
  const Space v257_18 = std::move(v257_18_result);
  return v257_18;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v267_13_result;
  for (int v267_13_label = 1; v267_13_label <= 2; ++v267_13_label) {
    const Space v267_13_tail = child(s0,v267_13_label);
    if (v267_13_tail.empty()) continue;
    const Path v267_13_head{v267_13_label};
    const Space v268_2 = singleton(v267_13_head);
    const Space v268_3 = intersect(constant_14,v268_2);
    const Space v268_4 = (has_head(v268_3) ? constant_15 : Space{});
    const Space v268_5 = subtract(constant_0,v268_4);
    Space v268_8;
    if (!v268_5.empty()) {
      const Path v269_6 = concat_path(p0,v267_13_head);
      Space v269_7_result;
      for (int v269_7_label = 1; v269_7_label <= 2; ++v269_7_label) {
        const Space v269_7_tail = child(v267_13_tail,v269_7_label);
        if (v269_7_tail.empty()) continue;
        const Path v269_7_head{v269_7_label};
        const Space v270_2 = singleton(v269_7_head);
        const Space v270_3 = intersect(constant_14,v270_2);
        const Space v270_4 = (has_head(v270_3) ? constant_15 : Space{});
        const Space v270_5 = subtract(constant_0,v270_4);
        Space v270_8;
        if (!v270_5.empty()) {
          const Path v271_6 = concat_path(v269_6,v269_7_head);
          const Space v271_7 = routine_61(c, v271_6, p1, v269_7_tail, s1);
          v270_8 = compose(v270_5,v271_7);
        }
        const Space v270_9 = intersect(constant_14,v270_2);
        const Space v270_10 = (has_head(v270_9) ? constant_15 : Space{});
        Space v270_12;
        if (!v270_10.empty()) {
          const Path v272_6 = concat_path(v269_6,v269_7_head);
          const Space v272_11 = routine_62(c, v272_6, p1, v269_7_tail, s1);
          v270_12 = compose(v270_10,v272_11);
        }
        const Space v270_13 = unite(v270_8,v270_12);
        v269_7_result = unite(v269_7_result,v270_13);
      }
      const Space v269_7 = std::move(v269_7_result);
      v268_8 = compose(v268_5,v269_7);
    }
    const Space v268_9 = intersect(constant_14,v268_2);
    const Space v268_10 = (has_head(v268_9) ? constant_15 : Space{});
    Space v268_12;
    if (!v268_10.empty()) {
      const Path v273_6 = concat_path(p0,v267_13_head);
      Space v273_11_result;
      for (int v273_11_label = 1; v273_11_label <= 2; ++v273_11_label) {
        const Space v273_11_tail = child(v267_13_tail,v273_11_label);
        if (v273_11_tail.empty()) continue;
        const Path v273_11_head{v273_11_label};
        const Space v274_2 = singleton(v273_11_head);
        const Space v274_3 = intersect(constant_14,v274_2);
        const Space v274_4 = (has_head(v274_3) ? constant_15 : Space{});
        const Space v274_5 = subtract(constant_0,v274_4);
        Space v274_8;
        if (!v274_5.empty()) {
          const Path v275_6 = concat_path(v273_6,v273_11_head);
          const Space v275_7 = routine_61(c, v275_6, p1, v273_11_tail, s1);
          v274_8 = compose(v274_5,v275_7);
        }
        const Space v274_9 = intersect(constant_14,v274_2);
        const Space v274_10 = (has_head(v274_9) ? constant_15 : Space{});
        Space v274_12;
        if (!v274_10.empty()) {
          const Path v276_6 = concat_path(v273_6,v273_11_head);
          const Space v276_11 = routine_26(c, v276_6, p1, v273_11_tail, s1);
          v274_12 = compose(v274_10,v276_11);
        }
        const Space v274_13 = unite(v274_8,v274_12);
        v273_11_result = unite(v273_11_result,v274_13);
      }
      const Space v273_11 = std::move(v273_11_result);
      v268_12 = compose(v268_10,v273_11);
    }
    const Space v268_13 = unite(v268_8,v268_12);
    v267_13_result = unite(v267_13_result,v268_13);
  }
  const Space v267_13 = std::move(v267_13_result);
  return v267_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v277_8 = unwrap(s1,constant_7);
  const Space v277_10 = unwrap(v277_8,constant_10);
  const Space v277_11 = unwrap(v277_10,p0);
  Space v277_18_result;
  for (int v277_18_label = 1; v277_18_label <= 2; ++v277_18_label) {
    const Space v277_18_tail = child(s0,v277_18_label);
    if (v277_18_tail.empty()) continue;
    const Path v277_18_head{v277_18_label};
    const Space v278_2 = singleton(v277_18_head);
    const Space v278_3 = intersect(constant_14,v278_2);
    const Space v278_4 = (has_head(v278_3) ? constant_15 : Space{});
    const Space v278_5 = subtract(constant_0,v278_4);
    Space v278_8;
    if (!v278_5.empty()) {
      const Path v279_6 = concat_path(p0,v277_18_head);
      Space v279_7_result;
      for (int v279_7_label = 1; v279_7_label <= 2; ++v279_7_label) {
        const Space v279_7_tail = child(v277_18_tail,v279_7_label);
        if (v279_7_tail.empty()) continue;
        const Path v279_7_head{v279_7_label};
        const Space v280_2 = singleton(v279_7_head);
        const Space v280_3 = intersect(constant_14,v280_2);
        const Space v280_4 = (has_head(v280_3) ? constant_15 : Space{});
        const Space v280_5 = subtract(constant_0,v280_4);
        Space v280_8;
        if (!v280_5.empty()) {
          const Path v281_6 = concat_path(v279_6,v279_7_head);
          const Space v281_7 = routine_61(c, v281_6, p1, v279_7_tail, s1);
          v280_8 = compose(v280_5,v281_7);
        }
        const Space v280_9 = intersect(constant_14,v280_2);
        const Space v280_10 = (has_head(v280_9) ? constant_15 : Space{});
        Space v280_12;
        if (!v280_10.empty()) {
          const Path v282_6 = concat_path(v279_6,v279_7_head);
          const Space v282_11 = routine_62(c, v282_6, p1, v279_7_tail, s1);
          v280_12 = compose(v280_10,v282_11);
        }
        const Space v280_13 = unite(v280_8,v280_12);
        v279_7_result = unite(v279_7_result,v280_13);
      }
      const Space v279_7 = std::move(v279_7_result);
      v278_8 = compose(v278_5,v279_7);
    }
    const Space v278_9 = intersect(constant_14,v278_2);
    const Space v278_10 = (has_head(v278_9) ? constant_15 : Space{});
    Space v278_13;
    if (!v278_10.empty()) {
      const Space v283_11 = unwrap(v277_11,v277_18_head);
      Space v283_12_result;
      for (int v283_12_label = 1; v283_12_label <= 2; ++v283_12_label) {
        const Space v283_12_tail = child(v283_11,v283_12_label);
        if (v283_12_tail.empty()) continue;
        const Path v283_12_head{v283_12_label};
        const Space v284_2 = singleton(v283_12_head);
        const Space v284_3 = intersect(constant_14,v284_2);
        const Space v284_4 = (has_head(v284_3) ? constant_15 : Space{});
        const Space v284_5 = subtract(constant_0,v284_4);
        Space v284_7;
        if (!v284_5.empty()) {
          const Space v285_6 = routine_59(c, v283_12_head, p1, v283_12_tail);
          v284_7 = compose(v284_5,v285_6);
        }
        const Space v284_8 = intersect(constant_14,v284_2);
        const Space v284_9 = (has_head(v284_8) ? constant_15 : Space{});
        Space v284_11;
        if (!v284_9.empty()) {
          const Space v286_10 = routine_60(c, v283_12_head, p1, v283_12_tail);
          v284_11 = compose(v284_9,v286_10);
        }
        const Space v284_12 = unite(v284_7,v284_11);
        v283_12_result = unite(v283_12_result,v284_12);
      }
      const Space v283_12 = std::move(v283_12_result);
      v278_13 = compose(v278_10,v283_12);
    }
    const Space v278_14 = unite(v278_8,v278_13);
    v277_18_result = unite(v277_18_result,v278_14);
  }
  const Space v277_18 = std::move(v277_18_result);
  return v277_18;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v287_5 = unwrap(s1,constant_7);
  const Space v287_7 = unwrap(v287_5,constant_10);
  const Space v287_8 = unwrap(v287_7,p0);
  Space v287_18_result;
  for (int v287_18_label = 1; v287_18_label <= 2; ++v287_18_label) {
    const Space v287_18_tail = child(v287_8,v287_18_label);
    if (v287_18_tail.empty()) continue;
    const Path v287_18_head{v287_18_label};
    const Space v288_2 = singleton(v287_18_head);
    const Space v288_3 = intersect(constant_14,v288_2);
    const Space v288_4 = (has_head(v288_3) ? constant_15 : Space{});
    const Space v288_5 = subtract(constant_0,v288_4);
    Space v288_7;
    if (!v288_5.empty()) {
      Space v289_6_result;
      for (int v289_6_label = 1; v289_6_label <= 2; ++v289_6_label) {
        const Space v289_6_tail = child(v287_18_tail,v289_6_label);
        if (v289_6_tail.empty()) continue;
        const Path v289_6_head{v289_6_label};
        const Space v290_2 = singleton(v289_6_head);
        const Space v290_3 = intersect(constant_14,v290_2);
        const Space v290_4 = (has_head(v290_3) ? constant_15 : Space{});
        const Space v290_5 = subtract(constant_0,v290_4);
        Space v290_8;
        if (!v290_5.empty()) {
          const Path v291_6 = concat_path(v287_18_head,v289_6_head);
          const Space v291_7 = routine_63(c, v291_6, p1, v289_6_tail);
          v290_8 = compose(v290_5,v291_7);
        }
        const Space v290_9 = intersect(constant_14,v290_2);
        const Space v290_10 = (has_head(v290_9) ? constant_15 : Space{});
        Space v290_12;
        if (!v290_10.empty()) {
          const Path v292_6 = concat_path(v287_18_head,v289_6_head);
          const Space v292_11 = routine_64(c, v292_6, p1, v289_6_tail);
          v290_12 = compose(v290_10,v292_11);
        }
        const Space v290_13 = unite(v290_8,v290_12);
        v289_6_result = unite(v289_6_result,v290_13);
      }
      const Space v289_6 = std::move(v289_6_result);
      v288_7 = compose(v288_5,v289_6);
    }
    const Space v288_8 = intersect(constant_14,v288_2);
    const Space v288_9 = (has_head(v288_8) ? constant_15 : Space{});
    Space v288_11;
    if (!v288_9.empty()) {
      Space v293_10_result;
      for (int v293_10_label = 1; v293_10_label <= 2; ++v293_10_label) {
        const Space v293_10_tail = child(v287_18_tail,v293_10_label);
        if (v293_10_tail.empty()) continue;
        const Path v293_10_head{v293_10_label};
        const Space v294_2 = singleton(v293_10_head);
        const Space v294_3 = intersect(constant_14,v294_2);
        const Space v294_4 = (has_head(v294_3) ? constant_15 : Space{});
        const Space v294_5 = subtract(constant_0,v294_4);
        Space v294_8;
        if (!v294_5.empty()) {
          const Path v295_6 = concat_path(v287_18_head,v293_10_head);
          const Space v295_7 = routine_63(c, v295_6, p1, v293_10_tail);
          v294_8 = compose(v294_5,v295_7);
        }
        const Space v294_9 = intersect(constant_14,v294_2);
        const Space v294_10 = (has_head(v294_9) ? constant_15 : Space{});
        Space v294_12;
        if (!v294_10.empty()) {
          const Path v296_6 = concat_path(v287_18_head,v293_10_head);
          const Space v296_11 = routine_65(c, v296_6, p1, v293_10_tail);
          v294_12 = compose(v294_10,v296_11);
        }
        const Space v294_13 = unite(v294_8,v294_12);
        v293_10_result = unite(v293_10_result,v294_13);
      }
      const Space v293_10 = std::move(v293_10_result);
      v288_11 = compose(v288_9,v293_10);
    }
    const Space v288_12 = unite(v288_7,v288_11);
    v287_18_result = unite(v287_18_result,v288_12);
  }
  const Space v287_18 = std::move(v287_18_result);
  return v287_18;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v297_11_result;
  for (int v297_11_label = 1; v297_11_label <= 2; ++v297_11_label) {
    const Space v297_11_tail = child(s0,v297_11_label);
    if (v297_11_tail.empty()) continue;
    const Path v297_11_head{v297_11_label};
    const Space v298_2 = singleton(v297_11_head);
    const Space v298_3 = intersect(constant_14,v298_2);
    const Space v298_4 = (has_head(v298_3) ? constant_15 : Space{});
    const Space v298_5 = subtract(constant_0,v298_4);
    Space v298_8;
    if (!v298_5.empty()) {
      const Path v299_6 = concat_path(p0,v297_11_head);
      Space v299_7_result;
      for (int v299_7_label = 1; v299_7_label <= 2; ++v299_7_label) {
        const Space v299_7_tail = child(v297_11_tail,v299_7_label);
        if (v299_7_tail.empty()) continue;
        const Path v299_7_head{v299_7_label};
        const Space v300_2 = singleton(v299_7_head);
        const Space v300_3 = intersect(constant_14,v300_2);
        const Space v300_4 = (has_head(v300_3) ? constant_15 : Space{});
        const Space v300_5 = subtract(constant_0,v300_4);
        Space v300_8;
        if (!v300_5.empty()) {
          const Path v301_6 = concat_path(v299_6,v299_7_head);
          const Space v301_7 = routine_66(c, v301_6, v299_7_tail);
          v300_8 = compose(v300_5,v301_7);
        }
        const Space v300_9 = intersect(constant_14,v300_2);
        const Space v300_10 = (has_head(v300_9) ? constant_15 : Space{});
        Space v300_12;
        if (!v300_10.empty()) {
          const Path v302_6 = concat_path(v299_6,v299_7_head);
          const Space v302_11 = routine_67(c, v302_6, v299_7_tail);
          v300_12 = compose(v300_10,v302_11);
        }
        const Space v300_13 = unite(v300_8,v300_12);
        v299_7_result = unite(v299_7_result,v300_13);
      }
      const Space v299_7 = std::move(v299_7_result);
      v298_8 = compose(v298_5,v299_7);
    }
    const Space v298_9 = intersect(constant_14,v298_2);
    const Space v298_10 = (has_head(v298_9) ? constant_15 : Space{});
    Space v298_12;
    if (!v298_10.empty()) {
      const Path v303_6 = concat_path(p0,v297_11_head);
      Space v303_11_result;
      for (int v303_11_label = 1; v303_11_label <= 2; ++v303_11_label) {
        const Space v303_11_tail = child(v297_11_tail,v303_11_label);
        if (v303_11_tail.empty()) continue;
        const Path v303_11_head{v303_11_label};
        const Space v304_2 = singleton(v303_11_head);
        const Space v304_3 = intersect(constant_14,v304_2);
        const Space v304_4 = (has_head(v304_3) ? constant_15 : Space{});
        const Space v304_5 = subtract(constant_0,v304_4);
        Space v304_8;
        if (!v304_5.empty()) {
          const Path v305_6 = concat_path(v303_6,v303_11_head);
          const Space v305_7 = routine_66(c, v305_6, v303_11_tail);
          v304_8 = compose(v304_5,v305_7);
        }
        const Space v304_9 = intersect(constant_14,v304_2);
        const Space v304_10 = (has_head(v304_9) ? constant_15 : Space{});
        Space v304_12;
        if (!v304_10.empty()) {
          const Path v306_6 = concat_path(v303_6,v303_11_head);
          const Space v306_11 = routine_8(c, v306_6, v303_11_tail);
          v304_12 = compose(v304_10,v306_11);
        }
        const Space v304_13 = unite(v304_8,v304_12);
        v303_11_result = unite(v303_11_result,v304_13);
      }
      const Space v303_11 = std::move(v303_11_result);
      v298_12 = compose(v298_10,v303_11);
    }
    const Space v298_13 = unite(v298_8,v298_12);
    v297_11_result = unite(v297_11_result,v298_13);
  }
  const Space v297_11 = std::move(v297_11_result);
  return v297_11;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v307_11_result;
  for (int v307_11_label = 1; v307_11_label <= 2; ++v307_11_label) {
    const Space v307_11_tail = child(s0,v307_11_label);
    if (v307_11_tail.empty()) continue;
    const Path v307_11_head{v307_11_label};
    const Space v308_2 = singleton(v307_11_head);
    const Space v308_3 = intersect(constant_14,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_15 : Space{});
    const Space v308_5 = subtract(constant_0,v308_4);
    Space v308_8;
    if (!v308_5.empty()) {
      const Path v309_6 = concat_path(p0,v307_11_head);
      Space v309_7_result;
      for (int v309_7_label = 1; v309_7_label <= 2; ++v309_7_label) {
        const Space v309_7_tail = child(v307_11_tail,v309_7_label);
        if (v309_7_tail.empty()) continue;
        const Path v309_7_head{v309_7_label};
        const Space v310_2 = singleton(v309_7_head);
        const Space v310_3 = intersect(constant_14,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_15 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v309_6,v309_7_head);
          const Space v311_7 = routine_66(c, v311_6, v309_7_tail);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_14,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_15 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v309_6,v309_7_head);
          const Space v312_11 = routine_67(c, v312_6, v309_7_tail);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_7_result = unite(v309_7_result,v310_13);
      }
      const Space v309_7 = std::move(v309_7_result);
      v308_8 = compose(v308_5,v309_7);
    }
    const Space v308_9 = intersect(constant_14,v308_2);
    const Space v308_10 = (has_head(v308_9) ? constant_15 : Space{});
    Space v308_12;
    if (!v308_10.empty()) {
      const Path v313_6 = concat_path(p0,v307_11_head);
      Space v313_11_result;
      for (int v313_11_label = 1; v313_11_label <= 2; ++v313_11_label) {
        const Space v313_11_tail = child(v307_11_tail,v313_11_label);
        if (v313_11_tail.empty()) continue;
        const Path v313_11_head{v313_11_label};
        const Space v314_2 = singleton(v313_11_head);
        const Space v314_3 = intersect(constant_14,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_15 : Space{});
        const Space v314_5 = subtract(constant_0,v314_4);
        Space v314_7;
        if (!v314_5.empty()) {
          const Space v315_6 = routine_29(c, v313_11_head, v313_6, v313_11_tail);
          v314_7 = compose(v314_5,v315_6);
        }
        const Space v314_8 = intersect(constant_14,v314_2);
        const Space v314_9 = (has_head(v314_8) ? constant_15 : Space{});
        Space v314_11;
        if (!v314_9.empty()) {
          const Space v316_10 = routine_30(c, v313_11_head, v313_6, v313_11_tail);
          v314_11 = compose(v314_9,v316_10);
        }
        const Space v314_12 = unite(v314_7,v314_11);
        v313_11_result = unite(v313_11_result,v314_12);
      }
      const Space v313_11 = std::move(v313_11_result);
      v308_12 = compose(v308_10,v313_11);
    }
    const Space v308_13 = unite(v308_8,v308_12);
    v307_11_result = unite(v307_11_result,v308_13);
  }
  const Space v307_11 = std::move(v307_11_result);
  return v307_11;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v317_12_result;
  for (int v317_12_label = 1; v317_12_label <= 2; ++v317_12_label) {
    const Space v317_12_tail = child(s0,v317_12_label);
    if (v317_12_tail.empty()) continue;
    const Path v317_12_head{v317_12_label};
    const Space v318_2 = singleton(v317_12_head);
    const Space v318_3 = intersect(constant_14,v318_2);
    const Space v318_4 = (has_head(v318_3) ? constant_15 : Space{});
    const Space v318_5 = subtract(constant_0,v318_4);
    Space v318_8;
    if (!v318_5.empty()) {
      const Path v319_6 = concat_path(p0,v317_12_head);
      Space v319_7_result;
      for (int v319_7_label = 1; v319_7_label <= 2; ++v319_7_label) {
        const Space v319_7_tail = child(v317_12_tail,v319_7_label);
        if (v319_7_tail.empty()) continue;
        const Path v319_7_head{v319_7_label};
        const Space v320_2 = singleton(v319_7_head);
        const Space v320_3 = intersect(constant_14,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_15 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_7_head);
          const Space v321_7 = routine_68(c, v321_6, p1, v319_7_tail);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_14,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_15 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_7_head);
          const Space v322_11 = routine_69(c, v322_6, p1, v319_7_tail);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_7_result = unite(v319_7_result,v320_13);
      }
      const Space v319_7 = std::move(v319_7_result);
      v318_8 = compose(v318_5,v319_7);
    }
    const Space v318_9 = intersect(constant_14,v318_2);
    const Space v318_10 = (has_head(v318_9) ? constant_15 : Space{});
    Space v318_12;
    if (!v318_10.empty()) {
      const Path v323_6 = concat_path(p0,v317_12_head);
      Space v323_11_result;
      for (int v323_11_label = 1; v323_11_label <= 2; ++v323_11_label) {
        const Space v323_11_tail = child(v317_12_tail,v323_11_label);
        if (v323_11_tail.empty()) continue;
        const Path v323_11_head{v323_11_label};
        const Space v324_2 = singleton(v323_11_head);
        const Space v324_3 = intersect(constant_14,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_15 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_11_head);
          const Space v325_7 = routine_68(c, v325_6, p1, v323_11_tail);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_14,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_15 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_11_head);
          const Space v326_11 = routine_33(c, v326_6, p1, v323_11_tail);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_11_result = unite(v323_11_result,v324_13);
      }
      const Space v323_11 = std::move(v323_11_result);
      v318_12 = compose(v318_10,v323_11);
    }
    const Space v318_13 = unite(v318_8,v318_12);
    v317_12_result = unite(v317_12_result,v318_13);
  }
  const Space v317_12 = std::move(v317_12_result);
  return v317_12;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v327_9_result;
  for (int v327_9_label = 1; v327_9_label <= 2; ++v327_9_label) {
    const Space v327_9_tail = child(s0,v327_9_label);
    if (v327_9_tail.empty()) continue;
    const Path v327_9_head{v327_9_label};
    const Space v328_2 = singleton(v327_9_head);
    const Space v328_3 = intersect(constant_14,v328_2);
    const Space v328_4 = (has_head(v328_3) ? constant_15 : Space{});
    const Space v328_5 = subtract(constant_0,v328_4);
    Space v328_8;
    if (!v328_5.empty()) {
      const Path v329_6 = concat_path(p0,v327_9_head);
      Space v329_7_result;
      for (int v329_7_label = 1; v329_7_label <= 2; ++v329_7_label) {
        const Space v329_7_tail = child(v327_9_tail,v329_7_label);
        if (v329_7_tail.empty()) continue;
        const Path v329_7_head{v329_7_label};
        const Space v330_2 = singleton(v329_7_head);
        const Space v330_3 = intersect(constant_14,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_15 : Space{});
        const Space v330_5 = subtract(constant_0,v330_4);
        Space v330_8;
        if (!v330_5.empty()) {
          const Path v331_6 = concat_path(v329_6,v329_7_head);
          const Space v331_7 = routine_68(c, v331_6, p1, v329_7_tail);
          v330_8 = compose(v330_5,v331_7);
        }
        const Space v330_9 = intersect(constant_14,v330_2);
        const Space v330_10 = (has_head(v330_9) ? constant_15 : Space{});
        Space v330_12;
        if (!v330_10.empty()) {
          const Path v332_6 = concat_path(v329_6,v329_7_head);
          const Space v332_11 = routine_69(c, v332_6, p1, v329_7_tail);
          v330_12 = compose(v330_10,v332_11);
        }
        const Space v330_13 = unite(v330_8,v330_12);
        v329_7_result = unite(v329_7_result,v330_13);
      }
      const Space v329_7 = std::move(v329_7_result);
      v328_8 = compose(v328_5,v329_7);
    }
    const Space v328_9 = intersect(constant_14,v328_2);
    const Space v328_10 = (has_head(v328_9) ? constant_15 : Space{});
    const Space v328_11 = compose(v328_10,v327_9_tail);
    const Path v333_6 = concat_path(p0,v327_9_head);
    const Space v328_12 = wrap(v328_11,v333_6);
    const Space v328_13 = wrap(v328_12,p1);
    const Space v328_14 = unite(v328_8,v328_13);
    v327_9_result = unite(v327_9_result,v328_14);
  }
  const Space v327_9 = std::move(v327_9_result);
  return v327_9;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v334_12_result;
  for (int v334_12_label = 1; v334_12_label <= 2; ++v334_12_label) {
    const Space v334_12_tail = child(s0,v334_12_label);
    if (v334_12_tail.empty()) continue;
    const Path v334_12_head{v334_12_label};
    const Space v335_2 = singleton(v334_12_head);
    const Space v335_3 = intersect(constant_14,v335_2);
    const Space v335_4 = (has_head(v335_3) ? constant_15 : Space{});
    const Space v335_5 = subtract(constant_0,v335_4);
    Space v335_8;
    if (!v335_5.empty()) {
      const Path v336_6 = concat_path(p0,v334_12_head);
      Space v336_7_result;
      for (int v336_7_label = 1; v336_7_label <= 2; ++v336_7_label) {
        const Space v336_7_tail = child(v334_12_tail,v336_7_label);
        if (v336_7_tail.empty()) continue;
        const Path v336_7_head{v336_7_label};
        const Space v337_2 = singleton(v336_7_head);
        const Space v337_3 = intersect(constant_14,v337_2);
        const Space v337_4 = (has_head(v337_3) ? constant_15 : Space{});
        const Space v337_5 = subtract(constant_0,v337_4);
        Space v337_8;
        if (!v337_5.empty()) {
          const Path v338_6 = concat_path(v336_6,v336_7_head);
          const Space v338_7 = routine_70(c, v338_6, p1, v336_7_tail);
          v337_8 = compose(v337_5,v338_7);
        }
        const Space v337_9 = intersect(constant_14,v337_2);
        const Space v337_10 = (has_head(v337_9) ? constant_15 : Space{});
        Space v337_12;
        if (!v337_10.empty()) {
          const Path v339_6 = concat_path(v336_6,v336_7_head);
          const Space v339_11 = routine_71(c, v339_6, p1, v336_7_tail);
          v337_12 = compose(v337_10,v339_11);
        }
        const Space v337_13 = unite(v337_8,v337_12);
        v336_7_result = unite(v336_7_result,v337_13);
      }
      const Space v336_7 = std::move(v336_7_result);
      v335_8 = compose(v335_5,v336_7);
    }
    const Space v335_9 = intersect(constant_14,v335_2);
    const Space v335_10 = (has_head(v335_9) ? constant_15 : Space{});
    Space v335_12;
    if (!v335_10.empty()) {
      const Path v340_6 = concat_path(p0,v334_12_head);
      Space v340_11_result;
      for (int v340_11_label = 1; v340_11_label <= 2; ++v340_11_label) {
        const Space v340_11_tail = child(v334_12_tail,v340_11_label);
        if (v340_11_tail.empty()) continue;
        const Path v340_11_head{v340_11_label};
        const Space v341_2 = singleton(v340_11_head);
        const Space v341_3 = intersect(constant_14,v341_2);
        const Space v341_4 = (has_head(v341_3) ? constant_15 : Space{});
        const Space v341_5 = subtract(constant_0,v341_4);
        Space v341_8;
        if (!v341_5.empty()) {
          const Path v342_6 = concat_path(v340_6,v340_11_head);
          const Space v342_7 = routine_70(c, v342_6, p1, v340_11_tail);
          v341_8 = compose(v341_5,v342_7);
        }
        const Space v341_9 = intersect(constant_14,v341_2);
        const Space v341_10 = (has_head(v341_9) ? constant_15 : Space{});
        Space v341_12;
        if (!v341_10.empty()) {
          const Path v343_6 = concat_path(v340_6,v340_11_head);
          const Space v343_11 = routine_33(c, v343_6, p1, v340_11_tail);
          v341_12 = compose(v341_10,v343_11);
        }
        const Space v341_13 = unite(v341_8,v341_12);
        v340_11_result = unite(v340_11_result,v341_13);
      }
      const Space v340_11 = std::move(v340_11_result);
      v335_12 = compose(v335_10,v340_11);
    }
    const Space v335_13 = unite(v335_8,v335_12);
    v334_12_result = unite(v334_12_result,v335_13);
  }
  const Space v334_12 = std::move(v334_12_result);
  return v334_12;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v344_9_result;
  for (int v344_9_label = 1; v344_9_label <= 2; ++v344_9_label) {
    const Space v344_9_tail = child(s0,v344_9_label);
    if (v344_9_tail.empty()) continue;
    const Path v344_9_head{v344_9_label};
    const Space v345_2 = singleton(v344_9_head);
    const Space v345_3 = intersect(constant_14,v345_2);
    const Space v345_4 = (has_head(v345_3) ? constant_15 : Space{});
    const Space v345_5 = subtract(constant_0,v345_4);
    Space v345_8;
    if (!v345_5.empty()) {
      const Path v346_6 = concat_path(p0,v344_9_head);
      Space v346_7_result;
      for (int v346_7_label = 1; v346_7_label <= 2; ++v346_7_label) {
        const Space v346_7_tail = child(v344_9_tail,v346_7_label);
        if (v346_7_tail.empty()) continue;
        const Path v346_7_head{v346_7_label};
        const Space v347_2 = singleton(v346_7_head);
        const Space v347_3 = intersect(constant_14,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_15 : Space{});
        const Space v347_5 = subtract(constant_0,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v346_6,v346_7_head);
          const Space v348_7 = routine_70(c, v348_6, p1, v346_7_tail);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_14,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_15 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v346_6,v346_7_head);
          const Space v349_11 = routine_71(c, v349_6, p1, v346_7_tail);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_7_result = unite(v346_7_result,v347_13);
      }
      const Space v346_7 = std::move(v346_7_result);
      v345_8 = compose(v345_5,v346_7);
    }
    const Space v345_9 = intersect(constant_14,v345_2);
    const Space v345_10 = (has_head(v345_9) ? constant_15 : Space{});
    const Space v345_11 = compose(v345_10,v344_9_tail);
    const Path v350_6 = concat_path(p0,v344_9_head);
    const Space v345_12 = wrap(v345_11,v350_6);
    const Space v345_13 = wrap(v345_12,p1);
    const Space v345_14 = unite(v345_8,v345_13);
    v344_9_result = unite(v344_9_result,v345_14);
  }
  const Space v344_9 = std::move(v344_9_result);
  return v344_9;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v351_3 = wrap(s0,p0);
  const Space v351_4 = wrap(v351_3,p1);
  return v351_4;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v352_12_result;
  for (int v352_12_label = 1; v352_12_label <= 2; ++v352_12_label) {
    const Space v352_12_tail = child(s0,v352_12_label);
    if (v352_12_tail.empty()) continue;
    const Path v352_12_head{v352_12_label};
    const Space v353_2 = singleton(v352_12_head);
    const Space v353_3 = intersect(constant_14,v353_2);
    const Space v353_4 = (has_head(v353_3) ? constant_15 : Space{});
    const Space v353_5 = subtract(constant_0,v353_4);
    Space v353_8;
    if (!v353_5.empty()) {
      const Path v354_6 = concat_path(p0,v352_12_head);
      Space v354_7_result;
      for (int v354_7_label = 1; v354_7_label <= 2; ++v354_7_label) {
        const Space v354_7_tail = child(v352_12_tail,v354_7_label);
        if (v354_7_tail.empty()) continue;
        const Path v354_7_head{v354_7_label};
        const Space v355_2 = singleton(v354_7_head);
        const Space v355_3 = intersect(constant_14,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_15 : Space{});
        const Space v355_5 = subtract(constant_0,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_7_head);
          const Space v356_7 = routine_72(c, v356_6, v354_7_tail, s1);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_14,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_15 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_7_head);
          const Space v357_11 = routine_73(c, v357_6, v354_7_tail, s1);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_7_result = unite(v354_7_result,v355_13);
      }
      const Space v354_7 = std::move(v354_7_result);
      v353_8 = compose(v353_5,v354_7);
    }
    const Space v353_9 = intersect(constant_14,v353_2);
    const Space v353_10 = (has_head(v353_9) ? constant_15 : Space{});
    Space v353_12;
    if (!v353_10.empty()) {
      const Path v358_6 = concat_path(p0,v352_12_head);
      Space v358_11_result;
      for (int v358_11_label = 1; v358_11_label <= 2; ++v358_11_label) {
        const Space v358_11_tail = child(v352_12_tail,v358_11_label);
        if (v358_11_tail.empty()) continue;
        const Path v358_11_head{v358_11_label};
        const Space v359_2 = singleton(v358_11_head);
        const Space v359_3 = intersect(constant_14,v359_2);
        const Space v359_4 = (has_head(v359_3) ? constant_15 : Space{});
        const Space v359_5 = subtract(constant_0,v359_4);
        Space v359_8;
        if (!v359_5.empty()) {
          const Path v360_6 = concat_path(v358_6,v358_11_head);
          const Space v360_7 = routine_72(c, v360_6, v358_11_tail, s1);
          v359_8 = compose(v359_5,v360_7);
        }
        const Space v359_9 = intersect(constant_14,v359_2);
        const Space v359_10 = (has_head(v359_9) ? constant_15 : Space{});
        Space v359_12;
        if (!v359_10.empty()) {
          const Path v361_6 = concat_path(v358_6,v358_11_head);
          const Space v361_11 = routine_11(c, v361_6, v358_11_tail, s1);
          v359_12 = compose(v359_10,v361_11);
        }
        const Space v359_13 = unite(v359_8,v359_12);
        v358_11_result = unite(v358_11_result,v359_13);
      }
      const Space v358_11 = std::move(v358_11_result);
      v353_12 = compose(v353_10,v358_11);
    }
    const Space v353_13 = unite(v353_8,v353_12);
    v352_12_result = unite(v352_12_result,v353_13);
  }
  const Space v352_12 = std::move(v352_12_result);
  return v352_12;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v362_12_result;
  for (int v362_12_label = 1; v362_12_label <= 2; ++v362_12_label) {
    const Space v362_12_tail = child(s0,v362_12_label);
    if (v362_12_tail.empty()) continue;
    const Path v362_12_head{v362_12_label};
    const Space v363_2 = singleton(v362_12_head);
    const Space v363_3 = intersect(constant_14,v363_2);
    const Space v363_4 = (has_head(v363_3) ? constant_15 : Space{});
    const Space v363_5 = subtract(constant_0,v363_4);
    Space v363_8;
    if (!v363_5.empty()) {
      const Path v364_6 = concat_path(p0,v362_12_head);
      Space v364_7_result;
      for (int v364_7_label = 1; v364_7_label <= 2; ++v364_7_label) {
        const Space v364_7_tail = child(v362_12_tail,v364_7_label);
        if (v364_7_tail.empty()) continue;
        const Path v364_7_head{v364_7_label};
        const Space v365_2 = singleton(v364_7_head);
        const Space v365_3 = intersect(constant_14,v365_2);
        const Space v365_4 = (has_head(v365_3) ? constant_15 : Space{});
        const Space v365_5 = subtract(constant_0,v365_4);
        Space v365_8;
        if (!v365_5.empty()) {
          const Path v366_6 = concat_path(v364_6,v364_7_head);
          const Space v366_7 = routine_72(c, v366_6, v364_7_tail, s1);
          v365_8 = compose(v365_5,v366_7);
        }
        const Space v365_9 = intersect(constant_14,v365_2);
        const Space v365_10 = (has_head(v365_9) ? constant_15 : Space{});
        Space v365_12;
        if (!v365_10.empty()) {
          const Path v367_6 = concat_path(v364_6,v364_7_head);
          const Space v367_11 = routine_73(c, v367_6, v364_7_tail, s1);
          v365_12 = compose(v365_10,v367_11);
        }
        const Space v365_13 = unite(v365_8,v365_12);
        v364_7_result = unite(v364_7_result,v365_13);
      }
      const Space v364_7 = std::move(v364_7_result);
      v363_8 = compose(v363_5,v364_7);
    }
    const Space v363_9 = intersect(constant_14,v363_2);
    const Space v363_10 = (has_head(v363_9) ? constant_15 : Space{});
    Space v363_12;
    if (!v363_10.empty()) {
      const Path v368_6 = concat_path(p0,v362_12_head);
      Space v368_11_result;
      for (int v368_11_label = 1; v368_11_label <= 2; ++v368_11_label) {
        const Space v368_11_tail = child(v362_12_tail,v368_11_label);
        if (v368_11_tail.empty()) continue;
        const Path v368_11_head{v368_11_label};
        const Space v369_2 = singleton(v368_11_head);
        const Space v369_3 = intersect(constant_14,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_15 : Space{});
        const Space v369_5 = subtract(constant_0,v369_4);
        Space v369_7;
        if (!v369_5.empty()) {
          const Space v370_6 = routine_36(c, v368_11_head, v368_6, v368_11_tail, s1);
          v369_7 = compose(v369_5,v370_6);
        }
        const Space v369_8 = intersect(constant_14,v369_2);
        const Space v369_9 = (has_head(v369_8) ? constant_15 : Space{});
        Space v369_11;
        if (!v369_9.empty()) {
          const Space v371_10 = routine_37(c, v368_11_head, v368_6, v368_11_tail, s1);
          v369_11 = compose(v369_9,v371_10);
        }
        const Space v369_12 = unite(v369_7,v369_11);
        v368_11_result = unite(v368_11_result,v369_12);
      }
      const Space v368_11 = std::move(v368_11_result);
      v363_12 = compose(v363_10,v368_11);
    }
    const Space v363_13 = unite(v363_8,v363_12);
    v362_12_result = unite(v362_12_result,v363_13);
  }
  const Space v362_12 = std::move(v362_12_result);
  return v362_12;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v372_13_result;
  for (int v372_13_label = 1; v372_13_label <= 2; ++v372_13_label) {
    const Space v372_13_tail = child(s0,v372_13_label);
    if (v372_13_tail.empty()) continue;
    const Path v372_13_head{v372_13_label};
    const Space v373_2 = singleton(v372_13_head);
    const Space v373_3 = intersect(constant_14,v373_2);
    const Space v373_4 = (has_head(v373_3) ? constant_15 : Space{});
    const Space v373_5 = subtract(constant_0,v373_4);
    Space v373_8;
    if (!v373_5.empty()) {
      const Path v374_6 = concat_path(p0,v372_13_head);
      Space v374_7_result;
      for (int v374_7_label = 1; v374_7_label <= 2; ++v374_7_label) {
        const Space v374_7_tail = child(v372_13_tail,v374_7_label);
        if (v374_7_tail.empty()) continue;
        const Path v374_7_head{v374_7_label};
        const Space v375_2 = singleton(v374_7_head);
        const Space v375_3 = intersect(constant_14,v375_2);
        const Space v375_4 = (has_head(v375_3) ? constant_15 : Space{});
        const Space v375_5 = subtract(constant_0,v375_4);
        Space v375_8;
        if (!v375_5.empty()) {
          const Path v376_6 = concat_path(v374_6,v374_7_head);
          const Space v376_7 = routine_74(c, v376_6, p1, v374_7_tail, s1);
          v375_8 = compose(v375_5,v376_7);
        }
        const Space v375_9 = intersect(constant_14,v375_2);
        const Space v375_10 = (has_head(v375_9) ? constant_15 : Space{});
        Space v375_12;
        if (!v375_10.empty()) {
          const Path v377_6 = concat_path(v374_6,v374_7_head);
          const Space v377_11 = routine_75(c, v377_6, p1, v374_7_tail, s1);
          v375_12 = compose(v375_10,v377_11);
        }
        const Space v375_13 = unite(v375_8,v375_12);
        v374_7_result = unite(v374_7_result,v375_13);
      }
      const Space v374_7 = std::move(v374_7_result);
      v373_8 = compose(v373_5,v374_7);
    }
    const Space v373_9 = intersect(constant_14,v373_2);
    const Space v373_10 = (has_head(v373_9) ? constant_15 : Space{});
    Space v373_12;
    if (!v373_10.empty()) {
      const Path v378_6 = concat_path(p0,v372_13_head);
      Space v378_11_result;
      for (int v378_11_label = 1; v378_11_label <= 2; ++v378_11_label) {
        const Space v378_11_tail = child(v372_13_tail,v378_11_label);
        if (v378_11_tail.empty()) continue;
        const Path v378_11_head{v378_11_label};
        const Space v379_2 = singleton(v378_11_head);
        const Space v379_3 = intersect(constant_14,v379_2);
        const Space v379_4 = (has_head(v379_3) ? constant_15 : Space{});
        const Space v379_5 = subtract(constant_0,v379_4);
        Space v379_8;
        if (!v379_5.empty()) {
          const Path v380_6 = concat_path(v378_6,v378_11_head);
          const Space v380_7 = routine_74(c, v380_6, p1, v378_11_tail, s1);
          v379_8 = compose(v379_5,v380_7);
        }
        const Space v379_9 = intersect(constant_14,v379_2);
        const Space v379_10 = (has_head(v379_9) ? constant_15 : Space{});
        Space v379_12;
        if (!v379_10.empty()) {
          const Path v381_6 = concat_path(v378_6,v378_11_head);
          const Space v381_11 = routine_40(c, v381_6, p1, v378_11_tail, s1);
          v379_12 = compose(v379_10,v381_11);
        }
        const Space v379_13 = unite(v379_8,v379_12);
        v378_11_result = unite(v378_11_result,v379_13);
      }
      const Space v378_11 = std::move(v378_11_result);
      v373_12 = compose(v373_10,v378_11);
    }
    const Space v373_13 = unite(v373_8,v373_12);
    v372_13_result = unite(v372_13_result,v373_13);
  }
  const Space v372_13 = std::move(v372_13_result);
  return v372_13;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v382_8 = unwrap(s1,constant_9);
  const Space v382_10 = unwrap(v382_8,constant_10);
  const Space v382_11 = unwrap(v382_10,p0);
  Space v382_18_result;
  for (int v382_18_label = 1; v382_18_label <= 2; ++v382_18_label) {
    const Space v382_18_tail = child(s0,v382_18_label);
    if (v382_18_tail.empty()) continue;
    const Path v382_18_head{v382_18_label};
    const Space v383_2 = singleton(v382_18_head);
    const Space v383_3 = intersect(constant_14,v383_2);
    const Space v383_4 = (has_head(v383_3) ? constant_15 : Space{});
    const Space v383_5 = subtract(constant_0,v383_4);
    Space v383_8;
    if (!v383_5.empty()) {
      const Path v384_6 = concat_path(p0,v382_18_head);
      Space v384_7_result;
      for (int v384_7_label = 1; v384_7_label <= 2; ++v384_7_label) {
        const Space v384_7_tail = child(v382_18_tail,v384_7_label);
        if (v384_7_tail.empty()) continue;
        const Path v384_7_head{v384_7_label};
        const Space v385_2 = singleton(v384_7_head);
        const Space v385_3 = intersect(constant_14,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_15 : Space{});
        const Space v385_5 = subtract(constant_0,v385_4);
        Space v385_8;
        if (!v385_5.empty()) {
          const Path v386_6 = concat_path(v384_6,v384_7_head);
          const Space v386_7 = routine_74(c, v386_6, p1, v384_7_tail, s1);
          v385_8 = compose(v385_5,v386_7);
        }
        const Space v385_9 = intersect(constant_14,v385_2);
        const Space v385_10 = (has_head(v385_9) ? constant_15 : Space{});
        Space v385_12;
        if (!v385_10.empty()) {
          const Path v387_6 = concat_path(v384_6,v384_7_head);
          const Space v387_11 = routine_75(c, v387_6, p1, v384_7_tail, s1);
          v385_12 = compose(v385_10,v387_11);
        }
        const Space v385_13 = unite(v385_8,v385_12);
        v384_7_result = unite(v384_7_result,v385_13);
      }
      const Space v384_7 = std::move(v384_7_result);
      v383_8 = compose(v383_5,v384_7);
    }
    const Space v383_9 = intersect(constant_14,v383_2);
    const Space v383_10 = (has_head(v383_9) ? constant_15 : Space{});
    Space v383_13;
    if (!v383_10.empty()) {
      const Space v388_11 = unwrap(v382_11,v382_18_head);
      Space v388_12_result;
      for (int v388_12_label = 1; v388_12_label <= 2; ++v388_12_label) {
        const Space v388_12_tail = child(v388_11,v388_12_label);
        if (v388_12_tail.empty()) continue;
        const Path v388_12_head{v388_12_label};
        const Space v389_2 = singleton(v388_12_head);
        const Space v389_3 = intersect(constant_14,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_15 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_7;
        if (!v389_5.empty()) {
          const Space v390_6 = routine_76(c, v388_12_head, p1, v388_12_tail);
          v389_7 = compose(v389_5,v390_6);
        }
        const Space v389_8 = intersect(constant_14,v389_2);
        const Space v389_9 = (has_head(v389_8) ? constant_15 : Space{});
        Space v389_11;
        if (!v389_9.empty()) {
          const Space v391_10 = routine_77(c, v388_12_head, p1, v388_12_tail);
          v389_11 = compose(v389_9,v391_10);
        }
        const Space v389_12 = unite(v389_7,v389_11);
        v388_12_result = unite(v388_12_result,v389_12);
      }
      const Space v388_12 = std::move(v388_12_result);
      v383_13 = compose(v383_10,v388_12);
    }
    const Space v383_14 = unite(v383_8,v383_13);
    v382_18_result = unite(v382_18_result,v383_14);
  }
  const Space v382_18 = std::move(v382_18_result);
  return v382_18;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v392_13_result;
  for (int v392_13_label = 1; v392_13_label <= 2; ++v392_13_label) {
    const Space v392_13_tail = child(s0,v392_13_label);
    if (v392_13_tail.empty()) continue;
    const Path v392_13_head{v392_13_label};
    const Space v393_2 = singleton(v392_13_head);
    const Space v393_3 = intersect(constant_14,v393_2);
    const Space v393_4 = (has_head(v393_3) ? constant_15 : Space{});
    const Space v393_5 = subtract(constant_0,v393_4);
    Space v393_8;
    if (!v393_5.empty()) {
      const Path v394_6 = concat_path(p0,v392_13_head);
      Space v394_7_result;
      for (int v394_7_label = 1; v394_7_label <= 2; ++v394_7_label) {
        const Space v394_7_tail = child(v392_13_tail,v394_7_label);
        if (v394_7_tail.empty()) continue;
        const Path v394_7_head{v394_7_label};
        const Space v395_2 = singleton(v394_7_head);
        const Space v395_3 = intersect(constant_14,v395_2);
        const Space v395_4 = (has_head(v395_3) ? constant_15 : Space{});
        const Space v395_5 = subtract(constant_0,v395_4);
        Space v395_8;
        if (!v395_5.empty()) {
          const Path v396_6 = concat_path(v394_6,v394_7_head);
          const Space v396_7 = routine_78(c, v396_6, p1, v394_7_tail, s1);
          v395_8 = compose(v395_5,v396_7);
        }
        const Space v395_9 = intersect(constant_14,v395_2);
        const Space v395_10 = (has_head(v395_9) ? constant_15 : Space{});
        Space v395_12;
        if (!v395_10.empty()) {
          const Path v397_6 = concat_path(v394_6,v394_7_head);
          const Space v397_11 = routine_79(c, v397_6, p1, v394_7_tail, s1);
          v395_12 = compose(v395_10,v397_11);
        }
        const Space v395_13 = unite(v395_8,v395_12);
        v394_7_result = unite(v394_7_result,v395_13);
      }
      const Space v394_7 = std::move(v394_7_result);
      v393_8 = compose(v393_5,v394_7);
    }
    const Space v393_9 = intersect(constant_14,v393_2);
    const Space v393_10 = (has_head(v393_9) ? constant_15 : Space{});
    Space v393_12;
    if (!v393_10.empty()) {
      const Path v398_6 = concat_path(p0,v392_13_head);
      Space v398_11_result;
      for (int v398_11_label = 1; v398_11_label <= 2; ++v398_11_label) {
        const Space v398_11_tail = child(v392_13_tail,v398_11_label);
        if (v398_11_tail.empty()) continue;
        const Path v398_11_head{v398_11_label};
        const Space v399_2 = singleton(v398_11_head);
        const Space v399_3 = intersect(constant_14,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_15 : Space{});
        const Space v399_5 = subtract(constant_0,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_11_head);
          const Space v400_7 = routine_78(c, v400_6, p1, v398_11_tail, s1);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_14,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_15 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_11_head);
          const Space v401_11 = routine_40(c, v401_6, p1, v398_11_tail, s1);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_11_result = unite(v398_11_result,v399_13);
      }
      const Space v398_11 = std::move(v398_11_result);
      v393_12 = compose(v393_10,v398_11);
    }
    const Space v393_13 = unite(v393_8,v393_12);
    v392_13_result = unite(v392_13_result,v393_13);
  }
  const Space v392_13 = std::move(v392_13_result);
  return v392_13;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v402_8 = unwrap(s1,constant_9);
  const Space v402_10 = unwrap(v402_8,constant_10);
  const Space v402_11 = unwrap(v402_10,p0);
  Space v402_18_result;
  for (int v402_18_label = 1; v402_18_label <= 2; ++v402_18_label) {
    const Space v402_18_tail = child(s0,v402_18_label);
    if (v402_18_tail.empty()) continue;
    const Path v402_18_head{v402_18_label};
    const Space v403_2 = singleton(v402_18_head);
    const Space v403_3 = intersect(constant_14,v403_2);
    const Space v403_4 = (has_head(v403_3) ? constant_15 : Space{});
    const Space v403_5 = subtract(constant_0,v403_4);
    Space v403_8;
    if (!v403_5.empty()) {
      const Path v404_6 = concat_path(p0,v402_18_head);
      Space v404_7_result;
      for (int v404_7_label = 1; v404_7_label <= 2; ++v404_7_label) {
        const Space v404_7_tail = child(v402_18_tail,v404_7_label);
        if (v404_7_tail.empty()) continue;
        const Path v404_7_head{v404_7_label};
        const Space v405_2 = singleton(v404_7_head);
        const Space v405_3 = intersect(constant_14,v405_2);
        const Space v405_4 = (has_head(v405_3) ? constant_15 : Space{});
        const Space v405_5 = subtract(constant_0,v405_4);
        Space v405_8;
        if (!v405_5.empty()) {
          const Path v406_6 = concat_path(v404_6,v404_7_head);
          const Space v406_7 = routine_78(c, v406_6, p1, v404_7_tail, s1);
          v405_8 = compose(v405_5,v406_7);
        }
        const Space v405_9 = intersect(constant_14,v405_2);
        const Space v405_10 = (has_head(v405_9) ? constant_15 : Space{});
        Space v405_12;
        if (!v405_10.empty()) {
          const Path v407_6 = concat_path(v404_6,v404_7_head);
          const Space v407_11 = routine_79(c, v407_6, p1, v404_7_tail, s1);
          v405_12 = compose(v405_10,v407_11);
        }
        const Space v405_13 = unite(v405_8,v405_12);
        v404_7_result = unite(v404_7_result,v405_13);
      }
      const Space v404_7 = std::move(v404_7_result);
      v403_8 = compose(v403_5,v404_7);
    }
    const Space v403_9 = intersect(constant_14,v403_2);
    const Space v403_10 = (has_head(v403_9) ? constant_15 : Space{});
    Space v403_13;
    if (!v403_10.empty()) {
      const Space v408_11 = unwrap(v402_11,v402_18_head);
      Space v408_12_result;
      for (int v408_12_label = 1; v408_12_label <= 2; ++v408_12_label) {
        const Space v408_12_tail = child(v408_11,v408_12_label);
        if (v408_12_tail.empty()) continue;
        const Path v408_12_head{v408_12_label};
        const Space v409_2 = singleton(v408_12_head);
        const Space v409_3 = intersect(constant_14,v409_2);
        const Space v409_4 = (has_head(v409_3) ? constant_15 : Space{});
        const Space v409_5 = subtract(constant_0,v409_4);
        Space v409_7;
        if (!v409_5.empty()) {
          const Space v410_6 = routine_76(c, v408_12_head, p1, v408_12_tail);
          v409_7 = compose(v409_5,v410_6);
        }
        const Space v409_8 = intersect(constant_14,v409_2);
        const Space v409_9 = (has_head(v409_8) ? constant_15 : Space{});
        Space v409_11;
        if (!v409_9.empty()) {
          const Space v411_10 = routine_77(c, v408_12_head, p1, v408_12_tail);
          v409_11 = compose(v409_9,v411_10);
        }
        const Space v409_12 = unite(v409_7,v409_11);
        v408_12_result = unite(v408_12_result,v409_12);
      }
      const Space v408_12 = std::move(v408_12_result);
      v403_13 = compose(v403_10,v408_12);
    }
    const Space v403_14 = unite(v403_8,v403_13);
    v402_18_result = unite(v402_18_result,v403_14);
  }
  const Space v402_18 = std::move(v402_18_result);
  return v402_18;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v412_5 = unwrap(s1,constant_9);
  const Space v412_7 = unwrap(v412_5,constant_10);
  const Space v412_8 = unwrap(v412_7,p0);
  Space v412_18_result;
  for (int v412_18_label = 1; v412_18_label <= 2; ++v412_18_label) {
    const Space v412_18_tail = child(v412_8,v412_18_label);
    if (v412_18_tail.empty()) continue;
    const Path v412_18_head{v412_18_label};
    const Space v413_2 = singleton(v412_18_head);
    const Space v413_3 = intersect(constant_14,v413_2);
    const Space v413_4 = (has_head(v413_3) ? constant_15 : Space{});
    const Space v413_5 = subtract(constant_0,v413_4);
    Space v413_7;
    if (!v413_5.empty()) {
      Space v414_6_result;
      for (int v414_6_label = 1; v414_6_label <= 2; ++v414_6_label) {
        const Space v414_6_tail = child(v412_18_tail,v414_6_label);
        if (v414_6_tail.empty()) continue;
        const Path v414_6_head{v414_6_label};
        const Space v415_2 = singleton(v414_6_head);
        const Space v415_3 = intersect(constant_14,v415_2);
        const Space v415_4 = (has_head(v415_3) ? constant_15 : Space{});
        const Space v415_5 = subtract(constant_0,v415_4);
        Space v415_8;
        if (!v415_5.empty()) {
          const Path v416_6 = concat_path(v412_18_head,v414_6_head);
          const Space v416_7 = routine_80(c, v416_6, p1, v414_6_tail);
          v415_8 = compose(v415_5,v416_7);
        }
        const Space v415_9 = intersect(constant_14,v415_2);
        const Space v415_10 = (has_head(v415_9) ? constant_15 : Space{});
        Space v415_12;
        if (!v415_10.empty()) {
          const Path v417_6 = concat_path(v412_18_head,v414_6_head);
          const Space v417_11 = routine_81(c, v417_6, p1, v414_6_tail);
          v415_12 = compose(v415_10,v417_11);
        }
        const Space v415_13 = unite(v415_8,v415_12);
        v414_6_result = unite(v414_6_result,v415_13);
      }
      const Space v414_6 = std::move(v414_6_result);
      v413_7 = compose(v413_5,v414_6);
    }
    const Space v413_8 = intersect(constant_14,v413_2);
    const Space v413_9 = (has_head(v413_8) ? constant_15 : Space{});
    Space v413_11;
    if (!v413_9.empty()) {
      Space v418_10_result;
      for (int v418_10_label = 1; v418_10_label <= 2; ++v418_10_label) {
        const Space v418_10_tail = child(v412_18_tail,v418_10_label);
        if (v418_10_tail.empty()) continue;
        const Path v418_10_head{v418_10_label};
        const Space v419_2 = singleton(v418_10_head);
        const Space v419_3 = intersect(constant_14,v419_2);
        const Space v419_4 = (has_head(v419_3) ? constant_15 : Space{});
        const Space v419_5 = subtract(constant_0,v419_4);
        Space v419_8;
        if (!v419_5.empty()) {
          const Path v420_6 = concat_path(v412_18_head,v418_10_head);
          const Space v420_7 = routine_80(c, v420_6, p1, v418_10_tail);
          v419_8 = compose(v419_5,v420_7);
        }
        const Space v419_9 = intersect(constant_14,v419_2);
        const Space v419_10 = (has_head(v419_9) ? constant_15 : Space{});
        Space v419_12;
        if (!v419_10.empty()) {
          const Path v421_6 = concat_path(v412_18_head,v418_10_head);
          const Space v421_11 = routine_82(c, v421_6, p1, v418_10_tail);
          v419_12 = compose(v419_10,v421_11);
        }
        const Space v419_13 = unite(v419_8,v419_12);
        v418_10_result = unite(v418_10_result,v419_13);
      }
      const Space v418_10 = std::move(v418_10_result);
      v413_11 = compose(v413_9,v418_10);
    }
    const Space v413_12 = unite(v413_7,v413_11);
    v412_18_result = unite(v412_18_result,v413_12);
  }
  const Space v412_18 = std::move(v412_18_result);
  return v412_18;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v422_12_result;
  for (int v422_12_label = 1; v422_12_label <= 2; ++v422_12_label) {
    const Space v422_12_tail = child(s0,v422_12_label);
    if (v422_12_tail.empty()) continue;
    const Path v422_12_head{v422_12_label};
    const Space v423_2 = singleton(v422_12_head);
    const Space v423_3 = intersect(constant_14,v423_2);
    const Space v423_4 = (has_head(v423_3) ? constant_15 : Space{});
    const Space v423_5 = subtract(constant_0,v423_4);
    Space v423_8;
    if (!v423_5.empty()) {
      const Path v424_6 = concat_path(p0,v422_12_head);
      Space v424_7_result;
      for (int v424_7_label = 1; v424_7_label <= 2; ++v424_7_label) {
        const Space v424_7_tail = child(v422_12_tail,v424_7_label);
        if (v424_7_tail.empty()) continue;
        const Path v424_7_head{v424_7_label};
        const Space v425_2 = singleton(v424_7_head);
        const Space v425_3 = intersect(constant_14,v425_2);
        const Space v425_4 = (has_head(v425_3) ? constant_15 : Space{});
        const Space v425_5 = subtract(constant_0,v425_4);
        Space v425_8;
        if (!v425_5.empty()) {
          const Path v426_6 = concat_path(v424_6,v424_7_head);
          const Space v426_7 = routine_83(c, v426_6, v424_7_tail, s1);
          v425_8 = compose(v425_5,v426_7);
        }
        const Space v425_9 = intersect(constant_14,v425_2);
        const Space v425_10 = (has_head(v425_9) ? constant_15 : Space{});
        Space v425_12;
        if (!v425_10.empty()) {
          const Path v427_6 = concat_path(v424_6,v424_7_head);
          const Space v427_11 = routine_84(c, v427_6, v424_7_tail, s1);
          v425_12 = compose(v425_10,v427_11);
        }
        const Space v425_13 = unite(v425_8,v425_12);
        v424_7_result = unite(v424_7_result,v425_13);
      }
      const Space v424_7 = std::move(v424_7_result);
      v423_8 = compose(v423_5,v424_7);
    }
    const Space v423_9 = intersect(constant_14,v423_2);
    const Space v423_10 = (has_head(v423_9) ? constant_15 : Space{});
    Space v423_12;
    if (!v423_10.empty()) {
      const Path v428_6 = concat_path(p0,v422_12_head);
      Space v428_11_result;
      for (int v428_11_label = 1; v428_11_label <= 2; ++v428_11_label) {
        const Space v428_11_tail = child(v422_12_tail,v428_11_label);
        if (v428_11_tail.empty()) continue;
        const Path v428_11_head{v428_11_label};
        const Space v429_2 = singleton(v428_11_head);
        const Space v429_3 = intersect(constant_14,v429_2);
        const Space v429_4 = (has_head(v429_3) ? constant_15 : Space{});
        const Space v429_5 = subtract(constant_0,v429_4);
        Space v429_8;
        if (!v429_5.empty()) {
          const Path v430_6 = concat_path(v428_6,v428_11_head);
          const Space v430_7 = routine_83(c, v430_6, v428_11_tail, s1);
          v429_8 = compose(v429_5,v430_7);
        }
        const Space v429_9 = intersect(constant_14,v429_2);
        const Space v429_10 = (has_head(v429_9) ? constant_15 : Space{});
        Space v429_12;
        if (!v429_10.empty()) {
          const Path v431_6 = concat_path(v428_6,v428_11_head);
          const Space v431_11 = routine_14(c, v431_6, v428_11_tail, s1);
          v429_12 = compose(v429_10,v431_11);
        }
        const Space v429_13 = unite(v429_8,v429_12);
        v428_11_result = unite(v428_11_result,v429_13);
      }
      const Space v428_11 = std::move(v428_11_result);
      v423_12 = compose(v423_10,v428_11);
    }
    const Space v423_13 = unite(v423_8,v423_12);
    v422_12_result = unite(v422_12_result,v423_13);
  }
  const Space v422_12 = std::move(v422_12_result);
  return v422_12;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v432_12_result;
  for (int v432_12_label = 1; v432_12_label <= 2; ++v432_12_label) {
    const Space v432_12_tail = child(s0,v432_12_label);
    if (v432_12_tail.empty()) continue;
    const Path v432_12_head{v432_12_label};
    const Space v433_2 = singleton(v432_12_head);
    const Space v433_3 = intersect(constant_14,v433_2);
    const Space v433_4 = (has_head(v433_3) ? constant_15 : Space{});
    const Space v433_5 = subtract(constant_0,v433_4);
    Space v433_8;
    if (!v433_5.empty()) {
      const Path v434_6 = concat_path(p0,v432_12_head);
      Space v434_7_result;
      for (int v434_7_label = 1; v434_7_label <= 2; ++v434_7_label) {
        const Space v434_7_tail = child(v432_12_tail,v434_7_label);
        if (v434_7_tail.empty()) continue;
        const Path v434_7_head{v434_7_label};
        const Space v435_2 = singleton(v434_7_head);
        const Space v435_3 = intersect(constant_14,v435_2);
        const Space v435_4 = (has_head(v435_3) ? constant_15 : Space{});
        const Space v435_5 = subtract(constant_0,v435_4);
        Space v435_8;
        if (!v435_5.empty()) {
          const Path v436_6 = concat_path(v434_6,v434_7_head);
          const Space v436_7 = routine_83(c, v436_6, v434_7_tail, s1);
          v435_8 = compose(v435_5,v436_7);
        }
        const Space v435_9 = intersect(constant_14,v435_2);
        const Space v435_10 = (has_head(v435_9) ? constant_15 : Space{});
        Space v435_12;
        if (!v435_10.empty()) {
          const Path v437_6 = concat_path(v434_6,v434_7_head);
          const Space v437_11 = routine_84(c, v437_6, v434_7_tail, s1);
          v435_12 = compose(v435_10,v437_11);
        }
        const Space v435_13 = unite(v435_8,v435_12);
        v434_7_result = unite(v434_7_result,v435_13);
      }
      const Space v434_7 = std::move(v434_7_result);
      v433_8 = compose(v433_5,v434_7);
    }
    const Space v433_9 = intersect(constant_14,v433_2);
    const Space v433_10 = (has_head(v433_9) ? constant_15 : Space{});
    Space v433_12;
    if (!v433_10.empty()) {
      const Path v438_6 = concat_path(p0,v432_12_head);
      Space v438_11_result;
      for (int v438_11_label = 1; v438_11_label <= 2; ++v438_11_label) {
        const Space v438_11_tail = child(v432_12_tail,v438_11_label);
        if (v438_11_tail.empty()) continue;
        const Path v438_11_head{v438_11_label};
        const Space v439_2 = singleton(v438_11_head);
        const Space v439_3 = intersect(constant_14,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_15 : Space{});
        const Space v439_5 = subtract(constant_0,v439_4);
        Space v439_7;
        if (!v439_5.empty()) {
          const Space v440_6 = routine_43(c, v438_11_head, v438_6, v438_11_tail, s1);
          v439_7 = compose(v439_5,v440_6);
        }
        const Space v439_8 = intersect(constant_14,v439_2);
        const Space v439_9 = (has_head(v439_8) ? constant_15 : Space{});
        Space v439_11;
        if (!v439_9.empty()) {
          const Space v441_10 = routine_44(c, v438_11_head, v438_6, v438_11_tail, s1);
          v439_11 = compose(v439_9,v441_10);
        }
        const Space v439_12 = unite(v439_7,v439_11);
        v438_11_result = unite(v438_11_result,v439_12);
      }
      const Space v438_11 = std::move(v438_11_result);
      v433_12 = compose(v433_10,v438_11);
    }
    const Space v433_13 = unite(v433_8,v433_12);
    v432_12_result = unite(v432_12_result,v433_13);
  }
  const Space v432_12 = std::move(v432_12_result);
  return v432_12;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v442_13_result;
  for (int v442_13_label = 1; v442_13_label <= 2; ++v442_13_label) {
    const Space v442_13_tail = child(s0,v442_13_label);
    if (v442_13_tail.empty()) continue;
    const Path v442_13_head{v442_13_label};
    const Space v443_2 = singleton(v442_13_head);
    const Space v443_3 = intersect(constant_14,v443_2);
    const Space v443_4 = (has_head(v443_3) ? constant_15 : Space{});
    const Space v443_5 = subtract(constant_0,v443_4);
    Space v443_8;
    if (!v443_5.empty()) {
      const Path v444_6 = concat_path(p0,v442_13_head);
      Space v444_7_result;
      for (int v444_7_label = 1; v444_7_label <= 2; ++v444_7_label) {
        const Space v444_7_tail = child(v442_13_tail,v444_7_label);
        if (v444_7_tail.empty()) continue;
        const Path v444_7_head{v444_7_label};
        const Space v445_2 = singleton(v444_7_head);
        const Space v445_3 = intersect(constant_14,v445_2);
        const Space v445_4 = (has_head(v445_3) ? constant_15 : Space{});
        const Space v445_5 = subtract(constant_0,v445_4);
        Space v445_8;
        if (!v445_5.empty()) {
          const Path v446_6 = concat_path(v444_6,v444_7_head);
          const Space v446_7 = routine_85(c, v446_6, p1, v444_7_tail, s1);
          v445_8 = compose(v445_5,v446_7);
        }
        const Space v445_9 = intersect(constant_14,v445_2);
        const Space v445_10 = (has_head(v445_9) ? constant_15 : Space{});
        Space v445_12;
        if (!v445_10.empty()) {
          const Path v447_6 = concat_path(v444_6,v444_7_head);
          const Space v447_11 = routine_86(c, v447_6, p1, v444_7_tail, s1);
          v445_12 = compose(v445_10,v447_11);
        }
        const Space v445_13 = unite(v445_8,v445_12);
        v444_7_result = unite(v444_7_result,v445_13);
      }
      const Space v444_7 = std::move(v444_7_result);
      v443_8 = compose(v443_5,v444_7);
    }
    const Space v443_9 = intersect(constant_14,v443_2);
    const Space v443_10 = (has_head(v443_9) ? constant_15 : Space{});
    Space v443_12;
    if (!v443_10.empty()) {
      const Path v448_6 = concat_path(p0,v442_13_head);
      Space v448_11_result;
      for (int v448_11_label = 1; v448_11_label <= 2; ++v448_11_label) {
        const Space v448_11_tail = child(v442_13_tail,v448_11_label);
        if (v448_11_tail.empty()) continue;
        const Path v448_11_head{v448_11_label};
        const Space v449_2 = singleton(v448_11_head);
        const Space v449_3 = intersect(constant_14,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_15 : Space{});
        const Space v449_5 = subtract(constant_0,v449_4);
        Space v449_8;
        if (!v449_5.empty()) {
          const Path v450_6 = concat_path(v448_6,v448_11_head);
          const Space v450_7 = routine_85(c, v450_6, p1, v448_11_tail, s1);
          v449_8 = compose(v449_5,v450_7);
        }
        const Space v449_9 = intersect(constant_14,v449_2);
        const Space v449_10 = (has_head(v449_9) ? constant_15 : Space{});
        Space v449_12;
        if (!v449_10.empty()) {
          const Path v451_6 = concat_path(v448_6,v448_11_head);
          const Space v451_11 = routine_47(c, v451_6, p1, v448_11_tail, s1);
          v449_12 = compose(v449_10,v451_11);
        }
        const Space v449_13 = unite(v449_8,v449_12);
        v448_11_result = unite(v448_11_result,v449_13);
      }
      const Space v448_11 = std::move(v448_11_result);
      v443_12 = compose(v443_10,v448_11);
    }
    const Space v443_13 = unite(v443_8,v443_12);
    v442_13_result = unite(v442_13_result,v443_13);
  }
  const Space v442_13 = std::move(v442_13_result);
  return v442_13;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v452_8 = unwrap(s1,constant_7);
  const Space v452_10 = unwrap(v452_8,constant_10);
  const Space v452_11 = unwrap(v452_10,p0);
  Space v452_18_result;
  for (int v452_18_label = 1; v452_18_label <= 2; ++v452_18_label) {
    const Space v452_18_tail = child(s0,v452_18_label);
    if (v452_18_tail.empty()) continue;
    const Path v452_18_head{v452_18_label};
    const Space v453_2 = singleton(v452_18_head);
    const Space v453_3 = intersect(constant_14,v453_2);
    const Space v453_4 = (has_head(v453_3) ? constant_15 : Space{});
    const Space v453_5 = subtract(constant_0,v453_4);
    Space v453_8;
    if (!v453_5.empty()) {
      const Path v454_6 = concat_path(p0,v452_18_head);
      Space v454_7_result;
      for (int v454_7_label = 1; v454_7_label <= 2; ++v454_7_label) {
        const Space v454_7_tail = child(v452_18_tail,v454_7_label);
        if (v454_7_tail.empty()) continue;
        const Path v454_7_head{v454_7_label};
        const Space v455_2 = singleton(v454_7_head);
        const Space v455_3 = intersect(constant_14,v455_2);
        const Space v455_4 = (has_head(v455_3) ? constant_15 : Space{});
        const Space v455_5 = subtract(constant_0,v455_4);
        Space v455_8;
        if (!v455_5.empty()) {
          const Path v456_6 = concat_path(v454_6,v454_7_head);
          const Space v456_7 = routine_85(c, v456_6, p1, v454_7_tail, s1);
          v455_8 = compose(v455_5,v456_7);
        }
        const Space v455_9 = intersect(constant_14,v455_2);
        const Space v455_10 = (has_head(v455_9) ? constant_15 : Space{});
        Space v455_12;
        if (!v455_10.empty()) {
          const Path v457_6 = concat_path(v454_6,v454_7_head);
          const Space v457_11 = routine_86(c, v457_6, p1, v454_7_tail, s1);
          v455_12 = compose(v455_10,v457_11);
        }
        const Space v455_13 = unite(v455_8,v455_12);
        v454_7_result = unite(v454_7_result,v455_13);
      }
      const Space v454_7 = std::move(v454_7_result);
      v453_8 = compose(v453_5,v454_7);
    }
    const Space v453_9 = intersect(constant_14,v453_2);
    const Space v453_10 = (has_head(v453_9) ? constant_15 : Space{});
    Space v453_13;
    if (!v453_10.empty()) {
      const Space v458_11 = unwrap(v452_11,v452_18_head);
      Space v458_12_result;
      for (int v458_12_label = 1; v458_12_label <= 2; ++v458_12_label) {
        const Space v458_12_tail = child(v458_11,v458_12_label);
        if (v458_12_tail.empty()) continue;
        const Path v458_12_head{v458_12_label};
        const Space v459_2 = singleton(v458_12_head);
        const Space v459_3 = intersect(constant_14,v459_2);
        const Space v459_4 = (has_head(v459_3) ? constant_15 : Space{});
        const Space v459_5 = subtract(constant_0,v459_4);
        Space v459_7;
        if (!v459_5.empty()) {
          const Space v460_6 = routine_87(c, v458_12_head, p1, v458_12_tail);
          v459_7 = compose(v459_5,v460_6);
        }
        const Space v459_8 = intersect(constant_14,v459_2);
        const Space v459_9 = (has_head(v459_8) ? constant_15 : Space{});
        Space v459_11;
        if (!v459_9.empty()) {
          const Space v461_10 = routine_88(c, v458_12_head, p1, v458_12_tail);
          v459_11 = compose(v459_9,v461_10);
        }
        const Space v459_12 = unite(v459_7,v459_11);
        v458_12_result = unite(v458_12_result,v459_12);
      }
      const Space v458_12 = std::move(v458_12_result);
      v453_13 = compose(v453_10,v458_12);
    }
    const Space v453_14 = unite(v453_8,v453_13);
    v452_18_result = unite(v452_18_result,v453_14);
  }
  const Space v452_18 = std::move(v452_18_result);
  return v452_18;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v462_13_result;
  for (int v462_13_label = 1; v462_13_label <= 2; ++v462_13_label) {
    const Space v462_13_tail = child(s0,v462_13_label);
    if (v462_13_tail.empty()) continue;
    const Path v462_13_head{v462_13_label};
    const Space v463_2 = singleton(v462_13_head);
    const Space v463_3 = intersect(constant_14,v463_2);
    const Space v463_4 = (has_head(v463_3) ? constant_15 : Space{});
    const Space v463_5 = subtract(constant_0,v463_4);
    Space v463_8;
    if (!v463_5.empty()) {
      const Path v464_6 = concat_path(p0,v462_13_head);
      Space v464_7_result;
      for (int v464_7_label = 1; v464_7_label <= 2; ++v464_7_label) {
        const Space v464_7_tail = child(v462_13_tail,v464_7_label);
        if (v464_7_tail.empty()) continue;
        const Path v464_7_head{v464_7_label};
        const Space v465_2 = singleton(v464_7_head);
        const Space v465_3 = intersect(constant_14,v465_2);
        const Space v465_4 = (has_head(v465_3) ? constant_15 : Space{});
        const Space v465_5 = subtract(constant_0,v465_4);
        Space v465_8;
        if (!v465_5.empty()) {
          const Path v466_6 = concat_path(v464_6,v464_7_head);
          const Space v466_7 = routine_89(c, v466_6, p1, v464_7_tail, s1);
          v465_8 = compose(v465_5,v466_7);
        }
        const Space v465_9 = intersect(constant_14,v465_2);
        const Space v465_10 = (has_head(v465_9) ? constant_15 : Space{});
        Space v465_12;
        if (!v465_10.empty()) {
          const Path v467_6 = concat_path(v464_6,v464_7_head);
          const Space v467_11 = routine_90(c, v467_6, p1, v464_7_tail, s1);
          v465_12 = compose(v465_10,v467_11);
        }
        const Space v465_13 = unite(v465_8,v465_12);
        v464_7_result = unite(v464_7_result,v465_13);
      }
      const Space v464_7 = std::move(v464_7_result);
      v463_8 = compose(v463_5,v464_7);
    }
    const Space v463_9 = intersect(constant_14,v463_2);
    const Space v463_10 = (has_head(v463_9) ? constant_15 : Space{});
    Space v463_12;
    if (!v463_10.empty()) {
      const Path v468_6 = concat_path(p0,v462_13_head);
      Space v468_11_result;
      for (int v468_11_label = 1; v468_11_label <= 2; ++v468_11_label) {
        const Space v468_11_tail = child(v462_13_tail,v468_11_label);
        if (v468_11_tail.empty()) continue;
        const Path v468_11_head{v468_11_label};
        const Space v469_2 = singleton(v468_11_head);
        const Space v469_3 = intersect(constant_14,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_15 : Space{});
        const Space v469_5 = subtract(constant_0,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_11_head);
          const Space v470_7 = routine_89(c, v470_6, p1, v468_11_tail, s1);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_14,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_15 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_11_head);
          const Space v471_11 = routine_47(c, v471_6, p1, v468_11_tail, s1);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_11_result = unite(v468_11_result,v469_13);
      }
      const Space v468_11 = std::move(v468_11_result);
      v463_12 = compose(v463_10,v468_11);
    }
    const Space v463_13 = unite(v463_8,v463_12);
    v462_13_result = unite(v462_13_result,v463_13);
  }
  const Space v462_13 = std::move(v462_13_result);
  return v462_13;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v472_8 = unwrap(s1,constant_7);
  const Space v472_10 = unwrap(v472_8,constant_10);
  const Space v472_11 = unwrap(v472_10,p0);
  Space v472_18_result;
  for (int v472_18_label = 1; v472_18_label <= 2; ++v472_18_label) {
    const Space v472_18_tail = child(s0,v472_18_label);
    if (v472_18_tail.empty()) continue;
    const Path v472_18_head{v472_18_label};
    const Space v473_2 = singleton(v472_18_head);
    const Space v473_3 = intersect(constant_14,v473_2);
    const Space v473_4 = (has_head(v473_3) ? constant_15 : Space{});
    const Space v473_5 = subtract(constant_0,v473_4);
    Space v473_8;
    if (!v473_5.empty()) {
      const Path v474_6 = concat_path(p0,v472_18_head);
      Space v474_7_result;
      for (int v474_7_label = 1; v474_7_label <= 2; ++v474_7_label) {
        const Space v474_7_tail = child(v472_18_tail,v474_7_label);
        if (v474_7_tail.empty()) continue;
        const Path v474_7_head{v474_7_label};
        const Space v475_2 = singleton(v474_7_head);
        const Space v475_3 = intersect(constant_14,v475_2);
        const Space v475_4 = (has_head(v475_3) ? constant_15 : Space{});
        const Space v475_5 = subtract(constant_0,v475_4);
        Space v475_8;
        if (!v475_5.empty()) {
          const Path v476_6 = concat_path(v474_6,v474_7_head);
          const Space v476_7 = routine_89(c, v476_6, p1, v474_7_tail, s1);
          v475_8 = compose(v475_5,v476_7);
        }
        const Space v475_9 = intersect(constant_14,v475_2);
        const Space v475_10 = (has_head(v475_9) ? constant_15 : Space{});
        Space v475_12;
        if (!v475_10.empty()) {
          const Path v477_6 = concat_path(v474_6,v474_7_head);
          const Space v477_11 = routine_90(c, v477_6, p1, v474_7_tail, s1);
          v475_12 = compose(v475_10,v477_11);
        }
        const Space v475_13 = unite(v475_8,v475_12);
        v474_7_result = unite(v474_7_result,v475_13);
      }
      const Space v474_7 = std::move(v474_7_result);
      v473_8 = compose(v473_5,v474_7);
    }
    const Space v473_9 = intersect(constant_14,v473_2);
    const Space v473_10 = (has_head(v473_9) ? constant_15 : Space{});
    Space v473_13;
    if (!v473_10.empty()) {
      const Space v478_11 = unwrap(v472_11,v472_18_head);
      Space v478_12_result;
      for (int v478_12_label = 1; v478_12_label <= 2; ++v478_12_label) {
        const Space v478_12_tail = child(v478_11,v478_12_label);
        if (v478_12_tail.empty()) continue;
        const Path v478_12_head{v478_12_label};
        const Space v479_2 = singleton(v478_12_head);
        const Space v479_3 = intersect(constant_14,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_15 : Space{});
        const Space v479_5 = subtract(constant_0,v479_4);
        Space v479_7;
        if (!v479_5.empty()) {
          const Space v480_6 = routine_87(c, v478_12_head, p1, v478_12_tail);
          v479_7 = compose(v479_5,v480_6);
        }
        const Space v479_8 = intersect(constant_14,v479_2);
        const Space v479_9 = (has_head(v479_8) ? constant_15 : Space{});
        Space v479_11;
        if (!v479_9.empty()) {
          const Space v481_10 = routine_88(c, v478_12_head, p1, v478_12_tail);
          v479_11 = compose(v479_9,v481_10);
        }
        const Space v479_12 = unite(v479_7,v479_11);
        v478_12_result = unite(v478_12_result,v479_12);
      }
      const Space v478_12 = std::move(v478_12_result);
      v473_13 = compose(v473_10,v478_12);
    }
    const Space v473_14 = unite(v473_8,v473_13);
    v472_18_result = unite(v472_18_result,v473_14);
  }
  const Space v472_18 = std::move(v472_18_result);
  return v472_18;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v482_5 = unwrap(s1,constant_7);
  const Space v482_7 = unwrap(v482_5,constant_10);
  const Space v482_8 = unwrap(v482_7,p0);
  Space v482_18_result;
  for (int v482_18_label = 1; v482_18_label <= 2; ++v482_18_label) {
    const Space v482_18_tail = child(v482_8,v482_18_label);
    if (v482_18_tail.empty()) continue;
    const Path v482_18_head{v482_18_label};
    const Space v483_2 = singleton(v482_18_head);
    const Space v483_3 = intersect(constant_14,v483_2);
    const Space v483_4 = (has_head(v483_3) ? constant_15 : Space{});
    const Space v483_5 = subtract(constant_0,v483_4);
    Space v483_7;
    if (!v483_5.empty()) {
      Space v484_6_result;
      for (int v484_6_label = 1; v484_6_label <= 2; ++v484_6_label) {
        const Space v484_6_tail = child(v482_18_tail,v484_6_label);
        if (v484_6_tail.empty()) continue;
        const Path v484_6_head{v484_6_label};
        const Space v485_2 = singleton(v484_6_head);
        const Space v485_3 = intersect(constant_14,v485_2);
        const Space v485_4 = (has_head(v485_3) ? constant_15 : Space{});
        const Space v485_5 = subtract(constant_0,v485_4);
        Space v485_8;
        if (!v485_5.empty()) {
          const Path v486_6 = concat_path(v482_18_head,v484_6_head);
          const Space v486_7 = routine_91(c, v486_6, p1, v484_6_tail);
          v485_8 = compose(v485_5,v486_7);
        }
        const Space v485_9 = intersect(constant_14,v485_2);
        const Space v485_10 = (has_head(v485_9) ? constant_15 : Space{});
        Space v485_12;
        if (!v485_10.empty()) {
          const Path v487_6 = concat_path(v482_18_head,v484_6_head);
          const Space v487_11 = routine_92(c, v487_6, p1, v484_6_tail);
          v485_12 = compose(v485_10,v487_11);
        }
        const Space v485_13 = unite(v485_8,v485_12);
        v484_6_result = unite(v484_6_result,v485_13);
      }
      const Space v484_6 = std::move(v484_6_result);
      v483_7 = compose(v483_5,v484_6);
    }
    const Space v483_8 = intersect(constant_14,v483_2);
    const Space v483_9 = (has_head(v483_8) ? constant_15 : Space{});
    Space v483_11;
    if (!v483_9.empty()) {
      Space v488_10_result;
      for (int v488_10_label = 1; v488_10_label <= 2; ++v488_10_label) {
        const Space v488_10_tail = child(v482_18_tail,v488_10_label);
        if (v488_10_tail.empty()) continue;
        const Path v488_10_head{v488_10_label};
        const Space v489_2 = singleton(v488_10_head);
        const Space v489_3 = intersect(constant_14,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_15 : Space{});
        const Space v489_5 = subtract(constant_0,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v482_18_head,v488_10_head);
          const Space v490_7 = routine_91(c, v490_6, p1, v488_10_tail);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_14,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_15 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v482_18_head,v488_10_head);
          const Space v491_11 = routine_93(c, v491_6, p1, v488_10_tail);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_10_result = unite(v488_10_result,v489_13);
      }
      const Space v488_10 = std::move(v488_10_result);
      v483_11 = compose(v483_9,v488_10);
    }
    const Space v483_12 = unite(v483_7,v483_11);
    v482_18_result = unite(v482_18_result,v483_12);
  }
  const Space v482_18 = std::move(v482_18_result);
  return v482_18;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v492_4_result;
  for (int v492_4_label = 1; v492_4_label <= 2; ++v492_4_label) {
    const Space v492_4_tail = child(s0,v492_4_label);
    if (v492_4_tail.empty()) continue;
    const Path v492_4_head{v492_4_label};
    const Space v493_2 = singleton(v492_4_head);
    const Space v493_3 = intersect(constant_14,v493_2);
    const Space v493_4 = (has_head(v493_3) ? constant_15 : Space{});
    Space v493_7;
    if (!v493_4.empty()) {
      const Path v494_5 = concat_path(p0,v492_4_head);
      Space v494_6_result;
      for (int v494_6_label = 1; v494_6_label <= 2; ++v494_6_label) {
        const Space v494_6_tail = child(v492_4_tail,v494_6_label);
        if (v494_6_tail.empty()) continue;
        const Path v494_6_head{v494_6_label};
        const Space v495_2 = singleton(v494_6_head);
        const Space v495_3 = intersect(constant_14,v495_2);
        const Space v495_4 = (has_head(v495_3) ? constant_15 : Space{});
        Space v495_7;
        if (!v495_4.empty()) {
          const Path v496_5 = concat_path(v494_5,v494_6_head);
          const Space v496_6 = routine_17(c, v496_5, v494_6_tail);
          v495_7 = compose(v495_4,v496_6);
        }
        v494_6_result = unite(v494_6_result,v495_7);
      }
      const Space v494_6 = std::move(v494_6_result);
      v493_7 = compose(v493_4,v494_6);
    }
    v492_4_result = unite(v492_4_result,v493_7);
  }
  const Space v492_4 = std::move(v492_4_result);
  return v492_4;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v497_6_result;
  for (int v497_6_label = 1; v497_6_label <= 2; ++v497_6_label) {
    const Space v497_6_tail = child(s0,v497_6_label);
    if (v497_6_tail.empty()) continue;
    const Path v497_6_head{v497_6_label};
    const Space v498_2 = singleton(v497_6_head);
    const Space v498_3 = intersect(constant_14,v498_2);
    const Space v498_4 = (has_head(v498_3) ? constant_15 : Space{});
    Space v498_7;
    if (!v498_4.empty()) {
      const Path v499_5 = concat_path(p0,v497_6_head);
      Space v499_6_result;
      for (int v499_6_label = 1; v499_6_label <= 2; ++v499_6_label) {
        const Space v499_6_tail = child(v497_6_tail,v499_6_label);
        if (v499_6_tail.empty()) continue;
        const Path v499_6_head{v499_6_label};
        const Space v500_2 = singleton(v499_6_head);
        const Space v500_3 = intersect(constant_14,v500_2);
        const Space v500_4 = (has_head(v500_3) ? constant_15 : Space{});
        const Space v500_5 = subtract(constant_0,v500_4);
        Space v500_7;
        if (!v500_5.empty()) {
          const Space v501_6 = routine_18(c, v499_6_head, v499_5, v499_6_tail);
          v500_7 = compose(v500_5,v501_6);
        }
        const Space v500_8 = intersect(constant_14,v500_2);
        const Space v500_9 = (has_head(v500_8) ? constant_15 : Space{});
        Space v500_11;
        if (!v500_9.empty()) {
          const Space v502_10 = routine_19(c, v499_6_head, v499_5, v499_6_tail);
          v500_11 = compose(v500_9,v502_10);
        }
        const Space v500_12 = unite(v500_7,v500_11);
        v499_6_result = unite(v499_6_result,v500_12);
      }
      const Space v499_6 = std::move(v499_6_result);
      v498_7 = compose(v498_4,v499_6);
    }
    v497_6_result = unite(v497_6_result,v498_7);
  }
  const Space v497_6 = std::move(v497_6_result);
  return v497_6;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v503_12_result;
  for (int v503_12_label = 1; v503_12_label <= 2; ++v503_12_label) {
    const Space v503_12_tail = child(s0,v503_12_label);
    if (v503_12_tail.empty()) continue;
    const Path v503_12_head{v503_12_label};
    const Space v504_2 = singleton(v503_12_head);
    const Space v504_3 = intersect(constant_14,v504_2);
    const Space v504_4 = (has_head(v504_3) ? constant_15 : Space{});
    const Space v504_5 = subtract(constant_0,v504_4);
    Space v504_8;
    if (!v504_5.empty()) {
      const Path v505_6 = concat_path(p0,v503_12_head);
      Space v505_7_result;
      for (int v505_7_label = 1; v505_7_label <= 2; ++v505_7_label) {
        const Space v505_7_tail = child(v503_12_tail,v505_7_label);
        if (v505_7_tail.empty()) continue;
        const Path v505_7_head{v505_7_label};
        const Space v506_2 = singleton(v505_7_head);
        const Space v506_3 = intersect(constant_14,v506_2);
        const Space v506_4 = (has_head(v506_3) ? constant_15 : Space{});
        const Space v506_5 = subtract(constant_0,v506_4);
        Space v506_8;
        if (!v506_5.empty()) {
          const Path v507_6 = concat_path(v505_6,v505_7_head);
          const Space v507_7 = routine_94(c, v507_6, p1, v505_7_tail);
          v506_8 = compose(v506_5,v507_7);
        }
        const Space v506_9 = intersect(constant_14,v506_2);
        const Space v506_10 = (has_head(v506_9) ? constant_15 : Space{});
        Space v506_12;
        if (!v506_10.empty()) {
          const Path v508_6 = concat_path(v505_6,v505_7_head);
          const Space v508_11 = routine_95(c, v508_6, p1, v505_7_tail);
          v506_12 = compose(v506_10,v508_11);
        }
        const Space v506_13 = unite(v506_8,v506_12);
        v505_7_result = unite(v505_7_result,v506_13);
      }
      const Space v505_7 = std::move(v505_7_result);
      v504_8 = compose(v504_5,v505_7);
    }
    const Space v504_9 = intersect(constant_14,v504_2);
    const Space v504_10 = (has_head(v504_9) ? constant_15 : Space{});
    Space v504_12;
    if (!v504_10.empty()) {
      const Path v509_6 = concat_path(p0,v503_12_head);
      Space v509_11_result;
      for (int v509_11_label = 1; v509_11_label <= 2; ++v509_11_label) {
        const Space v509_11_tail = child(v503_12_tail,v509_11_label);
        if (v509_11_tail.empty()) continue;
        const Path v509_11_head{v509_11_label};
        const Space v510_2 = singleton(v509_11_head);
        const Space v510_3 = intersect(constant_14,v510_2);
        const Space v510_4 = (has_head(v510_3) ? constant_15 : Space{});
        const Space v510_5 = subtract(constant_0,v510_4);
        Space v510_8;
        if (!v510_5.empty()) {
          const Path v511_6 = concat_path(v509_6,v509_11_head);
          const Space v511_7 = routine_94(c, v511_6, p1, v509_11_tail);
          v510_8 = compose(v510_5,v511_7);
        }
        const Space v510_9 = intersect(constant_14,v510_2);
        const Space v510_10 = (has_head(v510_9) ? constant_15 : Space{});
        Space v510_12;
        if (!v510_10.empty()) {
          const Path v512_6 = concat_path(v509_6,v509_11_head);
          const Space v512_11 = routine_52(c, v512_6, p1, v509_11_tail);
          v510_12 = compose(v510_10,v512_11);
        }
        const Space v510_13 = unite(v510_8,v510_12);
        v509_11_result = unite(v509_11_result,v510_13);
      }
      const Space v509_11 = std::move(v509_11_result);
      v504_12 = compose(v504_10,v509_11);
    }
    const Space v504_13 = unite(v504_8,v504_12);
    v503_12_result = unite(v503_12_result,v504_13);
  }
  const Space v503_12 = std::move(v503_12_result);
  return v503_12;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v513_10_result;
  for (int v513_10_label = 1; v513_10_label <= 2; ++v513_10_label) {
    const Space v513_10_tail = child(s0,v513_10_label);
    if (v513_10_tail.empty()) continue;
    const Path v513_10_head{v513_10_label};
    const Space v514_2 = singleton(v513_10_head);
    const Space v514_3 = intersect(constant_14,v514_2);
    const Space v514_4 = (has_head(v514_3) ? constant_15 : Space{});
    const Space v514_5 = compose(v514_4,v513_10_tail);
    const Path v515_6 = concat_path(p0,v513_10_head);
    const Space v514_7 = wrap(v514_5,v515_6);
    const Space v514_8 = wrap(v514_7,p1);
    const Space v514_9 = wrap(v514_8,constant_10);
    const Space v514_10 = intersect(constant_14,v514_2);
    const Space v514_11 = (has_head(v514_10) ? constant_15 : Space{});
    const Space v514_12 = subtract(constant_0,v514_11);
    Space v514_14;
    if (!v514_12.empty()) {
      Space v516_13_result;
      for (int v516_13_label = 1; v516_13_label <= 2; ++v516_13_label) {
        const Space v516_13_tail = child(v513_10_tail,v516_13_label);
        if (v516_13_tail.empty()) continue;
        const Path v516_13_head{v516_13_label};
        const Space v517_2 = singleton(v516_13_head);
        const Space v517_3 = intersect(constant_14,v517_2);
        const Space v517_4 = (has_head(v517_3) ? constant_15 : Space{});
        const Space v517_5 = subtract(constant_0,v517_4);
        Space v517_8;
        if (!v517_5.empty()) {
          const Path v518_6 = concat_path(v515_6,v516_13_head);
          const Space v518_7 = routine_94(c, v518_6, p1, v516_13_tail);
          v517_8 = compose(v517_5,v518_7);
        }
        const Space v517_9 = intersect(constant_14,v517_2);
        const Space v517_10 = (has_head(v517_9) ? constant_15 : Space{});
        Space v517_12;
        if (!v517_10.empty()) {
          const Path v519_6 = concat_path(v515_6,v516_13_head);
          const Space v519_11 = routine_95(c, v519_6, p1, v516_13_tail);
          v517_12 = compose(v517_10,v519_11);
        }
        const Space v517_13 = unite(v517_8,v517_12);
        v516_13_result = unite(v516_13_result,v517_13);
      }
      const Space v516_13 = std::move(v516_13_result);
      v514_14 = compose(v514_12,v516_13);
    }
    const Space v514_15 = unite(v514_9,v514_14);
    v513_10_result = unite(v513_10_result,v514_15);
  }
  const Space v513_10 = std::move(v513_10_result);
  return v513_10;
}

static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v520_3 = wrap(s0,p0);
  const Space v520_4 = wrap(v520_3,p1);
  const Space v520_6 = wrap(v520_4,constant_10);
  return v520_6;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v521_12_result;
  for (int v521_12_label = 1; v521_12_label <= 2; ++v521_12_label) {
    const Space v521_12_tail = child(s0,v521_12_label);
    if (v521_12_tail.empty()) continue;
    const Path v521_12_head{v521_12_label};
    const Space v522_2 = singleton(v521_12_head);
    const Space v522_3 = intersect(constant_14,v522_2);
    const Space v522_4 = (has_head(v522_3) ? constant_15 : Space{});
    const Space v522_5 = subtract(constant_0,v522_4);
    Space v522_8;
    if (!v522_5.empty()) {
      const Path v523_6 = concat_path(p0,v521_12_head);
      Space v523_7_result;
      for (int v523_7_label = 1; v523_7_label <= 2; ++v523_7_label) {
        const Space v523_7_tail = child(v521_12_tail,v523_7_label);
        if (v523_7_tail.empty()) continue;
        const Path v523_7_head{v523_7_label};
        const Space v524_2 = singleton(v523_7_head);
        const Space v524_3 = intersect(constant_14,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_15 : Space{});
        const Space v524_5 = subtract(constant_0,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v523_6,v523_7_head);
          const Space v525_7 = routine_96(c, v525_6, p1, v523_7_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_14,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_15 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v523_6,v523_7_head);
          const Space v526_11 = routine_97(c, v526_6, p1, v523_7_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_7_result = unite(v523_7_result,v524_13);
      }
      const Space v523_7 = std::move(v523_7_result);
      v522_8 = compose(v522_5,v523_7);
    }
    const Space v522_9 = intersect(constant_14,v522_2);
    const Space v522_10 = (has_head(v522_9) ? constant_15 : Space{});
    Space v522_12;
    if (!v522_10.empty()) {
      const Path v527_6 = concat_path(p0,v521_12_head);
      Space v527_11_result;
      for (int v527_11_label = 1; v527_11_label <= 2; ++v527_11_label) {
        const Space v527_11_tail = child(v521_12_tail,v527_11_label);
        if (v527_11_tail.empty()) continue;
        const Path v527_11_head{v527_11_label};
        const Space v528_2 = singleton(v527_11_head);
        const Space v528_3 = intersect(constant_14,v528_2);
        const Space v528_4 = (has_head(v528_3) ? constant_15 : Space{});
        const Space v528_5 = subtract(constant_0,v528_4);
        Space v528_8;
        if (!v528_5.empty()) {
          const Path v529_6 = concat_path(v527_6,v527_11_head);
          const Space v529_7 = routine_96(c, v529_6, p1, v527_11_tail);
          v528_8 = compose(v528_5,v529_7);
        }
        const Space v528_9 = intersect(constant_14,v528_2);
        const Space v528_10 = (has_head(v528_9) ? constant_15 : Space{});
        Space v528_12;
        if (!v528_10.empty()) {
          const Path v530_6 = concat_path(v527_6,v527_11_head);
          const Space v530_11 = routine_52(c, v530_6, p1, v527_11_tail);
          v528_12 = compose(v528_10,v530_11);
        }
        const Space v528_13 = unite(v528_8,v528_12);
        v527_11_result = unite(v527_11_result,v528_13);
      }
      const Space v527_11 = std::move(v527_11_result);
      v522_12 = compose(v522_10,v527_11);
    }
    const Space v522_13 = unite(v522_8,v522_12);
    v521_12_result = unite(v521_12_result,v522_13);
  }
  const Space v521_12 = std::move(v521_12_result);
  return v521_12;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v531_10_result;
  for (int v531_10_label = 1; v531_10_label <= 2; ++v531_10_label) {
    const Space v531_10_tail = child(s0,v531_10_label);
    if (v531_10_tail.empty()) continue;
    const Path v531_10_head{v531_10_label};
    const Space v532_2 = singleton(v531_10_head);
    const Space v532_3 = intersect(constant_14,v532_2);
    const Space v532_4 = (has_head(v532_3) ? constant_15 : Space{});
    const Space v532_5 = compose(v532_4,v531_10_tail);
    const Path v533_6 = concat_path(p0,v531_10_head);
    const Space v532_7 = wrap(v532_5,v533_6);
    const Space v532_8 = wrap(v532_7,p1);
    const Space v532_9 = wrap(v532_8,constant_10);
    const Space v532_10 = intersect(constant_14,v532_2);
    const Space v532_11 = (has_head(v532_10) ? constant_15 : Space{});
    const Space v532_12 = subtract(constant_0,v532_11);
    Space v532_14;
    if (!v532_12.empty()) {
      Space v534_13_result;
      for (int v534_13_label = 1; v534_13_label <= 2; ++v534_13_label) {
        const Space v534_13_tail = child(v531_10_tail,v534_13_label);
        if (v534_13_tail.empty()) continue;
        const Path v534_13_head{v534_13_label};
        const Space v535_2 = singleton(v534_13_head);
        const Space v535_3 = intersect(constant_14,v535_2);
        const Space v535_4 = (has_head(v535_3) ? constant_15 : Space{});
        const Space v535_5 = subtract(constant_0,v535_4);
        Space v535_8;
        if (!v535_5.empty()) {
          const Path v536_6 = concat_path(v533_6,v534_13_head);
          const Space v536_7 = routine_96(c, v536_6, p1, v534_13_tail);
          v535_8 = compose(v535_5,v536_7);
        }
        const Space v535_9 = intersect(constant_14,v535_2);
        const Space v535_10 = (has_head(v535_9) ? constant_15 : Space{});
        Space v535_12;
        if (!v535_10.empty()) {
          const Path v537_6 = concat_path(v533_6,v534_13_head);
          const Space v537_11 = routine_97(c, v537_6, p1, v534_13_tail);
          v535_12 = compose(v535_10,v537_11);
        }
        const Space v535_13 = unite(v535_8,v535_12);
        v534_13_result = unite(v534_13_result,v535_13);
      }
      const Space v534_13 = std::move(v534_13_result);
      v532_14 = compose(v532_12,v534_13);
    }
    const Space v532_15 = unite(v532_9,v532_14);
    v531_10_result = unite(v531_10_result,v532_15);
  }
  const Space v531_10 = std::move(v531_10_result);
  return v531_10;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v538_5_result;
  for (int v538_5_label = 1; v538_5_label <= 2; ++v538_5_label) {
    const Space v538_5_tail = child(s0,v538_5_label);
    if (v538_5_tail.empty()) continue;
    const Path v538_5_head{v538_5_label};
    const Space v539_2 = singleton(v538_5_head);
    const Space v539_3 = intersect(constant_14,v539_2);
    const Space v539_4 = (has_head(v539_3) ? constant_15 : Space{});
    Space v539_7;
    if (!v539_4.empty()) {
      const Path v540_5 = concat_path(p0,v538_5_head);
      Space v540_6_result;
      for (int v540_6_label = 1; v540_6_label <= 2; ++v540_6_label) {
        const Space v540_6_tail = child(v538_5_tail,v540_6_label);
        if (v540_6_tail.empty()) continue;
        const Path v540_6_head{v540_6_label};
        const Space v541_2 = singleton(v540_6_head);
        const Space v541_3 = intersect(constant_14,v541_2);
        const Space v541_4 = (has_head(v541_3) ? constant_15 : Space{});
        Space v541_7;
        if (!v541_4.empty()) {
          const Path v542_5 = concat_path(v540_5,v540_6_head);
          const Space v542_6 = routine_5(c, v542_5, v540_6_tail, s1);
          v541_7 = compose(v541_4,v542_6);
        }
        v540_6_result = unite(v540_6_result,v541_7);
      }
      const Space v540_6 = std::move(v540_6_result);
      v539_7 = compose(v539_4,v540_6);
    }
    v538_5_result = unite(v538_5_result,v539_7);
  }
  const Space v538_5 = std::move(v538_5_result);
  return v538_5;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v543_7_result;
  for (int v543_7_label = 1; v543_7_label <= 2; ++v543_7_label) {
    const Space v543_7_tail = child(s0,v543_7_label);
    if (v543_7_tail.empty()) continue;
    const Path v543_7_head{v543_7_label};
    const Space v544_2 = singleton(v543_7_head);
    const Space v544_3 = intersect(constant_14,v544_2);
    const Space v544_4 = (has_head(v544_3) ? constant_15 : Space{});
    Space v544_7;
    if (!v544_4.empty()) {
      const Path v545_5 = concat_path(p0,v543_7_head);
      Space v545_6_result;
      for (int v545_6_label = 1; v545_6_label <= 2; ++v545_6_label) {
        const Space v545_6_tail = child(v543_7_tail,v545_6_label);
        if (v545_6_tail.empty()) continue;
        const Path v545_6_head{v545_6_label};
        const Space v546_2 = singleton(v545_6_head);
        const Space v546_3 = intersect(constant_14,v546_2);
        const Space v546_4 = (has_head(v546_3) ? constant_15 : Space{});
        const Space v546_5 = subtract(constant_0,v546_4);
        Space v546_7;
        if (!v546_5.empty()) {
          const Space v547_6 = routine_22(c, v545_6_head, v545_5, v545_6_tail, s1);
          v546_7 = compose(v546_5,v547_6);
        }
        const Space v546_8 = intersect(constant_14,v546_2);
        const Space v546_9 = (has_head(v546_8) ? constant_15 : Space{});
        Space v546_11;
        if (!v546_9.empty()) {
          const Space v548_10 = routine_23(c, v545_6_head, v545_5, v545_6_tail, s1);
          v546_11 = compose(v546_9,v548_10);
        }
        const Space v546_12 = unite(v546_7,v546_11);
        v545_6_result = unite(v545_6_result,v546_12);
      }
      const Space v545_6 = std::move(v545_6_result);
      v544_7 = compose(v544_4,v545_6);
    }
    v543_7_result = unite(v543_7_result,v544_7);
  }
  const Space v543_7 = std::move(v543_7_result);
  return v543_7;
}

static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v549_13_result;
  for (int v549_13_label = 1; v549_13_label <= 2; ++v549_13_label) {
    const Space v549_13_tail = child(s0,v549_13_label);
    if (v549_13_tail.empty()) continue;
    const Path v549_13_head{v549_13_label};
    const Space v550_2 = singleton(v549_13_head);
    const Space v550_3 = intersect(constant_14,v550_2);
    const Space v550_4 = (has_head(v550_3) ? constant_15 : Space{});
    const Space v550_5 = subtract(constant_0,v550_4);
    Space v550_8;
    if (!v550_5.empty()) {
      const Path v551_6 = concat_path(p0,v549_13_head);
      Space v551_7_result;
      for (int v551_7_label = 1; v551_7_label <= 2; ++v551_7_label) {
        const Space v551_7_tail = child(v549_13_tail,v551_7_label);
        if (v551_7_tail.empty()) continue;
        const Path v551_7_head{v551_7_label};
        const Space v552_2 = singleton(v551_7_head);
        const Space v552_3 = intersect(constant_14,v552_2);
        const Space v552_4 = (has_head(v552_3) ? constant_15 : Space{});
        const Space v552_5 = subtract(constant_0,v552_4);
        Space v552_8;
        if (!v552_5.empty()) {
          const Path v553_6 = concat_path(v551_6,v551_7_head);
          const Space v553_7 = routine_98(c, v553_6, p1, v551_7_tail, s1);
          v552_8 = compose(v552_5,v553_7);
        }
        const Space v552_9 = intersect(constant_14,v552_2);
        const Space v552_10 = (has_head(v552_9) ? constant_15 : Space{});
        Space v552_12;
        if (!v552_10.empty()) {
          const Path v554_6 = concat_path(v551_6,v551_7_head);
          const Space v554_11 = routine_99(c, v554_6, p1, v551_7_tail, s1);
          v552_12 = compose(v552_10,v554_11);
        }
        const Space v552_13 = unite(v552_8,v552_12);
        v551_7_result = unite(v551_7_result,v552_13);
      }
      const Space v551_7 = std::move(v551_7_result);
      v550_8 = compose(v550_5,v551_7);
    }
    const Space v550_9 = intersect(constant_14,v550_2);
    const Space v550_10 = (has_head(v550_9) ? constant_15 : Space{});
    Space v550_12;
    if (!v550_10.empty()) {
      const Path v555_6 = concat_path(p0,v549_13_head);
      Space v555_11_result;
      for (int v555_11_label = 1; v555_11_label <= 2; ++v555_11_label) {
        const Space v555_11_tail = child(v549_13_tail,v555_11_label);
        if (v555_11_tail.empty()) continue;
        const Path v555_11_head{v555_11_label};
        const Space v556_2 = singleton(v555_11_head);
        const Space v556_3 = intersect(constant_14,v556_2);
        const Space v556_4 = (has_head(v556_3) ? constant_15 : Space{});
        const Space v556_5 = subtract(constant_0,v556_4);
        Space v556_8;
        if (!v556_5.empty()) {
          const Path v557_6 = concat_path(v555_6,v555_11_head);
          const Space v557_7 = routine_98(c, v557_6, p1, v555_11_tail, s1);
          v556_8 = compose(v556_5,v557_7);
        }
        const Space v556_9 = intersect(constant_14,v556_2);
        const Space v556_10 = (has_head(v556_9) ? constant_15 : Space{});
        Space v556_12;
        if (!v556_10.empty()) {
          const Path v558_6 = concat_path(v555_6,v555_11_head);
          const Space v558_11 = routine_26(c, v558_6, p1, v555_11_tail, s1);
          v556_12 = compose(v556_10,v558_11);
        }
        const Space v556_13 = unite(v556_8,v556_12);
        v555_11_result = unite(v555_11_result,v556_13);
      }
      const Space v555_11 = std::move(v555_11_result);
      v550_12 = compose(v550_10,v555_11);
    }
    const Space v550_13 = unite(v550_8,v550_12);
    v549_13_result = unite(v549_13_result,v550_13);
  }
  const Space v549_13 = std::move(v549_13_result);
  return v549_13;
}

static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v559_8 = unwrap(s1,constant_7);
  const Space v559_10 = unwrap(v559_8,constant_10);
  const Space v559_11 = unwrap(v559_10,p0);
  Space v559_18_result;
  for (int v559_18_label = 1; v559_18_label <= 2; ++v559_18_label) {
    const Space v559_18_tail = child(s0,v559_18_label);
    if (v559_18_tail.empty()) continue;
    const Path v559_18_head{v559_18_label};
    const Space v560_2 = singleton(v559_18_head);
    const Space v560_3 = intersect(constant_14,v560_2);
    const Space v560_4 = (has_head(v560_3) ? constant_15 : Space{});
    const Space v560_5 = subtract(constant_0,v560_4);
    Space v560_8;
    if (!v560_5.empty()) {
      const Path v561_6 = concat_path(p0,v559_18_head);
      Space v561_7_result;
      for (int v561_7_label = 1; v561_7_label <= 2; ++v561_7_label) {
        const Space v561_7_tail = child(v559_18_tail,v561_7_label);
        if (v561_7_tail.empty()) continue;
        const Path v561_7_head{v561_7_label};
        const Space v562_2 = singleton(v561_7_head);
        const Space v562_3 = intersect(constant_14,v562_2);
        const Space v562_4 = (has_head(v562_3) ? constant_15 : Space{});
        const Space v562_5 = subtract(constant_0,v562_4);
        Space v562_8;
        if (!v562_5.empty()) {
          const Path v563_6 = concat_path(v561_6,v561_7_head);
          const Space v563_7 = routine_98(c, v563_6, p1, v561_7_tail, s1);
          v562_8 = compose(v562_5,v563_7);
        }
        const Space v562_9 = intersect(constant_14,v562_2);
        const Space v562_10 = (has_head(v562_9) ? constant_15 : Space{});
        Space v562_12;
        if (!v562_10.empty()) {
          const Path v564_6 = concat_path(v561_6,v561_7_head);
          const Space v564_11 = routine_99(c, v564_6, p1, v561_7_tail, s1);
          v562_12 = compose(v562_10,v564_11);
        }
        const Space v562_13 = unite(v562_8,v562_12);
        v561_7_result = unite(v561_7_result,v562_13);
      }
      const Space v561_7 = std::move(v561_7_result);
      v560_8 = compose(v560_5,v561_7);
    }
    const Space v560_9 = intersect(constant_14,v560_2);
    const Space v560_10 = (has_head(v560_9) ? constant_15 : Space{});
    Space v560_13;
    if (!v560_10.empty()) {
      const Space v565_11 = unwrap(v559_11,v559_18_head);
      Space v565_12_result;
      for (int v565_12_label = 1; v565_12_label <= 2; ++v565_12_label) {
        const Space v565_12_tail = child(v565_11,v565_12_label);
        if (v565_12_tail.empty()) continue;
        const Path v565_12_head{v565_12_label};
        const Space v566_2 = singleton(v565_12_head);
        const Space v566_3 = intersect(constant_14,v566_2);
        const Space v566_4 = (has_head(v566_3) ? constant_15 : Space{});
        const Space v566_5 = subtract(constant_0,v566_4);
        Space v566_7;
        if (!v566_5.empty()) {
          const Space v567_6 = routine_59(c, v565_12_head, p1, v565_12_tail);
          v566_7 = compose(v566_5,v567_6);
        }
        const Space v566_8 = intersect(constant_14,v566_2);
        const Space v566_9 = (has_head(v566_8) ? constant_15 : Space{});
        Space v566_11;
        if (!v566_9.empty()) {
          const Space v568_10 = routine_60(c, v565_12_head, p1, v565_12_tail);
          v566_11 = compose(v566_9,v568_10);
        }
        const Space v566_12 = unite(v566_7,v566_11);
        v565_12_result = unite(v565_12_result,v566_12);
      }
      const Space v565_12 = std::move(v565_12_result);
      v560_13 = compose(v560_10,v565_12);
    }
    const Space v560_14 = unite(v560_8,v560_13);
    v559_18_result = unite(v559_18_result,v560_14);
  }
  const Space v559_18 = std::move(v559_18_result);
  return v559_18;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v569_12_result;
  for (int v569_12_label = 1; v569_12_label <= 2; ++v569_12_label) {
    const Space v569_12_tail = child(s0,v569_12_label);
    if (v569_12_tail.empty()) continue;
    const Path v569_12_head{v569_12_label};
    const Space v570_2 = singleton(v569_12_head);
    const Space v570_3 = intersect(constant_14,v570_2);
    const Space v570_4 = (has_head(v570_3) ? constant_15 : Space{});
    const Space v570_5 = subtract(constant_0,v570_4);
    Space v570_8;
    if (!v570_5.empty()) {
      const Path v571_6 = concat_path(p0,v569_12_head);
      Space v571_7_result;
      for (int v571_7_label = 1; v571_7_label <= 2; ++v571_7_label) {
        const Space v571_7_tail = child(v569_12_tail,v571_7_label);
        if (v571_7_tail.empty()) continue;
        const Path v571_7_head{v571_7_label};
        const Space v572_2 = singleton(v571_7_head);
        const Space v572_3 = intersect(constant_14,v572_2);
        const Space v572_4 = (has_head(v572_3) ? constant_15 : Space{});
        const Space v572_5 = subtract(constant_0,v572_4);
        Space v572_8;
        if (!v572_5.empty()) {
          const Path v573_6 = concat_path(v571_6,v571_7_head);
          const Space v573_7 = routine_100(c, v573_6, p1, v571_7_tail);
          v572_8 = compose(v572_5,v573_7);
        }
        const Space v572_9 = intersect(constant_14,v572_2);
        const Space v572_10 = (has_head(v572_9) ? constant_15 : Space{});
        Space v572_12;
        if (!v572_10.empty()) {
          const Path v574_6 = concat_path(v571_6,v571_7_head);
          const Space v574_11 = routine_101(c, v574_6, p1, v571_7_tail);
          v572_12 = compose(v572_10,v574_11);
        }
        const Space v572_13 = unite(v572_8,v572_12);
        v571_7_result = unite(v571_7_result,v572_13);
      }
      const Space v571_7 = std::move(v571_7_result);
      v570_8 = compose(v570_5,v571_7);
    }
    const Space v570_9 = intersect(constant_14,v570_2);
    const Space v570_10 = (has_head(v570_9) ? constant_15 : Space{});
    Space v570_12;
    if (!v570_10.empty()) {
      const Path v575_6 = concat_path(p0,v569_12_head);
      Space v575_11_result;
      for (int v575_11_label = 1; v575_11_label <= 2; ++v575_11_label) {
        const Space v575_11_tail = child(v569_12_tail,v575_11_label);
        if (v575_11_tail.empty()) continue;
        const Path v575_11_head{v575_11_label};
        const Space v576_2 = singleton(v575_11_head);
        const Space v576_3 = intersect(constant_14,v576_2);
        const Space v576_4 = (has_head(v576_3) ? constant_15 : Space{});
        const Space v576_5 = subtract(constant_0,v576_4);
        Space v576_8;
        if (!v576_5.empty()) {
          const Path v577_6 = concat_path(v575_6,v575_11_head);
          const Space v577_7 = routine_100(c, v577_6, p1, v575_11_tail);
          v576_8 = compose(v576_5,v577_7);
        }
        const Space v576_9 = intersect(constant_14,v576_2);
        const Space v576_10 = (has_head(v576_9) ? constant_15 : Space{});
        Space v576_12;
        if (!v576_10.empty()) {
          const Path v578_6 = concat_path(v575_6,v575_11_head);
          const Space v578_11 = routine_65(c, v578_6, p1, v575_11_tail);
          v576_12 = compose(v576_10,v578_11);
        }
        const Space v576_13 = unite(v576_8,v576_12);
        v575_11_result = unite(v575_11_result,v576_13);
      }
      const Space v575_11 = std::move(v575_11_result);
      v570_12 = compose(v570_10,v575_11);
    }
    const Space v570_13 = unite(v570_8,v570_12);
    v569_12_result = unite(v569_12_result,v570_13);
  }
  const Space v569_12 = std::move(v569_12_result);
  return v569_12;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v579_9_result;
  for (int v579_9_label = 1; v579_9_label <= 2; ++v579_9_label) {
    const Space v579_9_tail = child(s0,v579_9_label);
    if (v579_9_tail.empty()) continue;
    const Path v579_9_head{v579_9_label};
    const Space v580_2 = singleton(v579_9_head);
    const Space v580_3 = intersect(constant_14,v580_2);
    const Space v580_4 = (has_head(v580_3) ? constant_15 : Space{});
    const Space v580_5 = subtract(constant_0,v580_4);
    Space v580_8;
    if (!v580_5.empty()) {
      const Path v581_6 = concat_path(p0,v579_9_head);
      Space v581_7_result;
      for (int v581_7_label = 1; v581_7_label <= 2; ++v581_7_label) {
        const Space v581_7_tail = child(v579_9_tail,v581_7_label);
        if (v581_7_tail.empty()) continue;
        const Path v581_7_head{v581_7_label};
        const Space v582_2 = singleton(v581_7_head);
        const Space v582_3 = intersect(constant_14,v582_2);
        const Space v582_4 = (has_head(v582_3) ? constant_15 : Space{});
        const Space v582_5 = subtract(constant_0,v582_4);
        Space v582_8;
        if (!v582_5.empty()) {
          const Path v583_6 = concat_path(v581_6,v581_7_head);
          const Space v583_7 = routine_100(c, v583_6, p1, v581_7_tail);
          v582_8 = compose(v582_5,v583_7);
        }
        const Space v582_9 = intersect(constant_14,v582_2);
        const Space v582_10 = (has_head(v582_9) ? constant_15 : Space{});
        Space v582_12;
        if (!v582_10.empty()) {
          const Path v584_6 = concat_path(v581_6,v581_7_head);
          const Space v584_11 = routine_101(c, v584_6, p1, v581_7_tail);
          v582_12 = compose(v582_10,v584_11);
        }
        const Space v582_13 = unite(v582_8,v582_12);
        v581_7_result = unite(v581_7_result,v582_13);
      }
      const Space v581_7 = std::move(v581_7_result);
      v580_8 = compose(v580_5,v581_7);
    }
    const Space v580_9 = intersect(constant_14,v580_2);
    const Space v580_10 = (has_head(v580_9) ? constant_15 : Space{});
    const Space v580_11 = compose(v580_10,v579_9_tail);
    const Path v585_6 = concat_path(p0,v579_9_head);
    const Space v580_12 = wrap(v580_11,v585_6);
    const Space v580_13 = wrap(v580_12,p1);
    const Space v580_14 = unite(v580_8,v580_13);
    v579_9_result = unite(v579_9_result,v580_14);
  }
  const Space v579_9 = std::move(v579_9_result);
  return v579_9;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v586_13_result;
  for (int v586_13_label = 1; v586_13_label <= 2; ++v586_13_label) {
    const Space v586_13_tail = child(s0,v586_13_label);
    if (v586_13_tail.empty()) continue;
    const Path v586_13_head{v586_13_label};
    const Space v587_2 = singleton(v586_13_head);
    const Space v587_3 = intersect(constant_14,v587_2);
    const Space v587_4 = (has_head(v587_3) ? constant_15 : Space{});
    const Space v587_5 = subtract(constant_0,v587_4);
    Space v587_8;
    if (!v587_5.empty()) {
      const Path v588_6 = concat_path(p0,v586_13_head);
      Space v588_7_result;
      for (int v588_7_label = 1; v588_7_label <= 2; ++v588_7_label) {
        const Space v588_7_tail = child(v586_13_tail,v588_7_label);
        if (v588_7_tail.empty()) continue;
        const Path v588_7_head{v588_7_label};
        const Space v589_2 = singleton(v588_7_head);
        const Space v589_3 = intersect(constant_14,v589_2);
        const Space v589_4 = (has_head(v589_3) ? constant_15 : Space{});
        const Space v589_5 = subtract(constant_0,v589_4);
        Space v589_8;
        if (!v589_5.empty()) {
          const Path v590_6 = concat_path(v588_6,v588_7_head);
          const Space v590_7 = routine_102(c, v590_6, p1, v588_7_tail, s1);
          v589_8 = compose(v589_5,v590_7);
        }
        const Space v589_9 = intersect(constant_14,v589_2);
        const Space v589_10 = (has_head(v589_9) ? constant_15 : Space{});
        Space v589_12;
        if (!v589_10.empty()) {
          const Path v591_6 = concat_path(v588_6,v588_7_head);
          const Space v591_11 = routine_103(c, v591_6, p1, v588_7_tail, s1);
          v589_12 = compose(v589_10,v591_11);
        }
        const Space v589_13 = unite(v589_8,v589_12);
        v588_7_result = unite(v588_7_result,v589_13);
      }
      const Space v588_7 = std::move(v588_7_result);
      v587_8 = compose(v587_5,v588_7);
    }
    const Space v587_9 = intersect(constant_14,v587_2);
    const Space v587_10 = (has_head(v587_9) ? constant_15 : Space{});
    Space v587_12;
    if (!v587_10.empty()) {
      const Path v592_6 = concat_path(p0,v586_13_head);
      Space v592_11_result;
      for (int v592_11_label = 1; v592_11_label <= 2; ++v592_11_label) {
        const Space v592_11_tail = child(v586_13_tail,v592_11_label);
        if (v592_11_tail.empty()) continue;
        const Path v592_11_head{v592_11_label};
        const Space v593_2 = singleton(v592_11_head);
        const Space v593_3 = intersect(constant_14,v593_2);
        const Space v593_4 = (has_head(v593_3) ? constant_15 : Space{});
        const Space v593_5 = subtract(constant_0,v593_4);
        Space v593_8;
        if (!v593_5.empty()) {
          const Path v594_6 = concat_path(v592_6,v592_11_head);
          const Space v594_7 = routine_102(c, v594_6, p1, v592_11_tail, s1);
          v593_8 = compose(v593_5,v594_7);
        }
        const Space v593_9 = intersect(constant_14,v593_2);
        const Space v593_10 = (has_head(v593_9) ? constant_15 : Space{});
        Space v593_12;
        if (!v593_10.empty()) {
          const Path v595_6 = concat_path(v592_6,v592_11_head);
          const Space v595_11 = routine_26(c, v595_6, p1, v592_11_tail, s1);
          v593_12 = compose(v593_10,v595_11);
        }
        const Space v593_13 = unite(v593_8,v593_12);
        v592_11_result = unite(v592_11_result,v593_13);
      }
      const Space v592_11 = std::move(v592_11_result);
      v587_12 = compose(v587_10,v592_11);
    }
    const Space v587_13 = unite(v587_8,v587_12);
    v586_13_result = unite(v586_13_result,v587_13);
  }
  const Space v586_13 = std::move(v586_13_result);
  return v586_13;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v596_8 = unwrap(s1,constant_7);
  const Space v596_10 = unwrap(v596_8,constant_10);
  const Space v596_11 = unwrap(v596_10,p0);
  Space v596_18_result;
  for (int v596_18_label = 1; v596_18_label <= 2; ++v596_18_label) {
    const Space v596_18_tail = child(s0,v596_18_label);
    if (v596_18_tail.empty()) continue;
    const Path v596_18_head{v596_18_label};
    const Space v597_2 = singleton(v596_18_head);
    const Space v597_3 = intersect(constant_14,v597_2);
    const Space v597_4 = (has_head(v597_3) ? constant_15 : Space{});
    const Space v597_5 = subtract(constant_0,v597_4);
    Space v597_8;
    if (!v597_5.empty()) {
      const Path v598_6 = concat_path(p0,v596_18_head);
      Space v598_7_result;
      for (int v598_7_label = 1; v598_7_label <= 2; ++v598_7_label) {
        const Space v598_7_tail = child(v596_18_tail,v598_7_label);
        if (v598_7_tail.empty()) continue;
        const Path v598_7_head{v598_7_label};
        const Space v599_2 = singleton(v598_7_head);
        const Space v599_3 = intersect(constant_14,v599_2);
        const Space v599_4 = (has_head(v599_3) ? constant_15 : Space{});
        const Space v599_5 = subtract(constant_0,v599_4);
        Space v599_8;
        if (!v599_5.empty()) {
          const Path v600_6 = concat_path(v598_6,v598_7_head);
          const Space v600_7 = routine_102(c, v600_6, p1, v598_7_tail, s1);
          v599_8 = compose(v599_5,v600_7);
        }
        const Space v599_9 = intersect(constant_14,v599_2);
        const Space v599_10 = (has_head(v599_9) ? constant_15 : Space{});
        Space v599_12;
        if (!v599_10.empty()) {
          const Path v601_6 = concat_path(v598_6,v598_7_head);
          const Space v601_11 = routine_103(c, v601_6, p1, v598_7_tail, s1);
          v599_12 = compose(v599_10,v601_11);
        }
        const Space v599_13 = unite(v599_8,v599_12);
        v598_7_result = unite(v598_7_result,v599_13);
      }
      const Space v598_7 = std::move(v598_7_result);
      v597_8 = compose(v597_5,v598_7);
    }
    const Space v597_9 = intersect(constant_14,v597_2);
    const Space v597_10 = (has_head(v597_9) ? constant_15 : Space{});
    Space v597_13;
    if (!v597_10.empty()) {
      const Space v602_11 = unwrap(v596_11,v596_18_head);
      Space v602_12_result;
      for (int v602_12_label = 1; v602_12_label <= 2; ++v602_12_label) {
        const Space v602_12_tail = child(v602_11,v602_12_label);
        if (v602_12_tail.empty()) continue;
        const Path v602_12_head{v602_12_label};
        const Space v603_2 = singleton(v602_12_head);
        const Space v603_3 = intersect(constant_14,v603_2);
        const Space v603_4 = (has_head(v603_3) ? constant_15 : Space{});
        const Space v603_5 = subtract(constant_0,v603_4);
        Space v603_7;
        if (!v603_5.empty()) {
          const Space v604_6 = routine_59(c, v602_12_head, p1, v602_12_tail);
          v603_7 = compose(v603_5,v604_6);
        }
        const Space v603_8 = intersect(constant_14,v603_2);
        const Space v603_9 = (has_head(v603_8) ? constant_15 : Space{});
        Space v603_11;
        if (!v603_9.empty()) {
          const Space v605_10 = routine_60(c, v602_12_head, p1, v602_12_tail);
          v603_11 = compose(v603_9,v605_10);
        }
        const Space v603_12 = unite(v603_7,v603_11);
        v602_12_result = unite(v602_12_result,v603_12);
      }
      const Space v602_12 = std::move(v602_12_result);
      v597_13 = compose(v597_10,v602_12);
    }
    const Space v597_14 = unite(v597_8,v597_13);
    v596_18_result = unite(v596_18_result,v597_14);
  }
  const Space v596_18 = std::move(v596_18_result);
  return v596_18;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v606_12_result;
  for (int v606_12_label = 1; v606_12_label <= 2; ++v606_12_label) {
    const Space v606_12_tail = child(s0,v606_12_label);
    if (v606_12_tail.empty()) continue;
    const Path v606_12_head{v606_12_label};
    const Space v607_2 = singleton(v606_12_head);
    const Space v607_3 = intersect(constant_14,v607_2);
    const Space v607_4 = (has_head(v607_3) ? constant_15 : Space{});
    const Space v607_5 = subtract(constant_0,v607_4);
    Space v607_8;
    if (!v607_5.empty()) {
      const Path v608_6 = concat_path(p0,v606_12_head);
      Space v608_7_result;
      for (int v608_7_label = 1; v608_7_label <= 2; ++v608_7_label) {
        const Space v608_7_tail = child(v606_12_tail,v608_7_label);
        if (v608_7_tail.empty()) continue;
        const Path v608_7_head{v608_7_label};
        const Space v609_2 = singleton(v608_7_head);
        const Space v609_3 = intersect(constant_14,v609_2);
        const Space v609_4 = (has_head(v609_3) ? constant_15 : Space{});
        const Space v609_5 = subtract(constant_0,v609_4);
        Space v609_8;
        if (!v609_5.empty()) {
          const Path v610_6 = concat_path(v608_6,v608_7_head);
          const Space v610_7 = routine_104(c, v610_6, p1, v608_7_tail);
          v609_8 = compose(v609_5,v610_7);
        }
        const Space v609_9 = intersect(constant_14,v609_2);
        const Space v609_10 = (has_head(v609_9) ? constant_15 : Space{});
        Space v609_12;
        if (!v609_10.empty()) {
          const Path v611_6 = concat_path(v608_6,v608_7_head);
          const Space v611_11 = routine_105(c, v611_6, p1, v608_7_tail);
          v609_12 = compose(v609_10,v611_11);
        }
        const Space v609_13 = unite(v609_8,v609_12);
        v608_7_result = unite(v608_7_result,v609_13);
      }
      const Space v608_7 = std::move(v608_7_result);
      v607_8 = compose(v607_5,v608_7);
    }
    const Space v607_9 = intersect(constant_14,v607_2);
    const Space v607_10 = (has_head(v607_9) ? constant_15 : Space{});
    Space v607_12;
    if (!v607_10.empty()) {
      const Path v612_6 = concat_path(p0,v606_12_head);
      Space v612_11_result;
      for (int v612_11_label = 1; v612_11_label <= 2; ++v612_11_label) {
        const Space v612_11_tail = child(v606_12_tail,v612_11_label);
        if (v612_11_tail.empty()) continue;
        const Path v612_11_head{v612_11_label};
        const Space v613_2 = singleton(v612_11_head);
        const Space v613_3 = intersect(constant_14,v613_2);
        const Space v613_4 = (has_head(v613_3) ? constant_15 : Space{});
        const Space v613_5 = subtract(constant_0,v613_4);
        Space v613_8;
        if (!v613_5.empty()) {
          const Path v614_6 = concat_path(v612_6,v612_11_head);
          const Space v614_7 = routine_104(c, v614_6, p1, v612_11_tail);
          v613_8 = compose(v613_5,v614_7);
        }
        const Space v613_9 = intersect(constant_14,v613_2);
        const Space v613_10 = (has_head(v613_9) ? constant_15 : Space{});
        Space v613_12;
        if (!v613_10.empty()) {
          const Path v615_6 = concat_path(v612_6,v612_11_head);
          const Space v615_11 = routine_65(c, v615_6, p1, v612_11_tail);
          v613_12 = compose(v613_10,v615_11);
        }
        const Space v613_13 = unite(v613_8,v613_12);
        v612_11_result = unite(v612_11_result,v613_13);
      }
      const Space v612_11 = std::move(v612_11_result);
      v607_12 = compose(v607_10,v612_11);
    }
    const Space v607_13 = unite(v607_8,v607_12);
    v606_12_result = unite(v606_12_result,v607_13);
  }
  const Space v606_12 = std::move(v606_12_result);
  return v606_12;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v616_9_result;
  for (int v616_9_label = 1; v616_9_label <= 2; ++v616_9_label) {
    const Space v616_9_tail = child(s0,v616_9_label);
    if (v616_9_tail.empty()) continue;
    const Path v616_9_head{v616_9_label};
    const Space v617_2 = singleton(v616_9_head);
    const Space v617_3 = intersect(constant_14,v617_2);
    const Space v617_4 = (has_head(v617_3) ? constant_15 : Space{});
    const Space v617_5 = subtract(constant_0,v617_4);
    Space v617_8;
    if (!v617_5.empty()) {
      const Path v618_6 = concat_path(p0,v616_9_head);
      Space v618_7_result;
      for (int v618_7_label = 1; v618_7_label <= 2; ++v618_7_label) {
        const Space v618_7_tail = child(v616_9_tail,v618_7_label);
        if (v618_7_tail.empty()) continue;
        const Path v618_7_head{v618_7_label};
        const Space v619_2 = singleton(v618_7_head);
        const Space v619_3 = intersect(constant_14,v619_2);
        const Space v619_4 = (has_head(v619_3) ? constant_15 : Space{});
        const Space v619_5 = subtract(constant_0,v619_4);
        Space v619_8;
        if (!v619_5.empty()) {
          const Path v620_6 = concat_path(v618_6,v618_7_head);
          const Space v620_7 = routine_104(c, v620_6, p1, v618_7_tail);
          v619_8 = compose(v619_5,v620_7);
        }
        const Space v619_9 = intersect(constant_14,v619_2);
        const Space v619_10 = (has_head(v619_9) ? constant_15 : Space{});
        Space v619_12;
        if (!v619_10.empty()) {
          const Path v621_6 = concat_path(v618_6,v618_7_head);
          const Space v621_11 = routine_105(c, v621_6, p1, v618_7_tail);
          v619_12 = compose(v619_10,v621_11);
        }
        const Space v619_13 = unite(v619_8,v619_12);
        v618_7_result = unite(v618_7_result,v619_13);
      }
      const Space v618_7 = std::move(v618_7_result);
      v617_8 = compose(v617_5,v618_7);
    }
    const Space v617_9 = intersect(constant_14,v617_2);
    const Space v617_10 = (has_head(v617_9) ? constant_15 : Space{});
    const Space v617_11 = compose(v617_10,v616_9_tail);
    const Path v622_6 = concat_path(p0,v616_9_head);
    const Space v617_12 = wrap(v617_11,v622_6);
    const Space v617_13 = wrap(v617_12,p1);
    const Space v617_14 = unite(v617_8,v617_13);
    v616_9_result = unite(v616_9_result,v617_14);
  }
  const Space v616_9 = std::move(v616_9_result);
  return v616_9;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v623_3 = wrap(s0,p0);
  const Space v623_4 = wrap(v623_3,p1);
  return v623_4;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0) {
  Space v624_4_result;
  for (int v624_4_label = 1; v624_4_label <= 2; ++v624_4_label) {
    const Space v624_4_tail = child(s0,v624_4_label);
    if (v624_4_tail.empty()) continue;
    const Path v624_4_head{v624_4_label};
    const Space v625_2 = singleton(v624_4_head);
    const Space v625_3 = intersect(constant_14,v625_2);
    const Space v625_4 = (has_head(v625_3) ? constant_15 : Space{});
    Space v625_7;
    if (!v625_4.empty()) {
      const Path v626_5 = concat_path(p0,v624_4_head);
      Space v626_6_result;
      for (int v626_6_label = 1; v626_6_label <= 2; ++v626_6_label) {
        const Space v626_6_tail = child(v624_4_tail,v626_6_label);
        if (v626_6_tail.empty()) continue;
        const Path v626_6_head{v626_6_label};
        const Space v627_2 = singleton(v626_6_head);
        const Space v627_3 = intersect(constant_14,v627_2);
        const Space v627_4 = (has_head(v627_3) ? constant_15 : Space{});
        Space v627_7;
        if (!v627_4.empty()) {
          const Path v628_5 = concat_path(v626_5,v626_6_head);
          const Space v628_6 = routine_8(c, v628_5, v626_6_tail);
          v627_7 = compose(v627_4,v628_6);
        }
        v626_6_result = unite(v626_6_result,v627_7);
      }
      const Space v626_6 = std::move(v626_6_result);
      v625_7 = compose(v625_4,v626_6);
    }
    v624_4_result = unite(v624_4_result,v625_7);
  }
  const Space v624_4 = std::move(v624_4_result);
  return v624_4;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v629_6_result;
  for (int v629_6_label = 1; v629_6_label <= 2; ++v629_6_label) {
    const Space v629_6_tail = child(s0,v629_6_label);
    if (v629_6_tail.empty()) continue;
    const Path v629_6_head{v629_6_label};
    const Space v630_2 = singleton(v629_6_head);
    const Space v630_3 = intersect(constant_14,v630_2);
    const Space v630_4 = (has_head(v630_3) ? constant_15 : Space{});
    Space v630_7;
    if (!v630_4.empty()) {
      const Path v631_5 = concat_path(p0,v629_6_head);
      Space v631_6_result;
      for (int v631_6_label = 1; v631_6_label <= 2; ++v631_6_label) {
        const Space v631_6_tail = child(v629_6_tail,v631_6_label);
        if (v631_6_tail.empty()) continue;
        const Path v631_6_head{v631_6_label};
        const Space v632_2 = singleton(v631_6_head);
        const Space v632_3 = intersect(constant_14,v632_2);
        const Space v632_4 = (has_head(v632_3) ? constant_15 : Space{});
        const Space v632_5 = subtract(constant_0,v632_4);
        Space v632_7;
        if (!v632_5.empty()) {
          const Space v633_6 = routine_29(c, v631_6_head, v631_5, v631_6_tail);
          v632_7 = compose(v632_5,v633_6);
        }
        const Space v632_8 = intersect(constant_14,v632_2);
        const Space v632_9 = (has_head(v632_8) ? constant_15 : Space{});
        Space v632_11;
        if (!v632_9.empty()) {
          const Space v634_10 = routine_30(c, v631_6_head, v631_5, v631_6_tail);
          v632_11 = compose(v632_9,v634_10);
        }
        const Space v632_12 = unite(v632_7,v632_11);
        v631_6_result = unite(v631_6_result,v632_12);
      }
      const Space v631_6 = std::move(v631_6_result);
      v630_7 = compose(v630_4,v631_6);
    }
    v629_6_result = unite(v629_6_result,v630_7);
  }
  const Space v629_6 = std::move(v629_6_result);
  return v629_6;
}

static Space routine_68(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v635_12_result;
  for (int v635_12_label = 1; v635_12_label <= 2; ++v635_12_label) {
    const Space v635_12_tail = child(s0,v635_12_label);
    if (v635_12_tail.empty()) continue;
    const Path v635_12_head{v635_12_label};
    const Space v636_2 = singleton(v635_12_head);
    const Space v636_3 = intersect(constant_14,v636_2);
    const Space v636_4 = (has_head(v636_3) ? constant_15 : Space{});
    const Space v636_5 = subtract(constant_0,v636_4);
    Space v636_8;
    if (!v636_5.empty()) {
      const Path v637_6 = concat_path(p0,v635_12_head);
      Space v637_7_result;
      for (int v637_7_label = 1; v637_7_label <= 2; ++v637_7_label) {
        const Space v637_7_tail = child(v635_12_tail,v637_7_label);
        if (v637_7_tail.empty()) continue;
        const Path v637_7_head{v637_7_label};
        const Space v638_2 = singleton(v637_7_head);
        const Space v638_3 = intersect(constant_14,v638_2);
        const Space v638_4 = (has_head(v638_3) ? constant_15 : Space{});
        const Space v638_5 = subtract(constant_0,v638_4);
        Space v638_8;
        if (!v638_5.empty()) {
          const Path v639_6 = concat_path(v637_6,v637_7_head);
          const Space v639_7 = routine_106(c, v639_6, p1, v637_7_tail);
          v638_8 = compose(v638_5,v639_7);
        }
        const Space v638_9 = intersect(constant_14,v638_2);
        const Space v638_10 = (has_head(v638_9) ? constant_15 : Space{});
        Space v638_12;
        if (!v638_10.empty()) {
          const Path v640_6 = concat_path(v637_6,v637_7_head);
          const Space v640_11 = routine_107(c, v640_6, p1, v637_7_tail);
          v638_12 = compose(v638_10,v640_11);
        }
        const Space v638_13 = unite(v638_8,v638_12);
        v637_7_result = unite(v637_7_result,v638_13);
      }
      const Space v637_7 = std::move(v637_7_result);
      v636_8 = compose(v636_5,v637_7);
    }
    const Space v636_9 = intersect(constant_14,v636_2);
    const Space v636_10 = (has_head(v636_9) ? constant_15 : Space{});
    Space v636_12;
    if (!v636_10.empty()) {
      const Path v641_6 = concat_path(p0,v635_12_head);
      Space v641_11_result;
      for (int v641_11_label = 1; v641_11_label <= 2; ++v641_11_label) {
        const Space v641_11_tail = child(v635_12_tail,v641_11_label);
        if (v641_11_tail.empty()) continue;
        const Path v641_11_head{v641_11_label};
        const Space v642_2 = singleton(v641_11_head);
        const Space v642_3 = intersect(constant_14,v642_2);
        const Space v642_4 = (has_head(v642_3) ? constant_15 : Space{});
        const Space v642_5 = subtract(constant_0,v642_4);
        Space v642_8;
        if (!v642_5.empty()) {
          const Path v643_6 = concat_path(v641_6,v641_11_head);
          const Space v643_7 = routine_106(c, v643_6, p1, v641_11_tail);
          v642_8 = compose(v642_5,v643_7);
        }
        const Space v642_9 = intersect(constant_14,v642_2);
        const Space v642_10 = (has_head(v642_9) ? constant_15 : Space{});
        Space v642_12;
        if (!v642_10.empty()) {
          const Path v644_6 = concat_path(v641_6,v641_11_head);
          const Space v644_11 = routine_33(c, v644_6, p1, v641_11_tail);
          v642_12 = compose(v642_10,v644_11);
        }
        const Space v642_13 = unite(v642_8,v642_12);
        v641_11_result = unite(v641_11_result,v642_13);
      }
      const Space v641_11 = std::move(v641_11_result);
      v636_12 = compose(v636_10,v641_11);
    }
    const Space v636_13 = unite(v636_8,v636_12);
    v635_12_result = unite(v635_12_result,v636_13);
  }
  const Space v635_12 = std::move(v635_12_result);
  return v635_12;
}

static Space routine_69(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v645_9_result;
  for (int v645_9_label = 1; v645_9_label <= 2; ++v645_9_label) {
    const Space v645_9_tail = child(s0,v645_9_label);
    if (v645_9_tail.empty()) continue;
    const Path v645_9_head{v645_9_label};
    const Space v646_2 = singleton(v645_9_head);
    const Space v646_3 = intersect(constant_14,v646_2);
    const Space v646_4 = (has_head(v646_3) ? constant_15 : Space{});
    const Space v646_5 = subtract(constant_0,v646_4);
    Space v646_8;
    if (!v646_5.empty()) {
      const Path v647_6 = concat_path(p0,v645_9_head);
      Space v647_7_result;
      for (int v647_7_label = 1; v647_7_label <= 2; ++v647_7_label) {
        const Space v647_7_tail = child(v645_9_tail,v647_7_label);
        if (v647_7_tail.empty()) continue;
        const Path v647_7_head{v647_7_label};
        const Space v648_2 = singleton(v647_7_head);
        const Space v648_3 = intersect(constant_14,v648_2);
        const Space v648_4 = (has_head(v648_3) ? constant_15 : Space{});
        const Space v648_5 = subtract(constant_0,v648_4);
        Space v648_8;
        if (!v648_5.empty()) {
          const Path v649_6 = concat_path(v647_6,v647_7_head);
          const Space v649_7 = routine_106(c, v649_6, p1, v647_7_tail);
          v648_8 = compose(v648_5,v649_7);
        }
        const Space v648_9 = intersect(constant_14,v648_2);
        const Space v648_10 = (has_head(v648_9) ? constant_15 : Space{});
        Space v648_12;
        if (!v648_10.empty()) {
          const Path v650_6 = concat_path(v647_6,v647_7_head);
          const Space v650_11 = routine_107(c, v650_6, p1, v647_7_tail);
          v648_12 = compose(v648_10,v650_11);
        }
        const Space v648_13 = unite(v648_8,v648_12);
        v647_7_result = unite(v647_7_result,v648_13);
      }
      const Space v647_7 = std::move(v647_7_result);
      v646_8 = compose(v646_5,v647_7);
    }
    const Space v646_9 = intersect(constant_14,v646_2);
    const Space v646_10 = (has_head(v646_9) ? constant_15 : Space{});
    const Space v646_11 = compose(v646_10,v645_9_tail);
    const Path v651_6 = concat_path(p0,v645_9_head);
    const Space v646_12 = wrap(v646_11,v651_6);
    const Space v646_13 = wrap(v646_12,p1);
    const Space v646_14 = unite(v646_8,v646_13);
    v645_9_result = unite(v645_9_result,v646_14);
  }
  const Space v645_9 = std::move(v645_9_result);
  return v645_9;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v652_12_result;
  for (int v652_12_label = 1; v652_12_label <= 2; ++v652_12_label) {
    const Space v652_12_tail = child(s0,v652_12_label);
    if (v652_12_tail.empty()) continue;
    const Path v652_12_head{v652_12_label};
    const Space v653_2 = singleton(v652_12_head);
    const Space v653_3 = intersect(constant_14,v653_2);
    const Space v653_4 = (has_head(v653_3) ? constant_15 : Space{});
    const Space v653_5 = subtract(constant_0,v653_4);
    Space v653_8;
    if (!v653_5.empty()) {
      const Path v654_6 = concat_path(p0,v652_12_head);
      Space v654_7_result;
      for (int v654_7_label = 1; v654_7_label <= 2; ++v654_7_label) {
        const Space v654_7_tail = child(v652_12_tail,v654_7_label);
        if (v654_7_tail.empty()) continue;
        const Path v654_7_head{v654_7_label};
        const Space v655_2 = singleton(v654_7_head);
        const Space v655_3 = intersect(constant_14,v655_2);
        const Space v655_4 = (has_head(v655_3) ? constant_15 : Space{});
        const Space v655_5 = subtract(constant_0,v655_4);
        Space v655_8;
        if (!v655_5.empty()) {
          const Path v656_6 = concat_path(v654_6,v654_7_head);
          const Space v656_7 = routine_108(c, v656_6, p1, v654_7_tail);
          v655_8 = compose(v655_5,v656_7);
        }
        const Space v655_9 = intersect(constant_14,v655_2);
        const Space v655_10 = (has_head(v655_9) ? constant_15 : Space{});
        Space v655_12;
        if (!v655_10.empty()) {
          const Path v657_6 = concat_path(v654_6,v654_7_head);
          const Space v657_11 = routine_109(c, v657_6, p1, v654_7_tail);
          v655_12 = compose(v655_10,v657_11);
        }
        const Space v655_13 = unite(v655_8,v655_12);
        v654_7_result = unite(v654_7_result,v655_13);
      }
      const Space v654_7 = std::move(v654_7_result);
      v653_8 = compose(v653_5,v654_7);
    }
    const Space v653_9 = intersect(constant_14,v653_2);
    const Space v653_10 = (has_head(v653_9) ? constant_15 : Space{});
    Space v653_12;
    if (!v653_10.empty()) {
      const Path v658_6 = concat_path(p0,v652_12_head);
      Space v658_11_result;
      for (int v658_11_label = 1; v658_11_label <= 2; ++v658_11_label) {
        const Space v658_11_tail = child(v652_12_tail,v658_11_label);
        if (v658_11_tail.empty()) continue;
        const Path v658_11_head{v658_11_label};
        const Space v659_2 = singleton(v658_11_head);
        const Space v659_3 = intersect(constant_14,v659_2);
        const Space v659_4 = (has_head(v659_3) ? constant_15 : Space{});
        const Space v659_5 = subtract(constant_0,v659_4);
        Space v659_8;
        if (!v659_5.empty()) {
          const Path v660_6 = concat_path(v658_6,v658_11_head);
          const Space v660_7 = routine_108(c, v660_6, p1, v658_11_tail);
          v659_8 = compose(v659_5,v660_7);
        }
        const Space v659_9 = intersect(constant_14,v659_2);
        const Space v659_10 = (has_head(v659_9) ? constant_15 : Space{});
        Space v659_12;
        if (!v659_10.empty()) {
          const Path v661_6 = concat_path(v658_6,v658_11_head);
          const Space v661_11 = routine_33(c, v661_6, p1, v658_11_tail);
          v659_12 = compose(v659_10,v661_11);
        }
        const Space v659_13 = unite(v659_8,v659_12);
        v658_11_result = unite(v658_11_result,v659_13);
      }
      const Space v658_11 = std::move(v658_11_result);
      v653_12 = compose(v653_10,v658_11);
    }
    const Space v653_13 = unite(v653_8,v653_12);
    v652_12_result = unite(v652_12_result,v653_13);
  }
  const Space v652_12 = std::move(v652_12_result);
  return v652_12;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v662_9_result;
  for (int v662_9_label = 1; v662_9_label <= 2; ++v662_9_label) {
    const Space v662_9_tail = child(s0,v662_9_label);
    if (v662_9_tail.empty()) continue;
    const Path v662_9_head{v662_9_label};
    const Space v663_2 = singleton(v662_9_head);
    const Space v663_3 = intersect(constant_14,v663_2);
    const Space v663_4 = (has_head(v663_3) ? constant_15 : Space{});
    const Space v663_5 = subtract(constant_0,v663_4);
    Space v663_8;
    if (!v663_5.empty()) {
      const Path v664_6 = concat_path(p0,v662_9_head);
      Space v664_7_result;
      for (int v664_7_label = 1; v664_7_label <= 2; ++v664_7_label) {
        const Space v664_7_tail = child(v662_9_tail,v664_7_label);
        if (v664_7_tail.empty()) continue;
        const Path v664_7_head{v664_7_label};
        const Space v665_2 = singleton(v664_7_head);
        const Space v665_3 = intersect(constant_14,v665_2);
        const Space v665_4 = (has_head(v665_3) ? constant_15 : Space{});
        const Space v665_5 = subtract(constant_0,v665_4);
        Space v665_8;
        if (!v665_5.empty()) {
          const Path v666_6 = concat_path(v664_6,v664_7_head);
          const Space v666_7 = routine_108(c, v666_6, p1, v664_7_tail);
          v665_8 = compose(v665_5,v666_7);
        }
        const Space v665_9 = intersect(constant_14,v665_2);
        const Space v665_10 = (has_head(v665_9) ? constant_15 : Space{});
        Space v665_12;
        if (!v665_10.empty()) {
          const Path v667_6 = concat_path(v664_6,v664_7_head);
          const Space v667_11 = routine_109(c, v667_6, p1, v664_7_tail);
          v665_12 = compose(v665_10,v667_11);
        }
        const Space v665_13 = unite(v665_8,v665_12);
        v664_7_result = unite(v664_7_result,v665_13);
      }
      const Space v664_7 = std::move(v664_7_result);
      v663_8 = compose(v663_5,v664_7);
    }
    const Space v663_9 = intersect(constant_14,v663_2);
    const Space v663_10 = (has_head(v663_9) ? constant_15 : Space{});
    const Space v663_11 = compose(v663_10,v662_9_tail);
    const Path v668_6 = concat_path(p0,v662_9_head);
    const Space v663_12 = wrap(v663_11,v668_6);
    const Space v663_13 = wrap(v663_12,p1);
    const Space v663_14 = unite(v663_8,v663_13);
    v662_9_result = unite(v662_9_result,v663_14);
  }
  const Space v662_9 = std::move(v662_9_result);
  return v662_9;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v669_5_result;
  for (int v669_5_label = 1; v669_5_label <= 2; ++v669_5_label) {
    const Space v669_5_tail = child(s0,v669_5_label);
    if (v669_5_tail.empty()) continue;
    const Path v669_5_head{v669_5_label};
    const Space v670_2 = singleton(v669_5_head);
    const Space v670_3 = intersect(constant_14,v670_2);
    const Space v670_4 = (has_head(v670_3) ? constant_15 : Space{});
    Space v670_7;
    if (!v670_4.empty()) {
      const Path v671_5 = concat_path(p0,v669_5_head);
      Space v671_6_result;
      for (int v671_6_label = 1; v671_6_label <= 2; ++v671_6_label) {
        const Space v671_6_tail = child(v669_5_tail,v671_6_label);
        if (v671_6_tail.empty()) continue;
        const Path v671_6_head{v671_6_label};
        const Space v672_2 = singleton(v671_6_head);
        const Space v672_3 = intersect(constant_14,v672_2);
        const Space v672_4 = (has_head(v672_3) ? constant_15 : Space{});
        Space v672_7;
        if (!v672_4.empty()) {
          const Path v673_5 = concat_path(v671_5,v671_6_head);
          const Space v673_6 = routine_11(c, v673_5, v671_6_tail, s1);
          v672_7 = compose(v672_4,v673_6);
        }
        v671_6_result = unite(v671_6_result,v672_7);
      }
      const Space v671_6 = std::move(v671_6_result);
      v670_7 = compose(v670_4,v671_6);
    }
    v669_5_result = unite(v669_5_result,v670_7);
  }
  const Space v669_5 = std::move(v669_5_result);
  return v669_5;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v674_7_result;
  for (int v674_7_label = 1; v674_7_label <= 2; ++v674_7_label) {
    const Space v674_7_tail = child(s0,v674_7_label);
    if (v674_7_tail.empty()) continue;
    const Path v674_7_head{v674_7_label};
    const Space v675_2 = singleton(v674_7_head);
    const Space v675_3 = intersect(constant_14,v675_2);
    const Space v675_4 = (has_head(v675_3) ? constant_15 : Space{});
    Space v675_7;
    if (!v675_4.empty()) {
      const Path v676_5 = concat_path(p0,v674_7_head);
      Space v676_6_result;
      for (int v676_6_label = 1; v676_6_label <= 2; ++v676_6_label) {
        const Space v676_6_tail = child(v674_7_tail,v676_6_label);
        if (v676_6_tail.empty()) continue;
        const Path v676_6_head{v676_6_label};
        const Space v677_2 = singleton(v676_6_head);
        const Space v677_3 = intersect(constant_14,v677_2);
        const Space v677_4 = (has_head(v677_3) ? constant_15 : Space{});
        const Space v677_5 = subtract(constant_0,v677_4);
        Space v677_7;
        if (!v677_5.empty()) {
          const Space v678_6 = routine_36(c, v676_6_head, v676_5, v676_6_tail, s1);
          v677_7 = compose(v677_5,v678_6);
        }
        const Space v677_8 = intersect(constant_14,v677_2);
        const Space v677_9 = (has_head(v677_8) ? constant_15 : Space{});
        Space v677_11;
        if (!v677_9.empty()) {
          const Space v679_10 = routine_37(c, v676_6_head, v676_5, v676_6_tail, s1);
          v677_11 = compose(v677_9,v679_10);
        }
        const Space v677_12 = unite(v677_7,v677_11);
        v676_6_result = unite(v676_6_result,v677_12);
      }
      const Space v676_6 = std::move(v676_6_result);
      v675_7 = compose(v675_4,v676_6);
    }
    v674_7_result = unite(v674_7_result,v675_7);
  }
  const Space v674_7 = std::move(v674_7_result);
  return v674_7;
}

static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v680_13_result;
  for (int v680_13_label = 1; v680_13_label <= 2; ++v680_13_label) {
    const Space v680_13_tail = child(s0,v680_13_label);
    if (v680_13_tail.empty()) continue;
    const Path v680_13_head{v680_13_label};
    const Space v681_2 = singleton(v680_13_head);
    const Space v681_3 = intersect(constant_14,v681_2);
    const Space v681_4 = (has_head(v681_3) ? constant_15 : Space{});
    const Space v681_5 = subtract(constant_0,v681_4);
    Space v681_8;
    if (!v681_5.empty()) {
      const Path v682_6 = concat_path(p0,v680_13_head);
      Space v682_7_result;
      for (int v682_7_label = 1; v682_7_label <= 2; ++v682_7_label) {
        const Space v682_7_tail = child(v680_13_tail,v682_7_label);
        if (v682_7_tail.empty()) continue;
        const Path v682_7_head{v682_7_label};
        const Space v683_2 = singleton(v682_7_head);
        const Space v683_3 = intersect(constant_14,v683_2);
        const Space v683_4 = (has_head(v683_3) ? constant_15 : Space{});
        const Space v683_5 = subtract(constant_0,v683_4);
        Space v683_8;
        if (!v683_5.empty()) {
          const Path v684_6 = concat_path(v682_6,v682_7_head);
          const Space v684_7 = routine_110(c, v684_6, p1, v682_7_tail, s1);
          v683_8 = compose(v683_5,v684_7);
        }
        const Space v683_9 = intersect(constant_14,v683_2);
        const Space v683_10 = (has_head(v683_9) ? constant_15 : Space{});
        Space v683_12;
        if (!v683_10.empty()) {
          const Path v685_6 = concat_path(v682_6,v682_7_head);
          const Space v685_11 = routine_111(c, v685_6, p1, v682_7_tail, s1);
          v683_12 = compose(v683_10,v685_11);
        }
        const Space v683_13 = unite(v683_8,v683_12);
        v682_7_result = unite(v682_7_result,v683_13);
      }
      const Space v682_7 = std::move(v682_7_result);
      v681_8 = compose(v681_5,v682_7);
    }
    const Space v681_9 = intersect(constant_14,v681_2);
    const Space v681_10 = (has_head(v681_9) ? constant_15 : Space{});
    Space v681_12;
    if (!v681_10.empty()) {
      const Path v686_6 = concat_path(p0,v680_13_head);
      Space v686_11_result;
      for (int v686_11_label = 1; v686_11_label <= 2; ++v686_11_label) {
        const Space v686_11_tail = child(v680_13_tail,v686_11_label);
        if (v686_11_tail.empty()) continue;
        const Path v686_11_head{v686_11_label};
        const Space v687_2 = singleton(v686_11_head);
        const Space v687_3 = intersect(constant_14,v687_2);
        const Space v687_4 = (has_head(v687_3) ? constant_15 : Space{});
        const Space v687_5 = subtract(constant_0,v687_4);
        Space v687_8;
        if (!v687_5.empty()) {
          const Path v688_6 = concat_path(v686_6,v686_11_head);
          const Space v688_7 = routine_110(c, v688_6, p1, v686_11_tail, s1);
          v687_8 = compose(v687_5,v688_7);
        }
        const Space v687_9 = intersect(constant_14,v687_2);
        const Space v687_10 = (has_head(v687_9) ? constant_15 : Space{});
        Space v687_12;
        if (!v687_10.empty()) {
          const Path v689_6 = concat_path(v686_6,v686_11_head);
          const Space v689_11 = routine_40(c, v689_6, p1, v686_11_tail, s1);
          v687_12 = compose(v687_10,v689_11);
        }
        const Space v687_13 = unite(v687_8,v687_12);
        v686_11_result = unite(v686_11_result,v687_13);
      }
      const Space v686_11 = std::move(v686_11_result);
      v681_12 = compose(v681_10,v686_11);
    }
    const Space v681_13 = unite(v681_8,v681_12);
    v680_13_result = unite(v680_13_result,v681_13);
  }
  const Space v680_13 = std::move(v680_13_result);
  return v680_13;
}

static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v690_8 = unwrap(s1,constant_9);
  const Space v690_10 = unwrap(v690_8,constant_10);
  const Space v690_11 = unwrap(v690_10,p0);
  Space v690_18_result;
  for (int v690_18_label = 1; v690_18_label <= 2; ++v690_18_label) {
    const Space v690_18_tail = child(s0,v690_18_label);
    if (v690_18_tail.empty()) continue;
    const Path v690_18_head{v690_18_label};
    const Space v691_2 = singleton(v690_18_head);
    const Space v691_3 = intersect(constant_14,v691_2);
    const Space v691_4 = (has_head(v691_3) ? constant_15 : Space{});
    const Space v691_5 = subtract(constant_0,v691_4);
    Space v691_8;
    if (!v691_5.empty()) {
      const Path v692_6 = concat_path(p0,v690_18_head);
      Space v692_7_result;
      for (int v692_7_label = 1; v692_7_label <= 2; ++v692_7_label) {
        const Space v692_7_tail = child(v690_18_tail,v692_7_label);
        if (v692_7_tail.empty()) continue;
        const Path v692_7_head{v692_7_label};
        const Space v693_2 = singleton(v692_7_head);
        const Space v693_3 = intersect(constant_14,v693_2);
        const Space v693_4 = (has_head(v693_3) ? constant_15 : Space{});
        const Space v693_5 = subtract(constant_0,v693_4);
        Space v693_8;
        if (!v693_5.empty()) {
          const Path v694_6 = concat_path(v692_6,v692_7_head);
          const Space v694_7 = routine_110(c, v694_6, p1, v692_7_tail, s1);
          v693_8 = compose(v693_5,v694_7);
        }
        const Space v693_9 = intersect(constant_14,v693_2);
        const Space v693_10 = (has_head(v693_9) ? constant_15 : Space{});
        Space v693_12;
        if (!v693_10.empty()) {
          const Path v695_6 = concat_path(v692_6,v692_7_head);
          const Space v695_11 = routine_111(c, v695_6, p1, v692_7_tail, s1);
          v693_12 = compose(v693_10,v695_11);
        }
        const Space v693_13 = unite(v693_8,v693_12);
        v692_7_result = unite(v692_7_result,v693_13);
      }
      const Space v692_7 = std::move(v692_7_result);
      v691_8 = compose(v691_5,v692_7);
    }
    const Space v691_9 = intersect(constant_14,v691_2);
    const Space v691_10 = (has_head(v691_9) ? constant_15 : Space{});
    Space v691_13;
    if (!v691_10.empty()) {
      const Space v696_11 = unwrap(v690_11,v690_18_head);
      Space v696_12_result;
      for (int v696_12_label = 1; v696_12_label <= 2; ++v696_12_label) {
        const Space v696_12_tail = child(v696_11,v696_12_label);
        if (v696_12_tail.empty()) continue;
        const Path v696_12_head{v696_12_label};
        const Space v697_2 = singleton(v696_12_head);
        const Space v697_3 = intersect(constant_14,v697_2);
        const Space v697_4 = (has_head(v697_3) ? constant_15 : Space{});
        const Space v697_5 = subtract(constant_0,v697_4);
        Space v697_7;
        if (!v697_5.empty()) {
          const Space v698_6 = routine_76(c, v696_12_head, p1, v696_12_tail);
          v697_7 = compose(v697_5,v698_6);
        }
        const Space v697_8 = intersect(constant_14,v697_2);
        const Space v697_9 = (has_head(v697_8) ? constant_15 : Space{});
        Space v697_11;
        if (!v697_9.empty()) {
          const Space v699_10 = routine_77(c, v696_12_head, p1, v696_12_tail);
          v697_11 = compose(v697_9,v699_10);
        }
        const Space v697_12 = unite(v697_7,v697_11);
        v696_12_result = unite(v696_12_result,v697_12);
      }
      const Space v696_12 = std::move(v696_12_result);
      v691_13 = compose(v691_10,v696_12);
    }
    const Space v691_14 = unite(v691_8,v691_13);
    v690_18_result = unite(v690_18_result,v691_14);
  }
  const Space v690_18 = std::move(v690_18_result);
  return v690_18;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v700_12_result;
  for (int v700_12_label = 1; v700_12_label <= 2; ++v700_12_label) {
    const Space v700_12_tail = child(s0,v700_12_label);
    if (v700_12_tail.empty()) continue;
    const Path v700_12_head{v700_12_label};
    const Space v701_2 = singleton(v700_12_head);
    const Space v701_3 = intersect(constant_14,v701_2);
    const Space v701_4 = (has_head(v701_3) ? constant_15 : Space{});
    const Space v701_5 = subtract(constant_0,v701_4);
    Space v701_8;
    if (!v701_5.empty()) {
      const Path v702_6 = concat_path(p0,v700_12_head);
      Space v702_7_result;
      for (int v702_7_label = 1; v702_7_label <= 2; ++v702_7_label) {
        const Space v702_7_tail = child(v700_12_tail,v702_7_label);
        if (v702_7_tail.empty()) continue;
        const Path v702_7_head{v702_7_label};
        const Space v703_2 = singleton(v702_7_head);
        const Space v703_3 = intersect(constant_14,v703_2);
        const Space v703_4 = (has_head(v703_3) ? constant_15 : Space{});
        const Space v703_5 = subtract(constant_0,v703_4);
        Space v703_8;
        if (!v703_5.empty()) {
          const Path v704_6 = concat_path(v702_6,v702_7_head);
          const Space v704_7 = routine_112(c, v704_6, p1, v702_7_tail);
          v703_8 = compose(v703_5,v704_7);
        }
        const Space v703_9 = intersect(constant_14,v703_2);
        const Space v703_10 = (has_head(v703_9) ? constant_15 : Space{});
        Space v703_12;
        if (!v703_10.empty()) {
          const Path v705_6 = concat_path(v702_6,v702_7_head);
          const Space v705_11 = routine_113(c, v705_6, p1, v702_7_tail);
          v703_12 = compose(v703_10,v705_11);
        }
        const Space v703_13 = unite(v703_8,v703_12);
        v702_7_result = unite(v702_7_result,v703_13);
      }
      const Space v702_7 = std::move(v702_7_result);
      v701_8 = compose(v701_5,v702_7);
    }
    const Space v701_9 = intersect(constant_14,v701_2);
    const Space v701_10 = (has_head(v701_9) ? constant_15 : Space{});
    Space v701_12;
    if (!v701_10.empty()) {
      const Path v706_6 = concat_path(p0,v700_12_head);
      Space v706_11_result;
      for (int v706_11_label = 1; v706_11_label <= 2; ++v706_11_label) {
        const Space v706_11_tail = child(v700_12_tail,v706_11_label);
        if (v706_11_tail.empty()) continue;
        const Path v706_11_head{v706_11_label};
        const Space v707_2 = singleton(v706_11_head);
        const Space v707_3 = intersect(constant_14,v707_2);
        const Space v707_4 = (has_head(v707_3) ? constant_15 : Space{});
        const Space v707_5 = subtract(constant_0,v707_4);
        Space v707_8;
        if (!v707_5.empty()) {
          const Path v708_6 = concat_path(v706_6,v706_11_head);
          const Space v708_7 = routine_112(c, v708_6, p1, v706_11_tail);
          v707_8 = compose(v707_5,v708_7);
        }
        const Space v707_9 = intersect(constant_14,v707_2);
        const Space v707_10 = (has_head(v707_9) ? constant_15 : Space{});
        Space v707_12;
        if (!v707_10.empty()) {
          const Path v709_6 = concat_path(v706_6,v706_11_head);
          const Space v709_11 = routine_82(c, v709_6, p1, v706_11_tail);
          v707_12 = compose(v707_10,v709_11);
        }
        const Space v707_13 = unite(v707_8,v707_12);
        v706_11_result = unite(v706_11_result,v707_13);
      }
      const Space v706_11 = std::move(v706_11_result);
      v701_12 = compose(v701_10,v706_11);
    }
    const Space v701_13 = unite(v701_8,v701_12);
    v700_12_result = unite(v700_12_result,v701_13);
  }
  const Space v700_12 = std::move(v700_12_result);
  return v700_12;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v710_9_result;
  for (int v710_9_label = 1; v710_9_label <= 2; ++v710_9_label) {
    const Space v710_9_tail = child(s0,v710_9_label);
    if (v710_9_tail.empty()) continue;
    const Path v710_9_head{v710_9_label};
    const Space v711_2 = singleton(v710_9_head);
    const Space v711_3 = intersect(constant_14,v711_2);
    const Space v711_4 = (has_head(v711_3) ? constant_15 : Space{});
    const Space v711_5 = subtract(constant_0,v711_4);
    Space v711_8;
    if (!v711_5.empty()) {
      const Path v712_6 = concat_path(p0,v710_9_head);
      Space v712_7_result;
      for (int v712_7_label = 1; v712_7_label <= 2; ++v712_7_label) {
        const Space v712_7_tail = child(v710_9_tail,v712_7_label);
        if (v712_7_tail.empty()) continue;
        const Path v712_7_head{v712_7_label};
        const Space v713_2 = singleton(v712_7_head);
        const Space v713_3 = intersect(constant_14,v713_2);
        const Space v713_4 = (has_head(v713_3) ? constant_15 : Space{});
        const Space v713_5 = subtract(constant_0,v713_4);
        Space v713_8;
        if (!v713_5.empty()) {
          const Path v714_6 = concat_path(v712_6,v712_7_head);
          const Space v714_7 = routine_112(c, v714_6, p1, v712_7_tail);
          v713_8 = compose(v713_5,v714_7);
        }
        const Space v713_9 = intersect(constant_14,v713_2);
        const Space v713_10 = (has_head(v713_9) ? constant_15 : Space{});
        Space v713_12;
        if (!v713_10.empty()) {
          const Path v715_6 = concat_path(v712_6,v712_7_head);
          const Space v715_11 = routine_113(c, v715_6, p1, v712_7_tail);
          v713_12 = compose(v713_10,v715_11);
        }
        const Space v713_13 = unite(v713_8,v713_12);
        v712_7_result = unite(v712_7_result,v713_13);
      }
      const Space v712_7 = std::move(v712_7_result);
      v711_8 = compose(v711_5,v712_7);
    }
    const Space v711_9 = intersect(constant_14,v711_2);
    const Space v711_10 = (has_head(v711_9) ? constant_15 : Space{});
    const Space v711_11 = compose(v711_10,v710_9_tail);
    const Path v716_6 = concat_path(p0,v710_9_head);
    const Space v711_12 = wrap(v711_11,v716_6);
    const Space v711_13 = wrap(v711_12,p1);
    const Space v711_14 = unite(v711_8,v711_13);
    v710_9_result = unite(v710_9_result,v711_14);
  }
  const Space v710_9 = std::move(v710_9_result);
  return v710_9;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v717_13_result;
  for (int v717_13_label = 1; v717_13_label <= 2; ++v717_13_label) {
    const Space v717_13_tail = child(s0,v717_13_label);
    if (v717_13_tail.empty()) continue;
    const Path v717_13_head{v717_13_label};
    const Space v718_2 = singleton(v717_13_head);
    const Space v718_3 = intersect(constant_14,v718_2);
    const Space v718_4 = (has_head(v718_3) ? constant_15 : Space{});
    const Space v718_5 = subtract(constant_0,v718_4);
    Space v718_8;
    if (!v718_5.empty()) {
      const Path v719_6 = concat_path(p0,v717_13_head);
      Space v719_7_result;
      for (int v719_7_label = 1; v719_7_label <= 2; ++v719_7_label) {
        const Space v719_7_tail = child(v717_13_tail,v719_7_label);
        if (v719_7_tail.empty()) continue;
        const Path v719_7_head{v719_7_label};
        const Space v720_2 = singleton(v719_7_head);
        const Space v720_3 = intersect(constant_14,v720_2);
        const Space v720_4 = (has_head(v720_3) ? constant_15 : Space{});
        const Space v720_5 = subtract(constant_0,v720_4);
        Space v720_8;
        if (!v720_5.empty()) {
          const Path v721_6 = concat_path(v719_6,v719_7_head);
          const Space v721_7 = routine_114(c, v721_6, p1, v719_7_tail, s1);
          v720_8 = compose(v720_5,v721_7);
        }
        const Space v720_9 = intersect(constant_14,v720_2);
        const Space v720_10 = (has_head(v720_9) ? constant_15 : Space{});
        Space v720_12;
        if (!v720_10.empty()) {
          const Path v722_6 = concat_path(v719_6,v719_7_head);
          const Space v722_11 = routine_115(c, v722_6, p1, v719_7_tail, s1);
          v720_12 = compose(v720_10,v722_11);
        }
        const Space v720_13 = unite(v720_8,v720_12);
        v719_7_result = unite(v719_7_result,v720_13);
      }
      const Space v719_7 = std::move(v719_7_result);
      v718_8 = compose(v718_5,v719_7);
    }
    const Space v718_9 = intersect(constant_14,v718_2);
    const Space v718_10 = (has_head(v718_9) ? constant_15 : Space{});
    Space v718_12;
    if (!v718_10.empty()) {
      const Path v723_6 = concat_path(p0,v717_13_head);
      Space v723_11_result;
      for (int v723_11_label = 1; v723_11_label <= 2; ++v723_11_label) {
        const Space v723_11_tail = child(v717_13_tail,v723_11_label);
        if (v723_11_tail.empty()) continue;
        const Path v723_11_head{v723_11_label};
        const Space v724_2 = singleton(v723_11_head);
        const Space v724_3 = intersect(constant_14,v724_2);
        const Space v724_4 = (has_head(v724_3) ? constant_15 : Space{});
        const Space v724_5 = subtract(constant_0,v724_4);
        Space v724_8;
        if (!v724_5.empty()) {
          const Path v725_6 = concat_path(v723_6,v723_11_head);
          const Space v725_7 = routine_114(c, v725_6, p1, v723_11_tail, s1);
          v724_8 = compose(v724_5,v725_7);
        }
        const Space v724_9 = intersect(constant_14,v724_2);
        const Space v724_10 = (has_head(v724_9) ? constant_15 : Space{});
        Space v724_12;
        if (!v724_10.empty()) {
          const Path v726_6 = concat_path(v723_6,v723_11_head);
          const Space v726_11 = routine_40(c, v726_6, p1, v723_11_tail, s1);
          v724_12 = compose(v724_10,v726_11);
        }
        const Space v724_13 = unite(v724_8,v724_12);
        v723_11_result = unite(v723_11_result,v724_13);
      }
      const Space v723_11 = std::move(v723_11_result);
      v718_12 = compose(v718_10,v723_11);
    }
    const Space v718_13 = unite(v718_8,v718_12);
    v717_13_result = unite(v717_13_result,v718_13);
  }
  const Space v717_13 = std::move(v717_13_result);
  return v717_13;
}

static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v727_8 = unwrap(s1,constant_9);
  const Space v727_10 = unwrap(v727_8,constant_10);
  const Space v727_11 = unwrap(v727_10,p0);
  Space v727_18_result;
  for (int v727_18_label = 1; v727_18_label <= 2; ++v727_18_label) {
    const Space v727_18_tail = child(s0,v727_18_label);
    if (v727_18_tail.empty()) continue;
    const Path v727_18_head{v727_18_label};
    const Space v728_2 = singleton(v727_18_head);
    const Space v728_3 = intersect(constant_14,v728_2);
    const Space v728_4 = (has_head(v728_3) ? constant_15 : Space{});
    const Space v728_5 = subtract(constant_0,v728_4);
    Space v728_8;
    if (!v728_5.empty()) {
      const Path v729_6 = concat_path(p0,v727_18_head);
      Space v729_7_result;
      for (int v729_7_label = 1; v729_7_label <= 2; ++v729_7_label) {
        const Space v729_7_tail = child(v727_18_tail,v729_7_label);
        if (v729_7_tail.empty()) continue;
        const Path v729_7_head{v729_7_label};
        const Space v730_2 = singleton(v729_7_head);
        const Space v730_3 = intersect(constant_14,v730_2);
        const Space v730_4 = (has_head(v730_3) ? constant_15 : Space{});
        const Space v730_5 = subtract(constant_0,v730_4);
        Space v730_8;
        if (!v730_5.empty()) {
          const Path v731_6 = concat_path(v729_6,v729_7_head);
          const Space v731_7 = routine_114(c, v731_6, p1, v729_7_tail, s1);
          v730_8 = compose(v730_5,v731_7);
        }
        const Space v730_9 = intersect(constant_14,v730_2);
        const Space v730_10 = (has_head(v730_9) ? constant_15 : Space{});
        Space v730_12;
        if (!v730_10.empty()) {
          const Path v732_6 = concat_path(v729_6,v729_7_head);
          const Space v732_11 = routine_115(c, v732_6, p1, v729_7_tail, s1);
          v730_12 = compose(v730_10,v732_11);
        }
        const Space v730_13 = unite(v730_8,v730_12);
        v729_7_result = unite(v729_7_result,v730_13);
      }
      const Space v729_7 = std::move(v729_7_result);
      v728_8 = compose(v728_5,v729_7);
    }
    const Space v728_9 = intersect(constant_14,v728_2);
    const Space v728_10 = (has_head(v728_9) ? constant_15 : Space{});
    Space v728_13;
    if (!v728_10.empty()) {
      const Space v733_11 = unwrap(v727_11,v727_18_head);
      Space v733_12_result;
      for (int v733_12_label = 1; v733_12_label <= 2; ++v733_12_label) {
        const Space v733_12_tail = child(v733_11,v733_12_label);
        if (v733_12_tail.empty()) continue;
        const Path v733_12_head{v733_12_label};
        const Space v734_2 = singleton(v733_12_head);
        const Space v734_3 = intersect(constant_14,v734_2);
        const Space v734_4 = (has_head(v734_3) ? constant_15 : Space{});
        const Space v734_5 = subtract(constant_0,v734_4);
        Space v734_7;
        if (!v734_5.empty()) {
          const Space v735_6 = routine_76(c, v733_12_head, p1, v733_12_tail);
          v734_7 = compose(v734_5,v735_6);
        }
        const Space v734_8 = intersect(constant_14,v734_2);
        const Space v734_9 = (has_head(v734_8) ? constant_15 : Space{});
        Space v734_11;
        if (!v734_9.empty()) {
          const Space v736_10 = routine_77(c, v733_12_head, p1, v733_12_tail);
          v734_11 = compose(v734_9,v736_10);
        }
        const Space v734_12 = unite(v734_7,v734_11);
        v733_12_result = unite(v733_12_result,v734_12);
      }
      const Space v733_12 = std::move(v733_12_result);
      v728_13 = compose(v728_10,v733_12);
    }
    const Space v728_14 = unite(v728_8,v728_13);
    v727_18_result = unite(v727_18_result,v728_14);
  }
  const Space v727_18 = std::move(v727_18_result);
  return v727_18;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v737_12_result;
  for (int v737_12_label = 1; v737_12_label <= 2; ++v737_12_label) {
    const Space v737_12_tail = child(s0,v737_12_label);
    if (v737_12_tail.empty()) continue;
    const Path v737_12_head{v737_12_label};
    const Space v738_2 = singleton(v737_12_head);
    const Space v738_3 = intersect(constant_14,v738_2);
    const Space v738_4 = (has_head(v738_3) ? constant_15 : Space{});
    const Space v738_5 = subtract(constant_0,v738_4);
    Space v738_8;
    if (!v738_5.empty()) {
      const Path v739_6 = concat_path(p0,v737_12_head);
      Space v739_7_result;
      for (int v739_7_label = 1; v739_7_label <= 2; ++v739_7_label) {
        const Space v739_7_tail = child(v737_12_tail,v739_7_label);
        if (v739_7_tail.empty()) continue;
        const Path v739_7_head{v739_7_label};
        const Space v740_2 = singleton(v739_7_head);
        const Space v740_3 = intersect(constant_14,v740_2);
        const Space v740_4 = (has_head(v740_3) ? constant_15 : Space{});
        const Space v740_5 = subtract(constant_0,v740_4);
        Space v740_8;
        if (!v740_5.empty()) {
          const Path v741_6 = concat_path(v739_6,v739_7_head);
          const Space v741_7 = routine_116(c, v741_6, p1, v739_7_tail);
          v740_8 = compose(v740_5,v741_7);
        }
        const Space v740_9 = intersect(constant_14,v740_2);
        const Space v740_10 = (has_head(v740_9) ? constant_15 : Space{});
        Space v740_12;
        if (!v740_10.empty()) {
          const Path v742_6 = concat_path(v739_6,v739_7_head);
          const Space v742_11 = routine_117(c, v742_6, p1, v739_7_tail);
          v740_12 = compose(v740_10,v742_11);
        }
        const Space v740_13 = unite(v740_8,v740_12);
        v739_7_result = unite(v739_7_result,v740_13);
      }
      const Space v739_7 = std::move(v739_7_result);
      v738_8 = compose(v738_5,v739_7);
    }
    const Space v738_9 = intersect(constant_14,v738_2);
    const Space v738_10 = (has_head(v738_9) ? constant_15 : Space{});
    Space v738_12;
    if (!v738_10.empty()) {
      const Path v743_6 = concat_path(p0,v737_12_head);
      Space v743_11_result;
      for (int v743_11_label = 1; v743_11_label <= 2; ++v743_11_label) {
        const Space v743_11_tail = child(v737_12_tail,v743_11_label);
        if (v743_11_tail.empty()) continue;
        const Path v743_11_head{v743_11_label};
        const Space v744_2 = singleton(v743_11_head);
        const Space v744_3 = intersect(constant_14,v744_2);
        const Space v744_4 = (has_head(v744_3) ? constant_15 : Space{});
        const Space v744_5 = subtract(constant_0,v744_4);
        Space v744_8;
        if (!v744_5.empty()) {
          const Path v745_6 = concat_path(v743_6,v743_11_head);
          const Space v745_7 = routine_116(c, v745_6, p1, v743_11_tail);
          v744_8 = compose(v744_5,v745_7);
        }
        const Space v744_9 = intersect(constant_14,v744_2);
        const Space v744_10 = (has_head(v744_9) ? constant_15 : Space{});
        Space v744_12;
        if (!v744_10.empty()) {
          const Path v746_6 = concat_path(v743_6,v743_11_head);
          const Space v746_11 = routine_82(c, v746_6, p1, v743_11_tail);
          v744_12 = compose(v744_10,v746_11);
        }
        const Space v744_13 = unite(v744_8,v744_12);
        v743_11_result = unite(v743_11_result,v744_13);
      }
      const Space v743_11 = std::move(v743_11_result);
      v738_12 = compose(v738_10,v743_11);
    }
    const Space v738_13 = unite(v738_8,v738_12);
    v737_12_result = unite(v737_12_result,v738_13);
  }
  const Space v737_12 = std::move(v737_12_result);
  return v737_12;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v747_9_result;
  for (int v747_9_label = 1; v747_9_label <= 2; ++v747_9_label) {
    const Space v747_9_tail = child(s0,v747_9_label);
    if (v747_9_tail.empty()) continue;
    const Path v747_9_head{v747_9_label};
    const Space v748_2 = singleton(v747_9_head);
    const Space v748_3 = intersect(constant_14,v748_2);
    const Space v748_4 = (has_head(v748_3) ? constant_15 : Space{});
    const Space v748_5 = subtract(constant_0,v748_4);
    Space v748_8;
    if (!v748_5.empty()) {
      const Path v749_6 = concat_path(p0,v747_9_head);
      Space v749_7_result;
      for (int v749_7_label = 1; v749_7_label <= 2; ++v749_7_label) {
        const Space v749_7_tail = child(v747_9_tail,v749_7_label);
        if (v749_7_tail.empty()) continue;
        const Path v749_7_head{v749_7_label};
        const Space v750_2 = singleton(v749_7_head);
        const Space v750_3 = intersect(constant_14,v750_2);
        const Space v750_4 = (has_head(v750_3) ? constant_15 : Space{});
        const Space v750_5 = subtract(constant_0,v750_4);
        Space v750_8;
        if (!v750_5.empty()) {
          const Path v751_6 = concat_path(v749_6,v749_7_head);
          const Space v751_7 = routine_116(c, v751_6, p1, v749_7_tail);
          v750_8 = compose(v750_5,v751_7);
        }
        const Space v750_9 = intersect(constant_14,v750_2);
        const Space v750_10 = (has_head(v750_9) ? constant_15 : Space{});
        Space v750_12;
        if (!v750_10.empty()) {
          const Path v752_6 = concat_path(v749_6,v749_7_head);
          const Space v752_11 = routine_117(c, v752_6, p1, v749_7_tail);
          v750_12 = compose(v750_10,v752_11);
        }
        const Space v750_13 = unite(v750_8,v750_12);
        v749_7_result = unite(v749_7_result,v750_13);
      }
      const Space v749_7 = std::move(v749_7_result);
      v748_8 = compose(v748_5,v749_7);
    }
    const Space v748_9 = intersect(constant_14,v748_2);
    const Space v748_10 = (has_head(v748_9) ? constant_15 : Space{});
    const Space v748_11 = compose(v748_10,v747_9_tail);
    const Path v753_6 = concat_path(p0,v747_9_head);
    const Space v748_12 = wrap(v748_11,v753_6);
    const Space v748_13 = wrap(v748_12,p1);
    const Space v748_14 = unite(v748_8,v748_13);
    v747_9_result = unite(v747_9_result,v748_14);
  }
  const Space v747_9 = std::move(v747_9_result);
  return v747_9;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v754_3 = wrap(s0,p0);
  const Space v754_4 = wrap(v754_3,p1);
  return v754_4;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v755_5_result;
  for (int v755_5_label = 1; v755_5_label <= 2; ++v755_5_label) {
    const Space v755_5_tail = child(s0,v755_5_label);
    if (v755_5_tail.empty()) continue;
    const Path v755_5_head{v755_5_label};
    const Space v756_2 = singleton(v755_5_head);
    const Space v756_3 = intersect(constant_14,v756_2);
    const Space v756_4 = (has_head(v756_3) ? constant_15 : Space{});
    Space v756_7;
    if (!v756_4.empty()) {
      const Path v757_5 = concat_path(p0,v755_5_head);
      Space v757_6_result;
      for (int v757_6_label = 1; v757_6_label <= 2; ++v757_6_label) {
        const Space v757_6_tail = child(v755_5_tail,v757_6_label);
        if (v757_6_tail.empty()) continue;
        const Path v757_6_head{v757_6_label};
        const Space v758_2 = singleton(v757_6_head);
        const Space v758_3 = intersect(constant_14,v758_2);
        const Space v758_4 = (has_head(v758_3) ? constant_15 : Space{});
        Space v758_7;
        if (!v758_4.empty()) {
          const Path v759_5 = concat_path(v757_5,v757_6_head);
          const Space v759_6 = routine_14(c, v759_5, v757_6_tail, s1);
          v758_7 = compose(v758_4,v759_6);
        }
        v757_6_result = unite(v757_6_result,v758_7);
      }
      const Space v757_6 = std::move(v757_6_result);
      v756_7 = compose(v756_4,v757_6);
    }
    v755_5_result = unite(v755_5_result,v756_7);
  }
  const Space v755_5 = std::move(v755_5_result);
  return v755_5;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v760_7_result;
  for (int v760_7_label = 1; v760_7_label <= 2; ++v760_7_label) {
    const Space v760_7_tail = child(s0,v760_7_label);
    if (v760_7_tail.empty()) continue;
    const Path v760_7_head{v760_7_label};
    const Space v761_2 = singleton(v760_7_head);
    const Space v761_3 = intersect(constant_14,v761_2);
    const Space v761_4 = (has_head(v761_3) ? constant_15 : Space{});
    Space v761_7;
    if (!v761_4.empty()) {
      const Path v762_5 = concat_path(p0,v760_7_head);
      Space v762_6_result;
      for (int v762_6_label = 1; v762_6_label <= 2; ++v762_6_label) {
        const Space v762_6_tail = child(v760_7_tail,v762_6_label);
        if (v762_6_tail.empty()) continue;
        const Path v762_6_head{v762_6_label};
        const Space v763_2 = singleton(v762_6_head);
        const Space v763_3 = intersect(constant_14,v763_2);
        const Space v763_4 = (has_head(v763_3) ? constant_15 : Space{});
        const Space v763_5 = subtract(constant_0,v763_4);
        Space v763_7;
        if (!v763_5.empty()) {
          const Space v764_6 = routine_43(c, v762_6_head, v762_5, v762_6_tail, s1);
          v763_7 = compose(v763_5,v764_6);
        }
        const Space v763_8 = intersect(constant_14,v763_2);
        const Space v763_9 = (has_head(v763_8) ? constant_15 : Space{});
        Space v763_11;
        if (!v763_9.empty()) {
          const Space v765_10 = routine_44(c, v762_6_head, v762_5, v762_6_tail, s1);
          v763_11 = compose(v763_9,v765_10);
        }
        const Space v763_12 = unite(v763_7,v763_11);
        v762_6_result = unite(v762_6_result,v763_12);
      }
      const Space v762_6 = std::move(v762_6_result);
      v761_7 = compose(v761_4,v762_6);
    }
    v760_7_result = unite(v760_7_result,v761_7);
  }
  const Space v760_7 = std::move(v760_7_result);
  return v760_7;
}

static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v766_13_result;
  for (int v766_13_label = 1; v766_13_label <= 2; ++v766_13_label) {
    const Space v766_13_tail = child(s0,v766_13_label);
    if (v766_13_tail.empty()) continue;
    const Path v766_13_head{v766_13_label};
    const Space v767_2 = singleton(v766_13_head);
    const Space v767_3 = intersect(constant_14,v767_2);
    const Space v767_4 = (has_head(v767_3) ? constant_15 : Space{});
    const Space v767_5 = subtract(constant_0,v767_4);
    Space v767_8;
    if (!v767_5.empty()) {
      const Path v768_6 = concat_path(p0,v766_13_head);
      Space v768_7_result;
      for (int v768_7_label = 1; v768_7_label <= 2; ++v768_7_label) {
        const Space v768_7_tail = child(v766_13_tail,v768_7_label);
        if (v768_7_tail.empty()) continue;
        const Path v768_7_head{v768_7_label};
        const Space v769_2 = singleton(v768_7_head);
        const Space v769_3 = intersect(constant_14,v769_2);
        const Space v769_4 = (has_head(v769_3) ? constant_15 : Space{});
        const Space v769_5 = subtract(constant_0,v769_4);
        Space v769_8;
        if (!v769_5.empty()) {
          const Path v770_6 = concat_path(v768_6,v768_7_head);
          const Space v770_7 = routine_118(c, v770_6, p1, v768_7_tail, s1);
          v769_8 = compose(v769_5,v770_7);
        }
        const Space v769_9 = intersect(constant_14,v769_2);
        const Space v769_10 = (has_head(v769_9) ? constant_15 : Space{});
        Space v769_12;
        if (!v769_10.empty()) {
          const Path v771_6 = concat_path(v768_6,v768_7_head);
          const Space v771_11 = routine_119(c, v771_6, p1, v768_7_tail, s1);
          v769_12 = compose(v769_10,v771_11);
        }
        const Space v769_13 = unite(v769_8,v769_12);
        v768_7_result = unite(v768_7_result,v769_13);
      }
      const Space v768_7 = std::move(v768_7_result);
      v767_8 = compose(v767_5,v768_7);
    }
    const Space v767_9 = intersect(constant_14,v767_2);
    const Space v767_10 = (has_head(v767_9) ? constant_15 : Space{});
    Space v767_12;
    if (!v767_10.empty()) {
      const Path v772_6 = concat_path(p0,v766_13_head);
      Space v772_11_result;
      for (int v772_11_label = 1; v772_11_label <= 2; ++v772_11_label) {
        const Space v772_11_tail = child(v766_13_tail,v772_11_label);
        if (v772_11_tail.empty()) continue;
        const Path v772_11_head{v772_11_label};
        const Space v773_2 = singleton(v772_11_head);
        const Space v773_3 = intersect(constant_14,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_15 : Space{});
        const Space v773_5 = subtract(constant_0,v773_4);
        Space v773_8;
        if (!v773_5.empty()) {
          const Path v774_6 = concat_path(v772_6,v772_11_head);
          const Space v774_7 = routine_118(c, v774_6, p1, v772_11_tail, s1);
          v773_8 = compose(v773_5,v774_7);
        }
        const Space v773_9 = intersect(constant_14,v773_2);
        const Space v773_10 = (has_head(v773_9) ? constant_15 : Space{});
        Space v773_12;
        if (!v773_10.empty()) {
          const Path v775_6 = concat_path(v772_6,v772_11_head);
          const Space v775_11 = routine_47(c, v775_6, p1, v772_11_tail, s1);
          v773_12 = compose(v773_10,v775_11);
        }
        const Space v773_13 = unite(v773_8,v773_12);
        v772_11_result = unite(v772_11_result,v773_13);
      }
      const Space v772_11 = std::move(v772_11_result);
      v767_12 = compose(v767_10,v772_11);
    }
    const Space v767_13 = unite(v767_8,v767_12);
    v766_13_result = unite(v766_13_result,v767_13);
  }
  const Space v766_13 = std::move(v766_13_result);
  return v766_13;
}

static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v776_8 = unwrap(s1,constant_7);
  const Space v776_10 = unwrap(v776_8,constant_10);
  const Space v776_11 = unwrap(v776_10,p0);
  Space v776_18_result;
  for (int v776_18_label = 1; v776_18_label <= 2; ++v776_18_label) {
    const Space v776_18_tail = child(s0,v776_18_label);
    if (v776_18_tail.empty()) continue;
    const Path v776_18_head{v776_18_label};
    const Space v777_2 = singleton(v776_18_head);
    const Space v777_3 = intersect(constant_14,v777_2);
    const Space v777_4 = (has_head(v777_3) ? constant_15 : Space{});
    const Space v777_5 = subtract(constant_0,v777_4);
    Space v777_8;
    if (!v777_5.empty()) {
      const Path v778_6 = concat_path(p0,v776_18_head);
      Space v778_7_result;
      for (int v778_7_label = 1; v778_7_label <= 2; ++v778_7_label) {
        const Space v778_7_tail = child(v776_18_tail,v778_7_label);
        if (v778_7_tail.empty()) continue;
        const Path v778_7_head{v778_7_label};
        const Space v779_2 = singleton(v778_7_head);
        const Space v779_3 = intersect(constant_14,v779_2);
        const Space v779_4 = (has_head(v779_3) ? constant_15 : Space{});
        const Space v779_5 = subtract(constant_0,v779_4);
        Space v779_8;
        if (!v779_5.empty()) {
          const Path v780_6 = concat_path(v778_6,v778_7_head);
          const Space v780_7 = routine_118(c, v780_6, p1, v778_7_tail, s1);
          v779_8 = compose(v779_5,v780_7);
        }
        const Space v779_9 = intersect(constant_14,v779_2);
        const Space v779_10 = (has_head(v779_9) ? constant_15 : Space{});
        Space v779_12;
        if (!v779_10.empty()) {
          const Path v781_6 = concat_path(v778_6,v778_7_head);
          const Space v781_11 = routine_119(c, v781_6, p1, v778_7_tail, s1);
          v779_12 = compose(v779_10,v781_11);
        }
        const Space v779_13 = unite(v779_8,v779_12);
        v778_7_result = unite(v778_7_result,v779_13);
      }
      const Space v778_7 = std::move(v778_7_result);
      v777_8 = compose(v777_5,v778_7);
    }
    const Space v777_9 = intersect(constant_14,v777_2);
    const Space v777_10 = (has_head(v777_9) ? constant_15 : Space{});
    Space v777_13;
    if (!v777_10.empty()) {
      const Space v782_11 = unwrap(v776_11,v776_18_head);
      Space v782_12_result;
      for (int v782_12_label = 1; v782_12_label <= 2; ++v782_12_label) {
        const Space v782_12_tail = child(v782_11,v782_12_label);
        if (v782_12_tail.empty()) continue;
        const Path v782_12_head{v782_12_label};
        const Space v783_2 = singleton(v782_12_head);
        const Space v783_3 = intersect(constant_14,v783_2);
        const Space v783_4 = (has_head(v783_3) ? constant_15 : Space{});
        const Space v783_5 = subtract(constant_0,v783_4);
        Space v783_7;
        if (!v783_5.empty()) {
          const Space v784_6 = routine_87(c, v782_12_head, p1, v782_12_tail);
          v783_7 = compose(v783_5,v784_6);
        }
        const Space v783_8 = intersect(constant_14,v783_2);
        const Space v783_9 = (has_head(v783_8) ? constant_15 : Space{});
        Space v783_11;
        if (!v783_9.empty()) {
          const Space v785_10 = routine_88(c, v782_12_head, p1, v782_12_tail);
          v783_11 = compose(v783_9,v785_10);
        }
        const Space v783_12 = unite(v783_7,v783_11);
        v782_12_result = unite(v782_12_result,v783_12);
      }
      const Space v782_12 = std::move(v782_12_result);
      v777_13 = compose(v777_10,v782_12);
    }
    const Space v777_14 = unite(v777_8,v777_13);
    v776_18_result = unite(v776_18_result,v777_14);
  }
  const Space v776_18 = std::move(v776_18_result);
  return v776_18;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v786_12_result;
  for (int v786_12_label = 1; v786_12_label <= 2; ++v786_12_label) {
    const Space v786_12_tail = child(s0,v786_12_label);
    if (v786_12_tail.empty()) continue;
    const Path v786_12_head{v786_12_label};
    const Space v787_2 = singleton(v786_12_head);
    const Space v787_3 = intersect(constant_14,v787_2);
    const Space v787_4 = (has_head(v787_3) ? constant_15 : Space{});
    const Space v787_5 = subtract(constant_0,v787_4);
    Space v787_8;
    if (!v787_5.empty()) {
      const Path v788_6 = concat_path(p0,v786_12_head);
      Space v788_7_result;
      for (int v788_7_label = 1; v788_7_label <= 2; ++v788_7_label) {
        const Space v788_7_tail = child(v786_12_tail,v788_7_label);
        if (v788_7_tail.empty()) continue;
        const Path v788_7_head{v788_7_label};
        const Space v789_2 = singleton(v788_7_head);
        const Space v789_3 = intersect(constant_14,v789_2);
        const Space v789_4 = (has_head(v789_3) ? constant_15 : Space{});
        const Space v789_5 = subtract(constant_0,v789_4);
        Space v789_8;
        if (!v789_5.empty()) {
          const Path v790_6 = concat_path(v788_6,v788_7_head);
          const Space v790_7 = routine_120(c, v790_6, p1, v788_7_tail);
          v789_8 = compose(v789_5,v790_7);
        }
        const Space v789_9 = intersect(constant_14,v789_2);
        const Space v789_10 = (has_head(v789_9) ? constant_15 : Space{});
        Space v789_12;
        if (!v789_10.empty()) {
          const Path v791_6 = concat_path(v788_6,v788_7_head);
          const Space v791_11 = routine_121(c, v791_6, p1, v788_7_tail);
          v789_12 = compose(v789_10,v791_11);
        }
        const Space v789_13 = unite(v789_8,v789_12);
        v788_7_result = unite(v788_7_result,v789_13);
      }
      const Space v788_7 = std::move(v788_7_result);
      v787_8 = compose(v787_5,v788_7);
    }
    const Space v787_9 = intersect(constant_14,v787_2);
    const Space v787_10 = (has_head(v787_9) ? constant_15 : Space{});
    Space v787_12;
    if (!v787_10.empty()) {
      const Path v792_6 = concat_path(p0,v786_12_head);
      Space v792_11_result;
      for (int v792_11_label = 1; v792_11_label <= 2; ++v792_11_label) {
        const Space v792_11_tail = child(v786_12_tail,v792_11_label);
        if (v792_11_tail.empty()) continue;
        const Path v792_11_head{v792_11_label};
        const Space v793_2 = singleton(v792_11_head);
        const Space v793_3 = intersect(constant_14,v793_2);
        const Space v793_4 = (has_head(v793_3) ? constant_15 : Space{});
        const Space v793_5 = subtract(constant_0,v793_4);
        Space v793_8;
        if (!v793_5.empty()) {
          const Path v794_6 = concat_path(v792_6,v792_11_head);
          const Space v794_7 = routine_120(c, v794_6, p1, v792_11_tail);
          v793_8 = compose(v793_5,v794_7);
        }
        const Space v793_9 = intersect(constant_14,v793_2);
        const Space v793_10 = (has_head(v793_9) ? constant_15 : Space{});
        Space v793_12;
        if (!v793_10.empty()) {
          const Path v795_6 = concat_path(v792_6,v792_11_head);
          const Space v795_11 = routine_93(c, v795_6, p1, v792_11_tail);
          v793_12 = compose(v793_10,v795_11);
        }
        const Space v793_13 = unite(v793_8,v793_12);
        v792_11_result = unite(v792_11_result,v793_13);
      }
      const Space v792_11 = std::move(v792_11_result);
      v787_12 = compose(v787_10,v792_11);
    }
    const Space v787_13 = unite(v787_8,v787_12);
    v786_12_result = unite(v786_12_result,v787_13);
  }
  const Space v786_12 = std::move(v786_12_result);
  return v786_12;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v796_9_result;
  for (int v796_9_label = 1; v796_9_label <= 2; ++v796_9_label) {
    const Space v796_9_tail = child(s0,v796_9_label);
    if (v796_9_tail.empty()) continue;
    const Path v796_9_head{v796_9_label};
    const Space v797_2 = singleton(v796_9_head);
    const Space v797_3 = intersect(constant_14,v797_2);
    const Space v797_4 = (has_head(v797_3) ? constant_15 : Space{});
    const Space v797_5 = subtract(constant_0,v797_4);
    Space v797_8;
    if (!v797_5.empty()) {
      const Path v798_6 = concat_path(p0,v796_9_head);
      Space v798_7_result;
      for (int v798_7_label = 1; v798_7_label <= 2; ++v798_7_label) {
        const Space v798_7_tail = child(v796_9_tail,v798_7_label);
        if (v798_7_tail.empty()) continue;
        const Path v798_7_head{v798_7_label};
        const Space v799_2 = singleton(v798_7_head);
        const Space v799_3 = intersect(constant_14,v799_2);
        const Space v799_4 = (has_head(v799_3) ? constant_15 : Space{});
        const Space v799_5 = subtract(constant_0,v799_4);
        Space v799_8;
        if (!v799_5.empty()) {
          const Path v800_6 = concat_path(v798_6,v798_7_head);
          const Space v800_7 = routine_120(c, v800_6, p1, v798_7_tail);
          v799_8 = compose(v799_5,v800_7);
        }
        const Space v799_9 = intersect(constant_14,v799_2);
        const Space v799_10 = (has_head(v799_9) ? constant_15 : Space{});
        Space v799_12;
        if (!v799_10.empty()) {
          const Path v801_6 = concat_path(v798_6,v798_7_head);
          const Space v801_11 = routine_121(c, v801_6, p1, v798_7_tail);
          v799_12 = compose(v799_10,v801_11);
        }
        const Space v799_13 = unite(v799_8,v799_12);
        v798_7_result = unite(v798_7_result,v799_13);
      }
      const Space v798_7 = std::move(v798_7_result);
      v797_8 = compose(v797_5,v798_7);
    }
    const Space v797_9 = intersect(constant_14,v797_2);
    const Space v797_10 = (has_head(v797_9) ? constant_15 : Space{});
    const Space v797_11 = compose(v797_10,v796_9_tail);
    const Path v802_6 = concat_path(p0,v796_9_head);
    const Space v797_12 = wrap(v797_11,v802_6);
    const Space v797_13 = wrap(v797_12,p1);
    const Space v797_14 = unite(v797_8,v797_13);
    v796_9_result = unite(v796_9_result,v797_14);
  }
  const Space v796_9 = std::move(v796_9_result);
  return v796_9;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v803_13_result;
  for (int v803_13_label = 1; v803_13_label <= 2; ++v803_13_label) {
    const Space v803_13_tail = child(s0,v803_13_label);
    if (v803_13_tail.empty()) continue;
    const Path v803_13_head{v803_13_label};
    const Space v804_2 = singleton(v803_13_head);
    const Space v804_3 = intersect(constant_14,v804_2);
    const Space v804_4 = (has_head(v804_3) ? constant_15 : Space{});
    const Space v804_5 = subtract(constant_0,v804_4);
    Space v804_8;
    if (!v804_5.empty()) {
      const Path v805_6 = concat_path(p0,v803_13_head);
      Space v805_7_result;
      for (int v805_7_label = 1; v805_7_label <= 2; ++v805_7_label) {
        const Space v805_7_tail = child(v803_13_tail,v805_7_label);
        if (v805_7_tail.empty()) continue;
        const Path v805_7_head{v805_7_label};
        const Space v806_2 = singleton(v805_7_head);
        const Space v806_3 = intersect(constant_14,v806_2);
        const Space v806_4 = (has_head(v806_3) ? constant_15 : Space{});
        const Space v806_5 = subtract(constant_0,v806_4);
        Space v806_8;
        if (!v806_5.empty()) {
          const Path v807_6 = concat_path(v805_6,v805_7_head);
          const Space v807_7 = routine_122(c, v807_6, p1, v805_7_tail, s1);
          v806_8 = compose(v806_5,v807_7);
        }
        const Space v806_9 = intersect(constant_14,v806_2);
        const Space v806_10 = (has_head(v806_9) ? constant_15 : Space{});
        Space v806_12;
        if (!v806_10.empty()) {
          const Path v808_6 = concat_path(v805_6,v805_7_head);
          const Space v808_11 = routine_123(c, v808_6, p1, v805_7_tail, s1);
          v806_12 = compose(v806_10,v808_11);
        }
        const Space v806_13 = unite(v806_8,v806_12);
        v805_7_result = unite(v805_7_result,v806_13);
      }
      const Space v805_7 = std::move(v805_7_result);
      v804_8 = compose(v804_5,v805_7);
    }
    const Space v804_9 = intersect(constant_14,v804_2);
    const Space v804_10 = (has_head(v804_9) ? constant_15 : Space{});
    Space v804_12;
    if (!v804_10.empty()) {
      const Path v809_6 = concat_path(p0,v803_13_head);
      Space v809_11_result;
      for (int v809_11_label = 1; v809_11_label <= 2; ++v809_11_label) {
        const Space v809_11_tail = child(v803_13_tail,v809_11_label);
        if (v809_11_tail.empty()) continue;
        const Path v809_11_head{v809_11_label};
        const Space v810_2 = singleton(v809_11_head);
        const Space v810_3 = intersect(constant_14,v810_2);
        const Space v810_4 = (has_head(v810_3) ? constant_15 : Space{});
        const Space v810_5 = subtract(constant_0,v810_4);
        Space v810_8;
        if (!v810_5.empty()) {
          const Path v811_6 = concat_path(v809_6,v809_11_head);
          const Space v811_7 = routine_122(c, v811_6, p1, v809_11_tail, s1);
          v810_8 = compose(v810_5,v811_7);
        }
        const Space v810_9 = intersect(constant_14,v810_2);
        const Space v810_10 = (has_head(v810_9) ? constant_15 : Space{});
        Space v810_12;
        if (!v810_10.empty()) {
          const Path v812_6 = concat_path(v809_6,v809_11_head);
          const Space v812_11 = routine_47(c, v812_6, p1, v809_11_tail, s1);
          v810_12 = compose(v810_10,v812_11);
        }
        const Space v810_13 = unite(v810_8,v810_12);
        v809_11_result = unite(v809_11_result,v810_13);
      }
      const Space v809_11 = std::move(v809_11_result);
      v804_12 = compose(v804_10,v809_11);
    }
    const Space v804_13 = unite(v804_8,v804_12);
    v803_13_result = unite(v803_13_result,v804_13);
  }
  const Space v803_13 = std::move(v803_13_result);
  return v803_13;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v813_8 = unwrap(s1,constant_7);
  const Space v813_10 = unwrap(v813_8,constant_10);
  const Space v813_11 = unwrap(v813_10,p0);
  Space v813_18_result;
  for (int v813_18_label = 1; v813_18_label <= 2; ++v813_18_label) {
    const Space v813_18_tail = child(s0,v813_18_label);
    if (v813_18_tail.empty()) continue;
    const Path v813_18_head{v813_18_label};
    const Space v814_2 = singleton(v813_18_head);
    const Space v814_3 = intersect(constant_14,v814_2);
    const Space v814_4 = (has_head(v814_3) ? constant_15 : Space{});
    const Space v814_5 = subtract(constant_0,v814_4);
    Space v814_8;
    if (!v814_5.empty()) {
      const Path v815_6 = concat_path(p0,v813_18_head);
      Space v815_7_result;
      for (int v815_7_label = 1; v815_7_label <= 2; ++v815_7_label) {
        const Space v815_7_tail = child(v813_18_tail,v815_7_label);
        if (v815_7_tail.empty()) continue;
        const Path v815_7_head{v815_7_label};
        const Space v816_2 = singleton(v815_7_head);
        const Space v816_3 = intersect(constant_14,v816_2);
        const Space v816_4 = (has_head(v816_3) ? constant_15 : Space{});
        const Space v816_5 = subtract(constant_0,v816_4);
        Space v816_8;
        if (!v816_5.empty()) {
          const Path v817_6 = concat_path(v815_6,v815_7_head);
          const Space v817_7 = routine_122(c, v817_6, p1, v815_7_tail, s1);
          v816_8 = compose(v816_5,v817_7);
        }
        const Space v816_9 = intersect(constant_14,v816_2);
        const Space v816_10 = (has_head(v816_9) ? constant_15 : Space{});
        Space v816_12;
        if (!v816_10.empty()) {
          const Path v818_6 = concat_path(v815_6,v815_7_head);
          const Space v818_11 = routine_123(c, v818_6, p1, v815_7_tail, s1);
          v816_12 = compose(v816_10,v818_11);
        }
        const Space v816_13 = unite(v816_8,v816_12);
        v815_7_result = unite(v815_7_result,v816_13);
      }
      const Space v815_7 = std::move(v815_7_result);
      v814_8 = compose(v814_5,v815_7);
    }
    const Space v814_9 = intersect(constant_14,v814_2);
    const Space v814_10 = (has_head(v814_9) ? constant_15 : Space{});
    Space v814_13;
    if (!v814_10.empty()) {
      const Space v819_11 = unwrap(v813_11,v813_18_head);
      Space v819_12_result;
      for (int v819_12_label = 1; v819_12_label <= 2; ++v819_12_label) {
        const Space v819_12_tail = child(v819_11,v819_12_label);
        if (v819_12_tail.empty()) continue;
        const Path v819_12_head{v819_12_label};
        const Space v820_2 = singleton(v819_12_head);
        const Space v820_3 = intersect(constant_14,v820_2);
        const Space v820_4 = (has_head(v820_3) ? constant_15 : Space{});
        const Space v820_5 = subtract(constant_0,v820_4);
        Space v820_7;
        if (!v820_5.empty()) {
          const Space v821_6 = routine_87(c, v819_12_head, p1, v819_12_tail);
          v820_7 = compose(v820_5,v821_6);
        }
        const Space v820_8 = intersect(constant_14,v820_2);
        const Space v820_9 = (has_head(v820_8) ? constant_15 : Space{});
        Space v820_11;
        if (!v820_9.empty()) {
          const Space v822_10 = routine_88(c, v819_12_head, p1, v819_12_tail);
          v820_11 = compose(v820_9,v822_10);
        }
        const Space v820_12 = unite(v820_7,v820_11);
        v819_12_result = unite(v819_12_result,v820_12);
      }
      const Space v819_12 = std::move(v819_12_result);
      v814_13 = compose(v814_10,v819_12);
    }
    const Space v814_14 = unite(v814_8,v814_13);
    v813_18_result = unite(v813_18_result,v814_14);
  }
  const Space v813_18 = std::move(v813_18_result);
  return v813_18;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v823_12_result;
  for (int v823_12_label = 1; v823_12_label <= 2; ++v823_12_label) {
    const Space v823_12_tail = child(s0,v823_12_label);
    if (v823_12_tail.empty()) continue;
    const Path v823_12_head{v823_12_label};
    const Space v824_2 = singleton(v823_12_head);
    const Space v824_3 = intersect(constant_14,v824_2);
    const Space v824_4 = (has_head(v824_3) ? constant_15 : Space{});
    const Space v824_5 = subtract(constant_0,v824_4);
    Space v824_8;
    if (!v824_5.empty()) {
      const Path v825_6 = concat_path(p0,v823_12_head);
      Space v825_7_result;
      for (int v825_7_label = 1; v825_7_label <= 2; ++v825_7_label) {
        const Space v825_7_tail = child(v823_12_tail,v825_7_label);
        if (v825_7_tail.empty()) continue;
        const Path v825_7_head{v825_7_label};
        const Space v826_2 = singleton(v825_7_head);
        const Space v826_3 = intersect(constant_14,v826_2);
        const Space v826_4 = (has_head(v826_3) ? constant_15 : Space{});
        const Space v826_5 = subtract(constant_0,v826_4);
        Space v826_8;
        if (!v826_5.empty()) {
          const Path v827_6 = concat_path(v825_6,v825_7_head);
          const Space v827_7 = routine_124(c, v827_6, p1, v825_7_tail);
          v826_8 = compose(v826_5,v827_7);
        }
        const Space v826_9 = intersect(constant_14,v826_2);
        const Space v826_10 = (has_head(v826_9) ? constant_15 : Space{});
        Space v826_12;
        if (!v826_10.empty()) {
          const Path v828_6 = concat_path(v825_6,v825_7_head);
          const Space v828_11 = routine_125(c, v828_6, p1, v825_7_tail);
          v826_12 = compose(v826_10,v828_11);
        }
        const Space v826_13 = unite(v826_8,v826_12);
        v825_7_result = unite(v825_7_result,v826_13);
      }
      const Space v825_7 = std::move(v825_7_result);
      v824_8 = compose(v824_5,v825_7);
    }
    const Space v824_9 = intersect(constant_14,v824_2);
    const Space v824_10 = (has_head(v824_9) ? constant_15 : Space{});
    Space v824_12;
    if (!v824_10.empty()) {
      const Path v829_6 = concat_path(p0,v823_12_head);
      Space v829_11_result;
      for (int v829_11_label = 1; v829_11_label <= 2; ++v829_11_label) {
        const Space v829_11_tail = child(v823_12_tail,v829_11_label);
        if (v829_11_tail.empty()) continue;
        const Path v829_11_head{v829_11_label};
        const Space v830_2 = singleton(v829_11_head);
        const Space v830_3 = intersect(constant_14,v830_2);
        const Space v830_4 = (has_head(v830_3) ? constant_15 : Space{});
        const Space v830_5 = subtract(constant_0,v830_4);
        Space v830_8;
        if (!v830_5.empty()) {
          const Path v831_6 = concat_path(v829_6,v829_11_head);
          const Space v831_7 = routine_124(c, v831_6, p1, v829_11_tail);
          v830_8 = compose(v830_5,v831_7);
        }
        const Space v830_9 = intersect(constant_14,v830_2);
        const Space v830_10 = (has_head(v830_9) ? constant_15 : Space{});
        Space v830_12;
        if (!v830_10.empty()) {
          const Path v832_6 = concat_path(v829_6,v829_11_head);
          const Space v832_11 = routine_93(c, v832_6, p1, v829_11_tail);
          v830_12 = compose(v830_10,v832_11);
        }
        const Space v830_13 = unite(v830_8,v830_12);
        v829_11_result = unite(v829_11_result,v830_13);
      }
      const Space v829_11 = std::move(v829_11_result);
      v824_12 = compose(v824_10,v829_11);
    }
    const Space v824_13 = unite(v824_8,v824_12);
    v823_12_result = unite(v823_12_result,v824_13);
  }
  const Space v823_12 = std::move(v823_12_result);
  return v823_12;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v833_9_result;
  for (int v833_9_label = 1; v833_9_label <= 2; ++v833_9_label) {
    const Space v833_9_tail = child(s0,v833_9_label);
    if (v833_9_tail.empty()) continue;
    const Path v833_9_head{v833_9_label};
    const Space v834_2 = singleton(v833_9_head);
    const Space v834_3 = intersect(constant_14,v834_2);
    const Space v834_4 = (has_head(v834_3) ? constant_15 : Space{});
    const Space v834_5 = subtract(constant_0,v834_4);
    Space v834_8;
    if (!v834_5.empty()) {
      const Path v835_6 = concat_path(p0,v833_9_head);
      Space v835_7_result;
      for (int v835_7_label = 1; v835_7_label <= 2; ++v835_7_label) {
        const Space v835_7_tail = child(v833_9_tail,v835_7_label);
        if (v835_7_tail.empty()) continue;
        const Path v835_7_head{v835_7_label};
        const Space v836_2 = singleton(v835_7_head);
        const Space v836_3 = intersect(constant_14,v836_2);
        const Space v836_4 = (has_head(v836_3) ? constant_15 : Space{});
        const Space v836_5 = subtract(constant_0,v836_4);
        Space v836_8;
        if (!v836_5.empty()) {
          const Path v837_6 = concat_path(v835_6,v835_7_head);
          const Space v837_7 = routine_124(c, v837_6, p1, v835_7_tail);
          v836_8 = compose(v836_5,v837_7);
        }
        const Space v836_9 = intersect(constant_14,v836_2);
        const Space v836_10 = (has_head(v836_9) ? constant_15 : Space{});
        Space v836_12;
        if (!v836_10.empty()) {
          const Path v838_6 = concat_path(v835_6,v835_7_head);
          const Space v838_11 = routine_125(c, v838_6, p1, v835_7_tail);
          v836_12 = compose(v836_10,v838_11);
        }
        const Space v836_13 = unite(v836_8,v836_12);
        v835_7_result = unite(v835_7_result,v836_13);
      }
      const Space v835_7 = std::move(v835_7_result);
      v834_8 = compose(v834_5,v835_7);
    }
    const Space v834_9 = intersect(constant_14,v834_2);
    const Space v834_10 = (has_head(v834_9) ? constant_15 : Space{});
    const Space v834_11 = compose(v834_10,v833_9_tail);
    const Path v839_6 = concat_path(p0,v833_9_head);
    const Space v834_12 = wrap(v834_11,v839_6);
    const Space v834_13 = wrap(v834_12,p1);
    const Space v834_14 = unite(v834_8,v834_13);
    v833_9_result = unite(v833_9_result,v834_14);
  }
  const Space v833_9 = std::move(v833_9_result);
  return v833_9;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v840_3 = wrap(s0,p0);
  const Space v840_4 = wrap(v840_3,p1);
  return v840_4;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v841_12_result;
  for (int v841_12_label = 1; v841_12_label <= 2; ++v841_12_label) {
    const Space v841_12_tail = child(s0,v841_12_label);
    if (v841_12_tail.empty()) continue;
    const Path v841_12_head{v841_12_label};
    const Space v842_2 = singleton(v841_12_head);
    const Space v842_3 = intersect(constant_14,v842_2);
    const Space v842_4 = (has_head(v842_3) ? constant_15 : Space{});
    const Space v842_5 = subtract(constant_0,v842_4);
    Space v842_8;
    if (!v842_5.empty()) {
      const Path v843_6 = concat_path(p0,v841_12_head);
      Space v843_7_result;
      for (int v843_7_label = 1; v843_7_label <= 2; ++v843_7_label) {
        const Space v843_7_tail = child(v841_12_tail,v843_7_label);
        if (v843_7_tail.empty()) continue;
        const Path v843_7_head{v843_7_label};
        const Space v844_2 = singleton(v843_7_head);
        const Space v844_3 = intersect(constant_14,v844_2);
        const Space v844_4 = (has_head(v844_3) ? constant_15 : Space{});
        const Space v844_5 = subtract(constant_0,v844_4);
        Space v844_8;
        if (!v844_5.empty()) {
          const Path v845_6 = concat_path(v843_6,v843_7_head);
          const Space v845_7 = routine_126(c, v845_6, p1, v843_7_tail);
          v844_8 = compose(v844_5,v845_7);
        }
        const Space v844_9 = intersect(constant_14,v844_2);
        const Space v844_10 = (has_head(v844_9) ? constant_15 : Space{});
        Space v844_12;
        if (!v844_10.empty()) {
          const Path v846_6 = concat_path(v843_6,v843_7_head);
          const Space v846_11 = routine_127(c, v846_6, p1, v843_7_tail);
          v844_12 = compose(v844_10,v846_11);
        }
        const Space v844_13 = unite(v844_8,v844_12);
        v843_7_result = unite(v843_7_result,v844_13);
      }
      const Space v843_7 = std::move(v843_7_result);
      v842_8 = compose(v842_5,v843_7);
    }
    const Space v842_9 = intersect(constant_14,v842_2);
    const Space v842_10 = (has_head(v842_9) ? constant_15 : Space{});
    Space v842_12;
    if (!v842_10.empty()) {
      const Path v847_6 = concat_path(p0,v841_12_head);
      Space v847_11_result;
      for (int v847_11_label = 1; v847_11_label <= 2; ++v847_11_label) {
        const Space v847_11_tail = child(v841_12_tail,v847_11_label);
        if (v847_11_tail.empty()) continue;
        const Path v847_11_head{v847_11_label};
        const Space v848_2 = singleton(v847_11_head);
        const Space v848_3 = intersect(constant_14,v848_2);
        const Space v848_4 = (has_head(v848_3) ? constant_15 : Space{});
        const Space v848_5 = subtract(constant_0,v848_4);
        Space v848_8;
        if (!v848_5.empty()) {
          const Path v849_6 = concat_path(v847_6,v847_11_head);
          const Space v849_7 = routine_126(c, v849_6, p1, v847_11_tail);
          v848_8 = compose(v848_5,v849_7);
        }
        const Space v848_9 = intersect(constant_14,v848_2);
        const Space v848_10 = (has_head(v848_9) ? constant_15 : Space{});
        Space v848_12;
        if (!v848_10.empty()) {
          const Path v850_6 = concat_path(v847_6,v847_11_head);
          const Space v850_11 = routine_52(c, v850_6, p1, v847_11_tail);
          v848_12 = compose(v848_10,v850_11);
        }
        const Space v848_13 = unite(v848_8,v848_12);
        v847_11_result = unite(v847_11_result,v848_13);
      }
      const Space v847_11 = std::move(v847_11_result);
      v842_12 = compose(v842_10,v847_11);
    }
    const Space v842_13 = unite(v842_8,v842_12);
    v841_12_result = unite(v841_12_result,v842_13);
  }
  const Space v841_12 = std::move(v841_12_result);
  return v841_12;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v851_10_result;
  for (int v851_10_label = 1; v851_10_label <= 2; ++v851_10_label) {
    const Space v851_10_tail = child(s0,v851_10_label);
    if (v851_10_tail.empty()) continue;
    const Path v851_10_head{v851_10_label};
    const Space v852_2 = singleton(v851_10_head);
    const Space v852_3 = intersect(constant_14,v852_2);
    const Space v852_4 = (has_head(v852_3) ? constant_15 : Space{});
    const Space v852_5 = compose(v852_4,v851_10_tail);
    const Path v853_6 = concat_path(p0,v851_10_head);
    const Space v852_7 = wrap(v852_5,v853_6);
    const Space v852_8 = wrap(v852_7,p1);
    const Space v852_9 = wrap(v852_8,constant_10);
    const Space v852_10 = intersect(constant_14,v852_2);
    const Space v852_11 = (has_head(v852_10) ? constant_15 : Space{});
    const Space v852_12 = subtract(constant_0,v852_11);
    Space v852_14;
    if (!v852_12.empty()) {
      Space v854_13_result;
      for (int v854_13_label = 1; v854_13_label <= 2; ++v854_13_label) {
        const Space v854_13_tail = child(v851_10_tail,v854_13_label);
        if (v854_13_tail.empty()) continue;
        const Path v854_13_head{v854_13_label};
        const Space v855_2 = singleton(v854_13_head);
        const Space v855_3 = intersect(constant_14,v855_2);
        const Space v855_4 = (has_head(v855_3) ? constant_15 : Space{});
        const Space v855_5 = subtract(constant_0,v855_4);
        Space v855_8;
        if (!v855_5.empty()) {
          const Path v856_6 = concat_path(v853_6,v854_13_head);
          const Space v856_7 = routine_126(c, v856_6, p1, v854_13_tail);
          v855_8 = compose(v855_5,v856_7);
        }
        const Space v855_9 = intersect(constant_14,v855_2);
        const Space v855_10 = (has_head(v855_9) ? constant_15 : Space{});
        Space v855_12;
        if (!v855_10.empty()) {
          const Path v857_6 = concat_path(v853_6,v854_13_head);
          const Space v857_11 = routine_127(c, v857_6, p1, v854_13_tail);
          v855_12 = compose(v855_10,v857_11);
        }
        const Space v855_13 = unite(v855_8,v855_12);
        v854_13_result = unite(v854_13_result,v855_13);
      }
      const Space v854_13 = std::move(v854_13_result);
      v852_14 = compose(v852_12,v854_13);
    }
    const Space v852_15 = unite(v852_9,v852_14);
    v851_10_result = unite(v851_10_result,v852_15);
  }
  const Space v851_10 = std::move(v851_10_result);
  return v851_10;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v858_12_result;
  for (int v858_12_label = 1; v858_12_label <= 2; ++v858_12_label) {
    const Space v858_12_tail = child(s0,v858_12_label);
    if (v858_12_tail.empty()) continue;
    const Path v858_12_head{v858_12_label};
    const Space v859_2 = singleton(v858_12_head);
    const Space v859_3 = intersect(constant_14,v859_2);
    const Space v859_4 = (has_head(v859_3) ? constant_15 : Space{});
    const Space v859_5 = subtract(constant_0,v859_4);
    Space v859_8;
    if (!v859_5.empty()) {
      const Path v860_6 = concat_path(p0,v858_12_head);
      Space v860_7_result;
      for (int v860_7_label = 1; v860_7_label <= 2; ++v860_7_label) {
        const Space v860_7_tail = child(v858_12_tail,v860_7_label);
        if (v860_7_tail.empty()) continue;
        const Path v860_7_head{v860_7_label};
        const Space v861_2 = singleton(v860_7_head);
        const Space v861_3 = intersect(constant_14,v861_2);
        const Space v861_4 = (has_head(v861_3) ? constant_15 : Space{});
        const Space v861_5 = subtract(constant_0,v861_4);
        Space v861_8;
        if (!v861_5.empty()) {
          const Path v862_6 = concat_path(v860_6,v860_7_head);
          const Space v862_7 = routine_128(c, v862_6, p1, v860_7_tail);
          v861_8 = compose(v861_5,v862_7);
        }
        const Space v861_9 = intersect(constant_14,v861_2);
        const Space v861_10 = (has_head(v861_9) ? constant_15 : Space{});
        Space v861_12;
        if (!v861_10.empty()) {
          const Path v863_6 = concat_path(v860_6,v860_7_head);
          const Space v863_11 = routine_129(c, v863_6, p1, v860_7_tail);
          v861_12 = compose(v861_10,v863_11);
        }
        const Space v861_13 = unite(v861_8,v861_12);
        v860_7_result = unite(v860_7_result,v861_13);
      }
      const Space v860_7 = std::move(v860_7_result);
      v859_8 = compose(v859_5,v860_7);
    }
    const Space v859_9 = intersect(constant_14,v859_2);
    const Space v859_10 = (has_head(v859_9) ? constant_15 : Space{});
    Space v859_12;
    if (!v859_10.empty()) {
      const Path v864_6 = concat_path(p0,v858_12_head);
      Space v864_11_result;
      for (int v864_11_label = 1; v864_11_label <= 2; ++v864_11_label) {
        const Space v864_11_tail = child(v858_12_tail,v864_11_label);
        if (v864_11_tail.empty()) continue;
        const Path v864_11_head{v864_11_label};
        const Space v865_2 = singleton(v864_11_head);
        const Space v865_3 = intersect(constant_14,v865_2);
        const Space v865_4 = (has_head(v865_3) ? constant_15 : Space{});
        const Space v865_5 = subtract(constant_0,v865_4);
        Space v865_8;
        if (!v865_5.empty()) {
          const Path v866_6 = concat_path(v864_6,v864_11_head);
          const Space v866_7 = routine_128(c, v866_6, p1, v864_11_tail);
          v865_8 = compose(v865_5,v866_7);
        }
        const Space v865_9 = intersect(constant_14,v865_2);
        const Space v865_10 = (has_head(v865_9) ? constant_15 : Space{});
        Space v865_12;
        if (!v865_10.empty()) {
          const Path v867_6 = concat_path(v864_6,v864_11_head);
          const Space v867_11 = routine_52(c, v867_6, p1, v864_11_tail);
          v865_12 = compose(v865_10,v867_11);
        }
        const Space v865_13 = unite(v865_8,v865_12);
        v864_11_result = unite(v864_11_result,v865_13);
      }
      const Space v864_11 = std::move(v864_11_result);
      v859_12 = compose(v859_10,v864_11);
    }
    const Space v859_13 = unite(v859_8,v859_12);
    v858_12_result = unite(v858_12_result,v859_13);
  }
  const Space v858_12 = std::move(v858_12_result);
  return v858_12;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v868_10_result;
  for (int v868_10_label = 1; v868_10_label <= 2; ++v868_10_label) {
    const Space v868_10_tail = child(s0,v868_10_label);
    if (v868_10_tail.empty()) continue;
    const Path v868_10_head{v868_10_label};
    const Space v869_2 = singleton(v868_10_head);
    const Space v869_3 = intersect(constant_14,v869_2);
    const Space v869_4 = (has_head(v869_3) ? constant_15 : Space{});
    const Space v869_5 = compose(v869_4,v868_10_tail);
    const Path v870_6 = concat_path(p0,v868_10_head);
    const Space v869_7 = wrap(v869_5,v870_6);
    const Space v869_8 = wrap(v869_7,p1);
    const Space v869_9 = wrap(v869_8,constant_10);
    const Space v869_10 = intersect(constant_14,v869_2);
    const Space v869_11 = (has_head(v869_10) ? constant_15 : Space{});
    const Space v869_12 = subtract(constant_0,v869_11);
    Space v869_14;
    if (!v869_12.empty()) {
      Space v871_13_result;
      for (int v871_13_label = 1; v871_13_label <= 2; ++v871_13_label) {
        const Space v871_13_tail = child(v868_10_tail,v871_13_label);
        if (v871_13_tail.empty()) continue;
        const Path v871_13_head{v871_13_label};
        const Space v872_2 = singleton(v871_13_head);
        const Space v872_3 = intersect(constant_14,v872_2);
        const Space v872_4 = (has_head(v872_3) ? constant_15 : Space{});
        const Space v872_5 = subtract(constant_0,v872_4);
        Space v872_8;
        if (!v872_5.empty()) {
          const Path v873_6 = concat_path(v870_6,v871_13_head);
          const Space v873_7 = routine_128(c, v873_6, p1, v871_13_tail);
          v872_8 = compose(v872_5,v873_7);
        }
        const Space v872_9 = intersect(constant_14,v872_2);
        const Space v872_10 = (has_head(v872_9) ? constant_15 : Space{});
        Space v872_12;
        if (!v872_10.empty()) {
          const Path v874_6 = concat_path(v870_6,v871_13_head);
          const Space v874_11 = routine_129(c, v874_6, p1, v871_13_tail);
          v872_12 = compose(v872_10,v874_11);
        }
        const Space v872_13 = unite(v872_8,v872_12);
        v871_13_result = unite(v871_13_result,v872_13);
      }
      const Space v871_13 = std::move(v871_13_result);
      v869_14 = compose(v869_12,v871_13);
    }
    const Space v869_15 = unite(v869_9,v869_14);
    v868_10_result = unite(v868_10_result,v869_15);
  }
  const Space v868_10 = std::move(v868_10_result);
  return v868_10;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v875_13_result;
  for (int v875_13_label = 1; v875_13_label <= 2; ++v875_13_label) {
    const Space v875_13_tail = child(s0,v875_13_label);
    if (v875_13_tail.empty()) continue;
    const Path v875_13_head{v875_13_label};
    const Space v876_2 = singleton(v875_13_head);
    const Space v876_3 = intersect(constant_14,v876_2);
    const Space v876_4 = (has_head(v876_3) ? constant_15 : Space{});
    const Space v876_5 = subtract(constant_0,v876_4);
    Space v876_8;
    if (!v876_5.empty()) {
      const Path v877_6 = concat_path(p0,v875_13_head);
      Space v877_7_result;
      for (int v877_7_label = 1; v877_7_label <= 2; ++v877_7_label) {
        const Space v877_7_tail = child(v875_13_tail,v877_7_label);
        if (v877_7_tail.empty()) continue;
        const Path v877_7_head{v877_7_label};
        const Space v878_2 = singleton(v877_7_head);
        const Space v878_3 = intersect(constant_14,v878_2);
        const Space v878_4 = (has_head(v878_3) ? constant_15 : Space{});
        const Space v878_5 = subtract(constant_0,v878_4);
        Space v878_8;
        if (!v878_5.empty()) {
          const Path v879_6 = concat_path(v877_6,v877_7_head);
          const Space v879_7 = routine_130(c, v879_6, p1, v877_7_tail, s1);
          v878_8 = compose(v878_5,v879_7);
        }
        const Space v878_9 = intersect(constant_14,v878_2);
        const Space v878_10 = (has_head(v878_9) ? constant_15 : Space{});
        Space v878_12;
        if (!v878_10.empty()) {
          const Path v880_6 = concat_path(v877_6,v877_7_head);
          const Space v880_11 = routine_131(c, v880_6, p1, v877_7_tail, s1);
          v878_12 = compose(v878_10,v880_11);
        }
        const Space v878_13 = unite(v878_8,v878_12);
        v877_7_result = unite(v877_7_result,v878_13);
      }
      const Space v877_7 = std::move(v877_7_result);
      v876_8 = compose(v876_5,v877_7);
    }
    const Space v876_9 = intersect(constant_14,v876_2);
    const Space v876_10 = (has_head(v876_9) ? constant_15 : Space{});
    Space v876_12;
    if (!v876_10.empty()) {
      const Path v881_6 = concat_path(p0,v875_13_head);
      Space v881_11_result;
      for (int v881_11_label = 1; v881_11_label <= 2; ++v881_11_label) {
        const Space v881_11_tail = child(v875_13_tail,v881_11_label);
        if (v881_11_tail.empty()) continue;
        const Path v881_11_head{v881_11_label};
        const Space v882_2 = singleton(v881_11_head);
        const Space v882_3 = intersect(constant_14,v882_2);
        const Space v882_4 = (has_head(v882_3) ? constant_15 : Space{});
        const Space v882_5 = subtract(constant_0,v882_4);
        Space v882_8;
        if (!v882_5.empty()) {
          const Path v883_6 = concat_path(v881_6,v881_11_head);
          const Space v883_7 = routine_130(c, v883_6, p1, v881_11_tail, s1);
          v882_8 = compose(v882_5,v883_7);
        }
        const Space v882_9 = intersect(constant_14,v882_2);
        const Space v882_10 = (has_head(v882_9) ? constant_15 : Space{});
        Space v882_12;
        if (!v882_10.empty()) {
          const Path v884_6 = concat_path(v881_6,v881_11_head);
          const Space v884_11 = routine_26(c, v884_6, p1, v881_11_tail, s1);
          v882_12 = compose(v882_10,v884_11);
        }
        const Space v882_13 = unite(v882_8,v882_12);
        v881_11_result = unite(v881_11_result,v882_13);
      }
      const Space v881_11 = std::move(v881_11_result);
      v876_12 = compose(v876_10,v881_11);
    }
    const Space v876_13 = unite(v876_8,v876_12);
    v875_13_result = unite(v875_13_result,v876_13);
  }
  const Space v875_13 = std::move(v875_13_result);
  return v875_13;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v885_8 = unwrap(s1,constant_7);
  const Space v885_10 = unwrap(v885_8,constant_10);
  const Space v885_11 = unwrap(v885_10,p0);
  Space v885_18_result;
  for (int v885_18_label = 1; v885_18_label <= 2; ++v885_18_label) {
    const Space v885_18_tail = child(s0,v885_18_label);
    if (v885_18_tail.empty()) continue;
    const Path v885_18_head{v885_18_label};
    const Space v886_2 = singleton(v885_18_head);
    const Space v886_3 = intersect(constant_14,v886_2);
    const Space v886_4 = (has_head(v886_3) ? constant_15 : Space{});
    const Space v886_5 = subtract(constant_0,v886_4);
    Space v886_8;
    if (!v886_5.empty()) {
      const Path v887_6 = concat_path(p0,v885_18_head);
      Space v887_7_result;
      for (int v887_7_label = 1; v887_7_label <= 2; ++v887_7_label) {
        const Space v887_7_tail = child(v885_18_tail,v887_7_label);
        if (v887_7_tail.empty()) continue;
        const Path v887_7_head{v887_7_label};
        const Space v888_2 = singleton(v887_7_head);
        const Space v888_3 = intersect(constant_14,v888_2);
        const Space v888_4 = (has_head(v888_3) ? constant_15 : Space{});
        const Space v888_5 = subtract(constant_0,v888_4);
        Space v888_8;
        if (!v888_5.empty()) {
          const Path v889_6 = concat_path(v887_6,v887_7_head);
          const Space v889_7 = routine_130(c, v889_6, p1, v887_7_tail, s1);
          v888_8 = compose(v888_5,v889_7);
        }
        const Space v888_9 = intersect(constant_14,v888_2);
        const Space v888_10 = (has_head(v888_9) ? constant_15 : Space{});
        Space v888_12;
        if (!v888_10.empty()) {
          const Path v890_6 = concat_path(v887_6,v887_7_head);
          const Space v890_11 = routine_131(c, v890_6, p1, v887_7_tail, s1);
          v888_12 = compose(v888_10,v890_11);
        }
        const Space v888_13 = unite(v888_8,v888_12);
        v887_7_result = unite(v887_7_result,v888_13);
      }
      const Space v887_7 = std::move(v887_7_result);
      v886_8 = compose(v886_5,v887_7);
    }
    const Space v886_9 = intersect(constant_14,v886_2);
    const Space v886_10 = (has_head(v886_9) ? constant_15 : Space{});
    Space v886_13;
    if (!v886_10.empty()) {
      const Space v891_11 = unwrap(v885_11,v885_18_head);
      Space v891_12_result;
      for (int v891_12_label = 1; v891_12_label <= 2; ++v891_12_label) {
        const Space v891_12_tail = child(v891_11,v891_12_label);
        if (v891_12_tail.empty()) continue;
        const Path v891_12_head{v891_12_label};
        const Space v892_2 = singleton(v891_12_head);
        const Space v892_3 = intersect(constant_14,v892_2);
        const Space v892_4 = (has_head(v892_3) ? constant_15 : Space{});
        const Space v892_5 = subtract(constant_0,v892_4);
        Space v892_7;
        if (!v892_5.empty()) {
          const Space v893_6 = routine_59(c, v891_12_head, p1, v891_12_tail);
          v892_7 = compose(v892_5,v893_6);
        }
        const Space v892_8 = intersect(constant_14,v892_2);
        const Space v892_9 = (has_head(v892_8) ? constant_15 : Space{});
        Space v892_11;
        if (!v892_9.empty()) {
          const Space v894_10 = routine_60(c, v891_12_head, p1, v891_12_tail);
          v892_11 = compose(v892_9,v894_10);
        }
        const Space v892_12 = unite(v892_7,v892_11);
        v891_12_result = unite(v891_12_result,v892_12);
      }
      const Space v891_12 = std::move(v891_12_result);
      v886_13 = compose(v886_10,v891_12);
    }
    const Space v886_14 = unite(v886_8,v886_13);
    v885_18_result = unite(v885_18_result,v886_14);
  }
  const Space v885_18 = std::move(v885_18_result);
  return v885_18;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v895_12_result;
  for (int v895_12_label = 1; v895_12_label <= 2; ++v895_12_label) {
    const Space v895_12_tail = child(s0,v895_12_label);
    if (v895_12_tail.empty()) continue;
    const Path v895_12_head{v895_12_label};
    const Space v896_2 = singleton(v895_12_head);
    const Space v896_3 = intersect(constant_14,v896_2);
    const Space v896_4 = (has_head(v896_3) ? constant_15 : Space{});
    const Space v896_5 = subtract(constant_0,v896_4);
    Space v896_8;
    if (!v896_5.empty()) {
      const Path v897_6 = concat_path(p0,v895_12_head);
      Space v897_7_result;
      for (int v897_7_label = 1; v897_7_label <= 2; ++v897_7_label) {
        const Space v897_7_tail = child(v895_12_tail,v897_7_label);
        if (v897_7_tail.empty()) continue;
        const Path v897_7_head{v897_7_label};
        const Space v898_2 = singleton(v897_7_head);
        const Space v898_3 = intersect(constant_14,v898_2);
        const Space v898_4 = (has_head(v898_3) ? constant_15 : Space{});
        const Space v898_5 = subtract(constant_0,v898_4);
        Space v898_8;
        if (!v898_5.empty()) {
          const Path v899_6 = concat_path(v897_6,v897_7_head);
          const Space v899_7 = routine_132(c, v899_6, p1, v897_7_tail);
          v898_8 = compose(v898_5,v899_7);
        }
        const Space v898_9 = intersect(constant_14,v898_2);
        const Space v898_10 = (has_head(v898_9) ? constant_15 : Space{});
        Space v898_12;
        if (!v898_10.empty()) {
          const Path v900_6 = concat_path(v897_6,v897_7_head);
          const Space v900_11 = routine_133(c, v900_6, p1, v897_7_tail);
          v898_12 = compose(v898_10,v900_11);
        }
        const Space v898_13 = unite(v898_8,v898_12);
        v897_7_result = unite(v897_7_result,v898_13);
      }
      const Space v897_7 = std::move(v897_7_result);
      v896_8 = compose(v896_5,v897_7);
    }
    const Space v896_9 = intersect(constant_14,v896_2);
    const Space v896_10 = (has_head(v896_9) ? constant_15 : Space{});
    Space v896_12;
    if (!v896_10.empty()) {
      const Path v901_6 = concat_path(p0,v895_12_head);
      Space v901_11_result;
      for (int v901_11_label = 1; v901_11_label <= 2; ++v901_11_label) {
        const Space v901_11_tail = child(v895_12_tail,v901_11_label);
        if (v901_11_tail.empty()) continue;
        const Path v901_11_head{v901_11_label};
        const Space v902_2 = singleton(v901_11_head);
        const Space v902_3 = intersect(constant_14,v902_2);
        const Space v902_4 = (has_head(v902_3) ? constant_15 : Space{});
        const Space v902_5 = subtract(constant_0,v902_4);
        Space v902_8;
        if (!v902_5.empty()) {
          const Path v903_6 = concat_path(v901_6,v901_11_head);
          const Space v903_7 = routine_132(c, v903_6, p1, v901_11_tail);
          v902_8 = compose(v902_5,v903_7);
        }
        const Space v902_9 = intersect(constant_14,v902_2);
        const Space v902_10 = (has_head(v902_9) ? constant_15 : Space{});
        Space v902_12;
        if (!v902_10.empty()) {
          const Path v904_6 = concat_path(v901_6,v901_11_head);
          const Space v904_11 = routine_65(c, v904_6, p1, v901_11_tail);
          v902_12 = compose(v902_10,v904_11);
        }
        const Space v902_13 = unite(v902_8,v902_12);
        v901_11_result = unite(v901_11_result,v902_13);
      }
      const Space v901_11 = std::move(v901_11_result);
      v896_12 = compose(v896_10,v901_11);
    }
    const Space v896_13 = unite(v896_8,v896_12);
    v895_12_result = unite(v895_12_result,v896_13);
  }
  const Space v895_12 = std::move(v895_12_result);
  return v895_12;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v905_9_result;
  for (int v905_9_label = 1; v905_9_label <= 2; ++v905_9_label) {
    const Space v905_9_tail = child(s0,v905_9_label);
    if (v905_9_tail.empty()) continue;
    const Path v905_9_head{v905_9_label};
    const Space v906_2 = singleton(v905_9_head);
    const Space v906_3 = intersect(constant_14,v906_2);
    const Space v906_4 = (has_head(v906_3) ? constant_15 : Space{});
    const Space v906_5 = subtract(constant_0,v906_4);
    Space v906_8;
    if (!v906_5.empty()) {
      const Path v907_6 = concat_path(p0,v905_9_head);
      Space v907_7_result;
      for (int v907_7_label = 1; v907_7_label <= 2; ++v907_7_label) {
        const Space v907_7_tail = child(v905_9_tail,v907_7_label);
        if (v907_7_tail.empty()) continue;
        const Path v907_7_head{v907_7_label};
        const Space v908_2 = singleton(v907_7_head);
        const Space v908_3 = intersect(constant_14,v908_2);
        const Space v908_4 = (has_head(v908_3) ? constant_15 : Space{});
        const Space v908_5 = subtract(constant_0,v908_4);
        Space v908_8;
        if (!v908_5.empty()) {
          const Path v909_6 = concat_path(v907_6,v907_7_head);
          const Space v909_7 = routine_132(c, v909_6, p1, v907_7_tail);
          v908_8 = compose(v908_5,v909_7);
        }
        const Space v908_9 = intersect(constant_14,v908_2);
        const Space v908_10 = (has_head(v908_9) ? constant_15 : Space{});
        Space v908_12;
        if (!v908_10.empty()) {
          const Path v910_6 = concat_path(v907_6,v907_7_head);
          const Space v910_11 = routine_133(c, v910_6, p1, v907_7_tail);
          v908_12 = compose(v908_10,v910_11);
        }
        const Space v908_13 = unite(v908_8,v908_12);
        v907_7_result = unite(v907_7_result,v908_13);
      }
      const Space v907_7 = std::move(v907_7_result);
      v906_8 = compose(v906_5,v907_7);
    }
    const Space v906_9 = intersect(constant_14,v906_2);
    const Space v906_10 = (has_head(v906_9) ? constant_15 : Space{});
    const Space v906_11 = compose(v906_10,v905_9_tail);
    const Path v911_6 = concat_path(p0,v905_9_head);
    const Space v906_12 = wrap(v906_11,v911_6);
    const Space v906_13 = wrap(v906_12,p1);
    const Space v906_14 = unite(v906_8,v906_13);
    v905_9_result = unite(v905_9_result,v906_14);
  }
  const Space v905_9 = std::move(v905_9_result);
  return v905_9;
}

static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v912_6_result;
  for (int v912_6_label = 1; v912_6_label <= 2; ++v912_6_label) {
    const Space v912_6_tail = child(s0,v912_6_label);
    if (v912_6_tail.empty()) continue;
    const Path v912_6_head{v912_6_label};
    const Space v913_2 = singleton(v912_6_head);
    const Space v913_3 = intersect(constant_14,v913_2);
    const Space v913_4 = (has_head(v913_3) ? constant_15 : Space{});
    Space v913_7;
    if (!v913_4.empty()) {
      const Path v914_5 = concat_path(p0,v912_6_head);
      Space v914_6_result;
      for (int v914_6_label = 1; v914_6_label <= 2; ++v914_6_label) {
        const Space v914_6_tail = child(v912_6_tail,v914_6_label);
        if (v914_6_tail.empty()) continue;
        const Path v914_6_head{v914_6_label};
        const Space v915_2 = singleton(v914_6_head);
        const Space v915_3 = intersect(constant_14,v915_2);
        const Space v915_4 = (has_head(v915_3) ? constant_15 : Space{});
        Space v915_7;
        if (!v915_4.empty()) {
          const Path v916_5 = concat_path(v914_5,v914_6_head);
          const Space v916_6 = routine_26(c, v916_5, p1, v914_6_tail, s1);
          v915_7 = compose(v915_4,v916_6);
        }
        v914_6_result = unite(v914_6_result,v915_7);
      }
      const Space v914_6 = std::move(v914_6_result);
      v913_7 = compose(v913_4,v914_6);
    }
    v912_6_result = unite(v912_6_result,v913_7);
  }
  const Space v912_6 = std::move(v912_6_result);
  return v912_6;
}

static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v917_6 = unwrap(s1,constant_7);
  const Space v917_8 = unwrap(v917_6,constant_10);
  const Space v917_9 = unwrap(v917_8,p0);
  Space v917_13_result;
  for (int v917_13_label = 1; v917_13_label <= 2; ++v917_13_label) {
    const Space v917_13_tail = child(s0,v917_13_label);
    if (v917_13_tail.empty()) continue;
    const Path v917_13_head{v917_13_label};
    const Space v918_2 = singleton(v917_13_head);
    const Space v918_3 = intersect(constant_14,v918_2);
    const Space v918_4 = (has_head(v918_3) ? constant_15 : Space{});
    Space v918_7;
    if (!v918_4.empty()) {
      const Space v919_5 = unwrap(v917_9,v917_13_head);
      Space v919_6_result;
      for (int v919_6_label = 1; v919_6_label <= 2; ++v919_6_label) {
        const Space v919_6_tail = child(v919_5,v919_6_label);
        if (v919_6_tail.empty()) continue;
        const Path v919_6_head{v919_6_label};
        const Space v920_2 = singleton(v919_6_head);
        const Space v920_3 = intersect(constant_14,v920_2);
        const Space v920_4 = (has_head(v920_3) ? constant_15 : Space{});
        const Space v920_5 = subtract(constant_0,v920_4);
        Space v920_7;
        if (!v920_5.empty()) {
          const Space v921_6 = routine_59(c, v919_6_head, p1, v919_6_tail);
          v920_7 = compose(v920_5,v921_6);
        }
        const Space v920_8 = intersect(constant_14,v920_2);
        const Space v920_9 = (has_head(v920_8) ? constant_15 : Space{});
        Space v920_11;
        if (!v920_9.empty()) {
          const Space v922_10 = routine_60(c, v919_6_head, p1, v919_6_tail);
          v920_11 = compose(v920_9,v922_10);
        }
        const Space v920_12 = unite(v920_7,v920_11);
        v919_6_result = unite(v919_6_result,v920_12);
      }
      const Space v919_6 = std::move(v919_6_result);
      v918_7 = compose(v918_4,v919_6);
    }
    v917_13_result = unite(v917_13_result,v918_7);
  }
  const Space v917_13 = std::move(v917_13_result);
  return v917_13;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v923_12_result;
  for (int v923_12_label = 1; v923_12_label <= 2; ++v923_12_label) {
    const Space v923_12_tail = child(s0,v923_12_label);
    if (v923_12_tail.empty()) continue;
    const Path v923_12_head{v923_12_label};
    const Space v924_2 = singleton(v923_12_head);
    const Space v924_3 = intersect(constant_14,v924_2);
    const Space v924_4 = (has_head(v924_3) ? constant_15 : Space{});
    const Space v924_5 = subtract(constant_0,v924_4);
    Space v924_8;
    if (!v924_5.empty()) {
      const Path v925_6 = concat_path(p0,v923_12_head);
      Space v925_7_result;
      for (int v925_7_label = 1; v925_7_label <= 2; ++v925_7_label) {
        const Space v925_7_tail = child(v923_12_tail,v925_7_label);
        if (v925_7_tail.empty()) continue;
        const Path v925_7_head{v925_7_label};
        const Space v926_2 = singleton(v925_7_head);
        const Space v926_3 = intersect(constant_14,v926_2);
        const Space v926_4 = (has_head(v926_3) ? constant_15 : Space{});
        const Space v926_5 = subtract(constant_0,v926_4);
        Space v926_8;
        if (!v926_5.empty()) {
          const Path v927_6 = concat_path(v925_6,v925_7_head);
          const Space v927_7 = routine_134(c, v927_6, p1, v925_7_tail);
          v926_8 = compose(v926_5,v927_7);
        }
        const Space v926_9 = intersect(constant_14,v926_2);
        const Space v926_10 = (has_head(v926_9) ? constant_15 : Space{});
        Space v926_12;
        if (!v926_10.empty()) {
          const Path v928_6 = concat_path(v925_6,v925_7_head);
          const Space v928_11 = routine_135(c, v928_6, p1, v925_7_tail);
          v926_12 = compose(v926_10,v928_11);
        }
        const Space v926_13 = unite(v926_8,v926_12);
        v925_7_result = unite(v925_7_result,v926_13);
      }
      const Space v925_7 = std::move(v925_7_result);
      v924_8 = compose(v924_5,v925_7);
    }
    const Space v924_9 = intersect(constant_14,v924_2);
    const Space v924_10 = (has_head(v924_9) ? constant_15 : Space{});
    Space v924_12;
    if (!v924_10.empty()) {
      const Path v929_6 = concat_path(p0,v923_12_head);
      Space v929_11_result;
      for (int v929_11_label = 1; v929_11_label <= 2; ++v929_11_label) {
        const Space v929_11_tail = child(v923_12_tail,v929_11_label);
        if (v929_11_tail.empty()) continue;
        const Path v929_11_head{v929_11_label};
        const Space v930_2 = singleton(v929_11_head);
        const Space v930_3 = intersect(constant_14,v930_2);
        const Space v930_4 = (has_head(v930_3) ? constant_15 : Space{});
        const Space v930_5 = subtract(constant_0,v930_4);
        Space v930_8;
        if (!v930_5.empty()) {
          const Path v931_6 = concat_path(v929_6,v929_11_head);
          const Space v931_7 = routine_134(c, v931_6, p1, v929_11_tail);
          v930_8 = compose(v930_5,v931_7);
        }
        const Space v930_9 = intersect(constant_14,v930_2);
        const Space v930_10 = (has_head(v930_9) ? constant_15 : Space{});
        Space v930_12;
        if (!v930_10.empty()) {
          const Path v932_6 = concat_path(v929_6,v929_11_head);
          const Space v932_11 = routine_65(c, v932_6, p1, v929_11_tail);
          v930_12 = compose(v930_10,v932_11);
        }
        const Space v930_13 = unite(v930_8,v930_12);
        v929_11_result = unite(v929_11_result,v930_13);
      }
      const Space v929_11 = std::move(v929_11_result);
      v924_12 = compose(v924_10,v929_11);
    }
    const Space v924_13 = unite(v924_8,v924_12);
    v923_12_result = unite(v923_12_result,v924_13);
  }
  const Space v923_12 = std::move(v923_12_result);
  return v923_12;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v933_9_result;
  for (int v933_9_label = 1; v933_9_label <= 2; ++v933_9_label) {
    const Space v933_9_tail = child(s0,v933_9_label);
    if (v933_9_tail.empty()) continue;
    const Path v933_9_head{v933_9_label};
    const Space v934_2 = singleton(v933_9_head);
    const Space v934_3 = intersect(constant_14,v934_2);
    const Space v934_4 = (has_head(v934_3) ? constant_15 : Space{});
    const Space v934_5 = subtract(constant_0,v934_4);
    Space v934_8;
    if (!v934_5.empty()) {
      const Path v935_6 = concat_path(p0,v933_9_head);
      Space v935_7_result;
      for (int v935_7_label = 1; v935_7_label <= 2; ++v935_7_label) {
        const Space v935_7_tail = child(v933_9_tail,v935_7_label);
        if (v935_7_tail.empty()) continue;
        const Path v935_7_head{v935_7_label};
        const Space v936_2 = singleton(v935_7_head);
        const Space v936_3 = intersect(constant_14,v936_2);
        const Space v936_4 = (has_head(v936_3) ? constant_15 : Space{});
        const Space v936_5 = subtract(constant_0,v936_4);
        Space v936_8;
        if (!v936_5.empty()) {
          const Path v937_6 = concat_path(v935_6,v935_7_head);
          const Space v937_7 = routine_134(c, v937_6, p1, v935_7_tail);
          v936_8 = compose(v936_5,v937_7);
        }
        const Space v936_9 = intersect(constant_14,v936_2);
        const Space v936_10 = (has_head(v936_9) ? constant_15 : Space{});
        Space v936_12;
        if (!v936_10.empty()) {
          const Path v938_6 = concat_path(v935_6,v935_7_head);
          const Space v938_11 = routine_135(c, v938_6, p1, v935_7_tail);
          v936_12 = compose(v936_10,v938_11);
        }
        const Space v936_13 = unite(v936_8,v936_12);
        v935_7_result = unite(v935_7_result,v936_13);
      }
      const Space v935_7 = std::move(v935_7_result);
      v934_8 = compose(v934_5,v935_7);
    }
    const Space v934_9 = intersect(constant_14,v934_2);
    const Space v934_10 = (has_head(v934_9) ? constant_15 : Space{});
    const Space v934_11 = compose(v934_10,v933_9_tail);
    const Path v939_6 = concat_path(p0,v933_9_head);
    const Space v934_12 = wrap(v934_11,v939_6);
    const Space v934_13 = wrap(v934_12,p1);
    const Space v934_14 = unite(v934_8,v934_13);
    v933_9_result = unite(v933_9_result,v934_14);
  }
  const Space v933_9 = std::move(v933_9_result);
  return v933_9;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v940_12_result;
  for (int v940_12_label = 1; v940_12_label <= 2; ++v940_12_label) {
    const Space v940_12_tail = child(s0,v940_12_label);
    if (v940_12_tail.empty()) continue;
    const Path v940_12_head{v940_12_label};
    const Space v941_2 = singleton(v940_12_head);
    const Space v941_3 = intersect(constant_14,v941_2);
    const Space v941_4 = (has_head(v941_3) ? constant_15 : Space{});
    const Space v941_5 = subtract(constant_0,v941_4);
    Space v941_8;
    if (!v941_5.empty()) {
      const Path v942_6 = concat_path(p0,v940_12_head);
      Space v942_7_result;
      for (int v942_7_label = 1; v942_7_label <= 2; ++v942_7_label) {
        const Space v942_7_tail = child(v940_12_tail,v942_7_label);
        if (v942_7_tail.empty()) continue;
        const Path v942_7_head{v942_7_label};
        const Space v943_2 = singleton(v942_7_head);
        const Space v943_3 = intersect(constant_14,v943_2);
        const Space v943_4 = (has_head(v943_3) ? constant_15 : Space{});
        const Space v943_5 = subtract(constant_0,v943_4);
        Space v943_8;
        if (!v943_5.empty()) {
          const Path v944_6 = concat_path(v942_6,v942_7_head);
          const Space v944_7 = routine_136(c, v944_6, p1, v942_7_tail);
          v943_8 = compose(v943_5,v944_7);
        }
        const Space v943_9 = intersect(constant_14,v943_2);
        const Space v943_10 = (has_head(v943_9) ? constant_15 : Space{});
        Space v943_12;
        if (!v943_10.empty()) {
          const Path v945_6 = concat_path(v942_6,v942_7_head);
          const Space v945_11 = routine_137(c, v945_6, p1, v942_7_tail);
          v943_12 = compose(v943_10,v945_11);
        }
        const Space v943_13 = unite(v943_8,v943_12);
        v942_7_result = unite(v942_7_result,v943_13);
      }
      const Space v942_7 = std::move(v942_7_result);
      v941_8 = compose(v941_5,v942_7);
    }
    const Space v941_9 = intersect(constant_14,v941_2);
    const Space v941_10 = (has_head(v941_9) ? constant_15 : Space{});
    Space v941_12;
    if (!v941_10.empty()) {
      const Path v946_6 = concat_path(p0,v940_12_head);
      Space v946_11_result;
      for (int v946_11_label = 1; v946_11_label <= 2; ++v946_11_label) {
        const Space v946_11_tail = child(v940_12_tail,v946_11_label);
        if (v946_11_tail.empty()) continue;
        const Path v946_11_head{v946_11_label};
        const Space v947_2 = singleton(v946_11_head);
        const Space v947_3 = intersect(constant_14,v947_2);
        const Space v947_4 = (has_head(v947_3) ? constant_15 : Space{});
        const Space v947_5 = subtract(constant_0,v947_4);
        Space v947_8;
        if (!v947_5.empty()) {
          const Path v948_6 = concat_path(v946_6,v946_11_head);
          const Space v948_7 = routine_136(c, v948_6, p1, v946_11_tail);
          v947_8 = compose(v947_5,v948_7);
        }
        const Space v947_9 = intersect(constant_14,v947_2);
        const Space v947_10 = (has_head(v947_9) ? constant_15 : Space{});
        Space v947_12;
        if (!v947_10.empty()) {
          const Path v949_6 = concat_path(v946_6,v946_11_head);
          const Space v949_11 = routine_33(c, v949_6, p1, v946_11_tail);
          v947_12 = compose(v947_10,v949_11);
        }
        const Space v947_13 = unite(v947_8,v947_12);
        v946_11_result = unite(v946_11_result,v947_13);
      }
      const Space v946_11 = std::move(v946_11_result);
      v941_12 = compose(v941_10,v946_11);
    }
    const Space v941_13 = unite(v941_8,v941_12);
    v940_12_result = unite(v940_12_result,v941_13);
  }
  const Space v940_12 = std::move(v940_12_result);
  return v940_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v950_9_result;
  for (int v950_9_label = 1; v950_9_label <= 2; ++v950_9_label) {
    const Space v950_9_tail = child(s0,v950_9_label);
    if (v950_9_tail.empty()) continue;
    const Path v950_9_head{v950_9_label};
    const Space v951_2 = singleton(v950_9_head);
    const Space v951_3 = intersect(constant_14,v951_2);
    const Space v951_4 = (has_head(v951_3) ? constant_15 : Space{});
    const Space v951_5 = subtract(constant_0,v951_4);
    Space v951_8;
    if (!v951_5.empty()) {
      const Path v952_6 = concat_path(p0,v950_9_head);
      Space v952_7_result;
      for (int v952_7_label = 1; v952_7_label <= 2; ++v952_7_label) {
        const Space v952_7_tail = child(v950_9_tail,v952_7_label);
        if (v952_7_tail.empty()) continue;
        const Path v952_7_head{v952_7_label};
        const Space v953_2 = singleton(v952_7_head);
        const Space v953_3 = intersect(constant_14,v953_2);
        const Space v953_4 = (has_head(v953_3) ? constant_15 : Space{});
        const Space v953_5 = subtract(constant_0,v953_4);
        Space v953_8;
        if (!v953_5.empty()) {
          const Path v954_6 = concat_path(v952_6,v952_7_head);
          const Space v954_7 = routine_136(c, v954_6, p1, v952_7_tail);
          v953_8 = compose(v953_5,v954_7);
        }
        const Space v953_9 = intersect(constant_14,v953_2);
        const Space v953_10 = (has_head(v953_9) ? constant_15 : Space{});
        Space v953_12;
        if (!v953_10.empty()) {
          const Path v955_6 = concat_path(v952_6,v952_7_head);
          const Space v955_11 = routine_137(c, v955_6, p1, v952_7_tail);
          v953_12 = compose(v953_10,v955_11);
        }
        const Space v953_13 = unite(v953_8,v953_12);
        v952_7_result = unite(v952_7_result,v953_13);
      }
      const Space v952_7 = std::move(v952_7_result);
      v951_8 = compose(v951_5,v952_7);
    }
    const Space v951_9 = intersect(constant_14,v951_2);
    const Space v951_10 = (has_head(v951_9) ? constant_15 : Space{});
    const Space v951_11 = compose(v951_10,v950_9_tail);
    const Path v956_6 = concat_path(p0,v950_9_head);
    const Space v951_12 = wrap(v951_11,v956_6);
    const Space v951_13 = wrap(v951_12,p1);
    const Space v951_14 = unite(v951_8,v951_13);
    v950_9_result = unite(v950_9_result,v951_14);
  }
  const Space v950_9 = std::move(v950_9_result);
  return v950_9;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v957_5_result;
  for (int v957_5_label = 1; v957_5_label <= 2; ++v957_5_label) {
    const Space v957_5_tail = child(s0,v957_5_label);
    if (v957_5_tail.empty()) continue;
    const Path v957_5_head{v957_5_label};
    const Space v958_2 = singleton(v957_5_head);
    const Space v958_3 = intersect(constant_14,v958_2);
    const Space v958_4 = (has_head(v958_3) ? constant_15 : Space{});
    Space v958_7;
    if (!v958_4.empty()) {
      const Path v959_5 = concat_path(p0,v957_5_head);
      Space v959_6_result;
      for (int v959_6_label = 1; v959_6_label <= 2; ++v959_6_label) {
        const Space v959_6_tail = child(v957_5_tail,v959_6_label);
        if (v959_6_tail.empty()) continue;
        const Path v959_6_head{v959_6_label};
        const Space v960_2 = singleton(v959_6_head);
        const Space v960_3 = intersect(constant_14,v960_2);
        const Space v960_4 = (has_head(v960_3) ? constant_15 : Space{});
        Space v960_7;
        if (!v960_4.empty()) {
          const Path v961_5 = concat_path(v959_5,v959_6_head);
          const Space v961_6 = routine_33(c, v961_5, p1, v959_6_tail);
          v960_7 = compose(v960_4,v961_6);
        }
        v959_6_result = unite(v959_6_result,v960_7);
      }
      const Space v959_6 = std::move(v959_6_result);
      v958_7 = compose(v958_4,v959_6);
    }
    v957_5_result = unite(v957_5_result,v958_7);
  }
  const Space v957_5 = std::move(v957_5_result);
  return v957_5;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v962_4_result;
  for (int v962_4_label = 1; v962_4_label <= 2; ++v962_4_label) {
    const Space v962_4_tail = child(s0,v962_4_label);
    if (v962_4_tail.empty()) continue;
    const Path v962_4_head{v962_4_label};
    const Space v963_2 = singleton(v962_4_head);
    const Space v963_3 = intersect(constant_14,v963_2);
    const Space v963_4 = (has_head(v963_3) ? constant_15 : Space{});
    const Space v963_5 = compose(v963_4,v962_4_tail);
    const Path v963_6 = concat_path(p0,v962_4_head);
    const Space v963_7 = wrap(v963_5,v963_6);
    v962_4_result = unite(v962_4_result,v963_7);
  }
  const Space v962_4 = std::move(v962_4_result);
  const Space v962_5 = wrap(v962_4,p1);
  return v962_5;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v964_13_result;
  for (int v964_13_label = 1; v964_13_label <= 2; ++v964_13_label) {
    const Space v964_13_tail = child(s0,v964_13_label);
    if (v964_13_tail.empty()) continue;
    const Path v964_13_head{v964_13_label};
    const Space v965_2 = singleton(v964_13_head);
    const Space v965_3 = intersect(constant_14,v965_2);
    const Space v965_4 = (has_head(v965_3) ? constant_15 : Space{});
    const Space v965_5 = subtract(constant_0,v965_4);
    Space v965_8;
    if (!v965_5.empty()) {
      const Path v966_6 = concat_path(p0,v964_13_head);
      Space v966_7_result;
      for (int v966_7_label = 1; v966_7_label <= 2; ++v966_7_label) {
        const Space v966_7_tail = child(v964_13_tail,v966_7_label);
        if (v966_7_tail.empty()) continue;
        const Path v966_7_head{v966_7_label};
        const Space v967_2 = singleton(v966_7_head);
        const Space v967_3 = intersect(constant_14,v967_2);
        const Space v967_4 = (has_head(v967_3) ? constant_15 : Space{});
        const Space v967_5 = subtract(constant_0,v967_4);
        Space v967_8;
        if (!v967_5.empty()) {
          const Path v968_6 = concat_path(v966_6,v966_7_head);
          const Space v968_7 = routine_138(c, v968_6, p1, v966_7_tail, s1);
          v967_8 = compose(v967_5,v968_7);
        }
        const Space v967_9 = intersect(constant_14,v967_2);
        const Space v967_10 = (has_head(v967_9) ? constant_15 : Space{});
        Space v967_12;
        if (!v967_10.empty()) {
          const Path v969_6 = concat_path(v966_6,v966_7_head);
          const Space v969_11 = routine_139(c, v969_6, p1, v966_7_tail, s1);
          v967_12 = compose(v967_10,v969_11);
        }
        const Space v967_13 = unite(v967_8,v967_12);
        v966_7_result = unite(v966_7_result,v967_13);
      }
      const Space v966_7 = std::move(v966_7_result);
      v965_8 = compose(v965_5,v966_7);
    }
    const Space v965_9 = intersect(constant_14,v965_2);
    const Space v965_10 = (has_head(v965_9) ? constant_15 : Space{});
    Space v965_12;
    if (!v965_10.empty()) {
      const Path v970_6 = concat_path(p0,v964_13_head);
      Space v970_11_result;
      for (int v970_11_label = 1; v970_11_label <= 2; ++v970_11_label) {
        const Space v970_11_tail = child(v964_13_tail,v970_11_label);
        if (v970_11_tail.empty()) continue;
        const Path v970_11_head{v970_11_label};
        const Space v971_2 = singleton(v970_11_head);
        const Space v971_3 = intersect(constant_14,v971_2);
        const Space v971_4 = (has_head(v971_3) ? constant_15 : Space{});
        const Space v971_5 = subtract(constant_0,v971_4);
        Space v971_8;
        if (!v971_5.empty()) {
          const Path v972_6 = concat_path(v970_6,v970_11_head);
          const Space v972_7 = routine_138(c, v972_6, p1, v970_11_tail, s1);
          v971_8 = compose(v971_5,v972_7);
        }
        const Space v971_9 = intersect(constant_14,v971_2);
        const Space v971_10 = (has_head(v971_9) ? constant_15 : Space{});
        Space v971_12;
        if (!v971_10.empty()) {
          const Path v973_6 = concat_path(v970_6,v970_11_head);
          const Space v973_11 = routine_40(c, v973_6, p1, v970_11_tail, s1);
          v971_12 = compose(v971_10,v973_11);
        }
        const Space v971_13 = unite(v971_8,v971_12);
        v970_11_result = unite(v970_11_result,v971_13);
      }
      const Space v970_11 = std::move(v970_11_result);
      v965_12 = compose(v965_10,v970_11);
    }
    const Space v965_13 = unite(v965_8,v965_12);
    v964_13_result = unite(v964_13_result,v965_13);
  }
  const Space v964_13 = std::move(v964_13_result);
  return v964_13;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v974_8 = unwrap(s1,constant_9);
  const Space v974_10 = unwrap(v974_8,constant_10);
  const Space v974_11 = unwrap(v974_10,p0);
  Space v974_18_result;
  for (int v974_18_label = 1; v974_18_label <= 2; ++v974_18_label) {
    const Space v974_18_tail = child(s0,v974_18_label);
    if (v974_18_tail.empty()) continue;
    const Path v974_18_head{v974_18_label};
    const Space v975_2 = singleton(v974_18_head);
    const Space v975_3 = intersect(constant_14,v975_2);
    const Space v975_4 = (has_head(v975_3) ? constant_15 : Space{});
    const Space v975_5 = subtract(constant_0,v975_4);
    Space v975_8;
    if (!v975_5.empty()) {
      const Path v976_6 = concat_path(p0,v974_18_head);
      Space v976_7_result;
      for (int v976_7_label = 1; v976_7_label <= 2; ++v976_7_label) {
        const Space v976_7_tail = child(v974_18_tail,v976_7_label);
        if (v976_7_tail.empty()) continue;
        const Path v976_7_head{v976_7_label};
        const Space v977_2 = singleton(v976_7_head);
        const Space v977_3 = intersect(constant_14,v977_2);
        const Space v977_4 = (has_head(v977_3) ? constant_15 : Space{});
        const Space v977_5 = subtract(constant_0,v977_4);
        Space v977_8;
        if (!v977_5.empty()) {
          const Path v978_6 = concat_path(v976_6,v976_7_head);
          const Space v978_7 = routine_138(c, v978_6, p1, v976_7_tail, s1);
          v977_8 = compose(v977_5,v978_7);
        }
        const Space v977_9 = intersect(constant_14,v977_2);
        const Space v977_10 = (has_head(v977_9) ? constant_15 : Space{});
        Space v977_12;
        if (!v977_10.empty()) {
          const Path v979_6 = concat_path(v976_6,v976_7_head);
          const Space v979_11 = routine_139(c, v979_6, p1, v976_7_tail, s1);
          v977_12 = compose(v977_10,v979_11);
        }
        const Space v977_13 = unite(v977_8,v977_12);
        v976_7_result = unite(v976_7_result,v977_13);
      }
      const Space v976_7 = std::move(v976_7_result);
      v975_8 = compose(v975_5,v976_7);
    }
    const Space v975_9 = intersect(constant_14,v975_2);
    const Space v975_10 = (has_head(v975_9) ? constant_15 : Space{});
    Space v975_13;
    if (!v975_10.empty()) {
      const Space v980_11 = unwrap(v974_11,v974_18_head);
      Space v980_12_result;
      for (int v980_12_label = 1; v980_12_label <= 2; ++v980_12_label) {
        const Space v980_12_tail = child(v980_11,v980_12_label);
        if (v980_12_tail.empty()) continue;
        const Path v980_12_head{v980_12_label};
        const Space v981_2 = singleton(v980_12_head);
        const Space v981_3 = intersect(constant_14,v981_2);
        const Space v981_4 = (has_head(v981_3) ? constant_15 : Space{});
        const Space v981_5 = subtract(constant_0,v981_4);
        Space v981_7;
        if (!v981_5.empty()) {
          const Space v982_6 = routine_76(c, v980_12_head, p1, v980_12_tail);
          v981_7 = compose(v981_5,v982_6);
        }
        const Space v981_8 = intersect(constant_14,v981_2);
        const Space v981_9 = (has_head(v981_8) ? constant_15 : Space{});
        Space v981_11;
        if (!v981_9.empty()) {
          const Space v983_10 = routine_77(c, v980_12_head, p1, v980_12_tail);
          v981_11 = compose(v981_9,v983_10);
        }
        const Space v981_12 = unite(v981_7,v981_11);
        v980_12_result = unite(v980_12_result,v981_12);
      }
      const Space v980_12 = std::move(v980_12_result);
      v975_13 = compose(v975_10,v980_12);
    }
    const Space v975_14 = unite(v975_8,v975_13);
    v974_18_result = unite(v974_18_result,v975_14);
  }
  const Space v974_18 = std::move(v974_18_result);
  return v974_18;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v984_12_result;
  for (int v984_12_label = 1; v984_12_label <= 2; ++v984_12_label) {
    const Space v984_12_tail = child(s0,v984_12_label);
    if (v984_12_tail.empty()) continue;
    const Path v984_12_head{v984_12_label};
    const Space v985_2 = singleton(v984_12_head);
    const Space v985_3 = intersect(constant_14,v985_2);
    const Space v985_4 = (has_head(v985_3) ? constant_15 : Space{});
    const Space v985_5 = subtract(constant_0,v985_4);
    Space v985_8;
    if (!v985_5.empty()) {
      const Path v986_6 = concat_path(p0,v984_12_head);
      Space v986_7_result;
      for (int v986_7_label = 1; v986_7_label <= 2; ++v986_7_label) {
        const Space v986_7_tail = child(v984_12_tail,v986_7_label);
        if (v986_7_tail.empty()) continue;
        const Path v986_7_head{v986_7_label};
        const Space v987_2 = singleton(v986_7_head);
        const Space v987_3 = intersect(constant_14,v987_2);
        const Space v987_4 = (has_head(v987_3) ? constant_15 : Space{});
        const Space v987_5 = subtract(constant_0,v987_4);
        Space v987_8;
        if (!v987_5.empty()) {
          const Path v988_6 = concat_path(v986_6,v986_7_head);
          const Space v988_7 = routine_140(c, v988_6, p1, v986_7_tail);
          v987_8 = compose(v987_5,v988_7);
        }
        const Space v987_9 = intersect(constant_14,v987_2);
        const Space v987_10 = (has_head(v987_9) ? constant_15 : Space{});
        Space v987_12;
        if (!v987_10.empty()) {
          const Path v989_6 = concat_path(v986_6,v986_7_head);
          const Space v989_11 = routine_141(c, v989_6, p1, v986_7_tail);
          v987_12 = compose(v987_10,v989_11);
        }
        const Space v987_13 = unite(v987_8,v987_12);
        v986_7_result = unite(v986_7_result,v987_13);
      }
      const Space v986_7 = std::move(v986_7_result);
      v985_8 = compose(v985_5,v986_7);
    }
    const Space v985_9 = intersect(constant_14,v985_2);
    const Space v985_10 = (has_head(v985_9) ? constant_15 : Space{});
    Space v985_12;
    if (!v985_10.empty()) {
      const Path v990_6 = concat_path(p0,v984_12_head);
      Space v990_11_result;
      for (int v990_11_label = 1; v990_11_label <= 2; ++v990_11_label) {
        const Space v990_11_tail = child(v984_12_tail,v990_11_label);
        if (v990_11_tail.empty()) continue;
        const Path v990_11_head{v990_11_label};
        const Space v991_2 = singleton(v990_11_head);
        const Space v991_3 = intersect(constant_14,v991_2);
        const Space v991_4 = (has_head(v991_3) ? constant_15 : Space{});
        const Space v991_5 = subtract(constant_0,v991_4);
        Space v991_8;
        if (!v991_5.empty()) {
          const Path v992_6 = concat_path(v990_6,v990_11_head);
          const Space v992_7 = routine_140(c, v992_6, p1, v990_11_tail);
          v991_8 = compose(v991_5,v992_7);
        }
        const Space v991_9 = intersect(constant_14,v991_2);
        const Space v991_10 = (has_head(v991_9) ? constant_15 : Space{});
        Space v991_12;
        if (!v991_10.empty()) {
          const Path v993_6 = concat_path(v990_6,v990_11_head);
          const Space v993_11 = routine_82(c, v993_6, p1, v990_11_tail);
          v991_12 = compose(v991_10,v993_11);
        }
        const Space v991_13 = unite(v991_8,v991_12);
        v990_11_result = unite(v990_11_result,v991_13);
      }
      const Space v990_11 = std::move(v990_11_result);
      v985_12 = compose(v985_10,v990_11);
    }
    const Space v985_13 = unite(v985_8,v985_12);
    v984_12_result = unite(v984_12_result,v985_13);
  }
  const Space v984_12 = std::move(v984_12_result);
  return v984_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v994_9_result;
  for (int v994_9_label = 1; v994_9_label <= 2; ++v994_9_label) {
    const Space v994_9_tail = child(s0,v994_9_label);
    if (v994_9_tail.empty()) continue;
    const Path v994_9_head{v994_9_label};
    const Space v995_2 = singleton(v994_9_head);
    const Space v995_3 = intersect(constant_14,v995_2);
    const Space v995_4 = (has_head(v995_3) ? constant_15 : Space{});
    const Space v995_5 = subtract(constant_0,v995_4);
    Space v995_8;
    if (!v995_5.empty()) {
      const Path v996_6 = concat_path(p0,v994_9_head);
      Space v996_7_result;
      for (int v996_7_label = 1; v996_7_label <= 2; ++v996_7_label) {
        const Space v996_7_tail = child(v994_9_tail,v996_7_label);
        if (v996_7_tail.empty()) continue;
        const Path v996_7_head{v996_7_label};
        const Space v997_2 = singleton(v996_7_head);
        const Space v997_3 = intersect(constant_14,v997_2);
        const Space v997_4 = (has_head(v997_3) ? constant_15 : Space{});
        const Space v997_5 = subtract(constant_0,v997_4);
        Space v997_8;
        if (!v997_5.empty()) {
          const Path v998_6 = concat_path(v996_6,v996_7_head);
          const Space v998_7 = routine_140(c, v998_6, p1, v996_7_tail);
          v997_8 = compose(v997_5,v998_7);
        }
        const Space v997_9 = intersect(constant_14,v997_2);
        const Space v997_10 = (has_head(v997_9) ? constant_15 : Space{});
        Space v997_12;
        if (!v997_10.empty()) {
          const Path v999_6 = concat_path(v996_6,v996_7_head);
          const Space v999_11 = routine_141(c, v999_6, p1, v996_7_tail);
          v997_12 = compose(v997_10,v999_11);
        }
        const Space v997_13 = unite(v997_8,v997_12);
        v996_7_result = unite(v996_7_result,v997_13);
      }
      const Space v996_7 = std::move(v996_7_result);
      v995_8 = compose(v995_5,v996_7);
    }
    const Space v995_9 = intersect(constant_14,v995_2);
    const Space v995_10 = (has_head(v995_9) ? constant_15 : Space{});
    const Space v995_11 = compose(v995_10,v994_9_tail);
    const Path v1000_6 = concat_path(p0,v994_9_head);
    const Space v995_12 = wrap(v995_11,v1000_6);
    const Space v995_13 = wrap(v995_12,p1);
    const Space v995_14 = unite(v995_8,v995_13);
    v994_9_result = unite(v994_9_result,v995_14);
  }
  const Space v994_9 = std::move(v994_9_result);
  return v994_9;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1001_6_result;
  for (int v1001_6_label = 1; v1001_6_label <= 2; ++v1001_6_label) {
    const Space v1001_6_tail = child(s0,v1001_6_label);
    if (v1001_6_tail.empty()) continue;
    const Path v1001_6_head{v1001_6_label};
    const Space v1002_2 = singleton(v1001_6_head);
    const Space v1002_3 = intersect(constant_14,v1002_2);
    const Space v1002_4 = (has_head(v1002_3) ? constant_15 : Space{});
    Space v1002_7;
    if (!v1002_4.empty()) {
      const Path v1003_5 = concat_path(p0,v1001_6_head);
      Space v1003_6_result;
      for (int v1003_6_label = 1; v1003_6_label <= 2; ++v1003_6_label) {
        const Space v1003_6_tail = child(v1001_6_tail,v1003_6_label);
        if (v1003_6_tail.empty()) continue;
        const Path v1003_6_head{v1003_6_label};
        const Space v1004_2 = singleton(v1003_6_head);
        const Space v1004_3 = intersect(constant_14,v1004_2);
        const Space v1004_4 = (has_head(v1004_3) ? constant_15 : Space{});
        Space v1004_7;
        if (!v1004_4.empty()) {
          const Path v1005_5 = concat_path(v1003_5,v1003_6_head);
          const Space v1005_6 = routine_40(c, v1005_5, p1, v1003_6_tail, s1);
          v1004_7 = compose(v1004_4,v1005_6);
        }
        v1003_6_result = unite(v1003_6_result,v1004_7);
      }
      const Space v1003_6 = std::move(v1003_6_result);
      v1002_7 = compose(v1002_4,v1003_6);
    }
    v1001_6_result = unite(v1001_6_result,v1002_7);
  }
  const Space v1001_6 = std::move(v1001_6_result);
  return v1001_6;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1006_6 = unwrap(s1,constant_9);
  const Space v1006_8 = unwrap(v1006_6,constant_10);
  const Space v1006_9 = unwrap(v1006_8,p0);
  Space v1006_13_result;
  for (int v1006_13_label = 1; v1006_13_label <= 2; ++v1006_13_label) {
    const Space v1006_13_tail = child(s0,v1006_13_label);
    if (v1006_13_tail.empty()) continue;
    const Path v1006_13_head{v1006_13_label};
    const Space v1007_2 = singleton(v1006_13_head);
    const Space v1007_3 = intersect(constant_14,v1007_2);
    const Space v1007_4 = (has_head(v1007_3) ? constant_15 : Space{});
    Space v1007_7;
    if (!v1007_4.empty()) {
      const Space v1008_5 = unwrap(v1006_9,v1006_13_head);
      Space v1008_6_result;
      for (int v1008_6_label = 1; v1008_6_label <= 2; ++v1008_6_label) {
        const Space v1008_6_tail = child(v1008_5,v1008_6_label);
        if (v1008_6_tail.empty()) continue;
        const Path v1008_6_head{v1008_6_label};
        const Space v1009_2 = singleton(v1008_6_head);
        const Space v1009_3 = intersect(constant_14,v1009_2);
        const Space v1009_4 = (has_head(v1009_3) ? constant_15 : Space{});
        const Space v1009_5 = subtract(constant_0,v1009_4);
        Space v1009_7;
        if (!v1009_5.empty()) {
          const Space v1010_6 = routine_76(c, v1008_6_head, p1, v1008_6_tail);
          v1009_7 = compose(v1009_5,v1010_6);
        }
        const Space v1009_8 = intersect(constant_14,v1009_2);
        const Space v1009_9 = (has_head(v1009_8) ? constant_15 : Space{});
        Space v1009_11;
        if (!v1009_9.empty()) {
          const Space v1011_10 = routine_77(c, v1008_6_head, p1, v1008_6_tail);
          v1009_11 = compose(v1009_9,v1011_10);
        }
        const Space v1009_12 = unite(v1009_7,v1009_11);
        v1008_6_result = unite(v1008_6_result,v1009_12);
      }
      const Space v1008_6 = std::move(v1008_6_result);
      v1007_7 = compose(v1007_4,v1008_6);
    }
    v1006_13_result = unite(v1006_13_result,v1007_7);
  }
  const Space v1006_13 = std::move(v1006_13_result);
  return v1006_13;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1012_12_result;
  for (int v1012_12_label = 1; v1012_12_label <= 2; ++v1012_12_label) {
    const Space v1012_12_tail = child(s0,v1012_12_label);
    if (v1012_12_tail.empty()) continue;
    const Path v1012_12_head{v1012_12_label};
    const Space v1013_2 = singleton(v1012_12_head);
    const Space v1013_3 = intersect(constant_14,v1013_2);
    const Space v1013_4 = (has_head(v1013_3) ? constant_15 : Space{});
    const Space v1013_5 = subtract(constant_0,v1013_4);
    Space v1013_8;
    if (!v1013_5.empty()) {
      const Path v1014_6 = concat_path(p0,v1012_12_head);
      Space v1014_7_result;
      for (int v1014_7_label = 1; v1014_7_label <= 2; ++v1014_7_label) {
        const Space v1014_7_tail = child(v1012_12_tail,v1014_7_label);
        if (v1014_7_tail.empty()) continue;
        const Path v1014_7_head{v1014_7_label};
        const Space v1015_2 = singleton(v1014_7_head);
        const Space v1015_3 = intersect(constant_14,v1015_2);
        const Space v1015_4 = (has_head(v1015_3) ? constant_15 : Space{});
        const Space v1015_5 = subtract(constant_0,v1015_4);
        Space v1015_8;
        if (!v1015_5.empty()) {
          const Path v1016_6 = concat_path(v1014_6,v1014_7_head);
          const Space v1016_7 = routine_142(c, v1016_6, p1, v1014_7_tail);
          v1015_8 = compose(v1015_5,v1016_7);
        }
        const Space v1015_9 = intersect(constant_14,v1015_2);
        const Space v1015_10 = (has_head(v1015_9) ? constant_15 : Space{});
        Space v1015_12;
        if (!v1015_10.empty()) {
          const Path v1017_6 = concat_path(v1014_6,v1014_7_head);
          const Space v1017_11 = routine_143(c, v1017_6, p1, v1014_7_tail);
          v1015_12 = compose(v1015_10,v1017_11);
        }
        const Space v1015_13 = unite(v1015_8,v1015_12);
        v1014_7_result = unite(v1014_7_result,v1015_13);
      }
      const Space v1014_7 = std::move(v1014_7_result);
      v1013_8 = compose(v1013_5,v1014_7);
    }
    const Space v1013_9 = intersect(constant_14,v1013_2);
    const Space v1013_10 = (has_head(v1013_9) ? constant_15 : Space{});
    Space v1013_12;
    if (!v1013_10.empty()) {
      const Path v1018_6 = concat_path(p0,v1012_12_head);
      Space v1018_11_result;
      for (int v1018_11_label = 1; v1018_11_label <= 2; ++v1018_11_label) {
        const Space v1018_11_tail = child(v1012_12_tail,v1018_11_label);
        if (v1018_11_tail.empty()) continue;
        const Path v1018_11_head{v1018_11_label};
        const Space v1019_2 = singleton(v1018_11_head);
        const Space v1019_3 = intersect(constant_14,v1019_2);
        const Space v1019_4 = (has_head(v1019_3) ? constant_15 : Space{});
        const Space v1019_5 = subtract(constant_0,v1019_4);
        Space v1019_8;
        if (!v1019_5.empty()) {
          const Path v1020_6 = concat_path(v1018_6,v1018_11_head);
          const Space v1020_7 = routine_142(c, v1020_6, p1, v1018_11_tail);
          v1019_8 = compose(v1019_5,v1020_7);
        }
        const Space v1019_9 = intersect(constant_14,v1019_2);
        const Space v1019_10 = (has_head(v1019_9) ? constant_15 : Space{});
        Space v1019_12;
        if (!v1019_10.empty()) {
          const Path v1021_6 = concat_path(v1018_6,v1018_11_head);
          const Space v1021_11 = routine_82(c, v1021_6, p1, v1018_11_tail);
          v1019_12 = compose(v1019_10,v1021_11);
        }
        const Space v1019_13 = unite(v1019_8,v1019_12);
        v1018_11_result = unite(v1018_11_result,v1019_13);
      }
      const Space v1018_11 = std::move(v1018_11_result);
      v1013_12 = compose(v1013_10,v1018_11);
    }
    const Space v1013_13 = unite(v1013_8,v1013_12);
    v1012_12_result = unite(v1012_12_result,v1013_13);
  }
  const Space v1012_12 = std::move(v1012_12_result);
  return v1012_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1022_9_result;
  for (int v1022_9_label = 1; v1022_9_label <= 2; ++v1022_9_label) {
    const Space v1022_9_tail = child(s0,v1022_9_label);
    if (v1022_9_tail.empty()) continue;
    const Path v1022_9_head{v1022_9_label};
    const Space v1023_2 = singleton(v1022_9_head);
    const Space v1023_3 = intersect(constant_14,v1023_2);
    const Space v1023_4 = (has_head(v1023_3) ? constant_15 : Space{});
    const Space v1023_5 = subtract(constant_0,v1023_4);
    Space v1023_8;
    if (!v1023_5.empty()) {
      const Path v1024_6 = concat_path(p0,v1022_9_head);
      Space v1024_7_result;
      for (int v1024_7_label = 1; v1024_7_label <= 2; ++v1024_7_label) {
        const Space v1024_7_tail = child(v1022_9_tail,v1024_7_label);
        if (v1024_7_tail.empty()) continue;
        const Path v1024_7_head{v1024_7_label};
        const Space v1025_2 = singleton(v1024_7_head);
        const Space v1025_3 = intersect(constant_14,v1025_2);
        const Space v1025_4 = (has_head(v1025_3) ? constant_15 : Space{});
        const Space v1025_5 = subtract(constant_0,v1025_4);
        Space v1025_8;
        if (!v1025_5.empty()) {
          const Path v1026_6 = concat_path(v1024_6,v1024_7_head);
          const Space v1026_7 = routine_142(c, v1026_6, p1, v1024_7_tail);
          v1025_8 = compose(v1025_5,v1026_7);
        }
        const Space v1025_9 = intersect(constant_14,v1025_2);
        const Space v1025_10 = (has_head(v1025_9) ? constant_15 : Space{});
        Space v1025_12;
        if (!v1025_10.empty()) {
          const Path v1027_6 = concat_path(v1024_6,v1024_7_head);
          const Space v1027_11 = routine_143(c, v1027_6, p1, v1024_7_tail);
          v1025_12 = compose(v1025_10,v1027_11);
        }
        const Space v1025_13 = unite(v1025_8,v1025_12);
        v1024_7_result = unite(v1024_7_result,v1025_13);
      }
      const Space v1024_7 = std::move(v1024_7_result);
      v1023_8 = compose(v1023_5,v1024_7);
    }
    const Space v1023_9 = intersect(constant_14,v1023_2);
    const Space v1023_10 = (has_head(v1023_9) ? constant_15 : Space{});
    const Space v1023_11 = compose(v1023_10,v1022_9_tail);
    const Path v1028_6 = concat_path(p0,v1022_9_head);
    const Space v1023_12 = wrap(v1023_11,v1028_6);
    const Space v1023_13 = wrap(v1023_12,p1);
    const Space v1023_14 = unite(v1023_8,v1023_13);
    v1022_9_result = unite(v1022_9_result,v1023_14);
  }
  const Space v1022_9 = std::move(v1022_9_result);
  return v1022_9;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1029_13_result;
  for (int v1029_13_label = 1; v1029_13_label <= 2; ++v1029_13_label) {
    const Space v1029_13_tail = child(s0,v1029_13_label);
    if (v1029_13_tail.empty()) continue;
    const Path v1029_13_head{v1029_13_label};
    const Space v1030_2 = singleton(v1029_13_head);
    const Space v1030_3 = intersect(constant_14,v1030_2);
    const Space v1030_4 = (has_head(v1030_3) ? constant_15 : Space{});
    const Space v1030_5 = subtract(constant_0,v1030_4);
    Space v1030_8;
    if (!v1030_5.empty()) {
      const Path v1031_6 = concat_path(p0,v1029_13_head);
      Space v1031_7_result;
      for (int v1031_7_label = 1; v1031_7_label <= 2; ++v1031_7_label) {
        const Space v1031_7_tail = child(v1029_13_tail,v1031_7_label);
        if (v1031_7_tail.empty()) continue;
        const Path v1031_7_head{v1031_7_label};
        const Space v1032_2 = singleton(v1031_7_head);
        const Space v1032_3 = intersect(constant_14,v1032_2);
        const Space v1032_4 = (has_head(v1032_3) ? constant_15 : Space{});
        const Space v1032_5 = subtract(constant_0,v1032_4);
        Space v1032_8;
        if (!v1032_5.empty()) {
          const Path v1033_6 = concat_path(v1031_6,v1031_7_head);
          const Space v1033_7 = routine_144(c, v1033_6, p1, v1031_7_tail, s1);
          v1032_8 = compose(v1032_5,v1033_7);
        }
        const Space v1032_9 = intersect(constant_14,v1032_2);
        const Space v1032_10 = (has_head(v1032_9) ? constant_15 : Space{});
        Space v1032_12;
        if (!v1032_10.empty()) {
          const Path v1034_6 = concat_path(v1031_6,v1031_7_head);
          const Space v1034_11 = routine_145(c, v1034_6, p1, v1031_7_tail, s1);
          v1032_12 = compose(v1032_10,v1034_11);
        }
        const Space v1032_13 = unite(v1032_8,v1032_12);
        v1031_7_result = unite(v1031_7_result,v1032_13);
      }
      const Space v1031_7 = std::move(v1031_7_result);
      v1030_8 = compose(v1030_5,v1031_7);
    }
    const Space v1030_9 = intersect(constant_14,v1030_2);
    const Space v1030_10 = (has_head(v1030_9) ? constant_15 : Space{});
    Space v1030_12;
    if (!v1030_10.empty()) {
      const Path v1035_6 = concat_path(p0,v1029_13_head);
      Space v1035_11_result;
      for (int v1035_11_label = 1; v1035_11_label <= 2; ++v1035_11_label) {
        const Space v1035_11_tail = child(v1029_13_tail,v1035_11_label);
        if (v1035_11_tail.empty()) continue;
        const Path v1035_11_head{v1035_11_label};
        const Space v1036_2 = singleton(v1035_11_head);
        const Space v1036_3 = intersect(constant_14,v1036_2);
        const Space v1036_4 = (has_head(v1036_3) ? constant_15 : Space{});
        const Space v1036_5 = subtract(constant_0,v1036_4);
        Space v1036_8;
        if (!v1036_5.empty()) {
          const Path v1037_6 = concat_path(v1035_6,v1035_11_head);
          const Space v1037_7 = routine_144(c, v1037_6, p1, v1035_11_tail, s1);
          v1036_8 = compose(v1036_5,v1037_7);
        }
        const Space v1036_9 = intersect(constant_14,v1036_2);
        const Space v1036_10 = (has_head(v1036_9) ? constant_15 : Space{});
        Space v1036_12;
        if (!v1036_10.empty()) {
          const Path v1038_6 = concat_path(v1035_6,v1035_11_head);
          const Space v1038_11 = routine_47(c, v1038_6, p1, v1035_11_tail, s1);
          v1036_12 = compose(v1036_10,v1038_11);
        }
        const Space v1036_13 = unite(v1036_8,v1036_12);
        v1035_11_result = unite(v1035_11_result,v1036_13);
      }
      const Space v1035_11 = std::move(v1035_11_result);
      v1030_12 = compose(v1030_10,v1035_11);
    }
    const Space v1030_13 = unite(v1030_8,v1030_12);
    v1029_13_result = unite(v1029_13_result,v1030_13);
  }
  const Space v1029_13 = std::move(v1029_13_result);
  return v1029_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1039_8 = unwrap(s1,constant_7);
  const Space v1039_10 = unwrap(v1039_8,constant_10);
  const Space v1039_11 = unwrap(v1039_10,p0);
  Space v1039_18_result;
  for (int v1039_18_label = 1; v1039_18_label <= 2; ++v1039_18_label) {
    const Space v1039_18_tail = child(s0,v1039_18_label);
    if (v1039_18_tail.empty()) continue;
    const Path v1039_18_head{v1039_18_label};
    const Space v1040_2 = singleton(v1039_18_head);
    const Space v1040_3 = intersect(constant_14,v1040_2);
    const Space v1040_4 = (has_head(v1040_3) ? constant_15 : Space{});
    const Space v1040_5 = subtract(constant_0,v1040_4);
    Space v1040_8;
    if (!v1040_5.empty()) {
      const Path v1041_6 = concat_path(p0,v1039_18_head);
      Space v1041_7_result;
      for (int v1041_7_label = 1; v1041_7_label <= 2; ++v1041_7_label) {
        const Space v1041_7_tail = child(v1039_18_tail,v1041_7_label);
        if (v1041_7_tail.empty()) continue;
        const Path v1041_7_head{v1041_7_label};
        const Space v1042_2 = singleton(v1041_7_head);
        const Space v1042_3 = intersect(constant_14,v1042_2);
        const Space v1042_4 = (has_head(v1042_3) ? constant_15 : Space{});
        const Space v1042_5 = subtract(constant_0,v1042_4);
        Space v1042_8;
        if (!v1042_5.empty()) {
          const Path v1043_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1043_7 = routine_144(c, v1043_6, p1, v1041_7_tail, s1);
          v1042_8 = compose(v1042_5,v1043_7);
        }
        const Space v1042_9 = intersect(constant_14,v1042_2);
        const Space v1042_10 = (has_head(v1042_9) ? constant_15 : Space{});
        Space v1042_12;
        if (!v1042_10.empty()) {
          const Path v1044_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1044_11 = routine_145(c, v1044_6, p1, v1041_7_tail, s1);
          v1042_12 = compose(v1042_10,v1044_11);
        }
        const Space v1042_13 = unite(v1042_8,v1042_12);
        v1041_7_result = unite(v1041_7_result,v1042_13);
      }
      const Space v1041_7 = std::move(v1041_7_result);
      v1040_8 = compose(v1040_5,v1041_7);
    }
    const Space v1040_9 = intersect(constant_14,v1040_2);
    const Space v1040_10 = (has_head(v1040_9) ? constant_15 : Space{});
    Space v1040_13;
    if (!v1040_10.empty()) {
      const Space v1045_11 = unwrap(v1039_11,v1039_18_head);
      Space v1045_12_result;
      for (int v1045_12_label = 1; v1045_12_label <= 2; ++v1045_12_label) {
        const Space v1045_12_tail = child(v1045_11,v1045_12_label);
        if (v1045_12_tail.empty()) continue;
        const Path v1045_12_head{v1045_12_label};
        const Space v1046_2 = singleton(v1045_12_head);
        const Space v1046_3 = intersect(constant_14,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_15 : Space{});
        const Space v1046_5 = subtract(constant_0,v1046_4);
        Space v1046_7;
        if (!v1046_5.empty()) {
          const Space v1047_6 = routine_87(c, v1045_12_head, p1, v1045_12_tail);
          v1046_7 = compose(v1046_5,v1047_6);
        }
        const Space v1046_8 = intersect(constant_14,v1046_2);
        const Space v1046_9 = (has_head(v1046_8) ? constant_15 : Space{});
        Space v1046_11;
        if (!v1046_9.empty()) {
          const Space v1048_10 = routine_88(c, v1045_12_head, p1, v1045_12_tail);
          v1046_11 = compose(v1046_9,v1048_10);
        }
        const Space v1046_12 = unite(v1046_7,v1046_11);
        v1045_12_result = unite(v1045_12_result,v1046_12);
      }
      const Space v1045_12 = std::move(v1045_12_result);
      v1040_13 = compose(v1040_10,v1045_12);
    }
    const Space v1040_14 = unite(v1040_8,v1040_13);
    v1039_18_result = unite(v1039_18_result,v1040_14);
  }
  const Space v1039_18 = std::move(v1039_18_result);
  return v1039_18;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1049_12_result;
  for (int v1049_12_label = 1; v1049_12_label <= 2; ++v1049_12_label) {
    const Space v1049_12_tail = child(s0,v1049_12_label);
    if (v1049_12_tail.empty()) continue;
    const Path v1049_12_head{v1049_12_label};
    const Space v1050_2 = singleton(v1049_12_head);
    const Space v1050_3 = intersect(constant_14,v1050_2);
    const Space v1050_4 = (has_head(v1050_3) ? constant_15 : Space{});
    const Space v1050_5 = subtract(constant_0,v1050_4);
    Space v1050_8;
    if (!v1050_5.empty()) {
      const Path v1051_6 = concat_path(p0,v1049_12_head);
      Space v1051_7_result;
      for (int v1051_7_label = 1; v1051_7_label <= 2; ++v1051_7_label) {
        const Space v1051_7_tail = child(v1049_12_tail,v1051_7_label);
        if (v1051_7_tail.empty()) continue;
        const Path v1051_7_head{v1051_7_label};
        const Space v1052_2 = singleton(v1051_7_head);
        const Space v1052_3 = intersect(constant_14,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_15 : Space{});
        const Space v1052_5 = subtract(constant_0,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1053_7 = routine_146(c, v1053_6, p1, v1051_7_tail);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_14,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_15 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1054_11 = routine_147(c, v1054_6, p1, v1051_7_tail);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_7_result = unite(v1051_7_result,v1052_13);
      }
      const Space v1051_7 = std::move(v1051_7_result);
      v1050_8 = compose(v1050_5,v1051_7);
    }
    const Space v1050_9 = intersect(constant_14,v1050_2);
    const Space v1050_10 = (has_head(v1050_9) ? constant_15 : Space{});
    Space v1050_12;
    if (!v1050_10.empty()) {
      const Path v1055_6 = concat_path(p0,v1049_12_head);
      Space v1055_11_result;
      for (int v1055_11_label = 1; v1055_11_label <= 2; ++v1055_11_label) {
        const Space v1055_11_tail = child(v1049_12_tail,v1055_11_label);
        if (v1055_11_tail.empty()) continue;
        const Path v1055_11_head{v1055_11_label};
        const Space v1056_2 = singleton(v1055_11_head);
        const Space v1056_3 = intersect(constant_14,v1056_2);
        const Space v1056_4 = (has_head(v1056_3) ? constant_15 : Space{});
        const Space v1056_5 = subtract(constant_0,v1056_4);
        Space v1056_8;
        if (!v1056_5.empty()) {
          const Path v1057_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1057_7 = routine_146(c, v1057_6, p1, v1055_11_tail);
          v1056_8 = compose(v1056_5,v1057_7);
        }
        const Space v1056_9 = intersect(constant_14,v1056_2);
        const Space v1056_10 = (has_head(v1056_9) ? constant_15 : Space{});
        Space v1056_12;
        if (!v1056_10.empty()) {
          const Path v1058_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1058_11 = routine_93(c, v1058_6, p1, v1055_11_tail);
          v1056_12 = compose(v1056_10,v1058_11);
        }
        const Space v1056_13 = unite(v1056_8,v1056_12);
        v1055_11_result = unite(v1055_11_result,v1056_13);
      }
      const Space v1055_11 = std::move(v1055_11_result);
      v1050_12 = compose(v1050_10,v1055_11);
    }
    const Space v1050_13 = unite(v1050_8,v1050_12);
    v1049_12_result = unite(v1049_12_result,v1050_13);
  }
  const Space v1049_12 = std::move(v1049_12_result);
  return v1049_12;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1059_9_result;
  for (int v1059_9_label = 1; v1059_9_label <= 2; ++v1059_9_label) {
    const Space v1059_9_tail = child(s0,v1059_9_label);
    if (v1059_9_tail.empty()) continue;
    const Path v1059_9_head{v1059_9_label};
    const Space v1060_2 = singleton(v1059_9_head);
    const Space v1060_3 = intersect(constant_14,v1060_2);
    const Space v1060_4 = (has_head(v1060_3) ? constant_15 : Space{});
    const Space v1060_5 = subtract(constant_0,v1060_4);
    Space v1060_8;
    if (!v1060_5.empty()) {
      const Path v1061_6 = concat_path(p0,v1059_9_head);
      Space v1061_7_result;
      for (int v1061_7_label = 1; v1061_7_label <= 2; ++v1061_7_label) {
        const Space v1061_7_tail = child(v1059_9_tail,v1061_7_label);
        if (v1061_7_tail.empty()) continue;
        const Path v1061_7_head{v1061_7_label};
        const Space v1062_2 = singleton(v1061_7_head);
        const Space v1062_3 = intersect(constant_14,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_15 : Space{});
        const Space v1062_5 = subtract(constant_0,v1062_4);
        Space v1062_8;
        if (!v1062_5.empty()) {
          const Path v1063_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1063_7 = routine_146(c, v1063_6, p1, v1061_7_tail);
          v1062_8 = compose(v1062_5,v1063_7);
        }
        const Space v1062_9 = intersect(constant_14,v1062_2);
        const Space v1062_10 = (has_head(v1062_9) ? constant_15 : Space{});
        Space v1062_12;
        if (!v1062_10.empty()) {
          const Path v1064_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1064_11 = routine_147(c, v1064_6, p1, v1061_7_tail);
          v1062_12 = compose(v1062_10,v1064_11);
        }
        const Space v1062_13 = unite(v1062_8,v1062_12);
        v1061_7_result = unite(v1061_7_result,v1062_13);
      }
      const Space v1061_7 = std::move(v1061_7_result);
      v1060_8 = compose(v1060_5,v1061_7);
    }
    const Space v1060_9 = intersect(constant_14,v1060_2);
    const Space v1060_10 = (has_head(v1060_9) ? constant_15 : Space{});
    const Space v1060_11 = compose(v1060_10,v1059_9_tail);
    const Path v1065_6 = concat_path(p0,v1059_9_head);
    const Space v1060_12 = wrap(v1060_11,v1065_6);
    const Space v1060_13 = wrap(v1060_12,p1);
    const Space v1060_14 = unite(v1060_8,v1060_13);
    v1059_9_result = unite(v1059_9_result,v1060_14);
  }
  const Space v1059_9 = std::move(v1059_9_result);
  return v1059_9;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1066_6_result;
  for (int v1066_6_label = 1; v1066_6_label <= 2; ++v1066_6_label) {
    const Space v1066_6_tail = child(s0,v1066_6_label);
    if (v1066_6_tail.empty()) continue;
    const Path v1066_6_head{v1066_6_label};
    const Space v1067_2 = singleton(v1066_6_head);
    const Space v1067_3 = intersect(constant_14,v1067_2);
    const Space v1067_4 = (has_head(v1067_3) ? constant_15 : Space{});
    Space v1067_7;
    if (!v1067_4.empty()) {
      const Path v1068_5 = concat_path(p0,v1066_6_head);
      Space v1068_6_result;
      for (int v1068_6_label = 1; v1068_6_label <= 2; ++v1068_6_label) {
        const Space v1068_6_tail = child(v1066_6_tail,v1068_6_label);
        if (v1068_6_tail.empty()) continue;
        const Path v1068_6_head{v1068_6_label};
        const Space v1069_2 = singleton(v1068_6_head);
        const Space v1069_3 = intersect(constant_14,v1069_2);
        const Space v1069_4 = (has_head(v1069_3) ? constant_15 : Space{});
        Space v1069_7;
        if (!v1069_4.empty()) {
          const Path v1070_5 = concat_path(v1068_5,v1068_6_head);
          const Space v1070_6 = routine_47(c, v1070_5, p1, v1068_6_tail, s1);
          v1069_7 = compose(v1069_4,v1070_6);
        }
        v1068_6_result = unite(v1068_6_result,v1069_7);
      }
      const Space v1068_6 = std::move(v1068_6_result);
      v1067_7 = compose(v1067_4,v1068_6);
    }
    v1066_6_result = unite(v1066_6_result,v1067_7);
  }
  const Space v1066_6 = std::move(v1066_6_result);
  return v1066_6;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1071_6 = unwrap(s1,constant_7);
  const Space v1071_8 = unwrap(v1071_6,constant_10);
  const Space v1071_9 = unwrap(v1071_8,p0);
  Space v1071_13_result;
  for (int v1071_13_label = 1; v1071_13_label <= 2; ++v1071_13_label) {
    const Space v1071_13_tail = child(s0,v1071_13_label);
    if (v1071_13_tail.empty()) continue;
    const Path v1071_13_head{v1071_13_label};
    const Space v1072_2 = singleton(v1071_13_head);
    const Space v1072_3 = intersect(constant_14,v1072_2);
    const Space v1072_4 = (has_head(v1072_3) ? constant_15 : Space{});
    Space v1072_7;
    if (!v1072_4.empty()) {
      const Space v1073_5 = unwrap(v1071_9,v1071_13_head);
      Space v1073_6_result;
      for (int v1073_6_label = 1; v1073_6_label <= 2; ++v1073_6_label) {
        const Space v1073_6_tail = child(v1073_5,v1073_6_label);
        if (v1073_6_tail.empty()) continue;
        const Path v1073_6_head{v1073_6_label};
        const Space v1074_2 = singleton(v1073_6_head);
        const Space v1074_3 = intersect(constant_14,v1074_2);
        const Space v1074_4 = (has_head(v1074_3) ? constant_15 : Space{});
        const Space v1074_5 = subtract(constant_0,v1074_4);
        Space v1074_7;
        if (!v1074_5.empty()) {
          const Space v1075_6 = routine_87(c, v1073_6_head, p1, v1073_6_tail);
          v1074_7 = compose(v1074_5,v1075_6);
        }
        const Space v1074_8 = intersect(constant_14,v1074_2);
        const Space v1074_9 = (has_head(v1074_8) ? constant_15 : Space{});
        Space v1074_11;
        if (!v1074_9.empty()) {
          const Space v1076_10 = routine_88(c, v1073_6_head, p1, v1073_6_tail);
          v1074_11 = compose(v1074_9,v1076_10);
        }
        const Space v1074_12 = unite(v1074_7,v1074_11);
        v1073_6_result = unite(v1073_6_result,v1074_12);
      }
      const Space v1073_6 = std::move(v1073_6_result);
      v1072_7 = compose(v1072_4,v1073_6);
    }
    v1071_13_result = unite(v1071_13_result,v1072_7);
  }
  const Space v1071_13 = std::move(v1071_13_result);
  return v1071_13;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1077_12_result;
  for (int v1077_12_label = 1; v1077_12_label <= 2; ++v1077_12_label) {
    const Space v1077_12_tail = child(s0,v1077_12_label);
    if (v1077_12_tail.empty()) continue;
    const Path v1077_12_head{v1077_12_label};
    const Space v1078_2 = singleton(v1077_12_head);
    const Space v1078_3 = intersect(constant_14,v1078_2);
    const Space v1078_4 = (has_head(v1078_3) ? constant_15 : Space{});
    const Space v1078_5 = subtract(constant_0,v1078_4);
    Space v1078_8;
    if (!v1078_5.empty()) {
      const Path v1079_6 = concat_path(p0,v1077_12_head);
      Space v1079_7_result;
      for (int v1079_7_label = 1; v1079_7_label <= 2; ++v1079_7_label) {
        const Space v1079_7_tail = child(v1077_12_tail,v1079_7_label);
        if (v1079_7_tail.empty()) continue;
        const Path v1079_7_head{v1079_7_label};
        const Space v1080_2 = singleton(v1079_7_head);
        const Space v1080_3 = intersect(constant_14,v1080_2);
        const Space v1080_4 = (has_head(v1080_3) ? constant_15 : Space{});
        const Space v1080_5 = subtract(constant_0,v1080_4);
        Space v1080_8;
        if (!v1080_5.empty()) {
          const Path v1081_6 = concat_path(v1079_6,v1079_7_head);
          const Space v1081_7 = routine_148(c, v1081_6, p1, v1079_7_tail);
          v1080_8 = compose(v1080_5,v1081_7);
        }
        const Space v1080_9 = intersect(constant_14,v1080_2);
        const Space v1080_10 = (has_head(v1080_9) ? constant_15 : Space{});
        Space v1080_12;
        if (!v1080_10.empty()) {
          const Path v1082_6 = concat_path(v1079_6,v1079_7_head);
          const Space v1082_11 = routine_149(c, v1082_6, p1, v1079_7_tail);
          v1080_12 = compose(v1080_10,v1082_11);
        }
        const Space v1080_13 = unite(v1080_8,v1080_12);
        v1079_7_result = unite(v1079_7_result,v1080_13);
      }
      const Space v1079_7 = std::move(v1079_7_result);
      v1078_8 = compose(v1078_5,v1079_7);
    }
    const Space v1078_9 = intersect(constant_14,v1078_2);
    const Space v1078_10 = (has_head(v1078_9) ? constant_15 : Space{});
    Space v1078_12;
    if (!v1078_10.empty()) {
      const Path v1083_6 = concat_path(p0,v1077_12_head);
      Space v1083_11_result;
      for (int v1083_11_label = 1; v1083_11_label <= 2; ++v1083_11_label) {
        const Space v1083_11_tail = child(v1077_12_tail,v1083_11_label);
        if (v1083_11_tail.empty()) continue;
        const Path v1083_11_head{v1083_11_label};
        const Space v1084_2 = singleton(v1083_11_head);
        const Space v1084_3 = intersect(constant_14,v1084_2);
        const Space v1084_4 = (has_head(v1084_3) ? constant_15 : Space{});
        const Space v1084_5 = subtract(constant_0,v1084_4);
        Space v1084_8;
        if (!v1084_5.empty()) {
          const Path v1085_6 = concat_path(v1083_6,v1083_11_head);
          const Space v1085_7 = routine_148(c, v1085_6, p1, v1083_11_tail);
          v1084_8 = compose(v1084_5,v1085_7);
        }
        const Space v1084_9 = intersect(constant_14,v1084_2);
        const Space v1084_10 = (has_head(v1084_9) ? constant_15 : Space{});
        Space v1084_12;
        if (!v1084_10.empty()) {
          const Path v1086_6 = concat_path(v1083_6,v1083_11_head);
          const Space v1086_11 = routine_93(c, v1086_6, p1, v1083_11_tail);
          v1084_12 = compose(v1084_10,v1086_11);
        }
        const Space v1084_13 = unite(v1084_8,v1084_12);
        v1083_11_result = unite(v1083_11_result,v1084_13);
      }
      const Space v1083_11 = std::move(v1083_11_result);
      v1078_12 = compose(v1078_10,v1083_11);
    }
    const Space v1078_13 = unite(v1078_8,v1078_12);
    v1077_12_result = unite(v1077_12_result,v1078_13);
  }
  const Space v1077_12 = std::move(v1077_12_result);
  return v1077_12;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1087_9_result;
  for (int v1087_9_label = 1; v1087_9_label <= 2; ++v1087_9_label) {
    const Space v1087_9_tail = child(s0,v1087_9_label);
    if (v1087_9_tail.empty()) continue;
    const Path v1087_9_head{v1087_9_label};
    const Space v1088_2 = singleton(v1087_9_head);
    const Space v1088_3 = intersect(constant_14,v1088_2);
    const Space v1088_4 = (has_head(v1088_3) ? constant_15 : Space{});
    const Space v1088_5 = subtract(constant_0,v1088_4);
    Space v1088_8;
    if (!v1088_5.empty()) {
      const Path v1089_6 = concat_path(p0,v1087_9_head);
      Space v1089_7_result;
      for (int v1089_7_label = 1; v1089_7_label <= 2; ++v1089_7_label) {
        const Space v1089_7_tail = child(v1087_9_tail,v1089_7_label);
        if (v1089_7_tail.empty()) continue;
        const Path v1089_7_head{v1089_7_label};
        const Space v1090_2 = singleton(v1089_7_head);
        const Space v1090_3 = intersect(constant_14,v1090_2);
        const Space v1090_4 = (has_head(v1090_3) ? constant_15 : Space{});
        const Space v1090_5 = subtract(constant_0,v1090_4);
        Space v1090_8;
        if (!v1090_5.empty()) {
          const Path v1091_6 = concat_path(v1089_6,v1089_7_head);
          const Space v1091_7 = routine_148(c, v1091_6, p1, v1089_7_tail);
          v1090_8 = compose(v1090_5,v1091_7);
        }
        const Space v1090_9 = intersect(constant_14,v1090_2);
        const Space v1090_10 = (has_head(v1090_9) ? constant_15 : Space{});
        Space v1090_12;
        if (!v1090_10.empty()) {
          const Path v1092_6 = concat_path(v1089_6,v1089_7_head);
          const Space v1092_11 = routine_149(c, v1092_6, p1, v1089_7_tail);
          v1090_12 = compose(v1090_10,v1092_11);
        }
        const Space v1090_13 = unite(v1090_8,v1090_12);
        v1089_7_result = unite(v1089_7_result,v1090_13);
      }
      const Space v1089_7 = std::move(v1089_7_result);
      v1088_8 = compose(v1088_5,v1089_7);
    }
    const Space v1088_9 = intersect(constant_14,v1088_2);
    const Space v1088_10 = (has_head(v1088_9) ? constant_15 : Space{});
    const Space v1088_11 = compose(v1088_10,v1087_9_tail);
    const Path v1093_6 = concat_path(p0,v1087_9_head);
    const Space v1088_12 = wrap(v1088_11,v1093_6);
    const Space v1088_13 = wrap(v1088_12,p1);
    const Space v1088_14 = unite(v1088_8,v1088_13);
    v1087_9_result = unite(v1087_9_result,v1088_14);
  }
  const Space v1087_9 = std::move(v1087_9_result);
  return v1087_9;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1094_5_result;
  for (int v1094_5_label = 1; v1094_5_label <= 2; ++v1094_5_label) {
    const Space v1094_5_tail = child(s0,v1094_5_label);
    if (v1094_5_tail.empty()) continue;
    const Path v1094_5_head{v1094_5_label};
    const Space v1095_2 = singleton(v1094_5_head);
    const Space v1095_3 = intersect(constant_14,v1095_2);
    const Space v1095_4 = (has_head(v1095_3) ? constant_15 : Space{});
    Space v1095_7;
    if (!v1095_4.empty()) {
      const Path v1096_5 = concat_path(p0,v1094_5_head);
      Space v1096_6_result;
      for (int v1096_6_label = 1; v1096_6_label <= 2; ++v1096_6_label) {
        const Space v1096_6_tail = child(v1094_5_tail,v1096_6_label);
        if (v1096_6_tail.empty()) continue;
        const Path v1096_6_head{v1096_6_label};
        const Space v1097_2 = singleton(v1096_6_head);
        const Space v1097_3 = intersect(constant_14,v1097_2);
        const Space v1097_4 = (has_head(v1097_3) ? constant_15 : Space{});
        Space v1097_7;
        if (!v1097_4.empty()) {
          const Path v1098_5 = concat_path(v1096_5,v1096_6_head);
          const Space v1098_6 = routine_52(c, v1098_5, p1, v1096_6_tail);
          v1097_7 = compose(v1097_4,v1098_6);
        }
        v1096_6_result = unite(v1096_6_result,v1097_7);
      }
      const Space v1096_6 = std::move(v1096_6_result);
      v1095_7 = compose(v1095_4,v1096_6);
    }
    v1094_5_result = unite(v1094_5_result,v1095_7);
  }
  const Space v1094_5 = std::move(v1094_5_result);
  return v1094_5;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1099_4_result;
  for (int v1099_4_label = 1; v1099_4_label <= 2; ++v1099_4_label) {
    const Space v1099_4_tail = child(s0,v1099_4_label);
    if (v1099_4_tail.empty()) continue;
    const Path v1099_4_head{v1099_4_label};
    const Space v1100_2 = singleton(v1099_4_head);
    const Space v1100_3 = intersect(constant_14,v1100_2);
    const Space v1100_4 = (has_head(v1100_3) ? constant_15 : Space{});
    const Space v1100_5 = compose(v1100_4,v1099_4_tail);
    const Path v1100_6 = concat_path(p0,v1099_4_head);
    const Space v1100_7 = wrap(v1100_5,v1100_6);
    v1099_4_result = unite(v1099_4_result,v1100_7);
  }
  const Space v1099_4 = std::move(v1099_4_result);
  const Space v1099_5 = wrap(v1099_4,p1);
  const Space v1099_7 = wrap(v1099_5,constant_10);
  return v1099_7;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1101_3 = Space{};
  return v1101_3;
}

static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1102_4_result;
  for (int v1102_4_label = 1; v1102_4_label <= 2; ++v1102_4_label) {
    const Space v1102_4_tail = child(s0,v1102_4_label);
    if (v1102_4_tail.empty()) continue;
    const Path v1102_4_head{v1102_4_label};
    const Space v1103_2 = singleton(v1102_4_head);
    const Space v1103_3 = intersect(constant_14,v1103_2);
    const Space v1103_4 = (has_head(v1103_3) ? constant_15 : Space{});
    const Space v1103_5 = compose(v1103_4,v1102_4_tail);
    const Path v1103_6 = concat_path(p0,v1102_4_head);
    const Space v1103_7 = wrap(v1103_5,v1103_6);
    v1102_4_result = unite(v1102_4_result,v1103_7);
  }
  const Space v1102_4 = std::move(v1102_4_result);
  const Space v1102_5 = wrap(v1102_4,p1);
  const Space v1102_7 = wrap(v1102_5,constant_10);
  return v1102_7;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1104_4 = Space{};
  return v1104_4;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1105_6 = unwrap(s1,constant_7);
  const Space v1105_8 = unwrap(v1105_6,constant_10);
  const Space v1105_9 = unwrap(v1105_8,p0);
  Space v1105_13_result;
  for (int v1105_13_label = 1; v1105_13_label <= 2; ++v1105_13_label) {
    const Space v1105_13_tail = child(s0,v1105_13_label);
    if (v1105_13_tail.empty()) continue;
    const Path v1105_13_head{v1105_13_label};
    const Space v1106_2 = singleton(v1105_13_head);
    const Space v1106_3 = intersect(constant_14,v1106_2);
    const Space v1106_4 = (has_head(v1106_3) ? constant_15 : Space{});
    Space v1106_7;
    if (!v1106_4.empty()) {
      const Space v1107_5 = unwrap(v1105_9,v1105_13_head);
      Space v1107_6_result;
      for (int v1107_6_label = 1; v1107_6_label <= 2; ++v1107_6_label) {
        const Space v1107_6_tail = child(v1107_5,v1107_6_label);
        if (v1107_6_tail.empty()) continue;
        const Path v1107_6_head{v1107_6_label};
        const Space v1108_2 = singleton(v1107_6_head);
        const Space v1108_3 = intersect(constant_14,v1108_2);
        const Space v1108_4 = (has_head(v1108_3) ? constant_15 : Space{});
        const Space v1108_5 = subtract(constant_0,v1108_4);
        Space v1108_7;
        if (!v1108_5.empty()) {
          const Space v1109_6 = routine_59(c, v1107_6_head, p1, v1107_6_tail);
          v1108_7 = compose(v1108_5,v1109_6);
        }
        const Space v1108_8 = intersect(constant_14,v1108_2);
        const Space v1108_9 = (has_head(v1108_8) ? constant_15 : Space{});
        Space v1108_11;
        if (!v1108_9.empty()) {
          const Space v1110_10 = routine_60(c, v1107_6_head, p1, v1107_6_tail);
          v1108_11 = compose(v1108_9,v1110_10);
        }
        const Space v1108_12 = unite(v1108_7,v1108_11);
        v1107_6_result = unite(v1107_6_result,v1108_12);
      }
      const Space v1107_6 = std::move(v1107_6_result);
      v1106_7 = compose(v1106_4,v1107_6);
    }
    v1105_13_result = unite(v1105_13_result,v1106_7);
  }
  const Space v1105_13 = std::move(v1105_13_result);
  return v1105_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1111_12_result;
  for (int v1111_12_label = 1; v1111_12_label <= 2; ++v1111_12_label) {
    const Space v1111_12_tail = child(s0,v1111_12_label);
    if (v1111_12_tail.empty()) continue;
    const Path v1111_12_head{v1111_12_label};
    const Space v1112_2 = singleton(v1111_12_head);
    const Space v1112_3 = intersect(constant_14,v1112_2);
    const Space v1112_4 = (has_head(v1112_3) ? constant_15 : Space{});
    const Space v1112_5 = subtract(constant_0,v1112_4);
    Space v1112_8;
    if (!v1112_5.empty()) {
      const Path v1113_6 = concat_path(p0,v1111_12_head);
      Space v1113_7_result;
      for (int v1113_7_label = 1; v1113_7_label <= 2; ++v1113_7_label) {
        const Space v1113_7_tail = child(v1111_12_tail,v1113_7_label);
        if (v1113_7_tail.empty()) continue;
        const Path v1113_7_head{v1113_7_label};
        const Space v1114_2 = singleton(v1113_7_head);
        const Space v1114_3 = intersect(constant_14,v1114_2);
        const Space v1114_4 = (has_head(v1114_3) ? constant_15 : Space{});
        const Space v1114_5 = subtract(constant_0,v1114_4);
        Space v1114_8;
        if (!v1114_5.empty()) {
          const Path v1115_6 = concat_path(v1113_6,v1113_7_head);
          const Space v1115_7 = routine_150(c, v1115_6, p1, v1113_7_tail);
          v1114_8 = compose(v1114_5,v1115_7);
        }
        const Space v1114_9 = intersect(constant_14,v1114_2);
        const Space v1114_10 = (has_head(v1114_9) ? constant_15 : Space{});
        Space v1114_12;
        if (!v1114_10.empty()) {
          const Path v1116_6 = concat_path(v1113_6,v1113_7_head);
          const Space v1116_11 = routine_151(c, v1116_6, p1, v1113_7_tail);
          v1114_12 = compose(v1114_10,v1116_11);
        }
        const Space v1114_13 = unite(v1114_8,v1114_12);
        v1113_7_result = unite(v1113_7_result,v1114_13);
      }
      const Space v1113_7 = std::move(v1113_7_result);
      v1112_8 = compose(v1112_5,v1113_7);
    }
    const Space v1112_9 = intersect(constant_14,v1112_2);
    const Space v1112_10 = (has_head(v1112_9) ? constant_15 : Space{});
    Space v1112_12;
    if (!v1112_10.empty()) {
      const Path v1117_6 = concat_path(p0,v1111_12_head);
      Space v1117_11_result;
      for (int v1117_11_label = 1; v1117_11_label <= 2; ++v1117_11_label) {
        const Space v1117_11_tail = child(v1111_12_tail,v1117_11_label);
        if (v1117_11_tail.empty()) continue;
        const Path v1117_11_head{v1117_11_label};
        const Space v1118_2 = singleton(v1117_11_head);
        const Space v1118_3 = intersect(constant_14,v1118_2);
        const Space v1118_4 = (has_head(v1118_3) ? constant_15 : Space{});
        const Space v1118_5 = subtract(constant_0,v1118_4);
        Space v1118_8;
        if (!v1118_5.empty()) {
          const Path v1119_6 = concat_path(v1117_6,v1117_11_head);
          const Space v1119_7 = routine_150(c, v1119_6, p1, v1117_11_tail);
          v1118_8 = compose(v1118_5,v1119_7);
        }
        const Space v1118_9 = intersect(constant_14,v1118_2);
        const Space v1118_10 = (has_head(v1118_9) ? constant_15 : Space{});
        Space v1118_12;
        if (!v1118_10.empty()) {
          const Path v1120_6 = concat_path(v1117_6,v1117_11_head);
          const Space v1120_11 = routine_65(c, v1120_6, p1, v1117_11_tail);
          v1118_12 = compose(v1118_10,v1120_11);
        }
        const Space v1118_13 = unite(v1118_8,v1118_12);
        v1117_11_result = unite(v1117_11_result,v1118_13);
      }
      const Space v1117_11 = std::move(v1117_11_result);
      v1112_12 = compose(v1112_10,v1117_11);
    }
    const Space v1112_13 = unite(v1112_8,v1112_12);
    v1111_12_result = unite(v1111_12_result,v1112_13);
  }
  const Space v1111_12 = std::move(v1111_12_result);
  return v1111_12;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1121_9_result;
  for (int v1121_9_label = 1; v1121_9_label <= 2; ++v1121_9_label) {
    const Space v1121_9_tail = child(s0,v1121_9_label);
    if (v1121_9_tail.empty()) continue;
    const Path v1121_9_head{v1121_9_label};
    const Space v1122_2 = singleton(v1121_9_head);
    const Space v1122_3 = intersect(constant_14,v1122_2);
    const Space v1122_4 = (has_head(v1122_3) ? constant_15 : Space{});
    const Space v1122_5 = subtract(constant_0,v1122_4);
    Space v1122_8;
    if (!v1122_5.empty()) {
      const Path v1123_6 = concat_path(p0,v1121_9_head);
      Space v1123_7_result;
      for (int v1123_7_label = 1; v1123_7_label <= 2; ++v1123_7_label) {
        const Space v1123_7_tail = child(v1121_9_tail,v1123_7_label);
        if (v1123_7_tail.empty()) continue;
        const Path v1123_7_head{v1123_7_label};
        const Space v1124_2 = singleton(v1123_7_head);
        const Space v1124_3 = intersect(constant_14,v1124_2);
        const Space v1124_4 = (has_head(v1124_3) ? constant_15 : Space{});
        const Space v1124_5 = subtract(constant_0,v1124_4);
        Space v1124_8;
        if (!v1124_5.empty()) {
          const Path v1125_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1125_7 = routine_150(c, v1125_6, p1, v1123_7_tail);
          v1124_8 = compose(v1124_5,v1125_7);
        }
        const Space v1124_9 = intersect(constant_14,v1124_2);
        const Space v1124_10 = (has_head(v1124_9) ? constant_15 : Space{});
        Space v1124_12;
        if (!v1124_10.empty()) {
          const Path v1126_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1126_11 = routine_151(c, v1126_6, p1, v1123_7_tail);
          v1124_12 = compose(v1124_10,v1126_11);
        }
        const Space v1124_13 = unite(v1124_8,v1124_12);
        v1123_7_result = unite(v1123_7_result,v1124_13);
      }
      const Space v1123_7 = std::move(v1123_7_result);
      v1122_8 = compose(v1122_5,v1123_7);
    }
    const Space v1122_9 = intersect(constant_14,v1122_2);
    const Space v1122_10 = (has_head(v1122_9) ? constant_15 : Space{});
    const Space v1122_11 = compose(v1122_10,v1121_9_tail);
    const Path v1127_6 = concat_path(p0,v1121_9_head);
    const Space v1122_12 = wrap(v1122_11,v1127_6);
    const Space v1122_13 = wrap(v1122_12,p1);
    const Space v1122_14 = unite(v1122_8,v1122_13);
    v1121_9_result = unite(v1121_9_result,v1122_14);
  }
  const Space v1121_9 = std::move(v1121_9_result);
  return v1121_9;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1128_5_result;
  for (int v1128_5_label = 1; v1128_5_label <= 2; ++v1128_5_label) {
    const Space v1128_5_tail = child(s0,v1128_5_label);
    if (v1128_5_tail.empty()) continue;
    const Path v1128_5_head{v1128_5_label};
    const Space v1129_2 = singleton(v1128_5_head);
    const Space v1129_3 = intersect(constant_14,v1129_2);
    const Space v1129_4 = (has_head(v1129_3) ? constant_15 : Space{});
    Space v1129_7;
    if (!v1129_4.empty()) {
      const Path v1130_5 = concat_path(p0,v1128_5_head);
      Space v1130_6_result;
      for (int v1130_6_label = 1; v1130_6_label <= 2; ++v1130_6_label) {
        const Space v1130_6_tail = child(v1128_5_tail,v1130_6_label);
        if (v1130_6_tail.empty()) continue;
        const Path v1130_6_head{v1130_6_label};
        const Space v1131_2 = singleton(v1130_6_head);
        const Space v1131_3 = intersect(constant_14,v1131_2);
        const Space v1131_4 = (has_head(v1131_3) ? constant_15 : Space{});
        Space v1131_7;
        if (!v1131_4.empty()) {
          const Path v1132_5 = concat_path(v1130_5,v1130_6_head);
          const Space v1132_6 = routine_65(c, v1132_5, p1, v1130_6_tail);
          v1131_7 = compose(v1131_4,v1132_6);
        }
        v1130_6_result = unite(v1130_6_result,v1131_7);
      }
      const Space v1130_6 = std::move(v1130_6_result);
      v1129_7 = compose(v1129_4,v1130_6);
    }
    v1128_5_result = unite(v1128_5_result,v1129_7);
  }
  const Space v1128_5 = std::move(v1128_5_result);
  return v1128_5;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1133_4_result;
  for (int v1133_4_label = 1; v1133_4_label <= 2; ++v1133_4_label) {
    const Space v1133_4_tail = child(s0,v1133_4_label);
    if (v1133_4_tail.empty()) continue;
    const Path v1133_4_head{v1133_4_label};
    const Space v1134_2 = singleton(v1133_4_head);
    const Space v1134_3 = intersect(constant_14,v1134_2);
    const Space v1134_4 = (has_head(v1134_3) ? constant_15 : Space{});
    const Space v1134_5 = compose(v1134_4,v1133_4_tail);
    const Path v1134_6 = concat_path(p0,v1133_4_head);
    const Space v1134_7 = wrap(v1134_5,v1134_6);
    v1133_4_result = unite(v1133_4_result,v1134_7);
  }
  const Space v1133_4 = std::move(v1133_4_result);
  const Space v1133_5 = wrap(v1133_4,p1);
  return v1133_5;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1135_3 = Space{};
  return v1135_3;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1136_4_result;
  for (int v1136_4_label = 1; v1136_4_label <= 2; ++v1136_4_label) {
    const Space v1136_4_tail = child(s0,v1136_4_label);
    if (v1136_4_tail.empty()) continue;
    const Path v1136_4_head{v1136_4_label};
    const Space v1137_2 = singleton(v1136_4_head);
    const Space v1137_3 = intersect(constant_14,v1137_2);
    const Space v1137_4 = (has_head(v1137_3) ? constant_15 : Space{});
    const Space v1137_5 = compose(v1137_4,v1136_4_tail);
    const Path v1137_6 = concat_path(p0,v1136_4_head);
    const Space v1137_7 = wrap(v1137_5,v1137_6);
    v1136_4_result = unite(v1136_4_result,v1137_7);
  }
  const Space v1136_4 = std::move(v1136_4_result);
  const Space v1136_5 = wrap(v1136_4,p1);
  return v1136_5;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1138_4 = Space{};
  return v1138_4;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1139_6 = unwrap(s1,constant_9);
  const Space v1139_8 = unwrap(v1139_6,constant_10);
  const Space v1139_9 = unwrap(v1139_8,p0);
  Space v1139_13_result;
  for (int v1139_13_label = 1; v1139_13_label <= 2; ++v1139_13_label) {
    const Space v1139_13_tail = child(s0,v1139_13_label);
    if (v1139_13_tail.empty()) continue;
    const Path v1139_13_head{v1139_13_label};
    const Space v1140_2 = singleton(v1139_13_head);
    const Space v1140_3 = intersect(constant_14,v1140_2);
    const Space v1140_4 = (has_head(v1140_3) ? constant_15 : Space{});
    Space v1140_7;
    if (!v1140_4.empty()) {
      const Space v1141_5 = unwrap(v1139_9,v1139_13_head);
      Space v1141_6_result;
      for (int v1141_6_label = 1; v1141_6_label <= 2; ++v1141_6_label) {
        const Space v1141_6_tail = child(v1141_5,v1141_6_label);
        if (v1141_6_tail.empty()) continue;
        const Path v1141_6_head{v1141_6_label};
        const Space v1142_2 = singleton(v1141_6_head);
        const Space v1142_3 = intersect(constant_14,v1142_2);
        const Space v1142_4 = (has_head(v1142_3) ? constant_15 : Space{});
        const Space v1142_5 = subtract(constant_0,v1142_4);
        Space v1142_7;
        if (!v1142_5.empty()) {
          const Space v1143_6 = routine_76(c, v1141_6_head, p1, v1141_6_tail);
          v1142_7 = compose(v1142_5,v1143_6);
        }
        const Space v1142_8 = intersect(constant_14,v1142_2);
        const Space v1142_9 = (has_head(v1142_8) ? constant_15 : Space{});
        Space v1142_11;
        if (!v1142_9.empty()) {
          const Space v1144_10 = routine_77(c, v1141_6_head, p1, v1141_6_tail);
          v1142_11 = compose(v1142_9,v1144_10);
        }
        const Space v1142_12 = unite(v1142_7,v1142_11);
        v1141_6_result = unite(v1141_6_result,v1142_12);
      }
      const Space v1141_6 = std::move(v1141_6_result);
      v1140_7 = compose(v1140_4,v1141_6);
    }
    v1139_13_result = unite(v1139_13_result,v1140_7);
  }
  const Space v1139_13 = std::move(v1139_13_result);
  return v1139_13;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1145_12_result;
  for (int v1145_12_label = 1; v1145_12_label <= 2; ++v1145_12_label) {
    const Space v1145_12_tail = child(s0,v1145_12_label);
    if (v1145_12_tail.empty()) continue;
    const Path v1145_12_head{v1145_12_label};
    const Space v1146_2 = singleton(v1145_12_head);
    const Space v1146_3 = intersect(constant_14,v1146_2);
    const Space v1146_4 = (has_head(v1146_3) ? constant_15 : Space{});
    const Space v1146_5 = subtract(constant_0,v1146_4);
    Space v1146_8;
    if (!v1146_5.empty()) {
      const Path v1147_6 = concat_path(p0,v1145_12_head);
      Space v1147_7_result;
      for (int v1147_7_label = 1; v1147_7_label <= 2; ++v1147_7_label) {
        const Space v1147_7_tail = child(v1145_12_tail,v1147_7_label);
        if (v1147_7_tail.empty()) continue;
        const Path v1147_7_head{v1147_7_label};
        const Space v1148_2 = singleton(v1147_7_head);
        const Space v1148_3 = intersect(constant_14,v1148_2);
        const Space v1148_4 = (has_head(v1148_3) ? constant_15 : Space{});
        const Space v1148_5 = subtract(constant_0,v1148_4);
        Space v1148_8;
        if (!v1148_5.empty()) {
          const Path v1149_6 = concat_path(v1147_6,v1147_7_head);
          const Space v1149_7 = routine_152(c, v1149_6, p1, v1147_7_tail);
          v1148_8 = compose(v1148_5,v1149_7);
        }
        const Space v1148_9 = intersect(constant_14,v1148_2);
        const Space v1148_10 = (has_head(v1148_9) ? constant_15 : Space{});
        Space v1148_12;
        if (!v1148_10.empty()) {
          const Path v1150_6 = concat_path(v1147_6,v1147_7_head);
          const Space v1150_11 = routine_153(c, v1150_6, p1, v1147_7_tail);
          v1148_12 = compose(v1148_10,v1150_11);
        }
        const Space v1148_13 = unite(v1148_8,v1148_12);
        v1147_7_result = unite(v1147_7_result,v1148_13);
      }
      const Space v1147_7 = std::move(v1147_7_result);
      v1146_8 = compose(v1146_5,v1147_7);
    }
    const Space v1146_9 = intersect(constant_14,v1146_2);
    const Space v1146_10 = (has_head(v1146_9) ? constant_15 : Space{});
    Space v1146_12;
    if (!v1146_10.empty()) {
      const Path v1151_6 = concat_path(p0,v1145_12_head);
      Space v1151_11_result;
      for (int v1151_11_label = 1; v1151_11_label <= 2; ++v1151_11_label) {
        const Space v1151_11_tail = child(v1145_12_tail,v1151_11_label);
        if (v1151_11_tail.empty()) continue;
        const Path v1151_11_head{v1151_11_label};
        const Space v1152_2 = singleton(v1151_11_head);
        const Space v1152_3 = intersect(constant_14,v1152_2);
        const Space v1152_4 = (has_head(v1152_3) ? constant_15 : Space{});
        const Space v1152_5 = subtract(constant_0,v1152_4);
        Space v1152_8;
        if (!v1152_5.empty()) {
          const Path v1153_6 = concat_path(v1151_6,v1151_11_head);
          const Space v1153_7 = routine_152(c, v1153_6, p1, v1151_11_tail);
          v1152_8 = compose(v1152_5,v1153_7);
        }
        const Space v1152_9 = intersect(constant_14,v1152_2);
        const Space v1152_10 = (has_head(v1152_9) ? constant_15 : Space{});
        Space v1152_12;
        if (!v1152_10.empty()) {
          const Path v1154_6 = concat_path(v1151_6,v1151_11_head);
          const Space v1154_11 = routine_82(c, v1154_6, p1, v1151_11_tail);
          v1152_12 = compose(v1152_10,v1154_11);
        }
        const Space v1152_13 = unite(v1152_8,v1152_12);
        v1151_11_result = unite(v1151_11_result,v1152_13);
      }
      const Space v1151_11 = std::move(v1151_11_result);
      v1146_12 = compose(v1146_10,v1151_11);
    }
    const Space v1146_13 = unite(v1146_8,v1146_12);
    v1145_12_result = unite(v1145_12_result,v1146_13);
  }
  const Space v1145_12 = std::move(v1145_12_result);
  return v1145_12;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1155_9_result;
  for (int v1155_9_label = 1; v1155_9_label <= 2; ++v1155_9_label) {
    const Space v1155_9_tail = child(s0,v1155_9_label);
    if (v1155_9_tail.empty()) continue;
    const Path v1155_9_head{v1155_9_label};
    const Space v1156_2 = singleton(v1155_9_head);
    const Space v1156_3 = intersect(constant_14,v1156_2);
    const Space v1156_4 = (has_head(v1156_3) ? constant_15 : Space{});
    const Space v1156_5 = subtract(constant_0,v1156_4);
    Space v1156_8;
    if (!v1156_5.empty()) {
      const Path v1157_6 = concat_path(p0,v1155_9_head);
      Space v1157_7_result;
      for (int v1157_7_label = 1; v1157_7_label <= 2; ++v1157_7_label) {
        const Space v1157_7_tail = child(v1155_9_tail,v1157_7_label);
        if (v1157_7_tail.empty()) continue;
        const Path v1157_7_head{v1157_7_label};
        const Space v1158_2 = singleton(v1157_7_head);
        const Space v1158_3 = intersect(constant_14,v1158_2);
        const Space v1158_4 = (has_head(v1158_3) ? constant_15 : Space{});
        const Space v1158_5 = subtract(constant_0,v1158_4);
        Space v1158_8;
        if (!v1158_5.empty()) {
          const Path v1159_6 = concat_path(v1157_6,v1157_7_head);
          const Space v1159_7 = routine_152(c, v1159_6, p1, v1157_7_tail);
          v1158_8 = compose(v1158_5,v1159_7);
        }
        const Space v1158_9 = intersect(constant_14,v1158_2);
        const Space v1158_10 = (has_head(v1158_9) ? constant_15 : Space{});
        Space v1158_12;
        if (!v1158_10.empty()) {
          const Path v1160_6 = concat_path(v1157_6,v1157_7_head);
          const Space v1160_11 = routine_153(c, v1160_6, p1, v1157_7_tail);
          v1158_12 = compose(v1158_10,v1160_11);
        }
        const Space v1158_13 = unite(v1158_8,v1158_12);
        v1157_7_result = unite(v1157_7_result,v1158_13);
      }
      const Space v1157_7 = std::move(v1157_7_result);
      v1156_8 = compose(v1156_5,v1157_7);
    }
    const Space v1156_9 = intersect(constant_14,v1156_2);
    const Space v1156_10 = (has_head(v1156_9) ? constant_15 : Space{});
    const Space v1156_11 = compose(v1156_10,v1155_9_tail);
    const Path v1161_6 = concat_path(p0,v1155_9_head);
    const Space v1156_12 = wrap(v1156_11,v1161_6);
    const Space v1156_13 = wrap(v1156_12,p1);
    const Space v1156_14 = unite(v1156_8,v1156_13);
    v1155_9_result = unite(v1155_9_result,v1156_14);
  }
  const Space v1155_9 = std::move(v1155_9_result);
  return v1155_9;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1162_5_result;
  for (int v1162_5_label = 1; v1162_5_label <= 2; ++v1162_5_label) {
    const Space v1162_5_tail = child(s0,v1162_5_label);
    if (v1162_5_tail.empty()) continue;
    const Path v1162_5_head{v1162_5_label};
    const Space v1163_2 = singleton(v1162_5_head);
    const Space v1163_3 = intersect(constant_14,v1163_2);
    const Space v1163_4 = (has_head(v1163_3) ? constant_15 : Space{});
    Space v1163_7;
    if (!v1163_4.empty()) {
      const Path v1164_5 = concat_path(p0,v1162_5_head);
      Space v1164_6_result;
      for (int v1164_6_label = 1; v1164_6_label <= 2; ++v1164_6_label) {
        const Space v1164_6_tail = child(v1162_5_tail,v1164_6_label);
        if (v1164_6_tail.empty()) continue;
        const Path v1164_6_head{v1164_6_label};
        const Space v1165_2 = singleton(v1164_6_head);
        const Space v1165_3 = intersect(constant_14,v1165_2);
        const Space v1165_4 = (has_head(v1165_3) ? constant_15 : Space{});
        Space v1165_7;
        if (!v1165_4.empty()) {
          const Path v1166_5 = concat_path(v1164_5,v1164_6_head);
          const Space v1166_6 = routine_82(c, v1166_5, p1, v1164_6_tail);
          v1165_7 = compose(v1165_4,v1166_6);
        }
        v1164_6_result = unite(v1164_6_result,v1165_7);
      }
      const Space v1164_6 = std::move(v1164_6_result);
      v1163_7 = compose(v1163_4,v1164_6);
    }
    v1162_5_result = unite(v1162_5_result,v1163_7);
  }
  const Space v1162_5 = std::move(v1162_5_result);
  return v1162_5;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1167_4_result;
  for (int v1167_4_label = 1; v1167_4_label <= 2; ++v1167_4_label) {
    const Space v1167_4_tail = child(s0,v1167_4_label);
    if (v1167_4_tail.empty()) continue;
    const Path v1167_4_head{v1167_4_label};
    const Space v1168_2 = singleton(v1167_4_head);
    const Space v1168_3 = intersect(constant_14,v1168_2);
    const Space v1168_4 = (has_head(v1168_3) ? constant_15 : Space{});
    const Space v1168_5 = compose(v1168_4,v1167_4_tail);
    const Path v1168_6 = concat_path(p0,v1167_4_head);
    const Space v1168_7 = wrap(v1168_5,v1168_6);
    v1167_4_result = unite(v1167_4_result,v1168_7);
  }
  const Space v1167_4 = std::move(v1167_4_result);
  const Space v1167_5 = wrap(v1167_4,p1);
  return v1167_5;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1169_4 = Space{};
  return v1169_4;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1170_6 = unwrap(s1,constant_7);
  const Space v1170_8 = unwrap(v1170_6,constant_10);
  const Space v1170_9 = unwrap(v1170_8,p0);
  Space v1170_13_result;
  for (int v1170_13_label = 1; v1170_13_label <= 2; ++v1170_13_label) {
    const Space v1170_13_tail = child(s0,v1170_13_label);
    if (v1170_13_tail.empty()) continue;
    const Path v1170_13_head{v1170_13_label};
    const Space v1171_2 = singleton(v1170_13_head);
    const Space v1171_3 = intersect(constant_14,v1171_2);
    const Space v1171_4 = (has_head(v1171_3) ? constant_15 : Space{});
    Space v1171_7;
    if (!v1171_4.empty()) {
      const Space v1172_5 = unwrap(v1170_9,v1170_13_head);
      Space v1172_6_result;
      for (int v1172_6_label = 1; v1172_6_label <= 2; ++v1172_6_label) {
        const Space v1172_6_tail = child(v1172_5,v1172_6_label);
        if (v1172_6_tail.empty()) continue;
        const Path v1172_6_head{v1172_6_label};
        const Space v1173_2 = singleton(v1172_6_head);
        const Space v1173_3 = intersect(constant_14,v1173_2);
        const Space v1173_4 = (has_head(v1173_3) ? constant_15 : Space{});
        const Space v1173_5 = subtract(constant_0,v1173_4);
        Space v1173_7;
        if (!v1173_5.empty()) {
          const Space v1174_6 = routine_87(c, v1172_6_head, p1, v1172_6_tail);
          v1173_7 = compose(v1173_5,v1174_6);
        }
        const Space v1173_8 = intersect(constant_14,v1173_2);
        const Space v1173_9 = (has_head(v1173_8) ? constant_15 : Space{});
        Space v1173_11;
        if (!v1173_9.empty()) {
          const Space v1175_10 = routine_88(c, v1172_6_head, p1, v1172_6_tail);
          v1173_11 = compose(v1173_9,v1175_10);
        }
        const Space v1173_12 = unite(v1173_7,v1173_11);
        v1172_6_result = unite(v1172_6_result,v1173_12);
      }
      const Space v1172_6 = std::move(v1172_6_result);
      v1171_7 = compose(v1171_4,v1172_6);
    }
    v1170_13_result = unite(v1170_13_result,v1171_7);
  }
  const Space v1170_13 = std::move(v1170_13_result);
  return v1170_13;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1176_12_result;
  for (int v1176_12_label = 1; v1176_12_label <= 2; ++v1176_12_label) {
    const Space v1176_12_tail = child(s0,v1176_12_label);
    if (v1176_12_tail.empty()) continue;
    const Path v1176_12_head{v1176_12_label};
    const Space v1177_2 = singleton(v1176_12_head);
    const Space v1177_3 = intersect(constant_14,v1177_2);
    const Space v1177_4 = (has_head(v1177_3) ? constant_15 : Space{});
    const Space v1177_5 = subtract(constant_0,v1177_4);
    Space v1177_8;
    if (!v1177_5.empty()) {
      const Path v1178_6 = concat_path(p0,v1176_12_head);
      Space v1178_7_result;
      for (int v1178_7_label = 1; v1178_7_label <= 2; ++v1178_7_label) {
        const Space v1178_7_tail = child(v1176_12_tail,v1178_7_label);
        if (v1178_7_tail.empty()) continue;
        const Path v1178_7_head{v1178_7_label};
        const Space v1179_2 = singleton(v1178_7_head);
        const Space v1179_3 = intersect(constant_14,v1179_2);
        const Space v1179_4 = (has_head(v1179_3) ? constant_15 : Space{});
        const Space v1179_5 = subtract(constant_0,v1179_4);
        Space v1179_8;
        if (!v1179_5.empty()) {
          const Path v1180_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1180_7 = routine_154(c, v1180_6, p1, v1178_7_tail);
          v1179_8 = compose(v1179_5,v1180_7);
        }
        const Space v1179_9 = intersect(constant_14,v1179_2);
        const Space v1179_10 = (has_head(v1179_9) ? constant_15 : Space{});
        Space v1179_12;
        if (!v1179_10.empty()) {
          const Path v1181_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1181_11 = routine_155(c, v1181_6, p1, v1178_7_tail);
          v1179_12 = compose(v1179_10,v1181_11);
        }
        const Space v1179_13 = unite(v1179_8,v1179_12);
        v1178_7_result = unite(v1178_7_result,v1179_13);
      }
      const Space v1178_7 = std::move(v1178_7_result);
      v1177_8 = compose(v1177_5,v1178_7);
    }
    const Space v1177_9 = intersect(constant_14,v1177_2);
    const Space v1177_10 = (has_head(v1177_9) ? constant_15 : Space{});
    Space v1177_12;
    if (!v1177_10.empty()) {
      const Path v1182_6 = concat_path(p0,v1176_12_head);
      Space v1182_11_result;
      for (int v1182_11_label = 1; v1182_11_label <= 2; ++v1182_11_label) {
        const Space v1182_11_tail = child(v1176_12_tail,v1182_11_label);
        if (v1182_11_tail.empty()) continue;
        const Path v1182_11_head{v1182_11_label};
        const Space v1183_2 = singleton(v1182_11_head);
        const Space v1183_3 = intersect(constant_14,v1183_2);
        const Space v1183_4 = (has_head(v1183_3) ? constant_15 : Space{});
        const Space v1183_5 = subtract(constant_0,v1183_4);
        Space v1183_8;
        if (!v1183_5.empty()) {
          const Path v1184_6 = concat_path(v1182_6,v1182_11_head);
          const Space v1184_7 = routine_154(c, v1184_6, p1, v1182_11_tail);
          v1183_8 = compose(v1183_5,v1184_7);
        }
        const Space v1183_9 = intersect(constant_14,v1183_2);
        const Space v1183_10 = (has_head(v1183_9) ? constant_15 : Space{});
        Space v1183_12;
        if (!v1183_10.empty()) {
          const Path v1185_6 = concat_path(v1182_6,v1182_11_head);
          const Space v1185_11 = routine_93(c, v1185_6, p1, v1182_11_tail);
          v1183_12 = compose(v1183_10,v1185_11);
        }
        const Space v1183_13 = unite(v1183_8,v1183_12);
        v1182_11_result = unite(v1182_11_result,v1183_13);
      }
      const Space v1182_11 = std::move(v1182_11_result);
      v1177_12 = compose(v1177_10,v1182_11);
    }
    const Space v1177_13 = unite(v1177_8,v1177_12);
    v1176_12_result = unite(v1176_12_result,v1177_13);
  }
  const Space v1176_12 = std::move(v1176_12_result);
  return v1176_12;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1186_9_result;
  for (int v1186_9_label = 1; v1186_9_label <= 2; ++v1186_9_label) {
    const Space v1186_9_tail = child(s0,v1186_9_label);
    if (v1186_9_tail.empty()) continue;
    const Path v1186_9_head{v1186_9_label};
    const Space v1187_2 = singleton(v1186_9_head);
    const Space v1187_3 = intersect(constant_14,v1187_2);
    const Space v1187_4 = (has_head(v1187_3) ? constant_15 : Space{});
    const Space v1187_5 = subtract(constant_0,v1187_4);
    Space v1187_8;
    if (!v1187_5.empty()) {
      const Path v1188_6 = concat_path(p0,v1186_9_head);
      Space v1188_7_result;
      for (int v1188_7_label = 1; v1188_7_label <= 2; ++v1188_7_label) {
        const Space v1188_7_tail = child(v1186_9_tail,v1188_7_label);
        if (v1188_7_tail.empty()) continue;
        const Path v1188_7_head{v1188_7_label};
        const Space v1189_2 = singleton(v1188_7_head);
        const Space v1189_3 = intersect(constant_14,v1189_2);
        const Space v1189_4 = (has_head(v1189_3) ? constant_15 : Space{});
        const Space v1189_5 = subtract(constant_0,v1189_4);
        Space v1189_8;
        if (!v1189_5.empty()) {
          const Path v1190_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1190_7 = routine_154(c, v1190_6, p1, v1188_7_tail);
          v1189_8 = compose(v1189_5,v1190_7);
        }
        const Space v1189_9 = intersect(constant_14,v1189_2);
        const Space v1189_10 = (has_head(v1189_9) ? constant_15 : Space{});
        Space v1189_12;
        if (!v1189_10.empty()) {
          const Path v1191_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1191_11 = routine_155(c, v1191_6, p1, v1188_7_tail);
          v1189_12 = compose(v1189_10,v1191_11);
        }
        const Space v1189_13 = unite(v1189_8,v1189_12);
        v1188_7_result = unite(v1188_7_result,v1189_13);
      }
      const Space v1188_7 = std::move(v1188_7_result);
      v1187_8 = compose(v1187_5,v1188_7);
    }
    const Space v1187_9 = intersect(constant_14,v1187_2);
    const Space v1187_10 = (has_head(v1187_9) ? constant_15 : Space{});
    const Space v1187_11 = compose(v1187_10,v1186_9_tail);
    const Path v1192_6 = concat_path(p0,v1186_9_head);
    const Space v1187_12 = wrap(v1187_11,v1192_6);
    const Space v1187_13 = wrap(v1187_12,p1);
    const Space v1187_14 = unite(v1187_8,v1187_13);
    v1186_9_result = unite(v1186_9_result,v1187_14);
  }
  const Space v1186_9 = std::move(v1186_9_result);
  return v1186_9;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1193_5_result;
  for (int v1193_5_label = 1; v1193_5_label <= 2; ++v1193_5_label) {
    const Space v1193_5_tail = child(s0,v1193_5_label);
    if (v1193_5_tail.empty()) continue;
    const Path v1193_5_head{v1193_5_label};
    const Space v1194_2 = singleton(v1193_5_head);
    const Space v1194_3 = intersect(constant_14,v1194_2);
    const Space v1194_4 = (has_head(v1194_3) ? constant_15 : Space{});
    Space v1194_7;
    if (!v1194_4.empty()) {
      const Path v1195_5 = concat_path(p0,v1193_5_head);
      Space v1195_6_result;
      for (int v1195_6_label = 1; v1195_6_label <= 2; ++v1195_6_label) {
        const Space v1195_6_tail = child(v1193_5_tail,v1195_6_label);
        if (v1195_6_tail.empty()) continue;
        const Path v1195_6_head{v1195_6_label};
        const Space v1196_2 = singleton(v1195_6_head);
        const Space v1196_3 = intersect(constant_14,v1196_2);
        const Space v1196_4 = (has_head(v1196_3) ? constant_15 : Space{});
        Space v1196_7;
        if (!v1196_4.empty()) {
          const Path v1197_5 = concat_path(v1195_5,v1195_6_head);
          const Space v1197_6 = routine_93(c, v1197_5, p1, v1195_6_tail);
          v1196_7 = compose(v1196_4,v1197_6);
        }
        v1195_6_result = unite(v1195_6_result,v1196_7);
      }
      const Space v1195_6 = std::move(v1195_6_result);
      v1194_7 = compose(v1194_4,v1195_6);
    }
    v1193_5_result = unite(v1193_5_result,v1194_7);
  }
  const Space v1193_5 = std::move(v1193_5_result);
  return v1193_5;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1198_4_result;
  for (int v1198_4_label = 1; v1198_4_label <= 2; ++v1198_4_label) {
    const Space v1198_4_tail = child(s0,v1198_4_label);
    if (v1198_4_tail.empty()) continue;
    const Path v1198_4_head{v1198_4_label};
    const Space v1199_2 = singleton(v1198_4_head);
    const Space v1199_3 = intersect(constant_14,v1199_2);
    const Space v1199_4 = (has_head(v1199_3) ? constant_15 : Space{});
    const Space v1199_5 = compose(v1199_4,v1198_4_tail);
    const Path v1199_6 = concat_path(p0,v1198_4_head);
    const Space v1199_7 = wrap(v1199_5,v1199_6);
    v1198_4_result = unite(v1198_4_result,v1199_7);
  }
  const Space v1198_4 = std::move(v1198_4_result);
  const Space v1198_5 = wrap(v1198_4,p1);
  return v1198_5;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1200_3 = Space{};
  return v1200_3;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1201_4_result;
  for (int v1201_4_label = 1; v1201_4_label <= 2; ++v1201_4_label) {
    const Space v1201_4_tail = child(s0,v1201_4_label);
    if (v1201_4_tail.empty()) continue;
    const Path v1201_4_head{v1201_4_label};
    const Space v1202_2 = singleton(v1201_4_head);
    const Space v1202_3 = intersect(constant_14,v1202_2);
    const Space v1202_4 = (has_head(v1202_3) ? constant_15 : Space{});
    const Space v1202_5 = compose(v1202_4,v1201_4_tail);
    const Path v1202_6 = concat_path(p0,v1201_4_head);
    const Space v1202_7 = wrap(v1202_5,v1202_6);
    v1201_4_result = unite(v1201_4_result,v1202_7);
  }
  const Space v1201_4 = std::move(v1201_4_result);
  const Space v1201_5 = wrap(v1201_4,p1);
  return v1201_5;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1203_3 = Space{};
  return v1203_3;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1204_4_result;
  for (int v1204_4_label = 1; v1204_4_label <= 2; ++v1204_4_label) {
    const Space v1204_4_tail = child(s0,v1204_4_label);
    if (v1204_4_tail.empty()) continue;
    const Path v1204_4_head{v1204_4_label};
    const Space v1205_2 = singleton(v1204_4_head);
    const Space v1205_3 = intersect(constant_14,v1205_2);
    const Space v1205_4 = (has_head(v1205_3) ? constant_15 : Space{});
    const Space v1205_5 = compose(v1205_4,v1204_4_tail);
    const Path v1205_6 = concat_path(p0,v1204_4_head);
    const Space v1205_7 = wrap(v1205_5,v1205_6);
    v1204_4_result = unite(v1204_4_result,v1205_7);
  }
  const Space v1204_4 = std::move(v1204_4_result);
  const Space v1204_5 = wrap(v1204_4,p1);
  return v1204_5;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1206_3 = Space{};
  return v1206_3;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1207_4_result;
  for (int v1207_4_label = 1; v1207_4_label <= 2; ++v1207_4_label) {
    const Space v1207_4_tail = child(s0,v1207_4_label);
    if (v1207_4_tail.empty()) continue;
    const Path v1207_4_head{v1207_4_label};
    const Space v1208_2 = singleton(v1207_4_head);
    const Space v1208_3 = intersect(constant_14,v1208_2);
    const Space v1208_4 = (has_head(v1208_3) ? constant_15 : Space{});
    const Space v1208_5 = compose(v1208_4,v1207_4_tail);
    const Path v1208_6 = concat_path(p0,v1207_4_head);
    const Space v1208_7 = wrap(v1208_5,v1208_6);
    v1207_4_result = unite(v1207_4_result,v1208_7);
  }
  const Space v1207_4 = std::move(v1207_4_result);
  const Space v1207_5 = wrap(v1207_4,p1);
  return v1207_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
