#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("3 14 1 2 2 1 1 2 2 2 1 2 2 1 2 2 14 1 2 2 1 2 2 1 1 2 2 2 1 2 2 14 1 2 2 2 1 2 2 1 2 2 1 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("3 14 1 2 2 1 1 2 2 1 2 2 2 1 2 2 14 1 2 2 1 2 2 2 1 2 2 1 1 2 2 14 1 2 2 2 1 2 2 1 1 2 2 1 2 2");
static const Path constant_5 = Path{1,2};
static const Path constant_6 = Path{2,2};
static const Space constant_7 = literal_text("3 11 1 1 2 2 2 1 2 2 1 2 2 11 1 2 2 1 1 2 2 2 1 2 2 11 2 1 2 2 1 2 2 1 1 2 2");
static const Space constant_8 = literal_text("1 1 2");
static const Space constant_9 = singleton(Path{});
static const Space constant_10 = literal_text("1 5 1 1 1 2 2");
static const Space constant_11 = literal_text("1 5 1 2 1 2 2");
static const Space constant_12 = literal_text("1 5 2 1 1 2 2");
static const Space constant_13 = literal_text("1 2 2 2");
static const Path constant_14 = Path{1};
static const Space constant_15 = literal_text("8 20 1 1 2 2 1 1 2 1 2 2 1 1 1 2 2 1 2 1 2 2 20 1 1 2 2 1 1 2 1 2 2 1 2 1 2 2 1 1 1 2 2 17 1 1 2 2 1 2 1 1 2 2 1 1 1 2 2 2 2 17 1 1 2 2 1 2 1 1 2 2 2 2 1 1 1 2 2 20 2 1 2 2 1 1 1 1 2 2 1 1 1 2 2 1 2 1 2 2 20 2 1 2 2 1 1 1 1 2 2 1 2 1 2 2 1 1 1 2 2 20 2 1 2 2 1 2 1 1 2 2 1 2 1 2 2 2 1 1 2 2 20 2 1 2 2 1 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Path constant_16 = Path{2};
static const Space constant_17 = literal_text("8 17 1 1 2 2 1 1 1 1 2 2 2 1 1 2 2 2 2 17 1 1 2 2 1 1 1 1 2 2 2 2 2 1 1 2 2 20 1 1 2 2 2 1 1 1 2 2 1 2 1 2 2 2 1 1 2 2 20 1 1 2 2 2 1 1 1 2 2 2 1 1 2 2 1 2 1 2 2 14 2 1 1 2 1 2 2 2 1 1 2 2 2 2 14 2 1 1 2 1 2 2 2 2 2 1 1 2 2 14 2 2 1 1 1 2 2 1 1 1 2 2 2 2 14 2 2 1 1 1 2 2 2 2 1 1 1 2 2");
static const Space constant_18 = literal_text("4 19 1 2 2 1 1 2 1 2 2 1 1 1 2 2 1 2 1 2 2 19 1 2 2 1 1 2 1 2 2 1 2 1 2 2 1 1 1 2 2 16 1 2 2 1 2 1 1 2 2 1 1 1 2 2 2 2 16 1 2 2 1 2 1 1 2 2 2 2 1 1 1 2 2");
static const Space constant_19 = literal_text("4 16 1 2 2 1 1 1 1 2 2 2 1 1 2 2 2 2 16 1 2 2 1 1 1 1 2 2 2 2 2 1 1 2 2 19 1 2 2 2 1 1 1 2 2 1 2 1 2 2 2 1 1 2 2 19 1 2 2 2 1 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Space constant_20 = literal_text("4 19 1 2 2 1 1 1 1 2 2 1 1 1 2 2 1 2 1 2 2 19 1 2 2 1 1 1 1 2 2 1 2 1 2 2 1 1 1 2 2 19 1 2 2 1 2 1 1 2 2 1 2 1 2 2 2 1 1 2 2 19 1 2 2 1 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Space constant_21 = literal_text("4 13 1 1 2 1 2 2 2 1 1 2 2 2 2 13 1 1 2 1 2 2 2 2 2 1 1 2 2 13 2 1 1 1 2 2 1 1 1 2 2 2 2 13 2 1 1 1 2 2 2 2 1 1 1 2 2");
static const Path constant_22 = Path{2,1,1,2,2};
static const Path constant_23 = Path{1,2,1,2,2};
static const Path constant_24 = Path{1,1,1,2,2};
static const Space constant_25 = literal_text("4 10 1 1 1 2 2 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 10 2 1 1 2 2 2 1 1 2 2 4 2 2 2 2");
static const Space constant_26 = literal_text("1 11 1 1 1 2 2 2 1 2 1 2 2");
static const Space constant_27 = literal_text("1 11 1 2 1 2 2 2 1 2 1 2 2");
static const Space constant_28 = literal_text("1 11 2 1 1 2 2 2 1 2 1 2 2");
static const Space constant_29 = literal_text("1 8 2 2 2 1 2 1 2 2");
static Space routine_0(Context& c);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_257(Context& c, const Path& p0, const Space& s0);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_265(Context& c, const Path& p0, const Space& s0);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Space& s0);
static Space routine_201(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0);
static Space routine_217(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_209(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Space& s0);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Space& s0);
static Space routine_258(Context& c, const Path& p0, const Space& s0);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_266(Context& c, const Path& p0, const Space& s0);
static Space routine_183(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Space& s0);
static Space routine_202(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_218(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_210(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0);
static Space routine_194(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_287(Context& c, const Path& p0, const Space& s0);
static Space routine_221(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_292(Context& c, const Path& p0, const Space& s0);
static Space routine_228(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_240(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Space& s0);
static Space routine_250(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Space& s0);
static Space routine_245(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Space& s0);
static Space routine_235(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_288(Context& c, const Path& p0, const Space& s0);
static Space routine_222(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_293(Context& c, const Path& p0, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_229(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_140(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Space& s0);
static Space routine_241(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Space& s0);
static Space routine_251(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_246(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_236(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Space& s0);
static Space routine_305(Context& c, const Path& p0, const Space& s0);
static Space routine_255(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_309(Context& c, const Path& p0, const Space& s0);
static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_263(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_180(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_184(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_116(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Space& s0);
static Space routine_275(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_199(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Space& s0);
static Space routine_283(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_215(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Space& s0);
static Space routine_279(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Space& s0);
static Space routine_271(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Space& s0);
static Space routine_306(Context& c, const Path& p0, const Space& s0);
static Space routine_256(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_310(Context& c, const Path& p0, const Space& s0);
static Space routine_208(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_264(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_185(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_117(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Space& s0);
static Space routine_276(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_200(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Space& s0);
static Space routine_284(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_216(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Space& s0);
static Space routine_280(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Space& s0);
static Space routine_272(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Space& s0);
static Space routine_156(Context& c, const Path& p0, const Space& s0);
static Space routine_319(Context& c, const Path& p0, const Space& s0);
static Space routine_285(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_219(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_224(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_321(Context& c, const Path& p0, const Space& s0);
static Space routine_243(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_290(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_226(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_231(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Space& s0);
static Space routine_149(Context& c, const Path& p0, const Space& s0);
static Space routine_297(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Space& s0);
static Space routine_301(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_248(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Space& s0);
static Space routine_299(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_295(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_233(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Space& s0);
static Space routine_320(Context& c, const Path& p0, const Space& s0);
static Space routine_157(Context& c, const Path& p0, const Space& s0);
static Space routine_286(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_220(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_225(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_322(Context& c, const Path& p0, const Space& s0);
static Space routine_244(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_291(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_227(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_232(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Space& s0);
static Space routine_298(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_239(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Space& s0);
static Space routine_302(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_249(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Space& s0);
static Space routine_300(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_296(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_234(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Space& s0);
static Space routine_323(Context& c, const Path& p0, const Space& s0);
static Space routine_303(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_203(Context& c, const Path& p0, const Space& s0);
static Space routine_259(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_325(Context& c, const Path& p0, const Space& s0);
static Space routine_277(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_307(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_261(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_267(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_205(Context& c, const Path& p0, const Space& s0);
static Space routine_195(Context& c, const Path& p0, const Space& s0);
static Space routine_313(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Space& s0);
static Space routine_211(Context& c, const Path& p0, const Space& s0);
static Space routine_317(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_281(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_213(Context& c, const Path& p0, const Space& s0);
static Space routine_187(Context& c, const Path& p0, const Space& s0);
static Space routine_315(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_311(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_269(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_190(Context& c, const Path& p0, const Space& s0);
static Space routine_324(Context& c, const Path& p0, const Space& s0);
static Space routine_304(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_260(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_204(Context& c, const Path& p0, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_326(Context& c, const Path& p0, const Space& s0);
static Space routine_278(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_308(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_262(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_268(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_206(Context& c, const Path& p0, const Space& s0);
static Space routine_196(Context& c, const Path& p0, const Space& s0);
static Space routine_314(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_198(Context& c, const Path& p0, const Space& s0);
static Space routine_212(Context& c, const Path& p0, const Space& s0);
static Space routine_318(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_282(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_214(Context& c, const Path& p0, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Space& s0);
static Space routine_316(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_312(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_270(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_289(Context& c, const Path& p0, const Space& s0);
static Space routine_223(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_294(Context& c, const Path& p0, const Space& s0);
static Space routine_230(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_141(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_242(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Space& s0);
static Space routine_252(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_247(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_237(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c) {
  Space v0_18;
  if (!constant_0.empty()) {
    Space v1_17;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_4);
      const Space v2_12 = unite(v2_8,v2_11);
      const Space v2_15 = routine_3(c, constant_6, constant_7);
      const Space v2_16 = unite(v2_12,v2_15);
      v1_17 = compose(constant_0,v2_16);
    }
    v0_18 = compose(constant_0,v1_17);
  }
  return v0_18;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v3_11_result;
  for (int v3_11_label = 1; v3_11_label <= 2; ++v3_11_label) {
    const Space v3_11_tail = child(s0,v3_11_label);
    if (v3_11_tail.empty()) continue;
    const Path v3_11_head{v3_11_label};
    const Space v4_2 = singleton(v3_11_head);
    const Space v4_3 = intersect(constant_8,v4_2);
    const Space v4_4 = (has_head(v4_3) ? constant_9 : Space{});
    const Space v4_5 = subtract(constant_0,v4_4);
    Space v4_8;
    if (!v4_5.empty()) {
      const Path v5_6 = concat_path(p0,v3_11_head);
      Space v5_7_result;
      for (int v5_7_label = 1; v5_7_label <= 2; ++v5_7_label) {
        const Space v5_7_tail = child(v3_11_tail,v5_7_label);
        if (v5_7_tail.empty()) continue;
        const Path v5_7_head{v5_7_label};
        const Space v6_2 = singleton(v5_7_head);
        const Space v6_3 = intersect(constant_8,v6_2);
        const Space v6_4 = (has_head(v6_3) ? constant_9 : Space{});
        const Space v6_5 = subtract(constant_0,v6_4);
        Space v6_8;
        if (!v6_5.empty()) {
          const Path v7_6 = concat_path(v5_6,v5_7_head);
          const Space v7_7 = routine_4(c, v7_6, v5_7_tail);
          v6_8 = compose(v6_5,v7_7);
        }
        const Space v6_9 = intersect(constant_8,v6_2);
        const Space v6_10 = (has_head(v6_9) ? constant_9 : Space{});
        Space v6_12;
        if (!v6_10.empty()) {
          const Path v8_6 = concat_path(v5_6,v5_7_head);
          const Space v8_11 = routine_5(c, v8_6, v5_7_tail);
          v6_12 = compose(v6_10,v8_11);
        }
        const Space v6_13 = unite(v6_8,v6_12);
        v5_7_result = unite(v5_7_result,v6_13);
      }
      const Space v5_7 = std::move(v5_7_result);
      v4_8 = compose(v4_5,v5_7);
    }
    const Space v4_9 = intersect(constant_8,v4_2);
    const Space v4_10 = (has_head(v4_9) ? constant_9 : Space{});
    Space v4_12;
    if (!v4_10.empty()) {
      const Path v9_6 = concat_path(p0,v3_11_head);
      Space v9_11_result;
      for (int v9_11_label = 1; v9_11_label <= 2; ++v9_11_label) {
        const Space v9_11_tail = child(v3_11_tail,v9_11_label);
        if (v9_11_tail.empty()) continue;
        const Path v9_11_head{v9_11_label};
        const Space v10_2 = singleton(v9_11_head);
        const Space v10_3 = intersect(constant_8,v10_2);
        const Space v10_4 = (has_head(v10_3) ? constant_9 : Space{});
        const Space v10_5 = subtract(constant_0,v10_4);
        Space v10_8;
        if (!v10_5.empty()) {
          const Path v11_6 = concat_path(v9_6,v9_11_head);
          const Space v11_7 = routine_4(c, v11_6, v9_11_tail);
          v10_8 = compose(v10_5,v11_7);
        }
        const Space v10_9 = intersect(constant_8,v10_2);
        const Space v10_10 = (has_head(v10_9) ? constant_9 : Space{});
        Space v10_12;
        if (!v10_10.empty()) {
          const Path v12_6 = concat_path(v9_6,v9_11_head);
          const Space v12_11 = routine_3(c, v12_6, v9_11_tail);
          v10_12 = compose(v10_10,v12_11);
        }
        const Space v10_13 = unite(v10_8,v10_12);
        v9_11_result = unite(v9_11_result,v10_13);
      }
      const Space v9_11 = std::move(v9_11_result);
      v4_12 = compose(v4_10,v9_11);
    }
    const Space v4_13 = unite(v4_8,v4_12);
    v3_11_result = unite(v3_11_result,v4_13);
  }
  const Space v3_11 = std::move(v3_11_result);
  return v3_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v13_11_result;
  for (int v13_11_label = 1; v13_11_label <= 2; ++v13_11_label) {
    const Space v13_11_tail = child(s0,v13_11_label);
    if (v13_11_tail.empty()) continue;
    const Path v13_11_head{v13_11_label};
    const Space v14_2 = singleton(v13_11_head);
    const Space v14_3 = intersect(constant_8,v14_2);
    const Space v14_4 = (has_head(v14_3) ? constant_9 : Space{});
    const Space v14_5 = subtract(constant_0,v14_4);
    Space v14_8;
    if (!v14_5.empty()) {
      const Path v15_6 = concat_path(p0,v13_11_head);
      Space v15_7_result;
      for (int v15_7_label = 1; v15_7_label <= 2; ++v15_7_label) {
        const Space v15_7_tail = child(v13_11_tail,v15_7_label);
        if (v15_7_tail.empty()) continue;
        const Path v15_7_head{v15_7_label};
        const Space v16_2 = singleton(v15_7_head);
        const Space v16_3 = intersect(constant_8,v16_2);
        const Space v16_4 = (has_head(v16_3) ? constant_9 : Space{});
        const Space v16_5 = subtract(constant_0,v16_4);
        Space v16_8;
        if (!v16_5.empty()) {
          const Path v17_6 = concat_path(v15_6,v15_7_head);
          const Space v17_7 = routine_4(c, v17_6, v15_7_tail);
          v16_8 = compose(v16_5,v17_7);
        }
        const Space v16_9 = intersect(constant_8,v16_2);
        const Space v16_10 = (has_head(v16_9) ? constant_9 : Space{});
        Space v16_12;
        if (!v16_10.empty()) {
          const Path v18_6 = concat_path(v15_6,v15_7_head);
          const Space v18_11 = routine_5(c, v18_6, v15_7_tail);
          v16_12 = compose(v16_10,v18_11);
        }
        const Space v16_13 = unite(v16_8,v16_12);
        v15_7_result = unite(v15_7_result,v16_13);
      }
      const Space v15_7 = std::move(v15_7_result);
      v14_8 = compose(v14_5,v15_7);
    }
    const Space v14_9 = intersect(constant_8,v14_2);
    const Space v14_10 = (has_head(v14_9) ? constant_9 : Space{});
    Space v14_12;
    if (!v14_10.empty()) {
      const Path v19_6 = concat_path(p0,v13_11_head);
      Space v19_11_result;
      for (int v19_11_label = 1; v19_11_label <= 2; ++v19_11_label) {
        const Space v19_11_tail = child(v13_11_tail,v19_11_label);
        if (v19_11_tail.empty()) continue;
        const Path v19_11_head{v19_11_label};
        const Space v20_2 = singleton(v19_11_head);
        const Space v20_3 = intersect(constant_8,v20_2);
        const Space v20_4 = (has_head(v20_3) ? constant_9 : Space{});
        const Space v20_5 = subtract(constant_0,v20_4);
        Space v20_7;
        if (!v20_5.empty()) {
          const Space v21_6 = routine_6(c, v19_11_head, v19_6, v19_11_tail);
          v20_7 = compose(v20_5,v21_6);
        }
        const Space v20_8 = intersect(constant_8,v20_2);
        const Space v20_9 = (has_head(v20_8) ? constant_9 : Space{});
        Space v20_11;
        if (!v20_9.empty()) {
          const Space v22_10 = routine_7(c, v19_11_head, v19_6, v19_11_tail);
          v20_11 = compose(v20_9,v22_10);
        }
        const Space v20_12 = unite(v20_7,v20_11);
        v19_11_result = unite(v19_11_result,v20_12);
      }
      const Space v19_11 = std::move(v19_11_result);
      v14_12 = compose(v14_10,v19_11);
    }
    const Space v14_13 = unite(v14_8,v14_12);
    v13_11_result = unite(v13_11_result,v14_13);
  }
  const Space v13_11 = std::move(v13_11_result);
  return v13_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v23_11_result;
  for (int v23_11_label = 1; v23_11_label <= 2; ++v23_11_label) {
    const Space v23_11_tail = child(s0,v23_11_label);
    if (v23_11_tail.empty()) continue;
    const Path v23_11_head{v23_11_label};
    const Space v24_2 = singleton(v23_11_head);
    const Space v24_3 = intersect(constant_8,v24_2);
    const Space v24_4 = (has_head(v24_3) ? constant_9 : Space{});
    const Space v24_5 = subtract(constant_0,v24_4);
    Space v24_7;
    if (!v24_5.empty()) {
      Space v25_6_result;
      for (int v25_6_label = 1; v25_6_label <= 2; ++v25_6_label) {
        const Space v25_6_tail = child(v23_11_tail,v25_6_label);
        if (v25_6_tail.empty()) continue;
        const Path v25_6_head{v25_6_label};
        const Space v26_2 = singleton(v25_6_head);
        const Space v26_3 = intersect(constant_8,v26_2);
        const Space v26_4 = (has_head(v26_3) ? constant_9 : Space{});
        const Space v26_5 = subtract(constant_0,v26_4);
        Space v26_8;
        if (!v26_5.empty()) {
          const Path v27_6 = concat_path(v23_11_head,v25_6_head);
          const Space v27_7 = routine_8(c, v27_6, p0, v25_6_tail);
          v26_8 = compose(v26_5,v27_7);
        }
        const Space v26_9 = intersect(constant_8,v26_2);
        const Space v26_10 = (has_head(v26_9) ? constant_9 : Space{});
        Space v26_12;
        if (!v26_10.empty()) {
          const Path v28_6 = concat_path(v23_11_head,v25_6_head);
          const Space v28_11 = routine_9(c, v28_6, p0, v25_6_tail);
          v26_12 = compose(v26_10,v28_11);
        }
        const Space v26_13 = unite(v26_8,v26_12);
        v25_6_result = unite(v25_6_result,v26_13);
      }
      const Space v25_6 = std::move(v25_6_result);
      v24_7 = compose(v24_5,v25_6);
    }
    const Space v24_8 = intersect(constant_8,v24_2);
    const Space v24_9 = (has_head(v24_8) ? constant_9 : Space{});
    Space v24_11;
    if (!v24_9.empty()) {
      Space v29_10_result;
      for (int v29_10_label = 1; v29_10_label <= 2; ++v29_10_label) {
        const Space v29_10_tail = child(v23_11_tail,v29_10_label);
        if (v29_10_tail.empty()) continue;
        const Path v29_10_head{v29_10_label};
        const Space v30_2 = singleton(v29_10_head);
        const Space v30_3 = intersect(constant_8,v30_2);
        const Space v30_4 = (has_head(v30_3) ? constant_9 : Space{});
        const Space v30_5 = subtract(constant_0,v30_4);
        Space v30_8;
        if (!v30_5.empty()) {
          const Path v31_6 = concat_path(v23_11_head,v29_10_head);
          const Space v31_7 = routine_8(c, v31_6, p0, v29_10_tail);
          v30_8 = compose(v30_5,v31_7);
        }
        const Space v30_9 = intersect(constant_8,v30_2);
        const Space v30_10 = (has_head(v30_9) ? constant_9 : Space{});
        Space v30_12;
        if (!v30_10.empty()) {
          const Path v32_6 = concat_path(v23_11_head,v29_10_head);
          const Space v32_11 = routine_10(c, v32_6, p0, v29_10_tail);
          v30_12 = compose(v30_10,v32_11);
        }
        const Space v30_13 = unite(v30_8,v30_12);
        v29_10_result = unite(v29_10_result,v30_13);
      }
      const Space v29_10 = std::move(v29_10_result);
      v24_11 = compose(v24_9,v29_10);
    }
    const Space v24_12 = unite(v24_7,v24_11);
    v23_11_result = unite(v23_11_result,v24_12);
  }
  const Space v23_11 = std::move(v23_11_result);
  return v23_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v33_4_result;
  for (int v33_4_label = 1; v33_4_label <= 2; ++v33_4_label) {
    const Space v33_4_tail = child(s0,v33_4_label);
    if (v33_4_tail.empty()) continue;
    const Path v33_4_head{v33_4_label};
    const Space v34_2 = singleton(v33_4_head);
    const Space v34_3 = intersect(constant_8,v34_2);
    const Space v34_4 = (has_head(v34_3) ? constant_9 : Space{});
    Space v34_7;
    if (!v34_4.empty()) {
      const Path v35_5 = concat_path(p0,v33_4_head);
      Space v35_6_result;
      for (int v35_6_label = 1; v35_6_label <= 2; ++v35_6_label) {
        const Space v35_6_tail = child(v33_4_tail,v35_6_label);
        if (v35_6_tail.empty()) continue;
        const Path v35_6_head{v35_6_label};
        const Space v36_2 = singleton(v35_6_head);
        const Space v36_3 = intersect(constant_8,v36_2);
        const Space v36_4 = (has_head(v36_3) ? constant_9 : Space{});
        Space v36_7;
        if (!v36_4.empty()) {
          const Path v37_5 = concat_path(v35_5,v35_6_head);
          const Space v37_6 = routine_3(c, v37_5, v35_6_tail);
          v36_7 = compose(v36_4,v37_6);
        }
        v35_6_result = unite(v35_6_result,v36_7);
      }
      const Space v35_6 = std::move(v35_6_result);
      v34_7 = compose(v34_4,v35_6);
    }
    v33_4_result = unite(v33_4_result,v34_7);
  }
  const Space v33_4 = std::move(v33_4_result);
  return v33_4;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  Space v38_6_result;
  for (int v38_6_label = 1; v38_6_label <= 2; ++v38_6_label) {
    const Space v38_6_tail = child(s0,v38_6_label);
    if (v38_6_tail.empty()) continue;
    const Path v38_6_head{v38_6_label};
    const Space v39_2 = singleton(v38_6_head);
    const Space v39_3 = intersect(constant_8,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_9 : Space{});
    Space v39_7;
    if (!v39_4.empty()) {
      const Path v40_5 = concat_path(p0,v38_6_head);
      Space v40_6_result;
      for (int v40_6_label = 1; v40_6_label <= 2; ++v40_6_label) {
        const Space v40_6_tail = child(v38_6_tail,v40_6_label);
        if (v40_6_tail.empty()) continue;
        const Path v40_6_head{v40_6_label};
        const Space v41_2 = singleton(v40_6_head);
        const Space v41_3 = intersect(constant_8,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_9 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_7;
        if (!v41_5.empty()) {
          const Space v42_6 = routine_6(c, v40_6_head, v40_5, v40_6_tail);
          v41_7 = compose(v41_5,v42_6);
        }
        const Space v41_8 = intersect(constant_8,v41_2);
        const Space v41_9 = (has_head(v41_8) ? constant_9 : Space{});
        Space v41_11;
        if (!v41_9.empty()) {
          const Space v43_10 = routine_7(c, v40_6_head, v40_5, v40_6_tail);
          v41_11 = compose(v41_9,v43_10);
        }
        const Space v41_12 = unite(v41_7,v41_11);
        v40_6_result = unite(v40_6_result,v41_12);
      }
      const Space v40_6 = std::move(v40_6_result);
      v39_7 = compose(v39_4,v40_6);
    }
    v38_6_result = unite(v38_6_result,v39_7);
  }
  const Space v38_6 = std::move(v38_6_result);
  return v38_6;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v44_12_result;
  for (int v44_12_label = 1; v44_12_label <= 2; ++v44_12_label) {
    const Space v44_12_tail = child(s0,v44_12_label);
    if (v44_12_tail.empty()) continue;
    const Path v44_12_head{v44_12_label};
    const Space v45_2 = singleton(v44_12_head);
    const Space v45_3 = intersect(constant_8,v45_2);
    const Space v45_4 = (has_head(v45_3) ? constant_9 : Space{});
    const Space v45_5 = subtract(constant_0,v45_4);
    Space v45_8;
    if (!v45_5.empty()) {
      const Path v46_6 = concat_path(p0,v44_12_head);
      Space v46_7_result;
      for (int v46_7_label = 1; v46_7_label <= 2; ++v46_7_label) {
        const Space v46_7_tail = child(v44_12_tail,v46_7_label);
        if (v46_7_tail.empty()) continue;
        const Path v46_7_head{v46_7_label};
        const Space v47_2 = singleton(v46_7_head);
        const Space v47_3 = intersect(constant_8,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_9 : Space{});
        const Space v47_5 = subtract(constant_0,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_7_head);
          const Space v48_7 = routine_11(c, v48_6, p1, v46_7_tail);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_8,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_9 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_7_head);
          const Space v49_11 = routine_12(c, v49_6, p1, v46_7_tail);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_7_result = unite(v46_7_result,v47_13);
      }
      const Space v46_7 = std::move(v46_7_result);
      v45_8 = compose(v45_5,v46_7);
    }
    const Space v45_9 = intersect(constant_8,v45_2);
    const Space v45_10 = (has_head(v45_9) ? constant_9 : Space{});
    Space v45_12;
    if (!v45_10.empty()) {
      const Path v50_6 = concat_path(p0,v44_12_head);
      Space v50_11_result;
      for (int v50_11_label = 1; v50_11_label <= 2; ++v50_11_label) {
        const Space v50_11_tail = child(v44_12_tail,v50_11_label);
        if (v50_11_tail.empty()) continue;
        const Path v50_11_head{v50_11_label};
        const Space v51_2 = singleton(v50_11_head);
        const Space v51_3 = intersect(constant_8,v51_2);
        const Space v51_4 = (has_head(v51_3) ? constant_9 : Space{});
        const Space v51_5 = subtract(constant_0,v51_4);
        Space v51_8;
        if (!v51_5.empty()) {
          const Path v52_6 = concat_path(v50_6,v50_11_head);
          const Space v52_7 = routine_11(c, v52_6, p1, v50_11_tail);
          v51_8 = compose(v51_5,v52_7);
        }
        const Space v51_9 = intersect(constant_8,v51_2);
        const Space v51_10 = (has_head(v51_9) ? constant_9 : Space{});
        Space v51_12;
        if (!v51_10.empty()) {
          const Path v53_6 = concat_path(v50_6,v50_11_head);
          const Space v53_11 = routine_10(c, v53_6, p1, v50_11_tail);
          v51_12 = compose(v51_10,v53_11);
        }
        const Space v51_13 = unite(v51_8,v51_12);
        v50_11_result = unite(v50_11_result,v51_13);
      }
      const Space v50_11 = std::move(v50_11_result);
      v45_12 = compose(v45_10,v50_11);
    }
    const Space v45_13 = unite(v45_8,v45_12);
    v44_12_result = unite(v44_12_result,v45_13);
  }
  const Space v44_12 = std::move(v44_12_result);
  return v44_12;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v54_12_result;
  for (int v54_12_label = 1; v54_12_label <= 2; ++v54_12_label) {
    const Space v54_12_tail = child(s0,v54_12_label);
    if (v54_12_tail.empty()) continue;
    const Path v54_12_head{v54_12_label};
    const Space v55_2 = singleton(v54_12_head);
    const Space v55_3 = intersect(constant_8,v55_2);
    const Space v55_4 = (has_head(v55_3) ? constant_9 : Space{});
    const Space v55_5 = subtract(constant_0,v55_4);
    Space v55_8;
    if (!v55_5.empty()) {
      const Path v56_6 = concat_path(p0,v54_12_head);
      Space v56_7_result;
      for (int v56_7_label = 1; v56_7_label <= 2; ++v56_7_label) {
        const Space v56_7_tail = child(v54_12_tail,v56_7_label);
        if (v56_7_tail.empty()) continue;
        const Path v56_7_head{v56_7_label};
        const Space v57_2 = singleton(v56_7_head);
        const Space v57_3 = intersect(constant_8,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_9 : Space{});
        const Space v57_5 = subtract(constant_0,v57_4);
        Space v57_8;
        if (!v57_5.empty()) {
          const Path v58_6 = concat_path(v56_6,v56_7_head);
          const Space v58_7 = routine_11(c, v58_6, p1, v56_7_tail);
          v57_8 = compose(v57_5,v58_7);
        }
        const Space v57_9 = intersect(constant_8,v57_2);
        const Space v57_10 = (has_head(v57_9) ? constant_9 : Space{});
        Space v57_12;
        if (!v57_10.empty()) {
          const Path v59_6 = concat_path(v56_6,v56_7_head);
          const Space v59_11 = routine_12(c, v59_6, p1, v56_7_tail);
          v57_12 = compose(v57_10,v59_11);
        }
        const Space v57_13 = unite(v57_8,v57_12);
        v56_7_result = unite(v56_7_result,v57_13);
      }
      const Space v56_7 = std::move(v56_7_result);
      v55_8 = compose(v55_5,v56_7);
    }
    const Space v55_9 = intersect(constant_8,v55_2);
    const Space v55_10 = (has_head(v55_9) ? constant_9 : Space{});
    Space v55_12;
    if (!v55_10.empty()) {
      const Path v60_6 = concat_path(p0,v54_12_head);
      Space v60_11_result;
      for (int v60_11_label = 1; v60_11_label <= 2; ++v60_11_label) {
        const Space v60_11_tail = child(v54_12_tail,v60_11_label);
        if (v60_11_tail.empty()) continue;
        const Path v60_11_head{v60_11_label};
        const Space v61_2 = singleton(v60_11_head);
        const Space v61_3 = intersect(constant_8,v61_2);
        const Space v61_4 = (has_head(v61_3) ? constant_9 : Space{});
        const Space v61_5 = subtract(constant_0,v61_4);
        Space v61_7;
        if (!v61_5.empty()) {
          const Space v62_6 = routine_13(c, v60_11_head, p1, v60_6, v60_11_tail);
          v61_7 = compose(v61_5,v62_6);
        }
        const Space v61_8 = intersect(constant_8,v61_2);
        const Space v61_9 = (has_head(v61_8) ? constant_9 : Space{});
        Space v61_11;
        if (!v61_9.empty()) {
          const Space v63_10 = routine_14(c, v60_11_head, p1, v60_6, v60_11_tail);
          v61_11 = compose(v61_9,v63_10);
        }
        const Space v61_12 = unite(v61_7,v61_11);
        v60_11_result = unite(v60_11_result,v61_12);
      }
      const Space v60_11 = std::move(v60_11_result);
      v55_12 = compose(v55_10,v60_11);
    }
    const Space v55_13 = unite(v55_8,v55_12);
    v54_12_result = unite(v54_12_result,v55_13);
  }
  const Space v54_12 = std::move(v54_12_result);
  return v54_12;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v64_12_result;
  for (int v64_12_label = 1; v64_12_label <= 2; ++v64_12_label) {
    const Space v64_12_tail = child(s0,v64_12_label);
    if (v64_12_tail.empty()) continue;
    const Path v64_12_head{v64_12_label};
    const Space v65_2 = singleton(v64_12_head);
    const Space v65_3 = intersect(constant_8,v65_2);
    const Space v65_4 = (has_head(v65_3) ? constant_9 : Space{});
    const Space v65_5 = subtract(constant_0,v65_4);
    Space v65_8;
    if (!v65_5.empty()) {
      const Path v66_6 = concat_path(p0,v64_12_head);
      Space v66_7_result;
      for (int v66_7_label = 1; v66_7_label <= 2; ++v66_7_label) {
        const Space v66_7_tail = child(v64_12_tail,v66_7_label);
        if (v66_7_tail.empty()) continue;
        const Path v66_7_head{v66_7_label};
        const Space v67_2 = singleton(v66_7_head);
        const Space v67_3 = intersect(constant_8,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_9 : Space{});
        const Space v67_5 = subtract(constant_0,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_7_head);
          const Space v68_7 = routine_15(c, v68_6, p1, v66_7_tail);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_8,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_9 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_7_head);
          const Space v69_11 = routine_16(c, v69_6, p1, v66_7_tail);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_7_result = unite(v66_7_result,v67_13);
      }
      const Space v66_7 = std::move(v66_7_result);
      v65_8 = compose(v65_5,v66_7);
    }
    const Space v65_9 = intersect(constant_8,v65_2);
    const Space v65_10 = (has_head(v65_9) ? constant_9 : Space{});
    Space v65_12;
    if (!v65_10.empty()) {
      const Path v70_6 = concat_path(p0,v64_12_head);
      Space v70_11_result;
      for (int v70_11_label = 1; v70_11_label <= 2; ++v70_11_label) {
        const Space v70_11_tail = child(v64_12_tail,v70_11_label);
        if (v70_11_tail.empty()) continue;
        const Path v70_11_head{v70_11_label};
        const Space v71_2 = singleton(v70_11_head);
        const Space v71_3 = intersect(constant_8,v71_2);
        const Space v71_4 = (has_head(v71_3) ? constant_9 : Space{});
        const Space v71_5 = subtract(constant_0,v71_4);
        Space v71_8;
        if (!v71_5.empty()) {
          const Path v72_6 = concat_path(v70_6,v70_11_head);
          const Space v72_7 = routine_15(c, v72_6, p1, v70_11_tail);
          v71_8 = compose(v71_5,v72_7);
        }
        const Space v71_9 = intersect(constant_8,v71_2);
        const Space v71_10 = (has_head(v71_9) ? constant_9 : Space{});
        Space v71_12;
        if (!v71_10.empty()) {
          const Path v73_6 = concat_path(v70_6,v70_11_head);
          const Space v73_11 = routine_10(c, v73_6, p1, v70_11_tail);
          v71_12 = compose(v71_10,v73_11);
        }
        const Space v71_13 = unite(v71_8,v71_12);
        v70_11_result = unite(v70_11_result,v71_13);
      }
      const Space v70_11 = std::move(v70_11_result);
      v65_12 = compose(v65_10,v70_11);
    }
    const Space v65_13 = unite(v65_8,v65_12);
    v64_12_result = unite(v64_12_result,v65_13);
  }
  const Space v64_12 = std::move(v64_12_result);
  return v64_12;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v74_12_result;
  for (int v74_12_label = 1; v74_12_label <= 2; ++v74_12_label) {
    const Space v74_12_tail = child(s0,v74_12_label);
    if (v74_12_tail.empty()) continue;
    const Path v74_12_head{v74_12_label};
    const Space v75_2 = singleton(v74_12_head);
    const Space v75_3 = intersect(constant_8,v75_2);
    const Space v75_4 = (has_head(v75_3) ? constant_9 : Space{});
    const Space v75_5 = subtract(constant_0,v75_4);
    Space v75_8;
    if (!v75_5.empty()) {
      const Path v76_6 = concat_path(p0,v74_12_head);
      Space v76_7_result;
      for (int v76_7_label = 1; v76_7_label <= 2; ++v76_7_label) {
        const Space v76_7_tail = child(v74_12_tail,v76_7_label);
        if (v76_7_tail.empty()) continue;
        const Path v76_7_head{v76_7_label};
        const Space v77_2 = singleton(v76_7_head);
        const Space v77_3 = intersect(constant_8,v77_2);
        const Space v77_4 = (has_head(v77_3) ? constant_9 : Space{});
        const Space v77_5 = subtract(constant_0,v77_4);
        Space v77_8;
        if (!v77_5.empty()) {
          const Path v78_6 = concat_path(v76_6,v76_7_head);
          const Space v78_7 = routine_15(c, v78_6, p1, v76_7_tail);
          v77_8 = compose(v77_5,v78_7);
        }
        const Space v77_9 = intersect(constant_8,v77_2);
        const Space v77_10 = (has_head(v77_9) ? constant_9 : Space{});
        Space v77_12;
        if (!v77_10.empty()) {
          const Path v79_6 = concat_path(v76_6,v76_7_head);
          const Space v79_11 = routine_16(c, v79_6, p1, v76_7_tail);
          v77_12 = compose(v77_10,v79_11);
        }
        const Space v77_13 = unite(v77_8,v77_12);
        v76_7_result = unite(v76_7_result,v77_13);
      }
      const Space v76_7 = std::move(v76_7_result);
      v75_8 = compose(v75_5,v76_7);
    }
    const Space v75_9 = intersect(constant_8,v75_2);
    const Space v75_10 = (has_head(v75_9) ? constant_9 : Space{});
    Space v75_12;
    if (!v75_10.empty()) {
      const Path v80_6 = concat_path(p0,v74_12_head);
      Space v80_11_result;
      for (int v80_11_label = 1; v80_11_label <= 2; ++v80_11_label) {
        const Space v80_11_tail = child(v74_12_tail,v80_11_label);
        if (v80_11_tail.empty()) continue;
        const Path v80_11_head{v80_11_label};
        const Space v81_2 = singleton(v80_11_head);
        const Space v81_3 = intersect(constant_8,v81_2);
        const Space v81_4 = (has_head(v81_3) ? constant_9 : Space{});
        const Space v81_5 = subtract(constant_0,v81_4);
        Space v81_7;
        if (!v81_5.empty()) {
          const Space v82_6 = routine_13(c, v80_11_head, p1, v80_6, v80_11_tail);
          v81_7 = compose(v81_5,v82_6);
        }
        const Space v81_8 = intersect(constant_8,v81_2);
        const Space v81_9 = (has_head(v81_8) ? constant_9 : Space{});
        Space v81_11;
        if (!v81_9.empty()) {
          const Space v83_10 = routine_14(c, v80_11_head, p1, v80_6, v80_11_tail);
          v81_11 = compose(v81_9,v83_10);
        }
        const Space v81_12 = unite(v81_7,v81_11);
        v80_11_result = unite(v80_11_result,v81_12);
      }
      const Space v80_11 = std::move(v80_11_result);
      v75_12 = compose(v75_10,v80_11);
    }
    const Space v75_13 = unite(v75_8,v75_12);
    v74_12_result = unite(v74_12_result,v75_13);
  }
  const Space v74_12 = std::move(v74_12_result);
  return v74_12;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v84_12_result;
  for (int v84_12_label = 1; v84_12_label <= 2; ++v84_12_label) {
    const Space v84_12_tail = child(s0,v84_12_label);
    if (v84_12_tail.empty()) continue;
    const Path v84_12_head{v84_12_label};
    const Space v85_2 = singleton(v84_12_head);
    const Space v85_3 = intersect(constant_8,v85_2);
    const Space v85_4 = (has_head(v85_3) ? constant_9 : Space{});
    const Space v85_5 = subtract(constant_0,v85_4);
    Space v85_7;
    if (!v85_5.empty()) {
      Space v86_6_result;
      for (int v86_6_label = 1; v86_6_label <= 2; ++v86_6_label) {
        const Space v86_6_tail = child(v84_12_tail,v86_6_label);
        if (v86_6_tail.empty()) continue;
        const Path v86_6_head{v86_6_label};
        const Space v87_2 = singleton(v86_6_head);
        const Space v87_3 = intersect(constant_8,v87_2);
        const Space v87_4 = (has_head(v87_3) ? constant_9 : Space{});
        const Space v87_5 = subtract(constant_0,v87_4);
        Space v87_8;
        if (!v87_5.empty()) {
          const Path v88_6 = concat_path(v84_12_head,v86_6_head);
          const Space v88_7 = routine_17(c, v88_6, p1, p0, v86_6_tail);
          v87_8 = compose(v87_5,v88_7);
        }
        const Space v87_9 = intersect(constant_8,v87_2);
        const Space v87_10 = (has_head(v87_9) ? constant_9 : Space{});
        Space v87_12;
        if (!v87_10.empty()) {
          const Path v89_6 = concat_path(v84_12_head,v86_6_head);
          const Space v89_11 = routine_18(c, v89_6, p1, p0, v86_6_tail);
          v87_12 = compose(v87_10,v89_11);
        }
        const Space v87_13 = unite(v87_8,v87_12);
        v86_6_result = unite(v86_6_result,v87_13);
      }
      const Space v86_6 = std::move(v86_6_result);
      v85_7 = compose(v85_5,v86_6);
    }
    const Space v85_8 = intersect(constant_8,v85_2);
    const Space v85_9 = (has_head(v85_8) ? constant_9 : Space{});
    Space v85_11;
    if (!v85_9.empty()) {
      Space v90_10_result;
      for (int v90_10_label = 1; v90_10_label <= 2; ++v90_10_label) {
        const Space v90_10_tail = child(v84_12_tail,v90_10_label);
        if (v90_10_tail.empty()) continue;
        const Path v90_10_head{v90_10_label};
        const Space v91_2 = singleton(v90_10_head);
        const Space v91_3 = intersect(constant_8,v91_2);
        const Space v91_4 = (has_head(v91_3) ? constant_9 : Space{});
        const Space v91_5 = subtract(constant_0,v91_4);
        Space v91_8;
        if (!v91_5.empty()) {
          const Path v92_6 = concat_path(v84_12_head,v90_10_head);
          const Space v92_7 = routine_17(c, v92_6, p1, p0, v90_10_tail);
          v91_8 = compose(v91_5,v92_7);
        }
        const Space v91_9 = intersect(constant_8,v91_2);
        const Space v91_10 = (has_head(v91_9) ? constant_9 : Space{});
        Space v91_12;
        if (!v91_10.empty()) {
          const Path v93_6 = concat_path(v84_12_head,v90_10_head);
          const Space v93_11 = routine_19(c, v93_6, p1, p0, v90_10_tail);
          v91_12 = compose(v91_10,v93_11);
        }
        const Space v91_13 = unite(v91_8,v91_12);
        v90_10_result = unite(v90_10_result,v91_13);
      }
      const Space v90_10 = std::move(v90_10_result);
      v85_11 = compose(v85_9,v90_10);
    }
    const Space v85_12 = unite(v85_7,v85_11);
    v84_12_result = unite(v84_12_result,v85_12);
  }
  const Space v84_12 = std::move(v84_12_result);
  return v84_12;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v94_12_result;
  for (int v94_12_label = 1; v94_12_label <= 2; ++v94_12_label) {
    const Space v94_12_tail = child(s0,v94_12_label);
    if (v94_12_tail.empty()) continue;
    const Path v94_12_head{v94_12_label};
    const Space v95_2 = singleton(v94_12_head);
    const Space v95_3 = intersect(constant_8,v95_2);
    const Space v95_4 = (has_head(v95_3) ? constant_9 : Space{});
    const Space v95_5 = subtract(constant_0,v95_4);
    Space v95_8;
    if (!v95_5.empty()) {
      const Path v96_6 = concat_path(p0,v94_12_head);
      Space v96_7_result;
      for (int v96_7_label = 1; v96_7_label <= 2; ++v96_7_label) {
        const Space v96_7_tail = child(v94_12_tail,v96_7_label);
        if (v96_7_tail.empty()) continue;
        const Path v96_7_head{v96_7_label};
        const Space v97_2 = singleton(v96_7_head);
        const Space v97_3 = intersect(constant_8,v97_2);
        const Space v97_4 = (has_head(v97_3) ? constant_9 : Space{});
        const Space v97_5 = subtract(constant_0,v97_4);
        Space v97_8;
        if (!v97_5.empty()) {
          const Path v98_6 = concat_path(v96_6,v96_7_head);
          const Space v98_7 = routine_20(c, v98_6, p1, v96_7_tail);
          v97_8 = compose(v97_5,v98_7);
        }
        const Space v97_9 = intersect(constant_8,v97_2);
        const Space v97_10 = (has_head(v97_9) ? constant_9 : Space{});
        Space v97_12;
        if (!v97_10.empty()) {
          const Path v99_6 = concat_path(v96_6,v96_7_head);
          const Space v99_11 = routine_21(c, v99_6, p1, v96_7_tail);
          v97_12 = compose(v97_10,v99_11);
        }
        const Space v97_13 = unite(v97_8,v97_12);
        v96_7_result = unite(v96_7_result,v97_13);
      }
      const Space v96_7 = std::move(v96_7_result);
      v95_8 = compose(v95_5,v96_7);
    }
    const Space v95_9 = intersect(constant_8,v95_2);
    const Space v95_10 = (has_head(v95_9) ? constant_9 : Space{});
    Space v95_12;
    if (!v95_10.empty()) {
      const Path v100_6 = concat_path(p0,v94_12_head);
      Space v100_11_result;
      for (int v100_11_label = 1; v100_11_label <= 2; ++v100_11_label) {
        const Space v100_11_tail = child(v94_12_tail,v100_11_label);
        if (v100_11_tail.empty()) continue;
        const Path v100_11_head{v100_11_label};
        const Space v101_2 = singleton(v100_11_head);
        const Space v101_3 = intersect(constant_8,v101_2);
        const Space v101_4 = (has_head(v101_3) ? constant_9 : Space{});
        const Space v101_5 = subtract(constant_0,v101_4);
        Space v101_8;
        if (!v101_5.empty()) {
          const Path v102_6 = concat_path(v100_6,v100_11_head);
          const Space v102_7 = routine_20(c, v102_6, p1, v100_11_tail);
          v101_8 = compose(v101_5,v102_7);
        }
        const Space v101_9 = intersect(constant_8,v101_2);
        const Space v101_10 = (has_head(v101_9) ? constant_9 : Space{});
        Space v101_12;
        if (!v101_10.empty()) {
          const Path v103_6 = concat_path(v100_6,v100_11_head);
          const Space v103_11 = routine_10(c, v103_6, p1, v100_11_tail);
          v101_12 = compose(v101_10,v103_11);
        }
        const Space v101_13 = unite(v101_8,v101_12);
        v100_11_result = unite(v100_11_result,v101_13);
      }
      const Space v100_11 = std::move(v100_11_result);
      v95_12 = compose(v95_10,v100_11);
    }
    const Space v95_13 = unite(v95_8,v95_12);
    v94_12_result = unite(v94_12_result,v95_13);
  }
  const Space v94_12 = std::move(v94_12_result);
  return v94_12;
}

static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v104_12_result;
  for (int v104_12_label = 1; v104_12_label <= 2; ++v104_12_label) {
    const Space v104_12_tail = child(s0,v104_12_label);
    if (v104_12_tail.empty()) continue;
    const Path v104_12_head{v104_12_label};
    const Space v105_2 = singleton(v104_12_head);
    const Space v105_3 = intersect(constant_8,v105_2);
    const Space v105_4 = (has_head(v105_3) ? constant_9 : Space{});
    const Space v105_5 = subtract(constant_0,v105_4);
    Space v105_8;
    if (!v105_5.empty()) {
      const Path v106_6 = concat_path(p0,v104_12_head);
      Space v106_7_result;
      for (int v106_7_label = 1; v106_7_label <= 2; ++v106_7_label) {
        const Space v106_7_tail = child(v104_12_tail,v106_7_label);
        if (v106_7_tail.empty()) continue;
        const Path v106_7_head{v106_7_label};
        const Space v107_2 = singleton(v106_7_head);
        const Space v107_3 = intersect(constant_8,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_9 : Space{});
        const Space v107_5 = subtract(constant_0,v107_4);
        Space v107_8;
        if (!v107_5.empty()) {
          const Path v108_6 = concat_path(v106_6,v106_7_head);
          const Space v108_7 = routine_20(c, v108_6, p1, v106_7_tail);
          v107_8 = compose(v107_5,v108_7);
        }
        const Space v107_9 = intersect(constant_8,v107_2);
        const Space v107_10 = (has_head(v107_9) ? constant_9 : Space{});
        Space v107_12;
        if (!v107_10.empty()) {
          const Path v109_6 = concat_path(v106_6,v106_7_head);
          const Space v109_11 = routine_21(c, v109_6, p1, v106_7_tail);
          v107_12 = compose(v107_10,v109_11);
        }
        const Space v107_13 = unite(v107_8,v107_12);
        v106_7_result = unite(v106_7_result,v107_13);
      }
      const Space v106_7 = std::move(v106_7_result);
      v105_8 = compose(v105_5,v106_7);
    }
    const Space v105_9 = intersect(constant_8,v105_2);
    const Space v105_10 = (has_head(v105_9) ? constant_9 : Space{});
    Space v105_12;
    if (!v105_10.empty()) {
      const Path v110_6 = concat_path(p0,v104_12_head);
      Space v110_11_result;
      for (int v110_11_label = 1; v110_11_label <= 2; ++v110_11_label) {
        const Space v110_11_tail = child(v104_12_tail,v110_11_label);
        if (v110_11_tail.empty()) continue;
        const Path v110_11_head{v110_11_label};
        const Space v111_2 = singleton(v110_11_head);
        const Space v111_3 = intersect(constant_8,v111_2);
        const Space v111_4 = (has_head(v111_3) ? constant_9 : Space{});
        const Space v111_5 = subtract(constant_0,v111_4);
        Space v111_7;
        if (!v111_5.empty()) {
          const Space v112_6 = routine_13(c, v110_11_head, p1, v110_6, v110_11_tail);
          v111_7 = compose(v111_5,v112_6);
        }
        const Space v111_8 = intersect(constant_8,v111_2);
        const Space v111_9 = (has_head(v111_8) ? constant_9 : Space{});
        Space v111_11;
        if (!v111_9.empty()) {
          const Space v113_10 = routine_14(c, v110_11_head, p1, v110_6, v110_11_tail);
          v111_11 = compose(v111_9,v113_10);
        }
        const Space v111_12 = unite(v111_7,v111_11);
        v110_11_result = unite(v110_11_result,v111_12);
      }
      const Space v110_11 = std::move(v110_11_result);
      v105_12 = compose(v105_10,v110_11);
    }
    const Space v105_13 = unite(v105_8,v105_12);
    v104_12_result = unite(v104_12_result,v105_13);
  }
  const Space v104_12 = std::move(v104_12_result);
  return v104_12;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v114_13_result;
  for (int v114_13_label = 1; v114_13_label <= 2; ++v114_13_label) {
    const Space v114_13_tail = child(s0,v114_13_label);
    if (v114_13_tail.empty()) continue;
    const Path v114_13_head{v114_13_label};
    const Space v115_2 = singleton(v114_13_head);
    const Space v115_3 = intersect(constant_8,v115_2);
    const Space v115_4 = (has_head(v115_3) ? constant_9 : Space{});
    const Space v115_5 = subtract(constant_0,v115_4);
    Space v115_8;
    if (!v115_5.empty()) {
      const Path v116_6 = concat_path(p0,v114_13_head);
      Space v116_7_result;
      for (int v116_7_label = 1; v116_7_label <= 2; ++v116_7_label) {
        const Space v116_7_tail = child(v114_13_tail,v116_7_label);
        if (v116_7_tail.empty()) continue;
        const Path v116_7_head{v116_7_label};
        const Space v117_2 = singleton(v116_7_head);
        const Space v117_3 = intersect(constant_8,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_9 : Space{});
        const Space v117_5 = subtract(constant_0,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v116_6,v116_7_head);
          const Space v118_7 = routine_22(c, v118_6, p1, p2, v116_7_tail);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_8,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_9 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v116_6,v116_7_head);
          const Space v119_11 = routine_23(c, v119_6, p1, p2, v116_7_tail);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_7_result = unite(v116_7_result,v117_13);
      }
      const Space v116_7 = std::move(v116_7_result);
      v115_8 = compose(v115_5,v116_7);
    }
    const Space v115_9 = intersect(constant_8,v115_2);
    const Space v115_10 = (has_head(v115_9) ? constant_9 : Space{});
    Space v115_12;
    if (!v115_10.empty()) {
      const Path v120_6 = concat_path(p0,v114_13_head);
      Space v120_11_result;
      for (int v120_11_label = 1; v120_11_label <= 2; ++v120_11_label) {
        const Space v120_11_tail = child(v114_13_tail,v120_11_label);
        if (v120_11_tail.empty()) continue;
        const Path v120_11_head{v120_11_label};
        const Space v121_2 = singleton(v120_11_head);
        const Space v121_3 = intersect(constant_8,v121_2);
        const Space v121_4 = (has_head(v121_3) ? constant_9 : Space{});
        const Space v121_5 = subtract(constant_0,v121_4);
        Space v121_8;
        if (!v121_5.empty()) {
          const Path v122_6 = concat_path(v120_6,v120_11_head);
          const Space v122_7 = routine_22(c, v122_6, p1, p2, v120_11_tail);
          v121_8 = compose(v121_5,v122_7);
        }
        const Space v121_9 = intersect(constant_8,v121_2);
        const Space v121_10 = (has_head(v121_9) ? constant_9 : Space{});
        Space v121_12;
        if (!v121_10.empty()) {
          const Path v123_6 = concat_path(v120_6,v120_11_head);
          const Space v123_11 = routine_19(c, v123_6, p1, p2, v120_11_tail);
          v121_12 = compose(v121_10,v123_11);
        }
        const Space v121_13 = unite(v121_8,v121_12);
        v120_11_result = unite(v120_11_result,v121_13);
      }
      const Space v120_11 = std::move(v120_11_result);
      v115_12 = compose(v115_10,v120_11);
    }
    const Space v115_13 = unite(v115_8,v115_12);
    v114_13_result = unite(v114_13_result,v115_13);
  }
  const Space v114_13 = std::move(v114_13_result);
  return v114_13;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v124_13_result;
  for (int v124_13_label = 1; v124_13_label <= 2; ++v124_13_label) {
    const Space v124_13_tail = child(s0,v124_13_label);
    if (v124_13_tail.empty()) continue;
    const Path v124_13_head{v124_13_label};
    const Space v125_2 = singleton(v124_13_head);
    const Space v125_3 = intersect(constant_8,v125_2);
    const Space v125_4 = (has_head(v125_3) ? constant_9 : Space{});
    const Space v125_5 = subtract(constant_0,v125_4);
    Space v125_8;
    if (!v125_5.empty()) {
      const Path v126_6 = concat_path(p0,v124_13_head);
      Space v126_7_result;
      for (int v126_7_label = 1; v126_7_label <= 2; ++v126_7_label) {
        const Space v126_7_tail = child(v124_13_tail,v126_7_label);
        if (v126_7_tail.empty()) continue;
        const Path v126_7_head{v126_7_label};
        const Space v127_2 = singleton(v126_7_head);
        const Space v127_3 = intersect(constant_8,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_9 : Space{});
        const Space v127_5 = subtract(constant_0,v127_4);
        Space v127_8;
        if (!v127_5.empty()) {
          const Path v128_6 = concat_path(v126_6,v126_7_head);
          const Space v128_7 = routine_22(c, v128_6, p1, p2, v126_7_tail);
          v127_8 = compose(v127_5,v128_7);
        }
        const Space v127_9 = intersect(constant_8,v127_2);
        const Space v127_10 = (has_head(v127_9) ? constant_9 : Space{});
        Space v127_12;
        if (!v127_10.empty()) {
          const Path v129_6 = concat_path(v126_6,v126_7_head);
          const Space v129_11 = routine_23(c, v129_6, p1, p2, v126_7_tail);
          v127_12 = compose(v127_10,v129_11);
        }
        const Space v127_13 = unite(v127_8,v127_12);
        v126_7_result = unite(v126_7_result,v127_13);
      }
      const Space v126_7 = std::move(v126_7_result);
      v125_8 = compose(v125_5,v126_7);
    }
    const Space v125_9 = intersect(constant_8,v125_2);
    const Space v125_10 = (has_head(v125_9) ? constant_9 : Space{});
    Space v125_12;
    if (!v125_10.empty()) {
      const Path v130_6 = concat_path(p0,v124_13_head);
      Space v130_11_result;
      for (int v130_11_label = 1; v130_11_label <= 2; ++v130_11_label) {
        const Space v130_11_tail = child(v124_13_tail,v130_11_label);
        if (v130_11_tail.empty()) continue;
        const Path v130_11_head{v130_11_label};
        const Space v131_2 = singleton(v130_11_head);
        const Space v131_3 = intersect(constant_8,v131_2);
        const Space v131_4 = (has_head(v131_3) ? constant_9 : Space{});
        const Space v131_5 = subtract(constant_0,v131_4);
        Space v131_7;
        if (!v131_5.empty()) {
          const Space v132_6 = routine_24(c, v130_11_head, p1, p2, v130_6, v130_11_tail);
          v131_7 = compose(v131_5,v132_6);
        }
        const Space v131_8 = intersect(constant_8,v131_2);
        const Space v131_9 = (has_head(v131_8) ? constant_9 : Space{});
        Space v131_11;
        if (!v131_9.empty()) {
          const Space v133_10 = routine_25(c, v130_11_head, p1, p2, v130_6, v130_11_tail);
          v131_11 = compose(v131_9,v133_10);
        }
        const Space v131_12 = unite(v131_7,v131_11);
        v130_11_result = unite(v130_11_result,v131_12);
      }
      const Space v130_11 = std::move(v130_11_result);
      v125_12 = compose(v125_10,v130_11);
    }
    const Space v125_13 = unite(v125_8,v125_12);
    v124_13_result = unite(v124_13_result,v125_13);
  }
  const Space v124_13 = std::move(v124_13_result);
  return v124_13;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v134_5_result;
  for (int v134_5_label = 1; v134_5_label <= 2; ++v134_5_label) {
    const Space v134_5_tail = child(s0,v134_5_label);
    if (v134_5_tail.empty()) continue;
    const Path v134_5_head{v134_5_label};
    const Space v135_2 = singleton(v134_5_head);
    const Space v135_3 = intersect(constant_8,v135_2);
    const Space v135_4 = (has_head(v135_3) ? constant_9 : Space{});
    Space v135_7;
    if (!v135_4.empty()) {
      const Path v136_5 = concat_path(p0,v134_5_head);
      Space v136_6_result;
      for (int v136_6_label = 1; v136_6_label <= 2; ++v136_6_label) {
        const Space v136_6_tail = child(v134_5_tail,v136_6_label);
        if (v136_6_tail.empty()) continue;
        const Path v136_6_head{v136_6_label};
        const Space v137_2 = singleton(v136_6_head);
        const Space v137_3 = intersect(constant_8,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_9 : Space{});
        Space v137_7;
        if (!v137_4.empty()) {
          const Path v138_5 = concat_path(v136_5,v136_6_head);
          const Space v138_6 = routine_10(c, v138_5, p1, v136_6_tail);
          v137_7 = compose(v137_4,v138_6);
        }
        v136_6_result = unite(v136_6_result,v137_7);
      }
      const Space v136_6 = std::move(v136_6_result);
      v135_7 = compose(v135_4,v136_6);
    }
    v134_5_result = unite(v134_5_result,v135_7);
  }
  const Space v134_5 = std::move(v134_5_result);
  return v134_5;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v139_7_result;
  for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
    const Space v139_7_tail = child(s0,v139_7_label);
    if (v139_7_tail.empty()) continue;
    const Path v139_7_head{v139_7_label};
    const Space v140_2 = singleton(v139_7_head);
    const Space v140_3 = intersect(constant_8,v140_2);
    const Space v140_4 = (has_head(v140_3) ? constant_9 : Space{});
    Space v140_7;
    if (!v140_4.empty()) {
      const Path v141_5 = concat_path(p0,v139_7_head);
      Space v141_6_result;
      for (int v141_6_label = 1; v141_6_label <= 2; ++v141_6_label) {
        const Space v141_6_tail = child(v139_7_tail,v141_6_label);
        if (v141_6_tail.empty()) continue;
        const Path v141_6_head{v141_6_label};
        const Space v142_2 = singleton(v141_6_head);
        const Space v142_3 = intersect(constant_8,v142_2);
        const Space v142_4 = (has_head(v142_3) ? constant_9 : Space{});
        const Space v142_5 = subtract(constant_0,v142_4);
        Space v142_7;
        if (!v142_5.empty()) {
          const Space v143_6 = routine_13(c, v141_6_head, p1, v141_5, v141_6_tail);
          v142_7 = compose(v142_5,v143_6);
        }
        const Space v142_8 = intersect(constant_8,v142_2);
        const Space v142_9 = (has_head(v142_8) ? constant_9 : Space{});
        Space v142_11;
        if (!v142_9.empty()) {
          const Space v144_10 = routine_14(c, v141_6_head, p1, v141_5, v141_6_tail);
          v142_11 = compose(v142_9,v144_10);
        }
        const Space v142_12 = unite(v142_7,v142_11);
        v141_6_result = unite(v141_6_result,v142_12);
      }
      const Space v141_6 = std::move(v141_6_result);
      v140_7 = compose(v140_4,v141_6);
    }
    v139_7_result = unite(v139_7_result,v140_7);
  }
  const Space v139_7 = std::move(v139_7_result);
  return v139_7;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v145_13_result;
  for (int v145_13_label = 1; v145_13_label <= 2; ++v145_13_label) {
    const Space v145_13_tail = child(s0,v145_13_label);
    if (v145_13_tail.empty()) continue;
    const Path v145_13_head{v145_13_label};
    const Space v146_2 = singleton(v145_13_head);
    const Space v146_3 = intersect(constant_8,v146_2);
    const Space v146_4 = (has_head(v146_3) ? constant_9 : Space{});
    const Space v146_5 = subtract(constant_0,v146_4);
    Space v146_8;
    if (!v146_5.empty()) {
      const Path v147_6 = concat_path(p0,v145_13_head);
      Space v147_7_result;
      for (int v147_7_label = 1; v147_7_label <= 2; ++v147_7_label) {
        const Space v147_7_tail = child(v145_13_tail,v147_7_label);
        if (v147_7_tail.empty()) continue;
        const Path v147_7_head{v147_7_label};
        const Space v148_2 = singleton(v147_7_head);
        const Space v148_3 = intersect(constant_8,v148_2);
        const Space v148_4 = (has_head(v148_3) ? constant_9 : Space{});
        const Space v148_5 = subtract(constant_0,v148_4);
        Space v148_8;
        if (!v148_5.empty()) {
          const Path v149_6 = concat_path(v147_6,v147_7_head);
          const Space v149_7 = routine_26(c, v149_6, p1, p2, v147_7_tail);
          v148_8 = compose(v148_5,v149_7);
        }
        const Space v148_9 = intersect(constant_8,v148_2);
        const Space v148_10 = (has_head(v148_9) ? constant_9 : Space{});
        Space v148_12;
        if (!v148_10.empty()) {
          const Path v150_6 = concat_path(v147_6,v147_7_head);
          const Space v150_11 = routine_27(c, v150_6, p1, p2, v147_7_tail);
          v148_12 = compose(v148_10,v150_11);
        }
        const Space v148_13 = unite(v148_8,v148_12);
        v147_7_result = unite(v147_7_result,v148_13);
      }
      const Space v147_7 = std::move(v147_7_result);
      v146_8 = compose(v146_5,v147_7);
    }
    const Space v146_9 = intersect(constant_8,v146_2);
    const Space v146_10 = (has_head(v146_9) ? constant_9 : Space{});
    Space v146_12;
    if (!v146_10.empty()) {
      const Path v151_6 = concat_path(p0,v145_13_head);
      Space v151_11_result;
      for (int v151_11_label = 1; v151_11_label <= 2; ++v151_11_label) {
        const Space v151_11_tail = child(v145_13_tail,v151_11_label);
        if (v151_11_tail.empty()) continue;
        const Path v151_11_head{v151_11_label};
        const Space v152_2 = singleton(v151_11_head);
        const Space v152_3 = intersect(constant_8,v152_2);
        const Space v152_4 = (has_head(v152_3) ? constant_9 : Space{});
        const Space v152_5 = subtract(constant_0,v152_4);
        Space v152_8;
        if (!v152_5.empty()) {
          const Path v153_6 = concat_path(v151_6,v151_11_head);
          const Space v153_7 = routine_26(c, v153_6, p1, p2, v151_11_tail);
          v152_8 = compose(v152_5,v153_7);
        }
        const Space v152_9 = intersect(constant_8,v152_2);
        const Space v152_10 = (has_head(v152_9) ? constant_9 : Space{});
        Space v152_12;
        if (!v152_10.empty()) {
          const Path v154_6 = concat_path(v151_6,v151_11_head);
          const Space v154_11 = routine_19(c, v154_6, p1, p2, v151_11_tail);
          v152_12 = compose(v152_10,v154_11);
        }
        const Space v152_13 = unite(v152_8,v152_12);
        v151_11_result = unite(v151_11_result,v152_13);
      }
      const Space v151_11 = std::move(v151_11_result);
      v146_12 = compose(v146_10,v151_11);
    }
    const Space v146_13 = unite(v146_8,v146_12);
    v145_13_result = unite(v145_13_result,v146_13);
  }
  const Space v145_13 = std::move(v145_13_result);
  return v145_13;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v155_13_result;
  for (int v155_13_label = 1; v155_13_label <= 2; ++v155_13_label) {
    const Space v155_13_tail = child(s0,v155_13_label);
    if (v155_13_tail.empty()) continue;
    const Path v155_13_head{v155_13_label};
    const Space v156_2 = singleton(v155_13_head);
    const Space v156_3 = intersect(constant_8,v156_2);
    const Space v156_4 = (has_head(v156_3) ? constant_9 : Space{});
    const Space v156_5 = subtract(constant_0,v156_4);
    Space v156_8;
    if (!v156_5.empty()) {
      const Path v157_6 = concat_path(p0,v155_13_head);
      Space v157_7_result;
      for (int v157_7_label = 1; v157_7_label <= 2; ++v157_7_label) {
        const Space v157_7_tail = child(v155_13_tail,v157_7_label);
        if (v157_7_tail.empty()) continue;
        const Path v157_7_head{v157_7_label};
        const Space v158_2 = singleton(v157_7_head);
        const Space v158_3 = intersect(constant_8,v158_2);
        const Space v158_4 = (has_head(v158_3) ? constant_9 : Space{});
        const Space v158_5 = subtract(constant_0,v158_4);
        Space v158_8;
        if (!v158_5.empty()) {
          const Path v159_6 = concat_path(v157_6,v157_7_head);
          const Space v159_7 = routine_26(c, v159_6, p1, p2, v157_7_tail);
          v158_8 = compose(v158_5,v159_7);
        }
        const Space v158_9 = intersect(constant_8,v158_2);
        const Space v158_10 = (has_head(v158_9) ? constant_9 : Space{});
        Space v158_12;
        if (!v158_10.empty()) {
          const Path v160_6 = concat_path(v157_6,v157_7_head);
          const Space v160_11 = routine_27(c, v160_6, p1, p2, v157_7_tail);
          v158_12 = compose(v158_10,v160_11);
        }
        const Space v158_13 = unite(v158_8,v158_12);
        v157_7_result = unite(v157_7_result,v158_13);
      }
      const Space v157_7 = std::move(v157_7_result);
      v156_8 = compose(v156_5,v157_7);
    }
    const Space v156_9 = intersect(constant_8,v156_2);
    const Space v156_10 = (has_head(v156_9) ? constant_9 : Space{});
    Space v156_12;
    if (!v156_10.empty()) {
      const Path v161_6 = concat_path(p0,v155_13_head);
      Space v161_11_result;
      for (int v161_11_label = 1; v161_11_label <= 2; ++v161_11_label) {
        const Space v161_11_tail = child(v155_13_tail,v161_11_label);
        if (v161_11_tail.empty()) continue;
        const Path v161_11_head{v161_11_label};
        const Space v162_2 = singleton(v161_11_head);
        const Space v162_3 = intersect(constant_8,v162_2);
        const Space v162_4 = (has_head(v162_3) ? constant_9 : Space{});
        const Space v162_5 = subtract(constant_0,v162_4);
        Space v162_7;
        if (!v162_5.empty()) {
          const Space v163_6 = routine_24(c, v161_11_head, p1, p2, v161_6, v161_11_tail);
          v162_7 = compose(v162_5,v163_6);
        }
        const Space v162_8 = intersect(constant_8,v162_2);
        const Space v162_9 = (has_head(v162_8) ? constant_9 : Space{});
        Space v162_11;
        if (!v162_9.empty()) {
          const Space v164_10 = routine_25(c, v161_11_head, p1, p2, v161_6, v161_11_tail);
          v162_11 = compose(v162_9,v164_10);
        }
        const Space v162_12 = unite(v162_7,v162_11);
        v161_11_result = unite(v161_11_result,v162_12);
      }
      const Space v161_11 = std::move(v161_11_result);
      v156_12 = compose(v156_10,v161_11);
    }
    const Space v156_13 = unite(v156_8,v156_12);
    v155_13_result = unite(v155_13_result,v156_13);
  }
  const Space v155_13 = std::move(v155_13_result);
  return v155_13;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v165_13_result;
  for (int v165_13_label = 1; v165_13_label <= 2; ++v165_13_label) {
    const Space v165_13_tail = child(s0,v165_13_label);
    if (v165_13_tail.empty()) continue;
    const Path v165_13_head{v165_13_label};
    const Space v166_2 = singleton(v165_13_head);
    const Space v166_3 = intersect(constant_8,v166_2);
    const Space v166_4 = (has_head(v166_3) ? constant_9 : Space{});
    const Space v166_5 = subtract(constant_0,v166_4);
    Space v166_7;
    if (!v166_5.empty()) {
      Space v167_6_result;
      for (int v167_6_label = 1; v167_6_label <= 2; ++v167_6_label) {
        const Space v167_6_tail = child(v165_13_tail,v167_6_label);
        if (v167_6_tail.empty()) continue;
        const Path v167_6_head{v167_6_label};
        const Space v168_2 = singleton(v167_6_head);
        const Space v168_3 = intersect(constant_8,v168_2);
        const Space v168_4 = (has_head(v168_3) ? constant_9 : Space{});
        const Space v168_5 = subtract(constant_0,v168_4);
        Space v168_8;
        if (!v168_5.empty()) {
          const Path v169_6 = concat_path(v165_13_head,v167_6_head);
          const Space v169_7 = routine_28(c, v169_6, p1, p2, p0, v167_6_tail);
          v168_8 = compose(v168_5,v169_7);
        }
        const Space v168_9 = intersect(constant_8,v168_2);
        const Space v168_10 = (has_head(v168_9) ? constant_9 : Space{});
        Space v168_12;
        if (!v168_10.empty()) {
          const Path v170_6 = concat_path(v165_13_head,v167_6_head);
          const Space v170_11 = routine_29(c, v170_6, p1, p2, p0, v167_6_tail);
          v168_12 = compose(v168_10,v170_11);
        }
        const Space v168_13 = unite(v168_8,v168_12);
        v167_6_result = unite(v167_6_result,v168_13);
      }
      const Space v167_6 = std::move(v167_6_result);
      v166_7 = compose(v166_5,v167_6);
    }
    const Space v166_8 = intersect(constant_8,v166_2);
    const Space v166_9 = (has_head(v166_8) ? constant_9 : Space{});
    Space v166_11;
    if (!v166_9.empty()) {
      Space v171_10_result;
      for (int v171_10_label = 1; v171_10_label <= 2; ++v171_10_label) {
        const Space v171_10_tail = child(v165_13_tail,v171_10_label);
        if (v171_10_tail.empty()) continue;
        const Path v171_10_head{v171_10_label};
        const Space v172_2 = singleton(v171_10_head);
        const Space v172_3 = intersect(constant_8,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_9 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v165_13_head,v171_10_head);
          const Space v173_7 = routine_28(c, v173_6, p1, p2, p0, v171_10_tail);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_8,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_9 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v165_13_head,v171_10_head);
          const Space v174_11 = routine_30(c, v174_6, p1, p2, p0, v171_10_tail);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_10_result = unite(v171_10_result,v172_13);
      }
      const Space v171_10 = std::move(v171_10_result);
      v166_11 = compose(v166_9,v171_10);
    }
    const Space v166_12 = unite(v166_7,v166_11);
    v165_13_result = unite(v165_13_result,v166_12);
  }
  const Space v165_13 = std::move(v165_13_result);
  return v165_13;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v175_3 = Space{};
  return v175_3;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v176_7_result;
  for (int v176_7_label = 1; v176_7_label <= 2; ++v176_7_label) {
    const Space v176_7_tail = child(s0,v176_7_label);
    if (v176_7_tail.empty()) continue;
    const Path v176_7_head{v176_7_label};
    const Space v177_2 = singleton(v176_7_head);
    const Space v177_3 = intersect(constant_8,v177_2);
    const Space v177_4 = (has_head(v177_3) ? constant_9 : Space{});
    Space v177_7;
    if (!v177_4.empty()) {
      const Path v178_5 = concat_path(p0,v176_7_head);
      Space v178_6_result;
      for (int v178_6_label = 1; v178_6_label <= 2; ++v178_6_label) {
        const Space v178_6_tail = child(v176_7_tail,v178_6_label);
        if (v178_6_tail.empty()) continue;
        const Path v178_6_head{v178_6_label};
        const Space v179_2 = singleton(v178_6_head);
        const Space v179_3 = intersect(constant_8,v179_2);
        const Space v179_4 = (has_head(v179_3) ? constant_9 : Space{});
        const Space v179_5 = subtract(constant_0,v179_4);
        Space v179_7;
        if (!v179_5.empty()) {
          const Space v180_6 = routine_13(c, v178_6_head, p1, v178_5, v178_6_tail);
          v179_7 = compose(v179_5,v180_6);
        }
        const Space v179_8 = intersect(constant_8,v179_2);
        const Space v179_9 = (has_head(v179_8) ? constant_9 : Space{});
        Space v179_11;
        if (!v179_9.empty()) {
          const Space v181_10 = routine_14(c, v178_6_head, p1, v178_5, v178_6_tail);
          v179_11 = compose(v179_9,v181_10);
        }
        const Space v179_12 = unite(v179_7,v179_11);
        v178_6_result = unite(v178_6_result,v179_12);
      }
      const Space v178_6 = std::move(v178_6_result);
      v177_7 = compose(v177_4,v178_6);
    }
    v176_7_result = unite(v176_7_result,v177_7);
  }
  const Space v176_7 = std::move(v176_7_result);
  return v176_7;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v182_13_result;
  for (int v182_13_label = 1; v182_13_label <= 2; ++v182_13_label) {
    const Space v182_13_tail = child(s0,v182_13_label);
    if (v182_13_tail.empty()) continue;
    const Path v182_13_head{v182_13_label};
    const Space v183_2 = singleton(v182_13_head);
    const Space v183_3 = intersect(constant_8,v183_2);
    const Space v183_4 = (has_head(v183_3) ? constant_9 : Space{});
    const Space v183_5 = subtract(constant_0,v183_4);
    Space v183_8;
    if (!v183_5.empty()) {
      const Path v184_6 = concat_path(p0,v182_13_head);
      Space v184_7_result;
      for (int v184_7_label = 1; v184_7_label <= 2; ++v184_7_label) {
        const Space v184_7_tail = child(v182_13_tail,v184_7_label);
        if (v184_7_tail.empty()) continue;
        const Path v184_7_head{v184_7_label};
        const Space v185_2 = singleton(v184_7_head);
        const Space v185_3 = intersect(constant_8,v185_2);
        const Space v185_4 = (has_head(v185_3) ? constant_9 : Space{});
        const Space v185_5 = subtract(constant_0,v185_4);
        Space v185_8;
        if (!v185_5.empty()) {
          const Path v186_6 = concat_path(v184_6,v184_7_head);
          const Space v186_7 = routine_31(c, v186_6, p1, p2, v184_7_tail);
          v185_8 = compose(v185_5,v186_7);
        }
        const Space v185_9 = intersect(constant_8,v185_2);
        const Space v185_10 = (has_head(v185_9) ? constant_9 : Space{});
        Space v185_12;
        if (!v185_10.empty()) {
          const Path v187_6 = concat_path(v184_6,v184_7_head);
          const Space v187_11 = routine_32(c, v187_6, p1, p2, v184_7_tail);
          v185_12 = compose(v185_10,v187_11);
        }
        const Space v185_13 = unite(v185_8,v185_12);
        v184_7_result = unite(v184_7_result,v185_13);
      }
      const Space v184_7 = std::move(v184_7_result);
      v183_8 = compose(v183_5,v184_7);
    }
    const Space v183_9 = intersect(constant_8,v183_2);
    const Space v183_10 = (has_head(v183_9) ? constant_9 : Space{});
    Space v183_12;
    if (!v183_10.empty()) {
      const Path v188_6 = concat_path(p0,v182_13_head);
      Space v188_11_result;
      for (int v188_11_label = 1; v188_11_label <= 2; ++v188_11_label) {
        const Space v188_11_tail = child(v182_13_tail,v188_11_label);
        if (v188_11_tail.empty()) continue;
        const Path v188_11_head{v188_11_label};
        const Space v189_2 = singleton(v188_11_head);
        const Space v189_3 = intersect(constant_8,v189_2);
        const Space v189_4 = (has_head(v189_3) ? constant_9 : Space{});
        const Space v189_5 = subtract(constant_0,v189_4);
        Space v189_8;
        if (!v189_5.empty()) {
          const Path v190_6 = concat_path(v188_6,v188_11_head);
          const Space v190_7 = routine_31(c, v190_6, p1, p2, v188_11_tail);
          v189_8 = compose(v189_5,v190_7);
        }
        const Space v189_9 = intersect(constant_8,v189_2);
        const Space v189_10 = (has_head(v189_9) ? constant_9 : Space{});
        Space v189_12;
        if (!v189_10.empty()) {
          const Path v191_6 = concat_path(v188_6,v188_11_head);
          const Space v191_11 = routine_19(c, v191_6, p1, p2, v188_11_tail);
          v189_12 = compose(v189_10,v191_11);
        }
        const Space v189_13 = unite(v189_8,v189_12);
        v188_11_result = unite(v188_11_result,v189_13);
      }
      const Space v188_11 = std::move(v188_11_result);
      v183_12 = compose(v183_10,v188_11);
    }
    const Space v183_13 = unite(v183_8,v183_12);
    v182_13_result = unite(v182_13_result,v183_13);
  }
  const Space v182_13 = std::move(v182_13_result);
  return v182_13;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v192_13_result;
  for (int v192_13_label = 1; v192_13_label <= 2; ++v192_13_label) {
    const Space v192_13_tail = child(s0,v192_13_label);
    if (v192_13_tail.empty()) continue;
    const Path v192_13_head{v192_13_label};
    const Space v193_2 = singleton(v192_13_head);
    const Space v193_3 = intersect(constant_8,v193_2);
    const Space v193_4 = (has_head(v193_3) ? constant_9 : Space{});
    const Space v193_5 = subtract(constant_0,v193_4);
    Space v193_8;
    if (!v193_5.empty()) {
      const Path v194_6 = concat_path(p0,v192_13_head);
      Space v194_7_result;
      for (int v194_7_label = 1; v194_7_label <= 2; ++v194_7_label) {
        const Space v194_7_tail = child(v192_13_tail,v194_7_label);
        if (v194_7_tail.empty()) continue;
        const Path v194_7_head{v194_7_label};
        const Space v195_2 = singleton(v194_7_head);
        const Space v195_3 = intersect(constant_8,v195_2);
        const Space v195_4 = (has_head(v195_3) ? constant_9 : Space{});
        const Space v195_5 = subtract(constant_0,v195_4);
        Space v195_8;
        if (!v195_5.empty()) {
          const Path v196_6 = concat_path(v194_6,v194_7_head);
          const Space v196_7 = routine_31(c, v196_6, p1, p2, v194_7_tail);
          v195_8 = compose(v195_5,v196_7);
        }
        const Space v195_9 = intersect(constant_8,v195_2);
        const Space v195_10 = (has_head(v195_9) ? constant_9 : Space{});
        Space v195_12;
        if (!v195_10.empty()) {
          const Path v197_6 = concat_path(v194_6,v194_7_head);
          const Space v197_11 = routine_32(c, v197_6, p1, p2, v194_7_tail);
          v195_12 = compose(v195_10,v197_11);
        }
        const Space v195_13 = unite(v195_8,v195_12);
        v194_7_result = unite(v194_7_result,v195_13);
      }
      const Space v194_7 = std::move(v194_7_result);
      v193_8 = compose(v193_5,v194_7);
    }
    const Space v193_9 = intersect(constant_8,v193_2);
    const Space v193_10 = (has_head(v193_9) ? constant_9 : Space{});
    Space v193_12;
    if (!v193_10.empty()) {
      const Path v198_6 = concat_path(p0,v192_13_head);
      Space v198_11_result;
      for (int v198_11_label = 1; v198_11_label <= 2; ++v198_11_label) {
        const Space v198_11_tail = child(v192_13_tail,v198_11_label);
        if (v198_11_tail.empty()) continue;
        const Path v198_11_head{v198_11_label};
        const Space v199_2 = singleton(v198_11_head);
        const Space v199_3 = intersect(constant_8,v199_2);
        const Space v199_4 = (has_head(v199_3) ? constant_9 : Space{});
        const Space v199_5 = subtract(constant_0,v199_4);
        Space v199_7;
        if (!v199_5.empty()) {
          const Space v200_6 = routine_24(c, v198_11_head, p1, p2, v198_6, v198_11_tail);
          v199_7 = compose(v199_5,v200_6);
        }
        const Space v199_8 = intersect(constant_8,v199_2);
        const Space v199_9 = (has_head(v199_8) ? constant_9 : Space{});
        Space v199_11;
        if (!v199_9.empty()) {
          const Space v201_10 = routine_25(c, v198_11_head, p1, p2, v198_6, v198_11_tail);
          v199_11 = compose(v199_9,v201_10);
        }
        const Space v199_12 = unite(v199_7,v199_11);
        v198_11_result = unite(v198_11_result,v199_12);
      }
      const Space v198_11 = std::move(v198_11_result);
      v193_12 = compose(v193_10,v198_11);
    }
    const Space v193_13 = unite(v193_8,v193_12);
    v192_13_result = unite(v192_13_result,v193_13);
  }
  const Space v192_13 = std::move(v192_13_result);
  return v192_13;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v202_14_result;
  for (int v202_14_label = 1; v202_14_label <= 2; ++v202_14_label) {
    const Space v202_14_tail = child(s0,v202_14_label);
    if (v202_14_tail.empty()) continue;
    const Path v202_14_head{v202_14_label};
    const Space v203_2 = singleton(v202_14_head);
    const Space v203_3 = intersect(constant_8,v203_2);
    const Space v203_4 = (has_head(v203_3) ? constant_9 : Space{});
    const Space v203_5 = subtract(constant_0,v203_4);
    Space v203_8;
    if (!v203_5.empty()) {
      const Path v204_6 = concat_path(p0,v202_14_head);
      Space v204_7_result;
      for (int v204_7_label = 1; v204_7_label <= 2; ++v204_7_label) {
        const Space v204_7_tail = child(v202_14_tail,v204_7_label);
        if (v204_7_tail.empty()) continue;
        const Path v204_7_head{v204_7_label};
        const Space v205_2 = singleton(v204_7_head);
        const Space v205_3 = intersect(constant_8,v205_2);
        const Space v205_4 = (has_head(v205_3) ? constant_9 : Space{});
        const Space v205_5 = subtract(constant_0,v205_4);
        Space v205_8;
        if (!v205_5.empty()) {
          const Path v206_6 = concat_path(v204_6,v204_7_head);
          const Space v206_7 = routine_33(c, v206_6, p1, p2, p3, v204_7_tail);
          v205_8 = compose(v205_5,v206_7);
        }
        const Space v205_9 = intersect(constant_8,v205_2);
        const Space v205_10 = (has_head(v205_9) ? constant_9 : Space{});
        Space v205_12;
        if (!v205_10.empty()) {
          const Path v207_6 = concat_path(v204_6,v204_7_head);
          const Space v207_11 = routine_34(c, v207_6, p1, p2, p3, v204_7_tail);
          v205_12 = compose(v205_10,v207_11);
        }
        const Space v205_13 = unite(v205_8,v205_12);
        v204_7_result = unite(v204_7_result,v205_13);
      }
      const Space v204_7 = std::move(v204_7_result);
      v203_8 = compose(v203_5,v204_7);
    }
    const Space v203_9 = intersect(constant_8,v203_2);
    const Space v203_10 = (has_head(v203_9) ? constant_9 : Space{});
    Space v203_12;
    if (!v203_10.empty()) {
      const Path v208_6 = concat_path(p0,v202_14_head);
      Space v208_11_result;
      for (int v208_11_label = 1; v208_11_label <= 2; ++v208_11_label) {
        const Space v208_11_tail = child(v202_14_tail,v208_11_label);
        if (v208_11_tail.empty()) continue;
        const Path v208_11_head{v208_11_label};
        const Space v209_2 = singleton(v208_11_head);
        const Space v209_3 = intersect(constant_8,v209_2);
        const Space v209_4 = (has_head(v209_3) ? constant_9 : Space{});
        const Space v209_5 = subtract(constant_0,v209_4);
        Space v209_8;
        if (!v209_5.empty()) {
          const Path v210_6 = concat_path(v208_6,v208_11_head);
          const Space v210_7 = routine_33(c, v210_6, p1, p2, p3, v208_11_tail);
          v209_8 = compose(v209_5,v210_7);
        }
        const Space v209_9 = intersect(constant_8,v209_2);
        const Space v209_10 = (has_head(v209_9) ? constant_9 : Space{});
        Space v209_12;
        if (!v209_10.empty()) {
          const Path v211_6 = concat_path(v208_6,v208_11_head);
          const Space v211_11 = routine_30(c, v211_6, p1, p2, p3, v208_11_tail);
          v209_12 = compose(v209_10,v211_11);
        }
        const Space v209_13 = unite(v209_8,v209_12);
        v208_11_result = unite(v208_11_result,v209_13);
      }
      const Space v208_11 = std::move(v208_11_result);
      v203_12 = compose(v203_10,v208_11);
    }
    const Space v203_13 = unite(v203_8,v203_12);
    v202_14_result = unite(v202_14_result,v203_13);
  }
  const Space v202_14 = std::move(v202_14_result);
  return v202_14;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v212_8 = concat_path(p2,p3);
  Space v212_18_result;
  for (int v212_18_label = 1; v212_18_label <= 2; ++v212_18_label) {
    const Space v212_18_tail = child(s0,v212_18_label);
    if (v212_18_tail.empty()) continue;
    const Path v212_18_head{v212_18_label};
    const Space v213_2 = singleton(v212_18_head);
    const Space v213_3 = intersect(constant_8,v213_2);
    const Space v213_4 = (has_head(v213_3) ? constant_9 : Space{});
    const Space v213_5 = subtract(constant_0,v213_4);
    Space v213_8;
    if (!v213_5.empty()) {
      const Path v214_6 = concat_path(p0,v212_18_head);
      Space v214_7_result;
      for (int v214_7_label = 1; v214_7_label <= 2; ++v214_7_label) {
        const Space v214_7_tail = child(v212_18_tail,v214_7_label);
        if (v214_7_tail.empty()) continue;
        const Path v214_7_head{v214_7_label};
        const Space v215_2 = singleton(v214_7_head);
        const Space v215_3 = intersect(constant_8,v215_2);
        const Space v215_4 = (has_head(v215_3) ? constant_9 : Space{});
        const Space v215_5 = subtract(constant_0,v215_4);
        Space v215_8;
        if (!v215_5.empty()) {
          const Path v216_6 = concat_path(v214_6,v214_7_head);
          const Space v216_7 = routine_33(c, v216_6, p1, p2, p3, v214_7_tail);
          v215_8 = compose(v215_5,v216_7);
        }
        const Space v215_9 = intersect(constant_8,v215_2);
        const Space v215_10 = (has_head(v215_9) ? constant_9 : Space{});
        Space v215_12;
        if (!v215_10.empty()) {
          const Path v217_6 = concat_path(v214_6,v214_7_head);
          const Space v217_11 = routine_34(c, v217_6, p1, p2, p3, v214_7_tail);
          v215_12 = compose(v215_10,v217_11);
        }
        const Space v215_13 = unite(v215_8,v215_12);
        v214_7_result = unite(v214_7_result,v215_13);
      }
      const Space v214_7 = std::move(v214_7_result);
      v213_8 = compose(v213_5,v214_7);
    }
    const Space v213_9 = intersect(constant_8,v213_2);
    const Space v213_10 = (has_head(v213_9) ? constant_9 : Space{});
    Space v213_16;
    if (!v213_10.empty()) {
      const Path v218_6 = concat_path(p0,v212_18_head);
      const Path v218_11 = concat_path(v212_8,v218_6);
      const Space v218_12 = singleton(v218_11);
      const Space v218_13 = routine_35(c, p1, v218_12);
      Space v218_14_result;
      for (int v218_14_label = 1; v218_14_label <= 2; ++v218_14_label) {
        const Space v218_14_tail = child(v218_13,v218_14_label);
        if (v218_14_tail.empty()) continue;
        const Path v218_14_head{v218_14_label};
        const Space v219_2 = singleton(v218_14_head);
        const Space v219_3 = intersect(constant_8,v219_2);
        const Space v219_4 = (has_head(v219_3) ? constant_9 : Space{});
        const Space v219_5 = subtract(constant_0,v219_4);
        Space v219_7;
        if (!v219_5.empty()) {
          const Space v220_6 = routine_36(c, v218_14_head, p1, v218_14_tail);
          v219_7 = compose(v219_5,v220_6);
        }
        const Space v219_8 = intersect(constant_8,v219_2);
        const Space v219_9 = (has_head(v219_8) ? constant_9 : Space{});
        Space v219_11;
        if (!v219_9.empty()) {
          const Space v221_10 = routine_37(c, v218_14_head, p1, v218_14_tail);
          v219_11 = compose(v219_9,v221_10);
        }
        const Space v219_12 = unite(v219_7,v219_11);
        v218_14_result = unite(v218_14_result,v219_12);
      }
      const Space v218_14 = std::move(v218_14_result);
      Space v218_15_result;
      for (int v218_15_label = 1; v218_15_label <= 2; ++v218_15_label) {
        const Space v218_15_tail = child(v218_14,v218_15_label);
        if (v218_15_tail.empty()) continue;
        const Path v218_15_head{v218_15_label};
        const Space v222_2 = singleton(v218_15_head);
        const Space v222_3 = intersect(constant_8,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_9 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_38(c, v218_15_head, p1, v218_15_tail);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_8,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_9 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_39(c, v218_15_head, p1, v218_15_tail);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v218_15_result = unite(v218_15_result,v222_12);
      }
      const Space v218_15 = std::move(v218_15_result);
      v213_16 = compose(v213_10,v218_15);
    }
    const Space v213_17 = unite(v213_8,v213_16);
    v212_18_result = unite(v212_18_result,v213_17);
  }
  const Space v212_18 = std::move(v212_18_result);
  return v212_18;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v225_6_result;
  for (int v225_6_label = 1; v225_6_label <= 2; ++v225_6_label) {
    const Space v225_6_tail = child(s0,v225_6_label);
    if (v225_6_tail.empty()) continue;
    const Path v225_6_head{v225_6_label};
    const Space v226_2 = singleton(v225_6_head);
    const Space v226_3 = intersect(constant_8,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_9 : Space{});
    Space v226_7;
    if (!v226_4.empty()) {
      const Path v227_5 = concat_path(p0,v225_6_head);
      Space v227_6_result;
      for (int v227_6_label = 1; v227_6_label <= 2; ++v227_6_label) {
        const Space v227_6_tail = child(v225_6_tail,v227_6_label);
        if (v227_6_tail.empty()) continue;
        const Path v227_6_head{v227_6_label};
        const Space v228_2 = singleton(v227_6_head);
        const Space v228_3 = intersect(constant_8,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_9 : Space{});
        Space v228_7;
        if (!v228_4.empty()) {
          const Path v229_5 = concat_path(v227_5,v227_6_head);
          const Space v229_6 = routine_19(c, v229_5, p1, p2, v227_6_tail);
          v228_7 = compose(v228_4,v229_6);
        }
        v227_6_result = unite(v227_6_result,v228_7);
      }
      const Space v227_6 = std::move(v227_6_result);
      v226_7 = compose(v226_4,v227_6);
    }
    v225_6_result = unite(v225_6_result,v226_7);
  }
  const Space v225_6 = std::move(v225_6_result);
  return v225_6;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v230_8_result;
  for (int v230_8_label = 1; v230_8_label <= 2; ++v230_8_label) {
    const Space v230_8_tail = child(s0,v230_8_label);
    if (v230_8_tail.empty()) continue;
    const Path v230_8_head{v230_8_label};
    const Space v231_2 = singleton(v230_8_head);
    const Space v231_3 = intersect(constant_8,v231_2);
    const Space v231_4 = (has_head(v231_3) ? constant_9 : Space{});
    Space v231_7;
    if (!v231_4.empty()) {
      const Path v232_5 = concat_path(p0,v230_8_head);
      Space v232_6_result;
      for (int v232_6_label = 1; v232_6_label <= 2; ++v232_6_label) {
        const Space v232_6_tail = child(v230_8_tail,v232_6_label);
        if (v232_6_tail.empty()) continue;
        const Path v232_6_head{v232_6_label};
        const Space v233_2 = singleton(v232_6_head);
        const Space v233_3 = intersect(constant_8,v233_2);
        const Space v233_4 = (has_head(v233_3) ? constant_9 : Space{});
        const Space v233_5 = subtract(constant_0,v233_4);
        Space v233_7;
        if (!v233_5.empty()) {
          const Space v234_6 = routine_24(c, v232_6_head, p1, p2, v232_5, v232_6_tail);
          v233_7 = compose(v233_5,v234_6);
        }
        const Space v233_8 = intersect(constant_8,v233_2);
        const Space v233_9 = (has_head(v233_8) ? constant_9 : Space{});
        Space v233_11;
        if (!v233_9.empty()) {
          const Space v235_10 = routine_25(c, v232_6_head, p1, p2, v232_5, v232_6_tail);
          v233_11 = compose(v233_9,v235_10);
        }
        const Space v233_12 = unite(v233_7,v233_11);
        v232_6_result = unite(v232_6_result,v233_12);
      }
      const Space v232_6 = std::move(v232_6_result);
      v231_7 = compose(v231_4,v232_6);
    }
    v230_8_result = unite(v230_8_result,v231_7);
  }
  const Space v230_8 = std::move(v230_8_result);
  return v230_8;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v236_14_result;
  for (int v236_14_label = 1; v236_14_label <= 2; ++v236_14_label) {
    const Space v236_14_tail = child(s0,v236_14_label);
    if (v236_14_tail.empty()) continue;
    const Path v236_14_head{v236_14_label};
    const Space v237_2 = singleton(v236_14_head);
    const Space v237_3 = intersect(constant_8,v237_2);
    const Space v237_4 = (has_head(v237_3) ? constant_9 : Space{});
    const Space v237_5 = subtract(constant_0,v237_4);
    Space v237_8;
    if (!v237_5.empty()) {
      const Path v238_6 = concat_path(p0,v236_14_head);
      Space v238_7_result;
      for (int v238_7_label = 1; v238_7_label <= 2; ++v238_7_label) {
        const Space v238_7_tail = child(v236_14_tail,v238_7_label);
        if (v238_7_tail.empty()) continue;
        const Path v238_7_head{v238_7_label};
        const Space v239_2 = singleton(v238_7_head);
        const Space v239_3 = intersect(constant_8,v239_2);
        const Space v239_4 = (has_head(v239_3) ? constant_9 : Space{});
        const Space v239_5 = subtract(constant_0,v239_4);
        Space v239_8;
        if (!v239_5.empty()) {
          const Path v240_6 = concat_path(v238_6,v238_7_head);
          const Space v240_7 = routine_40(c, v240_6, p1, p2, p3, v238_7_tail);
          v239_8 = compose(v239_5,v240_7);
        }
        const Space v239_9 = intersect(constant_8,v239_2);
        const Space v239_10 = (has_head(v239_9) ? constant_9 : Space{});
        Space v239_12;
        if (!v239_10.empty()) {
          const Path v241_6 = concat_path(v238_6,v238_7_head);
          const Space v241_11 = routine_41(c, v241_6, p1, p2, p3, v238_7_tail);
          v239_12 = compose(v239_10,v241_11);
        }
        const Space v239_13 = unite(v239_8,v239_12);
        v238_7_result = unite(v238_7_result,v239_13);
      }
      const Space v238_7 = std::move(v238_7_result);
      v237_8 = compose(v237_5,v238_7);
    }
    const Space v237_9 = intersect(constant_8,v237_2);
    const Space v237_10 = (has_head(v237_9) ? constant_9 : Space{});
    Space v237_12;
    if (!v237_10.empty()) {
      const Path v242_6 = concat_path(p0,v236_14_head);
      Space v242_11_result;
      for (int v242_11_label = 1; v242_11_label <= 2; ++v242_11_label) {
        const Space v242_11_tail = child(v236_14_tail,v242_11_label);
        if (v242_11_tail.empty()) continue;
        const Path v242_11_head{v242_11_label};
        const Space v243_2 = singleton(v242_11_head);
        const Space v243_3 = intersect(constant_8,v243_2);
        const Space v243_4 = (has_head(v243_3) ? constant_9 : Space{});
        const Space v243_5 = subtract(constant_0,v243_4);
        Space v243_8;
        if (!v243_5.empty()) {
          const Path v244_6 = concat_path(v242_6,v242_11_head);
          const Space v244_7 = routine_40(c, v244_6, p1, p2, p3, v242_11_tail);
          v243_8 = compose(v243_5,v244_7);
        }
        const Space v243_9 = intersect(constant_8,v243_2);
        const Space v243_10 = (has_head(v243_9) ? constant_9 : Space{});
        Space v243_12;
        if (!v243_10.empty()) {
          const Path v245_6 = concat_path(v242_6,v242_11_head);
          const Space v245_11 = routine_30(c, v245_6, p1, p2, p3, v242_11_tail);
          v243_12 = compose(v243_10,v245_11);
        }
        const Space v243_13 = unite(v243_8,v243_12);
        v242_11_result = unite(v242_11_result,v243_13);
      }
      const Space v242_11 = std::move(v242_11_result);
      v237_12 = compose(v237_10,v242_11);
    }
    const Space v237_13 = unite(v237_8,v237_12);
    v236_14_result = unite(v236_14_result,v237_13);
  }
  const Space v236_14 = std::move(v236_14_result);
  return v236_14;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v246_8 = concat_path(p2,p3);
  Space v246_18_result;
  for (int v246_18_label = 1; v246_18_label <= 2; ++v246_18_label) {
    const Space v246_18_tail = child(s0,v246_18_label);
    if (v246_18_tail.empty()) continue;
    const Path v246_18_head{v246_18_label};
    const Space v247_2 = singleton(v246_18_head);
    const Space v247_3 = intersect(constant_8,v247_2);
    const Space v247_4 = (has_head(v247_3) ? constant_9 : Space{});
    const Space v247_5 = subtract(constant_0,v247_4);
    Space v247_8;
    if (!v247_5.empty()) {
      const Path v248_6 = concat_path(p0,v246_18_head);
      Space v248_7_result;
      for (int v248_7_label = 1; v248_7_label <= 2; ++v248_7_label) {
        const Space v248_7_tail = child(v246_18_tail,v248_7_label);
        if (v248_7_tail.empty()) continue;
        const Path v248_7_head{v248_7_label};
        const Space v249_2 = singleton(v248_7_head);
        const Space v249_3 = intersect(constant_8,v249_2);
        const Space v249_4 = (has_head(v249_3) ? constant_9 : Space{});
        const Space v249_5 = subtract(constant_0,v249_4);
        Space v249_8;
        if (!v249_5.empty()) {
          const Path v250_6 = concat_path(v248_6,v248_7_head);
          const Space v250_7 = routine_40(c, v250_6, p1, p2, p3, v248_7_tail);
          v249_8 = compose(v249_5,v250_7);
        }
        const Space v249_9 = intersect(constant_8,v249_2);
        const Space v249_10 = (has_head(v249_9) ? constant_9 : Space{});
        Space v249_12;
        if (!v249_10.empty()) {
          const Path v251_6 = concat_path(v248_6,v248_7_head);
          const Space v251_11 = routine_41(c, v251_6, p1, p2, p3, v248_7_tail);
          v249_12 = compose(v249_10,v251_11);
        }
        const Space v249_13 = unite(v249_8,v249_12);
        v248_7_result = unite(v248_7_result,v249_13);
      }
      const Space v248_7 = std::move(v248_7_result);
      v247_8 = compose(v247_5,v248_7);
    }
    const Space v247_9 = intersect(constant_8,v247_2);
    const Space v247_10 = (has_head(v247_9) ? constant_9 : Space{});
    Space v247_16;
    if (!v247_10.empty()) {
      const Path v252_6 = concat_path(p0,v246_18_head);
      const Path v252_11 = concat_path(v246_8,v252_6);
      const Space v252_12 = singleton(v252_11);
      const Space v252_13 = routine_35(c, p1, v252_12);
      Space v252_14_result;
      for (int v252_14_label = 1; v252_14_label <= 2; ++v252_14_label) {
        const Space v252_14_tail = child(v252_13,v252_14_label);
        if (v252_14_tail.empty()) continue;
        const Path v252_14_head{v252_14_label};
        const Space v253_2 = singleton(v252_14_head);
        const Space v253_3 = intersect(constant_8,v253_2);
        const Space v253_4 = (has_head(v253_3) ? constant_9 : Space{});
        const Space v253_5 = subtract(constant_0,v253_4);
        Space v253_7;
        if (!v253_5.empty()) {
          const Space v254_6 = routine_36(c, v252_14_head, p1, v252_14_tail);
          v253_7 = compose(v253_5,v254_6);
        }
        const Space v253_8 = intersect(constant_8,v253_2);
        const Space v253_9 = (has_head(v253_8) ? constant_9 : Space{});
        Space v253_11;
        if (!v253_9.empty()) {
          const Space v255_10 = routine_37(c, v252_14_head, p1, v252_14_tail);
          v253_11 = compose(v253_9,v255_10);
        }
        const Space v253_12 = unite(v253_7,v253_11);
        v252_14_result = unite(v252_14_result,v253_12);
      }
      const Space v252_14 = std::move(v252_14_result);
      Space v252_15_result;
      for (int v252_15_label = 1; v252_15_label <= 2; ++v252_15_label) {
        const Space v252_15_tail = child(v252_14,v252_15_label);
        if (v252_15_tail.empty()) continue;
        const Path v252_15_head{v252_15_label};
        const Space v256_2 = singleton(v252_15_head);
        const Space v256_3 = intersect(constant_8,v256_2);
        const Space v256_4 = (has_head(v256_3) ? constant_9 : Space{});
        const Space v256_5 = subtract(constant_0,v256_4);
        Space v256_7;
        if (!v256_5.empty()) {
          const Space v257_6 = routine_38(c, v252_15_head, p1, v252_15_tail);
          v256_7 = compose(v256_5,v257_6);
        }
        const Space v256_8 = intersect(constant_8,v256_2);
        const Space v256_9 = (has_head(v256_8) ? constant_9 : Space{});
        Space v256_11;
        if (!v256_9.empty()) {
          const Space v258_10 = routine_39(c, v252_15_head, p1, v252_15_tail);
          v256_11 = compose(v256_9,v258_10);
        }
        const Space v256_12 = unite(v256_7,v256_11);
        v252_15_result = unite(v252_15_result,v256_12);
      }
      const Space v252_15 = std::move(v252_15_result);
      v247_16 = compose(v247_10,v252_15);
    }
    const Space v247_17 = unite(v247_8,v247_16);
    v246_18_result = unite(v246_18_result,v247_17);
  }
  const Space v246_18 = std::move(v246_18_result);
  return v246_18;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v259_6 = singleton(p1);
  const Space v259_7 = intersect(constant_10,v259_6);
  Space v259_11_result;
  for (int v259_11_label = 1; v259_11_label <= 2; ++v259_11_label) {
    const Space v259_11_tail = child(v259_7,v259_11_label);
    if (v259_11_tail.empty()) continue;
    const Path v259_11_head{v259_11_label};
    const Space v260_2 = singleton(v259_11_head);
    const Space v260_3 = intersect(constant_8,v260_2);
    const Space v260_4 = (has_head(v260_3) ? constant_9 : Space{});
    const Space v260_5 = subtract(constant_0,v260_4);
    Space v260_7;
    if (!v260_5.empty()) {
      const Space v261_6 = routine_42(c, v259_11_head, v259_11_tail);
      v260_7 = compose(v260_5,v261_6);
    }
    const Space v260_8 = intersect(constant_8,v260_2);
    const Space v260_9 = (has_head(v260_8) ? constant_9 : Space{});
    Space v260_11;
    if (!v260_9.empty()) {
      const Space v262_10 = routine_43(c, v259_11_head, v259_11_tail);
      v260_11 = compose(v260_9,v262_10);
    }
    const Space v260_12 = unite(v260_7,v260_11);
    v259_11_result = unite(v259_11_result,v260_12);
  }
  const Space v259_11 = std::move(v259_11_result);
  Space v259_19;
  if (!v259_11.empty()) {
    const Path v263_12 = concat_path(p2,p3);
    const Path v263_13 = concat_path(v263_12,p0);
    const Space v263_14 = singleton(v263_13);
    Space v263_18_result;
    for (int v263_18_label = 1; v263_18_label <= 2; ++v263_18_label) {
      const Space v263_18_tail = child(v263_14,v263_18_label);
      if (v263_18_tail.empty()) continue;
      const Path v263_18_head{v263_18_label};
      const Space v264_2 = singleton(v263_18_head);
      const Space v264_3 = intersect(constant_8,v264_2);
      const Space v264_4 = (has_head(v264_3) ? constant_9 : Space{});
      const Space v264_5 = subtract(constant_0,v264_4);
      Space v264_7;
      if (!v264_5.empty()) {
        const Space v265_6 = routine_44(c, v263_18_head, v263_18_tail);
        v264_7 = compose(v264_5,v265_6);
      }
      const Space v264_8 = intersect(constant_8,v264_2);
      const Space v264_9 = (has_head(v264_8) ? constant_9 : Space{});
      Space v264_11;
      if (!v264_9.empty()) {
        const Space v266_10 = routine_45(c, v263_18_head, v263_18_tail);
        v264_11 = compose(v264_9,v266_10);
      }
      const Space v264_12 = unite(v264_7,v264_11);
      v263_18_result = unite(v263_18_result,v264_12);
    }
    const Space v263_18 = std::move(v263_18_result);
    v259_19 = compose(v259_11,v263_18);
  }
  const Space v259_21 = intersect(constant_11,v259_6);
  Space v259_25_result;
  for (int v259_25_label = 1; v259_25_label <= 2; ++v259_25_label) {
    const Space v259_25_tail = child(v259_21,v259_25_label);
    if (v259_25_tail.empty()) continue;
    const Path v259_25_head{v259_25_label};
    const Space v267_2 = singleton(v259_25_head);
    const Space v267_3 = intersect(constant_8,v267_2);
    const Space v267_4 = (has_head(v267_3) ? constant_9 : Space{});
    const Space v267_5 = subtract(constant_0,v267_4);
    Space v267_7;
    if (!v267_5.empty()) {
      const Space v268_6 = routine_46(c, v259_25_head, v259_25_tail);
      v267_7 = compose(v267_5,v268_6);
    }
    const Space v267_8 = intersect(constant_8,v267_2);
    const Space v267_9 = (has_head(v267_8) ? constant_9 : Space{});
    Space v267_11;
    if (!v267_9.empty()) {
      const Space v269_10 = routine_47(c, v259_25_head, v259_25_tail);
      v267_11 = compose(v267_9,v269_10);
    }
    const Space v267_12 = unite(v267_7,v267_11);
    v259_25_result = unite(v259_25_result,v267_12);
  }
  const Space v259_25 = std::move(v259_25_result);
  Space v259_30;
  if (!v259_25.empty()) {
    const Path v270_12 = concat_path(p2,p3);
    const Path v270_13 = concat_path(v270_12,p0);
    const Space v270_14 = singleton(v270_13);
    Space v270_29_result;
    for (int v270_29_label = 1; v270_29_label <= 2; ++v270_29_label) {
      const Space v270_29_tail = child(v270_14,v270_29_label);
      if (v270_29_tail.empty()) continue;
      const Path v270_29_head{v270_29_label};
      const Space v271_2 = singleton(v270_29_head);
      const Space v271_3 = intersect(constant_8,v271_2);
      const Space v271_4 = (has_head(v271_3) ? constant_9 : Space{});
      const Space v271_5 = subtract(constant_0,v271_4);
      Space v271_7;
      if (!v271_5.empty()) {
        const Space v272_6 = routine_48(c, v270_29_head, v270_29_tail);
        v271_7 = compose(v271_5,v272_6);
      }
      const Space v271_8 = intersect(constant_8,v271_2);
      const Space v271_9 = (has_head(v271_8) ? constant_9 : Space{});
      Space v271_11;
      if (!v271_9.empty()) {
        const Space v273_10 = routine_49(c, v270_29_head, v270_29_tail);
        v271_11 = compose(v271_9,v273_10);
      }
      const Space v271_12 = unite(v271_7,v271_11);
      v270_29_result = unite(v270_29_result,v271_12);
    }
    const Space v270_29 = std::move(v270_29_result);
    v259_30 = compose(v259_25,v270_29);
  }
  const Space v259_31 = unite(v259_19,v259_30);
  const Space v259_33 = intersect(constant_12,v259_6);
  Space v259_37_result;
  for (int v259_37_label = 1; v259_37_label <= 2; ++v259_37_label) {
    const Space v259_37_tail = child(v259_33,v259_37_label);
    if (v259_37_tail.empty()) continue;
    const Path v259_37_head{v259_37_label};
    const Space v274_2 = singleton(v259_37_head);
    const Space v274_3 = intersect(constant_8,v274_2);
    const Space v274_4 = (has_head(v274_3) ? constant_9 : Space{});
    const Space v274_5 = subtract(constant_0,v274_4);
    Space v274_7;
    if (!v274_5.empty()) {
      const Space v275_6 = routine_50(c, v259_37_head, v259_37_tail);
      v274_7 = compose(v274_5,v275_6);
    }
    const Space v274_8 = intersect(constant_8,v274_2);
    const Space v274_9 = (has_head(v274_8) ? constant_9 : Space{});
    Space v274_11;
    if (!v274_9.empty()) {
      const Space v276_10 = routine_51(c, v259_37_head, v259_37_tail);
      v274_11 = compose(v274_9,v276_10);
    }
    const Space v274_12 = unite(v274_7,v274_11);
    v259_37_result = unite(v259_37_result,v274_12);
  }
  const Space v259_37 = std::move(v259_37_result);
  Space v259_42;
  if (!v259_37.empty()) {
    const Path v277_12 = concat_path(p2,p3);
    const Path v277_13 = concat_path(v277_12,p0);
    const Space v277_14 = singleton(v277_13);
    Space v277_41_result;
    for (int v277_41_label = 1; v277_41_label <= 2; ++v277_41_label) {
      const Space v277_41_tail = child(v277_14,v277_41_label);
      if (v277_41_tail.empty()) continue;
      const Path v277_41_head{v277_41_label};
      const Space v278_2 = singleton(v277_41_head);
      const Space v278_3 = intersect(constant_8,v278_2);
      const Space v278_4 = (has_head(v278_3) ? constant_9 : Space{});
      const Space v278_5 = subtract(constant_0,v278_4);
      Space v278_7;
      if (!v278_5.empty()) {
        const Space v279_6 = routine_52(c, v277_41_head, v277_41_tail);
        v278_7 = compose(v278_5,v279_6);
      }
      const Space v278_8 = intersect(constant_8,v278_2);
      const Space v278_9 = (has_head(v278_8) ? constant_9 : Space{});
      Space v278_11;
      if (!v278_9.empty()) {
        const Space v280_10 = routine_53(c, v277_41_head, v277_41_tail);
        v278_11 = compose(v278_9,v280_10);
      }
      const Space v278_12 = unite(v278_7,v278_11);
      v277_41_result = unite(v277_41_result,v278_12);
    }
    const Space v277_41 = std::move(v277_41_result);
    v259_42 = compose(v259_37,v277_41);
  }
  const Space v259_43 = unite(v259_31,v259_42);
  const Space v259_45 = intersect(constant_13,v259_6);
  Space v259_49_result;
  for (int v259_49_label = 1; v259_49_label <= 2; ++v259_49_label) {
    const Space v259_49_tail = child(v259_45,v259_49_label);
    if (v259_49_tail.empty()) continue;
    const Path v259_49_head{v259_49_label};
    const Space v281_2 = singleton(v259_49_head);
    const Space v281_3 = intersect(constant_8,v281_2);
    const Space v281_4 = (has_head(v281_3) ? constant_9 : Space{});
    const Space v281_5 = subtract(constant_0,v281_4);
    Space v281_7;
    if (!v281_5.empty()) {
      const Space v282_6 = routine_54(c, v259_49_head, v259_49_tail);
      v281_7 = compose(v281_5,v282_6);
    }
    const Space v281_8 = intersect(constant_8,v281_2);
    const Space v281_9 = (has_head(v281_8) ? constant_9 : Space{});
    Space v281_11;
    if (!v281_9.empty()) {
      const Space v283_10 = routine_55(c, v259_49_head, v259_49_tail);
      v281_11 = compose(v281_9,v283_10);
    }
    const Space v281_12 = unite(v281_7,v281_11);
    v259_49_result = unite(v259_49_result,v281_12);
  }
  const Space v259_49 = std::move(v259_49_result);
  Space v259_54;
  if (!v259_49.empty()) {
    const Path v284_12 = concat_path(p2,p3);
    const Path v284_13 = concat_path(v284_12,p0);
    const Space v284_14 = singleton(v284_13);
    Space v284_53_result;
    for (int v284_53_label = 1; v284_53_label <= 2; ++v284_53_label) {
      const Space v284_53_tail = child(v284_14,v284_53_label);
      if (v284_53_tail.empty()) continue;
      const Path v284_53_head{v284_53_label};
      const Space v285_2 = singleton(v284_53_head);
      const Space v285_3 = intersect(constant_8,v285_2);
      const Space v285_4 = (has_head(v285_3) ? constant_9 : Space{});
      const Space v285_5 = subtract(constant_0,v285_4);
      Space v285_7;
      if (!v285_5.empty()) {
        const Space v286_6 = routine_56(c, v284_53_head, v284_53_tail);
        v285_7 = compose(v285_5,v286_6);
      }
      const Space v285_8 = intersect(constant_8,v285_2);
      const Space v285_9 = (has_head(v285_8) ? constant_9 : Space{});
      Space v285_11;
      if (!v285_9.empty()) {
        const Space v287_10 = routine_57(c, v284_53_head, v284_53_tail);
        v285_11 = compose(v285_9,v287_10);
      }
      const Space v285_12 = unite(v285_7,v285_11);
      v284_53_result = unite(v284_53_result,v285_12);
    }
    const Space v284_53 = std::move(v284_53_result);
    v259_54 = compose(v259_49,v284_53);
  }
  const Space v259_55 = unite(v259_43,v259_54);
  Space v259_65_result;
  for (int v259_65_label = 1; v259_65_label <= 2; ++v259_65_label) {
    const Space v259_65_tail = child(v259_55,v259_65_label);
    if (v259_65_tail.empty()) continue;
    const Path v259_65_head{v259_65_label};
    const Space v288_2 = singleton(v259_65_head);
    const Space v288_3 = intersect(constant_8,v288_2);
    const Space v288_4 = (has_head(v288_3) ? constant_9 : Space{});
    const Space v288_5 = subtract(constant_0,v288_4);
    Space v288_7;
    if (!v288_5.empty()) {
      Space v289_6_result;
      for (int v289_6_label = 1; v289_6_label <= 2; ++v289_6_label) {
        const Space v289_6_tail = child(v259_65_tail,v289_6_label);
        if (v289_6_tail.empty()) continue;
        const Path v289_6_head{v289_6_label};
        const Space v290_2 = singleton(v289_6_head);
        const Space v290_3 = intersect(constant_8,v290_2);
        const Space v290_4 = (has_head(v290_3) ? constant_9 : Space{});
        const Space v290_5 = subtract(constant_0,v290_4);
        Space v290_8;
        if (!v290_5.empty()) {
          const Path v291_6 = concat_path(v259_65_head,v289_6_head);
          const Space v291_7 = routine_58(c, v291_6, p1, v289_6_tail);
          v290_8 = compose(v290_5,v291_7);
        }
        const Space v290_9 = intersect(constant_8,v290_2);
        const Space v290_10 = (has_head(v290_9) ? constant_9 : Space{});
        Space v290_12;
        if (!v290_10.empty()) {
          const Path v292_6 = concat_path(v259_65_head,v289_6_head);
          const Space v292_11 = routine_59(c, v292_6, p1, v289_6_tail);
          v290_12 = compose(v290_10,v292_11);
        }
        const Space v290_13 = unite(v290_8,v290_12);
        v289_6_result = unite(v289_6_result,v290_13);
      }
      const Space v289_6 = std::move(v289_6_result);
      v288_7 = compose(v288_5,v289_6);
    }
    const Space v288_8 = intersect(constant_8,v288_2);
    const Space v288_9 = (has_head(v288_8) ? constant_9 : Space{});
    Space v288_11;
    if (!v288_9.empty()) {
      Space v293_10_result;
      for (int v293_10_label = 1; v293_10_label <= 2; ++v293_10_label) {
        const Space v293_10_tail = child(v259_65_tail,v293_10_label);
        if (v293_10_tail.empty()) continue;
        const Path v293_10_head{v293_10_label};
        const Space v294_2 = singleton(v293_10_head);
        const Space v294_3 = intersect(constant_8,v294_2);
        const Space v294_4 = (has_head(v294_3) ? constant_9 : Space{});
        const Space v294_5 = subtract(constant_0,v294_4);
        Space v294_8;
        if (!v294_5.empty()) {
          const Path v295_6 = concat_path(v259_65_head,v293_10_head);
          const Space v295_7 = routine_58(c, v295_6, p1, v293_10_tail);
          v294_8 = compose(v294_5,v295_7);
        }
        const Space v294_9 = intersect(constant_8,v294_2);
        const Space v294_10 = (has_head(v294_9) ? constant_9 : Space{});
        Space v294_12;
        if (!v294_10.empty()) {
          const Path v296_6 = concat_path(v259_65_head,v293_10_head);
          const Space v296_11 = routine_60(c, v296_6, p1, v293_10_tail);
          v294_12 = compose(v294_10,v296_11);
        }
        const Space v294_13 = unite(v294_8,v294_12);
        v293_10_result = unite(v293_10_result,v294_13);
      }
      const Space v293_10 = std::move(v293_10_result);
      v288_11 = compose(v288_9,v293_10);
    }
    const Space v288_12 = unite(v288_7,v288_11);
    v259_65_result = unite(v259_65_result,v288_12);
  }
  const Space v259_65 = std::move(v259_65_result);
  Space v259_75_result;
  for (int v259_75_label = 1; v259_75_label <= 2; ++v259_75_label) {
    const Space v259_75_tail = child(v259_65,v259_75_label);
    if (v259_75_tail.empty()) continue;
    const Path v259_75_head{v259_75_label};
    const Space v297_2 = singleton(v259_75_head);
    const Space v297_3 = intersect(constant_8,v297_2);
    const Space v297_4 = (has_head(v297_3) ? constant_9 : Space{});
    const Space v297_5 = subtract(constant_0,v297_4);
    Space v297_7;
    if (!v297_5.empty()) {
      Space v298_6_result;
      for (int v298_6_label = 1; v298_6_label <= 2; ++v298_6_label) {
        const Space v298_6_tail = child(v259_75_tail,v298_6_label);
        if (v298_6_tail.empty()) continue;
        const Path v298_6_head{v298_6_label};
        const Space v299_2 = singleton(v298_6_head);
        const Space v299_3 = intersect(constant_8,v299_2);
        const Space v299_4 = (has_head(v299_3) ? constant_9 : Space{});
        const Space v299_5 = subtract(constant_0,v299_4);
        Space v299_8;
        if (!v299_5.empty()) {
          const Path v300_6 = concat_path(v259_75_head,v298_6_head);
          const Space v300_7 = routine_61(c, v300_6, p1, v298_6_tail);
          v299_8 = compose(v299_5,v300_7);
        }
        const Space v299_9 = intersect(constant_8,v299_2);
        const Space v299_10 = (has_head(v299_9) ? constant_9 : Space{});
        Space v299_12;
        if (!v299_10.empty()) {
          const Path v301_6 = concat_path(v259_75_head,v298_6_head);
          const Space v301_11 = routine_62(c, v301_6, p1, v298_6_tail);
          v299_12 = compose(v299_10,v301_11);
        }
        const Space v299_13 = unite(v299_8,v299_12);
        v298_6_result = unite(v298_6_result,v299_13);
      }
      const Space v298_6 = std::move(v298_6_result);
      v297_7 = compose(v297_5,v298_6);
    }
    const Space v297_8 = intersect(constant_8,v297_2);
    const Space v297_9 = (has_head(v297_8) ? constant_9 : Space{});
    Space v297_11;
    if (!v297_9.empty()) {
      Space v302_10_result;
      for (int v302_10_label = 1; v302_10_label <= 2; ++v302_10_label) {
        const Space v302_10_tail = child(v259_75_tail,v302_10_label);
        if (v302_10_tail.empty()) continue;
        const Path v302_10_head{v302_10_label};
        const Space v303_2 = singleton(v302_10_head);
        const Space v303_3 = intersect(constant_8,v303_2);
        const Space v303_4 = (has_head(v303_3) ? constant_9 : Space{});
        const Space v303_5 = subtract(constant_0,v303_4);
        Space v303_8;
        if (!v303_5.empty()) {
          const Path v304_6 = concat_path(v259_75_head,v302_10_head);
          const Space v304_7 = routine_61(c, v304_6, p1, v302_10_tail);
          v303_8 = compose(v303_5,v304_7);
        }
        const Space v303_9 = intersect(constant_8,v303_2);
        const Space v303_10 = (has_head(v303_9) ? constant_9 : Space{});
        Space v303_12;
        if (!v303_10.empty()) {
          const Path v305_6 = concat_path(v259_75_head,v302_10_head);
          const Space v305_11 = routine_63(c, v305_6, p1, v302_10_tail);
          v303_12 = compose(v303_10,v305_11);
        }
        const Space v303_13 = unite(v303_8,v303_12);
        v302_10_result = unite(v302_10_result,v303_13);
      }
      const Space v302_10 = std::move(v302_10_result);
      v297_11 = compose(v297_9,v302_10);
    }
    const Space v297_12 = unite(v297_7,v297_11);
    v259_75_result = unite(v259_75_result,v297_12);
  }
  const Space v259_75 = std::move(v259_75_result);
  return v259_75;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v306_4 = Space{};
  return v306_4;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v307_8_result;
  for (int v307_8_label = 1; v307_8_label <= 2; ++v307_8_label) {
    const Space v307_8_tail = child(s0,v307_8_label);
    if (v307_8_tail.empty()) continue;
    const Path v307_8_head{v307_8_label};
    const Space v308_2 = singleton(v307_8_head);
    const Space v308_3 = intersect(constant_8,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_9 : Space{});
    Space v308_7;
    if (!v308_4.empty()) {
      const Path v309_5 = concat_path(p0,v307_8_head);
      Space v309_6_result;
      for (int v309_6_label = 1; v309_6_label <= 2; ++v309_6_label) {
        const Space v309_6_tail = child(v307_8_tail,v309_6_label);
        if (v309_6_tail.empty()) continue;
        const Path v309_6_head{v309_6_label};
        const Space v310_2 = singleton(v309_6_head);
        const Space v310_3 = intersect(constant_8,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_9 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_7;
        if (!v310_5.empty()) {
          const Space v311_6 = routine_24(c, v309_6_head, p1, p2, v309_5, v309_6_tail);
          v310_7 = compose(v310_5,v311_6);
        }
        const Space v310_8 = intersect(constant_8,v310_2);
        const Space v310_9 = (has_head(v310_8) ? constant_9 : Space{});
        Space v310_11;
        if (!v310_9.empty()) {
          const Space v312_10 = routine_25(c, v309_6_head, p1, p2, v309_5, v309_6_tail);
          v310_11 = compose(v310_9,v312_10);
        }
        const Space v310_12 = unite(v310_7,v310_11);
        v309_6_result = unite(v309_6_result,v310_12);
      }
      const Space v309_6 = std::move(v309_6_result);
      v308_7 = compose(v308_4,v309_6);
    }
    v307_8_result = unite(v307_8_result,v308_7);
  }
  const Space v307_8 = std::move(v307_8_result);
  return v307_8;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v313_14_result;
  for (int v313_14_label = 1; v313_14_label <= 2; ++v313_14_label) {
    const Space v313_14_tail = child(s0,v313_14_label);
    if (v313_14_tail.empty()) continue;
    const Path v313_14_head{v313_14_label};
    const Space v314_2 = singleton(v313_14_head);
    const Space v314_3 = intersect(constant_8,v314_2);
    const Space v314_4 = (has_head(v314_3) ? constant_9 : Space{});
    const Space v314_5 = subtract(constant_0,v314_4);
    Space v314_8;
    if (!v314_5.empty()) {
      const Path v315_6 = concat_path(p0,v313_14_head);
      Space v315_7_result;
      for (int v315_7_label = 1; v315_7_label <= 2; ++v315_7_label) {
        const Space v315_7_tail = child(v313_14_tail,v315_7_label);
        if (v315_7_tail.empty()) continue;
        const Path v315_7_head{v315_7_label};
        const Space v316_2 = singleton(v315_7_head);
        const Space v316_3 = intersect(constant_8,v316_2);
        const Space v316_4 = (has_head(v316_3) ? constant_9 : Space{});
        const Space v316_5 = subtract(constant_0,v316_4);
        Space v316_8;
        if (!v316_5.empty()) {
          const Path v317_6 = concat_path(v315_6,v315_7_head);
          const Space v317_7 = routine_64(c, v317_6, p1, p2, p3, v315_7_tail);
          v316_8 = compose(v316_5,v317_7);
        }
        const Space v316_9 = intersect(constant_8,v316_2);
        const Space v316_10 = (has_head(v316_9) ? constant_9 : Space{});
        Space v316_12;
        if (!v316_10.empty()) {
          const Path v318_6 = concat_path(v315_6,v315_7_head);
          const Space v318_11 = routine_65(c, v318_6, p1, p2, p3, v315_7_tail);
          v316_12 = compose(v316_10,v318_11);
        }
        const Space v316_13 = unite(v316_8,v316_12);
        v315_7_result = unite(v315_7_result,v316_13);
      }
      const Space v315_7 = std::move(v315_7_result);
      v314_8 = compose(v314_5,v315_7);
    }
    const Space v314_9 = intersect(constant_8,v314_2);
    const Space v314_10 = (has_head(v314_9) ? constant_9 : Space{});
    Space v314_12;
    if (!v314_10.empty()) {
      const Path v319_6 = concat_path(p0,v313_14_head);
      Space v319_11_result;
      for (int v319_11_label = 1; v319_11_label <= 2; ++v319_11_label) {
        const Space v319_11_tail = child(v313_14_tail,v319_11_label);
        if (v319_11_tail.empty()) continue;
        const Path v319_11_head{v319_11_label};
        const Space v320_2 = singleton(v319_11_head);
        const Space v320_3 = intersect(constant_8,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_9 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_11_head);
          const Space v321_7 = routine_64(c, v321_6, p1, p2, p3, v319_11_tail);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_8,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_9 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_11_head);
          const Space v322_11 = routine_30(c, v322_6, p1, p2, p3, v319_11_tail);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_11_result = unite(v319_11_result,v320_13);
      }
      const Space v319_11 = std::move(v319_11_result);
      v314_12 = compose(v314_10,v319_11);
    }
    const Space v314_13 = unite(v314_8,v314_12);
    v313_14_result = unite(v313_14_result,v314_13);
  }
  const Space v313_14 = std::move(v313_14_result);
  return v313_14;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v323_8 = concat_path(p2,p3);
  Space v323_18_result;
  for (int v323_18_label = 1; v323_18_label <= 2; ++v323_18_label) {
    const Space v323_18_tail = child(s0,v323_18_label);
    if (v323_18_tail.empty()) continue;
    const Path v323_18_head{v323_18_label};
    const Space v324_2 = singleton(v323_18_head);
    const Space v324_3 = intersect(constant_8,v324_2);
    const Space v324_4 = (has_head(v324_3) ? constant_9 : Space{});
    const Space v324_5 = subtract(constant_0,v324_4);
    Space v324_8;
    if (!v324_5.empty()) {
      const Path v325_6 = concat_path(p0,v323_18_head);
      Space v325_7_result;
      for (int v325_7_label = 1; v325_7_label <= 2; ++v325_7_label) {
        const Space v325_7_tail = child(v323_18_tail,v325_7_label);
        if (v325_7_tail.empty()) continue;
        const Path v325_7_head{v325_7_label};
        const Space v326_2 = singleton(v325_7_head);
        const Space v326_3 = intersect(constant_8,v326_2);
        const Space v326_4 = (has_head(v326_3) ? constant_9 : Space{});
        const Space v326_5 = subtract(constant_0,v326_4);
        Space v326_8;
        if (!v326_5.empty()) {
          const Path v327_6 = concat_path(v325_6,v325_7_head);
          const Space v327_7 = routine_64(c, v327_6, p1, p2, p3, v325_7_tail);
          v326_8 = compose(v326_5,v327_7);
        }
        const Space v326_9 = intersect(constant_8,v326_2);
        const Space v326_10 = (has_head(v326_9) ? constant_9 : Space{});
        Space v326_12;
        if (!v326_10.empty()) {
          const Path v328_6 = concat_path(v325_6,v325_7_head);
          const Space v328_11 = routine_65(c, v328_6, p1, p2, p3, v325_7_tail);
          v326_12 = compose(v326_10,v328_11);
        }
        const Space v326_13 = unite(v326_8,v326_12);
        v325_7_result = unite(v325_7_result,v326_13);
      }
      const Space v325_7 = std::move(v325_7_result);
      v324_8 = compose(v324_5,v325_7);
    }
    const Space v324_9 = intersect(constant_8,v324_2);
    const Space v324_10 = (has_head(v324_9) ? constant_9 : Space{});
    Space v324_16;
    if (!v324_10.empty()) {
      const Path v329_6 = concat_path(p0,v323_18_head);
      const Path v329_11 = concat_path(v323_8,v329_6);
      const Space v329_12 = singleton(v329_11);
      const Space v329_13 = routine_35(c, p1, v329_12);
      Space v329_14_result;
      for (int v329_14_label = 1; v329_14_label <= 2; ++v329_14_label) {
        const Space v329_14_tail = child(v329_13,v329_14_label);
        if (v329_14_tail.empty()) continue;
        const Path v329_14_head{v329_14_label};
        const Space v330_2 = singleton(v329_14_head);
        const Space v330_3 = intersect(constant_8,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_9 : Space{});
        const Space v330_5 = subtract(constant_0,v330_4);
        Space v330_7;
        if (!v330_5.empty()) {
          const Space v331_6 = routine_36(c, v329_14_head, p1, v329_14_tail);
          v330_7 = compose(v330_5,v331_6);
        }
        const Space v330_8 = intersect(constant_8,v330_2);
        const Space v330_9 = (has_head(v330_8) ? constant_9 : Space{});
        Space v330_11;
        if (!v330_9.empty()) {
          const Space v332_10 = routine_37(c, v329_14_head, p1, v329_14_tail);
          v330_11 = compose(v330_9,v332_10);
        }
        const Space v330_12 = unite(v330_7,v330_11);
        v329_14_result = unite(v329_14_result,v330_12);
      }
      const Space v329_14 = std::move(v329_14_result);
      Space v329_15_result;
      for (int v329_15_label = 1; v329_15_label <= 2; ++v329_15_label) {
        const Space v329_15_tail = child(v329_14,v329_15_label);
        if (v329_15_tail.empty()) continue;
        const Path v329_15_head{v329_15_label};
        const Space v333_2 = singleton(v329_15_head);
        const Space v333_3 = intersect(constant_8,v333_2);
        const Space v333_4 = (has_head(v333_3) ? constant_9 : Space{});
        const Space v333_5 = subtract(constant_0,v333_4);
        Space v333_7;
        if (!v333_5.empty()) {
          const Space v334_6 = routine_38(c, v329_15_head, p1, v329_15_tail);
          v333_7 = compose(v333_5,v334_6);
        }
        const Space v333_8 = intersect(constant_8,v333_2);
        const Space v333_9 = (has_head(v333_8) ? constant_9 : Space{});
        Space v333_11;
        if (!v333_9.empty()) {
          const Space v335_10 = routine_39(c, v329_15_head, p1, v329_15_tail);
          v333_11 = compose(v333_9,v335_10);
        }
        const Space v333_12 = unite(v333_7,v333_11);
        v329_15_result = unite(v329_15_result,v333_12);
      }
      const Space v329_15 = std::move(v329_15_result);
      v324_16 = compose(v324_10,v329_15);
    }
    const Space v324_17 = unite(v324_8,v324_16);
    v323_18_result = unite(v323_18_result,v324_17);
  }
  const Space v323_18 = std::move(v323_18_result);
  return v323_18;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  const Space v336_3 = singleton(p0);
  const Space v336_4 = intersect(constant_10,v336_3);
  Space v336_14_result;
  for (int v336_14_label = 1; v336_14_label <= 2; ++v336_14_label) {
    const Space v336_14_tail = child(v336_4,v336_14_label);
    if (v336_14_tail.empty()) continue;
    const Path v336_14_head{v336_14_label};
    const Space v337_2 = singleton(v336_14_head);
    const Space v337_3 = intersect(constant_8,v337_2);
    const Space v337_4 = (has_head(v337_3) ? constant_9 : Space{});
    const Space v337_5 = subtract(constant_0,v337_4);
    Space v337_7;
    if (!v337_5.empty()) {
      Space v338_6_result;
      for (int v338_6_label = 1; v338_6_label <= 2; ++v338_6_label) {
        const Space v338_6_tail = child(v336_14_tail,v338_6_label);
        if (v338_6_tail.empty()) continue;
        const Path v338_6_head{v338_6_label};
        const Space v339_2 = singleton(v338_6_head);
        const Space v339_3 = intersect(constant_8,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_9 : Space{});
        const Space v339_5 = subtract(constant_0,v339_4);
        Space v339_8;
        if (!v339_5.empty()) {
          const Path v340_6 = concat_path(v336_14_head,v338_6_head);
          const Space v340_7 = routine_66(c, v340_6, v338_6_tail);
          v339_8 = compose(v339_5,v340_7);
        }
        const Space v339_9 = intersect(constant_8,v339_2);
        const Space v339_10 = (has_head(v339_9) ? constant_9 : Space{});
        Space v339_12;
        if (!v339_10.empty()) {
          const Path v341_6 = concat_path(v336_14_head,v338_6_head);
          const Space v341_11 = routine_67(c, v341_6, v338_6_tail);
          v339_12 = compose(v339_10,v341_11);
        }
        const Space v339_13 = unite(v339_8,v339_12);
        v338_6_result = unite(v338_6_result,v339_13);
      }
      const Space v338_6 = std::move(v338_6_result);
      v337_7 = compose(v337_5,v338_6);
    }
    const Space v337_8 = intersect(constant_8,v337_2);
    const Space v337_9 = (has_head(v337_8) ? constant_9 : Space{});
    Space v337_11;
    if (!v337_9.empty()) {
      Space v342_10_result;
      for (int v342_10_label = 1; v342_10_label <= 2; ++v342_10_label) {
        const Space v342_10_tail = child(v336_14_tail,v342_10_label);
        if (v342_10_tail.empty()) continue;
        const Path v342_10_head{v342_10_label};
        const Space v343_2 = singleton(v342_10_head);
        const Space v343_3 = intersect(constant_8,v343_2);
        const Space v343_4 = (has_head(v343_3) ? constant_9 : Space{});
        const Space v343_5 = subtract(constant_0,v343_4);
        Space v343_8;
        if (!v343_5.empty()) {
          const Path v344_6 = concat_path(v336_14_head,v342_10_head);
          const Space v344_7 = routine_66(c, v344_6, v342_10_tail);
          v343_8 = compose(v343_5,v344_7);
        }
        const Space v343_9 = intersect(constant_8,v343_2);
        const Space v343_10 = (has_head(v343_9) ? constant_9 : Space{});
        Space v343_12;
        if (!v343_10.empty()) {
          const Path v345_6 = concat_path(v336_14_head,v342_10_head);
          const Space v345_11 = routine_68(c, v345_6, v342_10_tail);
          v343_12 = compose(v343_10,v345_11);
        }
        const Space v343_13 = unite(v343_8,v343_12);
        v342_10_result = unite(v342_10_result,v343_13);
      }
      const Space v342_10 = std::move(v342_10_result);
      v337_11 = compose(v337_9,v342_10);
    }
    const Space v337_12 = unite(v337_7,v337_11);
    v336_14_result = unite(v336_14_result,v337_12);
  }
  const Space v336_14 = std::move(v336_14_result);
  Space v336_25;
  if (!v336_14.empty()) {
    Space v346_24_result;
    for (int v346_24_label = 1; v346_24_label <= 2; ++v346_24_label) {
      const Space v346_24_tail = child(s0,v346_24_label);
      if (v346_24_tail.empty()) continue;
      const Path v346_24_head{v346_24_label};
      const Space v347_2 = singleton(v346_24_head);
      const Space v347_3 = intersect(constant_8,v347_2);
      const Space v347_4 = (has_head(v347_3) ? constant_9 : Space{});
      const Space v347_5 = subtract(constant_0,v347_4);
      Space v347_7;
      if (!v347_5.empty()) {
        Space v348_6_result;
        for (int v348_6_label = 1; v348_6_label <= 2; ++v348_6_label) {
          const Space v348_6_tail = child(v346_24_tail,v348_6_label);
          if (v348_6_tail.empty()) continue;
          const Path v348_6_head{v348_6_label};
          const Space v349_2 = singleton(v348_6_head);
          const Space v349_3 = intersect(constant_8,v349_2);
          const Space v349_4 = (has_head(v349_3) ? constant_9 : Space{});
          const Space v349_5 = subtract(constant_0,v349_4);
          Space v349_8;
          if (!v349_5.empty()) {
            const Path v350_6 = concat_path(v346_24_head,v348_6_head);
            const Space v350_7 = routine_69(c, v350_6, v348_6_tail);
            v349_8 = compose(v349_5,v350_7);
          }
          const Space v349_9 = intersect(constant_8,v349_2);
          const Space v349_10 = (has_head(v349_9) ? constant_9 : Space{});
          Space v349_12;
          if (!v349_10.empty()) {
            const Path v351_6 = concat_path(v346_24_head,v348_6_head);
            const Space v351_11 = routine_70(c, v351_6, v348_6_tail);
            v349_12 = compose(v349_10,v351_11);
          }
          const Space v349_13 = unite(v349_8,v349_12);
          v348_6_result = unite(v348_6_result,v349_13);
        }
        const Space v348_6 = std::move(v348_6_result);
        v347_7 = compose(v347_5,v348_6);
      }
      const Space v347_8 = intersect(constant_8,v347_2);
      const Space v347_9 = (has_head(v347_8) ? constant_9 : Space{});
      Space v347_11;
      if (!v347_9.empty()) {
        Space v352_10_result;
        for (int v352_10_label = 1; v352_10_label <= 2; ++v352_10_label) {
          const Space v352_10_tail = child(v346_24_tail,v352_10_label);
          if (v352_10_tail.empty()) continue;
          const Path v352_10_head{v352_10_label};
          const Space v353_2 = singleton(v352_10_head);
          const Space v353_3 = intersect(constant_8,v353_2);
          const Space v353_4 = (has_head(v353_3) ? constant_9 : Space{});
          const Space v353_5 = subtract(constant_0,v353_4);
          Space v353_8;
          if (!v353_5.empty()) {
            const Path v354_6 = concat_path(v346_24_head,v352_10_head);
            const Space v354_7 = routine_69(c, v354_6, v352_10_tail);
            v353_8 = compose(v353_5,v354_7);
          }
          const Space v353_9 = intersect(constant_8,v353_2);
          const Space v353_10 = (has_head(v353_9) ? constant_9 : Space{});
          Space v353_12;
          if (!v353_10.empty()) {
            const Path v355_6 = concat_path(v346_24_head,v352_10_head);
            const Space v355_11 = routine_71(c, v355_6, v352_10_tail);
            v353_12 = compose(v353_10,v355_11);
          }
          const Space v353_13 = unite(v353_8,v353_12);
          v352_10_result = unite(v352_10_result,v353_13);
        }
        const Space v352_10 = std::move(v352_10_result);
        v347_11 = compose(v347_9,v352_10);
      }
      const Space v347_12 = unite(v347_7,v347_11);
      v346_24_result = unite(v346_24_result,v347_12);
    }
    const Space v346_24 = std::move(v346_24_result);
    v336_25 = compose(v336_14,v346_24);
  }
  const Space v336_27 = intersect(constant_11,v336_3);
  Space v336_37_result;
  for (int v336_37_label = 1; v336_37_label <= 2; ++v336_37_label) {
    const Space v336_37_tail = child(v336_27,v336_37_label);
    if (v336_37_tail.empty()) continue;
    const Path v336_37_head{v336_37_label};
    const Space v356_2 = singleton(v336_37_head);
    const Space v356_3 = intersect(constant_8,v356_2);
    const Space v356_4 = (has_head(v356_3) ? constant_9 : Space{});
    const Space v356_5 = subtract(constant_0,v356_4);
    Space v356_7;
    if (!v356_5.empty()) {
      Space v357_6_result;
      for (int v357_6_label = 1; v357_6_label <= 2; ++v357_6_label) {
        const Space v357_6_tail = child(v336_37_tail,v357_6_label);
        if (v357_6_tail.empty()) continue;
        const Path v357_6_head{v357_6_label};
        const Space v358_2 = singleton(v357_6_head);
        const Space v358_3 = intersect(constant_8,v358_2);
        const Space v358_4 = (has_head(v358_3) ? constant_9 : Space{});
        const Space v358_5 = subtract(constant_0,v358_4);
        Space v358_8;
        if (!v358_5.empty()) {
          const Path v359_6 = concat_path(v336_37_head,v357_6_head);
          const Space v359_7 = routine_72(c, v359_6, v357_6_tail);
          v358_8 = compose(v358_5,v359_7);
        }
        const Space v358_9 = intersect(constant_8,v358_2);
        const Space v358_10 = (has_head(v358_9) ? constant_9 : Space{});
        Space v358_12;
        if (!v358_10.empty()) {
          const Path v360_6 = concat_path(v336_37_head,v357_6_head);
          const Space v360_11 = routine_73(c, v360_6, v357_6_tail);
          v358_12 = compose(v358_10,v360_11);
        }
        const Space v358_13 = unite(v358_8,v358_12);
        v357_6_result = unite(v357_6_result,v358_13);
      }
      const Space v357_6 = std::move(v357_6_result);
      v356_7 = compose(v356_5,v357_6);
    }
    const Space v356_8 = intersect(constant_8,v356_2);
    const Space v356_9 = (has_head(v356_8) ? constant_9 : Space{});
    Space v356_11;
    if (!v356_9.empty()) {
      Space v361_10_result;
      for (int v361_10_label = 1; v361_10_label <= 2; ++v361_10_label) {
        const Space v361_10_tail = child(v336_37_tail,v361_10_label);
        if (v361_10_tail.empty()) continue;
        const Path v361_10_head{v361_10_label};
        const Space v362_2 = singleton(v361_10_head);
        const Space v362_3 = intersect(constant_8,v362_2);
        const Space v362_4 = (has_head(v362_3) ? constant_9 : Space{});
        const Space v362_5 = subtract(constant_0,v362_4);
        Space v362_8;
        if (!v362_5.empty()) {
          const Path v363_6 = concat_path(v336_37_head,v361_10_head);
          const Space v363_7 = routine_72(c, v363_6, v361_10_tail);
          v362_8 = compose(v362_5,v363_7);
        }
        const Space v362_9 = intersect(constant_8,v362_2);
        const Space v362_10 = (has_head(v362_9) ? constant_9 : Space{});
        Space v362_12;
        if (!v362_10.empty()) {
          const Path v364_6 = concat_path(v336_37_head,v361_10_head);
          const Space v364_11 = routine_74(c, v364_6, v361_10_tail);
          v362_12 = compose(v362_10,v364_11);
        }
        const Space v362_13 = unite(v362_8,v362_12);
        v361_10_result = unite(v361_10_result,v362_13);
      }
      const Space v361_10 = std::move(v361_10_result);
      v356_11 = compose(v356_9,v361_10);
    }
    const Space v356_12 = unite(v356_7,v356_11);
    v336_37_result = unite(v336_37_result,v356_12);
  }
  const Space v336_37 = std::move(v336_37_result);
  Space v336_48;
  if (!v336_37.empty()) {
    Space v365_47_result;
    for (int v365_47_label = 1; v365_47_label <= 2; ++v365_47_label) {
      const Space v365_47_tail = child(s0,v365_47_label);
      if (v365_47_tail.empty()) continue;
      const Path v365_47_head{v365_47_label};
      const Space v366_2 = singleton(v365_47_head);
      const Space v366_3 = intersect(constant_8,v366_2);
      const Space v366_4 = (has_head(v366_3) ? constant_9 : Space{});
      const Space v366_5 = subtract(constant_0,v366_4);
      Space v366_7;
      if (!v366_5.empty()) {
        Space v367_6_result;
        for (int v367_6_label = 1; v367_6_label <= 2; ++v367_6_label) {
          const Space v367_6_tail = child(v365_47_tail,v367_6_label);
          if (v367_6_tail.empty()) continue;
          const Path v367_6_head{v367_6_label};
          const Space v368_2 = singleton(v367_6_head);
          const Space v368_3 = intersect(constant_8,v368_2);
          const Space v368_4 = (has_head(v368_3) ? constant_9 : Space{});
          const Space v368_5 = subtract(constant_0,v368_4);
          Space v368_8;
          if (!v368_5.empty()) {
            const Path v369_6 = concat_path(v365_47_head,v367_6_head);
            const Space v369_7 = routine_75(c, v369_6, v367_6_tail);
            v368_8 = compose(v368_5,v369_7);
          }
          const Space v368_9 = intersect(constant_8,v368_2);
          const Space v368_10 = (has_head(v368_9) ? constant_9 : Space{});
          Space v368_12;
          if (!v368_10.empty()) {
            const Path v370_6 = concat_path(v365_47_head,v367_6_head);
            const Space v370_11 = routine_76(c, v370_6, v367_6_tail);
            v368_12 = compose(v368_10,v370_11);
          }
          const Space v368_13 = unite(v368_8,v368_12);
          v367_6_result = unite(v367_6_result,v368_13);
        }
        const Space v367_6 = std::move(v367_6_result);
        v366_7 = compose(v366_5,v367_6);
      }
      const Space v366_8 = intersect(constant_8,v366_2);
      const Space v366_9 = (has_head(v366_8) ? constant_9 : Space{});
      Space v366_11;
      if (!v366_9.empty()) {
        Space v371_10_result;
        for (int v371_10_label = 1; v371_10_label <= 2; ++v371_10_label) {
          const Space v371_10_tail = child(v365_47_tail,v371_10_label);
          if (v371_10_tail.empty()) continue;
          const Path v371_10_head{v371_10_label};
          const Space v372_2 = singleton(v371_10_head);
          const Space v372_3 = intersect(constant_8,v372_2);
          const Space v372_4 = (has_head(v372_3) ? constant_9 : Space{});
          const Space v372_5 = subtract(constant_0,v372_4);
          Space v372_8;
          if (!v372_5.empty()) {
            const Path v373_6 = concat_path(v365_47_head,v371_10_head);
            const Space v373_7 = routine_75(c, v373_6, v371_10_tail);
            v372_8 = compose(v372_5,v373_7);
          }
          const Space v372_9 = intersect(constant_8,v372_2);
          const Space v372_10 = (has_head(v372_9) ? constant_9 : Space{});
          Space v372_12;
          if (!v372_10.empty()) {
            const Path v374_6 = concat_path(v365_47_head,v371_10_head);
            const Space v374_11 = routine_77(c, v374_6, v371_10_tail);
            v372_12 = compose(v372_10,v374_11);
          }
          const Space v372_13 = unite(v372_8,v372_12);
          v371_10_result = unite(v371_10_result,v372_13);
        }
        const Space v371_10 = std::move(v371_10_result);
        v366_11 = compose(v366_9,v371_10);
      }
      const Space v366_12 = unite(v366_7,v366_11);
      v365_47_result = unite(v365_47_result,v366_12);
    }
    const Space v365_47 = std::move(v365_47_result);
    v336_48 = compose(v336_37,v365_47);
  }
  const Space v336_49 = unite(v336_25,v336_48);
  const Space v336_51 = intersect(constant_12,v336_3);
  Space v336_61_result;
  for (int v336_61_label = 1; v336_61_label <= 2; ++v336_61_label) {
    const Space v336_61_tail = child(v336_51,v336_61_label);
    if (v336_61_tail.empty()) continue;
    const Path v336_61_head{v336_61_label};
    const Space v375_2 = singleton(v336_61_head);
    const Space v375_3 = intersect(constant_8,v375_2);
    const Space v375_4 = (has_head(v375_3) ? constant_9 : Space{});
    const Space v375_5 = subtract(constant_0,v375_4);
    Space v375_7;
    if (!v375_5.empty()) {
      Space v376_6_result;
      for (int v376_6_label = 1; v376_6_label <= 2; ++v376_6_label) {
        const Space v376_6_tail = child(v336_61_tail,v376_6_label);
        if (v376_6_tail.empty()) continue;
        const Path v376_6_head{v376_6_label};
        const Space v377_2 = singleton(v376_6_head);
        const Space v377_3 = intersect(constant_8,v377_2);
        const Space v377_4 = (has_head(v377_3) ? constant_9 : Space{});
        const Space v377_5 = subtract(constant_0,v377_4);
        Space v377_8;
        if (!v377_5.empty()) {
          const Path v378_6 = concat_path(v336_61_head,v376_6_head);
          const Space v378_7 = routine_78(c, v378_6, v376_6_tail);
          v377_8 = compose(v377_5,v378_7);
        }
        const Space v377_9 = intersect(constant_8,v377_2);
        const Space v377_10 = (has_head(v377_9) ? constant_9 : Space{});
        Space v377_12;
        if (!v377_10.empty()) {
          const Path v379_6 = concat_path(v336_61_head,v376_6_head);
          const Space v379_11 = routine_79(c, v379_6, v376_6_tail);
          v377_12 = compose(v377_10,v379_11);
        }
        const Space v377_13 = unite(v377_8,v377_12);
        v376_6_result = unite(v376_6_result,v377_13);
      }
      const Space v376_6 = std::move(v376_6_result);
      v375_7 = compose(v375_5,v376_6);
    }
    const Space v375_8 = intersect(constant_8,v375_2);
    const Space v375_9 = (has_head(v375_8) ? constant_9 : Space{});
    Space v375_11;
    if (!v375_9.empty()) {
      Space v380_10_result;
      for (int v380_10_label = 1; v380_10_label <= 2; ++v380_10_label) {
        const Space v380_10_tail = child(v336_61_tail,v380_10_label);
        if (v380_10_tail.empty()) continue;
        const Path v380_10_head{v380_10_label};
        const Space v381_2 = singleton(v380_10_head);
        const Space v381_3 = intersect(constant_8,v381_2);
        const Space v381_4 = (has_head(v381_3) ? constant_9 : Space{});
        const Space v381_5 = subtract(constant_0,v381_4);
        Space v381_8;
        if (!v381_5.empty()) {
          const Path v382_6 = concat_path(v336_61_head,v380_10_head);
          const Space v382_7 = routine_78(c, v382_6, v380_10_tail);
          v381_8 = compose(v381_5,v382_7);
        }
        const Space v381_9 = intersect(constant_8,v381_2);
        const Space v381_10 = (has_head(v381_9) ? constant_9 : Space{});
        Space v381_12;
        if (!v381_10.empty()) {
          const Path v383_6 = concat_path(v336_61_head,v380_10_head);
          const Space v383_11 = routine_80(c, v383_6, v380_10_tail);
          v381_12 = compose(v381_10,v383_11);
        }
        const Space v381_13 = unite(v381_8,v381_12);
        v380_10_result = unite(v380_10_result,v381_13);
      }
      const Space v380_10 = std::move(v380_10_result);
      v375_11 = compose(v375_9,v380_10);
    }
    const Space v375_12 = unite(v375_7,v375_11);
    v336_61_result = unite(v336_61_result,v375_12);
  }
  const Space v336_61 = std::move(v336_61_result);
  Space v336_72;
  if (!v336_61.empty()) {
    Space v384_71_result;
    for (int v384_71_label = 1; v384_71_label <= 2; ++v384_71_label) {
      const Space v384_71_tail = child(s0,v384_71_label);
      if (v384_71_tail.empty()) continue;
      const Path v384_71_head{v384_71_label};
      const Space v385_2 = singleton(v384_71_head);
      const Space v385_3 = intersect(constant_8,v385_2);
      const Space v385_4 = (has_head(v385_3) ? constant_9 : Space{});
      const Space v385_5 = subtract(constant_0,v385_4);
      Space v385_7;
      if (!v385_5.empty()) {
        Space v386_6_result;
        for (int v386_6_label = 1; v386_6_label <= 2; ++v386_6_label) {
          const Space v386_6_tail = child(v384_71_tail,v386_6_label);
          if (v386_6_tail.empty()) continue;
          const Path v386_6_head{v386_6_label};
          const Space v387_2 = singleton(v386_6_head);
          const Space v387_3 = intersect(constant_8,v387_2);
          const Space v387_4 = (has_head(v387_3) ? constant_9 : Space{});
          const Space v387_5 = subtract(constant_0,v387_4);
          Space v387_8;
          if (!v387_5.empty()) {
            const Path v388_6 = concat_path(v384_71_head,v386_6_head);
            const Space v388_7 = routine_81(c, v388_6, v386_6_tail);
            v387_8 = compose(v387_5,v388_7);
          }
          const Space v387_9 = intersect(constant_8,v387_2);
          const Space v387_10 = (has_head(v387_9) ? constant_9 : Space{});
          Space v387_12;
          if (!v387_10.empty()) {
            const Path v389_6 = concat_path(v384_71_head,v386_6_head);
            const Space v389_11 = routine_82(c, v389_6, v386_6_tail);
            v387_12 = compose(v387_10,v389_11);
          }
          const Space v387_13 = unite(v387_8,v387_12);
          v386_6_result = unite(v386_6_result,v387_13);
        }
        const Space v386_6 = std::move(v386_6_result);
        v385_7 = compose(v385_5,v386_6);
      }
      const Space v385_8 = intersect(constant_8,v385_2);
      const Space v385_9 = (has_head(v385_8) ? constant_9 : Space{});
      Space v385_11;
      if (!v385_9.empty()) {
        Space v390_10_result;
        for (int v390_10_label = 1; v390_10_label <= 2; ++v390_10_label) {
          const Space v390_10_tail = child(v384_71_tail,v390_10_label);
          if (v390_10_tail.empty()) continue;
          const Path v390_10_head{v390_10_label};
          const Space v391_2 = singleton(v390_10_head);
          const Space v391_3 = intersect(constant_8,v391_2);
          const Space v391_4 = (has_head(v391_3) ? constant_9 : Space{});
          const Space v391_5 = subtract(constant_0,v391_4);
          Space v391_8;
          if (!v391_5.empty()) {
            const Path v392_6 = concat_path(v384_71_head,v390_10_head);
            const Space v392_7 = routine_81(c, v392_6, v390_10_tail);
            v391_8 = compose(v391_5,v392_7);
          }
          const Space v391_9 = intersect(constant_8,v391_2);
          const Space v391_10 = (has_head(v391_9) ? constant_9 : Space{});
          Space v391_12;
          if (!v391_10.empty()) {
            const Path v393_6 = concat_path(v384_71_head,v390_10_head);
            const Space v393_11 = routine_83(c, v393_6, v390_10_tail);
            v391_12 = compose(v391_10,v393_11);
          }
          const Space v391_13 = unite(v391_8,v391_12);
          v390_10_result = unite(v390_10_result,v391_13);
        }
        const Space v390_10 = std::move(v390_10_result);
        v385_11 = compose(v385_9,v390_10);
      }
      const Space v385_12 = unite(v385_7,v385_11);
      v384_71_result = unite(v384_71_result,v385_12);
    }
    const Space v384_71 = std::move(v384_71_result);
    v336_72 = compose(v336_61,v384_71);
  }
  const Space v336_73 = unite(v336_49,v336_72);
  const Space v336_75 = intersect(constant_13,v336_3);
  Space v336_85_result;
  for (int v336_85_label = 1; v336_85_label <= 2; ++v336_85_label) {
    const Space v336_85_tail = child(v336_75,v336_85_label);
    if (v336_85_tail.empty()) continue;
    const Path v336_85_head{v336_85_label};
    const Space v394_2 = singleton(v336_85_head);
    const Space v394_3 = intersect(constant_8,v394_2);
    const Space v394_4 = (has_head(v394_3) ? constant_9 : Space{});
    const Space v394_5 = subtract(constant_0,v394_4);
    Space v394_7;
    if (!v394_5.empty()) {
      Space v395_6_result;
      for (int v395_6_label = 1; v395_6_label <= 2; ++v395_6_label) {
        const Space v395_6_tail = child(v336_85_tail,v395_6_label);
        if (v395_6_tail.empty()) continue;
        const Path v395_6_head{v395_6_label};
        const Space v396_2 = singleton(v395_6_head);
        const Space v396_3 = intersect(constant_8,v396_2);
        const Space v396_4 = (has_head(v396_3) ? constant_9 : Space{});
        const Space v396_5 = subtract(constant_0,v396_4);
        Space v396_8;
        if (!v396_5.empty()) {
          const Path v397_6 = concat_path(v336_85_head,v395_6_head);
          const Space v397_7 = routine_84(c, v397_6, v395_6_tail);
          v396_8 = compose(v396_5,v397_7);
        }
        const Space v396_9 = intersect(constant_8,v396_2);
        const Space v396_10 = (has_head(v396_9) ? constant_9 : Space{});
        Space v396_12;
        if (!v396_10.empty()) {
          const Path v398_6 = concat_path(v336_85_head,v395_6_head);
          const Space v398_11 = routine_85(c, v398_6, v395_6_tail);
          v396_12 = compose(v396_10,v398_11);
        }
        const Space v396_13 = unite(v396_8,v396_12);
        v395_6_result = unite(v395_6_result,v396_13);
      }
      const Space v395_6 = std::move(v395_6_result);
      v394_7 = compose(v394_5,v395_6);
    }
    const Space v394_8 = intersect(constant_8,v394_2);
    const Space v394_9 = (has_head(v394_8) ? constant_9 : Space{});
    Space v394_11;
    if (!v394_9.empty()) {
      Space v399_10_result;
      for (int v399_10_label = 1; v399_10_label <= 2; ++v399_10_label) {
        const Space v399_10_tail = child(v336_85_tail,v399_10_label);
        if (v399_10_tail.empty()) continue;
        const Path v399_10_head{v399_10_label};
        const Space v400_2 = singleton(v399_10_head);
        const Space v400_3 = intersect(constant_8,v400_2);
        const Space v400_4 = (has_head(v400_3) ? constant_9 : Space{});
        const Space v400_5 = subtract(constant_0,v400_4);
        Space v400_8;
        if (!v400_5.empty()) {
          const Path v401_6 = concat_path(v336_85_head,v399_10_head);
          const Space v401_7 = routine_84(c, v401_6, v399_10_tail);
          v400_8 = compose(v400_5,v401_7);
        }
        const Space v400_9 = intersect(constant_8,v400_2);
        const Space v400_10 = (has_head(v400_9) ? constant_9 : Space{});
        Space v400_12;
        if (!v400_10.empty()) {
          const Path v402_6 = concat_path(v336_85_head,v399_10_head);
          const Space v402_11 = routine_86(c, v402_6, v399_10_tail);
          v400_12 = compose(v400_10,v402_11);
        }
        const Space v400_13 = unite(v400_8,v400_12);
        v399_10_result = unite(v399_10_result,v400_13);
      }
      const Space v399_10 = std::move(v399_10_result);
      v394_11 = compose(v394_9,v399_10);
    }
    const Space v394_12 = unite(v394_7,v394_11);
    v336_85_result = unite(v336_85_result,v394_12);
  }
  const Space v336_85 = std::move(v336_85_result);
  Space v336_96;
  if (!v336_85.empty()) {
    Space v403_95_result;
    for (int v403_95_label = 1; v403_95_label <= 2; ++v403_95_label) {
      const Space v403_95_tail = child(s0,v403_95_label);
      if (v403_95_tail.empty()) continue;
      const Path v403_95_head{v403_95_label};
      const Space v404_2 = singleton(v403_95_head);
      const Space v404_3 = intersect(constant_8,v404_2);
      const Space v404_4 = (has_head(v404_3) ? constant_9 : Space{});
      const Space v404_5 = subtract(constant_0,v404_4);
      Space v404_7;
      if (!v404_5.empty()) {
        Space v405_6_result;
        for (int v405_6_label = 1; v405_6_label <= 2; ++v405_6_label) {
          const Space v405_6_tail = child(v403_95_tail,v405_6_label);
          if (v405_6_tail.empty()) continue;
          const Path v405_6_head{v405_6_label};
          const Space v406_2 = singleton(v405_6_head);
          const Space v406_3 = intersect(constant_8,v406_2);
          const Space v406_4 = (has_head(v406_3) ? constant_9 : Space{});
          const Space v406_5 = subtract(constant_0,v406_4);
          Space v406_8;
          if (!v406_5.empty()) {
            const Path v407_6 = concat_path(v403_95_head,v405_6_head);
            const Space v407_7 = routine_87(c, v407_6, v405_6_tail);
            v406_8 = compose(v406_5,v407_7);
          }
          const Space v406_9 = intersect(constant_8,v406_2);
          const Space v406_10 = (has_head(v406_9) ? constant_9 : Space{});
          Space v406_12;
          if (!v406_10.empty()) {
            const Path v408_6 = concat_path(v403_95_head,v405_6_head);
            const Space v408_11 = routine_88(c, v408_6, v405_6_tail);
            v406_12 = compose(v406_10,v408_11);
          }
          const Space v406_13 = unite(v406_8,v406_12);
          v405_6_result = unite(v405_6_result,v406_13);
        }
        const Space v405_6 = std::move(v405_6_result);
        v404_7 = compose(v404_5,v405_6);
      }
      const Space v404_8 = intersect(constant_8,v404_2);
      const Space v404_9 = (has_head(v404_8) ? constant_9 : Space{});
      Space v404_11;
      if (!v404_9.empty()) {
        Space v409_10_result;
        for (int v409_10_label = 1; v409_10_label <= 2; ++v409_10_label) {
          const Space v409_10_tail = child(v403_95_tail,v409_10_label);
          if (v409_10_tail.empty()) continue;
          const Path v409_10_head{v409_10_label};
          const Space v410_2 = singleton(v409_10_head);
          const Space v410_3 = intersect(constant_8,v410_2);
          const Space v410_4 = (has_head(v410_3) ? constant_9 : Space{});
          const Space v410_5 = subtract(constant_0,v410_4);
          Space v410_8;
          if (!v410_5.empty()) {
            const Path v411_6 = concat_path(v403_95_head,v409_10_head);
            const Space v411_7 = routine_87(c, v411_6, v409_10_tail);
            v410_8 = compose(v410_5,v411_7);
          }
          const Space v410_9 = intersect(constant_8,v410_2);
          const Space v410_10 = (has_head(v410_9) ? constant_9 : Space{});
          Space v410_12;
          if (!v410_10.empty()) {
            const Path v412_6 = concat_path(v403_95_head,v409_10_head);
            const Space v412_11 = routine_89(c, v412_6, v409_10_tail);
            v410_12 = compose(v410_10,v412_11);
          }
          const Space v410_13 = unite(v410_8,v410_12);
          v409_10_result = unite(v409_10_result,v410_13);
        }
        const Space v409_10 = std::move(v409_10_result);
        v404_11 = compose(v404_9,v409_10);
      }
      const Space v404_12 = unite(v404_7,v404_11);
      v403_95_result = unite(v403_95_result,v404_12);
    }
    const Space v403_95 = std::move(v403_95_result);
    v336_96 = compose(v336_85,v403_95);
  }
  const Space v336_97 = unite(v336_73,v336_96);
  return v336_97;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v413_12_result;
  for (int v413_12_label = 1; v413_12_label <= 2; ++v413_12_label) {
    const Space v413_12_tail = child(s0,v413_12_label);
    if (v413_12_tail.empty()) continue;
    const Path v413_12_head{v413_12_label};
    const Space v414_2 = singleton(v413_12_head);
    const Space v414_3 = intersect(constant_8,v414_2);
    const Space v414_4 = (has_head(v414_3) ? constant_9 : Space{});
    const Space v414_5 = subtract(constant_0,v414_4);
    Space v414_8;
    if (!v414_5.empty()) {
      const Path v415_6 = concat_path(p0,v413_12_head);
      Space v415_7_result;
      for (int v415_7_label = 1; v415_7_label <= 2; ++v415_7_label) {
        const Space v415_7_tail = child(v413_12_tail,v415_7_label);
        if (v415_7_tail.empty()) continue;
        const Path v415_7_head{v415_7_label};
        const Space v416_2 = singleton(v415_7_head);
        const Space v416_3 = intersect(constant_8,v416_2);
        const Space v416_4 = (has_head(v416_3) ? constant_9 : Space{});
        const Space v416_5 = subtract(constant_0,v416_4);
        Space v416_8;
        if (!v416_5.empty()) {
          const Path v417_6 = concat_path(v415_6,v415_7_head);
          const Space v417_7 = routine_90(c, v417_6, p1, v415_7_tail);
          v416_8 = compose(v416_5,v417_7);
        }
        const Space v416_9 = intersect(constant_8,v416_2);
        const Space v416_10 = (has_head(v416_9) ? constant_9 : Space{});
        Space v416_12;
        if (!v416_10.empty()) {
          const Path v418_6 = concat_path(v415_6,v415_7_head);
          const Space v418_11 = routine_91(c, v418_6, p1, v415_7_tail);
          v416_12 = compose(v416_10,v418_11);
        }
        const Space v416_13 = unite(v416_8,v416_12);
        v415_7_result = unite(v415_7_result,v416_13);
      }
      const Space v415_7 = std::move(v415_7_result);
      v414_8 = compose(v414_5,v415_7);
    }
    const Space v414_9 = intersect(constant_8,v414_2);
    const Space v414_10 = (has_head(v414_9) ? constant_9 : Space{});
    Space v414_12;
    if (!v414_10.empty()) {
      const Path v419_6 = concat_path(p0,v413_12_head);
      Space v419_11_result;
      for (int v419_11_label = 1; v419_11_label <= 2; ++v419_11_label) {
        const Space v419_11_tail = child(v413_12_tail,v419_11_label);
        if (v419_11_tail.empty()) continue;
        const Path v419_11_head{v419_11_label};
        const Space v420_2 = singleton(v419_11_head);
        const Space v420_3 = intersect(constant_8,v420_2);
        const Space v420_4 = (has_head(v420_3) ? constant_9 : Space{});
        const Space v420_5 = subtract(constant_0,v420_4);
        Space v420_8;
        if (!v420_5.empty()) {
          const Path v421_6 = concat_path(v419_6,v419_11_head);
          const Space v421_7 = routine_90(c, v421_6, p1, v419_11_tail);
          v420_8 = compose(v420_5,v421_7);
        }
        const Space v420_9 = intersect(constant_8,v420_2);
        const Space v420_10 = (has_head(v420_9) ? constant_9 : Space{});
        Space v420_12;
        if (!v420_10.empty()) {
          const Path v422_6 = concat_path(v419_6,v419_11_head);
          const Space v422_11 = routine_60(c, v422_6, p1, v419_11_tail);
          v420_12 = compose(v420_10,v422_11);
        }
        const Space v420_13 = unite(v420_8,v420_12);
        v419_11_result = unite(v419_11_result,v420_13);
      }
      const Space v419_11 = std::move(v419_11_result);
      v414_12 = compose(v414_10,v419_11);
    }
    const Space v414_13 = unite(v414_8,v414_12);
    v413_12_result = unite(v413_12_result,v414_13);
  }
  const Space v413_12 = std::move(v413_12_result);
  return v413_12;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v423_17_result;
  for (int v423_17_label = 1; v423_17_label <= 2; ++v423_17_label) {
    const Space v423_17_tail = child(s0,v423_17_label);
    if (v423_17_tail.empty()) continue;
    const Path v423_17_head{v423_17_label};
    const Space v424_2 = singleton(v423_17_head);
    const Space v424_3 = intersect(constant_8,v424_2);
    const Space v424_4 = (has_head(v424_3) ? constant_9 : Space{});
    const Space v424_5 = subtract(constant_0,v424_4);
    Space v424_8;
    if (!v424_5.empty()) {
      const Path v425_6 = concat_path(p0,v423_17_head);
      Space v425_7_result;
      for (int v425_7_label = 1; v425_7_label <= 2; ++v425_7_label) {
        const Space v425_7_tail = child(v423_17_tail,v425_7_label);
        if (v425_7_tail.empty()) continue;
        const Path v425_7_head{v425_7_label};
        const Space v426_2 = singleton(v425_7_head);
        const Space v426_3 = intersect(constant_8,v426_2);
        const Space v426_4 = (has_head(v426_3) ? constant_9 : Space{});
        const Space v426_5 = subtract(constant_0,v426_4);
        Space v426_8;
        if (!v426_5.empty()) {
          const Path v427_6 = concat_path(v425_6,v425_7_head);
          const Space v427_7 = routine_90(c, v427_6, p1, v425_7_tail);
          v426_8 = compose(v426_5,v427_7);
        }
        const Space v426_9 = intersect(constant_8,v426_2);
        const Space v426_10 = (has_head(v426_9) ? constant_9 : Space{});
        Space v426_12;
        if (!v426_10.empty()) {
          const Path v428_6 = concat_path(v425_6,v425_7_head);
          const Space v428_11 = routine_91(c, v428_6, p1, v425_7_tail);
          v426_12 = compose(v426_10,v428_11);
        }
        const Space v426_13 = unite(v426_8,v426_12);
        v425_7_result = unite(v425_7_result,v426_13);
      }
      const Space v425_7 = std::move(v425_7_result);
      v424_8 = compose(v424_5,v425_7);
    }
    const Space v424_9 = intersect(constant_8,v424_2);
    const Space v424_10 = (has_head(v424_9) ? constant_9 : Space{});
    Space v424_16;
    if (!v424_10.empty()) {
      const Path v429_6 = concat_path(p0,v423_17_head);
      Space v429_14;
      if (!constant_0.empty()) {
        const Space v430_11 = routine_92(c, constant_14, p1, constant_15);
        const Space v430_12 = routine_93(c, constant_16, p1, constant_17);
        const Space v430_13 = unite(v430_11,v430_12);
        v429_14 = compose(constant_0,v430_13);
      }
      Space v429_15_result;
      for (int v429_15_label = 1; v429_15_label <= 2; ++v429_15_label) {
        const Space v429_15_tail = child(v429_14,v429_15_label);
        if (v429_15_tail.empty()) continue;
        const Path v429_15_head{v429_15_label};
        const Space v431_2 = singleton(v429_15_head);
        const Space v431_3 = intersect(constant_8,v431_2);
        const Space v431_4 = (has_head(v431_3) ? constant_9 : Space{});
        const Space v431_5 = subtract(constant_0,v431_4);
        Space v431_7;
        if (!v431_5.empty()) {
          const Space v432_6 = routine_94(c, v429_15_head, v429_6, v429_15_tail, v423_17_tail);
          v431_7 = compose(v431_5,v432_6);
        }
        const Space v431_8 = intersect(constant_8,v431_2);
        const Space v431_9 = (has_head(v431_8) ? constant_9 : Space{});
        Space v431_11;
        if (!v431_9.empty()) {
          const Space v433_10 = routine_95(c, v429_15_head, v429_6, v429_15_tail, v423_17_tail);
          v431_11 = compose(v431_9,v433_10);
        }
        const Space v431_12 = unite(v431_7,v431_11);
        v429_15_result = unite(v429_15_result,v431_12);
      }
      const Space v429_15 = std::move(v429_15_result);
      v424_16 = compose(v424_10,v429_15);
    }
    const Space v424_17 = unite(v424_8,v424_16);
    v423_17_result = unite(v423_17_result,v424_17);
  }
  const Space v423_17 = std::move(v423_17_result);
  return v423_17;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v434_12_result;
  for (int v434_12_label = 1; v434_12_label <= 2; ++v434_12_label) {
    const Space v434_12_tail = child(s0,v434_12_label);
    if (v434_12_tail.empty()) continue;
    const Path v434_12_head{v434_12_label};
    const Space v435_2 = singleton(v434_12_head);
    const Space v435_3 = intersect(constant_8,v435_2);
    const Space v435_4 = (has_head(v435_3) ? constant_9 : Space{});
    const Space v435_5 = subtract(constant_0,v435_4);
    Space v435_8;
    if (!v435_5.empty()) {
      const Path v436_6 = concat_path(p0,v434_12_head);
      Space v436_7_result;
      for (int v436_7_label = 1; v436_7_label <= 2; ++v436_7_label) {
        const Space v436_7_tail = child(v434_12_tail,v436_7_label);
        if (v436_7_tail.empty()) continue;
        const Path v436_7_head{v436_7_label};
        const Space v437_2 = singleton(v436_7_head);
        const Space v437_3 = intersect(constant_8,v437_2);
        const Space v437_4 = (has_head(v437_3) ? constant_9 : Space{});
        const Space v437_5 = subtract(constant_0,v437_4);
        Space v437_8;
        if (!v437_5.empty()) {
          const Path v438_6 = concat_path(v436_6,v436_7_head);
          const Space v438_7 = routine_96(c, v438_6, p1, v436_7_tail);
          v437_8 = compose(v437_5,v438_7);
        }
        const Space v437_9 = intersect(constant_8,v437_2);
        const Space v437_10 = (has_head(v437_9) ? constant_9 : Space{});
        Space v437_12;
        if (!v437_10.empty()) {
          const Path v439_6 = concat_path(v436_6,v436_7_head);
          const Space v439_11 = routine_97(c, v439_6, p1, v436_7_tail);
          v437_12 = compose(v437_10,v439_11);
        }
        const Space v437_13 = unite(v437_8,v437_12);
        v436_7_result = unite(v436_7_result,v437_13);
      }
      const Space v436_7 = std::move(v436_7_result);
      v435_8 = compose(v435_5,v436_7);
    }
    const Space v435_9 = intersect(constant_8,v435_2);
    const Space v435_10 = (has_head(v435_9) ? constant_9 : Space{});
    Space v435_12;
    if (!v435_10.empty()) {
      const Path v440_6 = concat_path(p0,v434_12_head);
      Space v440_11_result;
      for (int v440_11_label = 1; v440_11_label <= 2; ++v440_11_label) {
        const Space v440_11_tail = child(v434_12_tail,v440_11_label);
        if (v440_11_tail.empty()) continue;
        const Path v440_11_head{v440_11_label};
        const Space v441_2 = singleton(v440_11_head);
        const Space v441_3 = intersect(constant_8,v441_2);
        const Space v441_4 = (has_head(v441_3) ? constant_9 : Space{});
        const Space v441_5 = subtract(constant_0,v441_4);
        Space v441_8;
        if (!v441_5.empty()) {
          const Path v442_6 = concat_path(v440_6,v440_11_head);
          const Space v442_7 = routine_96(c, v442_6, p1, v440_11_tail);
          v441_8 = compose(v441_5,v442_7);
        }
        const Space v441_9 = intersect(constant_8,v441_2);
        const Space v441_10 = (has_head(v441_9) ? constant_9 : Space{});
        Space v441_12;
        if (!v441_10.empty()) {
          const Path v443_6 = concat_path(v440_6,v440_11_head);
          const Space v443_11 = routine_63(c, v443_6, p1, v440_11_tail);
          v441_12 = compose(v441_10,v443_11);
        }
        const Space v441_13 = unite(v441_8,v441_12);
        v440_11_result = unite(v440_11_result,v441_13);
      }
      const Space v440_11 = std::move(v440_11_result);
      v435_12 = compose(v435_10,v440_11);
    }
    const Space v435_13 = unite(v435_8,v435_12);
    v434_12_result = unite(v434_12_result,v435_13);
  }
  const Space v434_12 = std::move(v434_12_result);
  return v434_12;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v444_17_result;
  for (int v444_17_label = 1; v444_17_label <= 2; ++v444_17_label) {
    const Space v444_17_tail = child(s0,v444_17_label);
    if (v444_17_tail.empty()) continue;
    const Path v444_17_head{v444_17_label};
    const Space v445_2 = singleton(v444_17_head);
    const Space v445_3 = intersect(constant_8,v445_2);
    const Space v445_4 = (has_head(v445_3) ? constant_9 : Space{});
    const Space v445_5 = subtract(constant_0,v445_4);
    Space v445_8;
    if (!v445_5.empty()) {
      const Path v446_6 = concat_path(p0,v444_17_head);
      Space v446_7_result;
      for (int v446_7_label = 1; v446_7_label <= 2; ++v446_7_label) {
        const Space v446_7_tail = child(v444_17_tail,v446_7_label);
        if (v446_7_tail.empty()) continue;
        const Path v446_7_head{v446_7_label};
        const Space v447_2 = singleton(v446_7_head);
        const Space v447_3 = intersect(constant_8,v447_2);
        const Space v447_4 = (has_head(v447_3) ? constant_9 : Space{});
        const Space v447_5 = subtract(constant_0,v447_4);
        Space v447_8;
        if (!v447_5.empty()) {
          const Path v448_6 = concat_path(v446_6,v446_7_head);
          const Space v448_7 = routine_96(c, v448_6, p1, v446_7_tail);
          v447_8 = compose(v447_5,v448_7);
        }
        const Space v447_9 = intersect(constant_8,v447_2);
        const Space v447_10 = (has_head(v447_9) ? constant_9 : Space{});
        Space v447_12;
        if (!v447_10.empty()) {
          const Path v449_6 = concat_path(v446_6,v446_7_head);
          const Space v449_11 = routine_97(c, v449_6, p1, v446_7_tail);
          v447_12 = compose(v447_10,v449_11);
        }
        const Space v447_13 = unite(v447_8,v447_12);
        v446_7_result = unite(v446_7_result,v447_13);
      }
      const Space v446_7 = std::move(v446_7_result);
      v445_8 = compose(v445_5,v446_7);
    }
    const Space v445_9 = intersect(constant_8,v445_2);
    const Space v445_10 = (has_head(v445_9) ? constant_9 : Space{});
    Space v445_16;
    if (!v445_10.empty()) {
      Space v450_14;
      if (!constant_0.empty()) {
        const Path v451_6 = concat_path(p0,v444_17_head);
        const Space v451_11 = routine_98(c, constant_14, p1, v451_6, constant_15);
        const Space v451_12 = routine_99(c, constant_16, p1, v451_6, constant_17);
        const Space v451_13 = unite(v451_11,v451_12);
        v450_14 = compose(constant_0,v451_13);
      }
      Space v450_15_result;
      for (int v450_15_label = 1; v450_15_label <= 2; ++v450_15_label) {
        const Space v450_15_tail = child(v450_14,v450_15_label);
        if (v450_15_tail.empty()) continue;
        const Path v450_15_head{v450_15_label};
        const Space v452_2 = singleton(v450_15_head);
        const Space v452_3 = intersect(constant_8,v452_2);
        const Space v452_4 = (has_head(v452_3) ? constant_9 : Space{});
        const Space v452_5 = subtract(constant_0,v452_4);
        Space v452_7;
        if (!v452_5.empty()) {
          const Space v453_6 = routine_100(c, v450_15_head, v450_15_tail, v444_17_tail);
          v452_7 = compose(v452_5,v453_6);
        }
        const Space v452_8 = intersect(constant_8,v452_2);
        const Space v452_9 = (has_head(v452_8) ? constant_9 : Space{});
        Space v452_11;
        if (!v452_9.empty()) {
          const Space v454_10 = routine_101(c, v450_15_head, v450_15_tail, v444_17_tail);
          v452_11 = compose(v452_9,v454_10);
        }
        const Space v452_12 = unite(v452_7,v452_11);
        v450_15_result = unite(v450_15_result,v452_12);
      }
      const Space v450_15 = std::move(v450_15_result);
      v445_16 = compose(v445_10,v450_15);
    }
    const Space v445_17 = unite(v445_8,v445_16);
    v444_17_result = unite(v444_17_result,v445_17);
  }
  const Space v444_17 = std::move(v444_17_result);
  return v444_17;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v455_7_result;
  for (int v455_7_label = 1; v455_7_label <= 2; ++v455_7_label) {
    const Space v455_7_tail = child(s0,v455_7_label);
    if (v455_7_tail.empty()) continue;
    const Path v455_7_head{v455_7_label};
    const Space v456_2 = singleton(v455_7_head);
    const Space v456_3 = intersect(constant_8,v456_2);
    const Space v456_4 = (has_head(v456_3) ? constant_9 : Space{});
    Space v456_7;
    if (!v456_4.empty()) {
      const Path v457_5 = concat_path(p0,v455_7_head);
      Space v457_6_result;
      for (int v457_6_label = 1; v457_6_label <= 2; ++v457_6_label) {
        const Space v457_6_tail = child(v455_7_tail,v457_6_label);
        if (v457_6_tail.empty()) continue;
        const Path v457_6_head{v457_6_label};
        const Space v458_2 = singleton(v457_6_head);
        const Space v458_3 = intersect(constant_8,v458_2);
        const Space v458_4 = (has_head(v458_3) ? constant_9 : Space{});
        Space v458_7;
        if (!v458_4.empty()) {
          const Path v459_5 = concat_path(v457_5,v457_6_head);
          const Space v459_6 = routine_30(c, v459_5, p1, p2, p3, v457_6_tail);
          v458_7 = compose(v458_4,v459_6);
        }
        v457_6_result = unite(v457_6_result,v458_7);
      }
      const Space v457_6 = std::move(v457_6_result);
      v456_7 = compose(v456_4,v457_6);
    }
    v455_7_result = unite(v455_7_result,v456_7);
  }
  const Space v455_7 = std::move(v455_7_result);
  return v455_7;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v460_6 = concat_path(p2,p3);
  Space v460_13_result;
  for (int v460_13_label = 1; v460_13_label <= 2; ++v460_13_label) {
    const Space v460_13_tail = child(s0,v460_13_label);
    if (v460_13_tail.empty()) continue;
    const Path v460_13_head{v460_13_label};
    const Space v461_2 = singleton(v460_13_head);
    const Space v461_3 = intersect(constant_8,v461_2);
    const Space v461_4 = (has_head(v461_3) ? constant_9 : Space{});
    Space v461_11;
    if (!v461_4.empty()) {
      const Path v462_5 = concat_path(p0,v460_13_head);
      const Path v462_6 = concat_path(v460_6,v462_5);
      const Space v462_7 = singleton(v462_6);
      const Space v462_8 = routine_35(c, p1, v462_7);
      Space v462_9_result;
      for (int v462_9_label = 1; v462_9_label <= 2; ++v462_9_label) {
        const Space v462_9_tail = child(v462_8,v462_9_label);
        if (v462_9_tail.empty()) continue;
        const Path v462_9_head{v462_9_label};
        const Space v463_2 = singleton(v462_9_head);
        const Space v463_3 = intersect(constant_8,v463_2);
        const Space v463_4 = (has_head(v463_3) ? constant_9 : Space{});
        const Space v463_5 = subtract(constant_0,v463_4);
        Space v463_7;
        if (!v463_5.empty()) {
          const Space v464_6 = routine_36(c, v462_9_head, p1, v462_9_tail);
          v463_7 = compose(v463_5,v464_6);
        }
        const Space v463_8 = intersect(constant_8,v463_2);
        const Space v463_9 = (has_head(v463_8) ? constant_9 : Space{});
        Space v463_11;
        if (!v463_9.empty()) {
          const Space v465_10 = routine_37(c, v462_9_head, p1, v462_9_tail);
          v463_11 = compose(v463_9,v465_10);
        }
        const Space v463_12 = unite(v463_7,v463_11);
        v462_9_result = unite(v462_9_result,v463_12);
      }
      const Space v462_9 = std::move(v462_9_result);
      Space v462_10_result;
      for (int v462_10_label = 1; v462_10_label <= 2; ++v462_10_label) {
        const Space v462_10_tail = child(v462_9,v462_10_label);
        if (v462_10_tail.empty()) continue;
        const Path v462_10_head{v462_10_label};
        const Space v466_2 = singleton(v462_10_head);
        const Space v466_3 = intersect(constant_8,v466_2);
        const Space v466_4 = (has_head(v466_3) ? constant_9 : Space{});
        const Space v466_5 = subtract(constant_0,v466_4);
        Space v466_7;
        if (!v466_5.empty()) {
          const Space v467_6 = routine_38(c, v462_10_head, p1, v462_10_tail);
          v466_7 = compose(v466_5,v467_6);
        }
        const Space v466_8 = intersect(constant_8,v466_2);
        const Space v466_9 = (has_head(v466_8) ? constant_9 : Space{});
        Space v466_11;
        if (!v466_9.empty()) {
          const Space v468_10 = routine_39(c, v462_10_head, p1, v462_10_tail);
          v466_11 = compose(v466_9,v468_10);
        }
        const Space v466_12 = unite(v466_7,v466_11);
        v462_10_result = unite(v462_10_result,v466_12);
      }
      const Space v462_10 = std::move(v462_10_result);
      v461_11 = compose(v461_4,v462_10);
    }
    v460_13_result = unite(v460_13_result,v461_11);
  }
  const Space v460_13 = std::move(v460_13_result);
  return v460_13;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0) {
  Space v469_11_result;
  for (int v469_11_label = 1; v469_11_label <= 2; ++v469_11_label) {
    const Space v469_11_tail = child(s0,v469_11_label);
    if (v469_11_tail.empty()) continue;
    const Path v469_11_head{v469_11_label};
    const Space v470_2 = singleton(v469_11_head);
    const Space v470_3 = intersect(constant_8,v470_2);
    const Space v470_4 = (has_head(v470_3) ? constant_9 : Space{});
    const Space v470_5 = subtract(constant_0,v470_4);
    Space v470_8;
    if (!v470_5.empty()) {
      const Path v471_6 = concat_path(p0,v469_11_head);
      Space v471_7_result;
      for (int v471_7_label = 1; v471_7_label <= 2; ++v471_7_label) {
        const Space v471_7_tail = child(v469_11_tail,v471_7_label);
        if (v471_7_tail.empty()) continue;
        const Path v471_7_head{v471_7_label};
        const Space v472_2 = singleton(v471_7_head);
        const Space v472_3 = intersect(constant_8,v472_2);
        const Space v472_4 = (has_head(v472_3) ? constant_9 : Space{});
        const Space v472_5 = subtract(constant_0,v472_4);
        Space v472_8;
        if (!v472_5.empty()) {
          const Path v473_6 = concat_path(v471_6,v471_7_head);
          const Space v473_7 = routine_102(c, v473_6, v471_7_tail);
          v472_8 = compose(v472_5,v473_7);
        }
        const Space v472_9 = intersect(constant_8,v472_2);
        const Space v472_10 = (has_head(v472_9) ? constant_9 : Space{});
        Space v472_12;
        if (!v472_10.empty()) {
          const Path v474_6 = concat_path(v471_6,v471_7_head);
          const Space v474_11 = routine_103(c, v474_6, v471_7_tail);
          v472_12 = compose(v472_10,v474_11);
        }
        const Space v472_13 = unite(v472_8,v472_12);
        v471_7_result = unite(v471_7_result,v472_13);
      }
      const Space v471_7 = std::move(v471_7_result);
      v470_8 = compose(v470_5,v471_7);
    }
    const Space v470_9 = intersect(constant_8,v470_2);
    const Space v470_10 = (has_head(v470_9) ? constant_9 : Space{});
    Space v470_12;
    if (!v470_10.empty()) {
      const Path v475_6 = concat_path(p0,v469_11_head);
      Space v475_11_result;
      for (int v475_11_label = 1; v475_11_label <= 2; ++v475_11_label) {
        const Space v475_11_tail = child(v469_11_tail,v475_11_label);
        if (v475_11_tail.empty()) continue;
        const Path v475_11_head{v475_11_label};
        const Space v476_2 = singleton(v475_11_head);
        const Space v476_3 = intersect(constant_8,v476_2);
        const Space v476_4 = (has_head(v476_3) ? constant_9 : Space{});
        const Space v476_5 = subtract(constant_0,v476_4);
        Space v476_8;
        if (!v476_5.empty()) {
          const Path v477_6 = concat_path(v475_6,v475_11_head);
          const Space v477_7 = routine_102(c, v477_6, v475_11_tail);
          v476_8 = compose(v476_5,v477_7);
        }
        const Space v476_9 = intersect(constant_8,v476_2);
        const Space v476_10 = (has_head(v476_9) ? constant_9 : Space{});
        Space v476_12;
        if (!v476_10.empty()) {
          const Path v478_6 = concat_path(v475_6,v475_11_head);
          const Space v478_11 = routine_68(c, v478_6, v475_11_tail);
          v476_12 = compose(v476_10,v478_11);
        }
        const Space v476_13 = unite(v476_8,v476_12);
        v475_11_result = unite(v475_11_result,v476_13);
      }
      const Space v475_11 = std::move(v475_11_result);
      v470_12 = compose(v470_10,v475_11);
    }
    const Space v470_13 = unite(v470_8,v470_12);
    v469_11_result = unite(v469_11_result,v470_13);
  }
  const Space v469_11 = std::move(v469_11_result);
  return v469_11;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0) {
  Space v479_8_result;
  for (int v479_8_label = 1; v479_8_label <= 2; ++v479_8_label) {
    const Space v479_8_tail = child(s0,v479_8_label);
    if (v479_8_tail.empty()) continue;
    const Path v479_8_head{v479_8_label};
    const Space v480_2 = singleton(v479_8_head);
    const Space v480_3 = intersect(constant_8,v480_2);
    const Space v480_4 = (has_head(v480_3) ? constant_9 : Space{});
    const Space v480_5 = subtract(constant_0,v480_4);
    Space v480_8;
    if (!v480_5.empty()) {
      const Path v481_6 = concat_path(p0,v479_8_head);
      Space v481_7_result;
      for (int v481_7_label = 1; v481_7_label <= 2; ++v481_7_label) {
        const Space v481_7_tail = child(v479_8_tail,v481_7_label);
        if (v481_7_tail.empty()) continue;
        const Path v481_7_head{v481_7_label};
        const Space v482_2 = singleton(v481_7_head);
        const Space v482_3 = intersect(constant_8,v482_2);
        const Space v482_4 = (has_head(v482_3) ? constant_9 : Space{});
        const Space v482_5 = subtract(constant_0,v482_4);
        Space v482_8;
        if (!v482_5.empty()) {
          const Path v483_6 = concat_path(v481_6,v481_7_head);
          const Space v483_7 = routine_102(c, v483_6, v481_7_tail);
          v482_8 = compose(v482_5,v483_7);
        }
        const Space v482_9 = intersect(constant_8,v482_2);
        const Space v482_10 = (has_head(v482_9) ? constant_9 : Space{});
        Space v482_12;
        if (!v482_10.empty()) {
          const Path v484_6 = concat_path(v481_6,v481_7_head);
          const Space v484_11 = routine_103(c, v484_6, v481_7_tail);
          v482_12 = compose(v482_10,v484_11);
        }
        const Space v482_13 = unite(v482_8,v482_12);
        v481_7_result = unite(v481_7_result,v482_13);
      }
      const Space v481_7 = std::move(v481_7_result);
      v480_8 = compose(v480_5,v481_7);
    }
    const Space v480_9 = intersect(constant_8,v480_2);
    const Space v480_10 = (has_head(v480_9) ? constant_9 : Space{});
    const Space v480_11 = compose(v480_10,v479_8_tail);
    const Space v480_12 = unite(v480_8,v480_11);
    v479_8_result = unite(v479_8_result,v480_12);
  }
  const Space v479_8 = std::move(v479_8_result);
  return v479_8;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  Space v485_11_result;
  for (int v485_11_label = 1; v485_11_label <= 2; ++v485_11_label) {
    const Space v485_11_tail = child(s0,v485_11_label);
    if (v485_11_tail.empty()) continue;
    const Path v485_11_head{v485_11_label};
    const Space v486_2 = singleton(v485_11_head);
    const Space v486_3 = intersect(constant_8,v486_2);
    const Space v486_4 = (has_head(v486_3) ? constant_9 : Space{});
    const Space v486_5 = subtract(constant_0,v486_4);
    Space v486_8;
    if (!v486_5.empty()) {
      const Path v487_6 = concat_path(p0,v485_11_head);
      Space v487_7_result;
      for (int v487_7_label = 1; v487_7_label <= 2; ++v487_7_label) {
        const Space v487_7_tail = child(v485_11_tail,v487_7_label);
        if (v487_7_tail.empty()) continue;
        const Path v487_7_head{v487_7_label};
        const Space v488_2 = singleton(v487_7_head);
        const Space v488_3 = intersect(constant_8,v488_2);
        const Space v488_4 = (has_head(v488_3) ? constant_9 : Space{});
        const Space v488_5 = subtract(constant_0,v488_4);
        Space v488_8;
        if (!v488_5.empty()) {
          const Path v489_6 = concat_path(v487_6,v487_7_head);
          const Space v489_7 = routine_104(c, v489_6, v487_7_tail);
          v488_8 = compose(v488_5,v489_7);
        }
        const Space v488_9 = intersect(constant_8,v488_2);
        const Space v488_10 = (has_head(v488_9) ? constant_9 : Space{});
        Space v488_12;
        if (!v488_10.empty()) {
          const Path v490_6 = concat_path(v487_6,v487_7_head);
          const Space v490_11 = routine_105(c, v490_6, v487_7_tail);
          v488_12 = compose(v488_10,v490_11);
        }
        const Space v488_13 = unite(v488_8,v488_12);
        v487_7_result = unite(v487_7_result,v488_13);
      }
      const Space v487_7 = std::move(v487_7_result);
      v486_8 = compose(v486_5,v487_7);
    }
    const Space v486_9 = intersect(constant_8,v486_2);
    const Space v486_10 = (has_head(v486_9) ? constant_9 : Space{});
    Space v486_12;
    if (!v486_10.empty()) {
      const Path v491_6 = concat_path(p0,v485_11_head);
      Space v491_11_result;
      for (int v491_11_label = 1; v491_11_label <= 2; ++v491_11_label) {
        const Space v491_11_tail = child(v485_11_tail,v491_11_label);
        if (v491_11_tail.empty()) continue;
        const Path v491_11_head{v491_11_label};
        const Space v492_2 = singleton(v491_11_head);
        const Space v492_3 = intersect(constant_8,v492_2);
        const Space v492_4 = (has_head(v492_3) ? constant_9 : Space{});
        const Space v492_5 = subtract(constant_0,v492_4);
        Space v492_8;
        if (!v492_5.empty()) {
          const Path v493_6 = concat_path(v491_6,v491_11_head);
          const Space v493_7 = routine_104(c, v493_6, v491_11_tail);
          v492_8 = compose(v492_5,v493_7);
        }
        const Space v492_9 = intersect(constant_8,v492_2);
        const Space v492_10 = (has_head(v492_9) ? constant_9 : Space{});
        Space v492_12;
        if (!v492_10.empty()) {
          const Path v494_6 = concat_path(v491_6,v491_11_head);
          const Space v494_11 = routine_71(c, v494_6, v491_11_tail);
          v492_12 = compose(v492_10,v494_11);
        }
        const Space v492_13 = unite(v492_8,v492_12);
        v491_11_result = unite(v491_11_result,v492_13);
      }
      const Space v491_11 = std::move(v491_11_result);
      v486_12 = compose(v486_10,v491_11);
    }
    const Space v486_13 = unite(v486_8,v486_12);
    v485_11_result = unite(v485_11_result,v486_13);
  }
  const Space v485_11 = std::move(v485_11_result);
  return v485_11;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0) {
  Space v495_11_result;
  for (int v495_11_label = 1; v495_11_label <= 2; ++v495_11_label) {
    const Space v495_11_tail = child(s0,v495_11_label);
    if (v495_11_tail.empty()) continue;
    const Path v495_11_head{v495_11_label};
    const Space v496_2 = singleton(v495_11_head);
    const Space v496_3 = intersect(constant_8,v496_2);
    const Space v496_4 = (has_head(v496_3) ? constant_9 : Space{});
    const Space v496_5 = subtract(constant_0,v496_4);
    Space v496_8;
    if (!v496_5.empty()) {
      const Path v497_6 = concat_path(p0,v495_11_head);
      Space v497_7_result;
      for (int v497_7_label = 1; v497_7_label <= 2; ++v497_7_label) {
        const Space v497_7_tail = child(v495_11_tail,v497_7_label);
        if (v497_7_tail.empty()) continue;
        const Path v497_7_head{v497_7_label};
        const Space v498_2 = singleton(v497_7_head);
        const Space v498_3 = intersect(constant_8,v498_2);
        const Space v498_4 = (has_head(v498_3) ? constant_9 : Space{});
        const Space v498_5 = subtract(constant_0,v498_4);
        Space v498_8;
        if (!v498_5.empty()) {
          const Path v499_6 = concat_path(v497_6,v497_7_head);
          const Space v499_7 = routine_104(c, v499_6, v497_7_tail);
          v498_8 = compose(v498_5,v499_7);
        }
        const Space v498_9 = intersect(constant_8,v498_2);
        const Space v498_10 = (has_head(v498_9) ? constant_9 : Space{});
        Space v498_12;
        if (!v498_10.empty()) {
          const Path v500_6 = concat_path(v497_6,v497_7_head);
          const Space v500_11 = routine_105(c, v500_6, v497_7_tail);
          v498_12 = compose(v498_10,v500_11);
        }
        const Space v498_13 = unite(v498_8,v498_12);
        v497_7_result = unite(v497_7_result,v498_13);
      }
      const Space v497_7 = std::move(v497_7_result);
      v496_8 = compose(v496_5,v497_7);
    }
    const Space v496_9 = intersect(constant_8,v496_2);
    const Space v496_10 = (has_head(v496_9) ? constant_9 : Space{});
    Space v496_12;
    if (!v496_10.empty()) {
      const Path v501_6 = concat_path(p0,v495_11_head);
      Space v501_11_result;
      for (int v501_11_label = 1; v501_11_label <= 2; ++v501_11_label) {
        const Space v501_11_tail = child(v495_11_tail,v501_11_label);
        if (v501_11_tail.empty()) continue;
        const Path v501_11_head{v501_11_label};
        const Space v502_2 = singleton(v501_11_head);
        const Space v502_3 = intersect(constant_8,v502_2);
        const Space v502_4 = (has_head(v502_3) ? constant_9 : Space{});
        const Space v502_5 = subtract(constant_0,v502_4);
        Space v502_7;
        if (!v502_5.empty()) {
          const Space v503_6 = routine_106(c, v501_11_head, v501_6, v501_11_tail);
          v502_7 = compose(v502_5,v503_6);
        }
        const Space v502_8 = intersect(constant_8,v502_2);
        const Space v502_9 = (has_head(v502_8) ? constant_9 : Space{});
        Space v502_11;
        if (!v502_9.empty()) {
          const Space v504_10 = routine_107(c, v501_11_head, v501_6, v501_11_tail);
          v502_11 = compose(v502_9,v504_10);
        }
        const Space v502_12 = unite(v502_7,v502_11);
        v501_11_result = unite(v501_11_result,v502_12);
      }
      const Space v501_11 = std::move(v501_11_result);
      v496_12 = compose(v496_10,v501_11);
    }
    const Space v496_13 = unite(v496_8,v496_12);
    v495_11_result = unite(v495_11_result,v496_13);
  }
  const Space v495_11 = std::move(v495_11_result);
  return v495_11;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0) {
  Space v505_11_result;
  for (int v505_11_label = 1; v505_11_label <= 2; ++v505_11_label) {
    const Space v505_11_tail = child(s0,v505_11_label);
    if (v505_11_tail.empty()) continue;
    const Path v505_11_head{v505_11_label};
    const Space v506_2 = singleton(v505_11_head);
    const Space v506_3 = intersect(constant_8,v506_2);
    const Space v506_4 = (has_head(v506_3) ? constant_9 : Space{});
    const Space v506_5 = subtract(constant_0,v506_4);
    Space v506_8;
    if (!v506_5.empty()) {
      const Path v507_6 = concat_path(p0,v505_11_head);
      Space v507_7_result;
      for (int v507_7_label = 1; v507_7_label <= 2; ++v507_7_label) {
        const Space v507_7_tail = child(v505_11_tail,v507_7_label);
        if (v507_7_tail.empty()) continue;
        const Path v507_7_head{v507_7_label};
        const Space v508_2 = singleton(v507_7_head);
        const Space v508_3 = intersect(constant_8,v508_2);
        const Space v508_4 = (has_head(v508_3) ? constant_9 : Space{});
        const Space v508_5 = subtract(constant_0,v508_4);
        Space v508_8;
        if (!v508_5.empty()) {
          const Path v509_6 = concat_path(v507_6,v507_7_head);
          const Space v509_7 = routine_108(c, v509_6, v507_7_tail);
          v508_8 = compose(v508_5,v509_7);
        }
        const Space v508_9 = intersect(constant_8,v508_2);
        const Space v508_10 = (has_head(v508_9) ? constant_9 : Space{});
        Space v508_12;
        if (!v508_10.empty()) {
          const Path v510_6 = concat_path(v507_6,v507_7_head);
          const Space v510_11 = routine_109(c, v510_6, v507_7_tail);
          v508_12 = compose(v508_10,v510_11);
        }
        const Space v508_13 = unite(v508_8,v508_12);
        v507_7_result = unite(v507_7_result,v508_13);
      }
      const Space v507_7 = std::move(v507_7_result);
      v506_8 = compose(v506_5,v507_7);
    }
    const Space v506_9 = intersect(constant_8,v506_2);
    const Space v506_10 = (has_head(v506_9) ? constant_9 : Space{});
    Space v506_12;
    if (!v506_10.empty()) {
      const Path v511_6 = concat_path(p0,v505_11_head);
      Space v511_11_result;
      for (int v511_11_label = 1; v511_11_label <= 2; ++v511_11_label) {
        const Space v511_11_tail = child(v505_11_tail,v511_11_label);
        if (v511_11_tail.empty()) continue;
        const Path v511_11_head{v511_11_label};
        const Space v512_2 = singleton(v511_11_head);
        const Space v512_3 = intersect(constant_8,v512_2);
        const Space v512_4 = (has_head(v512_3) ? constant_9 : Space{});
        const Space v512_5 = subtract(constant_0,v512_4);
        Space v512_8;
        if (!v512_5.empty()) {
          const Path v513_6 = concat_path(v511_6,v511_11_head);
          const Space v513_7 = routine_108(c, v513_6, v511_11_tail);
          v512_8 = compose(v512_5,v513_7);
        }
        const Space v512_9 = intersect(constant_8,v512_2);
        const Space v512_10 = (has_head(v512_9) ? constant_9 : Space{});
        Space v512_12;
        if (!v512_10.empty()) {
          const Path v514_6 = concat_path(v511_6,v511_11_head);
          const Space v514_11 = routine_74(c, v514_6, v511_11_tail);
          v512_12 = compose(v512_10,v514_11);
        }
        const Space v512_13 = unite(v512_8,v512_12);
        v511_11_result = unite(v511_11_result,v512_13);
      }
      const Space v511_11 = std::move(v511_11_result);
      v506_12 = compose(v506_10,v511_11);
    }
    const Space v506_13 = unite(v506_8,v506_12);
    v505_11_result = unite(v505_11_result,v506_13);
  }
  const Space v505_11 = std::move(v505_11_result);
  return v505_11;
}

static Space routine_47(Context& c, const Path& p0, const Space& s0) {
  Space v515_8_result;
  for (int v515_8_label = 1; v515_8_label <= 2; ++v515_8_label) {
    const Space v515_8_tail = child(s0,v515_8_label);
    if (v515_8_tail.empty()) continue;
    const Path v515_8_head{v515_8_label};
    const Space v516_2 = singleton(v515_8_head);
    const Space v516_3 = intersect(constant_8,v516_2);
    const Space v516_4 = (has_head(v516_3) ? constant_9 : Space{});
    const Space v516_5 = subtract(constant_0,v516_4);
    Space v516_8;
    if (!v516_5.empty()) {
      const Path v517_6 = concat_path(p0,v515_8_head);
      Space v517_7_result;
      for (int v517_7_label = 1; v517_7_label <= 2; ++v517_7_label) {
        const Space v517_7_tail = child(v515_8_tail,v517_7_label);
        if (v517_7_tail.empty()) continue;
        const Path v517_7_head{v517_7_label};
        const Space v518_2 = singleton(v517_7_head);
        const Space v518_3 = intersect(constant_8,v518_2);
        const Space v518_4 = (has_head(v518_3) ? constant_9 : Space{});
        const Space v518_5 = subtract(constant_0,v518_4);
        Space v518_8;
        if (!v518_5.empty()) {
          const Path v519_6 = concat_path(v517_6,v517_7_head);
          const Space v519_7 = routine_108(c, v519_6, v517_7_tail);
          v518_8 = compose(v518_5,v519_7);
        }
        const Space v518_9 = intersect(constant_8,v518_2);
        const Space v518_10 = (has_head(v518_9) ? constant_9 : Space{});
        Space v518_12;
        if (!v518_10.empty()) {
          const Path v520_6 = concat_path(v517_6,v517_7_head);
          const Space v520_11 = routine_109(c, v520_6, v517_7_tail);
          v518_12 = compose(v518_10,v520_11);
        }
        const Space v518_13 = unite(v518_8,v518_12);
        v517_7_result = unite(v517_7_result,v518_13);
      }
      const Space v517_7 = std::move(v517_7_result);
      v516_8 = compose(v516_5,v517_7);
    }
    const Space v516_9 = intersect(constant_8,v516_2);
    const Space v516_10 = (has_head(v516_9) ? constant_9 : Space{});
    const Space v516_11 = compose(v516_10,v515_8_tail);
    const Space v516_12 = unite(v516_8,v516_11);
    v515_8_result = unite(v515_8_result,v516_12);
  }
  const Space v515_8 = std::move(v515_8_result);
  return v515_8;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v521_11_result;
  for (int v521_11_label = 1; v521_11_label <= 2; ++v521_11_label) {
    const Space v521_11_tail = child(s0,v521_11_label);
    if (v521_11_tail.empty()) continue;
    const Path v521_11_head{v521_11_label};
    const Space v522_2 = singleton(v521_11_head);
    const Space v522_3 = intersect(constant_8,v522_2);
    const Space v522_4 = (has_head(v522_3) ? constant_9 : Space{});
    const Space v522_5 = subtract(constant_0,v522_4);
    Space v522_8;
    if (!v522_5.empty()) {
      const Path v523_6 = concat_path(p0,v521_11_head);
      Space v523_7_result;
      for (int v523_7_label = 1; v523_7_label <= 2; ++v523_7_label) {
        const Space v523_7_tail = child(v521_11_tail,v523_7_label);
        if (v523_7_tail.empty()) continue;
        const Path v523_7_head{v523_7_label};
        const Space v524_2 = singleton(v523_7_head);
        const Space v524_3 = intersect(constant_8,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_9 : Space{});
        const Space v524_5 = subtract(constant_0,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v523_6,v523_7_head);
          const Space v525_7 = routine_110(c, v525_6, v523_7_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_8,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_9 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v523_6,v523_7_head);
          const Space v526_11 = routine_111(c, v526_6, v523_7_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_7_result = unite(v523_7_result,v524_13);
      }
      const Space v523_7 = std::move(v523_7_result);
      v522_8 = compose(v522_5,v523_7);
    }
    const Space v522_9 = intersect(constant_8,v522_2);
    const Space v522_10 = (has_head(v522_9) ? constant_9 : Space{});
    Space v522_12;
    if (!v522_10.empty()) {
      const Path v527_6 = concat_path(p0,v521_11_head);
      Space v527_11_result;
      for (int v527_11_label = 1; v527_11_label <= 2; ++v527_11_label) {
        const Space v527_11_tail = child(v521_11_tail,v527_11_label);
        if (v527_11_tail.empty()) continue;
        const Path v527_11_head{v527_11_label};
        const Space v528_2 = singleton(v527_11_head);
        const Space v528_3 = intersect(constant_8,v528_2);
        const Space v528_4 = (has_head(v528_3) ? constant_9 : Space{});
        const Space v528_5 = subtract(constant_0,v528_4);
        Space v528_8;
        if (!v528_5.empty()) {
          const Path v529_6 = concat_path(v527_6,v527_11_head);
          const Space v529_7 = routine_110(c, v529_6, v527_11_tail);
          v528_8 = compose(v528_5,v529_7);
        }
        const Space v528_9 = intersect(constant_8,v528_2);
        const Space v528_10 = (has_head(v528_9) ? constant_9 : Space{});
        Space v528_12;
        if (!v528_10.empty()) {
          const Path v530_6 = concat_path(v527_6,v527_11_head);
          const Space v530_11 = routine_77(c, v530_6, v527_11_tail);
          v528_12 = compose(v528_10,v530_11);
        }
        const Space v528_13 = unite(v528_8,v528_12);
        v527_11_result = unite(v527_11_result,v528_13);
      }
      const Space v527_11 = std::move(v527_11_result);
      v522_12 = compose(v522_10,v527_11);
    }
    const Space v522_13 = unite(v522_8,v522_12);
    v521_11_result = unite(v521_11_result,v522_13);
  }
  const Space v521_11 = std::move(v521_11_result);
  return v521_11;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v531_11_result;
  for (int v531_11_label = 1; v531_11_label <= 2; ++v531_11_label) {
    const Space v531_11_tail = child(s0,v531_11_label);
    if (v531_11_tail.empty()) continue;
    const Path v531_11_head{v531_11_label};
    const Space v532_2 = singleton(v531_11_head);
    const Space v532_3 = intersect(constant_8,v532_2);
    const Space v532_4 = (has_head(v532_3) ? constant_9 : Space{});
    const Space v532_5 = subtract(constant_0,v532_4);
    Space v532_8;
    if (!v532_5.empty()) {
      const Path v533_6 = concat_path(p0,v531_11_head);
      Space v533_7_result;
      for (int v533_7_label = 1; v533_7_label <= 2; ++v533_7_label) {
        const Space v533_7_tail = child(v531_11_tail,v533_7_label);
        if (v533_7_tail.empty()) continue;
        const Path v533_7_head{v533_7_label};
        const Space v534_2 = singleton(v533_7_head);
        const Space v534_3 = intersect(constant_8,v534_2);
        const Space v534_4 = (has_head(v534_3) ? constant_9 : Space{});
        const Space v534_5 = subtract(constant_0,v534_4);
        Space v534_8;
        if (!v534_5.empty()) {
          const Path v535_6 = concat_path(v533_6,v533_7_head);
          const Space v535_7 = routine_110(c, v535_6, v533_7_tail);
          v534_8 = compose(v534_5,v535_7);
        }
        const Space v534_9 = intersect(constant_8,v534_2);
        const Space v534_10 = (has_head(v534_9) ? constant_9 : Space{});
        Space v534_12;
        if (!v534_10.empty()) {
          const Path v536_6 = concat_path(v533_6,v533_7_head);
          const Space v536_11 = routine_111(c, v536_6, v533_7_tail);
          v534_12 = compose(v534_10,v536_11);
        }
        const Space v534_13 = unite(v534_8,v534_12);
        v533_7_result = unite(v533_7_result,v534_13);
      }
      const Space v533_7 = std::move(v533_7_result);
      v532_8 = compose(v532_5,v533_7);
    }
    const Space v532_9 = intersect(constant_8,v532_2);
    const Space v532_10 = (has_head(v532_9) ? constant_9 : Space{});
    Space v532_12;
    if (!v532_10.empty()) {
      const Path v537_6 = concat_path(p0,v531_11_head);
      Space v537_11_result;
      for (int v537_11_label = 1; v537_11_label <= 2; ++v537_11_label) {
        const Space v537_11_tail = child(v531_11_tail,v537_11_label);
        if (v537_11_tail.empty()) continue;
        const Path v537_11_head{v537_11_label};
        const Space v538_2 = singleton(v537_11_head);
        const Space v538_3 = intersect(constant_8,v538_2);
        const Space v538_4 = (has_head(v538_3) ? constant_9 : Space{});
        const Space v538_5 = subtract(constant_0,v538_4);
        Space v538_7;
        if (!v538_5.empty()) {
          const Space v539_6 = routine_112(c, v537_11_head, v537_6, v537_11_tail);
          v538_7 = compose(v538_5,v539_6);
        }
        const Space v538_8 = intersect(constant_8,v538_2);
        const Space v538_9 = (has_head(v538_8) ? constant_9 : Space{});
        Space v538_11;
        if (!v538_9.empty()) {
          const Space v540_10 = routine_113(c, v537_11_head, v537_6, v537_11_tail);
          v538_11 = compose(v538_9,v540_10);
        }
        const Space v538_12 = unite(v538_7,v538_11);
        v537_11_result = unite(v537_11_result,v538_12);
      }
      const Space v537_11 = std::move(v537_11_result);
      v532_12 = compose(v532_10,v537_11);
    }
    const Space v532_13 = unite(v532_8,v532_12);
    v531_11_result = unite(v531_11_result,v532_13);
  }
  const Space v531_11 = std::move(v531_11_result);
  return v531_11;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v541_11_result;
  for (int v541_11_label = 1; v541_11_label <= 2; ++v541_11_label) {
    const Space v541_11_tail = child(s0,v541_11_label);
    if (v541_11_tail.empty()) continue;
    const Path v541_11_head{v541_11_label};
    const Space v542_2 = singleton(v541_11_head);
    const Space v542_3 = intersect(constant_8,v542_2);
    const Space v542_4 = (has_head(v542_3) ? constant_9 : Space{});
    const Space v542_5 = subtract(constant_0,v542_4);
    Space v542_8;
    if (!v542_5.empty()) {
      const Path v543_6 = concat_path(p0,v541_11_head);
      Space v543_7_result;
      for (int v543_7_label = 1; v543_7_label <= 2; ++v543_7_label) {
        const Space v543_7_tail = child(v541_11_tail,v543_7_label);
        if (v543_7_tail.empty()) continue;
        const Path v543_7_head{v543_7_label};
        const Space v544_2 = singleton(v543_7_head);
        const Space v544_3 = intersect(constant_8,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_9 : Space{});
        const Space v544_5 = subtract(constant_0,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_7_head);
          const Space v545_7 = routine_114(c, v545_6, v543_7_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_8,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_9 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_7_head);
          const Space v546_11 = routine_115(c, v546_6, v543_7_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_7_result = unite(v543_7_result,v544_13);
      }
      const Space v543_7 = std::move(v543_7_result);
      v542_8 = compose(v542_5,v543_7);
    }
    const Space v542_9 = intersect(constant_8,v542_2);
    const Space v542_10 = (has_head(v542_9) ? constant_9 : Space{});
    Space v542_12;
    if (!v542_10.empty()) {
      const Path v547_6 = concat_path(p0,v541_11_head);
      Space v547_11_result;
      for (int v547_11_label = 1; v547_11_label <= 2; ++v547_11_label) {
        const Space v547_11_tail = child(v541_11_tail,v547_11_label);
        if (v547_11_tail.empty()) continue;
        const Path v547_11_head{v547_11_label};
        const Space v548_2 = singleton(v547_11_head);
        const Space v548_3 = intersect(constant_8,v548_2);
        const Space v548_4 = (has_head(v548_3) ? constant_9 : Space{});
        const Space v548_5 = subtract(constant_0,v548_4);
        Space v548_8;
        if (!v548_5.empty()) {
          const Path v549_6 = concat_path(v547_6,v547_11_head);
          const Space v549_7 = routine_114(c, v549_6, v547_11_tail);
          v548_8 = compose(v548_5,v549_7);
        }
        const Space v548_9 = intersect(constant_8,v548_2);
        const Space v548_10 = (has_head(v548_9) ? constant_9 : Space{});
        Space v548_12;
        if (!v548_10.empty()) {
          const Path v550_6 = concat_path(v547_6,v547_11_head);
          const Space v550_11 = routine_80(c, v550_6, v547_11_tail);
          v548_12 = compose(v548_10,v550_11);
        }
        const Space v548_13 = unite(v548_8,v548_12);
        v547_11_result = unite(v547_11_result,v548_13);
      }
      const Space v547_11 = std::move(v547_11_result);
      v542_12 = compose(v542_10,v547_11);
    }
    const Space v542_13 = unite(v542_8,v542_12);
    v541_11_result = unite(v541_11_result,v542_13);
  }
  const Space v541_11 = std::move(v541_11_result);
  return v541_11;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v551_8_result;
  for (int v551_8_label = 1; v551_8_label <= 2; ++v551_8_label) {
    const Space v551_8_tail = child(s0,v551_8_label);
    if (v551_8_tail.empty()) continue;
    const Path v551_8_head{v551_8_label};
    const Space v552_2 = singleton(v551_8_head);
    const Space v552_3 = intersect(constant_8,v552_2);
    const Space v552_4 = (has_head(v552_3) ? constant_9 : Space{});
    const Space v552_5 = subtract(constant_0,v552_4);
    Space v552_8;
    if (!v552_5.empty()) {
      const Path v553_6 = concat_path(p0,v551_8_head);
      Space v553_7_result;
      for (int v553_7_label = 1; v553_7_label <= 2; ++v553_7_label) {
        const Space v553_7_tail = child(v551_8_tail,v553_7_label);
        if (v553_7_tail.empty()) continue;
        const Path v553_7_head{v553_7_label};
        const Space v554_2 = singleton(v553_7_head);
        const Space v554_3 = intersect(constant_8,v554_2);
        const Space v554_4 = (has_head(v554_3) ? constant_9 : Space{});
        const Space v554_5 = subtract(constant_0,v554_4);
        Space v554_8;
        if (!v554_5.empty()) {
          const Path v555_6 = concat_path(v553_6,v553_7_head);
          const Space v555_7 = routine_114(c, v555_6, v553_7_tail);
          v554_8 = compose(v554_5,v555_7);
        }
        const Space v554_9 = intersect(constant_8,v554_2);
        const Space v554_10 = (has_head(v554_9) ? constant_9 : Space{});
        Space v554_12;
        if (!v554_10.empty()) {
          const Path v556_6 = concat_path(v553_6,v553_7_head);
          const Space v556_11 = routine_115(c, v556_6, v553_7_tail);
          v554_12 = compose(v554_10,v556_11);
        }
        const Space v554_13 = unite(v554_8,v554_12);
        v553_7_result = unite(v553_7_result,v554_13);
      }
      const Space v553_7 = std::move(v553_7_result);
      v552_8 = compose(v552_5,v553_7);
    }
    const Space v552_9 = intersect(constant_8,v552_2);
    const Space v552_10 = (has_head(v552_9) ? constant_9 : Space{});
    const Space v552_11 = compose(v552_10,v551_8_tail);
    const Space v552_12 = unite(v552_8,v552_11);
    v551_8_result = unite(v551_8_result,v552_12);
  }
  const Space v551_8 = std::move(v551_8_result);
  return v551_8;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v557_11_result;
  for (int v557_11_label = 1; v557_11_label <= 2; ++v557_11_label) {
    const Space v557_11_tail = child(s0,v557_11_label);
    if (v557_11_tail.empty()) continue;
    const Path v557_11_head{v557_11_label};
    const Space v558_2 = singleton(v557_11_head);
    const Space v558_3 = intersect(constant_8,v558_2);
    const Space v558_4 = (has_head(v558_3) ? constant_9 : Space{});
    const Space v558_5 = subtract(constant_0,v558_4);
    Space v558_8;
    if (!v558_5.empty()) {
      const Path v559_6 = concat_path(p0,v557_11_head);
      Space v559_7_result;
      for (int v559_7_label = 1; v559_7_label <= 2; ++v559_7_label) {
        const Space v559_7_tail = child(v557_11_tail,v559_7_label);
        if (v559_7_tail.empty()) continue;
        const Path v559_7_head{v559_7_label};
        const Space v560_2 = singleton(v559_7_head);
        const Space v560_3 = intersect(constant_8,v560_2);
        const Space v560_4 = (has_head(v560_3) ? constant_9 : Space{});
        const Space v560_5 = subtract(constant_0,v560_4);
        Space v560_8;
        if (!v560_5.empty()) {
          const Path v561_6 = concat_path(v559_6,v559_7_head);
          const Space v561_7 = routine_116(c, v561_6, v559_7_tail);
          v560_8 = compose(v560_5,v561_7);
        }
        const Space v560_9 = intersect(constant_8,v560_2);
        const Space v560_10 = (has_head(v560_9) ? constant_9 : Space{});
        Space v560_12;
        if (!v560_10.empty()) {
          const Path v562_6 = concat_path(v559_6,v559_7_head);
          const Space v562_11 = routine_117(c, v562_6, v559_7_tail);
          v560_12 = compose(v560_10,v562_11);
        }
        const Space v560_13 = unite(v560_8,v560_12);
        v559_7_result = unite(v559_7_result,v560_13);
      }
      const Space v559_7 = std::move(v559_7_result);
      v558_8 = compose(v558_5,v559_7);
    }
    const Space v558_9 = intersect(constant_8,v558_2);
    const Space v558_10 = (has_head(v558_9) ? constant_9 : Space{});
    Space v558_12;
    if (!v558_10.empty()) {
      const Path v563_6 = concat_path(p0,v557_11_head);
      Space v563_11_result;
      for (int v563_11_label = 1; v563_11_label <= 2; ++v563_11_label) {
        const Space v563_11_tail = child(v557_11_tail,v563_11_label);
        if (v563_11_tail.empty()) continue;
        const Path v563_11_head{v563_11_label};
        const Space v564_2 = singleton(v563_11_head);
        const Space v564_3 = intersect(constant_8,v564_2);
        const Space v564_4 = (has_head(v564_3) ? constant_9 : Space{});
        const Space v564_5 = subtract(constant_0,v564_4);
        Space v564_8;
        if (!v564_5.empty()) {
          const Path v565_6 = concat_path(v563_6,v563_11_head);
          const Space v565_7 = routine_116(c, v565_6, v563_11_tail);
          v564_8 = compose(v564_5,v565_7);
        }
        const Space v564_9 = intersect(constant_8,v564_2);
        const Space v564_10 = (has_head(v564_9) ? constant_9 : Space{});
        Space v564_12;
        if (!v564_10.empty()) {
          const Path v566_6 = concat_path(v563_6,v563_11_head);
          const Space v566_11 = routine_83(c, v566_6, v563_11_tail);
          v564_12 = compose(v564_10,v566_11);
        }
        const Space v564_13 = unite(v564_8,v564_12);
        v563_11_result = unite(v563_11_result,v564_13);
      }
      const Space v563_11 = std::move(v563_11_result);
      v558_12 = compose(v558_10,v563_11);
    }
    const Space v558_13 = unite(v558_8,v558_12);
    v557_11_result = unite(v557_11_result,v558_13);
  }
  const Space v557_11 = std::move(v557_11_result);
  return v557_11;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0) {
  Space v567_11_result;
  for (int v567_11_label = 1; v567_11_label <= 2; ++v567_11_label) {
    const Space v567_11_tail = child(s0,v567_11_label);
    if (v567_11_tail.empty()) continue;
    const Path v567_11_head{v567_11_label};
    const Space v568_2 = singleton(v567_11_head);
    const Space v568_3 = intersect(constant_8,v568_2);
    const Space v568_4 = (has_head(v568_3) ? constant_9 : Space{});
    const Space v568_5 = subtract(constant_0,v568_4);
    Space v568_8;
    if (!v568_5.empty()) {
      const Path v569_6 = concat_path(p0,v567_11_head);
      Space v569_7_result;
      for (int v569_7_label = 1; v569_7_label <= 2; ++v569_7_label) {
        const Space v569_7_tail = child(v567_11_tail,v569_7_label);
        if (v569_7_tail.empty()) continue;
        const Path v569_7_head{v569_7_label};
        const Space v570_2 = singleton(v569_7_head);
        const Space v570_3 = intersect(constant_8,v570_2);
        const Space v570_4 = (has_head(v570_3) ? constant_9 : Space{});
        const Space v570_5 = subtract(constant_0,v570_4);
        Space v570_8;
        if (!v570_5.empty()) {
          const Path v571_6 = concat_path(v569_6,v569_7_head);
          const Space v571_7 = routine_116(c, v571_6, v569_7_tail);
          v570_8 = compose(v570_5,v571_7);
        }
        const Space v570_9 = intersect(constant_8,v570_2);
        const Space v570_10 = (has_head(v570_9) ? constant_9 : Space{});
        Space v570_12;
        if (!v570_10.empty()) {
          const Path v572_6 = concat_path(v569_6,v569_7_head);
          const Space v572_11 = routine_117(c, v572_6, v569_7_tail);
          v570_12 = compose(v570_10,v572_11);
        }
        const Space v570_13 = unite(v570_8,v570_12);
        v569_7_result = unite(v569_7_result,v570_13);
      }
      const Space v569_7 = std::move(v569_7_result);
      v568_8 = compose(v568_5,v569_7);
    }
    const Space v568_9 = intersect(constant_8,v568_2);
    const Space v568_10 = (has_head(v568_9) ? constant_9 : Space{});
    Space v568_12;
    if (!v568_10.empty()) {
      const Path v573_6 = concat_path(p0,v567_11_head);
      Space v573_11_result;
      for (int v573_11_label = 1; v573_11_label <= 2; ++v573_11_label) {
        const Space v573_11_tail = child(v567_11_tail,v573_11_label);
        if (v573_11_tail.empty()) continue;
        const Path v573_11_head{v573_11_label};
        const Space v574_2 = singleton(v573_11_head);
        const Space v574_3 = intersect(constant_8,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_9 : Space{});
        const Space v574_5 = subtract(constant_0,v574_4);
        Space v574_7;
        if (!v574_5.empty()) {
          const Space v575_6 = routine_118(c, v573_11_head, v573_6, v573_11_tail);
          v574_7 = compose(v574_5,v575_6);
        }
        const Space v574_8 = intersect(constant_8,v574_2);
        const Space v574_9 = (has_head(v574_8) ? constant_9 : Space{});
        Space v574_11;
        if (!v574_9.empty()) {
          const Space v576_10 = routine_119(c, v573_11_head, v573_6, v573_11_tail);
          v574_11 = compose(v574_9,v576_10);
        }
        const Space v574_12 = unite(v574_7,v574_11);
        v573_11_result = unite(v573_11_result,v574_12);
      }
      const Space v573_11 = std::move(v573_11_result);
      v568_12 = compose(v568_10,v573_11);
    }
    const Space v568_13 = unite(v568_8,v568_12);
    v567_11_result = unite(v567_11_result,v568_13);
  }
  const Space v567_11 = std::move(v567_11_result);
  return v567_11;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0) {
  Space v577_11_result;
  for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
    const Space v577_11_tail = child(s0,v577_11_label);
    if (v577_11_tail.empty()) continue;
    const Path v577_11_head{v577_11_label};
    const Space v578_2 = singleton(v577_11_head);
    const Space v578_3 = intersect(constant_8,v578_2);
    const Space v578_4 = (has_head(v578_3) ? constant_9 : Space{});
    const Space v578_5 = subtract(constant_0,v578_4);
    Space v578_8;
    if (!v578_5.empty()) {
      const Path v579_6 = concat_path(p0,v577_11_head);
      Space v579_7_result;
      for (int v579_7_label = 1; v579_7_label <= 2; ++v579_7_label) {
        const Space v579_7_tail = child(v577_11_tail,v579_7_label);
        if (v579_7_tail.empty()) continue;
        const Path v579_7_head{v579_7_label};
        const Space v580_2 = singleton(v579_7_head);
        const Space v580_3 = intersect(constant_8,v580_2);
        const Space v580_4 = (has_head(v580_3) ? constant_9 : Space{});
        const Space v580_5 = subtract(constant_0,v580_4);
        Space v580_8;
        if (!v580_5.empty()) {
          const Path v581_6 = concat_path(v579_6,v579_7_head);
          const Space v581_7 = routine_120(c, v581_6, v579_7_tail);
          v580_8 = compose(v580_5,v581_7);
        }
        const Space v580_9 = intersect(constant_8,v580_2);
        const Space v580_10 = (has_head(v580_9) ? constant_9 : Space{});
        Space v580_12;
        if (!v580_10.empty()) {
          const Path v582_6 = concat_path(v579_6,v579_7_head);
          const Space v582_11 = routine_121(c, v582_6, v579_7_tail);
          v580_12 = compose(v580_10,v582_11);
        }
        const Space v580_13 = unite(v580_8,v580_12);
        v579_7_result = unite(v579_7_result,v580_13);
      }
      const Space v579_7 = std::move(v579_7_result);
      v578_8 = compose(v578_5,v579_7);
    }
    const Space v578_9 = intersect(constant_8,v578_2);
    const Space v578_10 = (has_head(v578_9) ? constant_9 : Space{});
    Space v578_12;
    if (!v578_10.empty()) {
      const Path v583_6 = concat_path(p0,v577_11_head);
      Space v583_11_result;
      for (int v583_11_label = 1; v583_11_label <= 2; ++v583_11_label) {
        const Space v583_11_tail = child(v577_11_tail,v583_11_label);
        if (v583_11_tail.empty()) continue;
        const Path v583_11_head{v583_11_label};
        const Space v584_2 = singleton(v583_11_head);
        const Space v584_3 = intersect(constant_8,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_9 : Space{});
        const Space v584_5 = subtract(constant_0,v584_4);
        Space v584_8;
        if (!v584_5.empty()) {
          const Path v585_6 = concat_path(v583_6,v583_11_head);
          const Space v585_7 = routine_120(c, v585_6, v583_11_tail);
          v584_8 = compose(v584_5,v585_7);
        }
        const Space v584_9 = intersect(constant_8,v584_2);
        const Space v584_10 = (has_head(v584_9) ? constant_9 : Space{});
        Space v584_12;
        if (!v584_10.empty()) {
          const Path v586_6 = concat_path(v583_6,v583_11_head);
          const Space v586_11 = routine_86(c, v586_6, v583_11_tail);
          v584_12 = compose(v584_10,v586_11);
        }
        const Space v584_13 = unite(v584_8,v584_12);
        v583_11_result = unite(v583_11_result,v584_13);
      }
      const Space v583_11 = std::move(v583_11_result);
      v578_12 = compose(v578_10,v583_11);
    }
    const Space v578_13 = unite(v578_8,v578_12);
    v577_11_result = unite(v577_11_result,v578_13);
  }
  const Space v577_11 = std::move(v577_11_result);
  return v577_11;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v587_8_result;
  for (int v587_8_label = 1; v587_8_label <= 2; ++v587_8_label) {
    const Space v587_8_tail = child(s0,v587_8_label);
    if (v587_8_tail.empty()) continue;
    const Path v587_8_head{v587_8_label};
    const Space v588_2 = singleton(v587_8_head);
    const Space v588_3 = intersect(constant_8,v588_2);
    const Space v588_4 = (has_head(v588_3) ? constant_9 : Space{});
    const Space v588_5 = subtract(constant_0,v588_4);
    Space v588_8;
    if (!v588_5.empty()) {
      const Path v589_6 = concat_path(p0,v587_8_head);
      Space v589_7_result;
      for (int v589_7_label = 1; v589_7_label <= 2; ++v589_7_label) {
        const Space v589_7_tail = child(v587_8_tail,v589_7_label);
        if (v589_7_tail.empty()) continue;
        const Path v589_7_head{v589_7_label};
        const Space v590_2 = singleton(v589_7_head);
        const Space v590_3 = intersect(constant_8,v590_2);
        const Space v590_4 = (has_head(v590_3) ? constant_9 : Space{});
        const Space v590_5 = subtract(constant_0,v590_4);
        Space v590_8;
        if (!v590_5.empty()) {
          const Path v591_6 = concat_path(v589_6,v589_7_head);
          const Space v591_7 = routine_120(c, v591_6, v589_7_tail);
          v590_8 = compose(v590_5,v591_7);
        }
        const Space v590_9 = intersect(constant_8,v590_2);
        const Space v590_10 = (has_head(v590_9) ? constant_9 : Space{});
        Space v590_12;
        if (!v590_10.empty()) {
          const Path v592_6 = concat_path(v589_6,v589_7_head);
          const Space v592_11 = routine_121(c, v592_6, v589_7_tail);
          v590_12 = compose(v590_10,v592_11);
        }
        const Space v590_13 = unite(v590_8,v590_12);
        v589_7_result = unite(v589_7_result,v590_13);
      }
      const Space v589_7 = std::move(v589_7_result);
      v588_8 = compose(v588_5,v589_7);
    }
    const Space v588_9 = intersect(constant_8,v588_2);
    const Space v588_10 = (has_head(v588_9) ? constant_9 : Space{});
    const Space v588_11 = compose(v588_10,v587_8_tail);
    const Space v588_12 = unite(v588_8,v588_11);
    v587_8_result = unite(v587_8_result,v588_12);
  }
  const Space v587_8 = std::move(v587_8_result);
  return v587_8;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v593_11_result;
  for (int v593_11_label = 1; v593_11_label <= 2; ++v593_11_label) {
    const Space v593_11_tail = child(s0,v593_11_label);
    if (v593_11_tail.empty()) continue;
    const Path v593_11_head{v593_11_label};
    const Space v594_2 = singleton(v593_11_head);
    const Space v594_3 = intersect(constant_8,v594_2);
    const Space v594_4 = (has_head(v594_3) ? constant_9 : Space{});
    const Space v594_5 = subtract(constant_0,v594_4);
    Space v594_8;
    if (!v594_5.empty()) {
      const Path v595_6 = concat_path(p0,v593_11_head);
      Space v595_7_result;
      for (int v595_7_label = 1; v595_7_label <= 2; ++v595_7_label) {
        const Space v595_7_tail = child(v593_11_tail,v595_7_label);
        if (v595_7_tail.empty()) continue;
        const Path v595_7_head{v595_7_label};
        const Space v596_2 = singleton(v595_7_head);
        const Space v596_3 = intersect(constant_8,v596_2);
        const Space v596_4 = (has_head(v596_3) ? constant_9 : Space{});
        const Space v596_5 = subtract(constant_0,v596_4);
        Space v596_8;
        if (!v596_5.empty()) {
          const Path v597_6 = concat_path(v595_6,v595_7_head);
          const Space v597_7 = routine_122(c, v597_6, v595_7_tail);
          v596_8 = compose(v596_5,v597_7);
        }
        const Space v596_9 = intersect(constant_8,v596_2);
        const Space v596_10 = (has_head(v596_9) ? constant_9 : Space{});
        Space v596_12;
        if (!v596_10.empty()) {
          const Path v598_6 = concat_path(v595_6,v595_7_head);
          const Space v598_11 = routine_123(c, v598_6, v595_7_tail);
          v596_12 = compose(v596_10,v598_11);
        }
        const Space v596_13 = unite(v596_8,v596_12);
        v595_7_result = unite(v595_7_result,v596_13);
      }
      const Space v595_7 = std::move(v595_7_result);
      v594_8 = compose(v594_5,v595_7);
    }
    const Space v594_9 = intersect(constant_8,v594_2);
    const Space v594_10 = (has_head(v594_9) ? constant_9 : Space{});
    Space v594_12;
    if (!v594_10.empty()) {
      const Path v599_6 = concat_path(p0,v593_11_head);
      Space v599_11_result;
      for (int v599_11_label = 1; v599_11_label <= 2; ++v599_11_label) {
        const Space v599_11_tail = child(v593_11_tail,v599_11_label);
        if (v599_11_tail.empty()) continue;
        const Path v599_11_head{v599_11_label};
        const Space v600_2 = singleton(v599_11_head);
        const Space v600_3 = intersect(constant_8,v600_2);
        const Space v600_4 = (has_head(v600_3) ? constant_9 : Space{});
        const Space v600_5 = subtract(constant_0,v600_4);
        Space v600_8;
        if (!v600_5.empty()) {
          const Path v601_6 = concat_path(v599_6,v599_11_head);
          const Space v601_7 = routine_122(c, v601_6, v599_11_tail);
          v600_8 = compose(v600_5,v601_7);
        }
        const Space v600_9 = intersect(constant_8,v600_2);
        const Space v600_10 = (has_head(v600_9) ? constant_9 : Space{});
        Space v600_12;
        if (!v600_10.empty()) {
          const Path v602_6 = concat_path(v599_6,v599_11_head);
          const Space v602_11 = routine_89(c, v602_6, v599_11_tail);
          v600_12 = compose(v600_10,v602_11);
        }
        const Space v600_13 = unite(v600_8,v600_12);
        v599_11_result = unite(v599_11_result,v600_13);
      }
      const Space v599_11 = std::move(v599_11_result);
      v594_12 = compose(v594_10,v599_11);
    }
    const Space v594_13 = unite(v594_8,v594_12);
    v593_11_result = unite(v593_11_result,v594_13);
  }
  const Space v593_11 = std::move(v593_11_result);
  return v593_11;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v603_11_result;
  for (int v603_11_label = 1; v603_11_label <= 2; ++v603_11_label) {
    const Space v603_11_tail = child(s0,v603_11_label);
    if (v603_11_tail.empty()) continue;
    const Path v603_11_head{v603_11_label};
    const Space v604_2 = singleton(v603_11_head);
    const Space v604_3 = intersect(constant_8,v604_2);
    const Space v604_4 = (has_head(v604_3) ? constant_9 : Space{});
    const Space v604_5 = subtract(constant_0,v604_4);
    Space v604_8;
    if (!v604_5.empty()) {
      const Path v605_6 = concat_path(p0,v603_11_head);
      Space v605_7_result;
      for (int v605_7_label = 1; v605_7_label <= 2; ++v605_7_label) {
        const Space v605_7_tail = child(v603_11_tail,v605_7_label);
        if (v605_7_tail.empty()) continue;
        const Path v605_7_head{v605_7_label};
        const Space v606_2 = singleton(v605_7_head);
        const Space v606_3 = intersect(constant_8,v606_2);
        const Space v606_4 = (has_head(v606_3) ? constant_9 : Space{});
        const Space v606_5 = subtract(constant_0,v606_4);
        Space v606_8;
        if (!v606_5.empty()) {
          const Path v607_6 = concat_path(v605_6,v605_7_head);
          const Space v607_7 = routine_122(c, v607_6, v605_7_tail);
          v606_8 = compose(v606_5,v607_7);
        }
        const Space v606_9 = intersect(constant_8,v606_2);
        const Space v606_10 = (has_head(v606_9) ? constant_9 : Space{});
        Space v606_12;
        if (!v606_10.empty()) {
          const Path v608_6 = concat_path(v605_6,v605_7_head);
          const Space v608_11 = routine_123(c, v608_6, v605_7_tail);
          v606_12 = compose(v606_10,v608_11);
        }
        const Space v606_13 = unite(v606_8,v606_12);
        v605_7_result = unite(v605_7_result,v606_13);
      }
      const Space v605_7 = std::move(v605_7_result);
      v604_8 = compose(v604_5,v605_7);
    }
    const Space v604_9 = intersect(constant_8,v604_2);
    const Space v604_10 = (has_head(v604_9) ? constant_9 : Space{});
    Space v604_12;
    if (!v604_10.empty()) {
      const Path v609_6 = concat_path(p0,v603_11_head);
      Space v609_11_result;
      for (int v609_11_label = 1; v609_11_label <= 2; ++v609_11_label) {
        const Space v609_11_tail = child(v603_11_tail,v609_11_label);
        if (v609_11_tail.empty()) continue;
        const Path v609_11_head{v609_11_label};
        const Space v610_2 = singleton(v609_11_head);
        const Space v610_3 = intersect(constant_8,v610_2);
        const Space v610_4 = (has_head(v610_3) ? constant_9 : Space{});
        const Space v610_5 = subtract(constant_0,v610_4);
        Space v610_7;
        if (!v610_5.empty()) {
          const Space v611_6 = routine_124(c, v609_11_head, v609_6, v609_11_tail);
          v610_7 = compose(v610_5,v611_6);
        }
        const Space v610_8 = intersect(constant_8,v610_2);
        const Space v610_9 = (has_head(v610_8) ? constant_9 : Space{});
        Space v610_11;
        if (!v610_9.empty()) {
          const Space v612_10 = routine_125(c, v609_11_head, v609_6, v609_11_tail);
          v610_11 = compose(v610_9,v612_10);
        }
        const Space v610_12 = unite(v610_7,v610_11);
        v609_11_result = unite(v609_11_result,v610_12);
      }
      const Space v609_11 = std::move(v609_11_result);
      v604_12 = compose(v604_10,v609_11);
    }
    const Space v604_13 = unite(v604_8,v604_12);
    v603_11_result = unite(v603_11_result,v604_13);
  }
  const Space v603_11 = std::move(v603_11_result);
  return v603_11;
}

static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v613_12_result;
  for (int v613_12_label = 1; v613_12_label <= 2; ++v613_12_label) {
    const Space v613_12_tail = child(s0,v613_12_label);
    if (v613_12_tail.empty()) continue;
    const Path v613_12_head{v613_12_label};
    const Space v614_2 = singleton(v613_12_head);
    const Space v614_3 = intersect(constant_8,v614_2);
    const Space v614_4 = (has_head(v614_3) ? constant_9 : Space{});
    const Space v614_5 = subtract(constant_0,v614_4);
    Space v614_8;
    if (!v614_5.empty()) {
      const Path v615_6 = concat_path(p0,v613_12_head);
      Space v615_7_result;
      for (int v615_7_label = 1; v615_7_label <= 2; ++v615_7_label) {
        const Space v615_7_tail = child(v613_12_tail,v615_7_label);
        if (v615_7_tail.empty()) continue;
        const Path v615_7_head{v615_7_label};
        const Space v616_2 = singleton(v615_7_head);
        const Space v616_3 = intersect(constant_8,v616_2);
        const Space v616_4 = (has_head(v616_3) ? constant_9 : Space{});
        const Space v616_5 = subtract(constant_0,v616_4);
        Space v616_8;
        if (!v616_5.empty()) {
          const Path v617_6 = concat_path(v615_6,v615_7_head);
          const Space v617_7 = routine_126(c, v617_6, p1, v615_7_tail);
          v616_8 = compose(v616_5,v617_7);
        }
        const Space v616_9 = intersect(constant_8,v616_2);
        const Space v616_10 = (has_head(v616_9) ? constant_9 : Space{});
        Space v616_12;
        if (!v616_10.empty()) {
          const Path v618_6 = concat_path(v615_6,v615_7_head);
          const Space v618_11 = routine_127(c, v618_6, p1, v615_7_tail);
          v616_12 = compose(v616_10,v618_11);
        }
        const Space v616_13 = unite(v616_8,v616_12);
        v615_7_result = unite(v615_7_result,v616_13);
      }
      const Space v615_7 = std::move(v615_7_result);
      v614_8 = compose(v614_5,v615_7);
    }
    const Space v614_9 = intersect(constant_8,v614_2);
    const Space v614_10 = (has_head(v614_9) ? constant_9 : Space{});
    Space v614_12;
    if (!v614_10.empty()) {
      const Path v619_6 = concat_path(p0,v613_12_head);
      Space v619_11_result;
      for (int v619_11_label = 1; v619_11_label <= 2; ++v619_11_label) {
        const Space v619_11_tail = child(v613_12_tail,v619_11_label);
        if (v619_11_tail.empty()) continue;
        const Path v619_11_head{v619_11_label};
        const Space v620_2 = singleton(v619_11_head);
        const Space v620_3 = intersect(constant_8,v620_2);
        const Space v620_4 = (has_head(v620_3) ? constant_9 : Space{});
        const Space v620_5 = subtract(constant_0,v620_4);
        Space v620_8;
        if (!v620_5.empty()) {
          const Path v621_6 = concat_path(v619_6,v619_11_head);
          const Space v621_7 = routine_126(c, v621_6, p1, v619_11_tail);
          v620_8 = compose(v620_5,v621_7);
        }
        const Space v620_9 = intersect(constant_8,v620_2);
        const Space v620_10 = (has_head(v620_9) ? constant_9 : Space{});
        Space v620_12;
        if (!v620_10.empty()) {
          const Path v622_6 = concat_path(v619_6,v619_11_head);
          const Space v622_11 = routine_60(c, v622_6, p1, v619_11_tail);
          v620_12 = compose(v620_10,v622_11);
        }
        const Space v620_13 = unite(v620_8,v620_12);
        v619_11_result = unite(v619_11_result,v620_13);
      }
      const Space v619_11 = std::move(v619_11_result);
      v614_12 = compose(v614_10,v619_11);
    }
    const Space v614_13 = unite(v614_8,v614_12);
    v613_12_result = unite(v613_12_result,v614_13);
  }
  const Space v613_12 = std::move(v613_12_result);
  return v613_12;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v623_17_result;
  for (int v623_17_label = 1; v623_17_label <= 2; ++v623_17_label) {
    const Space v623_17_tail = child(s0,v623_17_label);
    if (v623_17_tail.empty()) continue;
    const Path v623_17_head{v623_17_label};
    const Space v624_2 = singleton(v623_17_head);
    const Space v624_3 = intersect(constant_8,v624_2);
    const Space v624_4 = (has_head(v624_3) ? constant_9 : Space{});
    const Space v624_5 = subtract(constant_0,v624_4);
    Space v624_8;
    if (!v624_5.empty()) {
      const Path v625_6 = concat_path(p0,v623_17_head);
      Space v625_7_result;
      for (int v625_7_label = 1; v625_7_label <= 2; ++v625_7_label) {
        const Space v625_7_tail = child(v623_17_tail,v625_7_label);
        if (v625_7_tail.empty()) continue;
        const Path v625_7_head{v625_7_label};
        const Space v626_2 = singleton(v625_7_head);
        const Space v626_3 = intersect(constant_8,v626_2);
        const Space v626_4 = (has_head(v626_3) ? constant_9 : Space{});
        const Space v626_5 = subtract(constant_0,v626_4);
        Space v626_8;
        if (!v626_5.empty()) {
          const Path v627_6 = concat_path(v625_6,v625_7_head);
          const Space v627_7 = routine_126(c, v627_6, p1, v625_7_tail);
          v626_8 = compose(v626_5,v627_7);
        }
        const Space v626_9 = intersect(constant_8,v626_2);
        const Space v626_10 = (has_head(v626_9) ? constant_9 : Space{});
        Space v626_12;
        if (!v626_10.empty()) {
          const Path v628_6 = concat_path(v625_6,v625_7_head);
          const Space v628_11 = routine_127(c, v628_6, p1, v625_7_tail);
          v626_12 = compose(v626_10,v628_11);
        }
        const Space v626_13 = unite(v626_8,v626_12);
        v625_7_result = unite(v625_7_result,v626_13);
      }
      const Space v625_7 = std::move(v625_7_result);
      v624_8 = compose(v624_5,v625_7);
    }
    const Space v624_9 = intersect(constant_8,v624_2);
    const Space v624_10 = (has_head(v624_9) ? constant_9 : Space{});
    Space v624_16;
    if (!v624_10.empty()) {
      const Path v629_6 = concat_path(p0,v623_17_head);
      Space v629_14;
      if (!constant_0.empty()) {
        const Space v630_11 = routine_92(c, constant_14, p1, constant_15);
        const Space v630_12 = routine_93(c, constant_16, p1, constant_17);
        const Space v630_13 = unite(v630_11,v630_12);
        v629_14 = compose(constant_0,v630_13);
      }
      Space v629_15_result;
      for (int v629_15_label = 1; v629_15_label <= 2; ++v629_15_label) {
        const Space v629_15_tail = child(v629_14,v629_15_label);
        if (v629_15_tail.empty()) continue;
        const Path v629_15_head{v629_15_label};
        const Space v631_2 = singleton(v629_15_head);
        const Space v631_3 = intersect(constant_8,v631_2);
        const Space v631_4 = (has_head(v631_3) ? constant_9 : Space{});
        const Space v631_5 = subtract(constant_0,v631_4);
        Space v631_7;
        if (!v631_5.empty()) {
          const Space v632_6 = routine_94(c, v629_15_head, v629_6, v629_15_tail, v623_17_tail);
          v631_7 = compose(v631_5,v632_6);
        }
        const Space v631_8 = intersect(constant_8,v631_2);
        const Space v631_9 = (has_head(v631_8) ? constant_9 : Space{});
        Space v631_11;
        if (!v631_9.empty()) {
          const Space v633_10 = routine_95(c, v629_15_head, v629_6, v629_15_tail, v623_17_tail);
          v631_11 = compose(v631_9,v633_10);
        }
        const Space v631_12 = unite(v631_7,v631_11);
        v629_15_result = unite(v629_15_result,v631_12);
      }
      const Space v629_15 = std::move(v629_15_result);
      v624_16 = compose(v624_10,v629_15);
    }
    const Space v624_17 = unite(v624_8,v624_16);
    v623_17_result = unite(v623_17_result,v624_17);
  }
  const Space v623_17 = std::move(v623_17_result);
  return v623_17;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v634_21;
  if (!constant_0.empty()) {
    Space v635_20;
    if (!constant_0.empty()) {
      const Space v636_7 = routine_128(c, constant_1, p1, constant_18);
      const Space v636_10 = routine_128(c, constant_3, p1, constant_19);
      const Space v636_11 = unite(v636_7,v636_10);
      const Space v636_14 = routine_129(c, constant_5, p1, constant_20);
      const Space v636_15 = unite(v636_11,v636_14);
      const Space v636_18 = routine_130(c, constant_6, p1, constant_21);
      const Space v636_19 = unite(v636_15,v636_18);
      v635_20 = compose(constant_0,v636_19);
    }
    v634_21 = compose(constant_0,v635_20);
  }
  Space v634_31_result;
  for (int v634_31_label = 1; v634_31_label <= 2; ++v634_31_label) {
    const Space v634_31_tail = child(v634_21,v634_31_label);
    if (v634_31_tail.empty()) continue;
    const Path v634_31_head{v634_31_label};
    const Space v637_2 = singleton(v634_31_head);
    const Space v637_3 = intersect(constant_8,v637_2);
    const Space v637_4 = (has_head(v637_3) ? constant_9 : Space{});
    const Space v637_5 = subtract(constant_0,v637_4);
    Space v637_7;
    if (!v637_5.empty()) {
      Space v638_6_result;
      for (int v638_6_label = 1; v638_6_label <= 2; ++v638_6_label) {
        const Space v638_6_tail = child(v634_31_tail,v638_6_label);
        if (v638_6_tail.empty()) continue;
        const Path v638_6_head{v638_6_label};
        const Space v639_2 = singleton(v638_6_head);
        const Space v639_3 = intersect(constant_8,v639_2);
        const Space v639_4 = (has_head(v639_3) ? constant_9 : Space{});
        const Space v639_5 = subtract(constant_0,v639_4);
        Space v639_8;
        if (!v639_5.empty()) {
          const Path v640_6 = concat_path(v634_31_head,v638_6_head);
          const Space v640_7 = routine_131(c, v640_6, p0, v638_6_tail, s0);
          v639_8 = compose(v639_5,v640_7);
        }
        const Space v639_9 = intersect(constant_8,v639_2);
        const Space v639_10 = (has_head(v639_9) ? constant_9 : Space{});
        Space v639_12;
        if (!v639_10.empty()) {
          const Path v641_6 = concat_path(v634_31_head,v638_6_head);
          const Space v641_11 = routine_132(c, v641_6, p0, v638_6_tail, s0);
          v639_12 = compose(v639_10,v641_11);
        }
        const Space v639_13 = unite(v639_8,v639_12);
        v638_6_result = unite(v638_6_result,v639_13);
      }
      const Space v638_6 = std::move(v638_6_result);
      v637_7 = compose(v637_5,v638_6);
    }
    const Space v637_8 = intersect(constant_8,v637_2);
    const Space v637_9 = (has_head(v637_8) ? constant_9 : Space{});
    Space v637_11;
    if (!v637_9.empty()) {
      Space v642_10_result;
      for (int v642_10_label = 1; v642_10_label <= 2; ++v642_10_label) {
        const Space v642_10_tail = child(v634_31_tail,v642_10_label);
        if (v642_10_tail.empty()) continue;
        const Path v642_10_head{v642_10_label};
        const Space v643_2 = singleton(v642_10_head);
        const Space v643_3 = intersect(constant_8,v643_2);
        const Space v643_4 = (has_head(v643_3) ? constant_9 : Space{});
        const Space v643_5 = subtract(constant_0,v643_4);
        Space v643_8;
        if (!v643_5.empty()) {
          const Path v644_6 = concat_path(v634_31_head,v642_10_head);
          const Space v644_7 = routine_131(c, v644_6, p0, v642_10_tail, s0);
          v643_8 = compose(v643_5,v644_7);
        }
        const Space v643_9 = intersect(constant_8,v643_2);
        const Space v643_10 = (has_head(v643_9) ? constant_9 : Space{});
        Space v643_12;
        if (!v643_10.empty()) {
          const Path v645_6 = concat_path(v634_31_head,v642_10_head);
          const Space v645_11 = routine_133(c, v645_6, p0, v642_10_tail, s0);
          v643_12 = compose(v643_10,v645_11);
        }
        const Space v643_13 = unite(v643_8,v643_12);
        v642_10_result = unite(v642_10_result,v643_13);
      }
      const Space v642_10 = std::move(v642_10_result);
      v637_11 = compose(v637_9,v642_10);
    }
    const Space v637_12 = unite(v637_7,v637_11);
    v634_31_result = unite(v634_31_result,v637_12);
  }
  const Space v634_31 = std::move(v634_31_result);
  return v634_31;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v646_12_result;
  for (int v646_12_label = 1; v646_12_label <= 2; ++v646_12_label) {
    const Space v646_12_tail = child(s0,v646_12_label);
    if (v646_12_tail.empty()) continue;
    const Path v646_12_head{v646_12_label};
    const Space v647_2 = singleton(v646_12_head);
    const Space v647_3 = intersect(constant_8,v647_2);
    const Space v647_4 = (has_head(v647_3) ? constant_9 : Space{});
    const Space v647_5 = subtract(constant_0,v647_4);
    Space v647_8;
    if (!v647_5.empty()) {
      const Path v648_6 = concat_path(p0,v646_12_head);
      Space v648_7_result;
      for (int v648_7_label = 1; v648_7_label <= 2; ++v648_7_label) {
        const Space v648_7_tail = child(v646_12_tail,v648_7_label);
        if (v648_7_tail.empty()) continue;
        const Path v648_7_head{v648_7_label};
        const Space v649_2 = singleton(v648_7_head);
        const Space v649_3 = intersect(constant_8,v649_2);
        const Space v649_4 = (has_head(v649_3) ? constant_9 : Space{});
        const Space v649_5 = subtract(constant_0,v649_4);
        Space v649_8;
        if (!v649_5.empty()) {
          const Path v650_6 = concat_path(v648_6,v648_7_head);
          const Space v650_7 = routine_134(c, v650_6, p1, v648_7_tail);
          v649_8 = compose(v649_5,v650_7);
        }
        const Space v649_9 = intersect(constant_8,v649_2);
        const Space v649_10 = (has_head(v649_9) ? constant_9 : Space{});
        Space v649_12;
        if (!v649_10.empty()) {
          const Path v651_6 = concat_path(v648_6,v648_7_head);
          const Space v651_11 = routine_135(c, v651_6, p1, v648_7_tail);
          v649_12 = compose(v649_10,v651_11);
        }
        const Space v649_13 = unite(v649_8,v649_12);
        v648_7_result = unite(v648_7_result,v649_13);
      }
      const Space v648_7 = std::move(v648_7_result);
      v647_8 = compose(v647_5,v648_7);
    }
    const Space v647_9 = intersect(constant_8,v647_2);
    const Space v647_10 = (has_head(v647_9) ? constant_9 : Space{});
    Space v647_12;
    if (!v647_10.empty()) {
      const Path v652_6 = concat_path(p0,v646_12_head);
      Space v652_11_result;
      for (int v652_11_label = 1; v652_11_label <= 2; ++v652_11_label) {
        const Space v652_11_tail = child(v646_12_tail,v652_11_label);
        if (v652_11_tail.empty()) continue;
        const Path v652_11_head{v652_11_label};
        const Space v653_2 = singleton(v652_11_head);
        const Space v653_3 = intersect(constant_8,v653_2);
        const Space v653_4 = (has_head(v653_3) ? constant_9 : Space{});
        const Space v653_5 = subtract(constant_0,v653_4);
        Space v653_8;
        if (!v653_5.empty()) {
          const Path v654_6 = concat_path(v652_6,v652_11_head);
          const Space v654_7 = routine_134(c, v654_6, p1, v652_11_tail);
          v653_8 = compose(v653_5,v654_7);
        }
        const Space v653_9 = intersect(constant_8,v653_2);
        const Space v653_10 = (has_head(v653_9) ? constant_9 : Space{});
        Space v653_12;
        if (!v653_10.empty()) {
          const Path v655_6 = concat_path(v652_6,v652_11_head);
          const Space v655_11 = routine_63(c, v655_6, p1, v652_11_tail);
          v653_12 = compose(v653_10,v655_11);
        }
        const Space v653_13 = unite(v653_8,v653_12);
        v652_11_result = unite(v652_11_result,v653_13);
      }
      const Space v652_11 = std::move(v652_11_result);
      v647_12 = compose(v647_10,v652_11);
    }
    const Space v647_13 = unite(v647_8,v647_12);
    v646_12_result = unite(v646_12_result,v647_13);
  }
  const Space v646_12 = std::move(v646_12_result);
  return v646_12;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v656_17_result;
  for (int v656_17_label = 1; v656_17_label <= 2; ++v656_17_label) {
    const Space v656_17_tail = child(s0,v656_17_label);
    if (v656_17_tail.empty()) continue;
    const Path v656_17_head{v656_17_label};
    const Space v657_2 = singleton(v656_17_head);
    const Space v657_3 = intersect(constant_8,v657_2);
    const Space v657_4 = (has_head(v657_3) ? constant_9 : Space{});
    const Space v657_5 = subtract(constant_0,v657_4);
    Space v657_8;
    if (!v657_5.empty()) {
      const Path v658_6 = concat_path(p0,v656_17_head);
      Space v658_7_result;
      for (int v658_7_label = 1; v658_7_label <= 2; ++v658_7_label) {
        const Space v658_7_tail = child(v656_17_tail,v658_7_label);
        if (v658_7_tail.empty()) continue;
        const Path v658_7_head{v658_7_label};
        const Space v659_2 = singleton(v658_7_head);
        const Space v659_3 = intersect(constant_8,v659_2);
        const Space v659_4 = (has_head(v659_3) ? constant_9 : Space{});
        const Space v659_5 = subtract(constant_0,v659_4);
        Space v659_8;
        if (!v659_5.empty()) {
          const Path v660_6 = concat_path(v658_6,v658_7_head);
          const Space v660_7 = routine_134(c, v660_6, p1, v658_7_tail);
          v659_8 = compose(v659_5,v660_7);
        }
        const Space v659_9 = intersect(constant_8,v659_2);
        const Space v659_10 = (has_head(v659_9) ? constant_9 : Space{});
        Space v659_12;
        if (!v659_10.empty()) {
          const Path v661_6 = concat_path(v658_6,v658_7_head);
          const Space v661_11 = routine_135(c, v661_6, p1, v658_7_tail);
          v659_12 = compose(v659_10,v661_11);
        }
        const Space v659_13 = unite(v659_8,v659_12);
        v658_7_result = unite(v658_7_result,v659_13);
      }
      const Space v658_7 = std::move(v658_7_result);
      v657_8 = compose(v657_5,v658_7);
    }
    const Space v657_9 = intersect(constant_8,v657_2);
    const Space v657_10 = (has_head(v657_9) ? constant_9 : Space{});
    Space v657_16;
    if (!v657_10.empty()) {
      Space v662_14;
      if (!constant_0.empty()) {
        const Path v663_6 = concat_path(p0,v656_17_head);
        const Space v663_11 = routine_98(c, constant_14, p1, v663_6, constant_15);
        const Space v663_12 = routine_99(c, constant_16, p1, v663_6, constant_17);
        const Space v663_13 = unite(v663_11,v663_12);
        v662_14 = compose(constant_0,v663_13);
      }
      Space v662_15_result;
      for (int v662_15_label = 1; v662_15_label <= 2; ++v662_15_label) {
        const Space v662_15_tail = child(v662_14,v662_15_label);
        if (v662_15_tail.empty()) continue;
        const Path v662_15_head{v662_15_label};
        const Space v664_2 = singleton(v662_15_head);
        const Space v664_3 = intersect(constant_8,v664_2);
        const Space v664_4 = (has_head(v664_3) ? constant_9 : Space{});
        const Space v664_5 = subtract(constant_0,v664_4);
        Space v664_7;
        if (!v664_5.empty()) {
          const Space v665_6 = routine_100(c, v662_15_head, v662_15_tail, v656_17_tail);
          v664_7 = compose(v664_5,v665_6);
        }
        const Space v664_8 = intersect(constant_8,v664_2);
        const Space v664_9 = (has_head(v664_8) ? constant_9 : Space{});
        Space v664_11;
        if (!v664_9.empty()) {
          const Space v666_10 = routine_101(c, v662_15_head, v662_15_tail, v656_17_tail);
          v664_11 = compose(v664_9,v666_10);
        }
        const Space v664_12 = unite(v664_7,v664_11);
        v662_15_result = unite(v662_15_result,v664_12);
      }
      const Space v662_15 = std::move(v662_15_result);
      v657_16 = compose(v657_10,v662_15);
    }
    const Space v657_17 = unite(v657_8,v657_16);
    v656_17_result = unite(v656_17_result,v657_17);
  }
  const Space v656_17 = std::move(v656_17_result);
  return v656_17;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v667_21;
  if (!constant_0.empty()) {
    Space v668_20;
    if (!constant_0.empty()) {
      const Space v669_7 = routine_136(c, constant_1, p1, p0, constant_18);
      const Space v669_10 = routine_136(c, constant_3, p1, p0, constant_19);
      const Space v669_11 = unite(v669_7,v669_10);
      const Space v669_14 = routine_137(c, constant_5, p1, p0, constant_20);
      const Space v669_15 = unite(v669_11,v669_14);
      const Space v669_18 = routine_138(c, constant_6, p1, p0, constant_21);
      const Space v669_19 = unite(v669_15,v669_18);
      v668_20 = compose(constant_0,v669_19);
    }
    v667_21 = compose(constant_0,v668_20);
  }
  Space v667_31_result;
  for (int v667_31_label = 1; v667_31_label <= 2; ++v667_31_label) {
    const Space v667_31_tail = child(v667_21,v667_31_label);
    if (v667_31_tail.empty()) continue;
    const Path v667_31_head{v667_31_label};
    const Space v670_2 = singleton(v667_31_head);
    const Space v670_3 = intersect(constant_8,v670_2);
    const Space v670_4 = (has_head(v670_3) ? constant_9 : Space{});
    const Space v670_5 = subtract(constant_0,v670_4);
    Space v670_7;
    if (!v670_5.empty()) {
      Space v671_6_result;
      for (int v671_6_label = 1; v671_6_label <= 2; ++v671_6_label) {
        const Space v671_6_tail = child(v667_31_tail,v671_6_label);
        if (v671_6_tail.empty()) continue;
        const Path v671_6_head{v671_6_label};
        const Space v672_2 = singleton(v671_6_head);
        const Space v672_3 = intersect(constant_8,v672_2);
        const Space v672_4 = (has_head(v672_3) ? constant_9 : Space{});
        const Space v672_5 = subtract(constant_0,v672_4);
        Space v672_8;
        if (!v672_5.empty()) {
          const Path v673_6 = concat_path(v667_31_head,v671_6_head);
          const Space v673_7 = routine_139(c, v673_6, v671_6_tail, s0);
          v672_8 = compose(v672_5,v673_7);
        }
        const Space v672_9 = intersect(constant_8,v672_2);
        const Space v672_10 = (has_head(v672_9) ? constant_9 : Space{});
        Space v672_12;
        if (!v672_10.empty()) {
          const Path v674_6 = concat_path(v667_31_head,v671_6_head);
          const Space v674_11 = routine_140(c, v674_6, v671_6_tail, s0);
          v672_12 = compose(v672_10,v674_11);
        }
        const Space v672_13 = unite(v672_8,v672_12);
        v671_6_result = unite(v671_6_result,v672_13);
      }
      const Space v671_6 = std::move(v671_6_result);
      v670_7 = compose(v670_5,v671_6);
    }
    const Space v670_8 = intersect(constant_8,v670_2);
    const Space v670_9 = (has_head(v670_8) ? constant_9 : Space{});
    Space v670_11;
    if (!v670_9.empty()) {
      Space v675_10_result;
      for (int v675_10_label = 1; v675_10_label <= 2; ++v675_10_label) {
        const Space v675_10_tail = child(v667_31_tail,v675_10_label);
        if (v675_10_tail.empty()) continue;
        const Path v675_10_head{v675_10_label};
        const Space v676_2 = singleton(v675_10_head);
        const Space v676_3 = intersect(constant_8,v676_2);
        const Space v676_4 = (has_head(v676_3) ? constant_9 : Space{});
        const Space v676_5 = subtract(constant_0,v676_4);
        Space v676_8;
        if (!v676_5.empty()) {
          const Path v677_6 = concat_path(v667_31_head,v675_10_head);
          const Space v677_7 = routine_139(c, v677_6, v675_10_tail, s0);
          v676_8 = compose(v676_5,v677_7);
        }
        const Space v676_9 = intersect(constant_8,v676_2);
        const Space v676_10 = (has_head(v676_9) ? constant_9 : Space{});
        Space v676_12;
        if (!v676_10.empty()) {
          const Path v678_6 = concat_path(v667_31_head,v675_10_head);
          const Space v678_11 = routine_141(c, v678_6, v675_10_tail, s0);
          v676_12 = compose(v676_10,v678_11);
        }
        const Space v676_13 = unite(v676_8,v676_12);
        v675_10_result = unite(v675_10_result,v676_13);
      }
      const Space v675_10 = std::move(v675_10_result);
      v670_11 = compose(v670_9,v675_10);
    }
    const Space v670_12 = unite(v670_7,v670_11);
    v667_31_result = unite(v667_31_result,v670_12);
  }
  const Space v667_31 = std::move(v667_31_result);
  return v667_31;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v679_5 = Space{};
  return v679_5;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v680_6 = concat_path(p2,p3);
  Space v680_13_result;
  for (int v680_13_label = 1; v680_13_label <= 2; ++v680_13_label) {
    const Space v680_13_tail = child(s0,v680_13_label);
    if (v680_13_tail.empty()) continue;
    const Path v680_13_head{v680_13_label};
    const Space v681_2 = singleton(v680_13_head);
    const Space v681_3 = intersect(constant_8,v681_2);
    const Space v681_4 = (has_head(v681_3) ? constant_9 : Space{});
    Space v681_11;
    if (!v681_4.empty()) {
      const Path v682_5 = concat_path(p0,v680_13_head);
      const Path v682_6 = concat_path(v680_6,v682_5);
      const Space v682_7 = singleton(v682_6);
      const Space v682_8 = routine_35(c, p1, v682_7);
      Space v682_9_result;
      for (int v682_9_label = 1; v682_9_label <= 2; ++v682_9_label) {
        const Space v682_9_tail = child(v682_8,v682_9_label);
        if (v682_9_tail.empty()) continue;
        const Path v682_9_head{v682_9_label};
        const Space v683_2 = singleton(v682_9_head);
        const Space v683_3 = intersect(constant_8,v683_2);
        const Space v683_4 = (has_head(v683_3) ? constant_9 : Space{});
        const Space v683_5 = subtract(constant_0,v683_4);
        Space v683_7;
        if (!v683_5.empty()) {
          const Space v684_6 = routine_36(c, v682_9_head, p1, v682_9_tail);
          v683_7 = compose(v683_5,v684_6);
        }
        const Space v683_8 = intersect(constant_8,v683_2);
        const Space v683_9 = (has_head(v683_8) ? constant_9 : Space{});
        Space v683_11;
        if (!v683_9.empty()) {
          const Space v685_10 = routine_37(c, v682_9_head, p1, v682_9_tail);
          v683_11 = compose(v683_9,v685_10);
        }
        const Space v683_12 = unite(v683_7,v683_11);
        v682_9_result = unite(v682_9_result,v683_12);
      }
      const Space v682_9 = std::move(v682_9_result);
      Space v682_10_result;
      for (int v682_10_label = 1; v682_10_label <= 2; ++v682_10_label) {
        const Space v682_10_tail = child(v682_9,v682_10_label);
        if (v682_10_tail.empty()) continue;
        const Path v682_10_head{v682_10_label};
        const Space v686_2 = singleton(v682_10_head);
        const Space v686_3 = intersect(constant_8,v686_2);
        const Space v686_4 = (has_head(v686_3) ? constant_9 : Space{});
        const Space v686_5 = subtract(constant_0,v686_4);
        Space v686_7;
        if (!v686_5.empty()) {
          const Space v687_6 = routine_38(c, v682_10_head, p1, v682_10_tail);
          v686_7 = compose(v686_5,v687_6);
        }
        const Space v686_8 = intersect(constant_8,v686_2);
        const Space v686_9 = (has_head(v686_8) ? constant_9 : Space{});
        Space v686_11;
        if (!v686_9.empty()) {
          const Space v688_10 = routine_39(c, v682_10_head, p1, v682_10_tail);
          v686_11 = compose(v686_9,v688_10);
        }
        const Space v686_12 = unite(v686_7,v686_11);
        v682_10_result = unite(v682_10_result,v686_12);
      }
      const Space v682_10 = std::move(v682_10_result);
      v681_11 = compose(v681_4,v682_10);
    }
    v680_13_result = unite(v680_13_result,v681_11);
  }
  const Space v680_13 = std::move(v680_13_result);
  return v680_13;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0) {
  Space v689_11_result;
  for (int v689_11_label = 1; v689_11_label <= 2; ++v689_11_label) {
    const Space v689_11_tail = child(s0,v689_11_label);
    if (v689_11_tail.empty()) continue;
    const Path v689_11_head{v689_11_label};
    const Space v690_2 = singleton(v689_11_head);
    const Space v690_3 = intersect(constant_8,v690_2);
    const Space v690_4 = (has_head(v690_3) ? constant_9 : Space{});
    const Space v690_5 = subtract(constant_0,v690_4);
    Space v690_8;
    if (!v690_5.empty()) {
      const Path v691_6 = concat_path(p0,v689_11_head);
      Space v691_7_result;
      for (int v691_7_label = 1; v691_7_label <= 2; ++v691_7_label) {
        const Space v691_7_tail = child(v689_11_tail,v691_7_label);
        if (v691_7_tail.empty()) continue;
        const Path v691_7_head{v691_7_label};
        const Space v692_2 = singleton(v691_7_head);
        const Space v692_3 = intersect(constant_8,v692_2);
        const Space v692_4 = (has_head(v692_3) ? constant_9 : Space{});
        const Space v692_5 = subtract(constant_0,v692_4);
        Space v692_8;
        if (!v692_5.empty()) {
          const Path v693_6 = concat_path(v691_6,v691_7_head);
          const Space v693_7 = routine_142(c, v693_6, v691_7_tail);
          v692_8 = compose(v692_5,v693_7);
        }
        const Space v692_9 = intersect(constant_8,v692_2);
        const Space v692_10 = (has_head(v692_9) ? constant_9 : Space{});
        Space v692_12;
        if (!v692_10.empty()) {
          const Path v694_6 = concat_path(v691_6,v691_7_head);
          const Space v694_11 = routine_143(c, v694_6, v691_7_tail);
          v692_12 = compose(v692_10,v694_11);
        }
        const Space v692_13 = unite(v692_8,v692_12);
        v691_7_result = unite(v691_7_result,v692_13);
      }
      const Space v691_7 = std::move(v691_7_result);
      v690_8 = compose(v690_5,v691_7);
    }
    const Space v690_9 = intersect(constant_8,v690_2);
    const Space v690_10 = (has_head(v690_9) ? constant_9 : Space{});
    Space v690_12;
    if (!v690_10.empty()) {
      const Path v695_6 = concat_path(p0,v689_11_head);
      Space v695_11_result;
      for (int v695_11_label = 1; v695_11_label <= 2; ++v695_11_label) {
        const Space v695_11_tail = child(v689_11_tail,v695_11_label);
        if (v695_11_tail.empty()) continue;
        const Path v695_11_head{v695_11_label};
        const Space v696_2 = singleton(v695_11_head);
        const Space v696_3 = intersect(constant_8,v696_2);
        const Space v696_4 = (has_head(v696_3) ? constant_9 : Space{});
        const Space v696_5 = subtract(constant_0,v696_4);
        Space v696_8;
        if (!v696_5.empty()) {
          const Path v697_6 = concat_path(v695_6,v695_11_head);
          const Space v697_7 = routine_142(c, v697_6, v695_11_tail);
          v696_8 = compose(v696_5,v697_7);
        }
        const Space v696_9 = intersect(constant_8,v696_2);
        const Space v696_10 = (has_head(v696_9) ? constant_9 : Space{});
        Space v696_12;
        if (!v696_10.empty()) {
          const Path v698_6 = concat_path(v695_6,v695_11_head);
          const Space v698_11 = routine_68(c, v698_6, v695_11_tail);
          v696_12 = compose(v696_10,v698_11);
        }
        const Space v696_13 = unite(v696_8,v696_12);
        v695_11_result = unite(v695_11_result,v696_13);
      }
      const Space v695_11 = std::move(v695_11_result);
      v690_12 = compose(v690_10,v695_11);
    }
    const Space v690_13 = unite(v690_8,v690_12);
    v689_11_result = unite(v689_11_result,v690_13);
  }
  const Space v689_11 = std::move(v689_11_result);
  return v689_11;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v699_8_result;
  for (int v699_8_label = 1; v699_8_label <= 2; ++v699_8_label) {
    const Space v699_8_tail = child(s0,v699_8_label);
    if (v699_8_tail.empty()) continue;
    const Path v699_8_head{v699_8_label};
    const Space v700_2 = singleton(v699_8_head);
    const Space v700_3 = intersect(constant_8,v700_2);
    const Space v700_4 = (has_head(v700_3) ? constant_9 : Space{});
    const Space v700_5 = subtract(constant_0,v700_4);
    Space v700_8;
    if (!v700_5.empty()) {
      const Path v701_6 = concat_path(p0,v699_8_head);
      Space v701_7_result;
      for (int v701_7_label = 1; v701_7_label <= 2; ++v701_7_label) {
        const Space v701_7_tail = child(v699_8_tail,v701_7_label);
        if (v701_7_tail.empty()) continue;
        const Path v701_7_head{v701_7_label};
        const Space v702_2 = singleton(v701_7_head);
        const Space v702_3 = intersect(constant_8,v702_2);
        const Space v702_4 = (has_head(v702_3) ? constant_9 : Space{});
        const Space v702_5 = subtract(constant_0,v702_4);
        Space v702_8;
        if (!v702_5.empty()) {
          const Path v703_6 = concat_path(v701_6,v701_7_head);
          const Space v703_7 = routine_142(c, v703_6, v701_7_tail);
          v702_8 = compose(v702_5,v703_7);
        }
        const Space v702_9 = intersect(constant_8,v702_2);
        const Space v702_10 = (has_head(v702_9) ? constant_9 : Space{});
        Space v702_12;
        if (!v702_10.empty()) {
          const Path v704_6 = concat_path(v701_6,v701_7_head);
          const Space v704_11 = routine_143(c, v704_6, v701_7_tail);
          v702_12 = compose(v702_10,v704_11);
        }
        const Space v702_13 = unite(v702_8,v702_12);
        v701_7_result = unite(v701_7_result,v702_13);
      }
      const Space v701_7 = std::move(v701_7_result);
      v700_8 = compose(v700_5,v701_7);
    }
    const Space v700_9 = intersect(constant_8,v700_2);
    const Space v700_10 = (has_head(v700_9) ? constant_9 : Space{});
    const Space v700_11 = compose(v700_10,v699_8_tail);
    const Space v700_12 = unite(v700_8,v700_11);
    v699_8_result = unite(v699_8_result,v700_12);
  }
  const Space v699_8 = std::move(v699_8_result);
  return v699_8;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  Space v706_11_result;
  for (int v706_11_label = 1; v706_11_label <= 2; ++v706_11_label) {
    const Space v706_11_tail = child(s0,v706_11_label);
    if (v706_11_tail.empty()) continue;
    const Path v706_11_head{v706_11_label};
    const Space v707_2 = singleton(v706_11_head);
    const Space v707_3 = intersect(constant_8,v707_2);
    const Space v707_4 = (has_head(v707_3) ? constant_9 : Space{});
    const Space v707_5 = subtract(constant_0,v707_4);
    Space v707_8;
    if (!v707_5.empty()) {
      const Path v708_6 = concat_path(p0,v706_11_head);
      Space v708_7_result;
      for (int v708_7_label = 1; v708_7_label <= 2; ++v708_7_label) {
        const Space v708_7_tail = child(v706_11_tail,v708_7_label);
        if (v708_7_tail.empty()) continue;
        const Path v708_7_head{v708_7_label};
        const Space v709_2 = singleton(v708_7_head);
        const Space v709_3 = intersect(constant_8,v709_2);
        const Space v709_4 = (has_head(v709_3) ? constant_9 : Space{});
        const Space v709_5 = subtract(constant_0,v709_4);
        Space v709_8;
        if (!v709_5.empty()) {
          const Path v710_6 = concat_path(v708_6,v708_7_head);
          const Space v710_7 = routine_144(c, v710_6, v708_7_tail);
          v709_8 = compose(v709_5,v710_7);
        }
        const Space v709_9 = intersect(constant_8,v709_2);
        const Space v709_10 = (has_head(v709_9) ? constant_9 : Space{});
        Space v709_12;
        if (!v709_10.empty()) {
          const Path v711_6 = concat_path(v708_6,v708_7_head);
          const Space v711_11 = routine_145(c, v711_6, v708_7_tail);
          v709_12 = compose(v709_10,v711_11);
        }
        const Space v709_13 = unite(v709_8,v709_12);
        v708_7_result = unite(v708_7_result,v709_13);
      }
      const Space v708_7 = std::move(v708_7_result);
      v707_8 = compose(v707_5,v708_7);
    }
    const Space v707_9 = intersect(constant_8,v707_2);
    const Space v707_10 = (has_head(v707_9) ? constant_9 : Space{});
    Space v707_12;
    if (!v707_10.empty()) {
      const Path v712_6 = concat_path(p0,v706_11_head);
      Space v712_11_result;
      for (int v712_11_label = 1; v712_11_label <= 2; ++v712_11_label) {
        const Space v712_11_tail = child(v706_11_tail,v712_11_label);
        if (v712_11_tail.empty()) continue;
        const Path v712_11_head{v712_11_label};
        const Space v713_2 = singleton(v712_11_head);
        const Space v713_3 = intersect(constant_8,v713_2);
        const Space v713_4 = (has_head(v713_3) ? constant_9 : Space{});
        const Space v713_5 = subtract(constant_0,v713_4);
        Space v713_8;
        if (!v713_5.empty()) {
          const Path v714_6 = concat_path(v712_6,v712_11_head);
          const Space v714_7 = routine_144(c, v714_6, v712_11_tail);
          v713_8 = compose(v713_5,v714_7);
        }
        const Space v713_9 = intersect(constant_8,v713_2);
        const Space v713_10 = (has_head(v713_9) ? constant_9 : Space{});
        Space v713_12;
        if (!v713_10.empty()) {
          const Path v715_6 = concat_path(v712_6,v712_11_head);
          const Space v715_11 = routine_71(c, v715_6, v712_11_tail);
          v713_12 = compose(v713_10,v715_11);
        }
        const Space v713_13 = unite(v713_8,v713_12);
        v712_11_result = unite(v712_11_result,v713_13);
      }
      const Space v712_11 = std::move(v712_11_result);
      v707_12 = compose(v707_10,v712_11);
    }
    const Space v707_13 = unite(v707_8,v707_12);
    v706_11_result = unite(v706_11_result,v707_13);
  }
  const Space v706_11 = std::move(v706_11_result);
  return v706_11;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v716_11_result;
  for (int v716_11_label = 1; v716_11_label <= 2; ++v716_11_label) {
    const Space v716_11_tail = child(s0,v716_11_label);
    if (v716_11_tail.empty()) continue;
    const Path v716_11_head{v716_11_label};
    const Space v717_2 = singleton(v716_11_head);
    const Space v717_3 = intersect(constant_8,v717_2);
    const Space v717_4 = (has_head(v717_3) ? constant_9 : Space{});
    const Space v717_5 = subtract(constant_0,v717_4);
    Space v717_8;
    if (!v717_5.empty()) {
      const Path v718_6 = concat_path(p0,v716_11_head);
      Space v718_7_result;
      for (int v718_7_label = 1; v718_7_label <= 2; ++v718_7_label) {
        const Space v718_7_tail = child(v716_11_tail,v718_7_label);
        if (v718_7_tail.empty()) continue;
        const Path v718_7_head{v718_7_label};
        const Space v719_2 = singleton(v718_7_head);
        const Space v719_3 = intersect(constant_8,v719_2);
        const Space v719_4 = (has_head(v719_3) ? constant_9 : Space{});
        const Space v719_5 = subtract(constant_0,v719_4);
        Space v719_8;
        if (!v719_5.empty()) {
          const Path v720_6 = concat_path(v718_6,v718_7_head);
          const Space v720_7 = routine_144(c, v720_6, v718_7_tail);
          v719_8 = compose(v719_5,v720_7);
        }
        const Space v719_9 = intersect(constant_8,v719_2);
        const Space v719_10 = (has_head(v719_9) ? constant_9 : Space{});
        Space v719_12;
        if (!v719_10.empty()) {
          const Path v721_6 = concat_path(v718_6,v718_7_head);
          const Space v721_11 = routine_145(c, v721_6, v718_7_tail);
          v719_12 = compose(v719_10,v721_11);
        }
        const Space v719_13 = unite(v719_8,v719_12);
        v718_7_result = unite(v718_7_result,v719_13);
      }
      const Space v718_7 = std::move(v718_7_result);
      v717_8 = compose(v717_5,v718_7);
    }
    const Space v717_9 = intersect(constant_8,v717_2);
    const Space v717_10 = (has_head(v717_9) ? constant_9 : Space{});
    Space v717_12;
    if (!v717_10.empty()) {
      const Path v722_6 = concat_path(p0,v716_11_head);
      Space v722_11_result;
      for (int v722_11_label = 1; v722_11_label <= 2; ++v722_11_label) {
        const Space v722_11_tail = child(v716_11_tail,v722_11_label);
        if (v722_11_tail.empty()) continue;
        const Path v722_11_head{v722_11_label};
        const Space v723_2 = singleton(v722_11_head);
        const Space v723_3 = intersect(constant_8,v723_2);
        const Space v723_4 = (has_head(v723_3) ? constant_9 : Space{});
        const Space v723_5 = subtract(constant_0,v723_4);
        Space v723_7;
        if (!v723_5.empty()) {
          const Space v724_6 = routine_106(c, v722_11_head, v722_6, v722_11_tail);
          v723_7 = compose(v723_5,v724_6);
        }
        const Space v723_8 = intersect(constant_8,v723_2);
        const Space v723_9 = (has_head(v723_8) ? constant_9 : Space{});
        Space v723_11;
        if (!v723_9.empty()) {
          const Space v725_10 = routine_107(c, v722_11_head, v722_6, v722_11_tail);
          v723_11 = compose(v723_9,v725_10);
        }
        const Space v723_12 = unite(v723_7,v723_11);
        v722_11_result = unite(v722_11_result,v723_12);
      }
      const Space v722_11 = std::move(v722_11_result);
      v717_12 = compose(v717_10,v722_11);
    }
    const Space v717_13 = unite(v717_8,v717_12);
    v716_11_result = unite(v716_11_result,v717_13);
  }
  const Space v716_11 = std::move(v716_11_result);
  return v716_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v726_11_result;
  for (int v726_11_label = 1; v726_11_label <= 2; ++v726_11_label) {
    const Space v726_11_tail = child(s0,v726_11_label);
    if (v726_11_tail.empty()) continue;
    const Path v726_11_head{v726_11_label};
    const Space v727_2 = singleton(v726_11_head);
    const Space v727_3 = intersect(constant_8,v727_2);
    const Space v727_4 = (has_head(v727_3) ? constant_9 : Space{});
    const Space v727_5 = subtract(constant_0,v727_4);
    Space v727_7;
    if (!v727_5.empty()) {
      Space v728_6_result;
      for (int v728_6_label = 1; v728_6_label <= 2; ++v728_6_label) {
        const Space v728_6_tail = child(v726_11_tail,v728_6_label);
        if (v728_6_tail.empty()) continue;
        const Path v728_6_head{v728_6_label};
        const Space v729_2 = singleton(v728_6_head);
        const Space v729_3 = intersect(constant_8,v729_2);
        const Space v729_4 = (has_head(v729_3) ? constant_9 : Space{});
        const Space v729_5 = subtract(constant_0,v729_4);
        Space v729_8;
        if (!v729_5.empty()) {
          const Path v730_6 = concat_path(v726_11_head,v728_6_head);
          const Space v730_7 = routine_146(c, v730_6, p0, v728_6_tail);
          v729_8 = compose(v729_5,v730_7);
        }
        const Space v729_9 = intersect(constant_8,v729_2);
        const Space v729_10 = (has_head(v729_9) ? constant_9 : Space{});
        Space v729_12;
        if (!v729_10.empty()) {
          const Path v731_6 = concat_path(v726_11_head,v728_6_head);
          const Space v731_11 = routine_147(c, v731_6, p0, v728_6_tail);
          v729_12 = compose(v729_10,v731_11);
        }
        const Space v729_13 = unite(v729_8,v729_12);
        v728_6_result = unite(v728_6_result,v729_13);
      }
      const Space v728_6 = std::move(v728_6_result);
      v727_7 = compose(v727_5,v728_6);
    }
    const Space v727_8 = intersect(constant_8,v727_2);
    const Space v727_9 = (has_head(v727_8) ? constant_9 : Space{});
    Space v727_11;
    if (!v727_9.empty()) {
      Space v732_10_result;
      for (int v732_10_label = 1; v732_10_label <= 2; ++v732_10_label) {
        const Space v732_10_tail = child(v726_11_tail,v732_10_label);
        if (v732_10_tail.empty()) continue;
        const Path v732_10_head{v732_10_label};
        const Space v733_2 = singleton(v732_10_head);
        const Space v733_3 = intersect(constant_8,v733_2);
        const Space v733_4 = (has_head(v733_3) ? constant_9 : Space{});
        const Space v733_5 = subtract(constant_0,v733_4);
        Space v733_8;
        if (!v733_5.empty()) {
          const Path v734_6 = concat_path(v726_11_head,v732_10_head);
          const Space v734_7 = routine_146(c, v734_6, p0, v732_10_tail);
          v733_8 = compose(v733_5,v734_7);
        }
        const Space v733_9 = intersect(constant_8,v733_2);
        const Space v733_10 = (has_head(v733_9) ? constant_9 : Space{});
        Space v733_12;
        if (!v733_10.empty()) {
          const Path v735_6 = concat_path(v726_11_head,v732_10_head);
          const Space v735_11 = routine_148(c, v735_6, p0, v732_10_tail);
          v733_12 = compose(v733_10,v735_11);
        }
        const Space v733_13 = unite(v733_8,v733_12);
        v732_10_result = unite(v732_10_result,v733_13);
      }
      const Space v732_10 = std::move(v732_10_result);
      v727_11 = compose(v727_9,v732_10);
    }
    const Space v727_12 = unite(v727_7,v727_11);
    v726_11_result = unite(v726_11_result,v727_12);
  }
  const Space v726_11 = std::move(v726_11_result);
  return v726_11;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  Space v736_11_result;
  for (int v736_11_label = 1; v736_11_label <= 2; ++v736_11_label) {
    const Space v736_11_tail = child(s0,v736_11_label);
    if (v736_11_tail.empty()) continue;
    const Path v736_11_head{v736_11_label};
    const Space v737_2 = singleton(v736_11_head);
    const Space v737_3 = intersect(constant_8,v737_2);
    const Space v737_4 = (has_head(v737_3) ? constant_9 : Space{});
    const Space v737_5 = subtract(constant_0,v737_4);
    Space v737_8;
    if (!v737_5.empty()) {
      const Path v738_6 = concat_path(p0,v736_11_head);
      Space v738_7_result;
      for (int v738_7_label = 1; v738_7_label <= 2; ++v738_7_label) {
        const Space v738_7_tail = child(v736_11_tail,v738_7_label);
        if (v738_7_tail.empty()) continue;
        const Path v738_7_head{v738_7_label};
        const Space v739_2 = singleton(v738_7_head);
        const Space v739_3 = intersect(constant_8,v739_2);
        const Space v739_4 = (has_head(v739_3) ? constant_9 : Space{});
        const Space v739_5 = subtract(constant_0,v739_4);
        Space v739_8;
        if (!v739_5.empty()) {
          const Path v740_6 = concat_path(v738_6,v738_7_head);
          const Space v740_7 = routine_149(c, v740_6, v738_7_tail);
          v739_8 = compose(v739_5,v740_7);
        }
        const Space v739_9 = intersect(constant_8,v739_2);
        const Space v739_10 = (has_head(v739_9) ? constant_9 : Space{});
        Space v739_12;
        if (!v739_10.empty()) {
          const Path v741_6 = concat_path(v738_6,v738_7_head);
          const Space v741_11 = routine_150(c, v741_6, v738_7_tail);
          v739_12 = compose(v739_10,v741_11);
        }
        const Space v739_13 = unite(v739_8,v739_12);
        v738_7_result = unite(v738_7_result,v739_13);
      }
      const Space v738_7 = std::move(v738_7_result);
      v737_8 = compose(v737_5,v738_7);
    }
    const Space v737_9 = intersect(constant_8,v737_2);
    const Space v737_10 = (has_head(v737_9) ? constant_9 : Space{});
    Space v737_12;
    if (!v737_10.empty()) {
      const Path v742_6 = concat_path(p0,v736_11_head);
      Space v742_11_result;
      for (int v742_11_label = 1; v742_11_label <= 2; ++v742_11_label) {
        const Space v742_11_tail = child(v736_11_tail,v742_11_label);
        if (v742_11_tail.empty()) continue;
        const Path v742_11_head{v742_11_label};
        const Space v743_2 = singleton(v742_11_head);
        const Space v743_3 = intersect(constant_8,v743_2);
        const Space v743_4 = (has_head(v743_3) ? constant_9 : Space{});
        const Space v743_5 = subtract(constant_0,v743_4);
        Space v743_8;
        if (!v743_5.empty()) {
          const Path v744_6 = concat_path(v742_6,v742_11_head);
          const Space v744_7 = routine_149(c, v744_6, v742_11_tail);
          v743_8 = compose(v743_5,v744_7);
        }
        const Space v743_9 = intersect(constant_8,v743_2);
        const Space v743_10 = (has_head(v743_9) ? constant_9 : Space{});
        Space v743_12;
        if (!v743_10.empty()) {
          const Path v745_6 = concat_path(v742_6,v742_11_head);
          const Space v745_11 = routine_74(c, v745_6, v742_11_tail);
          v743_12 = compose(v743_10,v745_11);
        }
        const Space v743_13 = unite(v743_8,v743_12);
        v742_11_result = unite(v742_11_result,v743_13);
      }
      const Space v742_11 = std::move(v742_11_result);
      v737_12 = compose(v737_10,v742_11);
    }
    const Space v737_13 = unite(v737_8,v737_12);
    v736_11_result = unite(v736_11_result,v737_13);
  }
  const Space v736_11 = std::move(v736_11_result);
  return v736_11;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0) {
  Space v746_8_result;
  for (int v746_8_label = 1; v746_8_label <= 2; ++v746_8_label) {
    const Space v746_8_tail = child(s0,v746_8_label);
    if (v746_8_tail.empty()) continue;
    const Path v746_8_head{v746_8_label};
    const Space v747_2 = singleton(v746_8_head);
    const Space v747_3 = intersect(constant_8,v747_2);
    const Space v747_4 = (has_head(v747_3) ? constant_9 : Space{});
    const Space v747_5 = subtract(constant_0,v747_4);
    Space v747_8;
    if (!v747_5.empty()) {
      const Path v748_6 = concat_path(p0,v746_8_head);
      Space v748_7_result;
      for (int v748_7_label = 1; v748_7_label <= 2; ++v748_7_label) {
        const Space v748_7_tail = child(v746_8_tail,v748_7_label);
        if (v748_7_tail.empty()) continue;
        const Path v748_7_head{v748_7_label};
        const Space v749_2 = singleton(v748_7_head);
        const Space v749_3 = intersect(constant_8,v749_2);
        const Space v749_4 = (has_head(v749_3) ? constant_9 : Space{});
        const Space v749_5 = subtract(constant_0,v749_4);
        Space v749_8;
        if (!v749_5.empty()) {
          const Path v750_6 = concat_path(v748_6,v748_7_head);
          const Space v750_7 = routine_149(c, v750_6, v748_7_tail);
          v749_8 = compose(v749_5,v750_7);
        }
        const Space v749_9 = intersect(constant_8,v749_2);
        const Space v749_10 = (has_head(v749_9) ? constant_9 : Space{});
        Space v749_12;
        if (!v749_10.empty()) {
          const Path v751_6 = concat_path(v748_6,v748_7_head);
          const Space v751_11 = routine_150(c, v751_6, v748_7_tail);
          v749_12 = compose(v749_10,v751_11);
        }
        const Space v749_13 = unite(v749_8,v749_12);
        v748_7_result = unite(v748_7_result,v749_13);
      }
      const Space v748_7 = std::move(v748_7_result);
      v747_8 = compose(v747_5,v748_7);
    }
    const Space v747_9 = intersect(constant_8,v747_2);
    const Space v747_10 = (has_head(v747_9) ? constant_9 : Space{});
    const Space v747_11 = compose(v747_10,v746_8_tail);
    const Space v747_12 = unite(v747_8,v747_11);
    v746_8_result = unite(v746_8_result,v747_12);
  }
  const Space v746_8 = std::move(v746_8_result);
  return v746_8;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  Space v753_11_result;
  for (int v753_11_label = 1; v753_11_label <= 2; ++v753_11_label) {
    const Space v753_11_tail = child(s0,v753_11_label);
    if (v753_11_tail.empty()) continue;
    const Path v753_11_head{v753_11_label};
    const Space v754_2 = singleton(v753_11_head);
    const Space v754_3 = intersect(constant_8,v754_2);
    const Space v754_4 = (has_head(v754_3) ? constant_9 : Space{});
    const Space v754_5 = subtract(constant_0,v754_4);
    Space v754_8;
    if (!v754_5.empty()) {
      const Path v755_6 = concat_path(p0,v753_11_head);
      Space v755_7_result;
      for (int v755_7_label = 1; v755_7_label <= 2; ++v755_7_label) {
        const Space v755_7_tail = child(v753_11_tail,v755_7_label);
        if (v755_7_tail.empty()) continue;
        const Path v755_7_head{v755_7_label};
        const Space v756_2 = singleton(v755_7_head);
        const Space v756_3 = intersect(constant_8,v756_2);
        const Space v756_4 = (has_head(v756_3) ? constant_9 : Space{});
        const Space v756_5 = subtract(constant_0,v756_4);
        Space v756_8;
        if (!v756_5.empty()) {
          const Path v757_6 = concat_path(v755_6,v755_7_head);
          const Space v757_7 = routine_151(c, v757_6, v755_7_tail);
          v756_8 = compose(v756_5,v757_7);
        }
        const Space v756_9 = intersect(constant_8,v756_2);
        const Space v756_10 = (has_head(v756_9) ? constant_9 : Space{});
        Space v756_12;
        if (!v756_10.empty()) {
          const Path v758_6 = concat_path(v755_6,v755_7_head);
          const Space v758_11 = routine_152(c, v758_6, v755_7_tail);
          v756_12 = compose(v756_10,v758_11);
        }
        const Space v756_13 = unite(v756_8,v756_12);
        v755_7_result = unite(v755_7_result,v756_13);
      }
      const Space v755_7 = std::move(v755_7_result);
      v754_8 = compose(v754_5,v755_7);
    }
    const Space v754_9 = intersect(constant_8,v754_2);
    const Space v754_10 = (has_head(v754_9) ? constant_9 : Space{});
    Space v754_12;
    if (!v754_10.empty()) {
      const Path v759_6 = concat_path(p0,v753_11_head);
      Space v759_11_result;
      for (int v759_11_label = 1; v759_11_label <= 2; ++v759_11_label) {
        const Space v759_11_tail = child(v753_11_tail,v759_11_label);
        if (v759_11_tail.empty()) continue;
        const Path v759_11_head{v759_11_label};
        const Space v760_2 = singleton(v759_11_head);
        const Space v760_3 = intersect(constant_8,v760_2);
        const Space v760_4 = (has_head(v760_3) ? constant_9 : Space{});
        const Space v760_5 = subtract(constant_0,v760_4);
        Space v760_8;
        if (!v760_5.empty()) {
          const Path v761_6 = concat_path(v759_6,v759_11_head);
          const Space v761_7 = routine_151(c, v761_6, v759_11_tail);
          v760_8 = compose(v760_5,v761_7);
        }
        const Space v760_9 = intersect(constant_8,v760_2);
        const Space v760_10 = (has_head(v760_9) ? constant_9 : Space{});
        Space v760_12;
        if (!v760_10.empty()) {
          const Path v762_6 = concat_path(v759_6,v759_11_head);
          const Space v762_11 = routine_77(c, v762_6, v759_11_tail);
          v760_12 = compose(v760_10,v762_11);
        }
        const Space v760_13 = unite(v760_8,v760_12);
        v759_11_result = unite(v759_11_result,v760_13);
      }
      const Space v759_11 = std::move(v759_11_result);
      v754_12 = compose(v754_10,v759_11);
    }
    const Space v754_13 = unite(v754_8,v754_12);
    v753_11_result = unite(v753_11_result,v754_13);
  }
  const Space v753_11 = std::move(v753_11_result);
  return v753_11;
}

static Space routine_76(Context& c, const Path& p0, const Space& s0) {
  Space v763_11_result;
  for (int v763_11_label = 1; v763_11_label <= 2; ++v763_11_label) {
    const Space v763_11_tail = child(s0,v763_11_label);
    if (v763_11_tail.empty()) continue;
    const Path v763_11_head{v763_11_label};
    const Space v764_2 = singleton(v763_11_head);
    const Space v764_3 = intersect(constant_8,v764_2);
    const Space v764_4 = (has_head(v764_3) ? constant_9 : Space{});
    const Space v764_5 = subtract(constant_0,v764_4);
    Space v764_8;
    if (!v764_5.empty()) {
      const Path v765_6 = concat_path(p0,v763_11_head);
      Space v765_7_result;
      for (int v765_7_label = 1; v765_7_label <= 2; ++v765_7_label) {
        const Space v765_7_tail = child(v763_11_tail,v765_7_label);
        if (v765_7_tail.empty()) continue;
        const Path v765_7_head{v765_7_label};
        const Space v766_2 = singleton(v765_7_head);
        const Space v766_3 = intersect(constant_8,v766_2);
        const Space v766_4 = (has_head(v766_3) ? constant_9 : Space{});
        const Space v766_5 = subtract(constant_0,v766_4);
        Space v766_8;
        if (!v766_5.empty()) {
          const Path v767_6 = concat_path(v765_6,v765_7_head);
          const Space v767_7 = routine_151(c, v767_6, v765_7_tail);
          v766_8 = compose(v766_5,v767_7);
        }
        const Space v766_9 = intersect(constant_8,v766_2);
        const Space v766_10 = (has_head(v766_9) ? constant_9 : Space{});
        Space v766_12;
        if (!v766_10.empty()) {
          const Path v768_6 = concat_path(v765_6,v765_7_head);
          const Space v768_11 = routine_152(c, v768_6, v765_7_tail);
          v766_12 = compose(v766_10,v768_11);
        }
        const Space v766_13 = unite(v766_8,v766_12);
        v765_7_result = unite(v765_7_result,v766_13);
      }
      const Space v765_7 = std::move(v765_7_result);
      v764_8 = compose(v764_5,v765_7);
    }
    const Space v764_9 = intersect(constant_8,v764_2);
    const Space v764_10 = (has_head(v764_9) ? constant_9 : Space{});
    Space v764_12;
    if (!v764_10.empty()) {
      const Path v769_6 = concat_path(p0,v763_11_head);
      Space v769_11_result;
      for (int v769_11_label = 1; v769_11_label <= 2; ++v769_11_label) {
        const Space v769_11_tail = child(v763_11_tail,v769_11_label);
        if (v769_11_tail.empty()) continue;
        const Path v769_11_head{v769_11_label};
        const Space v770_2 = singleton(v769_11_head);
        const Space v770_3 = intersect(constant_8,v770_2);
        const Space v770_4 = (has_head(v770_3) ? constant_9 : Space{});
        const Space v770_5 = subtract(constant_0,v770_4);
        Space v770_7;
        if (!v770_5.empty()) {
          const Space v771_6 = routine_112(c, v769_11_head, v769_6, v769_11_tail);
          v770_7 = compose(v770_5,v771_6);
        }
        const Space v770_8 = intersect(constant_8,v770_2);
        const Space v770_9 = (has_head(v770_8) ? constant_9 : Space{});
        Space v770_11;
        if (!v770_9.empty()) {
          const Space v772_10 = routine_113(c, v769_11_head, v769_6, v769_11_tail);
          v770_11 = compose(v770_9,v772_10);
        }
        const Space v770_12 = unite(v770_7,v770_11);
        v769_11_result = unite(v769_11_result,v770_12);
      }
      const Space v769_11 = std::move(v769_11_result);
      v764_12 = compose(v764_10,v769_11);
    }
    const Space v764_13 = unite(v764_8,v764_12);
    v763_11_result = unite(v763_11_result,v764_13);
  }
  const Space v763_11 = std::move(v763_11_result);
  return v763_11;
}

static Space routine_77(Context& c, const Path& p0, const Space& s0) {
  Space v773_11_result;
  for (int v773_11_label = 1; v773_11_label <= 2; ++v773_11_label) {
    const Space v773_11_tail = child(s0,v773_11_label);
    if (v773_11_tail.empty()) continue;
    const Path v773_11_head{v773_11_label};
    const Space v774_2 = singleton(v773_11_head);
    const Space v774_3 = intersect(constant_8,v774_2);
    const Space v774_4 = (has_head(v774_3) ? constant_9 : Space{});
    const Space v774_5 = subtract(constant_0,v774_4);
    Space v774_7;
    if (!v774_5.empty()) {
      Space v775_6_result;
      for (int v775_6_label = 1; v775_6_label <= 2; ++v775_6_label) {
        const Space v775_6_tail = child(v773_11_tail,v775_6_label);
        if (v775_6_tail.empty()) continue;
        const Path v775_6_head{v775_6_label};
        const Space v776_2 = singleton(v775_6_head);
        const Space v776_3 = intersect(constant_8,v776_2);
        const Space v776_4 = (has_head(v776_3) ? constant_9 : Space{});
        const Space v776_5 = subtract(constant_0,v776_4);
        Space v776_8;
        if (!v776_5.empty()) {
          const Path v777_6 = concat_path(v773_11_head,v775_6_head);
          const Space v777_7 = routine_153(c, v777_6, p0, v775_6_tail);
          v776_8 = compose(v776_5,v777_7);
        }
        const Space v776_9 = intersect(constant_8,v776_2);
        const Space v776_10 = (has_head(v776_9) ? constant_9 : Space{});
        Space v776_12;
        if (!v776_10.empty()) {
          const Path v778_6 = concat_path(v773_11_head,v775_6_head);
          const Space v778_11 = routine_154(c, v778_6, p0, v775_6_tail);
          v776_12 = compose(v776_10,v778_11);
        }
        const Space v776_13 = unite(v776_8,v776_12);
        v775_6_result = unite(v775_6_result,v776_13);
      }
      const Space v775_6 = std::move(v775_6_result);
      v774_7 = compose(v774_5,v775_6);
    }
    const Space v774_8 = intersect(constant_8,v774_2);
    const Space v774_9 = (has_head(v774_8) ? constant_9 : Space{});
    Space v774_11;
    if (!v774_9.empty()) {
      Space v779_10_result;
      for (int v779_10_label = 1; v779_10_label <= 2; ++v779_10_label) {
        const Space v779_10_tail = child(v773_11_tail,v779_10_label);
        if (v779_10_tail.empty()) continue;
        const Path v779_10_head{v779_10_label};
        const Space v780_2 = singleton(v779_10_head);
        const Space v780_3 = intersect(constant_8,v780_2);
        const Space v780_4 = (has_head(v780_3) ? constant_9 : Space{});
        const Space v780_5 = subtract(constant_0,v780_4);
        Space v780_8;
        if (!v780_5.empty()) {
          const Path v781_6 = concat_path(v773_11_head,v779_10_head);
          const Space v781_7 = routine_153(c, v781_6, p0, v779_10_tail);
          v780_8 = compose(v780_5,v781_7);
        }
        const Space v780_9 = intersect(constant_8,v780_2);
        const Space v780_10 = (has_head(v780_9) ? constant_9 : Space{});
        Space v780_12;
        if (!v780_10.empty()) {
          const Path v782_6 = concat_path(v773_11_head,v779_10_head);
          const Space v782_11 = routine_155(c, v782_6, p0, v779_10_tail);
          v780_12 = compose(v780_10,v782_11);
        }
        const Space v780_13 = unite(v780_8,v780_12);
        v779_10_result = unite(v779_10_result,v780_13);
      }
      const Space v779_10 = std::move(v779_10_result);
      v774_11 = compose(v774_9,v779_10);
    }
    const Space v774_12 = unite(v774_7,v774_11);
    v773_11_result = unite(v773_11_result,v774_12);
  }
  const Space v773_11 = std::move(v773_11_result);
  return v773_11;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v783_11_result;
  for (int v783_11_label = 1; v783_11_label <= 2; ++v783_11_label) {
    const Space v783_11_tail = child(s0,v783_11_label);
    if (v783_11_tail.empty()) continue;
    const Path v783_11_head{v783_11_label};
    const Space v784_2 = singleton(v783_11_head);
    const Space v784_3 = intersect(constant_8,v784_2);
    const Space v784_4 = (has_head(v784_3) ? constant_9 : Space{});
    const Space v784_5 = subtract(constant_0,v784_4);
    Space v784_8;
    if (!v784_5.empty()) {
      const Path v785_6 = concat_path(p0,v783_11_head);
      Space v785_7_result;
      for (int v785_7_label = 1; v785_7_label <= 2; ++v785_7_label) {
        const Space v785_7_tail = child(v783_11_tail,v785_7_label);
        if (v785_7_tail.empty()) continue;
        const Path v785_7_head{v785_7_label};
        const Space v786_2 = singleton(v785_7_head);
        const Space v786_3 = intersect(constant_8,v786_2);
        const Space v786_4 = (has_head(v786_3) ? constant_9 : Space{});
        const Space v786_5 = subtract(constant_0,v786_4);
        Space v786_8;
        if (!v786_5.empty()) {
          const Path v787_6 = concat_path(v785_6,v785_7_head);
          const Space v787_7 = routine_156(c, v787_6, v785_7_tail);
          v786_8 = compose(v786_5,v787_7);
        }
        const Space v786_9 = intersect(constant_8,v786_2);
        const Space v786_10 = (has_head(v786_9) ? constant_9 : Space{});
        Space v786_12;
        if (!v786_10.empty()) {
          const Path v788_6 = concat_path(v785_6,v785_7_head);
          const Space v788_11 = routine_157(c, v788_6, v785_7_tail);
          v786_12 = compose(v786_10,v788_11);
        }
        const Space v786_13 = unite(v786_8,v786_12);
        v785_7_result = unite(v785_7_result,v786_13);
      }
      const Space v785_7 = std::move(v785_7_result);
      v784_8 = compose(v784_5,v785_7);
    }
    const Space v784_9 = intersect(constant_8,v784_2);
    const Space v784_10 = (has_head(v784_9) ? constant_9 : Space{});
    Space v784_12;
    if (!v784_10.empty()) {
      const Path v789_6 = concat_path(p0,v783_11_head);
      Space v789_11_result;
      for (int v789_11_label = 1; v789_11_label <= 2; ++v789_11_label) {
        const Space v789_11_tail = child(v783_11_tail,v789_11_label);
        if (v789_11_tail.empty()) continue;
        const Path v789_11_head{v789_11_label};
        const Space v790_2 = singleton(v789_11_head);
        const Space v790_3 = intersect(constant_8,v790_2);
        const Space v790_4 = (has_head(v790_3) ? constant_9 : Space{});
        const Space v790_5 = subtract(constant_0,v790_4);
        Space v790_8;
        if (!v790_5.empty()) {
          const Path v791_6 = concat_path(v789_6,v789_11_head);
          const Space v791_7 = routine_156(c, v791_6, v789_11_tail);
          v790_8 = compose(v790_5,v791_7);
        }
        const Space v790_9 = intersect(constant_8,v790_2);
        const Space v790_10 = (has_head(v790_9) ? constant_9 : Space{});
        Space v790_12;
        if (!v790_10.empty()) {
          const Path v792_6 = concat_path(v789_6,v789_11_head);
          const Space v792_11 = routine_80(c, v792_6, v789_11_tail);
          v790_12 = compose(v790_10,v792_11);
        }
        const Space v790_13 = unite(v790_8,v790_12);
        v789_11_result = unite(v789_11_result,v790_13);
      }
      const Space v789_11 = std::move(v789_11_result);
      v784_12 = compose(v784_10,v789_11);
    }
    const Space v784_13 = unite(v784_8,v784_12);
    v783_11_result = unite(v783_11_result,v784_13);
  }
  const Space v783_11 = std::move(v783_11_result);
  return v783_11;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  Space v793_8_result;
  for (int v793_8_label = 1; v793_8_label <= 2; ++v793_8_label) {
    const Space v793_8_tail = child(s0,v793_8_label);
    if (v793_8_tail.empty()) continue;
    const Path v793_8_head{v793_8_label};
    const Space v794_2 = singleton(v793_8_head);
    const Space v794_3 = intersect(constant_8,v794_2);
    const Space v794_4 = (has_head(v794_3) ? constant_9 : Space{});
    const Space v794_5 = subtract(constant_0,v794_4);
    Space v794_8;
    if (!v794_5.empty()) {
      const Path v795_6 = concat_path(p0,v793_8_head);
      Space v795_7_result;
      for (int v795_7_label = 1; v795_7_label <= 2; ++v795_7_label) {
        const Space v795_7_tail = child(v793_8_tail,v795_7_label);
        if (v795_7_tail.empty()) continue;
        const Path v795_7_head{v795_7_label};
        const Space v796_2 = singleton(v795_7_head);
        const Space v796_3 = intersect(constant_8,v796_2);
        const Space v796_4 = (has_head(v796_3) ? constant_9 : Space{});
        const Space v796_5 = subtract(constant_0,v796_4);
        Space v796_8;
        if (!v796_5.empty()) {
          const Path v797_6 = concat_path(v795_6,v795_7_head);
          const Space v797_7 = routine_156(c, v797_6, v795_7_tail);
          v796_8 = compose(v796_5,v797_7);
        }
        const Space v796_9 = intersect(constant_8,v796_2);
        const Space v796_10 = (has_head(v796_9) ? constant_9 : Space{});
        Space v796_12;
        if (!v796_10.empty()) {
          const Path v798_6 = concat_path(v795_6,v795_7_head);
          const Space v798_11 = routine_157(c, v798_6, v795_7_tail);
          v796_12 = compose(v796_10,v798_11);
        }
        const Space v796_13 = unite(v796_8,v796_12);
        v795_7_result = unite(v795_7_result,v796_13);
      }
      const Space v795_7 = std::move(v795_7_result);
      v794_8 = compose(v794_5,v795_7);
    }
    const Space v794_9 = intersect(constant_8,v794_2);
    const Space v794_10 = (has_head(v794_9) ? constant_9 : Space{});
    const Space v794_11 = compose(v794_10,v793_8_tail);
    const Space v794_12 = unite(v794_8,v794_11);
    v793_8_result = unite(v793_8_result,v794_12);
  }
  const Space v793_8 = std::move(v793_8_result);
  return v793_8;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_81(Context& c, const Path& p0, const Space& s0) {
  Space v800_11_result;
  for (int v800_11_label = 1; v800_11_label <= 2; ++v800_11_label) {
    const Space v800_11_tail = child(s0,v800_11_label);
    if (v800_11_tail.empty()) continue;
    const Path v800_11_head{v800_11_label};
    const Space v801_2 = singleton(v800_11_head);
    const Space v801_3 = intersect(constant_8,v801_2);
    const Space v801_4 = (has_head(v801_3) ? constant_9 : Space{});
    const Space v801_5 = subtract(constant_0,v801_4);
    Space v801_8;
    if (!v801_5.empty()) {
      const Path v802_6 = concat_path(p0,v800_11_head);
      Space v802_7_result;
      for (int v802_7_label = 1; v802_7_label <= 2; ++v802_7_label) {
        const Space v802_7_tail = child(v800_11_tail,v802_7_label);
        if (v802_7_tail.empty()) continue;
        const Path v802_7_head{v802_7_label};
        const Space v803_2 = singleton(v802_7_head);
        const Space v803_3 = intersect(constant_8,v803_2);
        const Space v803_4 = (has_head(v803_3) ? constant_9 : Space{});
        const Space v803_5 = subtract(constant_0,v803_4);
        Space v803_8;
        if (!v803_5.empty()) {
          const Path v804_6 = concat_path(v802_6,v802_7_head);
          const Space v804_7 = routine_158(c, v804_6, v802_7_tail);
          v803_8 = compose(v803_5,v804_7);
        }
        const Space v803_9 = intersect(constant_8,v803_2);
        const Space v803_10 = (has_head(v803_9) ? constant_9 : Space{});
        Space v803_12;
        if (!v803_10.empty()) {
          const Path v805_6 = concat_path(v802_6,v802_7_head);
          const Space v805_11 = routine_159(c, v805_6, v802_7_tail);
          v803_12 = compose(v803_10,v805_11);
        }
        const Space v803_13 = unite(v803_8,v803_12);
        v802_7_result = unite(v802_7_result,v803_13);
      }
      const Space v802_7 = std::move(v802_7_result);
      v801_8 = compose(v801_5,v802_7);
    }
    const Space v801_9 = intersect(constant_8,v801_2);
    const Space v801_10 = (has_head(v801_9) ? constant_9 : Space{});
    Space v801_12;
    if (!v801_10.empty()) {
      const Path v806_6 = concat_path(p0,v800_11_head);
      Space v806_11_result;
      for (int v806_11_label = 1; v806_11_label <= 2; ++v806_11_label) {
        const Space v806_11_tail = child(v800_11_tail,v806_11_label);
        if (v806_11_tail.empty()) continue;
        const Path v806_11_head{v806_11_label};
        const Space v807_2 = singleton(v806_11_head);
        const Space v807_3 = intersect(constant_8,v807_2);
        const Space v807_4 = (has_head(v807_3) ? constant_9 : Space{});
        const Space v807_5 = subtract(constant_0,v807_4);
        Space v807_8;
        if (!v807_5.empty()) {
          const Path v808_6 = concat_path(v806_6,v806_11_head);
          const Space v808_7 = routine_158(c, v808_6, v806_11_tail);
          v807_8 = compose(v807_5,v808_7);
        }
        const Space v807_9 = intersect(constant_8,v807_2);
        const Space v807_10 = (has_head(v807_9) ? constant_9 : Space{});
        Space v807_12;
        if (!v807_10.empty()) {
          const Path v809_6 = concat_path(v806_6,v806_11_head);
          const Space v809_11 = routine_83(c, v809_6, v806_11_tail);
          v807_12 = compose(v807_10,v809_11);
        }
        const Space v807_13 = unite(v807_8,v807_12);
        v806_11_result = unite(v806_11_result,v807_13);
      }
      const Space v806_11 = std::move(v806_11_result);
      v801_12 = compose(v801_10,v806_11);
    }
    const Space v801_13 = unite(v801_8,v801_12);
    v800_11_result = unite(v800_11_result,v801_13);
  }
  const Space v800_11 = std::move(v800_11_result);
  return v800_11;
}

static Space routine_82(Context& c, const Path& p0, const Space& s0) {
  Space v810_11_result;
  for (int v810_11_label = 1; v810_11_label <= 2; ++v810_11_label) {
    const Space v810_11_tail = child(s0,v810_11_label);
    if (v810_11_tail.empty()) continue;
    const Path v810_11_head{v810_11_label};
    const Space v811_2 = singleton(v810_11_head);
    const Space v811_3 = intersect(constant_8,v811_2);
    const Space v811_4 = (has_head(v811_3) ? constant_9 : Space{});
    const Space v811_5 = subtract(constant_0,v811_4);
    Space v811_8;
    if (!v811_5.empty()) {
      const Path v812_6 = concat_path(p0,v810_11_head);
      Space v812_7_result;
      for (int v812_7_label = 1; v812_7_label <= 2; ++v812_7_label) {
        const Space v812_7_tail = child(v810_11_tail,v812_7_label);
        if (v812_7_tail.empty()) continue;
        const Path v812_7_head{v812_7_label};
        const Space v813_2 = singleton(v812_7_head);
        const Space v813_3 = intersect(constant_8,v813_2);
        const Space v813_4 = (has_head(v813_3) ? constant_9 : Space{});
        const Space v813_5 = subtract(constant_0,v813_4);
        Space v813_8;
        if (!v813_5.empty()) {
          const Path v814_6 = concat_path(v812_6,v812_7_head);
          const Space v814_7 = routine_158(c, v814_6, v812_7_tail);
          v813_8 = compose(v813_5,v814_7);
        }
        const Space v813_9 = intersect(constant_8,v813_2);
        const Space v813_10 = (has_head(v813_9) ? constant_9 : Space{});
        Space v813_12;
        if (!v813_10.empty()) {
          const Path v815_6 = concat_path(v812_6,v812_7_head);
          const Space v815_11 = routine_159(c, v815_6, v812_7_tail);
          v813_12 = compose(v813_10,v815_11);
        }
        const Space v813_13 = unite(v813_8,v813_12);
        v812_7_result = unite(v812_7_result,v813_13);
      }
      const Space v812_7 = std::move(v812_7_result);
      v811_8 = compose(v811_5,v812_7);
    }
    const Space v811_9 = intersect(constant_8,v811_2);
    const Space v811_10 = (has_head(v811_9) ? constant_9 : Space{});
    Space v811_12;
    if (!v811_10.empty()) {
      const Path v816_6 = concat_path(p0,v810_11_head);
      Space v816_11_result;
      for (int v816_11_label = 1; v816_11_label <= 2; ++v816_11_label) {
        const Space v816_11_tail = child(v810_11_tail,v816_11_label);
        if (v816_11_tail.empty()) continue;
        const Path v816_11_head{v816_11_label};
        const Space v817_2 = singleton(v816_11_head);
        const Space v817_3 = intersect(constant_8,v817_2);
        const Space v817_4 = (has_head(v817_3) ? constant_9 : Space{});
        const Space v817_5 = subtract(constant_0,v817_4);
        Space v817_7;
        if (!v817_5.empty()) {
          const Space v818_6 = routine_118(c, v816_11_head, v816_6, v816_11_tail);
          v817_7 = compose(v817_5,v818_6);
        }
        const Space v817_8 = intersect(constant_8,v817_2);
        const Space v817_9 = (has_head(v817_8) ? constant_9 : Space{});
        Space v817_11;
        if (!v817_9.empty()) {
          const Space v819_10 = routine_119(c, v816_11_head, v816_6, v816_11_tail);
          v817_11 = compose(v817_9,v819_10);
        }
        const Space v817_12 = unite(v817_7,v817_11);
        v816_11_result = unite(v816_11_result,v817_12);
      }
      const Space v816_11 = std::move(v816_11_result);
      v811_12 = compose(v811_10,v816_11);
    }
    const Space v811_13 = unite(v811_8,v811_12);
    v810_11_result = unite(v810_11_result,v811_13);
  }
  const Space v810_11 = std::move(v810_11_result);
  return v810_11;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v820_11_result;
  for (int v820_11_label = 1; v820_11_label <= 2; ++v820_11_label) {
    const Space v820_11_tail = child(s0,v820_11_label);
    if (v820_11_tail.empty()) continue;
    const Path v820_11_head{v820_11_label};
    const Space v821_2 = singleton(v820_11_head);
    const Space v821_3 = intersect(constant_8,v821_2);
    const Space v821_4 = (has_head(v821_3) ? constant_9 : Space{});
    const Space v821_5 = subtract(constant_0,v821_4);
    Space v821_7;
    if (!v821_5.empty()) {
      Space v822_6_result;
      for (int v822_6_label = 1; v822_6_label <= 2; ++v822_6_label) {
        const Space v822_6_tail = child(v820_11_tail,v822_6_label);
        if (v822_6_tail.empty()) continue;
        const Path v822_6_head{v822_6_label};
        const Space v823_2 = singleton(v822_6_head);
        const Space v823_3 = intersect(constant_8,v823_2);
        const Space v823_4 = (has_head(v823_3) ? constant_9 : Space{});
        const Space v823_5 = subtract(constant_0,v823_4);
        Space v823_8;
        if (!v823_5.empty()) {
          const Path v824_6 = concat_path(v820_11_head,v822_6_head);
          const Space v824_7 = routine_160(c, v824_6, p0, v822_6_tail);
          v823_8 = compose(v823_5,v824_7);
        }
        const Space v823_9 = intersect(constant_8,v823_2);
        const Space v823_10 = (has_head(v823_9) ? constant_9 : Space{});
        Space v823_12;
        if (!v823_10.empty()) {
          const Path v825_6 = concat_path(v820_11_head,v822_6_head);
          const Space v825_11 = routine_161(c, v825_6, p0, v822_6_tail);
          v823_12 = compose(v823_10,v825_11);
        }
        const Space v823_13 = unite(v823_8,v823_12);
        v822_6_result = unite(v822_6_result,v823_13);
      }
      const Space v822_6 = std::move(v822_6_result);
      v821_7 = compose(v821_5,v822_6);
    }
    const Space v821_8 = intersect(constant_8,v821_2);
    const Space v821_9 = (has_head(v821_8) ? constant_9 : Space{});
    Space v821_11;
    if (!v821_9.empty()) {
      Space v826_10_result;
      for (int v826_10_label = 1; v826_10_label <= 2; ++v826_10_label) {
        const Space v826_10_tail = child(v820_11_tail,v826_10_label);
        if (v826_10_tail.empty()) continue;
        const Path v826_10_head{v826_10_label};
        const Space v827_2 = singleton(v826_10_head);
        const Space v827_3 = intersect(constant_8,v827_2);
        const Space v827_4 = (has_head(v827_3) ? constant_9 : Space{});
        const Space v827_5 = subtract(constant_0,v827_4);
        Space v827_8;
        if (!v827_5.empty()) {
          const Path v828_6 = concat_path(v820_11_head,v826_10_head);
          const Space v828_7 = routine_160(c, v828_6, p0, v826_10_tail);
          v827_8 = compose(v827_5,v828_7);
        }
        const Space v827_9 = intersect(constant_8,v827_2);
        const Space v827_10 = (has_head(v827_9) ? constant_9 : Space{});
        Space v827_12;
        if (!v827_10.empty()) {
          const Path v829_6 = concat_path(v820_11_head,v826_10_head);
          const Space v829_11 = routine_162(c, v829_6, p0, v826_10_tail);
          v827_12 = compose(v827_10,v829_11);
        }
        const Space v827_13 = unite(v827_8,v827_12);
        v826_10_result = unite(v826_10_result,v827_13);
      }
      const Space v826_10 = std::move(v826_10_result);
      v821_11 = compose(v821_9,v826_10);
    }
    const Space v821_12 = unite(v821_7,v821_11);
    v820_11_result = unite(v820_11_result,v821_12);
  }
  const Space v820_11 = std::move(v820_11_result);
  return v820_11;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0) {
  Space v830_11_result;
  for (int v830_11_label = 1; v830_11_label <= 2; ++v830_11_label) {
    const Space v830_11_tail = child(s0,v830_11_label);
    if (v830_11_tail.empty()) continue;
    const Path v830_11_head{v830_11_label};
    const Space v831_2 = singleton(v830_11_head);
    const Space v831_3 = intersect(constant_8,v831_2);
    const Space v831_4 = (has_head(v831_3) ? constant_9 : Space{});
    const Space v831_5 = subtract(constant_0,v831_4);
    Space v831_8;
    if (!v831_5.empty()) {
      const Path v832_6 = concat_path(p0,v830_11_head);
      Space v832_7_result;
      for (int v832_7_label = 1; v832_7_label <= 2; ++v832_7_label) {
        const Space v832_7_tail = child(v830_11_tail,v832_7_label);
        if (v832_7_tail.empty()) continue;
        const Path v832_7_head{v832_7_label};
        const Space v833_2 = singleton(v832_7_head);
        const Space v833_3 = intersect(constant_8,v833_2);
        const Space v833_4 = (has_head(v833_3) ? constant_9 : Space{});
        const Space v833_5 = subtract(constant_0,v833_4);
        Space v833_8;
        if (!v833_5.empty()) {
          const Path v834_6 = concat_path(v832_6,v832_7_head);
          const Space v834_7 = routine_163(c, v834_6, v832_7_tail);
          v833_8 = compose(v833_5,v834_7);
        }
        const Space v833_9 = intersect(constant_8,v833_2);
        const Space v833_10 = (has_head(v833_9) ? constant_9 : Space{});
        Space v833_12;
        if (!v833_10.empty()) {
          const Path v835_6 = concat_path(v832_6,v832_7_head);
          const Space v835_11 = routine_164(c, v835_6, v832_7_tail);
          v833_12 = compose(v833_10,v835_11);
        }
        const Space v833_13 = unite(v833_8,v833_12);
        v832_7_result = unite(v832_7_result,v833_13);
      }
      const Space v832_7 = std::move(v832_7_result);
      v831_8 = compose(v831_5,v832_7);
    }
    const Space v831_9 = intersect(constant_8,v831_2);
    const Space v831_10 = (has_head(v831_9) ? constant_9 : Space{});
    Space v831_12;
    if (!v831_10.empty()) {
      const Path v836_6 = concat_path(p0,v830_11_head);
      Space v836_11_result;
      for (int v836_11_label = 1; v836_11_label <= 2; ++v836_11_label) {
        const Space v836_11_tail = child(v830_11_tail,v836_11_label);
        if (v836_11_tail.empty()) continue;
        const Path v836_11_head{v836_11_label};
        const Space v837_2 = singleton(v836_11_head);
        const Space v837_3 = intersect(constant_8,v837_2);
        const Space v837_4 = (has_head(v837_3) ? constant_9 : Space{});
        const Space v837_5 = subtract(constant_0,v837_4);
        Space v837_8;
        if (!v837_5.empty()) {
          const Path v838_6 = concat_path(v836_6,v836_11_head);
          const Space v838_7 = routine_163(c, v838_6, v836_11_tail);
          v837_8 = compose(v837_5,v838_7);
        }
        const Space v837_9 = intersect(constant_8,v837_2);
        const Space v837_10 = (has_head(v837_9) ? constant_9 : Space{});
        Space v837_12;
        if (!v837_10.empty()) {
          const Path v839_6 = concat_path(v836_6,v836_11_head);
          const Space v839_11 = routine_86(c, v839_6, v836_11_tail);
          v837_12 = compose(v837_10,v839_11);
        }
        const Space v837_13 = unite(v837_8,v837_12);
        v836_11_result = unite(v836_11_result,v837_13);
      }
      const Space v836_11 = std::move(v836_11_result);
      v831_12 = compose(v831_10,v836_11);
    }
    const Space v831_13 = unite(v831_8,v831_12);
    v830_11_result = unite(v830_11_result,v831_13);
  }
  const Space v830_11 = std::move(v830_11_result);
  return v830_11;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0) {
  Space v840_8_result;
  for (int v840_8_label = 1; v840_8_label <= 2; ++v840_8_label) {
    const Space v840_8_tail = child(s0,v840_8_label);
    if (v840_8_tail.empty()) continue;
    const Path v840_8_head{v840_8_label};
    const Space v841_2 = singleton(v840_8_head);
    const Space v841_3 = intersect(constant_8,v841_2);
    const Space v841_4 = (has_head(v841_3) ? constant_9 : Space{});
    const Space v841_5 = subtract(constant_0,v841_4);
    Space v841_8;
    if (!v841_5.empty()) {
      const Path v842_6 = concat_path(p0,v840_8_head);
      Space v842_7_result;
      for (int v842_7_label = 1; v842_7_label <= 2; ++v842_7_label) {
        const Space v842_7_tail = child(v840_8_tail,v842_7_label);
        if (v842_7_tail.empty()) continue;
        const Path v842_7_head{v842_7_label};
        const Space v843_2 = singleton(v842_7_head);
        const Space v843_3 = intersect(constant_8,v843_2);
        const Space v843_4 = (has_head(v843_3) ? constant_9 : Space{});
        const Space v843_5 = subtract(constant_0,v843_4);
        Space v843_8;
        if (!v843_5.empty()) {
          const Path v844_6 = concat_path(v842_6,v842_7_head);
          const Space v844_7 = routine_163(c, v844_6, v842_7_tail);
          v843_8 = compose(v843_5,v844_7);
        }
        const Space v843_9 = intersect(constant_8,v843_2);
        const Space v843_10 = (has_head(v843_9) ? constant_9 : Space{});
        Space v843_12;
        if (!v843_10.empty()) {
          const Path v845_6 = concat_path(v842_6,v842_7_head);
          const Space v845_11 = routine_164(c, v845_6, v842_7_tail);
          v843_12 = compose(v843_10,v845_11);
        }
        const Space v843_13 = unite(v843_8,v843_12);
        v842_7_result = unite(v842_7_result,v843_13);
      }
      const Space v842_7 = std::move(v842_7_result);
      v841_8 = compose(v841_5,v842_7);
    }
    const Space v841_9 = intersect(constant_8,v841_2);
    const Space v841_10 = (has_head(v841_9) ? constant_9 : Space{});
    const Space v841_11 = compose(v841_10,v840_8_tail);
    const Space v841_12 = unite(v841_8,v841_11);
    v840_8_result = unite(v840_8_result,v841_12);
  }
  const Space v840_8 = std::move(v840_8_result);
  return v840_8;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_87(Context& c, const Path& p0, const Space& s0) {
  Space v847_11_result;
  for (int v847_11_label = 1; v847_11_label <= 2; ++v847_11_label) {
    const Space v847_11_tail = child(s0,v847_11_label);
    if (v847_11_tail.empty()) continue;
    const Path v847_11_head{v847_11_label};
    const Space v848_2 = singleton(v847_11_head);
    const Space v848_3 = intersect(constant_8,v848_2);
    const Space v848_4 = (has_head(v848_3) ? constant_9 : Space{});
    const Space v848_5 = subtract(constant_0,v848_4);
    Space v848_8;
    if (!v848_5.empty()) {
      const Path v849_6 = concat_path(p0,v847_11_head);
      Space v849_7_result;
      for (int v849_7_label = 1; v849_7_label <= 2; ++v849_7_label) {
        const Space v849_7_tail = child(v847_11_tail,v849_7_label);
        if (v849_7_tail.empty()) continue;
        const Path v849_7_head{v849_7_label};
        const Space v850_2 = singleton(v849_7_head);
        const Space v850_3 = intersect(constant_8,v850_2);
        const Space v850_4 = (has_head(v850_3) ? constant_9 : Space{});
        const Space v850_5 = subtract(constant_0,v850_4);
        Space v850_8;
        if (!v850_5.empty()) {
          const Path v851_6 = concat_path(v849_6,v849_7_head);
          const Space v851_7 = routine_165(c, v851_6, v849_7_tail);
          v850_8 = compose(v850_5,v851_7);
        }
        const Space v850_9 = intersect(constant_8,v850_2);
        const Space v850_10 = (has_head(v850_9) ? constant_9 : Space{});
        Space v850_12;
        if (!v850_10.empty()) {
          const Path v852_6 = concat_path(v849_6,v849_7_head);
          const Space v852_11 = routine_166(c, v852_6, v849_7_tail);
          v850_12 = compose(v850_10,v852_11);
        }
        const Space v850_13 = unite(v850_8,v850_12);
        v849_7_result = unite(v849_7_result,v850_13);
      }
      const Space v849_7 = std::move(v849_7_result);
      v848_8 = compose(v848_5,v849_7);
    }
    const Space v848_9 = intersect(constant_8,v848_2);
    const Space v848_10 = (has_head(v848_9) ? constant_9 : Space{});
    Space v848_12;
    if (!v848_10.empty()) {
      const Path v853_6 = concat_path(p0,v847_11_head);
      Space v853_11_result;
      for (int v853_11_label = 1; v853_11_label <= 2; ++v853_11_label) {
        const Space v853_11_tail = child(v847_11_tail,v853_11_label);
        if (v853_11_tail.empty()) continue;
        const Path v853_11_head{v853_11_label};
        const Space v854_2 = singleton(v853_11_head);
        const Space v854_3 = intersect(constant_8,v854_2);
        const Space v854_4 = (has_head(v854_3) ? constant_9 : Space{});
        const Space v854_5 = subtract(constant_0,v854_4);
        Space v854_8;
        if (!v854_5.empty()) {
          const Path v855_6 = concat_path(v853_6,v853_11_head);
          const Space v855_7 = routine_165(c, v855_6, v853_11_tail);
          v854_8 = compose(v854_5,v855_7);
        }
        const Space v854_9 = intersect(constant_8,v854_2);
        const Space v854_10 = (has_head(v854_9) ? constant_9 : Space{});
        Space v854_12;
        if (!v854_10.empty()) {
          const Path v856_6 = concat_path(v853_6,v853_11_head);
          const Space v856_11 = routine_89(c, v856_6, v853_11_tail);
          v854_12 = compose(v854_10,v856_11);
        }
        const Space v854_13 = unite(v854_8,v854_12);
        v853_11_result = unite(v853_11_result,v854_13);
      }
      const Space v853_11 = std::move(v853_11_result);
      v848_12 = compose(v848_10,v853_11);
    }
    const Space v848_13 = unite(v848_8,v848_12);
    v847_11_result = unite(v847_11_result,v848_13);
  }
  const Space v847_11 = std::move(v847_11_result);
  return v847_11;
}

static Space routine_88(Context& c, const Path& p0, const Space& s0) {
  Space v857_11_result;
  for (int v857_11_label = 1; v857_11_label <= 2; ++v857_11_label) {
    const Space v857_11_tail = child(s0,v857_11_label);
    if (v857_11_tail.empty()) continue;
    const Path v857_11_head{v857_11_label};
    const Space v858_2 = singleton(v857_11_head);
    const Space v858_3 = intersect(constant_8,v858_2);
    const Space v858_4 = (has_head(v858_3) ? constant_9 : Space{});
    const Space v858_5 = subtract(constant_0,v858_4);
    Space v858_8;
    if (!v858_5.empty()) {
      const Path v859_6 = concat_path(p0,v857_11_head);
      Space v859_7_result;
      for (int v859_7_label = 1; v859_7_label <= 2; ++v859_7_label) {
        const Space v859_7_tail = child(v857_11_tail,v859_7_label);
        if (v859_7_tail.empty()) continue;
        const Path v859_7_head{v859_7_label};
        const Space v860_2 = singleton(v859_7_head);
        const Space v860_3 = intersect(constant_8,v860_2);
        const Space v860_4 = (has_head(v860_3) ? constant_9 : Space{});
        const Space v860_5 = subtract(constant_0,v860_4);
        Space v860_8;
        if (!v860_5.empty()) {
          const Path v861_6 = concat_path(v859_6,v859_7_head);
          const Space v861_7 = routine_165(c, v861_6, v859_7_tail);
          v860_8 = compose(v860_5,v861_7);
        }
        const Space v860_9 = intersect(constant_8,v860_2);
        const Space v860_10 = (has_head(v860_9) ? constant_9 : Space{});
        Space v860_12;
        if (!v860_10.empty()) {
          const Path v862_6 = concat_path(v859_6,v859_7_head);
          const Space v862_11 = routine_166(c, v862_6, v859_7_tail);
          v860_12 = compose(v860_10,v862_11);
        }
        const Space v860_13 = unite(v860_8,v860_12);
        v859_7_result = unite(v859_7_result,v860_13);
      }
      const Space v859_7 = std::move(v859_7_result);
      v858_8 = compose(v858_5,v859_7);
    }
    const Space v858_9 = intersect(constant_8,v858_2);
    const Space v858_10 = (has_head(v858_9) ? constant_9 : Space{});
    Space v858_12;
    if (!v858_10.empty()) {
      const Path v863_6 = concat_path(p0,v857_11_head);
      Space v863_11_result;
      for (int v863_11_label = 1; v863_11_label <= 2; ++v863_11_label) {
        const Space v863_11_tail = child(v857_11_tail,v863_11_label);
        if (v863_11_tail.empty()) continue;
        const Path v863_11_head{v863_11_label};
        const Space v864_2 = singleton(v863_11_head);
        const Space v864_3 = intersect(constant_8,v864_2);
        const Space v864_4 = (has_head(v864_3) ? constant_9 : Space{});
        const Space v864_5 = subtract(constant_0,v864_4);
        Space v864_7;
        if (!v864_5.empty()) {
          const Space v865_6 = routine_124(c, v863_11_head, v863_6, v863_11_tail);
          v864_7 = compose(v864_5,v865_6);
        }
        const Space v864_8 = intersect(constant_8,v864_2);
        const Space v864_9 = (has_head(v864_8) ? constant_9 : Space{});
        Space v864_11;
        if (!v864_9.empty()) {
          const Space v866_10 = routine_125(c, v863_11_head, v863_6, v863_11_tail);
          v864_11 = compose(v864_9,v866_10);
        }
        const Space v864_12 = unite(v864_7,v864_11);
        v863_11_result = unite(v863_11_result,v864_12);
      }
      const Space v863_11 = std::move(v863_11_result);
      v858_12 = compose(v858_10,v863_11);
    }
    const Space v858_13 = unite(v858_8,v858_12);
    v857_11_result = unite(v857_11_result,v858_13);
  }
  const Space v857_11 = std::move(v857_11_result);
  return v857_11;
}

static Space routine_89(Context& c, const Path& p0, const Space& s0) {
  Space v867_11_result;
  for (int v867_11_label = 1; v867_11_label <= 2; ++v867_11_label) {
    const Space v867_11_tail = child(s0,v867_11_label);
    if (v867_11_tail.empty()) continue;
    const Path v867_11_head{v867_11_label};
    const Space v868_2 = singleton(v867_11_head);
    const Space v868_3 = intersect(constant_8,v868_2);
    const Space v868_4 = (has_head(v868_3) ? constant_9 : Space{});
    const Space v868_5 = subtract(constant_0,v868_4);
    Space v868_7;
    if (!v868_5.empty()) {
      Space v869_6_result;
      for (int v869_6_label = 1; v869_6_label <= 2; ++v869_6_label) {
        const Space v869_6_tail = child(v867_11_tail,v869_6_label);
        if (v869_6_tail.empty()) continue;
        const Path v869_6_head{v869_6_label};
        const Space v870_2 = singleton(v869_6_head);
        const Space v870_3 = intersect(constant_8,v870_2);
        const Space v870_4 = (has_head(v870_3) ? constant_9 : Space{});
        const Space v870_5 = subtract(constant_0,v870_4);
        Space v870_8;
        if (!v870_5.empty()) {
          const Path v871_6 = concat_path(v867_11_head,v869_6_head);
          const Space v871_7 = routine_167(c, v871_6, p0, v869_6_tail);
          v870_8 = compose(v870_5,v871_7);
        }
        const Space v870_9 = intersect(constant_8,v870_2);
        const Space v870_10 = (has_head(v870_9) ? constant_9 : Space{});
        Space v870_12;
        if (!v870_10.empty()) {
          const Path v872_6 = concat_path(v867_11_head,v869_6_head);
          const Space v872_11 = routine_168(c, v872_6, p0, v869_6_tail);
          v870_12 = compose(v870_10,v872_11);
        }
        const Space v870_13 = unite(v870_8,v870_12);
        v869_6_result = unite(v869_6_result,v870_13);
      }
      const Space v869_6 = std::move(v869_6_result);
      v868_7 = compose(v868_5,v869_6);
    }
    const Space v868_8 = intersect(constant_8,v868_2);
    const Space v868_9 = (has_head(v868_8) ? constant_9 : Space{});
    Space v868_11;
    if (!v868_9.empty()) {
      Space v873_10_result;
      for (int v873_10_label = 1; v873_10_label <= 2; ++v873_10_label) {
        const Space v873_10_tail = child(v867_11_tail,v873_10_label);
        if (v873_10_tail.empty()) continue;
        const Path v873_10_head{v873_10_label};
        const Space v874_2 = singleton(v873_10_head);
        const Space v874_3 = intersect(constant_8,v874_2);
        const Space v874_4 = (has_head(v874_3) ? constant_9 : Space{});
        const Space v874_5 = subtract(constant_0,v874_4);
        Space v874_8;
        if (!v874_5.empty()) {
          const Path v875_6 = concat_path(v867_11_head,v873_10_head);
          const Space v875_7 = routine_167(c, v875_6, p0, v873_10_tail);
          v874_8 = compose(v874_5,v875_7);
        }
        const Space v874_9 = intersect(constant_8,v874_2);
        const Space v874_10 = (has_head(v874_9) ? constant_9 : Space{});
        Space v874_12;
        if (!v874_10.empty()) {
          const Path v876_6 = concat_path(v867_11_head,v873_10_head);
          const Space v876_11 = routine_169(c, v876_6, p0, v873_10_tail);
          v874_12 = compose(v874_10,v876_11);
        }
        const Space v874_13 = unite(v874_8,v874_12);
        v873_10_result = unite(v873_10_result,v874_13);
      }
      const Space v873_10 = std::move(v873_10_result);
      v868_11 = compose(v868_9,v873_10);
    }
    const Space v868_12 = unite(v868_7,v868_11);
    v867_11_result = unite(v867_11_result,v868_12);
  }
  const Space v867_11 = std::move(v867_11_result);
  return v867_11;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v877_12_result;
  for (int v877_12_label = 1; v877_12_label <= 2; ++v877_12_label) {
    const Space v877_12_tail = child(s0,v877_12_label);
    if (v877_12_tail.empty()) continue;
    const Path v877_12_head{v877_12_label};
    const Space v878_2 = singleton(v877_12_head);
    const Space v878_3 = intersect(constant_8,v878_2);
    const Space v878_4 = (has_head(v878_3) ? constant_9 : Space{});
    const Space v878_5 = subtract(constant_0,v878_4);
    Space v878_8;
    if (!v878_5.empty()) {
      const Path v879_6 = concat_path(p0,v877_12_head);
      Space v879_7_result;
      for (int v879_7_label = 1; v879_7_label <= 2; ++v879_7_label) {
        const Space v879_7_tail = child(v877_12_tail,v879_7_label);
        if (v879_7_tail.empty()) continue;
        const Path v879_7_head{v879_7_label};
        const Space v880_2 = singleton(v879_7_head);
        const Space v880_3 = intersect(constant_8,v880_2);
        const Space v880_4 = (has_head(v880_3) ? constant_9 : Space{});
        const Space v880_5 = subtract(constant_0,v880_4);
        Space v880_8;
        if (!v880_5.empty()) {
          const Path v881_6 = concat_path(v879_6,v879_7_head);
          const Space v881_7 = routine_170(c, v881_6, p1, v879_7_tail);
          v880_8 = compose(v880_5,v881_7);
        }
        const Space v880_9 = intersect(constant_8,v880_2);
        const Space v880_10 = (has_head(v880_9) ? constant_9 : Space{});
        Space v880_12;
        if (!v880_10.empty()) {
          const Path v882_6 = concat_path(v879_6,v879_7_head);
          const Space v882_11 = routine_171(c, v882_6, p1, v879_7_tail);
          v880_12 = compose(v880_10,v882_11);
        }
        const Space v880_13 = unite(v880_8,v880_12);
        v879_7_result = unite(v879_7_result,v880_13);
      }
      const Space v879_7 = std::move(v879_7_result);
      v878_8 = compose(v878_5,v879_7);
    }
    const Space v878_9 = intersect(constant_8,v878_2);
    const Space v878_10 = (has_head(v878_9) ? constant_9 : Space{});
    Space v878_12;
    if (!v878_10.empty()) {
      const Path v883_6 = concat_path(p0,v877_12_head);
      Space v883_11_result;
      for (int v883_11_label = 1; v883_11_label <= 2; ++v883_11_label) {
        const Space v883_11_tail = child(v877_12_tail,v883_11_label);
        if (v883_11_tail.empty()) continue;
        const Path v883_11_head{v883_11_label};
        const Space v884_2 = singleton(v883_11_head);
        const Space v884_3 = intersect(constant_8,v884_2);
        const Space v884_4 = (has_head(v884_3) ? constant_9 : Space{});
        const Space v884_5 = subtract(constant_0,v884_4);
        Space v884_8;
        if (!v884_5.empty()) {
          const Path v885_6 = concat_path(v883_6,v883_11_head);
          const Space v885_7 = routine_170(c, v885_6, p1, v883_11_tail);
          v884_8 = compose(v884_5,v885_7);
        }
        const Space v884_9 = intersect(constant_8,v884_2);
        const Space v884_10 = (has_head(v884_9) ? constant_9 : Space{});
        Space v884_12;
        if (!v884_10.empty()) {
          const Path v886_6 = concat_path(v883_6,v883_11_head);
          const Space v886_11 = routine_60(c, v886_6, p1, v883_11_tail);
          v884_12 = compose(v884_10,v886_11);
        }
        const Space v884_13 = unite(v884_8,v884_12);
        v883_11_result = unite(v883_11_result,v884_13);
      }
      const Space v883_11 = std::move(v883_11_result);
      v878_12 = compose(v878_10,v883_11);
    }
    const Space v878_13 = unite(v878_8,v878_12);
    v877_12_result = unite(v877_12_result,v878_13);
  }
  const Space v877_12 = std::move(v877_12_result);
  return v877_12;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v887_17_result;
  for (int v887_17_label = 1; v887_17_label <= 2; ++v887_17_label) {
    const Space v887_17_tail = child(s0,v887_17_label);
    if (v887_17_tail.empty()) continue;
    const Path v887_17_head{v887_17_label};
    const Space v888_2 = singleton(v887_17_head);
    const Space v888_3 = intersect(constant_8,v888_2);
    const Space v888_4 = (has_head(v888_3) ? constant_9 : Space{});
    const Space v888_5 = subtract(constant_0,v888_4);
    Space v888_8;
    if (!v888_5.empty()) {
      const Path v889_6 = concat_path(p0,v887_17_head);
      Space v889_7_result;
      for (int v889_7_label = 1; v889_7_label <= 2; ++v889_7_label) {
        const Space v889_7_tail = child(v887_17_tail,v889_7_label);
        if (v889_7_tail.empty()) continue;
        const Path v889_7_head{v889_7_label};
        const Space v890_2 = singleton(v889_7_head);
        const Space v890_3 = intersect(constant_8,v890_2);
        const Space v890_4 = (has_head(v890_3) ? constant_9 : Space{});
        const Space v890_5 = subtract(constant_0,v890_4);
        Space v890_8;
        if (!v890_5.empty()) {
          const Path v891_6 = concat_path(v889_6,v889_7_head);
          const Space v891_7 = routine_170(c, v891_6, p1, v889_7_tail);
          v890_8 = compose(v890_5,v891_7);
        }
        const Space v890_9 = intersect(constant_8,v890_2);
        const Space v890_10 = (has_head(v890_9) ? constant_9 : Space{});
        Space v890_12;
        if (!v890_10.empty()) {
          const Path v892_6 = concat_path(v889_6,v889_7_head);
          const Space v892_11 = routine_171(c, v892_6, p1, v889_7_tail);
          v890_12 = compose(v890_10,v892_11);
        }
        const Space v890_13 = unite(v890_8,v890_12);
        v889_7_result = unite(v889_7_result,v890_13);
      }
      const Space v889_7 = std::move(v889_7_result);
      v888_8 = compose(v888_5,v889_7);
    }
    const Space v888_9 = intersect(constant_8,v888_2);
    const Space v888_10 = (has_head(v888_9) ? constant_9 : Space{});
    Space v888_16;
    if (!v888_10.empty()) {
      const Path v893_6 = concat_path(p0,v887_17_head);
      Space v893_14;
      if (!constant_0.empty()) {
        const Space v894_11 = routine_92(c, constant_14, p1, constant_15);
        const Space v894_12 = routine_93(c, constant_16, p1, constant_17);
        const Space v894_13 = unite(v894_11,v894_12);
        v893_14 = compose(constant_0,v894_13);
      }
      Space v893_15_result;
      for (int v893_15_label = 1; v893_15_label <= 2; ++v893_15_label) {
        const Space v893_15_tail = child(v893_14,v893_15_label);
        if (v893_15_tail.empty()) continue;
        const Path v893_15_head{v893_15_label};
        const Space v895_2 = singleton(v893_15_head);
        const Space v895_3 = intersect(constant_8,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_9 : Space{});
        const Space v895_5 = subtract(constant_0,v895_4);
        Space v895_7;
        if (!v895_5.empty()) {
          const Space v896_6 = routine_94(c, v893_15_head, v893_6, v893_15_tail, v887_17_tail);
          v895_7 = compose(v895_5,v896_6);
        }
        const Space v895_8 = intersect(constant_8,v895_2);
        const Space v895_9 = (has_head(v895_8) ? constant_9 : Space{});
        Space v895_11;
        if (!v895_9.empty()) {
          const Space v897_10 = routine_95(c, v893_15_head, v893_6, v893_15_tail, v887_17_tail);
          v895_11 = compose(v895_9,v897_10);
        }
        const Space v895_12 = unite(v895_7,v895_11);
        v893_15_result = unite(v893_15_result,v895_12);
      }
      const Space v893_15 = std::move(v893_15_result);
      v888_16 = compose(v888_10,v893_15);
    }
    const Space v888_17 = unite(v888_8,v888_16);
    v887_17_result = unite(v887_17_result,v888_17);
  }
  const Space v887_17 = std::move(v887_17_result);
  return v887_17;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v898_12_result;
  for (int v898_12_label = 1; v898_12_label <= 2; ++v898_12_label) {
    const Space v898_12_tail = child(s0,v898_12_label);
    if (v898_12_tail.empty()) continue;
    const Path v898_12_head{v898_12_label};
    const Space v899_2 = singleton(v898_12_head);
    const Space v899_3 = intersect(constant_8,v899_2);
    const Space v899_4 = (has_head(v899_3) ? constant_9 : Space{});
    const Space v899_5 = subtract(constant_0,v899_4);
    Space v899_8;
    if (!v899_5.empty()) {
      const Path v900_6 = concat_path(p0,v898_12_head);
      Space v900_7_result;
      for (int v900_7_label = 1; v900_7_label <= 2; ++v900_7_label) {
        const Space v900_7_tail = child(v898_12_tail,v900_7_label);
        if (v900_7_tail.empty()) continue;
        const Path v900_7_head{v900_7_label};
        const Space v901_2 = singleton(v900_7_head);
        const Space v901_3 = intersect(constant_8,v901_2);
        const Space v901_4 = (has_head(v901_3) ? constant_9 : Space{});
        const Space v901_5 = subtract(constant_0,v901_4);
        Space v901_8;
        if (!v901_5.empty()) {
          const Path v902_6 = concat_path(v900_6,v900_7_head);
          const Space v902_7 = routine_172(c, v902_6, p1, v900_7_tail);
          v901_8 = compose(v901_5,v902_7);
        }
        const Space v901_9 = intersect(constant_8,v901_2);
        const Space v901_10 = (has_head(v901_9) ? constant_9 : Space{});
        Space v901_12;
        if (!v901_10.empty()) {
          const Path v903_6 = concat_path(v900_6,v900_7_head);
          const Space v903_11 = routine_173(c, v903_6, p1, v900_7_tail);
          v901_12 = compose(v901_10,v903_11);
        }
        const Space v901_13 = unite(v901_8,v901_12);
        v900_7_result = unite(v900_7_result,v901_13);
      }
      const Space v900_7 = std::move(v900_7_result);
      v899_8 = compose(v899_5,v900_7);
    }
    const Space v899_9 = intersect(constant_8,v899_2);
    const Space v899_10 = (has_head(v899_9) ? constant_9 : Space{});
    Space v899_12;
    if (!v899_10.empty()) {
      const Path v904_6 = concat_path(p0,v898_12_head);
      Space v904_11_result;
      for (int v904_11_label = 1; v904_11_label <= 2; ++v904_11_label) {
        const Space v904_11_tail = child(v898_12_tail,v904_11_label);
        if (v904_11_tail.empty()) continue;
        const Path v904_11_head{v904_11_label};
        const Space v905_2 = singleton(v904_11_head);
        const Space v905_3 = intersect(constant_8,v905_2);
        const Space v905_4 = (has_head(v905_3) ? constant_9 : Space{});
        const Space v905_5 = subtract(constant_0,v905_4);
        Space v905_8;
        if (!v905_5.empty()) {
          const Path v906_6 = concat_path(v904_6,v904_11_head);
          const Space v906_7 = routine_172(c, v906_6, p1, v904_11_tail);
          v905_8 = compose(v905_5,v906_7);
        }
        const Space v905_9 = intersect(constant_8,v905_2);
        const Space v905_10 = (has_head(v905_9) ? constant_9 : Space{});
        Space v905_12;
        if (!v905_10.empty()) {
          const Path v907_6 = concat_path(v904_6,v904_11_head);
          const Space v907_11 = routine_130(c, v907_6, p1, v904_11_tail);
          v905_12 = compose(v905_10,v907_11);
        }
        const Space v905_13 = unite(v905_8,v905_12);
        v904_11_result = unite(v904_11_result,v905_13);
      }
      const Space v904_11 = std::move(v904_11_result);
      v899_12 = compose(v899_10,v904_11);
    }
    const Space v899_13 = unite(v899_8,v899_12);
    v898_12_result = unite(v898_12_result,v899_13);
  }
  const Space v898_12 = std::move(v898_12_result);
  return v898_12;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v908_12_result;
  for (int v908_12_label = 1; v908_12_label <= 2; ++v908_12_label) {
    const Space v908_12_tail = child(s0,v908_12_label);
    if (v908_12_tail.empty()) continue;
    const Path v908_12_head{v908_12_label};
    const Space v909_2 = singleton(v908_12_head);
    const Space v909_3 = intersect(constant_8,v909_2);
    const Space v909_4 = (has_head(v909_3) ? constant_9 : Space{});
    const Space v909_5 = subtract(constant_0,v909_4);
    Space v909_8;
    if (!v909_5.empty()) {
      const Path v910_6 = concat_path(p0,v908_12_head);
      Space v910_7_result;
      for (int v910_7_label = 1; v910_7_label <= 2; ++v910_7_label) {
        const Space v910_7_tail = child(v908_12_tail,v910_7_label);
        if (v910_7_tail.empty()) continue;
        const Path v910_7_head{v910_7_label};
        const Space v911_2 = singleton(v910_7_head);
        const Space v911_3 = intersect(constant_8,v911_2);
        const Space v911_4 = (has_head(v911_3) ? constant_9 : Space{});
        const Space v911_5 = subtract(constant_0,v911_4);
        Space v911_8;
        if (!v911_5.empty()) {
          const Path v912_6 = concat_path(v910_6,v910_7_head);
          const Space v912_7 = routine_172(c, v912_6, p1, v910_7_tail);
          v911_8 = compose(v911_5,v912_7);
        }
        const Space v911_9 = intersect(constant_8,v911_2);
        const Space v911_10 = (has_head(v911_9) ? constant_9 : Space{});
        Space v911_12;
        if (!v911_10.empty()) {
          const Path v913_6 = concat_path(v910_6,v910_7_head);
          const Space v913_11 = routine_173(c, v913_6, p1, v910_7_tail);
          v911_12 = compose(v911_10,v913_11);
        }
        const Space v911_13 = unite(v911_8,v911_12);
        v910_7_result = unite(v910_7_result,v911_13);
      }
      const Space v910_7 = std::move(v910_7_result);
      v909_8 = compose(v909_5,v910_7);
    }
    const Space v909_9 = intersect(constant_8,v909_2);
    const Space v909_10 = (has_head(v909_9) ? constant_9 : Space{});
    Space v909_12;
    if (!v909_10.empty()) {
      const Path v914_6 = concat_path(p0,v908_12_head);
      Space v914_11_result;
      for (int v914_11_label = 1; v914_11_label <= 2; ++v914_11_label) {
        const Space v914_11_tail = child(v908_12_tail,v914_11_label);
        if (v914_11_tail.empty()) continue;
        const Path v914_11_head{v914_11_label};
        const Space v915_2 = singleton(v914_11_head);
        const Space v915_3 = intersect(constant_8,v915_2);
        const Space v915_4 = (has_head(v915_3) ? constant_9 : Space{});
        const Space v915_5 = subtract(constant_0,v915_4);
        Space v915_7;
        if (!v915_5.empty()) {
          const Space v916_6 = routine_174(c, v914_11_head, p1, v914_6, v914_11_tail);
          v915_7 = compose(v915_5,v916_6);
        }
        const Space v915_8 = intersect(constant_8,v915_2);
        const Space v915_9 = (has_head(v915_8) ? constant_9 : Space{});
        Space v915_11;
        if (!v915_9.empty()) {
          const Space v917_10 = routine_175(c, v914_11_head, p1, v914_6, v914_11_tail);
          v915_11 = compose(v915_9,v917_10);
        }
        const Space v915_12 = unite(v915_7,v915_11);
        v914_11_result = unite(v914_11_result,v915_12);
      }
      const Space v914_11 = std::move(v914_11_result);
      v909_12 = compose(v909_10,v914_11);
    }
    const Space v909_13 = unite(v909_8,v909_12);
    v908_12_result = unite(v908_12_result,v909_13);
  }
  const Space v908_12 = std::move(v908_12_result);
  return v908_12;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v918_13_result;
  for (int v918_13_label = 1; v918_13_label <= 2; ++v918_13_label) {
    const Space v918_13_tail = child(s0,v918_13_label);
    if (v918_13_tail.empty()) continue;
    const Path v918_13_head{v918_13_label};
    const Space v919_2 = singleton(v918_13_head);
    const Space v919_3 = intersect(constant_8,v919_2);
    const Space v919_4 = (has_head(v919_3) ? constant_9 : Space{});
    const Space v919_5 = subtract(constant_0,v919_4);
    Space v919_8;
    if (!v919_5.empty()) {
      const Path v920_6 = concat_path(p0,v918_13_head);
      Space v920_7_result;
      for (int v920_7_label = 1; v920_7_label <= 2; ++v920_7_label) {
        const Space v920_7_tail = child(v918_13_tail,v920_7_label);
        if (v920_7_tail.empty()) continue;
        const Path v920_7_head{v920_7_label};
        const Space v921_2 = singleton(v920_7_head);
        const Space v921_3 = intersect(constant_8,v921_2);
        const Space v921_4 = (has_head(v921_3) ? constant_9 : Space{});
        const Space v921_5 = subtract(constant_0,v921_4);
        Space v921_8;
        if (!v921_5.empty()) {
          const Path v922_6 = concat_path(v920_6,v920_7_head);
          const Space v922_7 = routine_176(c, v922_6, p1, v920_7_tail, s1);
          v921_8 = compose(v921_5,v922_7);
        }
        const Space v921_9 = intersect(constant_8,v921_2);
        const Space v921_10 = (has_head(v921_9) ? constant_9 : Space{});
        Space v921_12;
        if (!v921_10.empty()) {
          const Path v923_6 = concat_path(v920_6,v920_7_head);
          const Space v923_11 = routine_177(c, v923_6, p1, v920_7_tail, s1);
          v921_12 = compose(v921_10,v923_11);
        }
        const Space v921_13 = unite(v921_8,v921_12);
        v920_7_result = unite(v920_7_result,v921_13);
      }
      const Space v920_7 = std::move(v920_7_result);
      v919_8 = compose(v919_5,v920_7);
    }
    const Space v919_9 = intersect(constant_8,v919_2);
    const Space v919_10 = (has_head(v919_9) ? constant_9 : Space{});
    Space v919_12;
    if (!v919_10.empty()) {
      const Path v924_6 = concat_path(p0,v918_13_head);
      Space v924_11_result;
      for (int v924_11_label = 1; v924_11_label <= 2; ++v924_11_label) {
        const Space v924_11_tail = child(v918_13_tail,v924_11_label);
        if (v924_11_tail.empty()) continue;
        const Path v924_11_head{v924_11_label};
        const Space v925_2 = singleton(v924_11_head);
        const Space v925_3 = intersect(constant_8,v925_2);
        const Space v925_4 = (has_head(v925_3) ? constant_9 : Space{});
        const Space v925_5 = subtract(constant_0,v925_4);
        Space v925_8;
        if (!v925_5.empty()) {
          const Path v926_6 = concat_path(v924_6,v924_11_head);
          const Space v926_7 = routine_176(c, v926_6, p1, v924_11_tail, s1);
          v925_8 = compose(v925_5,v926_7);
        }
        const Space v925_9 = intersect(constant_8,v925_2);
        const Space v925_10 = (has_head(v925_9) ? constant_9 : Space{});
        Space v925_12;
        if (!v925_10.empty()) {
          const Path v927_6 = concat_path(v924_6,v924_11_head);
          const Space v927_11 = routine_133(c, v927_6, p1, v924_11_tail, s1);
          v925_12 = compose(v925_10,v927_11);
        }
        const Space v925_13 = unite(v925_8,v925_12);
        v924_11_result = unite(v924_11_result,v925_13);
      }
      const Space v924_11 = std::move(v924_11_result);
      v919_12 = compose(v919_10,v924_11);
    }
    const Space v919_13 = unite(v919_8,v919_12);
    v918_13_result = unite(v918_13_result,v919_13);
  }
  const Space v918_13 = std::move(v918_13_result);
  return v918_13;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v928_10_result;
  for (int v928_10_label = 1; v928_10_label <= 2; ++v928_10_label) {
    const Space v928_10_tail = child(s0,v928_10_label);
    if (v928_10_tail.empty()) continue;
    const Path v928_10_head{v928_10_label};
    const Space v929_2 = singleton(v928_10_head);
    const Space v929_3 = intersect(constant_8,v929_2);
    const Space v929_4 = (has_head(v929_3) ? constant_9 : Space{});
    const Space v929_5 = subtract(constant_0,v929_4);
    Space v929_8;
    if (!v929_5.empty()) {
      const Path v930_6 = concat_path(p0,v928_10_head);
      Space v930_7_result;
      for (int v930_7_label = 1; v930_7_label <= 2; ++v930_7_label) {
        const Space v930_7_tail = child(v928_10_tail,v930_7_label);
        if (v930_7_tail.empty()) continue;
        const Path v930_7_head{v930_7_label};
        const Space v931_2 = singleton(v930_7_head);
        const Space v931_3 = intersect(constant_8,v931_2);
        const Space v931_4 = (has_head(v931_3) ? constant_9 : Space{});
        const Space v931_5 = subtract(constant_0,v931_4);
        Space v931_8;
        if (!v931_5.empty()) {
          const Path v932_6 = concat_path(v930_6,v930_7_head);
          const Space v932_7 = routine_176(c, v932_6, p1, v930_7_tail, s1);
          v931_8 = compose(v931_5,v932_7);
        }
        const Space v931_9 = intersect(constant_8,v931_2);
        const Space v931_10 = (has_head(v931_9) ? constant_9 : Space{});
        Space v931_12;
        if (!v931_10.empty()) {
          const Path v933_6 = concat_path(v930_6,v930_7_head);
          const Space v933_11 = routine_177(c, v933_6, p1, v930_7_tail, s1);
          v931_12 = compose(v931_10,v933_11);
        }
        const Space v931_13 = unite(v931_8,v931_12);
        v930_7_result = unite(v930_7_result,v931_13);
      }
      const Space v930_7 = std::move(v930_7_result);
      v929_8 = compose(v929_5,v930_7);
    }
    const Space v929_9 = intersect(constant_8,v929_2);
    const Space v929_10 = (has_head(v929_9) ? constant_9 : Space{});
    const Space v929_11 = unwrap(v928_10_tail,p1);
    const Path v934_6 = concat_path(p0,v928_10_head);
    const Space v929_12 = wrap(v929_11,v934_6);
    const Space v929_13 = compose(v929_12,s1);
    const Space v929_14 = compose(v929_10,v929_13);
    const Space v929_15 = unite(v929_8,v929_14);
    v928_10_result = unite(v928_10_result,v929_15);
  }
  const Space v928_10 = std::move(v928_10_result);
  return v928_10;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v935_12_result;
  for (int v935_12_label = 1; v935_12_label <= 2; ++v935_12_label) {
    const Space v935_12_tail = child(s0,v935_12_label);
    if (v935_12_tail.empty()) continue;
    const Path v935_12_head{v935_12_label};
    const Space v936_2 = singleton(v935_12_head);
    const Space v936_3 = intersect(constant_8,v936_2);
    const Space v936_4 = (has_head(v936_3) ? constant_9 : Space{});
    const Space v936_5 = subtract(constant_0,v936_4);
    Space v936_8;
    if (!v936_5.empty()) {
      const Path v937_6 = concat_path(p0,v935_12_head);
      Space v937_7_result;
      for (int v937_7_label = 1; v937_7_label <= 2; ++v937_7_label) {
        const Space v937_7_tail = child(v935_12_tail,v937_7_label);
        if (v937_7_tail.empty()) continue;
        const Path v937_7_head{v937_7_label};
        const Space v938_2 = singleton(v937_7_head);
        const Space v938_3 = intersect(constant_8,v938_2);
        const Space v938_4 = (has_head(v938_3) ? constant_9 : Space{});
        const Space v938_5 = subtract(constant_0,v938_4);
        Space v938_8;
        if (!v938_5.empty()) {
          const Path v939_6 = concat_path(v937_6,v937_7_head);
          const Space v939_7 = routine_178(c, v939_6, p1, v937_7_tail);
          v938_8 = compose(v938_5,v939_7);
        }
        const Space v938_9 = intersect(constant_8,v938_2);
        const Space v938_10 = (has_head(v938_9) ? constant_9 : Space{});
        Space v938_12;
        if (!v938_10.empty()) {
          const Path v940_6 = concat_path(v937_6,v937_7_head);
          const Space v940_11 = routine_179(c, v940_6, p1, v937_7_tail);
          v938_12 = compose(v938_10,v940_11);
        }
        const Space v938_13 = unite(v938_8,v938_12);
        v937_7_result = unite(v937_7_result,v938_13);
      }
      const Space v937_7 = std::move(v937_7_result);
      v936_8 = compose(v936_5,v937_7);
    }
    const Space v936_9 = intersect(constant_8,v936_2);
    const Space v936_10 = (has_head(v936_9) ? constant_9 : Space{});
    Space v936_12;
    if (!v936_10.empty()) {
      const Path v941_6 = concat_path(p0,v935_12_head);
      Space v941_11_result;
      for (int v941_11_label = 1; v941_11_label <= 2; ++v941_11_label) {
        const Space v941_11_tail = child(v935_12_tail,v941_11_label);
        if (v941_11_tail.empty()) continue;
        const Path v941_11_head{v941_11_label};
        const Space v942_2 = singleton(v941_11_head);
        const Space v942_3 = intersect(constant_8,v942_2);
        const Space v942_4 = (has_head(v942_3) ? constant_9 : Space{});
        const Space v942_5 = subtract(constant_0,v942_4);
        Space v942_8;
        if (!v942_5.empty()) {
          const Path v943_6 = concat_path(v941_6,v941_11_head);
          const Space v943_7 = routine_178(c, v943_6, p1, v941_11_tail);
          v942_8 = compose(v942_5,v943_7);
        }
        const Space v942_9 = intersect(constant_8,v942_2);
        const Space v942_10 = (has_head(v942_9) ? constant_9 : Space{});
        Space v942_12;
        if (!v942_10.empty()) {
          const Path v944_6 = concat_path(v941_6,v941_11_head);
          const Space v944_11 = routine_63(c, v944_6, p1, v941_11_tail);
          v942_12 = compose(v942_10,v944_11);
        }
        const Space v942_13 = unite(v942_8,v942_12);
        v941_11_result = unite(v941_11_result,v942_13);
      }
      const Space v941_11 = std::move(v941_11_result);
      v936_12 = compose(v936_10,v941_11);
    }
    const Space v936_13 = unite(v936_8,v936_12);
    v935_12_result = unite(v935_12_result,v936_13);
  }
  const Space v935_12 = std::move(v935_12_result);
  return v935_12;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v945_17_result;
  for (int v945_17_label = 1; v945_17_label <= 2; ++v945_17_label) {
    const Space v945_17_tail = child(s0,v945_17_label);
    if (v945_17_tail.empty()) continue;
    const Path v945_17_head{v945_17_label};
    const Space v946_2 = singleton(v945_17_head);
    const Space v946_3 = intersect(constant_8,v946_2);
    const Space v946_4 = (has_head(v946_3) ? constant_9 : Space{});
    const Space v946_5 = subtract(constant_0,v946_4);
    Space v946_8;
    if (!v946_5.empty()) {
      const Path v947_6 = concat_path(p0,v945_17_head);
      Space v947_7_result;
      for (int v947_7_label = 1; v947_7_label <= 2; ++v947_7_label) {
        const Space v947_7_tail = child(v945_17_tail,v947_7_label);
        if (v947_7_tail.empty()) continue;
        const Path v947_7_head{v947_7_label};
        const Space v948_2 = singleton(v947_7_head);
        const Space v948_3 = intersect(constant_8,v948_2);
        const Space v948_4 = (has_head(v948_3) ? constant_9 : Space{});
        const Space v948_5 = subtract(constant_0,v948_4);
        Space v948_8;
        if (!v948_5.empty()) {
          const Path v949_6 = concat_path(v947_6,v947_7_head);
          const Space v949_7 = routine_178(c, v949_6, p1, v947_7_tail);
          v948_8 = compose(v948_5,v949_7);
        }
        const Space v948_9 = intersect(constant_8,v948_2);
        const Space v948_10 = (has_head(v948_9) ? constant_9 : Space{});
        Space v948_12;
        if (!v948_10.empty()) {
          const Path v950_6 = concat_path(v947_6,v947_7_head);
          const Space v950_11 = routine_179(c, v950_6, p1, v947_7_tail);
          v948_12 = compose(v948_10,v950_11);
        }
        const Space v948_13 = unite(v948_8,v948_12);
        v947_7_result = unite(v947_7_result,v948_13);
      }
      const Space v947_7 = std::move(v947_7_result);
      v946_8 = compose(v946_5,v947_7);
    }
    const Space v946_9 = intersect(constant_8,v946_2);
    const Space v946_10 = (has_head(v946_9) ? constant_9 : Space{});
    Space v946_16;
    if (!v946_10.empty()) {
      Space v951_14;
      if (!constant_0.empty()) {
        const Path v952_6 = concat_path(p0,v945_17_head);
        const Space v952_11 = routine_98(c, constant_14, p1, v952_6, constant_15);
        const Space v952_12 = routine_99(c, constant_16, p1, v952_6, constant_17);
        const Space v952_13 = unite(v952_11,v952_12);
        v951_14 = compose(constant_0,v952_13);
      }
      Space v951_15_result;
      for (int v951_15_label = 1; v951_15_label <= 2; ++v951_15_label) {
        const Space v951_15_tail = child(v951_14,v951_15_label);
        if (v951_15_tail.empty()) continue;
        const Path v951_15_head{v951_15_label};
        const Space v953_2 = singleton(v951_15_head);
        const Space v953_3 = intersect(constant_8,v953_2);
        const Space v953_4 = (has_head(v953_3) ? constant_9 : Space{});
        const Space v953_5 = subtract(constant_0,v953_4);
        Space v953_7;
        if (!v953_5.empty()) {
          const Space v954_6 = routine_100(c, v951_15_head, v951_15_tail, v945_17_tail);
          v953_7 = compose(v953_5,v954_6);
        }
        const Space v953_8 = intersect(constant_8,v953_2);
        const Space v953_9 = (has_head(v953_8) ? constant_9 : Space{});
        Space v953_11;
        if (!v953_9.empty()) {
          const Space v955_10 = routine_101(c, v951_15_head, v951_15_tail, v945_17_tail);
          v953_11 = compose(v953_9,v955_10);
        }
        const Space v953_12 = unite(v953_7,v953_11);
        v951_15_result = unite(v951_15_result,v953_12);
      }
      const Space v951_15 = std::move(v951_15_result);
      v946_16 = compose(v946_10,v951_15);
    }
    const Space v946_17 = unite(v946_8,v946_16);
    v945_17_result = unite(v945_17_result,v946_17);
  }
  const Space v945_17 = std::move(v945_17_result);
  return v945_17;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v956_13_result;
  for (int v956_13_label = 1; v956_13_label <= 2; ++v956_13_label) {
    const Space v956_13_tail = child(s0,v956_13_label);
    if (v956_13_tail.empty()) continue;
    const Path v956_13_head{v956_13_label};
    const Space v957_2 = singleton(v956_13_head);
    const Space v957_3 = intersect(constant_8,v957_2);
    const Space v957_4 = (has_head(v957_3) ? constant_9 : Space{});
    const Space v957_5 = subtract(constant_0,v957_4);
    Space v957_8;
    if (!v957_5.empty()) {
      const Path v958_6 = concat_path(p0,v956_13_head);
      Space v958_7_result;
      for (int v958_7_label = 1; v958_7_label <= 2; ++v958_7_label) {
        const Space v958_7_tail = child(v956_13_tail,v958_7_label);
        if (v958_7_tail.empty()) continue;
        const Path v958_7_head{v958_7_label};
        const Space v959_2 = singleton(v958_7_head);
        const Space v959_3 = intersect(constant_8,v959_2);
        const Space v959_4 = (has_head(v959_3) ? constant_9 : Space{});
        const Space v959_5 = subtract(constant_0,v959_4);
        Space v959_8;
        if (!v959_5.empty()) {
          const Path v960_6 = concat_path(v958_6,v958_7_head);
          const Space v960_7 = routine_180(c, v960_6, p1, p2, v958_7_tail);
          v959_8 = compose(v959_5,v960_7);
        }
        const Space v959_9 = intersect(constant_8,v959_2);
        const Space v959_10 = (has_head(v959_9) ? constant_9 : Space{});
        Space v959_12;
        if (!v959_10.empty()) {
          const Path v961_6 = concat_path(v958_6,v958_7_head);
          const Space v961_11 = routine_181(c, v961_6, p1, p2, v958_7_tail);
          v959_12 = compose(v959_10,v961_11);
        }
        const Space v959_13 = unite(v959_8,v959_12);
        v958_7_result = unite(v958_7_result,v959_13);
      }
      const Space v958_7 = std::move(v958_7_result);
      v957_8 = compose(v957_5,v958_7);
    }
    const Space v957_9 = intersect(constant_8,v957_2);
    const Space v957_10 = (has_head(v957_9) ? constant_9 : Space{});
    Space v957_12;
    if (!v957_10.empty()) {
      const Path v962_6 = concat_path(p0,v956_13_head);
      Space v962_11_result;
      for (int v962_11_label = 1; v962_11_label <= 2; ++v962_11_label) {
        const Space v962_11_tail = child(v956_13_tail,v962_11_label);
        if (v962_11_tail.empty()) continue;
        const Path v962_11_head{v962_11_label};
        const Space v963_2 = singleton(v962_11_head);
        const Space v963_3 = intersect(constant_8,v963_2);
        const Space v963_4 = (has_head(v963_3) ? constant_9 : Space{});
        const Space v963_5 = subtract(constant_0,v963_4);
        Space v963_8;
        if (!v963_5.empty()) {
          const Path v964_6 = concat_path(v962_6,v962_11_head);
          const Space v964_7 = routine_180(c, v964_6, p1, p2, v962_11_tail);
          v963_8 = compose(v963_5,v964_7);
        }
        const Space v963_9 = intersect(constant_8,v963_2);
        const Space v963_10 = (has_head(v963_9) ? constant_9 : Space{});
        Space v963_12;
        if (!v963_10.empty()) {
          const Path v965_6 = concat_path(v962_6,v962_11_head);
          const Space v965_11 = routine_138(c, v965_6, p1, p2, v962_11_tail);
          v963_12 = compose(v963_10,v965_11);
        }
        const Space v963_13 = unite(v963_8,v963_12);
        v962_11_result = unite(v962_11_result,v963_13);
      }
      const Space v962_11 = std::move(v962_11_result);
      v957_12 = compose(v957_10,v962_11);
    }
    const Space v957_13 = unite(v957_8,v957_12);
    v956_13_result = unite(v956_13_result,v957_13);
  }
  const Space v956_13 = std::move(v956_13_result);
  return v956_13;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v966_13_result;
  for (int v966_13_label = 1; v966_13_label <= 2; ++v966_13_label) {
    const Space v966_13_tail = child(s0,v966_13_label);
    if (v966_13_tail.empty()) continue;
    const Path v966_13_head{v966_13_label};
    const Space v967_2 = singleton(v966_13_head);
    const Space v967_3 = intersect(constant_8,v967_2);
    const Space v967_4 = (has_head(v967_3) ? constant_9 : Space{});
    const Space v967_5 = subtract(constant_0,v967_4);
    Space v967_8;
    if (!v967_5.empty()) {
      const Path v968_6 = concat_path(p0,v966_13_head);
      Space v968_7_result;
      for (int v968_7_label = 1; v968_7_label <= 2; ++v968_7_label) {
        const Space v968_7_tail = child(v966_13_tail,v968_7_label);
        if (v968_7_tail.empty()) continue;
        const Path v968_7_head{v968_7_label};
        const Space v969_2 = singleton(v968_7_head);
        const Space v969_3 = intersect(constant_8,v969_2);
        const Space v969_4 = (has_head(v969_3) ? constant_9 : Space{});
        const Space v969_5 = subtract(constant_0,v969_4);
        Space v969_8;
        if (!v969_5.empty()) {
          const Path v970_6 = concat_path(v968_6,v968_7_head);
          const Space v970_7 = routine_180(c, v970_6, p1, p2, v968_7_tail);
          v969_8 = compose(v969_5,v970_7);
        }
        const Space v969_9 = intersect(constant_8,v969_2);
        const Space v969_10 = (has_head(v969_9) ? constant_9 : Space{});
        Space v969_12;
        if (!v969_10.empty()) {
          const Path v971_6 = concat_path(v968_6,v968_7_head);
          const Space v971_11 = routine_181(c, v971_6, p1, p2, v968_7_tail);
          v969_12 = compose(v969_10,v971_11);
        }
        const Space v969_13 = unite(v969_8,v969_12);
        v968_7_result = unite(v968_7_result,v969_13);
      }
      const Space v968_7 = std::move(v968_7_result);
      v967_8 = compose(v967_5,v968_7);
    }
    const Space v967_9 = intersect(constant_8,v967_2);
    const Space v967_10 = (has_head(v967_9) ? constant_9 : Space{});
    Space v967_12;
    if (!v967_10.empty()) {
      const Path v972_6 = concat_path(p0,v966_13_head);
      Space v972_11_result;
      for (int v972_11_label = 1; v972_11_label <= 2; ++v972_11_label) {
        const Space v972_11_tail = child(v966_13_tail,v972_11_label);
        if (v972_11_tail.empty()) continue;
        const Path v972_11_head{v972_11_label};
        const Space v973_2 = singleton(v972_11_head);
        const Space v973_3 = intersect(constant_8,v973_2);
        const Space v973_4 = (has_head(v973_3) ? constant_9 : Space{});
        const Space v973_5 = subtract(constant_0,v973_4);
        Space v973_7;
        if (!v973_5.empty()) {
          const Space v974_6 = routine_182(c, v972_11_head, p1, p2, v972_6, v972_11_tail);
          v973_7 = compose(v973_5,v974_6);
        }
        const Space v973_8 = intersect(constant_8,v973_2);
        const Space v973_9 = (has_head(v973_8) ? constant_9 : Space{});
        Space v973_11;
        if (!v973_9.empty()) {
          const Space v975_10 = routine_183(c, v972_11_head, p1, p2, v972_6, v972_11_tail);
          v973_11 = compose(v973_9,v975_10);
        }
        const Space v973_12 = unite(v973_7,v973_11);
        v972_11_result = unite(v972_11_result,v973_12);
      }
      const Space v972_11 = std::move(v972_11_result);
      v967_12 = compose(v967_10,v972_11);
    }
    const Space v967_13 = unite(v967_8,v967_12);
    v966_13_result = unite(v966_13_result,v967_13);
  }
  const Space v966_13 = std::move(v966_13_result);
  return v966_13;
}

static Space routine_100(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v976_12_result;
  for (int v976_12_label = 1; v976_12_label <= 2; ++v976_12_label) {
    const Space v976_12_tail = child(s0,v976_12_label);
    if (v976_12_tail.empty()) continue;
    const Path v976_12_head{v976_12_label};
    const Space v977_2 = singleton(v976_12_head);
    const Space v977_3 = intersect(constant_8,v977_2);
    const Space v977_4 = (has_head(v977_3) ? constant_9 : Space{});
    const Space v977_5 = subtract(constant_0,v977_4);
    Space v977_8;
    if (!v977_5.empty()) {
      const Path v978_6 = concat_path(p0,v976_12_head);
      Space v978_7_result;
      for (int v978_7_label = 1; v978_7_label <= 2; ++v978_7_label) {
        const Space v978_7_tail = child(v976_12_tail,v978_7_label);
        if (v978_7_tail.empty()) continue;
        const Path v978_7_head{v978_7_label};
        const Space v979_2 = singleton(v978_7_head);
        const Space v979_3 = intersect(constant_8,v979_2);
        const Space v979_4 = (has_head(v979_3) ? constant_9 : Space{});
        const Space v979_5 = subtract(constant_0,v979_4);
        Space v979_8;
        if (!v979_5.empty()) {
          const Path v980_6 = concat_path(v978_6,v978_7_head);
          const Space v980_7 = routine_184(c, v980_6, v978_7_tail, s1);
          v979_8 = compose(v979_5,v980_7);
        }
        const Space v979_9 = intersect(constant_8,v979_2);
        const Space v979_10 = (has_head(v979_9) ? constant_9 : Space{});
        Space v979_12;
        if (!v979_10.empty()) {
          const Path v981_6 = concat_path(v978_6,v978_7_head);
          const Space v981_11 = routine_185(c, v981_6, v978_7_tail, s1);
          v979_12 = compose(v979_10,v981_11);
        }
        const Space v979_13 = unite(v979_8,v979_12);
        v978_7_result = unite(v978_7_result,v979_13);
      }
      const Space v978_7 = std::move(v978_7_result);
      v977_8 = compose(v977_5,v978_7);
    }
    const Space v977_9 = intersect(constant_8,v977_2);
    const Space v977_10 = (has_head(v977_9) ? constant_9 : Space{});
    Space v977_12;
    if (!v977_10.empty()) {
      const Path v982_6 = concat_path(p0,v976_12_head);
      Space v982_11_result;
      for (int v982_11_label = 1; v982_11_label <= 2; ++v982_11_label) {
        const Space v982_11_tail = child(v976_12_tail,v982_11_label);
        if (v982_11_tail.empty()) continue;
        const Path v982_11_head{v982_11_label};
        const Space v983_2 = singleton(v982_11_head);
        const Space v983_3 = intersect(constant_8,v983_2);
        const Space v983_4 = (has_head(v983_3) ? constant_9 : Space{});
        const Space v983_5 = subtract(constant_0,v983_4);
        Space v983_8;
        if (!v983_5.empty()) {
          const Path v984_6 = concat_path(v982_6,v982_11_head);
          const Space v984_7 = routine_184(c, v984_6, v982_11_tail, s1);
          v983_8 = compose(v983_5,v984_7);
        }
        const Space v983_9 = intersect(constant_8,v983_2);
        const Space v983_10 = (has_head(v983_9) ? constant_9 : Space{});
        Space v983_12;
        if (!v983_10.empty()) {
          const Path v985_6 = concat_path(v982_6,v982_11_head);
          const Space v985_11 = routine_141(c, v985_6, v982_11_tail, s1);
          v983_12 = compose(v983_10,v985_11);
        }
        const Space v983_13 = unite(v983_8,v983_12);
        v982_11_result = unite(v982_11_result,v983_13);
      }
      const Space v982_11 = std::move(v982_11_result);
      v977_12 = compose(v977_10,v982_11);
    }
    const Space v977_13 = unite(v977_8,v977_12);
    v976_12_result = unite(v976_12_result,v977_13);
  }
  const Space v976_12 = std::move(v976_12_result);
  return v976_12;
}

static Space routine_101(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v986_9_result;
  for (int v986_9_label = 1; v986_9_label <= 2; ++v986_9_label) {
    const Space v986_9_tail = child(s0,v986_9_label);
    if (v986_9_tail.empty()) continue;
    const Path v986_9_head{v986_9_label};
    const Space v987_2 = singleton(v986_9_head);
    const Space v987_3 = intersect(constant_8,v987_2);
    const Space v987_4 = (has_head(v987_3) ? constant_9 : Space{});
    const Space v987_5 = subtract(constant_0,v987_4);
    Space v987_8;
    if (!v987_5.empty()) {
      const Path v988_6 = concat_path(p0,v986_9_head);
      Space v988_7_result;
      for (int v988_7_label = 1; v988_7_label <= 2; ++v988_7_label) {
        const Space v988_7_tail = child(v986_9_tail,v988_7_label);
        if (v988_7_tail.empty()) continue;
        const Path v988_7_head{v988_7_label};
        const Space v989_2 = singleton(v988_7_head);
        const Space v989_3 = intersect(constant_8,v989_2);
        const Space v989_4 = (has_head(v989_3) ? constant_9 : Space{});
        const Space v989_5 = subtract(constant_0,v989_4);
        Space v989_8;
        if (!v989_5.empty()) {
          const Path v990_6 = concat_path(v988_6,v988_7_head);
          const Space v990_7 = routine_184(c, v990_6, v988_7_tail, s1);
          v989_8 = compose(v989_5,v990_7);
        }
        const Space v989_9 = intersect(constant_8,v989_2);
        const Space v989_10 = (has_head(v989_9) ? constant_9 : Space{});
        Space v989_12;
        if (!v989_10.empty()) {
          const Path v991_6 = concat_path(v988_6,v988_7_head);
          const Space v991_11 = routine_185(c, v991_6, v988_7_tail, s1);
          v989_12 = compose(v989_10,v991_11);
        }
        const Space v989_13 = unite(v989_8,v989_12);
        v988_7_result = unite(v988_7_result,v989_13);
      }
      const Space v988_7 = std::move(v988_7_result);
      v987_8 = compose(v987_5,v988_7);
    }
    const Space v987_9 = intersect(constant_8,v987_2);
    const Space v987_10 = (has_head(v987_9) ? constant_9 : Space{});
    Space v987_12;
    if (!v987_10.empty()) {
      const Path v992_6 = concat_path(p0,v986_9_head);
      const Space v992_11 = routine_186(c, v992_6, s1);
      v987_12 = compose(v987_10,v992_11);
    }
    const Space v987_13 = unite(v987_8,v987_12);
    v986_9_result = unite(v986_9_result,v987_13);
  }
  const Space v986_9 = std::move(v986_9_result);
  return v986_9;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0) {
  Space v993_11_result;
  for (int v993_11_label = 1; v993_11_label <= 2; ++v993_11_label) {
    const Space v993_11_tail = child(s0,v993_11_label);
    if (v993_11_tail.empty()) continue;
    const Path v993_11_head{v993_11_label};
    const Space v994_2 = singleton(v993_11_head);
    const Space v994_3 = intersect(constant_8,v994_2);
    const Space v994_4 = (has_head(v994_3) ? constant_9 : Space{});
    const Space v994_5 = subtract(constant_0,v994_4);
    Space v994_8;
    if (!v994_5.empty()) {
      const Path v995_6 = concat_path(p0,v993_11_head);
      Space v995_7_result;
      for (int v995_7_label = 1; v995_7_label <= 2; ++v995_7_label) {
        const Space v995_7_tail = child(v993_11_tail,v995_7_label);
        if (v995_7_tail.empty()) continue;
        const Path v995_7_head{v995_7_label};
        const Space v996_2 = singleton(v995_7_head);
        const Space v996_3 = intersect(constant_8,v996_2);
        const Space v996_4 = (has_head(v996_3) ? constant_9 : Space{});
        const Space v996_5 = subtract(constant_0,v996_4);
        Space v996_8;
        if (!v996_5.empty()) {
          const Path v997_6 = concat_path(v995_6,v995_7_head);
          const Space v997_7 = routine_187(c, v997_6, v995_7_tail);
          v996_8 = compose(v996_5,v997_7);
        }
        const Space v996_9 = intersect(constant_8,v996_2);
        const Space v996_10 = (has_head(v996_9) ? constant_9 : Space{});
        Space v996_12;
        if (!v996_10.empty()) {
          const Path v998_6 = concat_path(v995_6,v995_7_head);
          const Space v998_11 = routine_188(c, v998_6, v995_7_tail);
          v996_12 = compose(v996_10,v998_11);
        }
        const Space v996_13 = unite(v996_8,v996_12);
        v995_7_result = unite(v995_7_result,v996_13);
      }
      const Space v995_7 = std::move(v995_7_result);
      v994_8 = compose(v994_5,v995_7);
    }
    const Space v994_9 = intersect(constant_8,v994_2);
    const Space v994_10 = (has_head(v994_9) ? constant_9 : Space{});
    Space v994_12;
    if (!v994_10.empty()) {
      const Path v999_6 = concat_path(p0,v993_11_head);
      Space v999_11_result;
      for (int v999_11_label = 1; v999_11_label <= 2; ++v999_11_label) {
        const Space v999_11_tail = child(v993_11_tail,v999_11_label);
        if (v999_11_tail.empty()) continue;
        const Path v999_11_head{v999_11_label};
        const Space v1000_2 = singleton(v999_11_head);
        const Space v1000_3 = intersect(constant_8,v1000_2);
        const Space v1000_4 = (has_head(v1000_3) ? constant_9 : Space{});
        const Space v1000_5 = subtract(constant_0,v1000_4);
        Space v1000_8;
        if (!v1000_5.empty()) {
          const Path v1001_6 = concat_path(v999_6,v999_11_head);
          const Space v1001_7 = routine_187(c, v1001_6, v999_11_tail);
          v1000_8 = compose(v1000_5,v1001_7);
        }
        const Space v1000_9 = intersect(constant_8,v1000_2);
        const Space v1000_10 = (has_head(v1000_9) ? constant_9 : Space{});
        Space v1000_12;
        if (!v1000_10.empty()) {
          const Path v1002_6 = concat_path(v999_6,v999_11_head);
          const Space v1002_11 = routine_68(c, v1002_6, v999_11_tail);
          v1000_12 = compose(v1000_10,v1002_11);
        }
        const Space v1000_13 = unite(v1000_8,v1000_12);
        v999_11_result = unite(v999_11_result,v1000_13);
      }
      const Space v999_11 = std::move(v999_11_result);
      v994_12 = compose(v994_10,v999_11);
    }
    const Space v994_13 = unite(v994_8,v994_12);
    v993_11_result = unite(v993_11_result,v994_13);
  }
  const Space v993_11 = std::move(v993_11_result);
  return v993_11;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0) {
  Space v1003_8_result;
  for (int v1003_8_label = 1; v1003_8_label <= 2; ++v1003_8_label) {
    const Space v1003_8_tail = child(s0,v1003_8_label);
    if (v1003_8_tail.empty()) continue;
    const Path v1003_8_head{v1003_8_label};
    const Space v1004_2 = singleton(v1003_8_head);
    const Space v1004_3 = intersect(constant_8,v1004_2);
    const Space v1004_4 = (has_head(v1004_3) ? constant_9 : Space{});
    const Space v1004_5 = subtract(constant_0,v1004_4);
    Space v1004_8;
    if (!v1004_5.empty()) {
      const Path v1005_6 = concat_path(p0,v1003_8_head);
      Space v1005_7_result;
      for (int v1005_7_label = 1; v1005_7_label <= 2; ++v1005_7_label) {
        const Space v1005_7_tail = child(v1003_8_tail,v1005_7_label);
        if (v1005_7_tail.empty()) continue;
        const Path v1005_7_head{v1005_7_label};
        const Space v1006_2 = singleton(v1005_7_head);
        const Space v1006_3 = intersect(constant_8,v1006_2);
        const Space v1006_4 = (has_head(v1006_3) ? constant_9 : Space{});
        const Space v1006_5 = subtract(constant_0,v1006_4);
        Space v1006_8;
        if (!v1006_5.empty()) {
          const Path v1007_6 = concat_path(v1005_6,v1005_7_head);
          const Space v1007_7 = routine_187(c, v1007_6, v1005_7_tail);
          v1006_8 = compose(v1006_5,v1007_7);
        }
        const Space v1006_9 = intersect(constant_8,v1006_2);
        const Space v1006_10 = (has_head(v1006_9) ? constant_9 : Space{});
        Space v1006_12;
        if (!v1006_10.empty()) {
          const Path v1008_6 = concat_path(v1005_6,v1005_7_head);
          const Space v1008_11 = routine_188(c, v1008_6, v1005_7_tail);
          v1006_12 = compose(v1006_10,v1008_11);
        }
        const Space v1006_13 = unite(v1006_8,v1006_12);
        v1005_7_result = unite(v1005_7_result,v1006_13);
      }
      const Space v1005_7 = std::move(v1005_7_result);
      v1004_8 = compose(v1004_5,v1005_7);
    }
    const Space v1004_9 = intersect(constant_8,v1004_2);
    const Space v1004_10 = (has_head(v1004_9) ? constant_9 : Space{});
    const Space v1004_11 = compose(v1004_10,v1003_8_tail);
    const Space v1004_12 = unite(v1004_8,v1004_11);
    v1003_8_result = unite(v1003_8_result,v1004_12);
  }
  const Space v1003_8 = std::move(v1003_8_result);
  return v1003_8;
}

static Space routine_104(Context& c, const Path& p0, const Space& s0) {
  Space v1009_11_result;
  for (int v1009_11_label = 1; v1009_11_label <= 2; ++v1009_11_label) {
    const Space v1009_11_tail = child(s0,v1009_11_label);
    if (v1009_11_tail.empty()) continue;
    const Path v1009_11_head{v1009_11_label};
    const Space v1010_2 = singleton(v1009_11_head);
    const Space v1010_3 = intersect(constant_8,v1010_2);
    const Space v1010_4 = (has_head(v1010_3) ? constant_9 : Space{});
    const Space v1010_5 = subtract(constant_0,v1010_4);
    Space v1010_8;
    if (!v1010_5.empty()) {
      const Path v1011_6 = concat_path(p0,v1009_11_head);
      Space v1011_7_result;
      for (int v1011_7_label = 1; v1011_7_label <= 2; ++v1011_7_label) {
        const Space v1011_7_tail = child(v1009_11_tail,v1011_7_label);
        if (v1011_7_tail.empty()) continue;
        const Path v1011_7_head{v1011_7_label};
        const Space v1012_2 = singleton(v1011_7_head);
        const Space v1012_3 = intersect(constant_8,v1012_2);
        const Space v1012_4 = (has_head(v1012_3) ? constant_9 : Space{});
        const Space v1012_5 = subtract(constant_0,v1012_4);
        Space v1012_8;
        if (!v1012_5.empty()) {
          const Path v1013_6 = concat_path(v1011_6,v1011_7_head);
          const Space v1013_7 = routine_189(c, v1013_6, v1011_7_tail);
          v1012_8 = compose(v1012_5,v1013_7);
        }
        const Space v1012_9 = intersect(constant_8,v1012_2);
        const Space v1012_10 = (has_head(v1012_9) ? constant_9 : Space{});
        Space v1012_12;
        if (!v1012_10.empty()) {
          const Path v1014_6 = concat_path(v1011_6,v1011_7_head);
          const Space v1014_11 = routine_190(c, v1014_6, v1011_7_tail);
          v1012_12 = compose(v1012_10,v1014_11);
        }
        const Space v1012_13 = unite(v1012_8,v1012_12);
        v1011_7_result = unite(v1011_7_result,v1012_13);
      }
      const Space v1011_7 = std::move(v1011_7_result);
      v1010_8 = compose(v1010_5,v1011_7);
    }
    const Space v1010_9 = intersect(constant_8,v1010_2);
    const Space v1010_10 = (has_head(v1010_9) ? constant_9 : Space{});
    Space v1010_12;
    if (!v1010_10.empty()) {
      const Path v1015_6 = concat_path(p0,v1009_11_head);
      Space v1015_11_result;
      for (int v1015_11_label = 1; v1015_11_label <= 2; ++v1015_11_label) {
        const Space v1015_11_tail = child(v1009_11_tail,v1015_11_label);
        if (v1015_11_tail.empty()) continue;
        const Path v1015_11_head{v1015_11_label};
        const Space v1016_2 = singleton(v1015_11_head);
        const Space v1016_3 = intersect(constant_8,v1016_2);
        const Space v1016_4 = (has_head(v1016_3) ? constant_9 : Space{});
        const Space v1016_5 = subtract(constant_0,v1016_4);
        Space v1016_8;
        if (!v1016_5.empty()) {
          const Path v1017_6 = concat_path(v1015_6,v1015_11_head);
          const Space v1017_7 = routine_189(c, v1017_6, v1015_11_tail);
          v1016_8 = compose(v1016_5,v1017_7);
        }
        const Space v1016_9 = intersect(constant_8,v1016_2);
        const Space v1016_10 = (has_head(v1016_9) ? constant_9 : Space{});
        Space v1016_12;
        if (!v1016_10.empty()) {
          const Path v1018_6 = concat_path(v1015_6,v1015_11_head);
          const Space v1018_11 = routine_71(c, v1018_6, v1015_11_tail);
          v1016_12 = compose(v1016_10,v1018_11);
        }
        const Space v1016_13 = unite(v1016_8,v1016_12);
        v1015_11_result = unite(v1015_11_result,v1016_13);
      }
      const Space v1015_11 = std::move(v1015_11_result);
      v1010_12 = compose(v1010_10,v1015_11);
    }
    const Space v1010_13 = unite(v1010_8,v1010_12);
    v1009_11_result = unite(v1009_11_result,v1010_13);
  }
  const Space v1009_11 = std::move(v1009_11_result);
  return v1009_11;
}

static Space routine_105(Context& c, const Path& p0, const Space& s0) {
  Space v1019_11_result;
  for (int v1019_11_label = 1; v1019_11_label <= 2; ++v1019_11_label) {
    const Space v1019_11_tail = child(s0,v1019_11_label);
    if (v1019_11_tail.empty()) continue;
    const Path v1019_11_head{v1019_11_label};
    const Space v1020_2 = singleton(v1019_11_head);
    const Space v1020_3 = intersect(constant_8,v1020_2);
    const Space v1020_4 = (has_head(v1020_3) ? constant_9 : Space{});
    const Space v1020_5 = subtract(constant_0,v1020_4);
    Space v1020_8;
    if (!v1020_5.empty()) {
      const Path v1021_6 = concat_path(p0,v1019_11_head);
      Space v1021_7_result;
      for (int v1021_7_label = 1; v1021_7_label <= 2; ++v1021_7_label) {
        const Space v1021_7_tail = child(v1019_11_tail,v1021_7_label);
        if (v1021_7_tail.empty()) continue;
        const Path v1021_7_head{v1021_7_label};
        const Space v1022_2 = singleton(v1021_7_head);
        const Space v1022_3 = intersect(constant_8,v1022_2);
        const Space v1022_4 = (has_head(v1022_3) ? constant_9 : Space{});
        const Space v1022_5 = subtract(constant_0,v1022_4);
        Space v1022_8;
        if (!v1022_5.empty()) {
          const Path v1023_6 = concat_path(v1021_6,v1021_7_head);
          const Space v1023_7 = routine_189(c, v1023_6, v1021_7_tail);
          v1022_8 = compose(v1022_5,v1023_7);
        }
        const Space v1022_9 = intersect(constant_8,v1022_2);
        const Space v1022_10 = (has_head(v1022_9) ? constant_9 : Space{});
        Space v1022_12;
        if (!v1022_10.empty()) {
          const Path v1024_6 = concat_path(v1021_6,v1021_7_head);
          const Space v1024_11 = routine_190(c, v1024_6, v1021_7_tail);
          v1022_12 = compose(v1022_10,v1024_11);
        }
        const Space v1022_13 = unite(v1022_8,v1022_12);
        v1021_7_result = unite(v1021_7_result,v1022_13);
      }
      const Space v1021_7 = std::move(v1021_7_result);
      v1020_8 = compose(v1020_5,v1021_7);
    }
    const Space v1020_9 = intersect(constant_8,v1020_2);
    const Space v1020_10 = (has_head(v1020_9) ? constant_9 : Space{});
    Space v1020_12;
    if (!v1020_10.empty()) {
      const Path v1025_6 = concat_path(p0,v1019_11_head);
      Space v1025_11_result;
      for (int v1025_11_label = 1; v1025_11_label <= 2; ++v1025_11_label) {
        const Space v1025_11_tail = child(v1019_11_tail,v1025_11_label);
        if (v1025_11_tail.empty()) continue;
        const Path v1025_11_head{v1025_11_label};
        const Space v1026_2 = singleton(v1025_11_head);
        const Space v1026_3 = intersect(constant_8,v1026_2);
        const Space v1026_4 = (has_head(v1026_3) ? constant_9 : Space{});
        const Space v1026_5 = subtract(constant_0,v1026_4);
        Space v1026_7;
        if (!v1026_5.empty()) {
          const Space v1027_6 = routine_106(c, v1025_11_head, v1025_6, v1025_11_tail);
          v1026_7 = compose(v1026_5,v1027_6);
        }
        const Space v1026_8 = intersect(constant_8,v1026_2);
        const Space v1026_9 = (has_head(v1026_8) ? constant_9 : Space{});
        Space v1026_11;
        if (!v1026_9.empty()) {
          const Space v1028_10 = routine_107(c, v1025_11_head, v1025_6, v1025_11_tail);
          v1026_11 = compose(v1026_9,v1028_10);
        }
        const Space v1026_12 = unite(v1026_7,v1026_11);
        v1025_11_result = unite(v1025_11_result,v1026_12);
      }
      const Space v1025_11 = std::move(v1025_11_result);
      v1020_12 = compose(v1020_10,v1025_11);
    }
    const Space v1020_13 = unite(v1020_8,v1020_12);
    v1019_11_result = unite(v1019_11_result,v1020_13);
  }
  const Space v1019_11 = std::move(v1019_11_result);
  return v1019_11;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1029_12_result;
  for (int v1029_12_label = 1; v1029_12_label <= 2; ++v1029_12_label) {
    const Space v1029_12_tail = child(s0,v1029_12_label);
    if (v1029_12_tail.empty()) continue;
    const Path v1029_12_head{v1029_12_label};
    const Space v1030_2 = singleton(v1029_12_head);
    const Space v1030_3 = intersect(constant_8,v1030_2);
    const Space v1030_4 = (has_head(v1030_3) ? constant_9 : Space{});
    const Space v1030_5 = subtract(constant_0,v1030_4);
    Space v1030_8;
    if (!v1030_5.empty()) {
      const Path v1031_6 = concat_path(p0,v1029_12_head);
      Space v1031_7_result;
      for (int v1031_7_label = 1; v1031_7_label <= 2; ++v1031_7_label) {
        const Space v1031_7_tail = child(v1029_12_tail,v1031_7_label);
        if (v1031_7_tail.empty()) continue;
        const Path v1031_7_head{v1031_7_label};
        const Space v1032_2 = singleton(v1031_7_head);
        const Space v1032_3 = intersect(constant_8,v1032_2);
        const Space v1032_4 = (has_head(v1032_3) ? constant_9 : Space{});
        const Space v1032_5 = subtract(constant_0,v1032_4);
        Space v1032_8;
        if (!v1032_5.empty()) {
          const Path v1033_6 = concat_path(v1031_6,v1031_7_head);
          const Space v1033_7 = routine_191(c, v1033_6, p1, v1031_7_tail);
          v1032_8 = compose(v1032_5,v1033_7);
        }
        const Space v1032_9 = intersect(constant_8,v1032_2);
        const Space v1032_10 = (has_head(v1032_9) ? constant_9 : Space{});
        Space v1032_12;
        if (!v1032_10.empty()) {
          const Path v1034_6 = concat_path(v1031_6,v1031_7_head);
          const Space v1034_11 = routine_192(c, v1034_6, p1, v1031_7_tail);
          v1032_12 = compose(v1032_10,v1034_11);
        }
        const Space v1032_13 = unite(v1032_8,v1032_12);
        v1031_7_result = unite(v1031_7_result,v1032_13);
      }
      const Space v1031_7 = std::move(v1031_7_result);
      v1030_8 = compose(v1030_5,v1031_7);
    }
    const Space v1030_9 = intersect(constant_8,v1030_2);
    const Space v1030_10 = (has_head(v1030_9) ? constant_9 : Space{});
    Space v1030_12;
    if (!v1030_10.empty()) {
      const Path v1035_6 = concat_path(p0,v1029_12_head);
      Space v1035_11_result;
      for (int v1035_11_label = 1; v1035_11_label <= 2; ++v1035_11_label) {
        const Space v1035_11_tail = child(v1029_12_tail,v1035_11_label);
        if (v1035_11_tail.empty()) continue;
        const Path v1035_11_head{v1035_11_label};
        const Space v1036_2 = singleton(v1035_11_head);
        const Space v1036_3 = intersect(constant_8,v1036_2);
        const Space v1036_4 = (has_head(v1036_3) ? constant_9 : Space{});
        const Space v1036_5 = subtract(constant_0,v1036_4);
        Space v1036_8;
        if (!v1036_5.empty()) {
          const Path v1037_6 = concat_path(v1035_6,v1035_11_head);
          const Space v1037_7 = routine_191(c, v1037_6, p1, v1035_11_tail);
          v1036_8 = compose(v1036_5,v1037_7);
        }
        const Space v1036_9 = intersect(constant_8,v1036_2);
        const Space v1036_10 = (has_head(v1036_9) ? constant_9 : Space{});
        Space v1036_12;
        if (!v1036_10.empty()) {
          const Path v1038_6 = concat_path(v1035_6,v1035_11_head);
          const Space v1038_11 = routine_148(c, v1038_6, p1, v1035_11_tail);
          v1036_12 = compose(v1036_10,v1038_11);
        }
        const Space v1036_13 = unite(v1036_8,v1036_12);
        v1035_11_result = unite(v1035_11_result,v1036_13);
      }
      const Space v1035_11 = std::move(v1035_11_result);
      v1030_12 = compose(v1030_10,v1035_11);
    }
    const Space v1030_13 = unite(v1030_8,v1030_12);
    v1029_12_result = unite(v1029_12_result,v1030_13);
  }
  const Space v1029_12 = std::move(v1029_12_result);
  return v1029_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1039_12_result;
  for (int v1039_12_label = 1; v1039_12_label <= 2; ++v1039_12_label) {
    const Space v1039_12_tail = child(s0,v1039_12_label);
    if (v1039_12_tail.empty()) continue;
    const Path v1039_12_head{v1039_12_label};
    const Space v1040_2 = singleton(v1039_12_head);
    const Space v1040_3 = intersect(constant_8,v1040_2);
    const Space v1040_4 = (has_head(v1040_3) ? constant_9 : Space{});
    const Space v1040_5 = subtract(constant_0,v1040_4);
    Space v1040_8;
    if (!v1040_5.empty()) {
      const Path v1041_6 = concat_path(p0,v1039_12_head);
      Space v1041_7_result;
      for (int v1041_7_label = 1; v1041_7_label <= 2; ++v1041_7_label) {
        const Space v1041_7_tail = child(v1039_12_tail,v1041_7_label);
        if (v1041_7_tail.empty()) continue;
        const Path v1041_7_head{v1041_7_label};
        const Space v1042_2 = singleton(v1041_7_head);
        const Space v1042_3 = intersect(constant_8,v1042_2);
        const Space v1042_4 = (has_head(v1042_3) ? constant_9 : Space{});
        const Space v1042_5 = subtract(constant_0,v1042_4);
        Space v1042_8;
        if (!v1042_5.empty()) {
          const Path v1043_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1043_7 = routine_191(c, v1043_6, p1, v1041_7_tail);
          v1042_8 = compose(v1042_5,v1043_7);
        }
        const Space v1042_9 = intersect(constant_8,v1042_2);
        const Space v1042_10 = (has_head(v1042_9) ? constant_9 : Space{});
        Space v1042_12;
        if (!v1042_10.empty()) {
          const Path v1044_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1044_11 = routine_192(c, v1044_6, p1, v1041_7_tail);
          v1042_12 = compose(v1042_10,v1044_11);
        }
        const Space v1042_13 = unite(v1042_8,v1042_12);
        v1041_7_result = unite(v1041_7_result,v1042_13);
      }
      const Space v1041_7 = std::move(v1041_7_result);
      v1040_8 = compose(v1040_5,v1041_7);
    }
    const Space v1040_9 = intersect(constant_8,v1040_2);
    const Space v1040_10 = (has_head(v1040_9) ? constant_9 : Space{});
    Space v1040_12;
    if (!v1040_10.empty()) {
      const Path v1045_6 = concat_path(p0,v1039_12_head);
      Space v1045_11_result;
      for (int v1045_11_label = 1; v1045_11_label <= 2; ++v1045_11_label) {
        const Space v1045_11_tail = child(v1039_12_tail,v1045_11_label);
        if (v1045_11_tail.empty()) continue;
        const Path v1045_11_head{v1045_11_label};
        const Space v1046_2 = singleton(v1045_11_head);
        const Space v1046_3 = intersect(constant_8,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_9 : Space{});
        const Space v1046_5 = subtract(constant_0,v1046_4);
        Space v1046_7;
        if (!v1046_5.empty()) {
          const Space v1047_6 = routine_193(c, v1045_11_head, p1, v1045_6, v1045_11_tail);
          v1046_7 = compose(v1046_5,v1047_6);
        }
        const Space v1046_8 = intersect(constant_8,v1046_2);
        const Space v1046_9 = (has_head(v1046_8) ? constant_9 : Space{});
        Space v1046_11;
        if (!v1046_9.empty()) {
          const Space v1048_10 = routine_194(c, v1045_11_head, p1, v1045_6, v1045_11_tail);
          v1046_11 = compose(v1046_9,v1048_10);
        }
        const Space v1046_12 = unite(v1046_7,v1046_11);
        v1045_11_result = unite(v1045_11_result,v1046_12);
      }
      const Space v1045_11 = std::move(v1045_11_result);
      v1040_12 = compose(v1040_10,v1045_11);
    }
    const Space v1040_13 = unite(v1040_8,v1040_12);
    v1039_12_result = unite(v1039_12_result,v1040_13);
  }
  const Space v1039_12 = std::move(v1039_12_result);
  return v1039_12;
}

static Space routine_108(Context& c, const Path& p0, const Space& s0) {
  Space v1049_11_result;
  for (int v1049_11_label = 1; v1049_11_label <= 2; ++v1049_11_label) {
    const Space v1049_11_tail = child(s0,v1049_11_label);
    if (v1049_11_tail.empty()) continue;
    const Path v1049_11_head{v1049_11_label};
    const Space v1050_2 = singleton(v1049_11_head);
    const Space v1050_3 = intersect(constant_8,v1050_2);
    const Space v1050_4 = (has_head(v1050_3) ? constant_9 : Space{});
    const Space v1050_5 = subtract(constant_0,v1050_4);
    Space v1050_8;
    if (!v1050_5.empty()) {
      const Path v1051_6 = concat_path(p0,v1049_11_head);
      Space v1051_7_result;
      for (int v1051_7_label = 1; v1051_7_label <= 2; ++v1051_7_label) {
        const Space v1051_7_tail = child(v1049_11_tail,v1051_7_label);
        if (v1051_7_tail.empty()) continue;
        const Path v1051_7_head{v1051_7_label};
        const Space v1052_2 = singleton(v1051_7_head);
        const Space v1052_3 = intersect(constant_8,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_9 : Space{});
        const Space v1052_5 = subtract(constant_0,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1053_7 = routine_195(c, v1053_6, v1051_7_tail);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_8,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_9 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1054_11 = routine_196(c, v1054_6, v1051_7_tail);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_7_result = unite(v1051_7_result,v1052_13);
      }
      const Space v1051_7 = std::move(v1051_7_result);
      v1050_8 = compose(v1050_5,v1051_7);
    }
    const Space v1050_9 = intersect(constant_8,v1050_2);
    const Space v1050_10 = (has_head(v1050_9) ? constant_9 : Space{});
    Space v1050_12;
    if (!v1050_10.empty()) {
      const Path v1055_6 = concat_path(p0,v1049_11_head);
      Space v1055_11_result;
      for (int v1055_11_label = 1; v1055_11_label <= 2; ++v1055_11_label) {
        const Space v1055_11_tail = child(v1049_11_tail,v1055_11_label);
        if (v1055_11_tail.empty()) continue;
        const Path v1055_11_head{v1055_11_label};
        const Space v1056_2 = singleton(v1055_11_head);
        const Space v1056_3 = intersect(constant_8,v1056_2);
        const Space v1056_4 = (has_head(v1056_3) ? constant_9 : Space{});
        const Space v1056_5 = subtract(constant_0,v1056_4);
        Space v1056_8;
        if (!v1056_5.empty()) {
          const Path v1057_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1057_7 = routine_195(c, v1057_6, v1055_11_tail);
          v1056_8 = compose(v1056_5,v1057_7);
        }
        const Space v1056_9 = intersect(constant_8,v1056_2);
        const Space v1056_10 = (has_head(v1056_9) ? constant_9 : Space{});
        Space v1056_12;
        if (!v1056_10.empty()) {
          const Path v1058_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1058_11 = routine_74(c, v1058_6, v1055_11_tail);
          v1056_12 = compose(v1056_10,v1058_11);
        }
        const Space v1056_13 = unite(v1056_8,v1056_12);
        v1055_11_result = unite(v1055_11_result,v1056_13);
      }
      const Space v1055_11 = std::move(v1055_11_result);
      v1050_12 = compose(v1050_10,v1055_11);
    }
    const Space v1050_13 = unite(v1050_8,v1050_12);
    v1049_11_result = unite(v1049_11_result,v1050_13);
  }
  const Space v1049_11 = std::move(v1049_11_result);
  return v1049_11;
}

static Space routine_109(Context& c, const Path& p0, const Space& s0) {
  Space v1059_8_result;
  for (int v1059_8_label = 1; v1059_8_label <= 2; ++v1059_8_label) {
    const Space v1059_8_tail = child(s0,v1059_8_label);
    if (v1059_8_tail.empty()) continue;
    const Path v1059_8_head{v1059_8_label};
    const Space v1060_2 = singleton(v1059_8_head);
    const Space v1060_3 = intersect(constant_8,v1060_2);
    const Space v1060_4 = (has_head(v1060_3) ? constant_9 : Space{});
    const Space v1060_5 = subtract(constant_0,v1060_4);
    Space v1060_8;
    if (!v1060_5.empty()) {
      const Path v1061_6 = concat_path(p0,v1059_8_head);
      Space v1061_7_result;
      for (int v1061_7_label = 1; v1061_7_label <= 2; ++v1061_7_label) {
        const Space v1061_7_tail = child(v1059_8_tail,v1061_7_label);
        if (v1061_7_tail.empty()) continue;
        const Path v1061_7_head{v1061_7_label};
        const Space v1062_2 = singleton(v1061_7_head);
        const Space v1062_3 = intersect(constant_8,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_9 : Space{});
        const Space v1062_5 = subtract(constant_0,v1062_4);
        Space v1062_8;
        if (!v1062_5.empty()) {
          const Path v1063_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1063_7 = routine_195(c, v1063_6, v1061_7_tail);
          v1062_8 = compose(v1062_5,v1063_7);
        }
        const Space v1062_9 = intersect(constant_8,v1062_2);
        const Space v1062_10 = (has_head(v1062_9) ? constant_9 : Space{});
        Space v1062_12;
        if (!v1062_10.empty()) {
          const Path v1064_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1064_11 = routine_196(c, v1064_6, v1061_7_tail);
          v1062_12 = compose(v1062_10,v1064_11);
        }
        const Space v1062_13 = unite(v1062_8,v1062_12);
        v1061_7_result = unite(v1061_7_result,v1062_13);
      }
      const Space v1061_7 = std::move(v1061_7_result);
      v1060_8 = compose(v1060_5,v1061_7);
    }
    const Space v1060_9 = intersect(constant_8,v1060_2);
    const Space v1060_10 = (has_head(v1060_9) ? constant_9 : Space{});
    const Space v1060_11 = compose(v1060_10,v1059_8_tail);
    const Space v1060_12 = unite(v1060_8,v1060_11);
    v1059_8_result = unite(v1059_8_result,v1060_12);
  }
  const Space v1059_8 = std::move(v1059_8_result);
  return v1059_8;
}

static Space routine_110(Context& c, const Path& p0, const Space& s0) {
  Space v1065_11_result;
  for (int v1065_11_label = 1; v1065_11_label <= 2; ++v1065_11_label) {
    const Space v1065_11_tail = child(s0,v1065_11_label);
    if (v1065_11_tail.empty()) continue;
    const Path v1065_11_head{v1065_11_label};
    const Space v1066_2 = singleton(v1065_11_head);
    const Space v1066_3 = intersect(constant_8,v1066_2);
    const Space v1066_4 = (has_head(v1066_3) ? constant_9 : Space{});
    const Space v1066_5 = subtract(constant_0,v1066_4);
    Space v1066_8;
    if (!v1066_5.empty()) {
      const Path v1067_6 = concat_path(p0,v1065_11_head);
      Space v1067_7_result;
      for (int v1067_7_label = 1; v1067_7_label <= 2; ++v1067_7_label) {
        const Space v1067_7_tail = child(v1065_11_tail,v1067_7_label);
        if (v1067_7_tail.empty()) continue;
        const Path v1067_7_head{v1067_7_label};
        const Space v1068_2 = singleton(v1067_7_head);
        const Space v1068_3 = intersect(constant_8,v1068_2);
        const Space v1068_4 = (has_head(v1068_3) ? constant_9 : Space{});
        const Space v1068_5 = subtract(constant_0,v1068_4);
        Space v1068_8;
        if (!v1068_5.empty()) {
          const Path v1069_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1069_7 = routine_197(c, v1069_6, v1067_7_tail);
          v1068_8 = compose(v1068_5,v1069_7);
        }
        const Space v1068_9 = intersect(constant_8,v1068_2);
        const Space v1068_10 = (has_head(v1068_9) ? constant_9 : Space{});
        Space v1068_12;
        if (!v1068_10.empty()) {
          const Path v1070_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1070_11 = routine_198(c, v1070_6, v1067_7_tail);
          v1068_12 = compose(v1068_10,v1070_11);
        }
        const Space v1068_13 = unite(v1068_8,v1068_12);
        v1067_7_result = unite(v1067_7_result,v1068_13);
      }
      const Space v1067_7 = std::move(v1067_7_result);
      v1066_8 = compose(v1066_5,v1067_7);
    }
    const Space v1066_9 = intersect(constant_8,v1066_2);
    const Space v1066_10 = (has_head(v1066_9) ? constant_9 : Space{});
    Space v1066_12;
    if (!v1066_10.empty()) {
      const Path v1071_6 = concat_path(p0,v1065_11_head);
      Space v1071_11_result;
      for (int v1071_11_label = 1; v1071_11_label <= 2; ++v1071_11_label) {
        const Space v1071_11_tail = child(v1065_11_tail,v1071_11_label);
        if (v1071_11_tail.empty()) continue;
        const Path v1071_11_head{v1071_11_label};
        const Space v1072_2 = singleton(v1071_11_head);
        const Space v1072_3 = intersect(constant_8,v1072_2);
        const Space v1072_4 = (has_head(v1072_3) ? constant_9 : Space{});
        const Space v1072_5 = subtract(constant_0,v1072_4);
        Space v1072_8;
        if (!v1072_5.empty()) {
          const Path v1073_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1073_7 = routine_197(c, v1073_6, v1071_11_tail);
          v1072_8 = compose(v1072_5,v1073_7);
        }
        const Space v1072_9 = intersect(constant_8,v1072_2);
        const Space v1072_10 = (has_head(v1072_9) ? constant_9 : Space{});
        Space v1072_12;
        if (!v1072_10.empty()) {
          const Path v1074_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1074_11 = routine_77(c, v1074_6, v1071_11_tail);
          v1072_12 = compose(v1072_10,v1074_11);
        }
        const Space v1072_13 = unite(v1072_8,v1072_12);
        v1071_11_result = unite(v1071_11_result,v1072_13);
      }
      const Space v1071_11 = std::move(v1071_11_result);
      v1066_12 = compose(v1066_10,v1071_11);
    }
    const Space v1066_13 = unite(v1066_8,v1066_12);
    v1065_11_result = unite(v1065_11_result,v1066_13);
  }
  const Space v1065_11 = std::move(v1065_11_result);
  return v1065_11;
}

static Space routine_111(Context& c, const Path& p0, const Space& s0) {
  Space v1075_11_result;
  for (int v1075_11_label = 1; v1075_11_label <= 2; ++v1075_11_label) {
    const Space v1075_11_tail = child(s0,v1075_11_label);
    if (v1075_11_tail.empty()) continue;
    const Path v1075_11_head{v1075_11_label};
    const Space v1076_2 = singleton(v1075_11_head);
    const Space v1076_3 = intersect(constant_8,v1076_2);
    const Space v1076_4 = (has_head(v1076_3) ? constant_9 : Space{});
    const Space v1076_5 = subtract(constant_0,v1076_4);
    Space v1076_8;
    if (!v1076_5.empty()) {
      const Path v1077_6 = concat_path(p0,v1075_11_head);
      Space v1077_7_result;
      for (int v1077_7_label = 1; v1077_7_label <= 2; ++v1077_7_label) {
        const Space v1077_7_tail = child(v1075_11_tail,v1077_7_label);
        if (v1077_7_tail.empty()) continue;
        const Path v1077_7_head{v1077_7_label};
        const Space v1078_2 = singleton(v1077_7_head);
        const Space v1078_3 = intersect(constant_8,v1078_2);
        const Space v1078_4 = (has_head(v1078_3) ? constant_9 : Space{});
        const Space v1078_5 = subtract(constant_0,v1078_4);
        Space v1078_8;
        if (!v1078_5.empty()) {
          const Path v1079_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1079_7 = routine_197(c, v1079_6, v1077_7_tail);
          v1078_8 = compose(v1078_5,v1079_7);
        }
        const Space v1078_9 = intersect(constant_8,v1078_2);
        const Space v1078_10 = (has_head(v1078_9) ? constant_9 : Space{});
        Space v1078_12;
        if (!v1078_10.empty()) {
          const Path v1080_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1080_11 = routine_198(c, v1080_6, v1077_7_tail);
          v1078_12 = compose(v1078_10,v1080_11);
        }
        const Space v1078_13 = unite(v1078_8,v1078_12);
        v1077_7_result = unite(v1077_7_result,v1078_13);
      }
      const Space v1077_7 = std::move(v1077_7_result);
      v1076_8 = compose(v1076_5,v1077_7);
    }
    const Space v1076_9 = intersect(constant_8,v1076_2);
    const Space v1076_10 = (has_head(v1076_9) ? constant_9 : Space{});
    Space v1076_12;
    if (!v1076_10.empty()) {
      const Path v1081_6 = concat_path(p0,v1075_11_head);
      Space v1081_11_result;
      for (int v1081_11_label = 1; v1081_11_label <= 2; ++v1081_11_label) {
        const Space v1081_11_tail = child(v1075_11_tail,v1081_11_label);
        if (v1081_11_tail.empty()) continue;
        const Path v1081_11_head{v1081_11_label};
        const Space v1082_2 = singleton(v1081_11_head);
        const Space v1082_3 = intersect(constant_8,v1082_2);
        const Space v1082_4 = (has_head(v1082_3) ? constant_9 : Space{});
        const Space v1082_5 = subtract(constant_0,v1082_4);
        Space v1082_7;
        if (!v1082_5.empty()) {
          const Space v1083_6 = routine_112(c, v1081_11_head, v1081_6, v1081_11_tail);
          v1082_7 = compose(v1082_5,v1083_6);
        }
        const Space v1082_8 = intersect(constant_8,v1082_2);
        const Space v1082_9 = (has_head(v1082_8) ? constant_9 : Space{});
        Space v1082_11;
        if (!v1082_9.empty()) {
          const Space v1084_10 = routine_113(c, v1081_11_head, v1081_6, v1081_11_tail);
          v1082_11 = compose(v1082_9,v1084_10);
        }
        const Space v1082_12 = unite(v1082_7,v1082_11);
        v1081_11_result = unite(v1081_11_result,v1082_12);
      }
      const Space v1081_11 = std::move(v1081_11_result);
      v1076_12 = compose(v1076_10,v1081_11);
    }
    const Space v1076_13 = unite(v1076_8,v1076_12);
    v1075_11_result = unite(v1075_11_result,v1076_13);
  }
  const Space v1075_11 = std::move(v1075_11_result);
  return v1075_11;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1085_12_result;
  for (int v1085_12_label = 1; v1085_12_label <= 2; ++v1085_12_label) {
    const Space v1085_12_tail = child(s0,v1085_12_label);
    if (v1085_12_tail.empty()) continue;
    const Path v1085_12_head{v1085_12_label};
    const Space v1086_2 = singleton(v1085_12_head);
    const Space v1086_3 = intersect(constant_8,v1086_2);
    const Space v1086_4 = (has_head(v1086_3) ? constant_9 : Space{});
    const Space v1086_5 = subtract(constant_0,v1086_4);
    Space v1086_8;
    if (!v1086_5.empty()) {
      const Path v1087_6 = concat_path(p0,v1085_12_head);
      Space v1087_7_result;
      for (int v1087_7_label = 1; v1087_7_label <= 2; ++v1087_7_label) {
        const Space v1087_7_tail = child(v1085_12_tail,v1087_7_label);
        if (v1087_7_tail.empty()) continue;
        const Path v1087_7_head{v1087_7_label};
        const Space v1088_2 = singleton(v1087_7_head);
        const Space v1088_3 = intersect(constant_8,v1088_2);
        const Space v1088_4 = (has_head(v1088_3) ? constant_9 : Space{});
        const Space v1088_5 = subtract(constant_0,v1088_4);
        Space v1088_8;
        if (!v1088_5.empty()) {
          const Path v1089_6 = concat_path(v1087_6,v1087_7_head);
          const Space v1089_7 = routine_199(c, v1089_6, p1, v1087_7_tail);
          v1088_8 = compose(v1088_5,v1089_7);
        }
        const Space v1088_9 = intersect(constant_8,v1088_2);
        const Space v1088_10 = (has_head(v1088_9) ? constant_9 : Space{});
        Space v1088_12;
        if (!v1088_10.empty()) {
          const Path v1090_6 = concat_path(v1087_6,v1087_7_head);
          const Space v1090_11 = routine_200(c, v1090_6, p1, v1087_7_tail);
          v1088_12 = compose(v1088_10,v1090_11);
        }
        const Space v1088_13 = unite(v1088_8,v1088_12);
        v1087_7_result = unite(v1087_7_result,v1088_13);
      }
      const Space v1087_7 = std::move(v1087_7_result);
      v1086_8 = compose(v1086_5,v1087_7);
    }
    const Space v1086_9 = intersect(constant_8,v1086_2);
    const Space v1086_10 = (has_head(v1086_9) ? constant_9 : Space{});
    Space v1086_12;
    if (!v1086_10.empty()) {
      const Path v1091_6 = concat_path(p0,v1085_12_head);
      Space v1091_11_result;
      for (int v1091_11_label = 1; v1091_11_label <= 2; ++v1091_11_label) {
        const Space v1091_11_tail = child(v1085_12_tail,v1091_11_label);
        if (v1091_11_tail.empty()) continue;
        const Path v1091_11_head{v1091_11_label};
        const Space v1092_2 = singleton(v1091_11_head);
        const Space v1092_3 = intersect(constant_8,v1092_2);
        const Space v1092_4 = (has_head(v1092_3) ? constant_9 : Space{});
        const Space v1092_5 = subtract(constant_0,v1092_4);
        Space v1092_8;
        if (!v1092_5.empty()) {
          const Path v1093_6 = concat_path(v1091_6,v1091_11_head);
          const Space v1093_7 = routine_199(c, v1093_6, p1, v1091_11_tail);
          v1092_8 = compose(v1092_5,v1093_7);
        }
        const Space v1092_9 = intersect(constant_8,v1092_2);
        const Space v1092_10 = (has_head(v1092_9) ? constant_9 : Space{});
        Space v1092_12;
        if (!v1092_10.empty()) {
          const Path v1094_6 = concat_path(v1091_6,v1091_11_head);
          const Space v1094_11 = routine_155(c, v1094_6, p1, v1091_11_tail);
          v1092_12 = compose(v1092_10,v1094_11);
        }
        const Space v1092_13 = unite(v1092_8,v1092_12);
        v1091_11_result = unite(v1091_11_result,v1092_13);
      }
      const Space v1091_11 = std::move(v1091_11_result);
      v1086_12 = compose(v1086_10,v1091_11);
    }
    const Space v1086_13 = unite(v1086_8,v1086_12);
    v1085_12_result = unite(v1085_12_result,v1086_13);
  }
  const Space v1085_12 = std::move(v1085_12_result);
  return v1085_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1095_12_result;
  for (int v1095_12_label = 1; v1095_12_label <= 2; ++v1095_12_label) {
    const Space v1095_12_tail = child(s0,v1095_12_label);
    if (v1095_12_tail.empty()) continue;
    const Path v1095_12_head{v1095_12_label};
    const Space v1096_2 = singleton(v1095_12_head);
    const Space v1096_3 = intersect(constant_8,v1096_2);
    const Space v1096_4 = (has_head(v1096_3) ? constant_9 : Space{});
    const Space v1096_5 = subtract(constant_0,v1096_4);
    Space v1096_8;
    if (!v1096_5.empty()) {
      const Path v1097_6 = concat_path(p0,v1095_12_head);
      Space v1097_7_result;
      for (int v1097_7_label = 1; v1097_7_label <= 2; ++v1097_7_label) {
        const Space v1097_7_tail = child(v1095_12_tail,v1097_7_label);
        if (v1097_7_tail.empty()) continue;
        const Path v1097_7_head{v1097_7_label};
        const Space v1098_2 = singleton(v1097_7_head);
        const Space v1098_3 = intersect(constant_8,v1098_2);
        const Space v1098_4 = (has_head(v1098_3) ? constant_9 : Space{});
        const Space v1098_5 = subtract(constant_0,v1098_4);
        Space v1098_8;
        if (!v1098_5.empty()) {
          const Path v1099_6 = concat_path(v1097_6,v1097_7_head);
          const Space v1099_7 = routine_199(c, v1099_6, p1, v1097_7_tail);
          v1098_8 = compose(v1098_5,v1099_7);
        }
        const Space v1098_9 = intersect(constant_8,v1098_2);
        const Space v1098_10 = (has_head(v1098_9) ? constant_9 : Space{});
        Space v1098_12;
        if (!v1098_10.empty()) {
          const Path v1100_6 = concat_path(v1097_6,v1097_7_head);
          const Space v1100_11 = routine_200(c, v1100_6, p1, v1097_7_tail);
          v1098_12 = compose(v1098_10,v1100_11);
        }
        const Space v1098_13 = unite(v1098_8,v1098_12);
        v1097_7_result = unite(v1097_7_result,v1098_13);
      }
      const Space v1097_7 = std::move(v1097_7_result);
      v1096_8 = compose(v1096_5,v1097_7);
    }
    const Space v1096_9 = intersect(constant_8,v1096_2);
    const Space v1096_10 = (has_head(v1096_9) ? constant_9 : Space{});
    Space v1096_12;
    if (!v1096_10.empty()) {
      const Path v1101_6 = concat_path(p0,v1095_12_head);
      Space v1101_11_result;
      for (int v1101_11_label = 1; v1101_11_label <= 2; ++v1101_11_label) {
        const Space v1101_11_tail = child(v1095_12_tail,v1101_11_label);
        if (v1101_11_tail.empty()) continue;
        const Path v1101_11_head{v1101_11_label};
        const Space v1102_2 = singleton(v1101_11_head);
        const Space v1102_3 = intersect(constant_8,v1102_2);
        const Space v1102_4 = (has_head(v1102_3) ? constant_9 : Space{});
        const Space v1102_5 = subtract(constant_0,v1102_4);
        Space v1102_7;
        if (!v1102_5.empty()) {
          const Space v1103_6 = routine_201(c, v1101_11_head, p1, v1101_6, v1101_11_tail);
          v1102_7 = compose(v1102_5,v1103_6);
        }
        const Space v1102_8 = intersect(constant_8,v1102_2);
        const Space v1102_9 = (has_head(v1102_8) ? constant_9 : Space{});
        Space v1102_11;
        if (!v1102_9.empty()) {
          const Space v1104_10 = routine_202(c, v1101_11_head, p1, v1101_6, v1101_11_tail);
          v1102_11 = compose(v1102_9,v1104_10);
        }
        const Space v1102_12 = unite(v1102_7,v1102_11);
        v1101_11_result = unite(v1101_11_result,v1102_12);
      }
      const Space v1101_11 = std::move(v1101_11_result);
      v1096_12 = compose(v1096_10,v1101_11);
    }
    const Space v1096_13 = unite(v1096_8,v1096_12);
    v1095_12_result = unite(v1095_12_result,v1096_13);
  }
  const Space v1095_12 = std::move(v1095_12_result);
  return v1095_12;
}

static Space routine_114(Context& c, const Path& p0, const Space& s0) {
  Space v1105_11_result;
  for (int v1105_11_label = 1; v1105_11_label <= 2; ++v1105_11_label) {
    const Space v1105_11_tail = child(s0,v1105_11_label);
    if (v1105_11_tail.empty()) continue;
    const Path v1105_11_head{v1105_11_label};
    const Space v1106_2 = singleton(v1105_11_head);
    const Space v1106_3 = intersect(constant_8,v1106_2);
    const Space v1106_4 = (has_head(v1106_3) ? constant_9 : Space{});
    const Space v1106_5 = subtract(constant_0,v1106_4);
    Space v1106_8;
    if (!v1106_5.empty()) {
      const Path v1107_6 = concat_path(p0,v1105_11_head);
      Space v1107_7_result;
      for (int v1107_7_label = 1; v1107_7_label <= 2; ++v1107_7_label) {
        const Space v1107_7_tail = child(v1105_11_tail,v1107_7_label);
        if (v1107_7_tail.empty()) continue;
        const Path v1107_7_head{v1107_7_label};
        const Space v1108_2 = singleton(v1107_7_head);
        const Space v1108_3 = intersect(constant_8,v1108_2);
        const Space v1108_4 = (has_head(v1108_3) ? constant_9 : Space{});
        const Space v1108_5 = subtract(constant_0,v1108_4);
        Space v1108_8;
        if (!v1108_5.empty()) {
          const Path v1109_6 = concat_path(v1107_6,v1107_7_head);
          const Space v1109_7 = routine_203(c, v1109_6, v1107_7_tail);
          v1108_8 = compose(v1108_5,v1109_7);
        }
        const Space v1108_9 = intersect(constant_8,v1108_2);
        const Space v1108_10 = (has_head(v1108_9) ? constant_9 : Space{});
        Space v1108_12;
        if (!v1108_10.empty()) {
          const Path v1110_6 = concat_path(v1107_6,v1107_7_head);
          const Space v1110_11 = routine_204(c, v1110_6, v1107_7_tail);
          v1108_12 = compose(v1108_10,v1110_11);
        }
        const Space v1108_13 = unite(v1108_8,v1108_12);
        v1107_7_result = unite(v1107_7_result,v1108_13);
      }
      const Space v1107_7 = std::move(v1107_7_result);
      v1106_8 = compose(v1106_5,v1107_7);
    }
    const Space v1106_9 = intersect(constant_8,v1106_2);
    const Space v1106_10 = (has_head(v1106_9) ? constant_9 : Space{});
    Space v1106_12;
    if (!v1106_10.empty()) {
      const Path v1111_6 = concat_path(p0,v1105_11_head);
      Space v1111_11_result;
      for (int v1111_11_label = 1; v1111_11_label <= 2; ++v1111_11_label) {
        const Space v1111_11_tail = child(v1105_11_tail,v1111_11_label);
        if (v1111_11_tail.empty()) continue;
        const Path v1111_11_head{v1111_11_label};
        const Space v1112_2 = singleton(v1111_11_head);
        const Space v1112_3 = intersect(constant_8,v1112_2);
        const Space v1112_4 = (has_head(v1112_3) ? constant_9 : Space{});
        const Space v1112_5 = subtract(constant_0,v1112_4);
        Space v1112_8;
        if (!v1112_5.empty()) {
          const Path v1113_6 = concat_path(v1111_6,v1111_11_head);
          const Space v1113_7 = routine_203(c, v1113_6, v1111_11_tail);
          v1112_8 = compose(v1112_5,v1113_7);
        }
        const Space v1112_9 = intersect(constant_8,v1112_2);
        const Space v1112_10 = (has_head(v1112_9) ? constant_9 : Space{});
        Space v1112_12;
        if (!v1112_10.empty()) {
          const Path v1114_6 = concat_path(v1111_6,v1111_11_head);
          const Space v1114_11 = routine_80(c, v1114_6, v1111_11_tail);
          v1112_12 = compose(v1112_10,v1114_11);
        }
        const Space v1112_13 = unite(v1112_8,v1112_12);
        v1111_11_result = unite(v1111_11_result,v1112_13);
      }
      const Space v1111_11 = std::move(v1111_11_result);
      v1106_12 = compose(v1106_10,v1111_11);
    }
    const Space v1106_13 = unite(v1106_8,v1106_12);
    v1105_11_result = unite(v1105_11_result,v1106_13);
  }
  const Space v1105_11 = std::move(v1105_11_result);
  return v1105_11;
}

static Space routine_115(Context& c, const Path& p0, const Space& s0) {
  Space v1115_8_result;
  for (int v1115_8_label = 1; v1115_8_label <= 2; ++v1115_8_label) {
    const Space v1115_8_tail = child(s0,v1115_8_label);
    if (v1115_8_tail.empty()) continue;
    const Path v1115_8_head{v1115_8_label};
    const Space v1116_2 = singleton(v1115_8_head);
    const Space v1116_3 = intersect(constant_8,v1116_2);
    const Space v1116_4 = (has_head(v1116_3) ? constant_9 : Space{});
    const Space v1116_5 = subtract(constant_0,v1116_4);
    Space v1116_8;
    if (!v1116_5.empty()) {
      const Path v1117_6 = concat_path(p0,v1115_8_head);
      Space v1117_7_result;
      for (int v1117_7_label = 1; v1117_7_label <= 2; ++v1117_7_label) {
        const Space v1117_7_tail = child(v1115_8_tail,v1117_7_label);
        if (v1117_7_tail.empty()) continue;
        const Path v1117_7_head{v1117_7_label};
        const Space v1118_2 = singleton(v1117_7_head);
        const Space v1118_3 = intersect(constant_8,v1118_2);
        const Space v1118_4 = (has_head(v1118_3) ? constant_9 : Space{});
        const Space v1118_5 = subtract(constant_0,v1118_4);
        Space v1118_8;
        if (!v1118_5.empty()) {
          const Path v1119_6 = concat_path(v1117_6,v1117_7_head);
          const Space v1119_7 = routine_203(c, v1119_6, v1117_7_tail);
          v1118_8 = compose(v1118_5,v1119_7);
        }
        const Space v1118_9 = intersect(constant_8,v1118_2);
        const Space v1118_10 = (has_head(v1118_9) ? constant_9 : Space{});
        Space v1118_12;
        if (!v1118_10.empty()) {
          const Path v1120_6 = concat_path(v1117_6,v1117_7_head);
          const Space v1120_11 = routine_204(c, v1120_6, v1117_7_tail);
          v1118_12 = compose(v1118_10,v1120_11);
        }
        const Space v1118_13 = unite(v1118_8,v1118_12);
        v1117_7_result = unite(v1117_7_result,v1118_13);
      }
      const Space v1117_7 = std::move(v1117_7_result);
      v1116_8 = compose(v1116_5,v1117_7);
    }
    const Space v1116_9 = intersect(constant_8,v1116_2);
    const Space v1116_10 = (has_head(v1116_9) ? constant_9 : Space{});
    const Space v1116_11 = compose(v1116_10,v1115_8_tail);
    const Space v1116_12 = unite(v1116_8,v1116_11);
    v1115_8_result = unite(v1115_8_result,v1116_12);
  }
  const Space v1115_8 = std::move(v1115_8_result);
  return v1115_8;
}

static Space routine_116(Context& c, const Path& p0, const Space& s0) {
  Space v1121_11_result;
  for (int v1121_11_label = 1; v1121_11_label <= 2; ++v1121_11_label) {
    const Space v1121_11_tail = child(s0,v1121_11_label);
    if (v1121_11_tail.empty()) continue;
    const Path v1121_11_head{v1121_11_label};
    const Space v1122_2 = singleton(v1121_11_head);
    const Space v1122_3 = intersect(constant_8,v1122_2);
    const Space v1122_4 = (has_head(v1122_3) ? constant_9 : Space{});
    const Space v1122_5 = subtract(constant_0,v1122_4);
    Space v1122_8;
    if (!v1122_5.empty()) {
      const Path v1123_6 = concat_path(p0,v1121_11_head);
      Space v1123_7_result;
      for (int v1123_7_label = 1; v1123_7_label <= 2; ++v1123_7_label) {
        const Space v1123_7_tail = child(v1121_11_tail,v1123_7_label);
        if (v1123_7_tail.empty()) continue;
        const Path v1123_7_head{v1123_7_label};
        const Space v1124_2 = singleton(v1123_7_head);
        const Space v1124_3 = intersect(constant_8,v1124_2);
        const Space v1124_4 = (has_head(v1124_3) ? constant_9 : Space{});
        const Space v1124_5 = subtract(constant_0,v1124_4);
        Space v1124_8;
        if (!v1124_5.empty()) {
          const Path v1125_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1125_7 = routine_205(c, v1125_6, v1123_7_tail);
          v1124_8 = compose(v1124_5,v1125_7);
        }
        const Space v1124_9 = intersect(constant_8,v1124_2);
        const Space v1124_10 = (has_head(v1124_9) ? constant_9 : Space{});
        Space v1124_12;
        if (!v1124_10.empty()) {
          const Path v1126_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1126_11 = routine_206(c, v1126_6, v1123_7_tail);
          v1124_12 = compose(v1124_10,v1126_11);
        }
        const Space v1124_13 = unite(v1124_8,v1124_12);
        v1123_7_result = unite(v1123_7_result,v1124_13);
      }
      const Space v1123_7 = std::move(v1123_7_result);
      v1122_8 = compose(v1122_5,v1123_7);
    }
    const Space v1122_9 = intersect(constant_8,v1122_2);
    const Space v1122_10 = (has_head(v1122_9) ? constant_9 : Space{});
    Space v1122_12;
    if (!v1122_10.empty()) {
      const Path v1127_6 = concat_path(p0,v1121_11_head);
      Space v1127_11_result;
      for (int v1127_11_label = 1; v1127_11_label <= 2; ++v1127_11_label) {
        const Space v1127_11_tail = child(v1121_11_tail,v1127_11_label);
        if (v1127_11_tail.empty()) continue;
        const Path v1127_11_head{v1127_11_label};
        const Space v1128_2 = singleton(v1127_11_head);
        const Space v1128_3 = intersect(constant_8,v1128_2);
        const Space v1128_4 = (has_head(v1128_3) ? constant_9 : Space{});
        const Space v1128_5 = subtract(constant_0,v1128_4);
        Space v1128_8;
        if (!v1128_5.empty()) {
          const Path v1129_6 = concat_path(v1127_6,v1127_11_head);
          const Space v1129_7 = routine_205(c, v1129_6, v1127_11_tail);
          v1128_8 = compose(v1128_5,v1129_7);
        }
        const Space v1128_9 = intersect(constant_8,v1128_2);
        const Space v1128_10 = (has_head(v1128_9) ? constant_9 : Space{});
        Space v1128_12;
        if (!v1128_10.empty()) {
          const Path v1130_6 = concat_path(v1127_6,v1127_11_head);
          const Space v1130_11 = routine_83(c, v1130_6, v1127_11_tail);
          v1128_12 = compose(v1128_10,v1130_11);
        }
        const Space v1128_13 = unite(v1128_8,v1128_12);
        v1127_11_result = unite(v1127_11_result,v1128_13);
      }
      const Space v1127_11 = std::move(v1127_11_result);
      v1122_12 = compose(v1122_10,v1127_11);
    }
    const Space v1122_13 = unite(v1122_8,v1122_12);
    v1121_11_result = unite(v1121_11_result,v1122_13);
  }
  const Space v1121_11 = std::move(v1121_11_result);
  return v1121_11;
}

static Space routine_117(Context& c, const Path& p0, const Space& s0) {
  Space v1131_11_result;
  for (int v1131_11_label = 1; v1131_11_label <= 2; ++v1131_11_label) {
    const Space v1131_11_tail = child(s0,v1131_11_label);
    if (v1131_11_tail.empty()) continue;
    const Path v1131_11_head{v1131_11_label};
    const Space v1132_2 = singleton(v1131_11_head);
    const Space v1132_3 = intersect(constant_8,v1132_2);
    const Space v1132_4 = (has_head(v1132_3) ? constant_9 : Space{});
    const Space v1132_5 = subtract(constant_0,v1132_4);
    Space v1132_8;
    if (!v1132_5.empty()) {
      const Path v1133_6 = concat_path(p0,v1131_11_head);
      Space v1133_7_result;
      for (int v1133_7_label = 1; v1133_7_label <= 2; ++v1133_7_label) {
        const Space v1133_7_tail = child(v1131_11_tail,v1133_7_label);
        if (v1133_7_tail.empty()) continue;
        const Path v1133_7_head{v1133_7_label};
        const Space v1134_2 = singleton(v1133_7_head);
        const Space v1134_3 = intersect(constant_8,v1134_2);
        const Space v1134_4 = (has_head(v1134_3) ? constant_9 : Space{});
        const Space v1134_5 = subtract(constant_0,v1134_4);
        Space v1134_8;
        if (!v1134_5.empty()) {
          const Path v1135_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1135_7 = routine_205(c, v1135_6, v1133_7_tail);
          v1134_8 = compose(v1134_5,v1135_7);
        }
        const Space v1134_9 = intersect(constant_8,v1134_2);
        const Space v1134_10 = (has_head(v1134_9) ? constant_9 : Space{});
        Space v1134_12;
        if (!v1134_10.empty()) {
          const Path v1136_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1136_11 = routine_206(c, v1136_6, v1133_7_tail);
          v1134_12 = compose(v1134_10,v1136_11);
        }
        const Space v1134_13 = unite(v1134_8,v1134_12);
        v1133_7_result = unite(v1133_7_result,v1134_13);
      }
      const Space v1133_7 = std::move(v1133_7_result);
      v1132_8 = compose(v1132_5,v1133_7);
    }
    const Space v1132_9 = intersect(constant_8,v1132_2);
    const Space v1132_10 = (has_head(v1132_9) ? constant_9 : Space{});
    Space v1132_12;
    if (!v1132_10.empty()) {
      const Path v1137_6 = concat_path(p0,v1131_11_head);
      Space v1137_11_result;
      for (int v1137_11_label = 1; v1137_11_label <= 2; ++v1137_11_label) {
        const Space v1137_11_tail = child(v1131_11_tail,v1137_11_label);
        if (v1137_11_tail.empty()) continue;
        const Path v1137_11_head{v1137_11_label};
        const Space v1138_2 = singleton(v1137_11_head);
        const Space v1138_3 = intersect(constant_8,v1138_2);
        const Space v1138_4 = (has_head(v1138_3) ? constant_9 : Space{});
        const Space v1138_5 = subtract(constant_0,v1138_4);
        Space v1138_7;
        if (!v1138_5.empty()) {
          const Space v1139_6 = routine_118(c, v1137_11_head, v1137_6, v1137_11_tail);
          v1138_7 = compose(v1138_5,v1139_6);
        }
        const Space v1138_8 = intersect(constant_8,v1138_2);
        const Space v1138_9 = (has_head(v1138_8) ? constant_9 : Space{});
        Space v1138_11;
        if (!v1138_9.empty()) {
          const Space v1140_10 = routine_119(c, v1137_11_head, v1137_6, v1137_11_tail);
          v1138_11 = compose(v1138_9,v1140_10);
        }
        const Space v1138_12 = unite(v1138_7,v1138_11);
        v1137_11_result = unite(v1137_11_result,v1138_12);
      }
      const Space v1137_11 = std::move(v1137_11_result);
      v1132_12 = compose(v1132_10,v1137_11);
    }
    const Space v1132_13 = unite(v1132_8,v1132_12);
    v1131_11_result = unite(v1131_11_result,v1132_13);
  }
  const Space v1131_11 = std::move(v1131_11_result);
  return v1131_11;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1141_12_result;
  for (int v1141_12_label = 1; v1141_12_label <= 2; ++v1141_12_label) {
    const Space v1141_12_tail = child(s0,v1141_12_label);
    if (v1141_12_tail.empty()) continue;
    const Path v1141_12_head{v1141_12_label};
    const Space v1142_2 = singleton(v1141_12_head);
    const Space v1142_3 = intersect(constant_8,v1142_2);
    const Space v1142_4 = (has_head(v1142_3) ? constant_9 : Space{});
    const Space v1142_5 = subtract(constant_0,v1142_4);
    Space v1142_8;
    if (!v1142_5.empty()) {
      const Path v1143_6 = concat_path(p0,v1141_12_head);
      Space v1143_7_result;
      for (int v1143_7_label = 1; v1143_7_label <= 2; ++v1143_7_label) {
        const Space v1143_7_tail = child(v1141_12_tail,v1143_7_label);
        if (v1143_7_tail.empty()) continue;
        const Path v1143_7_head{v1143_7_label};
        const Space v1144_2 = singleton(v1143_7_head);
        const Space v1144_3 = intersect(constant_8,v1144_2);
        const Space v1144_4 = (has_head(v1144_3) ? constant_9 : Space{});
        const Space v1144_5 = subtract(constant_0,v1144_4);
        Space v1144_8;
        if (!v1144_5.empty()) {
          const Path v1145_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1145_7 = routine_207(c, v1145_6, p1, v1143_7_tail);
          v1144_8 = compose(v1144_5,v1145_7);
        }
        const Space v1144_9 = intersect(constant_8,v1144_2);
        const Space v1144_10 = (has_head(v1144_9) ? constant_9 : Space{});
        Space v1144_12;
        if (!v1144_10.empty()) {
          const Path v1146_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1146_11 = routine_208(c, v1146_6, p1, v1143_7_tail);
          v1144_12 = compose(v1144_10,v1146_11);
        }
        const Space v1144_13 = unite(v1144_8,v1144_12);
        v1143_7_result = unite(v1143_7_result,v1144_13);
      }
      const Space v1143_7 = std::move(v1143_7_result);
      v1142_8 = compose(v1142_5,v1143_7);
    }
    const Space v1142_9 = intersect(constant_8,v1142_2);
    const Space v1142_10 = (has_head(v1142_9) ? constant_9 : Space{});
    Space v1142_12;
    if (!v1142_10.empty()) {
      const Path v1147_6 = concat_path(p0,v1141_12_head);
      Space v1147_11_result;
      for (int v1147_11_label = 1; v1147_11_label <= 2; ++v1147_11_label) {
        const Space v1147_11_tail = child(v1141_12_tail,v1147_11_label);
        if (v1147_11_tail.empty()) continue;
        const Path v1147_11_head{v1147_11_label};
        const Space v1148_2 = singleton(v1147_11_head);
        const Space v1148_3 = intersect(constant_8,v1148_2);
        const Space v1148_4 = (has_head(v1148_3) ? constant_9 : Space{});
        const Space v1148_5 = subtract(constant_0,v1148_4);
        Space v1148_8;
        if (!v1148_5.empty()) {
          const Path v1149_6 = concat_path(v1147_6,v1147_11_head);
          const Space v1149_7 = routine_207(c, v1149_6, p1, v1147_11_tail);
          v1148_8 = compose(v1148_5,v1149_7);
        }
        const Space v1148_9 = intersect(constant_8,v1148_2);
        const Space v1148_10 = (has_head(v1148_9) ? constant_9 : Space{});
        Space v1148_12;
        if (!v1148_10.empty()) {
          const Path v1150_6 = concat_path(v1147_6,v1147_11_head);
          const Space v1150_11 = routine_162(c, v1150_6, p1, v1147_11_tail);
          v1148_12 = compose(v1148_10,v1150_11);
        }
        const Space v1148_13 = unite(v1148_8,v1148_12);
        v1147_11_result = unite(v1147_11_result,v1148_13);
      }
      const Space v1147_11 = std::move(v1147_11_result);
      v1142_12 = compose(v1142_10,v1147_11);
    }
    const Space v1142_13 = unite(v1142_8,v1142_12);
    v1141_12_result = unite(v1141_12_result,v1142_13);
  }
  const Space v1141_12 = std::move(v1141_12_result);
  return v1141_12;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1151_12_result;
  for (int v1151_12_label = 1; v1151_12_label <= 2; ++v1151_12_label) {
    const Space v1151_12_tail = child(s0,v1151_12_label);
    if (v1151_12_tail.empty()) continue;
    const Path v1151_12_head{v1151_12_label};
    const Space v1152_2 = singleton(v1151_12_head);
    const Space v1152_3 = intersect(constant_8,v1152_2);
    const Space v1152_4 = (has_head(v1152_3) ? constant_9 : Space{});
    const Space v1152_5 = subtract(constant_0,v1152_4);
    Space v1152_8;
    if (!v1152_5.empty()) {
      const Path v1153_6 = concat_path(p0,v1151_12_head);
      Space v1153_7_result;
      for (int v1153_7_label = 1; v1153_7_label <= 2; ++v1153_7_label) {
        const Space v1153_7_tail = child(v1151_12_tail,v1153_7_label);
        if (v1153_7_tail.empty()) continue;
        const Path v1153_7_head{v1153_7_label};
        const Space v1154_2 = singleton(v1153_7_head);
        const Space v1154_3 = intersect(constant_8,v1154_2);
        const Space v1154_4 = (has_head(v1154_3) ? constant_9 : Space{});
        const Space v1154_5 = subtract(constant_0,v1154_4);
        Space v1154_8;
        if (!v1154_5.empty()) {
          const Path v1155_6 = concat_path(v1153_6,v1153_7_head);
          const Space v1155_7 = routine_207(c, v1155_6, p1, v1153_7_tail);
          v1154_8 = compose(v1154_5,v1155_7);
        }
        const Space v1154_9 = intersect(constant_8,v1154_2);
        const Space v1154_10 = (has_head(v1154_9) ? constant_9 : Space{});
        Space v1154_12;
        if (!v1154_10.empty()) {
          const Path v1156_6 = concat_path(v1153_6,v1153_7_head);
          const Space v1156_11 = routine_208(c, v1156_6, p1, v1153_7_tail);
          v1154_12 = compose(v1154_10,v1156_11);
        }
        const Space v1154_13 = unite(v1154_8,v1154_12);
        v1153_7_result = unite(v1153_7_result,v1154_13);
      }
      const Space v1153_7 = std::move(v1153_7_result);
      v1152_8 = compose(v1152_5,v1153_7);
    }
    const Space v1152_9 = intersect(constant_8,v1152_2);
    const Space v1152_10 = (has_head(v1152_9) ? constant_9 : Space{});
    Space v1152_12;
    if (!v1152_10.empty()) {
      const Path v1157_6 = concat_path(p0,v1151_12_head);
      Space v1157_11_result;
      for (int v1157_11_label = 1; v1157_11_label <= 2; ++v1157_11_label) {
        const Space v1157_11_tail = child(v1151_12_tail,v1157_11_label);
        if (v1157_11_tail.empty()) continue;
        const Path v1157_11_head{v1157_11_label};
        const Space v1158_2 = singleton(v1157_11_head);
        const Space v1158_3 = intersect(constant_8,v1158_2);
        const Space v1158_4 = (has_head(v1158_3) ? constant_9 : Space{});
        const Space v1158_5 = subtract(constant_0,v1158_4);
        Space v1158_7;
        if (!v1158_5.empty()) {
          const Space v1159_6 = routine_209(c, v1157_11_head, p1, v1157_6, v1157_11_tail);
          v1158_7 = compose(v1158_5,v1159_6);
        }
        const Space v1158_8 = intersect(constant_8,v1158_2);
        const Space v1158_9 = (has_head(v1158_8) ? constant_9 : Space{});
        Space v1158_11;
        if (!v1158_9.empty()) {
          const Space v1160_10 = routine_210(c, v1157_11_head, p1, v1157_6, v1157_11_tail);
          v1158_11 = compose(v1158_9,v1160_10);
        }
        const Space v1158_12 = unite(v1158_7,v1158_11);
        v1157_11_result = unite(v1157_11_result,v1158_12);
      }
      const Space v1157_11 = std::move(v1157_11_result);
      v1152_12 = compose(v1152_10,v1157_11);
    }
    const Space v1152_13 = unite(v1152_8,v1152_12);
    v1151_12_result = unite(v1151_12_result,v1152_13);
  }
  const Space v1151_12 = std::move(v1151_12_result);
  return v1151_12;
}

static Space routine_120(Context& c, const Path& p0, const Space& s0) {
  Space v1161_11_result;
  for (int v1161_11_label = 1; v1161_11_label <= 2; ++v1161_11_label) {
    const Space v1161_11_tail = child(s0,v1161_11_label);
    if (v1161_11_tail.empty()) continue;
    const Path v1161_11_head{v1161_11_label};
    const Space v1162_2 = singleton(v1161_11_head);
    const Space v1162_3 = intersect(constant_8,v1162_2);
    const Space v1162_4 = (has_head(v1162_3) ? constant_9 : Space{});
    const Space v1162_5 = subtract(constant_0,v1162_4);
    Space v1162_8;
    if (!v1162_5.empty()) {
      const Path v1163_6 = concat_path(p0,v1161_11_head);
      Space v1163_7_result;
      for (int v1163_7_label = 1; v1163_7_label <= 2; ++v1163_7_label) {
        const Space v1163_7_tail = child(v1161_11_tail,v1163_7_label);
        if (v1163_7_tail.empty()) continue;
        const Path v1163_7_head{v1163_7_label};
        const Space v1164_2 = singleton(v1163_7_head);
        const Space v1164_3 = intersect(constant_8,v1164_2);
        const Space v1164_4 = (has_head(v1164_3) ? constant_9 : Space{});
        const Space v1164_5 = subtract(constant_0,v1164_4);
        Space v1164_8;
        if (!v1164_5.empty()) {
          const Path v1165_6 = concat_path(v1163_6,v1163_7_head);
          const Space v1165_7 = routine_211(c, v1165_6, v1163_7_tail);
          v1164_8 = compose(v1164_5,v1165_7);
        }
        const Space v1164_9 = intersect(constant_8,v1164_2);
        const Space v1164_10 = (has_head(v1164_9) ? constant_9 : Space{});
        Space v1164_12;
        if (!v1164_10.empty()) {
          const Path v1166_6 = concat_path(v1163_6,v1163_7_head);
          const Space v1166_11 = routine_212(c, v1166_6, v1163_7_tail);
          v1164_12 = compose(v1164_10,v1166_11);
        }
        const Space v1164_13 = unite(v1164_8,v1164_12);
        v1163_7_result = unite(v1163_7_result,v1164_13);
      }
      const Space v1163_7 = std::move(v1163_7_result);
      v1162_8 = compose(v1162_5,v1163_7);
    }
    const Space v1162_9 = intersect(constant_8,v1162_2);
    const Space v1162_10 = (has_head(v1162_9) ? constant_9 : Space{});
    Space v1162_12;
    if (!v1162_10.empty()) {
      const Path v1167_6 = concat_path(p0,v1161_11_head);
      Space v1167_11_result;
      for (int v1167_11_label = 1; v1167_11_label <= 2; ++v1167_11_label) {
        const Space v1167_11_tail = child(v1161_11_tail,v1167_11_label);
        if (v1167_11_tail.empty()) continue;
        const Path v1167_11_head{v1167_11_label};
        const Space v1168_2 = singleton(v1167_11_head);
        const Space v1168_3 = intersect(constant_8,v1168_2);
        const Space v1168_4 = (has_head(v1168_3) ? constant_9 : Space{});
        const Space v1168_5 = subtract(constant_0,v1168_4);
        Space v1168_8;
        if (!v1168_5.empty()) {
          const Path v1169_6 = concat_path(v1167_6,v1167_11_head);
          const Space v1169_7 = routine_211(c, v1169_6, v1167_11_tail);
          v1168_8 = compose(v1168_5,v1169_7);
        }
        const Space v1168_9 = intersect(constant_8,v1168_2);
        const Space v1168_10 = (has_head(v1168_9) ? constant_9 : Space{});
        Space v1168_12;
        if (!v1168_10.empty()) {
          const Path v1170_6 = concat_path(v1167_6,v1167_11_head);
          const Space v1170_11 = routine_86(c, v1170_6, v1167_11_tail);
          v1168_12 = compose(v1168_10,v1170_11);
        }
        const Space v1168_13 = unite(v1168_8,v1168_12);
        v1167_11_result = unite(v1167_11_result,v1168_13);
      }
      const Space v1167_11 = std::move(v1167_11_result);
      v1162_12 = compose(v1162_10,v1167_11);
    }
    const Space v1162_13 = unite(v1162_8,v1162_12);
    v1161_11_result = unite(v1161_11_result,v1162_13);
  }
  const Space v1161_11 = std::move(v1161_11_result);
  return v1161_11;
}

static Space routine_121(Context& c, const Path& p0, const Space& s0) {
  Space v1171_8_result;
  for (int v1171_8_label = 1; v1171_8_label <= 2; ++v1171_8_label) {
    const Space v1171_8_tail = child(s0,v1171_8_label);
    if (v1171_8_tail.empty()) continue;
    const Path v1171_8_head{v1171_8_label};
    const Space v1172_2 = singleton(v1171_8_head);
    const Space v1172_3 = intersect(constant_8,v1172_2);
    const Space v1172_4 = (has_head(v1172_3) ? constant_9 : Space{});
    const Space v1172_5 = subtract(constant_0,v1172_4);
    Space v1172_8;
    if (!v1172_5.empty()) {
      const Path v1173_6 = concat_path(p0,v1171_8_head);
      Space v1173_7_result;
      for (int v1173_7_label = 1; v1173_7_label <= 2; ++v1173_7_label) {
        const Space v1173_7_tail = child(v1171_8_tail,v1173_7_label);
        if (v1173_7_tail.empty()) continue;
        const Path v1173_7_head{v1173_7_label};
        const Space v1174_2 = singleton(v1173_7_head);
        const Space v1174_3 = intersect(constant_8,v1174_2);
        const Space v1174_4 = (has_head(v1174_3) ? constant_9 : Space{});
        const Space v1174_5 = subtract(constant_0,v1174_4);
        Space v1174_8;
        if (!v1174_5.empty()) {
          const Path v1175_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1175_7 = routine_211(c, v1175_6, v1173_7_tail);
          v1174_8 = compose(v1174_5,v1175_7);
        }
        const Space v1174_9 = intersect(constant_8,v1174_2);
        const Space v1174_10 = (has_head(v1174_9) ? constant_9 : Space{});
        Space v1174_12;
        if (!v1174_10.empty()) {
          const Path v1176_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1176_11 = routine_212(c, v1176_6, v1173_7_tail);
          v1174_12 = compose(v1174_10,v1176_11);
        }
        const Space v1174_13 = unite(v1174_8,v1174_12);
        v1173_7_result = unite(v1173_7_result,v1174_13);
      }
      const Space v1173_7 = std::move(v1173_7_result);
      v1172_8 = compose(v1172_5,v1173_7);
    }
    const Space v1172_9 = intersect(constant_8,v1172_2);
    const Space v1172_10 = (has_head(v1172_9) ? constant_9 : Space{});
    const Space v1172_11 = compose(v1172_10,v1171_8_tail);
    const Space v1172_12 = unite(v1172_8,v1172_11);
    v1171_8_result = unite(v1171_8_result,v1172_12);
  }
  const Space v1171_8 = std::move(v1171_8_result);
  return v1171_8;
}

static Space routine_122(Context& c, const Path& p0, const Space& s0) {
  Space v1177_11_result;
  for (int v1177_11_label = 1; v1177_11_label <= 2; ++v1177_11_label) {
    const Space v1177_11_tail = child(s0,v1177_11_label);
    if (v1177_11_tail.empty()) continue;
    const Path v1177_11_head{v1177_11_label};
    const Space v1178_2 = singleton(v1177_11_head);
    const Space v1178_3 = intersect(constant_8,v1178_2);
    const Space v1178_4 = (has_head(v1178_3) ? constant_9 : Space{});
    const Space v1178_5 = subtract(constant_0,v1178_4);
    Space v1178_8;
    if (!v1178_5.empty()) {
      const Path v1179_6 = concat_path(p0,v1177_11_head);
      Space v1179_7_result;
      for (int v1179_7_label = 1; v1179_7_label <= 2; ++v1179_7_label) {
        const Space v1179_7_tail = child(v1177_11_tail,v1179_7_label);
        if (v1179_7_tail.empty()) continue;
        const Path v1179_7_head{v1179_7_label};
        const Space v1180_2 = singleton(v1179_7_head);
        const Space v1180_3 = intersect(constant_8,v1180_2);
        const Space v1180_4 = (has_head(v1180_3) ? constant_9 : Space{});
        const Space v1180_5 = subtract(constant_0,v1180_4);
        Space v1180_8;
        if (!v1180_5.empty()) {
          const Path v1181_6 = concat_path(v1179_6,v1179_7_head);
          const Space v1181_7 = routine_213(c, v1181_6, v1179_7_tail);
          v1180_8 = compose(v1180_5,v1181_7);
        }
        const Space v1180_9 = intersect(constant_8,v1180_2);
        const Space v1180_10 = (has_head(v1180_9) ? constant_9 : Space{});
        Space v1180_12;
        if (!v1180_10.empty()) {
          const Path v1182_6 = concat_path(v1179_6,v1179_7_head);
          const Space v1182_11 = routine_214(c, v1182_6, v1179_7_tail);
          v1180_12 = compose(v1180_10,v1182_11);
        }
        const Space v1180_13 = unite(v1180_8,v1180_12);
        v1179_7_result = unite(v1179_7_result,v1180_13);
      }
      const Space v1179_7 = std::move(v1179_7_result);
      v1178_8 = compose(v1178_5,v1179_7);
    }
    const Space v1178_9 = intersect(constant_8,v1178_2);
    const Space v1178_10 = (has_head(v1178_9) ? constant_9 : Space{});
    Space v1178_12;
    if (!v1178_10.empty()) {
      const Path v1183_6 = concat_path(p0,v1177_11_head);
      Space v1183_11_result;
      for (int v1183_11_label = 1; v1183_11_label <= 2; ++v1183_11_label) {
        const Space v1183_11_tail = child(v1177_11_tail,v1183_11_label);
        if (v1183_11_tail.empty()) continue;
        const Path v1183_11_head{v1183_11_label};
        const Space v1184_2 = singleton(v1183_11_head);
        const Space v1184_3 = intersect(constant_8,v1184_2);
        const Space v1184_4 = (has_head(v1184_3) ? constant_9 : Space{});
        const Space v1184_5 = subtract(constant_0,v1184_4);
        Space v1184_8;
        if (!v1184_5.empty()) {
          const Path v1185_6 = concat_path(v1183_6,v1183_11_head);
          const Space v1185_7 = routine_213(c, v1185_6, v1183_11_tail);
          v1184_8 = compose(v1184_5,v1185_7);
        }
        const Space v1184_9 = intersect(constant_8,v1184_2);
        const Space v1184_10 = (has_head(v1184_9) ? constant_9 : Space{});
        Space v1184_12;
        if (!v1184_10.empty()) {
          const Path v1186_6 = concat_path(v1183_6,v1183_11_head);
          const Space v1186_11 = routine_89(c, v1186_6, v1183_11_tail);
          v1184_12 = compose(v1184_10,v1186_11);
        }
        const Space v1184_13 = unite(v1184_8,v1184_12);
        v1183_11_result = unite(v1183_11_result,v1184_13);
      }
      const Space v1183_11 = std::move(v1183_11_result);
      v1178_12 = compose(v1178_10,v1183_11);
    }
    const Space v1178_13 = unite(v1178_8,v1178_12);
    v1177_11_result = unite(v1177_11_result,v1178_13);
  }
  const Space v1177_11 = std::move(v1177_11_result);
  return v1177_11;
}

static Space routine_123(Context& c, const Path& p0, const Space& s0) {
  Space v1187_11_result;
  for (int v1187_11_label = 1; v1187_11_label <= 2; ++v1187_11_label) {
    const Space v1187_11_tail = child(s0,v1187_11_label);
    if (v1187_11_tail.empty()) continue;
    const Path v1187_11_head{v1187_11_label};
    const Space v1188_2 = singleton(v1187_11_head);
    const Space v1188_3 = intersect(constant_8,v1188_2);
    const Space v1188_4 = (has_head(v1188_3) ? constant_9 : Space{});
    const Space v1188_5 = subtract(constant_0,v1188_4);
    Space v1188_8;
    if (!v1188_5.empty()) {
      const Path v1189_6 = concat_path(p0,v1187_11_head);
      Space v1189_7_result;
      for (int v1189_7_label = 1; v1189_7_label <= 2; ++v1189_7_label) {
        const Space v1189_7_tail = child(v1187_11_tail,v1189_7_label);
        if (v1189_7_tail.empty()) continue;
        const Path v1189_7_head{v1189_7_label};
        const Space v1190_2 = singleton(v1189_7_head);
        const Space v1190_3 = intersect(constant_8,v1190_2);
        const Space v1190_4 = (has_head(v1190_3) ? constant_9 : Space{});
        const Space v1190_5 = subtract(constant_0,v1190_4);
        Space v1190_8;
        if (!v1190_5.empty()) {
          const Path v1191_6 = concat_path(v1189_6,v1189_7_head);
          const Space v1191_7 = routine_213(c, v1191_6, v1189_7_tail);
          v1190_8 = compose(v1190_5,v1191_7);
        }
        const Space v1190_9 = intersect(constant_8,v1190_2);
        const Space v1190_10 = (has_head(v1190_9) ? constant_9 : Space{});
        Space v1190_12;
        if (!v1190_10.empty()) {
          const Path v1192_6 = concat_path(v1189_6,v1189_7_head);
          const Space v1192_11 = routine_214(c, v1192_6, v1189_7_tail);
          v1190_12 = compose(v1190_10,v1192_11);
        }
        const Space v1190_13 = unite(v1190_8,v1190_12);
        v1189_7_result = unite(v1189_7_result,v1190_13);
      }
      const Space v1189_7 = std::move(v1189_7_result);
      v1188_8 = compose(v1188_5,v1189_7);
    }
    const Space v1188_9 = intersect(constant_8,v1188_2);
    const Space v1188_10 = (has_head(v1188_9) ? constant_9 : Space{});
    Space v1188_12;
    if (!v1188_10.empty()) {
      const Path v1193_6 = concat_path(p0,v1187_11_head);
      Space v1193_11_result;
      for (int v1193_11_label = 1; v1193_11_label <= 2; ++v1193_11_label) {
        const Space v1193_11_tail = child(v1187_11_tail,v1193_11_label);
        if (v1193_11_tail.empty()) continue;
        const Path v1193_11_head{v1193_11_label};
        const Space v1194_2 = singleton(v1193_11_head);
        const Space v1194_3 = intersect(constant_8,v1194_2);
        const Space v1194_4 = (has_head(v1194_3) ? constant_9 : Space{});
        const Space v1194_5 = subtract(constant_0,v1194_4);
        Space v1194_7;
        if (!v1194_5.empty()) {
          const Space v1195_6 = routine_124(c, v1193_11_head, v1193_6, v1193_11_tail);
          v1194_7 = compose(v1194_5,v1195_6);
        }
        const Space v1194_8 = intersect(constant_8,v1194_2);
        const Space v1194_9 = (has_head(v1194_8) ? constant_9 : Space{});
        Space v1194_11;
        if (!v1194_9.empty()) {
          const Space v1196_10 = routine_125(c, v1193_11_head, v1193_6, v1193_11_tail);
          v1194_11 = compose(v1194_9,v1196_10);
        }
        const Space v1194_12 = unite(v1194_7,v1194_11);
        v1193_11_result = unite(v1193_11_result,v1194_12);
      }
      const Space v1193_11 = std::move(v1193_11_result);
      v1188_12 = compose(v1188_10,v1193_11);
    }
    const Space v1188_13 = unite(v1188_8,v1188_12);
    v1187_11_result = unite(v1187_11_result,v1188_13);
  }
  const Space v1187_11 = std::move(v1187_11_result);
  return v1187_11;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1197_12_result;
  for (int v1197_12_label = 1; v1197_12_label <= 2; ++v1197_12_label) {
    const Space v1197_12_tail = child(s0,v1197_12_label);
    if (v1197_12_tail.empty()) continue;
    const Path v1197_12_head{v1197_12_label};
    const Space v1198_2 = singleton(v1197_12_head);
    const Space v1198_3 = intersect(constant_8,v1198_2);
    const Space v1198_4 = (has_head(v1198_3) ? constant_9 : Space{});
    const Space v1198_5 = subtract(constant_0,v1198_4);
    Space v1198_8;
    if (!v1198_5.empty()) {
      const Path v1199_6 = concat_path(p0,v1197_12_head);
      Space v1199_7_result;
      for (int v1199_7_label = 1; v1199_7_label <= 2; ++v1199_7_label) {
        const Space v1199_7_tail = child(v1197_12_tail,v1199_7_label);
        if (v1199_7_tail.empty()) continue;
        const Path v1199_7_head{v1199_7_label};
        const Space v1200_2 = singleton(v1199_7_head);
        const Space v1200_3 = intersect(constant_8,v1200_2);
        const Space v1200_4 = (has_head(v1200_3) ? constant_9 : Space{});
        const Space v1200_5 = subtract(constant_0,v1200_4);
        Space v1200_8;
        if (!v1200_5.empty()) {
          const Path v1201_6 = concat_path(v1199_6,v1199_7_head);
          const Space v1201_7 = routine_215(c, v1201_6, p1, v1199_7_tail);
          v1200_8 = compose(v1200_5,v1201_7);
        }
        const Space v1200_9 = intersect(constant_8,v1200_2);
        const Space v1200_10 = (has_head(v1200_9) ? constant_9 : Space{});
        Space v1200_12;
        if (!v1200_10.empty()) {
          const Path v1202_6 = concat_path(v1199_6,v1199_7_head);
          const Space v1202_11 = routine_216(c, v1202_6, p1, v1199_7_tail);
          v1200_12 = compose(v1200_10,v1202_11);
        }
        const Space v1200_13 = unite(v1200_8,v1200_12);
        v1199_7_result = unite(v1199_7_result,v1200_13);
      }
      const Space v1199_7 = std::move(v1199_7_result);
      v1198_8 = compose(v1198_5,v1199_7);
    }
    const Space v1198_9 = intersect(constant_8,v1198_2);
    const Space v1198_10 = (has_head(v1198_9) ? constant_9 : Space{});
    Space v1198_12;
    if (!v1198_10.empty()) {
      const Path v1203_6 = concat_path(p0,v1197_12_head);
      Space v1203_11_result;
      for (int v1203_11_label = 1; v1203_11_label <= 2; ++v1203_11_label) {
        const Space v1203_11_tail = child(v1197_12_tail,v1203_11_label);
        if (v1203_11_tail.empty()) continue;
        const Path v1203_11_head{v1203_11_label};
        const Space v1204_2 = singleton(v1203_11_head);
        const Space v1204_3 = intersect(constant_8,v1204_2);
        const Space v1204_4 = (has_head(v1204_3) ? constant_9 : Space{});
        const Space v1204_5 = subtract(constant_0,v1204_4);
        Space v1204_8;
        if (!v1204_5.empty()) {
          const Path v1205_6 = concat_path(v1203_6,v1203_11_head);
          const Space v1205_7 = routine_215(c, v1205_6, p1, v1203_11_tail);
          v1204_8 = compose(v1204_5,v1205_7);
        }
        const Space v1204_9 = intersect(constant_8,v1204_2);
        const Space v1204_10 = (has_head(v1204_9) ? constant_9 : Space{});
        Space v1204_12;
        if (!v1204_10.empty()) {
          const Path v1206_6 = concat_path(v1203_6,v1203_11_head);
          const Space v1206_11 = routine_169(c, v1206_6, p1, v1203_11_tail);
          v1204_12 = compose(v1204_10,v1206_11);
        }
        const Space v1204_13 = unite(v1204_8,v1204_12);
        v1203_11_result = unite(v1203_11_result,v1204_13);
      }
      const Space v1203_11 = std::move(v1203_11_result);
      v1198_12 = compose(v1198_10,v1203_11);
    }
    const Space v1198_13 = unite(v1198_8,v1198_12);
    v1197_12_result = unite(v1197_12_result,v1198_13);
  }
  const Space v1197_12 = std::move(v1197_12_result);
  return v1197_12;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1207_12_result;
  for (int v1207_12_label = 1; v1207_12_label <= 2; ++v1207_12_label) {
    const Space v1207_12_tail = child(s0,v1207_12_label);
    if (v1207_12_tail.empty()) continue;
    const Path v1207_12_head{v1207_12_label};
    const Space v1208_2 = singleton(v1207_12_head);
    const Space v1208_3 = intersect(constant_8,v1208_2);
    const Space v1208_4 = (has_head(v1208_3) ? constant_9 : Space{});
    const Space v1208_5 = subtract(constant_0,v1208_4);
    Space v1208_8;
    if (!v1208_5.empty()) {
      const Path v1209_6 = concat_path(p0,v1207_12_head);
      Space v1209_7_result;
      for (int v1209_7_label = 1; v1209_7_label <= 2; ++v1209_7_label) {
        const Space v1209_7_tail = child(v1207_12_tail,v1209_7_label);
        if (v1209_7_tail.empty()) continue;
        const Path v1209_7_head{v1209_7_label};
        const Space v1210_2 = singleton(v1209_7_head);
        const Space v1210_3 = intersect(constant_8,v1210_2);
        const Space v1210_4 = (has_head(v1210_3) ? constant_9 : Space{});
        const Space v1210_5 = subtract(constant_0,v1210_4);
        Space v1210_8;
        if (!v1210_5.empty()) {
          const Path v1211_6 = concat_path(v1209_6,v1209_7_head);
          const Space v1211_7 = routine_215(c, v1211_6, p1, v1209_7_tail);
          v1210_8 = compose(v1210_5,v1211_7);
        }
        const Space v1210_9 = intersect(constant_8,v1210_2);
        const Space v1210_10 = (has_head(v1210_9) ? constant_9 : Space{});
        Space v1210_12;
        if (!v1210_10.empty()) {
          const Path v1212_6 = concat_path(v1209_6,v1209_7_head);
          const Space v1212_11 = routine_216(c, v1212_6, p1, v1209_7_tail);
          v1210_12 = compose(v1210_10,v1212_11);
        }
        const Space v1210_13 = unite(v1210_8,v1210_12);
        v1209_7_result = unite(v1209_7_result,v1210_13);
      }
      const Space v1209_7 = std::move(v1209_7_result);
      v1208_8 = compose(v1208_5,v1209_7);
    }
    const Space v1208_9 = intersect(constant_8,v1208_2);
    const Space v1208_10 = (has_head(v1208_9) ? constant_9 : Space{});
    Space v1208_12;
    if (!v1208_10.empty()) {
      const Path v1213_6 = concat_path(p0,v1207_12_head);
      Space v1213_11_result;
      for (int v1213_11_label = 1; v1213_11_label <= 2; ++v1213_11_label) {
        const Space v1213_11_tail = child(v1207_12_tail,v1213_11_label);
        if (v1213_11_tail.empty()) continue;
        const Path v1213_11_head{v1213_11_label};
        const Space v1214_2 = singleton(v1213_11_head);
        const Space v1214_3 = intersect(constant_8,v1214_2);
        const Space v1214_4 = (has_head(v1214_3) ? constant_9 : Space{});
        const Space v1214_5 = subtract(constant_0,v1214_4);
        Space v1214_7;
        if (!v1214_5.empty()) {
          const Space v1215_6 = routine_217(c, v1213_11_head, p1, v1213_6, v1213_11_tail);
          v1214_7 = compose(v1214_5,v1215_6);
        }
        const Space v1214_8 = intersect(constant_8,v1214_2);
        const Space v1214_9 = (has_head(v1214_8) ? constant_9 : Space{});
        Space v1214_11;
        if (!v1214_9.empty()) {
          const Space v1216_10 = routine_218(c, v1213_11_head, p1, v1213_6, v1213_11_tail);
          v1214_11 = compose(v1214_9,v1216_10);
        }
        const Space v1214_12 = unite(v1214_7,v1214_11);
        v1213_11_result = unite(v1213_11_result,v1214_12);
      }
      const Space v1213_11 = std::move(v1213_11_result);
      v1208_12 = compose(v1208_10,v1213_11);
    }
    const Space v1208_13 = unite(v1208_8,v1208_12);
    v1207_12_result = unite(v1207_12_result,v1208_13);
  }
  const Space v1207_12 = std::move(v1207_12_result);
  return v1207_12;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1217_5_result;
  for (int v1217_5_label = 1; v1217_5_label <= 2; ++v1217_5_label) {
    const Space v1217_5_tail = child(s0,v1217_5_label);
    if (v1217_5_tail.empty()) continue;
    const Path v1217_5_head{v1217_5_label};
    const Space v1218_2 = singleton(v1217_5_head);
    const Space v1218_3 = intersect(constant_8,v1218_2);
    const Space v1218_4 = (has_head(v1218_3) ? constant_9 : Space{});
    Space v1218_7;
    if (!v1218_4.empty()) {
      const Path v1219_5 = concat_path(p0,v1217_5_head);
      Space v1219_6_result;
      for (int v1219_6_label = 1; v1219_6_label <= 2; ++v1219_6_label) {
        const Space v1219_6_tail = child(v1217_5_tail,v1219_6_label);
        if (v1219_6_tail.empty()) continue;
        const Path v1219_6_head{v1219_6_label};
        const Space v1220_2 = singleton(v1219_6_head);
        const Space v1220_3 = intersect(constant_8,v1220_2);
        const Space v1220_4 = (has_head(v1220_3) ? constant_9 : Space{});
        Space v1220_7;
        if (!v1220_4.empty()) {
          const Path v1221_5 = concat_path(v1219_5,v1219_6_head);
          const Space v1221_6 = routine_60(c, v1221_5, p1, v1219_6_tail);
          v1220_7 = compose(v1220_4,v1221_6);
        }
        v1219_6_result = unite(v1219_6_result,v1220_7);
      }
      const Space v1219_6 = std::move(v1219_6_result);
      v1218_7 = compose(v1218_4,v1219_6);
    }
    v1217_5_result = unite(v1217_5_result,v1218_7);
  }
  const Space v1217_5 = std::move(v1217_5_result);
  return v1217_5;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1222_12_result;
  for (int v1222_12_label = 1; v1222_12_label <= 2; ++v1222_12_label) {
    const Space v1222_12_tail = child(s0,v1222_12_label);
    if (v1222_12_tail.empty()) continue;
    const Path v1222_12_head{v1222_12_label};
    const Space v1223_2 = singleton(v1222_12_head);
    const Space v1223_3 = intersect(constant_8,v1223_2);
    const Space v1223_4 = (has_head(v1223_3) ? constant_9 : Space{});
    Space v1223_11;
    if (!v1223_4.empty()) {
      Space v1224_8;
      if (!constant_0.empty()) {
        const Space v1225_5 = routine_92(c, constant_14, p1, constant_15);
        const Space v1225_6 = routine_93(c, constant_16, p1, constant_17);
        const Space v1225_7 = unite(v1225_5,v1225_6);
        v1224_8 = compose(constant_0,v1225_7);
      }
      const Path v1224_9 = concat_path(p0,v1222_12_head);
      Space v1224_10_result;
      for (int v1224_10_label = 1; v1224_10_label <= 2; ++v1224_10_label) {
        const Space v1224_10_tail = child(v1224_8,v1224_10_label);
        if (v1224_10_tail.empty()) continue;
        const Path v1224_10_head{v1224_10_label};
        const Space v1226_2 = singleton(v1224_10_head);
        const Space v1226_3 = intersect(constant_8,v1226_2);
        const Space v1226_4 = (has_head(v1226_3) ? constant_9 : Space{});
        const Space v1226_5 = subtract(constant_0,v1226_4);
        Space v1226_7;
        if (!v1226_5.empty()) {
          const Space v1227_6 = routine_94(c, v1224_10_head, v1224_9, v1224_10_tail, v1222_12_tail);
          v1226_7 = compose(v1226_5,v1227_6);
        }
        const Space v1226_8 = intersect(constant_8,v1226_2);
        const Space v1226_9 = (has_head(v1226_8) ? constant_9 : Space{});
        Space v1226_11;
        if (!v1226_9.empty()) {
          const Space v1228_10 = routine_95(c, v1224_10_head, v1224_9, v1224_10_tail, v1222_12_tail);
          v1226_11 = compose(v1226_9,v1228_10);
        }
        const Space v1226_12 = unite(v1226_7,v1226_11);
        v1224_10_result = unite(v1224_10_result,v1226_12);
      }
      const Space v1224_10 = std::move(v1224_10_result);
      v1223_11 = compose(v1223_4,v1224_10);
    }
    v1222_12_result = unite(v1222_12_result,v1223_11);
  }
  const Space v1222_12 = std::move(v1222_12_result);
  return v1222_12;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1229_12_result;
  for (int v1229_12_label = 1; v1229_12_label <= 2; ++v1229_12_label) {
    const Space v1229_12_tail = child(s0,v1229_12_label);
    if (v1229_12_tail.empty()) continue;
    const Path v1229_12_head{v1229_12_label};
    const Space v1230_2 = singleton(v1229_12_head);
    const Space v1230_3 = intersect(constant_8,v1230_2);
    const Space v1230_4 = (has_head(v1230_3) ? constant_9 : Space{});
    const Space v1230_5 = subtract(constant_0,v1230_4);
    Space v1230_8;
    if (!v1230_5.empty()) {
      const Path v1231_6 = concat_path(p0,v1229_12_head);
      Space v1231_7_result;
      for (int v1231_7_label = 1; v1231_7_label <= 2; ++v1231_7_label) {
        const Space v1231_7_tail = child(v1229_12_tail,v1231_7_label);
        if (v1231_7_tail.empty()) continue;
        const Path v1231_7_head{v1231_7_label};
        const Space v1232_2 = singleton(v1231_7_head);
        const Space v1232_3 = intersect(constant_8,v1232_2);
        const Space v1232_4 = (has_head(v1232_3) ? constant_9 : Space{});
        const Space v1232_5 = subtract(constant_0,v1232_4);
        Space v1232_8;
        if (!v1232_5.empty()) {
          const Path v1233_6 = concat_path(v1231_6,v1231_7_head);
          const Space v1233_7 = routine_219(c, v1233_6, p1, v1231_7_tail);
          v1232_8 = compose(v1232_5,v1233_7);
        }
        const Space v1232_9 = intersect(constant_8,v1232_2);
        const Space v1232_10 = (has_head(v1232_9) ? constant_9 : Space{});
        Space v1232_12;
        if (!v1232_10.empty()) {
          const Path v1234_6 = concat_path(v1231_6,v1231_7_head);
          const Space v1234_11 = routine_220(c, v1234_6, p1, v1231_7_tail);
          v1232_12 = compose(v1232_10,v1234_11);
        }
        const Space v1232_13 = unite(v1232_8,v1232_12);
        v1231_7_result = unite(v1231_7_result,v1232_13);
      }
      const Space v1231_7 = std::move(v1231_7_result);
      v1230_8 = compose(v1230_5,v1231_7);
    }
    const Space v1230_9 = intersect(constant_8,v1230_2);
    const Space v1230_10 = (has_head(v1230_9) ? constant_9 : Space{});
    Space v1230_12;
    if (!v1230_10.empty()) {
      const Path v1235_6 = concat_path(p0,v1229_12_head);
      Space v1235_11_result;
      for (int v1235_11_label = 1; v1235_11_label <= 2; ++v1235_11_label) {
        const Space v1235_11_tail = child(v1229_12_tail,v1235_11_label);
        if (v1235_11_tail.empty()) continue;
        const Path v1235_11_head{v1235_11_label};
        const Space v1236_2 = singleton(v1235_11_head);
        const Space v1236_3 = intersect(constant_8,v1236_2);
        const Space v1236_4 = (has_head(v1236_3) ? constant_9 : Space{});
        const Space v1236_5 = subtract(constant_0,v1236_4);
        Space v1236_8;
        if (!v1236_5.empty()) {
          const Path v1237_6 = concat_path(v1235_6,v1235_11_head);
          const Space v1237_7 = routine_219(c, v1237_6, p1, v1235_11_tail);
          v1236_8 = compose(v1236_5,v1237_7);
        }
        const Space v1236_9 = intersect(constant_8,v1236_2);
        const Space v1236_10 = (has_head(v1236_9) ? constant_9 : Space{});
        Space v1236_12;
        if (!v1236_10.empty()) {
          const Path v1238_6 = concat_path(v1235_6,v1235_11_head);
          const Space v1238_11 = routine_130(c, v1238_6, p1, v1235_11_tail);
          v1236_12 = compose(v1236_10,v1238_11);
        }
        const Space v1236_13 = unite(v1236_8,v1236_12);
        v1235_11_result = unite(v1235_11_result,v1236_13);
      }
      const Space v1235_11 = std::move(v1235_11_result);
      v1230_12 = compose(v1230_10,v1235_11);
    }
    const Space v1230_13 = unite(v1230_8,v1230_12);
    v1229_12_result = unite(v1229_12_result,v1230_13);
  }
  const Space v1229_12 = std::move(v1229_12_result);
  return v1229_12;
}

static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1239_12_result;
  for (int v1239_12_label = 1; v1239_12_label <= 2; ++v1239_12_label) {
    const Space v1239_12_tail = child(s0,v1239_12_label);
    if (v1239_12_tail.empty()) continue;
    const Path v1239_12_head{v1239_12_label};
    const Space v1240_2 = singleton(v1239_12_head);
    const Space v1240_3 = intersect(constant_8,v1240_2);
    const Space v1240_4 = (has_head(v1240_3) ? constant_9 : Space{});
    const Space v1240_5 = subtract(constant_0,v1240_4);
    Space v1240_8;
    if (!v1240_5.empty()) {
      const Path v1241_6 = concat_path(p0,v1239_12_head);
      Space v1241_7_result;
      for (int v1241_7_label = 1; v1241_7_label <= 2; ++v1241_7_label) {
        const Space v1241_7_tail = child(v1239_12_tail,v1241_7_label);
        if (v1241_7_tail.empty()) continue;
        const Path v1241_7_head{v1241_7_label};
        const Space v1242_2 = singleton(v1241_7_head);
        const Space v1242_3 = intersect(constant_8,v1242_2);
        const Space v1242_4 = (has_head(v1242_3) ? constant_9 : Space{});
        const Space v1242_5 = subtract(constant_0,v1242_4);
        Space v1242_8;
        if (!v1242_5.empty()) {
          const Path v1243_6 = concat_path(v1241_6,v1241_7_head);
          const Space v1243_7 = routine_219(c, v1243_6, p1, v1241_7_tail);
          v1242_8 = compose(v1242_5,v1243_7);
        }
        const Space v1242_9 = intersect(constant_8,v1242_2);
        const Space v1242_10 = (has_head(v1242_9) ? constant_9 : Space{});
        Space v1242_12;
        if (!v1242_10.empty()) {
          const Path v1244_6 = concat_path(v1241_6,v1241_7_head);
          const Space v1244_11 = routine_220(c, v1244_6, p1, v1241_7_tail);
          v1242_12 = compose(v1242_10,v1244_11);
        }
        const Space v1242_13 = unite(v1242_8,v1242_12);
        v1241_7_result = unite(v1241_7_result,v1242_13);
      }
      const Space v1241_7 = std::move(v1241_7_result);
      v1240_8 = compose(v1240_5,v1241_7);
    }
    const Space v1240_9 = intersect(constant_8,v1240_2);
    const Space v1240_10 = (has_head(v1240_9) ? constant_9 : Space{});
    Space v1240_12;
    if (!v1240_10.empty()) {
      const Path v1245_6 = concat_path(p0,v1239_12_head);
      Space v1245_11_result;
      for (int v1245_11_label = 1; v1245_11_label <= 2; ++v1245_11_label) {
        const Space v1245_11_tail = child(v1239_12_tail,v1245_11_label);
        if (v1245_11_tail.empty()) continue;
        const Path v1245_11_head{v1245_11_label};
        const Space v1246_2 = singleton(v1245_11_head);
        const Space v1246_3 = intersect(constant_8,v1246_2);
        const Space v1246_4 = (has_head(v1246_3) ? constant_9 : Space{});
        const Space v1246_5 = subtract(constant_0,v1246_4);
        Space v1246_7;
        if (!v1246_5.empty()) {
          const Space v1247_6 = routine_174(c, v1245_11_head, p1, v1245_6, v1245_11_tail);
          v1246_7 = compose(v1246_5,v1247_6);
        }
        const Space v1246_8 = intersect(constant_8,v1246_2);
        const Space v1246_9 = (has_head(v1246_8) ? constant_9 : Space{});
        Space v1246_11;
        if (!v1246_9.empty()) {
          const Space v1248_10 = routine_175(c, v1245_11_head, p1, v1245_6, v1245_11_tail);
          v1246_11 = compose(v1246_9,v1248_10);
        }
        const Space v1246_12 = unite(v1246_7,v1246_11);
        v1245_11_result = unite(v1245_11_result,v1246_12);
      }
      const Space v1245_11 = std::move(v1245_11_result);
      v1240_12 = compose(v1240_10,v1245_11);
    }
    const Space v1240_13 = unite(v1240_8,v1240_12);
    v1239_12_result = unite(v1239_12_result,v1240_13);
  }
  const Space v1239_12 = std::move(v1239_12_result);
  return v1239_12;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1249_12_result;
  for (int v1249_12_label = 1; v1249_12_label <= 2; ++v1249_12_label) {
    const Space v1249_12_tail = child(s0,v1249_12_label);
    if (v1249_12_tail.empty()) continue;
    const Path v1249_12_head{v1249_12_label};
    const Space v1250_2 = singleton(v1249_12_head);
    const Space v1250_3 = intersect(constant_8,v1250_2);
    const Space v1250_4 = (has_head(v1250_3) ? constant_9 : Space{});
    const Space v1250_5 = subtract(constant_0,v1250_4);
    Space v1250_7;
    if (!v1250_5.empty()) {
      Space v1251_6_result;
      for (int v1251_6_label = 1; v1251_6_label <= 2; ++v1251_6_label) {
        const Space v1251_6_tail = child(v1249_12_tail,v1251_6_label);
        if (v1251_6_tail.empty()) continue;
        const Path v1251_6_head{v1251_6_label};
        const Space v1252_2 = singleton(v1251_6_head);
        const Space v1252_3 = intersect(constant_8,v1252_2);
        const Space v1252_4 = (has_head(v1252_3) ? constant_9 : Space{});
        const Space v1252_5 = subtract(constant_0,v1252_4);
        Space v1252_8;
        if (!v1252_5.empty()) {
          const Path v1253_6 = concat_path(v1249_12_head,v1251_6_head);
          const Space v1253_7 = routine_221(c, v1253_6, p1, p0, v1251_6_tail);
          v1252_8 = compose(v1252_5,v1253_7);
        }
        const Space v1252_9 = intersect(constant_8,v1252_2);
        const Space v1252_10 = (has_head(v1252_9) ? constant_9 : Space{});
        Space v1252_12;
        if (!v1252_10.empty()) {
          const Path v1254_6 = concat_path(v1249_12_head,v1251_6_head);
          const Space v1254_11 = routine_222(c, v1254_6, p1, p0, v1251_6_tail);
          v1252_12 = compose(v1252_10,v1254_11);
        }
        const Space v1252_13 = unite(v1252_8,v1252_12);
        v1251_6_result = unite(v1251_6_result,v1252_13);
      }
      const Space v1251_6 = std::move(v1251_6_result);
      v1250_7 = compose(v1250_5,v1251_6);
    }
    const Space v1250_8 = intersect(constant_8,v1250_2);
    const Space v1250_9 = (has_head(v1250_8) ? constant_9 : Space{});
    Space v1250_11;
    if (!v1250_9.empty()) {
      Space v1255_10_result;
      for (int v1255_10_label = 1; v1255_10_label <= 2; ++v1255_10_label) {
        const Space v1255_10_tail = child(v1249_12_tail,v1255_10_label);
        if (v1255_10_tail.empty()) continue;
        const Path v1255_10_head{v1255_10_label};
        const Space v1256_2 = singleton(v1255_10_head);
        const Space v1256_3 = intersect(constant_8,v1256_2);
        const Space v1256_4 = (has_head(v1256_3) ? constant_9 : Space{});
        const Space v1256_5 = subtract(constant_0,v1256_4);
        Space v1256_8;
        if (!v1256_5.empty()) {
          const Path v1257_6 = concat_path(v1249_12_head,v1255_10_head);
          const Space v1257_7 = routine_221(c, v1257_6, p1, p0, v1255_10_tail);
          v1256_8 = compose(v1256_5,v1257_7);
        }
        const Space v1256_9 = intersect(constant_8,v1256_2);
        const Space v1256_10 = (has_head(v1256_9) ? constant_9 : Space{});
        Space v1256_12;
        if (!v1256_10.empty()) {
          const Path v1258_6 = concat_path(v1249_12_head,v1255_10_head);
          const Space v1258_11 = routine_223(c, v1258_6, p1, p0, v1255_10_tail);
          v1256_12 = compose(v1256_10,v1258_11);
        }
        const Space v1256_13 = unite(v1256_8,v1256_12);
        v1255_10_result = unite(v1255_10_result,v1256_13);
      }
      const Space v1255_10 = std::move(v1255_10_result);
      v1250_11 = compose(v1250_9,v1255_10);
    }
    const Space v1250_12 = unite(v1250_7,v1250_11);
    v1249_12_result = unite(v1249_12_result,v1250_12);
  }
  const Space v1249_12 = std::move(v1249_12_result);
  return v1249_12;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1259_13_result;
  for (int v1259_13_label = 1; v1259_13_label <= 2; ++v1259_13_label) {
    const Space v1259_13_tail = child(s0,v1259_13_label);
    if (v1259_13_tail.empty()) continue;
    const Path v1259_13_head{v1259_13_label};
    const Space v1260_2 = singleton(v1259_13_head);
    const Space v1260_3 = intersect(constant_8,v1260_2);
    const Space v1260_4 = (has_head(v1260_3) ? constant_9 : Space{});
    const Space v1260_5 = subtract(constant_0,v1260_4);
    Space v1260_8;
    if (!v1260_5.empty()) {
      const Path v1261_6 = concat_path(p0,v1259_13_head);
      Space v1261_7_result;
      for (int v1261_7_label = 1; v1261_7_label <= 2; ++v1261_7_label) {
        const Space v1261_7_tail = child(v1259_13_tail,v1261_7_label);
        if (v1261_7_tail.empty()) continue;
        const Path v1261_7_head{v1261_7_label};
        const Space v1262_2 = singleton(v1261_7_head);
        const Space v1262_3 = intersect(constant_8,v1262_2);
        const Space v1262_4 = (has_head(v1262_3) ? constant_9 : Space{});
        const Space v1262_5 = subtract(constant_0,v1262_4);
        Space v1262_8;
        if (!v1262_5.empty()) {
          const Path v1263_6 = concat_path(v1261_6,v1261_7_head);
          const Space v1263_7 = routine_224(c, v1263_6, p1, v1261_7_tail, s1);
          v1262_8 = compose(v1262_5,v1263_7);
        }
        const Space v1262_9 = intersect(constant_8,v1262_2);
        const Space v1262_10 = (has_head(v1262_9) ? constant_9 : Space{});
        Space v1262_12;
        if (!v1262_10.empty()) {
          const Path v1264_6 = concat_path(v1261_6,v1261_7_head);
          const Space v1264_11 = routine_225(c, v1264_6, p1, v1261_7_tail, s1);
          v1262_12 = compose(v1262_10,v1264_11);
        }
        const Space v1262_13 = unite(v1262_8,v1262_12);
        v1261_7_result = unite(v1261_7_result,v1262_13);
      }
      const Space v1261_7 = std::move(v1261_7_result);
      v1260_8 = compose(v1260_5,v1261_7);
    }
    const Space v1260_9 = intersect(constant_8,v1260_2);
    const Space v1260_10 = (has_head(v1260_9) ? constant_9 : Space{});
    Space v1260_12;
    if (!v1260_10.empty()) {
      const Path v1265_6 = concat_path(p0,v1259_13_head);
      Space v1265_11_result;
      for (int v1265_11_label = 1; v1265_11_label <= 2; ++v1265_11_label) {
        const Space v1265_11_tail = child(v1259_13_tail,v1265_11_label);
        if (v1265_11_tail.empty()) continue;
        const Path v1265_11_head{v1265_11_label};
        const Space v1266_2 = singleton(v1265_11_head);
        const Space v1266_3 = intersect(constant_8,v1266_2);
        const Space v1266_4 = (has_head(v1266_3) ? constant_9 : Space{});
        const Space v1266_5 = subtract(constant_0,v1266_4);
        Space v1266_8;
        if (!v1266_5.empty()) {
          const Path v1267_6 = concat_path(v1265_6,v1265_11_head);
          const Space v1267_7 = routine_224(c, v1267_6, p1, v1265_11_tail, s1);
          v1266_8 = compose(v1266_5,v1267_7);
        }
        const Space v1266_9 = intersect(constant_8,v1266_2);
        const Space v1266_10 = (has_head(v1266_9) ? constant_9 : Space{});
        Space v1266_12;
        if (!v1266_10.empty()) {
          const Path v1268_6 = concat_path(v1265_6,v1265_11_head);
          const Space v1268_11 = routine_133(c, v1268_6, p1, v1265_11_tail, s1);
          v1266_12 = compose(v1266_10,v1268_11);
        }
        const Space v1266_13 = unite(v1266_8,v1266_12);
        v1265_11_result = unite(v1265_11_result,v1266_13);
      }
      const Space v1265_11 = std::move(v1265_11_result);
      v1260_12 = compose(v1260_10,v1265_11);
    }
    const Space v1260_13 = unite(v1260_8,v1260_12);
    v1259_13_result = unite(v1259_13_result,v1260_13);
  }
  const Space v1259_13 = std::move(v1259_13_result);
  return v1259_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1269_10_result;
  for (int v1269_10_label = 1; v1269_10_label <= 2; ++v1269_10_label) {
    const Space v1269_10_tail = child(s0,v1269_10_label);
    if (v1269_10_tail.empty()) continue;
    const Path v1269_10_head{v1269_10_label};
    const Space v1270_2 = singleton(v1269_10_head);
    const Space v1270_3 = intersect(constant_8,v1270_2);
    const Space v1270_4 = (has_head(v1270_3) ? constant_9 : Space{});
    const Space v1270_5 = subtract(constant_0,v1270_4);
    Space v1270_8;
    if (!v1270_5.empty()) {
      const Path v1271_6 = concat_path(p0,v1269_10_head);
      Space v1271_7_result;
      for (int v1271_7_label = 1; v1271_7_label <= 2; ++v1271_7_label) {
        const Space v1271_7_tail = child(v1269_10_tail,v1271_7_label);
        if (v1271_7_tail.empty()) continue;
        const Path v1271_7_head{v1271_7_label};
        const Space v1272_2 = singleton(v1271_7_head);
        const Space v1272_3 = intersect(constant_8,v1272_2);
        const Space v1272_4 = (has_head(v1272_3) ? constant_9 : Space{});
        const Space v1272_5 = subtract(constant_0,v1272_4);
        Space v1272_8;
        if (!v1272_5.empty()) {
          const Path v1273_6 = concat_path(v1271_6,v1271_7_head);
          const Space v1273_7 = routine_224(c, v1273_6, p1, v1271_7_tail, s1);
          v1272_8 = compose(v1272_5,v1273_7);
        }
        const Space v1272_9 = intersect(constant_8,v1272_2);
        const Space v1272_10 = (has_head(v1272_9) ? constant_9 : Space{});
        Space v1272_12;
        if (!v1272_10.empty()) {
          const Path v1274_6 = concat_path(v1271_6,v1271_7_head);
          const Space v1274_11 = routine_225(c, v1274_6, p1, v1271_7_tail, s1);
          v1272_12 = compose(v1272_10,v1274_11);
        }
        const Space v1272_13 = unite(v1272_8,v1272_12);
        v1271_7_result = unite(v1271_7_result,v1272_13);
      }
      const Space v1271_7 = std::move(v1271_7_result);
      v1270_8 = compose(v1270_5,v1271_7);
    }
    const Space v1270_9 = intersect(constant_8,v1270_2);
    const Space v1270_10 = (has_head(v1270_9) ? constant_9 : Space{});
    const Space v1270_11 = unwrap(v1269_10_tail,p1);
    const Path v1275_6 = concat_path(p0,v1269_10_head);
    const Space v1270_12 = wrap(v1270_11,v1275_6);
    const Space v1270_13 = compose(v1270_12,s1);
    const Space v1270_14 = compose(v1270_10,v1270_13);
    const Space v1270_15 = unite(v1270_8,v1270_14);
    v1269_10_result = unite(v1269_10_result,v1270_15);
  }
  const Space v1269_10 = std::move(v1269_10_result);
  return v1269_10;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1276_4 = unwrap(s0,p1);
  const Space v1276_5 = wrap(v1276_4,p0);
  const Space v1276_6 = compose(v1276_5,s1);
  return v1276_6;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1277_5_result;
  for (int v1277_5_label = 1; v1277_5_label <= 2; ++v1277_5_label) {
    const Space v1277_5_tail = child(s0,v1277_5_label);
    if (v1277_5_tail.empty()) continue;
    const Path v1277_5_head{v1277_5_label};
    const Space v1278_2 = singleton(v1277_5_head);
    const Space v1278_3 = intersect(constant_8,v1278_2);
    const Space v1278_4 = (has_head(v1278_3) ? constant_9 : Space{});
    Space v1278_7;
    if (!v1278_4.empty()) {
      const Path v1279_5 = concat_path(p0,v1277_5_head);
      Space v1279_6_result;
      for (int v1279_6_label = 1; v1279_6_label <= 2; ++v1279_6_label) {
        const Space v1279_6_tail = child(v1277_5_tail,v1279_6_label);
        if (v1279_6_tail.empty()) continue;
        const Path v1279_6_head{v1279_6_label};
        const Space v1280_2 = singleton(v1279_6_head);
        const Space v1280_3 = intersect(constant_8,v1280_2);
        const Space v1280_4 = (has_head(v1280_3) ? constant_9 : Space{});
        Space v1280_7;
        if (!v1280_4.empty()) {
          const Path v1281_5 = concat_path(v1279_5,v1279_6_head);
          const Space v1281_6 = routine_63(c, v1281_5, p1, v1279_6_tail);
          v1280_7 = compose(v1280_4,v1281_6);
        }
        v1279_6_result = unite(v1279_6_result,v1280_7);
      }
      const Space v1279_6 = std::move(v1279_6_result);
      v1278_7 = compose(v1278_4,v1279_6);
    }
    v1277_5_result = unite(v1277_5_result,v1278_7);
  }
  const Space v1277_5 = std::move(v1277_5_result);
  return v1277_5;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1282_12_result;
  for (int v1282_12_label = 1; v1282_12_label <= 2; ++v1282_12_label) {
    const Space v1282_12_tail = child(s0,v1282_12_label);
    if (v1282_12_tail.empty()) continue;
    const Path v1282_12_head{v1282_12_label};
    const Space v1283_2 = singleton(v1282_12_head);
    const Space v1283_3 = intersect(constant_8,v1283_2);
    const Space v1283_4 = (has_head(v1283_3) ? constant_9 : Space{});
    Space v1283_11;
    if (!v1283_4.empty()) {
      Space v1284_9;
      if (!constant_0.empty()) {
        const Path v1285_5 = concat_path(p0,v1282_12_head);
        const Space v1285_6 = routine_98(c, constant_14, p1, v1285_5, constant_15);
        const Space v1285_7 = routine_99(c, constant_16, p1, v1285_5, constant_17);
        const Space v1285_8 = unite(v1285_6,v1285_7);
        v1284_9 = compose(constant_0,v1285_8);
      }
      Space v1284_10_result;
      for (int v1284_10_label = 1; v1284_10_label <= 2; ++v1284_10_label) {
        const Space v1284_10_tail = child(v1284_9,v1284_10_label);
        if (v1284_10_tail.empty()) continue;
        const Path v1284_10_head{v1284_10_label};
        const Space v1286_2 = singleton(v1284_10_head);
        const Space v1286_3 = intersect(constant_8,v1286_2);
        const Space v1286_4 = (has_head(v1286_3) ? constant_9 : Space{});
        const Space v1286_5 = subtract(constant_0,v1286_4);
        Space v1286_7;
        if (!v1286_5.empty()) {
          const Space v1287_6 = routine_100(c, v1284_10_head, v1284_10_tail, v1282_12_tail);
          v1286_7 = compose(v1286_5,v1287_6);
        }
        const Space v1286_8 = intersect(constant_8,v1286_2);
        const Space v1286_9 = (has_head(v1286_8) ? constant_9 : Space{});
        Space v1286_11;
        if (!v1286_9.empty()) {
          const Space v1288_10 = routine_101(c, v1284_10_head, v1284_10_tail, v1282_12_tail);
          v1286_11 = compose(v1286_9,v1288_10);
        }
        const Space v1286_12 = unite(v1286_7,v1286_11);
        v1284_10_result = unite(v1284_10_result,v1286_12);
      }
      const Space v1284_10 = std::move(v1284_10_result);
      v1283_11 = compose(v1283_4,v1284_10);
    }
    v1282_12_result = unite(v1282_12_result,v1283_11);
  }
  const Space v1282_12 = std::move(v1282_12_result);
  return v1282_12;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1289_13_result;
  for (int v1289_13_label = 1; v1289_13_label <= 2; ++v1289_13_label) {
    const Space v1289_13_tail = child(s0,v1289_13_label);
    if (v1289_13_tail.empty()) continue;
    const Path v1289_13_head{v1289_13_label};
    const Space v1290_2 = singleton(v1289_13_head);
    const Space v1290_3 = intersect(constant_8,v1290_2);
    const Space v1290_4 = (has_head(v1290_3) ? constant_9 : Space{});
    const Space v1290_5 = subtract(constant_0,v1290_4);
    Space v1290_8;
    if (!v1290_5.empty()) {
      const Path v1291_6 = concat_path(p0,v1289_13_head);
      Space v1291_7_result;
      for (int v1291_7_label = 1; v1291_7_label <= 2; ++v1291_7_label) {
        const Space v1291_7_tail = child(v1289_13_tail,v1291_7_label);
        if (v1291_7_tail.empty()) continue;
        const Path v1291_7_head{v1291_7_label};
        const Space v1292_2 = singleton(v1291_7_head);
        const Space v1292_3 = intersect(constant_8,v1292_2);
        const Space v1292_4 = (has_head(v1292_3) ? constant_9 : Space{});
        const Space v1292_5 = subtract(constant_0,v1292_4);
        Space v1292_8;
        if (!v1292_5.empty()) {
          const Path v1293_6 = concat_path(v1291_6,v1291_7_head);
          const Space v1293_7 = routine_226(c, v1293_6, p1, p2, v1291_7_tail);
          v1292_8 = compose(v1292_5,v1293_7);
        }
        const Space v1292_9 = intersect(constant_8,v1292_2);
        const Space v1292_10 = (has_head(v1292_9) ? constant_9 : Space{});
        Space v1292_12;
        if (!v1292_10.empty()) {
          const Path v1294_6 = concat_path(v1291_6,v1291_7_head);
          const Space v1294_11 = routine_227(c, v1294_6, p1, p2, v1291_7_tail);
          v1292_12 = compose(v1292_10,v1294_11);
        }
        const Space v1292_13 = unite(v1292_8,v1292_12);
        v1291_7_result = unite(v1291_7_result,v1292_13);
      }
      const Space v1291_7 = std::move(v1291_7_result);
      v1290_8 = compose(v1290_5,v1291_7);
    }
    const Space v1290_9 = intersect(constant_8,v1290_2);
    const Space v1290_10 = (has_head(v1290_9) ? constant_9 : Space{});
    Space v1290_12;
    if (!v1290_10.empty()) {
      const Path v1295_6 = concat_path(p0,v1289_13_head);
      Space v1295_11_result;
      for (int v1295_11_label = 1; v1295_11_label <= 2; ++v1295_11_label) {
        const Space v1295_11_tail = child(v1289_13_tail,v1295_11_label);
        if (v1295_11_tail.empty()) continue;
        const Path v1295_11_head{v1295_11_label};
        const Space v1296_2 = singleton(v1295_11_head);
        const Space v1296_3 = intersect(constant_8,v1296_2);
        const Space v1296_4 = (has_head(v1296_3) ? constant_9 : Space{});
        const Space v1296_5 = subtract(constant_0,v1296_4);
        Space v1296_8;
        if (!v1296_5.empty()) {
          const Path v1297_6 = concat_path(v1295_6,v1295_11_head);
          const Space v1297_7 = routine_226(c, v1297_6, p1, p2, v1295_11_tail);
          v1296_8 = compose(v1296_5,v1297_7);
        }
        const Space v1296_9 = intersect(constant_8,v1296_2);
        const Space v1296_10 = (has_head(v1296_9) ? constant_9 : Space{});
        Space v1296_12;
        if (!v1296_10.empty()) {
          const Path v1298_6 = concat_path(v1295_6,v1295_11_head);
          const Space v1298_11 = routine_138(c, v1298_6, p1, p2, v1295_11_tail);
          v1296_12 = compose(v1296_10,v1298_11);
        }
        const Space v1296_13 = unite(v1296_8,v1296_12);
        v1295_11_result = unite(v1295_11_result,v1296_13);
      }
      const Space v1295_11 = std::move(v1295_11_result);
      v1290_12 = compose(v1290_10,v1295_11);
    }
    const Space v1290_13 = unite(v1290_8,v1290_12);
    v1289_13_result = unite(v1289_13_result,v1290_13);
  }
  const Space v1289_13 = std::move(v1289_13_result);
  return v1289_13;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1299_13_result;
  for (int v1299_13_label = 1; v1299_13_label <= 2; ++v1299_13_label) {
    const Space v1299_13_tail = child(s0,v1299_13_label);
    if (v1299_13_tail.empty()) continue;
    const Path v1299_13_head{v1299_13_label};
    const Space v1300_2 = singleton(v1299_13_head);
    const Space v1300_3 = intersect(constant_8,v1300_2);
    const Space v1300_4 = (has_head(v1300_3) ? constant_9 : Space{});
    const Space v1300_5 = subtract(constant_0,v1300_4);
    Space v1300_8;
    if (!v1300_5.empty()) {
      const Path v1301_6 = concat_path(p0,v1299_13_head);
      Space v1301_7_result;
      for (int v1301_7_label = 1; v1301_7_label <= 2; ++v1301_7_label) {
        const Space v1301_7_tail = child(v1299_13_tail,v1301_7_label);
        if (v1301_7_tail.empty()) continue;
        const Path v1301_7_head{v1301_7_label};
        const Space v1302_2 = singleton(v1301_7_head);
        const Space v1302_3 = intersect(constant_8,v1302_2);
        const Space v1302_4 = (has_head(v1302_3) ? constant_9 : Space{});
        const Space v1302_5 = subtract(constant_0,v1302_4);
        Space v1302_8;
        if (!v1302_5.empty()) {
          const Path v1303_6 = concat_path(v1301_6,v1301_7_head);
          const Space v1303_7 = routine_226(c, v1303_6, p1, p2, v1301_7_tail);
          v1302_8 = compose(v1302_5,v1303_7);
        }
        const Space v1302_9 = intersect(constant_8,v1302_2);
        const Space v1302_10 = (has_head(v1302_9) ? constant_9 : Space{});
        Space v1302_12;
        if (!v1302_10.empty()) {
          const Path v1304_6 = concat_path(v1301_6,v1301_7_head);
          const Space v1304_11 = routine_227(c, v1304_6, p1, p2, v1301_7_tail);
          v1302_12 = compose(v1302_10,v1304_11);
        }
        const Space v1302_13 = unite(v1302_8,v1302_12);
        v1301_7_result = unite(v1301_7_result,v1302_13);
      }
      const Space v1301_7 = std::move(v1301_7_result);
      v1300_8 = compose(v1300_5,v1301_7);
    }
    const Space v1300_9 = intersect(constant_8,v1300_2);
    const Space v1300_10 = (has_head(v1300_9) ? constant_9 : Space{});
    Space v1300_12;
    if (!v1300_10.empty()) {
      const Path v1305_6 = concat_path(p0,v1299_13_head);
      Space v1305_11_result;
      for (int v1305_11_label = 1; v1305_11_label <= 2; ++v1305_11_label) {
        const Space v1305_11_tail = child(v1299_13_tail,v1305_11_label);
        if (v1305_11_tail.empty()) continue;
        const Path v1305_11_head{v1305_11_label};
        const Space v1306_2 = singleton(v1305_11_head);
        const Space v1306_3 = intersect(constant_8,v1306_2);
        const Space v1306_4 = (has_head(v1306_3) ? constant_9 : Space{});
        const Space v1306_5 = subtract(constant_0,v1306_4);
        Space v1306_7;
        if (!v1306_5.empty()) {
          const Space v1307_6 = routine_182(c, v1305_11_head, p1, p2, v1305_6, v1305_11_tail);
          v1306_7 = compose(v1306_5,v1307_6);
        }
        const Space v1306_8 = intersect(constant_8,v1306_2);
        const Space v1306_9 = (has_head(v1306_8) ? constant_9 : Space{});
        Space v1306_11;
        if (!v1306_9.empty()) {
          const Space v1308_10 = routine_183(c, v1305_11_head, p1, p2, v1305_6, v1305_11_tail);
          v1306_11 = compose(v1306_9,v1308_10);
        }
        const Space v1306_12 = unite(v1306_7,v1306_11);
        v1305_11_result = unite(v1305_11_result,v1306_12);
      }
      const Space v1305_11 = std::move(v1305_11_result);
      v1300_12 = compose(v1300_10,v1305_11);
    }
    const Space v1300_13 = unite(v1300_8,v1300_12);
    v1299_13_result = unite(v1299_13_result,v1300_13);
  }
  const Space v1299_13 = std::move(v1299_13_result);
  return v1299_13;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1309_13_result;
  for (int v1309_13_label = 1; v1309_13_label <= 2; ++v1309_13_label) {
    const Space v1309_13_tail = child(s0,v1309_13_label);
    if (v1309_13_tail.empty()) continue;
    const Path v1309_13_head{v1309_13_label};
    const Space v1310_2 = singleton(v1309_13_head);
    const Space v1310_3 = intersect(constant_8,v1310_2);
    const Space v1310_4 = (has_head(v1310_3) ? constant_9 : Space{});
    const Space v1310_5 = subtract(constant_0,v1310_4);
    Space v1310_7;
    if (!v1310_5.empty()) {
      Space v1311_6_result;
      for (int v1311_6_label = 1; v1311_6_label <= 2; ++v1311_6_label) {
        const Space v1311_6_tail = child(v1309_13_tail,v1311_6_label);
        if (v1311_6_tail.empty()) continue;
        const Path v1311_6_head{v1311_6_label};
        const Space v1312_2 = singleton(v1311_6_head);
        const Space v1312_3 = intersect(constant_8,v1312_2);
        const Space v1312_4 = (has_head(v1312_3) ? constant_9 : Space{});
        const Space v1312_5 = subtract(constant_0,v1312_4);
        Space v1312_8;
        if (!v1312_5.empty()) {
          const Path v1313_6 = concat_path(v1309_13_head,v1311_6_head);
          const Space v1313_7 = routine_228(c, v1313_6, p1, p2, p0, v1311_6_tail);
          v1312_8 = compose(v1312_5,v1313_7);
        }
        const Space v1312_9 = intersect(constant_8,v1312_2);
        const Space v1312_10 = (has_head(v1312_9) ? constant_9 : Space{});
        Space v1312_12;
        if (!v1312_10.empty()) {
          const Path v1314_6 = concat_path(v1309_13_head,v1311_6_head);
          const Space v1314_11 = routine_229(c, v1314_6, p1, p2, p0, v1311_6_tail);
          v1312_12 = compose(v1312_10,v1314_11);
        }
        const Space v1312_13 = unite(v1312_8,v1312_12);
        v1311_6_result = unite(v1311_6_result,v1312_13);
      }
      const Space v1311_6 = std::move(v1311_6_result);
      v1310_7 = compose(v1310_5,v1311_6);
    }
    const Space v1310_8 = intersect(constant_8,v1310_2);
    const Space v1310_9 = (has_head(v1310_8) ? constant_9 : Space{});
    Space v1310_11;
    if (!v1310_9.empty()) {
      Space v1315_10_result;
      for (int v1315_10_label = 1; v1315_10_label <= 2; ++v1315_10_label) {
        const Space v1315_10_tail = child(v1309_13_tail,v1315_10_label);
        if (v1315_10_tail.empty()) continue;
        const Path v1315_10_head{v1315_10_label};
        const Space v1316_2 = singleton(v1315_10_head);
        const Space v1316_3 = intersect(constant_8,v1316_2);
        const Space v1316_4 = (has_head(v1316_3) ? constant_9 : Space{});
        const Space v1316_5 = subtract(constant_0,v1316_4);
        Space v1316_8;
        if (!v1316_5.empty()) {
          const Path v1317_6 = concat_path(v1309_13_head,v1315_10_head);
          const Space v1317_7 = routine_228(c, v1317_6, p1, p2, p0, v1315_10_tail);
          v1316_8 = compose(v1316_5,v1317_7);
        }
        const Space v1316_9 = intersect(constant_8,v1316_2);
        const Space v1316_10 = (has_head(v1316_9) ? constant_9 : Space{});
        Space v1316_12;
        if (!v1316_10.empty()) {
          const Path v1318_6 = concat_path(v1309_13_head,v1315_10_head);
          const Space v1318_11 = routine_230(c, v1318_6, p1, p2, p0, v1315_10_tail);
          v1316_12 = compose(v1316_10,v1318_11);
        }
        const Space v1316_13 = unite(v1316_8,v1316_12);
        v1315_10_result = unite(v1315_10_result,v1316_13);
      }
      const Space v1315_10 = std::move(v1315_10_result);
      v1310_11 = compose(v1310_9,v1315_10);
    }
    const Space v1310_12 = unite(v1310_7,v1310_11);
    v1309_13_result = unite(v1309_13_result,v1310_12);
  }
  const Space v1309_13 = std::move(v1309_13_result);
  return v1309_13;
}

static Space routine_139(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1319_12_result;
  for (int v1319_12_label = 1; v1319_12_label <= 2; ++v1319_12_label) {
    const Space v1319_12_tail = child(s0,v1319_12_label);
    if (v1319_12_tail.empty()) continue;
    const Path v1319_12_head{v1319_12_label};
    const Space v1320_2 = singleton(v1319_12_head);
    const Space v1320_3 = intersect(constant_8,v1320_2);
    const Space v1320_4 = (has_head(v1320_3) ? constant_9 : Space{});
    const Space v1320_5 = subtract(constant_0,v1320_4);
    Space v1320_8;
    if (!v1320_5.empty()) {
      const Path v1321_6 = concat_path(p0,v1319_12_head);
      Space v1321_7_result;
      for (int v1321_7_label = 1; v1321_7_label <= 2; ++v1321_7_label) {
        const Space v1321_7_tail = child(v1319_12_tail,v1321_7_label);
        if (v1321_7_tail.empty()) continue;
        const Path v1321_7_head{v1321_7_label};
        const Space v1322_2 = singleton(v1321_7_head);
        const Space v1322_3 = intersect(constant_8,v1322_2);
        const Space v1322_4 = (has_head(v1322_3) ? constant_9 : Space{});
        const Space v1322_5 = subtract(constant_0,v1322_4);
        Space v1322_8;
        if (!v1322_5.empty()) {
          const Path v1323_6 = concat_path(v1321_6,v1321_7_head);
          const Space v1323_7 = routine_231(c, v1323_6, v1321_7_tail, s1);
          v1322_8 = compose(v1322_5,v1323_7);
        }
        const Space v1322_9 = intersect(constant_8,v1322_2);
        const Space v1322_10 = (has_head(v1322_9) ? constant_9 : Space{});
        Space v1322_12;
        if (!v1322_10.empty()) {
          const Path v1324_6 = concat_path(v1321_6,v1321_7_head);
          const Space v1324_11 = routine_232(c, v1324_6, v1321_7_tail, s1);
          v1322_12 = compose(v1322_10,v1324_11);
        }
        const Space v1322_13 = unite(v1322_8,v1322_12);
        v1321_7_result = unite(v1321_7_result,v1322_13);
      }
      const Space v1321_7 = std::move(v1321_7_result);
      v1320_8 = compose(v1320_5,v1321_7);
    }
    const Space v1320_9 = intersect(constant_8,v1320_2);
    const Space v1320_10 = (has_head(v1320_9) ? constant_9 : Space{});
    Space v1320_12;
    if (!v1320_10.empty()) {
      const Path v1325_6 = concat_path(p0,v1319_12_head);
      Space v1325_11_result;
      for (int v1325_11_label = 1; v1325_11_label <= 2; ++v1325_11_label) {
        const Space v1325_11_tail = child(v1319_12_tail,v1325_11_label);
        if (v1325_11_tail.empty()) continue;
        const Path v1325_11_head{v1325_11_label};
        const Space v1326_2 = singleton(v1325_11_head);
        const Space v1326_3 = intersect(constant_8,v1326_2);
        const Space v1326_4 = (has_head(v1326_3) ? constant_9 : Space{});
        const Space v1326_5 = subtract(constant_0,v1326_4);
        Space v1326_8;
        if (!v1326_5.empty()) {
          const Path v1327_6 = concat_path(v1325_6,v1325_11_head);
          const Space v1327_7 = routine_231(c, v1327_6, v1325_11_tail, s1);
          v1326_8 = compose(v1326_5,v1327_7);
        }
        const Space v1326_9 = intersect(constant_8,v1326_2);
        const Space v1326_10 = (has_head(v1326_9) ? constant_9 : Space{});
        Space v1326_12;
        if (!v1326_10.empty()) {
          const Path v1328_6 = concat_path(v1325_6,v1325_11_head);
          const Space v1328_11 = routine_141(c, v1328_6, v1325_11_tail, s1);
          v1326_12 = compose(v1326_10,v1328_11);
        }
        const Space v1326_13 = unite(v1326_8,v1326_12);
        v1325_11_result = unite(v1325_11_result,v1326_13);
      }
      const Space v1325_11 = std::move(v1325_11_result);
      v1320_12 = compose(v1320_10,v1325_11);
    }
    const Space v1320_13 = unite(v1320_8,v1320_12);
    v1319_12_result = unite(v1319_12_result,v1320_13);
  }
  const Space v1319_12 = std::move(v1319_12_result);
  return v1319_12;
}

static Space routine_140(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1329_9_result;
  for (int v1329_9_label = 1; v1329_9_label <= 2; ++v1329_9_label) {
    const Space v1329_9_tail = child(s0,v1329_9_label);
    if (v1329_9_tail.empty()) continue;
    const Path v1329_9_head{v1329_9_label};
    const Space v1330_2 = singleton(v1329_9_head);
    const Space v1330_3 = intersect(constant_8,v1330_2);
    const Space v1330_4 = (has_head(v1330_3) ? constant_9 : Space{});
    const Space v1330_5 = subtract(constant_0,v1330_4);
    Space v1330_8;
    if (!v1330_5.empty()) {
      const Path v1331_6 = concat_path(p0,v1329_9_head);
      Space v1331_7_result;
      for (int v1331_7_label = 1; v1331_7_label <= 2; ++v1331_7_label) {
        const Space v1331_7_tail = child(v1329_9_tail,v1331_7_label);
        if (v1331_7_tail.empty()) continue;
        const Path v1331_7_head{v1331_7_label};
        const Space v1332_2 = singleton(v1331_7_head);
        const Space v1332_3 = intersect(constant_8,v1332_2);
        const Space v1332_4 = (has_head(v1332_3) ? constant_9 : Space{});
        const Space v1332_5 = subtract(constant_0,v1332_4);
        Space v1332_8;
        if (!v1332_5.empty()) {
          const Path v1333_6 = concat_path(v1331_6,v1331_7_head);
          const Space v1333_7 = routine_231(c, v1333_6, v1331_7_tail, s1);
          v1332_8 = compose(v1332_5,v1333_7);
        }
        const Space v1332_9 = intersect(constant_8,v1332_2);
        const Space v1332_10 = (has_head(v1332_9) ? constant_9 : Space{});
        Space v1332_12;
        if (!v1332_10.empty()) {
          const Path v1334_6 = concat_path(v1331_6,v1331_7_head);
          const Space v1334_11 = routine_232(c, v1334_6, v1331_7_tail, s1);
          v1332_12 = compose(v1332_10,v1334_11);
        }
        const Space v1332_13 = unite(v1332_8,v1332_12);
        v1331_7_result = unite(v1331_7_result,v1332_13);
      }
      const Space v1331_7 = std::move(v1331_7_result);
      v1330_8 = compose(v1330_5,v1331_7);
    }
    const Space v1330_9 = intersect(constant_8,v1330_2);
    const Space v1330_10 = (has_head(v1330_9) ? constant_9 : Space{});
    Space v1330_12;
    if (!v1330_10.empty()) {
      const Path v1335_6 = concat_path(p0,v1329_9_head);
      const Space v1335_11 = routine_186(c, v1335_6, s1);
      v1330_12 = compose(v1330_10,v1335_11);
    }
    const Space v1330_13 = unite(v1330_8,v1330_12);
    v1329_9_result = unite(v1329_9_result,v1330_13);
  }
  const Space v1329_9 = std::move(v1329_9_result);
  return v1329_9;
}

static Space routine_141(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1336_4 = singleton(p0);
  const Space v1336_5 = intersect(constant_10,v1336_4);
  const Space v1336_7 = unwrap(s1,constant_22);
  const Space v1336_9 = unwrap(s1,constant_23);
  const Space v1336_10 = compose(v1336_7,v1336_9);
  const Space v1336_12 = unwrap(s1,constant_6);
  const Space v1336_13 = compose(v1336_10,v1336_12);
  const Space v1336_14 = compose(v1336_5,v1336_13);
  const Space v1336_16 = intersect(constant_11,v1336_4);
  const Space v1336_17 = compose(v1336_7,v1336_12);
  const Space v1336_19 = unwrap(s1,constant_24);
  const Space v1336_20 = compose(v1336_17,v1336_19);
  const Space v1336_21 = compose(v1336_16,v1336_20);
  const Space v1336_22 = unite(v1336_14,v1336_21);
  const Space v1336_24 = intersect(constant_12,v1336_4);
  const Space v1336_25 = compose(v1336_9,v1336_12);
  const Space v1336_26 = compose(v1336_25,v1336_19);
  const Space v1336_27 = compose(v1336_24,v1336_26);
  const Space v1336_28 = unite(v1336_22,v1336_27);
  const Space v1336_30 = intersect(constant_13,v1336_4);
  const Space v1336_31 = compose(v1336_10,v1336_19);
  const Space v1336_32 = compose(v1336_30,v1336_31);
  const Space v1336_33 = unite(v1336_28,v1336_32);
  return v1336_33;
}

static Space routine_142(Context& c, const Path& p0, const Space& s0) {
  Space v1337_4_result;
  for (int v1337_4_label = 1; v1337_4_label <= 2; ++v1337_4_label) {
    const Space v1337_4_tail = child(s0,v1337_4_label);
    if (v1337_4_tail.empty()) continue;
    const Path v1337_4_head{v1337_4_label};
    const Space v1338_2 = singleton(v1337_4_head);
    const Space v1338_3 = intersect(constant_8,v1338_2);
    const Space v1338_4 = (has_head(v1338_3) ? constant_9 : Space{});
    Space v1338_7;
    if (!v1338_4.empty()) {
      const Path v1339_5 = concat_path(p0,v1337_4_head);
      Space v1339_6_result;
      for (int v1339_6_label = 1; v1339_6_label <= 2; ++v1339_6_label) {
        const Space v1339_6_tail = child(v1337_4_tail,v1339_6_label);
        if (v1339_6_tail.empty()) continue;
        const Path v1339_6_head{v1339_6_label};
        const Space v1340_2 = singleton(v1339_6_head);
        const Space v1340_3 = intersect(constant_8,v1340_2);
        const Space v1340_4 = (has_head(v1340_3) ? constant_9 : Space{});
        Space v1340_7;
        if (!v1340_4.empty()) {
          const Path v1341_5 = concat_path(v1339_5,v1339_6_head);
          const Space v1341_6 = routine_68(c, v1341_5, v1339_6_tail);
          v1340_7 = compose(v1340_4,v1341_6);
        }
        v1339_6_result = unite(v1339_6_result,v1340_7);
      }
      const Space v1339_6 = std::move(v1339_6_result);
      v1338_7 = compose(v1338_4,v1339_6);
    }
    v1337_4_result = unite(v1337_4_result,v1338_7);
  }
  const Space v1337_4 = std::move(v1337_4_result);
  return v1337_4;
}

static Space routine_143(Context& c, const Path& p0, const Space& s0) {
  Space v1342_3_result;
  for (int v1342_3_label = 1; v1342_3_label <= 2; ++v1342_3_label) {
    const Space v1342_3_tail = child(s0,v1342_3_label);
    if (v1342_3_tail.empty()) continue;
    const Path v1342_3_head{v1342_3_label};
    const Space v1343_2 = singleton(v1342_3_head);
    const Space v1343_3 = intersect(constant_8,v1343_2);
    const Space v1343_4 = (has_head(v1343_3) ? constant_9 : Space{});
    const Space v1343_5 = compose(v1343_4,v1342_3_tail);
    v1342_3_result = unite(v1342_3_result,v1343_5);
  }
  const Space v1342_3 = std::move(v1342_3_result);
  return v1342_3;
}

static Space routine_144(Context& c, const Path& p0, const Space& s0) {
  Space v1344_4_result;
  for (int v1344_4_label = 1; v1344_4_label <= 2; ++v1344_4_label) {
    const Space v1344_4_tail = child(s0,v1344_4_label);
    if (v1344_4_tail.empty()) continue;
    const Path v1344_4_head{v1344_4_label};
    const Space v1345_2 = singleton(v1344_4_head);
    const Space v1345_3 = intersect(constant_8,v1345_2);
    const Space v1345_4 = (has_head(v1345_3) ? constant_9 : Space{});
    Space v1345_7;
    if (!v1345_4.empty()) {
      const Path v1346_5 = concat_path(p0,v1344_4_head);
      Space v1346_6_result;
      for (int v1346_6_label = 1; v1346_6_label <= 2; ++v1346_6_label) {
        const Space v1346_6_tail = child(v1344_4_tail,v1346_6_label);
        if (v1346_6_tail.empty()) continue;
        const Path v1346_6_head{v1346_6_label};
        const Space v1347_2 = singleton(v1346_6_head);
        const Space v1347_3 = intersect(constant_8,v1347_2);
        const Space v1347_4 = (has_head(v1347_3) ? constant_9 : Space{});
        Space v1347_7;
        if (!v1347_4.empty()) {
          const Path v1348_5 = concat_path(v1346_5,v1346_6_head);
          const Space v1348_6 = routine_71(c, v1348_5, v1346_6_tail);
          v1347_7 = compose(v1347_4,v1348_6);
        }
        v1346_6_result = unite(v1346_6_result,v1347_7);
      }
      const Space v1346_6 = std::move(v1346_6_result);
      v1345_7 = compose(v1345_4,v1346_6);
    }
    v1344_4_result = unite(v1344_4_result,v1345_7);
  }
  const Space v1344_4 = std::move(v1344_4_result);
  return v1344_4;
}

static Space routine_145(Context& c, const Path& p0, const Space& s0) {
  Space v1349_6_result;
  for (int v1349_6_label = 1; v1349_6_label <= 2; ++v1349_6_label) {
    const Space v1349_6_tail = child(s0,v1349_6_label);
    if (v1349_6_tail.empty()) continue;
    const Path v1349_6_head{v1349_6_label};
    const Space v1350_2 = singleton(v1349_6_head);
    const Space v1350_3 = intersect(constant_8,v1350_2);
    const Space v1350_4 = (has_head(v1350_3) ? constant_9 : Space{});
    Space v1350_7;
    if (!v1350_4.empty()) {
      const Path v1351_5 = concat_path(p0,v1349_6_head);
      Space v1351_6_result;
      for (int v1351_6_label = 1; v1351_6_label <= 2; ++v1351_6_label) {
        const Space v1351_6_tail = child(v1349_6_tail,v1351_6_label);
        if (v1351_6_tail.empty()) continue;
        const Path v1351_6_head{v1351_6_label};
        const Space v1352_2 = singleton(v1351_6_head);
        const Space v1352_3 = intersect(constant_8,v1352_2);
        const Space v1352_4 = (has_head(v1352_3) ? constant_9 : Space{});
        const Space v1352_5 = subtract(constant_0,v1352_4);
        Space v1352_7;
        if (!v1352_5.empty()) {
          const Space v1353_6 = routine_106(c, v1351_6_head, v1351_5, v1351_6_tail);
          v1352_7 = compose(v1352_5,v1353_6);
        }
        const Space v1352_8 = intersect(constant_8,v1352_2);
        const Space v1352_9 = (has_head(v1352_8) ? constant_9 : Space{});
        Space v1352_11;
        if (!v1352_9.empty()) {
          const Space v1354_10 = routine_107(c, v1351_6_head, v1351_5, v1351_6_tail);
          v1352_11 = compose(v1352_9,v1354_10);
        }
        const Space v1352_12 = unite(v1352_7,v1352_11);
        v1351_6_result = unite(v1351_6_result,v1352_12);
      }
      const Space v1351_6 = std::move(v1351_6_result);
      v1350_7 = compose(v1350_4,v1351_6);
    }
    v1349_6_result = unite(v1349_6_result,v1350_7);
  }
  const Space v1349_6 = std::move(v1349_6_result);
  return v1349_6;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1355_12_result;
  for (int v1355_12_label = 1; v1355_12_label <= 2; ++v1355_12_label) {
    const Space v1355_12_tail = child(s0,v1355_12_label);
    if (v1355_12_tail.empty()) continue;
    const Path v1355_12_head{v1355_12_label};
    const Space v1356_2 = singleton(v1355_12_head);
    const Space v1356_3 = intersect(constant_8,v1356_2);
    const Space v1356_4 = (has_head(v1356_3) ? constant_9 : Space{});
    const Space v1356_5 = subtract(constant_0,v1356_4);
    Space v1356_8;
    if (!v1356_5.empty()) {
      const Path v1357_6 = concat_path(p0,v1355_12_head);
      Space v1357_7_result;
      for (int v1357_7_label = 1; v1357_7_label <= 2; ++v1357_7_label) {
        const Space v1357_7_tail = child(v1355_12_tail,v1357_7_label);
        if (v1357_7_tail.empty()) continue;
        const Path v1357_7_head{v1357_7_label};
        const Space v1358_2 = singleton(v1357_7_head);
        const Space v1358_3 = intersect(constant_8,v1358_2);
        const Space v1358_4 = (has_head(v1358_3) ? constant_9 : Space{});
        const Space v1358_5 = subtract(constant_0,v1358_4);
        Space v1358_8;
        if (!v1358_5.empty()) {
          const Path v1359_6 = concat_path(v1357_6,v1357_7_head);
          const Space v1359_7 = routine_233(c, v1359_6, p1, v1357_7_tail);
          v1358_8 = compose(v1358_5,v1359_7);
        }
        const Space v1358_9 = intersect(constant_8,v1358_2);
        const Space v1358_10 = (has_head(v1358_9) ? constant_9 : Space{});
        Space v1358_12;
        if (!v1358_10.empty()) {
          const Path v1360_6 = concat_path(v1357_6,v1357_7_head);
          const Space v1360_11 = routine_234(c, v1360_6, p1, v1357_7_tail);
          v1358_12 = compose(v1358_10,v1360_11);
        }
        const Space v1358_13 = unite(v1358_8,v1358_12);
        v1357_7_result = unite(v1357_7_result,v1358_13);
      }
      const Space v1357_7 = std::move(v1357_7_result);
      v1356_8 = compose(v1356_5,v1357_7);
    }
    const Space v1356_9 = intersect(constant_8,v1356_2);
    const Space v1356_10 = (has_head(v1356_9) ? constant_9 : Space{});
    Space v1356_12;
    if (!v1356_10.empty()) {
      const Path v1361_6 = concat_path(p0,v1355_12_head);
      Space v1361_11_result;
      for (int v1361_11_label = 1; v1361_11_label <= 2; ++v1361_11_label) {
        const Space v1361_11_tail = child(v1355_12_tail,v1361_11_label);
        if (v1361_11_tail.empty()) continue;
        const Path v1361_11_head{v1361_11_label};
        const Space v1362_2 = singleton(v1361_11_head);
        const Space v1362_3 = intersect(constant_8,v1362_2);
        const Space v1362_4 = (has_head(v1362_3) ? constant_9 : Space{});
        const Space v1362_5 = subtract(constant_0,v1362_4);
        Space v1362_8;
        if (!v1362_5.empty()) {
          const Path v1363_6 = concat_path(v1361_6,v1361_11_head);
          const Space v1363_7 = routine_233(c, v1363_6, p1, v1361_11_tail);
          v1362_8 = compose(v1362_5,v1363_7);
        }
        const Space v1362_9 = intersect(constant_8,v1362_2);
        const Space v1362_10 = (has_head(v1362_9) ? constant_9 : Space{});
        Space v1362_12;
        if (!v1362_10.empty()) {
          const Path v1364_6 = concat_path(v1361_6,v1361_11_head);
          const Space v1364_11 = routine_148(c, v1364_6, p1, v1361_11_tail);
          v1362_12 = compose(v1362_10,v1364_11);
        }
        const Space v1362_13 = unite(v1362_8,v1362_12);
        v1361_11_result = unite(v1361_11_result,v1362_13);
      }
      const Space v1361_11 = std::move(v1361_11_result);
      v1356_12 = compose(v1356_10,v1361_11);
    }
    const Space v1356_13 = unite(v1356_8,v1356_12);
    v1355_12_result = unite(v1355_12_result,v1356_13);
  }
  const Space v1355_12 = std::move(v1355_12_result);
  return v1355_12;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1365_12_result;
  for (int v1365_12_label = 1; v1365_12_label <= 2; ++v1365_12_label) {
    const Space v1365_12_tail = child(s0,v1365_12_label);
    if (v1365_12_tail.empty()) continue;
    const Path v1365_12_head{v1365_12_label};
    const Space v1366_2 = singleton(v1365_12_head);
    const Space v1366_3 = intersect(constant_8,v1366_2);
    const Space v1366_4 = (has_head(v1366_3) ? constant_9 : Space{});
    const Space v1366_5 = subtract(constant_0,v1366_4);
    Space v1366_8;
    if (!v1366_5.empty()) {
      const Path v1367_6 = concat_path(p0,v1365_12_head);
      Space v1367_7_result;
      for (int v1367_7_label = 1; v1367_7_label <= 2; ++v1367_7_label) {
        const Space v1367_7_tail = child(v1365_12_tail,v1367_7_label);
        if (v1367_7_tail.empty()) continue;
        const Path v1367_7_head{v1367_7_label};
        const Space v1368_2 = singleton(v1367_7_head);
        const Space v1368_3 = intersect(constant_8,v1368_2);
        const Space v1368_4 = (has_head(v1368_3) ? constant_9 : Space{});
        const Space v1368_5 = subtract(constant_0,v1368_4);
        Space v1368_8;
        if (!v1368_5.empty()) {
          const Path v1369_6 = concat_path(v1367_6,v1367_7_head);
          const Space v1369_7 = routine_233(c, v1369_6, p1, v1367_7_tail);
          v1368_8 = compose(v1368_5,v1369_7);
        }
        const Space v1368_9 = intersect(constant_8,v1368_2);
        const Space v1368_10 = (has_head(v1368_9) ? constant_9 : Space{});
        Space v1368_12;
        if (!v1368_10.empty()) {
          const Path v1370_6 = concat_path(v1367_6,v1367_7_head);
          const Space v1370_11 = routine_234(c, v1370_6, p1, v1367_7_tail);
          v1368_12 = compose(v1368_10,v1370_11);
        }
        const Space v1368_13 = unite(v1368_8,v1368_12);
        v1367_7_result = unite(v1367_7_result,v1368_13);
      }
      const Space v1367_7 = std::move(v1367_7_result);
      v1366_8 = compose(v1366_5,v1367_7);
    }
    const Space v1366_9 = intersect(constant_8,v1366_2);
    const Space v1366_10 = (has_head(v1366_9) ? constant_9 : Space{});
    Space v1366_12;
    if (!v1366_10.empty()) {
      const Path v1371_6 = concat_path(p0,v1365_12_head);
      Space v1371_11_result;
      for (int v1371_11_label = 1; v1371_11_label <= 2; ++v1371_11_label) {
        const Space v1371_11_tail = child(v1365_12_tail,v1371_11_label);
        if (v1371_11_tail.empty()) continue;
        const Path v1371_11_head{v1371_11_label};
        const Space v1372_2 = singleton(v1371_11_head);
        const Space v1372_3 = intersect(constant_8,v1372_2);
        const Space v1372_4 = (has_head(v1372_3) ? constant_9 : Space{});
        const Space v1372_5 = subtract(constant_0,v1372_4);
        Space v1372_7;
        if (!v1372_5.empty()) {
          const Space v1373_6 = routine_193(c, v1371_11_head, p1, v1371_6, v1371_11_tail);
          v1372_7 = compose(v1372_5,v1373_6);
        }
        const Space v1372_8 = intersect(constant_8,v1372_2);
        const Space v1372_9 = (has_head(v1372_8) ? constant_9 : Space{});
        Space v1372_11;
        if (!v1372_9.empty()) {
          const Space v1374_10 = routine_194(c, v1371_11_head, p1, v1371_6, v1371_11_tail);
          v1372_11 = compose(v1372_9,v1374_10);
        }
        const Space v1372_12 = unite(v1372_7,v1372_11);
        v1371_11_result = unite(v1371_11_result,v1372_12);
      }
      const Space v1371_11 = std::move(v1371_11_result);
      v1366_12 = compose(v1366_10,v1371_11);
    }
    const Space v1366_13 = unite(v1366_8,v1366_12);
    v1365_12_result = unite(v1365_12_result,v1366_13);
  }
  const Space v1365_12 = std::move(v1365_12_result);
  return v1365_12;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1375_12_result;
  for (int v1375_12_label = 1; v1375_12_label <= 2; ++v1375_12_label) {
    const Space v1375_12_tail = child(s0,v1375_12_label);
    if (v1375_12_tail.empty()) continue;
    const Path v1375_12_head{v1375_12_label};
    const Space v1376_2 = singleton(v1375_12_head);
    const Space v1376_3 = intersect(constant_8,v1376_2);
    const Space v1376_4 = (has_head(v1376_3) ? constant_9 : Space{});
    const Space v1376_5 = subtract(constant_0,v1376_4);
    Space v1376_7;
    if (!v1376_5.empty()) {
      Space v1377_6_result;
      for (int v1377_6_label = 1; v1377_6_label <= 2; ++v1377_6_label) {
        const Space v1377_6_tail = child(v1375_12_tail,v1377_6_label);
        if (v1377_6_tail.empty()) continue;
        const Path v1377_6_head{v1377_6_label};
        const Space v1378_2 = singleton(v1377_6_head);
        const Space v1378_3 = intersect(constant_8,v1378_2);
        const Space v1378_4 = (has_head(v1378_3) ? constant_9 : Space{});
        const Space v1378_5 = subtract(constant_0,v1378_4);
        Space v1378_8;
        if (!v1378_5.empty()) {
          const Path v1379_6 = concat_path(v1375_12_head,v1377_6_head);
          const Space v1379_7 = routine_235(c, v1379_6, p1, p0, v1377_6_tail);
          v1378_8 = compose(v1378_5,v1379_7);
        }
        const Space v1378_9 = intersect(constant_8,v1378_2);
        const Space v1378_10 = (has_head(v1378_9) ? constant_9 : Space{});
        Space v1378_12;
        if (!v1378_10.empty()) {
          const Path v1380_6 = concat_path(v1375_12_head,v1377_6_head);
          const Space v1380_11 = routine_236(c, v1380_6, p1, p0, v1377_6_tail);
          v1378_12 = compose(v1378_10,v1380_11);
        }
        const Space v1378_13 = unite(v1378_8,v1378_12);
        v1377_6_result = unite(v1377_6_result,v1378_13);
      }
      const Space v1377_6 = std::move(v1377_6_result);
      v1376_7 = compose(v1376_5,v1377_6);
    }
    const Space v1376_8 = intersect(constant_8,v1376_2);
    const Space v1376_9 = (has_head(v1376_8) ? constant_9 : Space{});
    Space v1376_11;
    if (!v1376_9.empty()) {
      Space v1381_10_result;
      for (int v1381_10_label = 1; v1381_10_label <= 2; ++v1381_10_label) {
        const Space v1381_10_tail = child(v1375_12_tail,v1381_10_label);
        if (v1381_10_tail.empty()) continue;
        const Path v1381_10_head{v1381_10_label};
        const Space v1382_2 = singleton(v1381_10_head);
        const Space v1382_3 = intersect(constant_8,v1382_2);
        const Space v1382_4 = (has_head(v1382_3) ? constant_9 : Space{});
        const Space v1382_5 = subtract(constant_0,v1382_4);
        Space v1382_8;
        if (!v1382_5.empty()) {
          const Path v1383_6 = concat_path(v1375_12_head,v1381_10_head);
          const Space v1383_7 = routine_235(c, v1383_6, p1, p0, v1381_10_tail);
          v1382_8 = compose(v1382_5,v1383_7);
        }
        const Space v1382_9 = intersect(constant_8,v1382_2);
        const Space v1382_10 = (has_head(v1382_9) ? constant_9 : Space{});
        Space v1382_12;
        if (!v1382_10.empty()) {
          const Path v1384_6 = concat_path(v1375_12_head,v1381_10_head);
          const Space v1384_11 = routine_237(c, v1384_6, p1, p0, v1381_10_tail);
          v1382_12 = compose(v1382_10,v1384_11);
        }
        const Space v1382_13 = unite(v1382_8,v1382_12);
        v1381_10_result = unite(v1381_10_result,v1382_13);
      }
      const Space v1381_10 = std::move(v1381_10_result);
      v1376_11 = compose(v1376_9,v1381_10);
    }
    const Space v1376_12 = unite(v1376_7,v1376_11);
    v1375_12_result = unite(v1375_12_result,v1376_12);
  }
  const Space v1375_12 = std::move(v1375_12_result);
  return v1375_12;
}

static Space routine_149(Context& c, const Path& p0, const Space& s0) {
  Space v1385_4_result;
  for (int v1385_4_label = 1; v1385_4_label <= 2; ++v1385_4_label) {
    const Space v1385_4_tail = child(s0,v1385_4_label);
    if (v1385_4_tail.empty()) continue;
    const Path v1385_4_head{v1385_4_label};
    const Space v1386_2 = singleton(v1385_4_head);
    const Space v1386_3 = intersect(constant_8,v1386_2);
    const Space v1386_4 = (has_head(v1386_3) ? constant_9 : Space{});
    Space v1386_7;
    if (!v1386_4.empty()) {
      const Path v1387_5 = concat_path(p0,v1385_4_head);
      Space v1387_6_result;
      for (int v1387_6_label = 1; v1387_6_label <= 2; ++v1387_6_label) {
        const Space v1387_6_tail = child(v1385_4_tail,v1387_6_label);
        if (v1387_6_tail.empty()) continue;
        const Path v1387_6_head{v1387_6_label};
        const Space v1388_2 = singleton(v1387_6_head);
        const Space v1388_3 = intersect(constant_8,v1388_2);
        const Space v1388_4 = (has_head(v1388_3) ? constant_9 : Space{});
        Space v1388_7;
        if (!v1388_4.empty()) {
          const Path v1389_5 = concat_path(v1387_5,v1387_6_head);
          const Space v1389_6 = routine_74(c, v1389_5, v1387_6_tail);
          v1388_7 = compose(v1388_4,v1389_6);
        }
        v1387_6_result = unite(v1387_6_result,v1388_7);
      }
      const Space v1387_6 = std::move(v1387_6_result);
      v1386_7 = compose(v1386_4,v1387_6);
    }
    v1385_4_result = unite(v1385_4_result,v1386_7);
  }
  const Space v1385_4 = std::move(v1385_4_result);
  return v1385_4;
}

static Space routine_150(Context& c, const Path& p0, const Space& s0) {
  Space v1390_3_result;
  for (int v1390_3_label = 1; v1390_3_label <= 2; ++v1390_3_label) {
    const Space v1390_3_tail = child(s0,v1390_3_label);
    if (v1390_3_tail.empty()) continue;
    const Path v1390_3_head{v1390_3_label};
    const Space v1391_2 = singleton(v1390_3_head);
    const Space v1391_3 = intersect(constant_8,v1391_2);
    const Space v1391_4 = (has_head(v1391_3) ? constant_9 : Space{});
    const Space v1391_5 = compose(v1391_4,v1390_3_tail);
    v1390_3_result = unite(v1390_3_result,v1391_5);
  }
  const Space v1390_3 = std::move(v1390_3_result);
  return v1390_3;
}

static Space routine_151(Context& c, const Path& p0, const Space& s0) {
  Space v1392_4_result;
  for (int v1392_4_label = 1; v1392_4_label <= 2; ++v1392_4_label) {
    const Space v1392_4_tail = child(s0,v1392_4_label);
    if (v1392_4_tail.empty()) continue;
    const Path v1392_4_head{v1392_4_label};
    const Space v1393_2 = singleton(v1392_4_head);
    const Space v1393_3 = intersect(constant_8,v1393_2);
    const Space v1393_4 = (has_head(v1393_3) ? constant_9 : Space{});
    Space v1393_7;
    if (!v1393_4.empty()) {
      const Path v1394_5 = concat_path(p0,v1392_4_head);
      Space v1394_6_result;
      for (int v1394_6_label = 1; v1394_6_label <= 2; ++v1394_6_label) {
        const Space v1394_6_tail = child(v1392_4_tail,v1394_6_label);
        if (v1394_6_tail.empty()) continue;
        const Path v1394_6_head{v1394_6_label};
        const Space v1395_2 = singleton(v1394_6_head);
        const Space v1395_3 = intersect(constant_8,v1395_2);
        const Space v1395_4 = (has_head(v1395_3) ? constant_9 : Space{});
        Space v1395_7;
        if (!v1395_4.empty()) {
          const Path v1396_5 = concat_path(v1394_5,v1394_6_head);
          const Space v1396_6 = routine_77(c, v1396_5, v1394_6_tail);
          v1395_7 = compose(v1395_4,v1396_6);
        }
        v1394_6_result = unite(v1394_6_result,v1395_7);
      }
      const Space v1394_6 = std::move(v1394_6_result);
      v1393_7 = compose(v1393_4,v1394_6);
    }
    v1392_4_result = unite(v1392_4_result,v1393_7);
  }
  const Space v1392_4 = std::move(v1392_4_result);
  return v1392_4;
}

static Space routine_152(Context& c, const Path& p0, const Space& s0) {
  Space v1397_6_result;
  for (int v1397_6_label = 1; v1397_6_label <= 2; ++v1397_6_label) {
    const Space v1397_6_tail = child(s0,v1397_6_label);
    if (v1397_6_tail.empty()) continue;
    const Path v1397_6_head{v1397_6_label};
    const Space v1398_2 = singleton(v1397_6_head);
    const Space v1398_3 = intersect(constant_8,v1398_2);
    const Space v1398_4 = (has_head(v1398_3) ? constant_9 : Space{});
    Space v1398_7;
    if (!v1398_4.empty()) {
      const Path v1399_5 = concat_path(p0,v1397_6_head);
      Space v1399_6_result;
      for (int v1399_6_label = 1; v1399_6_label <= 2; ++v1399_6_label) {
        const Space v1399_6_tail = child(v1397_6_tail,v1399_6_label);
        if (v1399_6_tail.empty()) continue;
        const Path v1399_6_head{v1399_6_label};
        const Space v1400_2 = singleton(v1399_6_head);
        const Space v1400_3 = intersect(constant_8,v1400_2);
        const Space v1400_4 = (has_head(v1400_3) ? constant_9 : Space{});
        const Space v1400_5 = subtract(constant_0,v1400_4);
        Space v1400_7;
        if (!v1400_5.empty()) {
          const Space v1401_6 = routine_112(c, v1399_6_head, v1399_5, v1399_6_tail);
          v1400_7 = compose(v1400_5,v1401_6);
        }
        const Space v1400_8 = intersect(constant_8,v1400_2);
        const Space v1400_9 = (has_head(v1400_8) ? constant_9 : Space{});
        Space v1400_11;
        if (!v1400_9.empty()) {
          const Space v1402_10 = routine_113(c, v1399_6_head, v1399_5, v1399_6_tail);
          v1400_11 = compose(v1400_9,v1402_10);
        }
        const Space v1400_12 = unite(v1400_7,v1400_11);
        v1399_6_result = unite(v1399_6_result,v1400_12);
      }
      const Space v1399_6 = std::move(v1399_6_result);
      v1398_7 = compose(v1398_4,v1399_6);
    }
    v1397_6_result = unite(v1397_6_result,v1398_7);
  }
  const Space v1397_6 = std::move(v1397_6_result);
  return v1397_6;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1403_12_result;
  for (int v1403_12_label = 1; v1403_12_label <= 2; ++v1403_12_label) {
    const Space v1403_12_tail = child(s0,v1403_12_label);
    if (v1403_12_tail.empty()) continue;
    const Path v1403_12_head{v1403_12_label};
    const Space v1404_2 = singleton(v1403_12_head);
    const Space v1404_3 = intersect(constant_8,v1404_2);
    const Space v1404_4 = (has_head(v1404_3) ? constant_9 : Space{});
    const Space v1404_5 = subtract(constant_0,v1404_4);
    Space v1404_8;
    if (!v1404_5.empty()) {
      const Path v1405_6 = concat_path(p0,v1403_12_head);
      Space v1405_7_result;
      for (int v1405_7_label = 1; v1405_7_label <= 2; ++v1405_7_label) {
        const Space v1405_7_tail = child(v1403_12_tail,v1405_7_label);
        if (v1405_7_tail.empty()) continue;
        const Path v1405_7_head{v1405_7_label};
        const Space v1406_2 = singleton(v1405_7_head);
        const Space v1406_3 = intersect(constant_8,v1406_2);
        const Space v1406_4 = (has_head(v1406_3) ? constant_9 : Space{});
        const Space v1406_5 = subtract(constant_0,v1406_4);
        Space v1406_8;
        if (!v1406_5.empty()) {
          const Path v1407_6 = concat_path(v1405_6,v1405_7_head);
          const Space v1407_7 = routine_238(c, v1407_6, p1, v1405_7_tail);
          v1406_8 = compose(v1406_5,v1407_7);
        }
        const Space v1406_9 = intersect(constant_8,v1406_2);
        const Space v1406_10 = (has_head(v1406_9) ? constant_9 : Space{});
        Space v1406_12;
        if (!v1406_10.empty()) {
          const Path v1408_6 = concat_path(v1405_6,v1405_7_head);
          const Space v1408_11 = routine_239(c, v1408_6, p1, v1405_7_tail);
          v1406_12 = compose(v1406_10,v1408_11);
        }
        const Space v1406_13 = unite(v1406_8,v1406_12);
        v1405_7_result = unite(v1405_7_result,v1406_13);
      }
      const Space v1405_7 = std::move(v1405_7_result);
      v1404_8 = compose(v1404_5,v1405_7);
    }
    const Space v1404_9 = intersect(constant_8,v1404_2);
    const Space v1404_10 = (has_head(v1404_9) ? constant_9 : Space{});
    Space v1404_12;
    if (!v1404_10.empty()) {
      const Path v1409_6 = concat_path(p0,v1403_12_head);
      Space v1409_11_result;
      for (int v1409_11_label = 1; v1409_11_label <= 2; ++v1409_11_label) {
        const Space v1409_11_tail = child(v1403_12_tail,v1409_11_label);
        if (v1409_11_tail.empty()) continue;
        const Path v1409_11_head{v1409_11_label};
        const Space v1410_2 = singleton(v1409_11_head);
        const Space v1410_3 = intersect(constant_8,v1410_2);
        const Space v1410_4 = (has_head(v1410_3) ? constant_9 : Space{});
        const Space v1410_5 = subtract(constant_0,v1410_4);
        Space v1410_8;
        if (!v1410_5.empty()) {
          const Path v1411_6 = concat_path(v1409_6,v1409_11_head);
          const Space v1411_7 = routine_238(c, v1411_6, p1, v1409_11_tail);
          v1410_8 = compose(v1410_5,v1411_7);
        }
        const Space v1410_9 = intersect(constant_8,v1410_2);
        const Space v1410_10 = (has_head(v1410_9) ? constant_9 : Space{});
        Space v1410_12;
        if (!v1410_10.empty()) {
          const Path v1412_6 = concat_path(v1409_6,v1409_11_head);
          const Space v1412_11 = routine_155(c, v1412_6, p1, v1409_11_tail);
          v1410_12 = compose(v1410_10,v1412_11);
        }
        const Space v1410_13 = unite(v1410_8,v1410_12);
        v1409_11_result = unite(v1409_11_result,v1410_13);
      }
      const Space v1409_11 = std::move(v1409_11_result);
      v1404_12 = compose(v1404_10,v1409_11);
    }
    const Space v1404_13 = unite(v1404_8,v1404_12);
    v1403_12_result = unite(v1403_12_result,v1404_13);
  }
  const Space v1403_12 = std::move(v1403_12_result);
  return v1403_12;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1413_12_result;
  for (int v1413_12_label = 1; v1413_12_label <= 2; ++v1413_12_label) {
    const Space v1413_12_tail = child(s0,v1413_12_label);
    if (v1413_12_tail.empty()) continue;
    const Path v1413_12_head{v1413_12_label};
    const Space v1414_2 = singleton(v1413_12_head);
    const Space v1414_3 = intersect(constant_8,v1414_2);
    const Space v1414_4 = (has_head(v1414_3) ? constant_9 : Space{});
    const Space v1414_5 = subtract(constant_0,v1414_4);
    Space v1414_8;
    if (!v1414_5.empty()) {
      const Path v1415_6 = concat_path(p0,v1413_12_head);
      Space v1415_7_result;
      for (int v1415_7_label = 1; v1415_7_label <= 2; ++v1415_7_label) {
        const Space v1415_7_tail = child(v1413_12_tail,v1415_7_label);
        if (v1415_7_tail.empty()) continue;
        const Path v1415_7_head{v1415_7_label};
        const Space v1416_2 = singleton(v1415_7_head);
        const Space v1416_3 = intersect(constant_8,v1416_2);
        const Space v1416_4 = (has_head(v1416_3) ? constant_9 : Space{});
        const Space v1416_5 = subtract(constant_0,v1416_4);
        Space v1416_8;
        if (!v1416_5.empty()) {
          const Path v1417_6 = concat_path(v1415_6,v1415_7_head);
          const Space v1417_7 = routine_238(c, v1417_6, p1, v1415_7_tail);
          v1416_8 = compose(v1416_5,v1417_7);
        }
        const Space v1416_9 = intersect(constant_8,v1416_2);
        const Space v1416_10 = (has_head(v1416_9) ? constant_9 : Space{});
        Space v1416_12;
        if (!v1416_10.empty()) {
          const Path v1418_6 = concat_path(v1415_6,v1415_7_head);
          const Space v1418_11 = routine_239(c, v1418_6, p1, v1415_7_tail);
          v1416_12 = compose(v1416_10,v1418_11);
        }
        const Space v1416_13 = unite(v1416_8,v1416_12);
        v1415_7_result = unite(v1415_7_result,v1416_13);
      }
      const Space v1415_7 = std::move(v1415_7_result);
      v1414_8 = compose(v1414_5,v1415_7);
    }
    const Space v1414_9 = intersect(constant_8,v1414_2);
    const Space v1414_10 = (has_head(v1414_9) ? constant_9 : Space{});
    Space v1414_12;
    if (!v1414_10.empty()) {
      const Path v1419_6 = concat_path(p0,v1413_12_head);
      Space v1419_11_result;
      for (int v1419_11_label = 1; v1419_11_label <= 2; ++v1419_11_label) {
        const Space v1419_11_tail = child(v1413_12_tail,v1419_11_label);
        if (v1419_11_tail.empty()) continue;
        const Path v1419_11_head{v1419_11_label};
        const Space v1420_2 = singleton(v1419_11_head);
        const Space v1420_3 = intersect(constant_8,v1420_2);
        const Space v1420_4 = (has_head(v1420_3) ? constant_9 : Space{});
        const Space v1420_5 = subtract(constant_0,v1420_4);
        Space v1420_7;
        if (!v1420_5.empty()) {
          const Space v1421_6 = routine_201(c, v1419_11_head, p1, v1419_6, v1419_11_tail);
          v1420_7 = compose(v1420_5,v1421_6);
        }
        const Space v1420_8 = intersect(constant_8,v1420_2);
        const Space v1420_9 = (has_head(v1420_8) ? constant_9 : Space{});
        Space v1420_11;
        if (!v1420_9.empty()) {
          const Space v1422_10 = routine_202(c, v1419_11_head, p1, v1419_6, v1419_11_tail);
          v1420_11 = compose(v1420_9,v1422_10);
        }
        const Space v1420_12 = unite(v1420_7,v1420_11);
        v1419_11_result = unite(v1419_11_result,v1420_12);
      }
      const Space v1419_11 = std::move(v1419_11_result);
      v1414_12 = compose(v1414_10,v1419_11);
    }
    const Space v1414_13 = unite(v1414_8,v1414_12);
    v1413_12_result = unite(v1413_12_result,v1414_13);
  }
  const Space v1413_12 = std::move(v1413_12_result);
  return v1413_12;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1423_12_result;
  for (int v1423_12_label = 1; v1423_12_label <= 2; ++v1423_12_label) {
    const Space v1423_12_tail = child(s0,v1423_12_label);
    if (v1423_12_tail.empty()) continue;
    const Path v1423_12_head{v1423_12_label};
    const Space v1424_2 = singleton(v1423_12_head);
    const Space v1424_3 = intersect(constant_8,v1424_2);
    const Space v1424_4 = (has_head(v1424_3) ? constant_9 : Space{});
    const Space v1424_5 = subtract(constant_0,v1424_4);
    Space v1424_7;
    if (!v1424_5.empty()) {
      Space v1425_6_result;
      for (int v1425_6_label = 1; v1425_6_label <= 2; ++v1425_6_label) {
        const Space v1425_6_tail = child(v1423_12_tail,v1425_6_label);
        if (v1425_6_tail.empty()) continue;
        const Path v1425_6_head{v1425_6_label};
        const Space v1426_2 = singleton(v1425_6_head);
        const Space v1426_3 = intersect(constant_8,v1426_2);
        const Space v1426_4 = (has_head(v1426_3) ? constant_9 : Space{});
        const Space v1426_5 = subtract(constant_0,v1426_4);
        Space v1426_8;
        if (!v1426_5.empty()) {
          const Path v1427_6 = concat_path(v1423_12_head,v1425_6_head);
          const Space v1427_7 = routine_240(c, v1427_6, p1, p0, v1425_6_tail);
          v1426_8 = compose(v1426_5,v1427_7);
        }
        const Space v1426_9 = intersect(constant_8,v1426_2);
        const Space v1426_10 = (has_head(v1426_9) ? constant_9 : Space{});
        Space v1426_12;
        if (!v1426_10.empty()) {
          const Path v1428_6 = concat_path(v1423_12_head,v1425_6_head);
          const Space v1428_11 = routine_241(c, v1428_6, p1, p0, v1425_6_tail);
          v1426_12 = compose(v1426_10,v1428_11);
        }
        const Space v1426_13 = unite(v1426_8,v1426_12);
        v1425_6_result = unite(v1425_6_result,v1426_13);
      }
      const Space v1425_6 = std::move(v1425_6_result);
      v1424_7 = compose(v1424_5,v1425_6);
    }
    const Space v1424_8 = intersect(constant_8,v1424_2);
    const Space v1424_9 = (has_head(v1424_8) ? constant_9 : Space{});
    Space v1424_11;
    if (!v1424_9.empty()) {
      Space v1429_10_result;
      for (int v1429_10_label = 1; v1429_10_label <= 2; ++v1429_10_label) {
        const Space v1429_10_tail = child(v1423_12_tail,v1429_10_label);
        if (v1429_10_tail.empty()) continue;
        const Path v1429_10_head{v1429_10_label};
        const Space v1430_2 = singleton(v1429_10_head);
        const Space v1430_3 = intersect(constant_8,v1430_2);
        const Space v1430_4 = (has_head(v1430_3) ? constant_9 : Space{});
        const Space v1430_5 = subtract(constant_0,v1430_4);
        Space v1430_8;
        if (!v1430_5.empty()) {
          const Path v1431_6 = concat_path(v1423_12_head,v1429_10_head);
          const Space v1431_7 = routine_240(c, v1431_6, p1, p0, v1429_10_tail);
          v1430_8 = compose(v1430_5,v1431_7);
        }
        const Space v1430_9 = intersect(constant_8,v1430_2);
        const Space v1430_10 = (has_head(v1430_9) ? constant_9 : Space{});
        Space v1430_12;
        if (!v1430_10.empty()) {
          const Path v1432_6 = concat_path(v1423_12_head,v1429_10_head);
          const Space v1432_11 = routine_242(c, v1432_6, p1, p0, v1429_10_tail);
          v1430_12 = compose(v1430_10,v1432_11);
        }
        const Space v1430_13 = unite(v1430_8,v1430_12);
        v1429_10_result = unite(v1429_10_result,v1430_13);
      }
      const Space v1429_10 = std::move(v1429_10_result);
      v1424_11 = compose(v1424_9,v1429_10);
    }
    const Space v1424_12 = unite(v1424_7,v1424_11);
    v1423_12_result = unite(v1423_12_result,v1424_12);
  }
  const Space v1423_12 = std::move(v1423_12_result);
  return v1423_12;
}

static Space routine_156(Context& c, const Path& p0, const Space& s0) {
  Space v1433_4_result;
  for (int v1433_4_label = 1; v1433_4_label <= 2; ++v1433_4_label) {
    const Space v1433_4_tail = child(s0,v1433_4_label);
    if (v1433_4_tail.empty()) continue;
    const Path v1433_4_head{v1433_4_label};
    const Space v1434_2 = singleton(v1433_4_head);
    const Space v1434_3 = intersect(constant_8,v1434_2);
    const Space v1434_4 = (has_head(v1434_3) ? constant_9 : Space{});
    Space v1434_7;
    if (!v1434_4.empty()) {
      const Path v1435_5 = concat_path(p0,v1433_4_head);
      Space v1435_6_result;
      for (int v1435_6_label = 1; v1435_6_label <= 2; ++v1435_6_label) {
        const Space v1435_6_tail = child(v1433_4_tail,v1435_6_label);
        if (v1435_6_tail.empty()) continue;
        const Path v1435_6_head{v1435_6_label};
        const Space v1436_2 = singleton(v1435_6_head);
        const Space v1436_3 = intersect(constant_8,v1436_2);
        const Space v1436_4 = (has_head(v1436_3) ? constant_9 : Space{});
        Space v1436_7;
        if (!v1436_4.empty()) {
          const Path v1437_5 = concat_path(v1435_5,v1435_6_head);
          const Space v1437_6 = routine_80(c, v1437_5, v1435_6_tail);
          v1436_7 = compose(v1436_4,v1437_6);
        }
        v1435_6_result = unite(v1435_6_result,v1436_7);
      }
      const Space v1435_6 = std::move(v1435_6_result);
      v1434_7 = compose(v1434_4,v1435_6);
    }
    v1433_4_result = unite(v1433_4_result,v1434_7);
  }
  const Space v1433_4 = std::move(v1433_4_result);
  return v1433_4;
}

static Space routine_157(Context& c, const Path& p0, const Space& s0) {
  Space v1438_3_result;
  for (int v1438_3_label = 1; v1438_3_label <= 2; ++v1438_3_label) {
    const Space v1438_3_tail = child(s0,v1438_3_label);
    if (v1438_3_tail.empty()) continue;
    const Path v1438_3_head{v1438_3_label};
    const Space v1439_2 = singleton(v1438_3_head);
    const Space v1439_3 = intersect(constant_8,v1439_2);
    const Space v1439_4 = (has_head(v1439_3) ? constant_9 : Space{});
    const Space v1439_5 = compose(v1439_4,v1438_3_tail);
    v1438_3_result = unite(v1438_3_result,v1439_5);
  }
  const Space v1438_3 = std::move(v1438_3_result);
  return v1438_3;
}

static Space routine_158(Context& c, const Path& p0, const Space& s0) {
  Space v1440_4_result;
  for (int v1440_4_label = 1; v1440_4_label <= 2; ++v1440_4_label) {
    const Space v1440_4_tail = child(s0,v1440_4_label);
    if (v1440_4_tail.empty()) continue;
    const Path v1440_4_head{v1440_4_label};
    const Space v1441_2 = singleton(v1440_4_head);
    const Space v1441_3 = intersect(constant_8,v1441_2);
    const Space v1441_4 = (has_head(v1441_3) ? constant_9 : Space{});
    Space v1441_7;
    if (!v1441_4.empty()) {
      const Path v1442_5 = concat_path(p0,v1440_4_head);
      Space v1442_6_result;
      for (int v1442_6_label = 1; v1442_6_label <= 2; ++v1442_6_label) {
        const Space v1442_6_tail = child(v1440_4_tail,v1442_6_label);
        if (v1442_6_tail.empty()) continue;
        const Path v1442_6_head{v1442_6_label};
        const Space v1443_2 = singleton(v1442_6_head);
        const Space v1443_3 = intersect(constant_8,v1443_2);
        const Space v1443_4 = (has_head(v1443_3) ? constant_9 : Space{});
        Space v1443_7;
        if (!v1443_4.empty()) {
          const Path v1444_5 = concat_path(v1442_5,v1442_6_head);
          const Space v1444_6 = routine_83(c, v1444_5, v1442_6_tail);
          v1443_7 = compose(v1443_4,v1444_6);
        }
        v1442_6_result = unite(v1442_6_result,v1443_7);
      }
      const Space v1442_6 = std::move(v1442_6_result);
      v1441_7 = compose(v1441_4,v1442_6);
    }
    v1440_4_result = unite(v1440_4_result,v1441_7);
  }
  const Space v1440_4 = std::move(v1440_4_result);
  return v1440_4;
}

static Space routine_159(Context& c, const Path& p0, const Space& s0) {
  Space v1445_6_result;
  for (int v1445_6_label = 1; v1445_6_label <= 2; ++v1445_6_label) {
    const Space v1445_6_tail = child(s0,v1445_6_label);
    if (v1445_6_tail.empty()) continue;
    const Path v1445_6_head{v1445_6_label};
    const Space v1446_2 = singleton(v1445_6_head);
    const Space v1446_3 = intersect(constant_8,v1446_2);
    const Space v1446_4 = (has_head(v1446_3) ? constant_9 : Space{});
    Space v1446_7;
    if (!v1446_4.empty()) {
      const Path v1447_5 = concat_path(p0,v1445_6_head);
      Space v1447_6_result;
      for (int v1447_6_label = 1; v1447_6_label <= 2; ++v1447_6_label) {
        const Space v1447_6_tail = child(v1445_6_tail,v1447_6_label);
        if (v1447_6_tail.empty()) continue;
        const Path v1447_6_head{v1447_6_label};
        const Space v1448_2 = singleton(v1447_6_head);
        const Space v1448_3 = intersect(constant_8,v1448_2);
        const Space v1448_4 = (has_head(v1448_3) ? constant_9 : Space{});
        const Space v1448_5 = subtract(constant_0,v1448_4);
        Space v1448_7;
        if (!v1448_5.empty()) {
          const Space v1449_6 = routine_118(c, v1447_6_head, v1447_5, v1447_6_tail);
          v1448_7 = compose(v1448_5,v1449_6);
        }
        const Space v1448_8 = intersect(constant_8,v1448_2);
        const Space v1448_9 = (has_head(v1448_8) ? constant_9 : Space{});
        Space v1448_11;
        if (!v1448_9.empty()) {
          const Space v1450_10 = routine_119(c, v1447_6_head, v1447_5, v1447_6_tail);
          v1448_11 = compose(v1448_9,v1450_10);
        }
        const Space v1448_12 = unite(v1448_7,v1448_11);
        v1447_6_result = unite(v1447_6_result,v1448_12);
      }
      const Space v1447_6 = std::move(v1447_6_result);
      v1446_7 = compose(v1446_4,v1447_6);
    }
    v1445_6_result = unite(v1445_6_result,v1446_7);
  }
  const Space v1445_6 = std::move(v1445_6_result);
  return v1445_6;
}

static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1451_12_result;
  for (int v1451_12_label = 1; v1451_12_label <= 2; ++v1451_12_label) {
    const Space v1451_12_tail = child(s0,v1451_12_label);
    if (v1451_12_tail.empty()) continue;
    const Path v1451_12_head{v1451_12_label};
    const Space v1452_2 = singleton(v1451_12_head);
    const Space v1452_3 = intersect(constant_8,v1452_2);
    const Space v1452_4 = (has_head(v1452_3) ? constant_9 : Space{});
    const Space v1452_5 = subtract(constant_0,v1452_4);
    Space v1452_8;
    if (!v1452_5.empty()) {
      const Path v1453_6 = concat_path(p0,v1451_12_head);
      Space v1453_7_result;
      for (int v1453_7_label = 1; v1453_7_label <= 2; ++v1453_7_label) {
        const Space v1453_7_tail = child(v1451_12_tail,v1453_7_label);
        if (v1453_7_tail.empty()) continue;
        const Path v1453_7_head{v1453_7_label};
        const Space v1454_2 = singleton(v1453_7_head);
        const Space v1454_3 = intersect(constant_8,v1454_2);
        const Space v1454_4 = (has_head(v1454_3) ? constant_9 : Space{});
        const Space v1454_5 = subtract(constant_0,v1454_4);
        Space v1454_8;
        if (!v1454_5.empty()) {
          const Path v1455_6 = concat_path(v1453_6,v1453_7_head);
          const Space v1455_7 = routine_243(c, v1455_6, p1, v1453_7_tail);
          v1454_8 = compose(v1454_5,v1455_7);
        }
        const Space v1454_9 = intersect(constant_8,v1454_2);
        const Space v1454_10 = (has_head(v1454_9) ? constant_9 : Space{});
        Space v1454_12;
        if (!v1454_10.empty()) {
          const Path v1456_6 = concat_path(v1453_6,v1453_7_head);
          const Space v1456_11 = routine_244(c, v1456_6, p1, v1453_7_tail);
          v1454_12 = compose(v1454_10,v1456_11);
        }
        const Space v1454_13 = unite(v1454_8,v1454_12);
        v1453_7_result = unite(v1453_7_result,v1454_13);
      }
      const Space v1453_7 = std::move(v1453_7_result);
      v1452_8 = compose(v1452_5,v1453_7);
    }
    const Space v1452_9 = intersect(constant_8,v1452_2);
    const Space v1452_10 = (has_head(v1452_9) ? constant_9 : Space{});
    Space v1452_12;
    if (!v1452_10.empty()) {
      const Path v1457_6 = concat_path(p0,v1451_12_head);
      Space v1457_11_result;
      for (int v1457_11_label = 1; v1457_11_label <= 2; ++v1457_11_label) {
        const Space v1457_11_tail = child(v1451_12_tail,v1457_11_label);
        if (v1457_11_tail.empty()) continue;
        const Path v1457_11_head{v1457_11_label};
        const Space v1458_2 = singleton(v1457_11_head);
        const Space v1458_3 = intersect(constant_8,v1458_2);
        const Space v1458_4 = (has_head(v1458_3) ? constant_9 : Space{});
        const Space v1458_5 = subtract(constant_0,v1458_4);
        Space v1458_8;
        if (!v1458_5.empty()) {
          const Path v1459_6 = concat_path(v1457_6,v1457_11_head);
          const Space v1459_7 = routine_243(c, v1459_6, p1, v1457_11_tail);
          v1458_8 = compose(v1458_5,v1459_7);
        }
        const Space v1458_9 = intersect(constant_8,v1458_2);
        const Space v1458_10 = (has_head(v1458_9) ? constant_9 : Space{});
        Space v1458_12;
        if (!v1458_10.empty()) {
          const Path v1460_6 = concat_path(v1457_6,v1457_11_head);
          const Space v1460_11 = routine_162(c, v1460_6, p1, v1457_11_tail);
          v1458_12 = compose(v1458_10,v1460_11);
        }
        const Space v1458_13 = unite(v1458_8,v1458_12);
        v1457_11_result = unite(v1457_11_result,v1458_13);
      }
      const Space v1457_11 = std::move(v1457_11_result);
      v1452_12 = compose(v1452_10,v1457_11);
    }
    const Space v1452_13 = unite(v1452_8,v1452_12);
    v1451_12_result = unite(v1451_12_result,v1452_13);
  }
  const Space v1451_12 = std::move(v1451_12_result);
  return v1451_12;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1461_12_result;
  for (int v1461_12_label = 1; v1461_12_label <= 2; ++v1461_12_label) {
    const Space v1461_12_tail = child(s0,v1461_12_label);
    if (v1461_12_tail.empty()) continue;
    const Path v1461_12_head{v1461_12_label};
    const Space v1462_2 = singleton(v1461_12_head);
    const Space v1462_3 = intersect(constant_8,v1462_2);
    const Space v1462_4 = (has_head(v1462_3) ? constant_9 : Space{});
    const Space v1462_5 = subtract(constant_0,v1462_4);
    Space v1462_8;
    if (!v1462_5.empty()) {
      const Path v1463_6 = concat_path(p0,v1461_12_head);
      Space v1463_7_result;
      for (int v1463_7_label = 1; v1463_7_label <= 2; ++v1463_7_label) {
        const Space v1463_7_tail = child(v1461_12_tail,v1463_7_label);
        if (v1463_7_tail.empty()) continue;
        const Path v1463_7_head{v1463_7_label};
        const Space v1464_2 = singleton(v1463_7_head);
        const Space v1464_3 = intersect(constant_8,v1464_2);
        const Space v1464_4 = (has_head(v1464_3) ? constant_9 : Space{});
        const Space v1464_5 = subtract(constant_0,v1464_4);
        Space v1464_8;
        if (!v1464_5.empty()) {
          const Path v1465_6 = concat_path(v1463_6,v1463_7_head);
          const Space v1465_7 = routine_243(c, v1465_6, p1, v1463_7_tail);
          v1464_8 = compose(v1464_5,v1465_7);
        }
        const Space v1464_9 = intersect(constant_8,v1464_2);
        const Space v1464_10 = (has_head(v1464_9) ? constant_9 : Space{});
        Space v1464_12;
        if (!v1464_10.empty()) {
          const Path v1466_6 = concat_path(v1463_6,v1463_7_head);
          const Space v1466_11 = routine_244(c, v1466_6, p1, v1463_7_tail);
          v1464_12 = compose(v1464_10,v1466_11);
        }
        const Space v1464_13 = unite(v1464_8,v1464_12);
        v1463_7_result = unite(v1463_7_result,v1464_13);
      }
      const Space v1463_7 = std::move(v1463_7_result);
      v1462_8 = compose(v1462_5,v1463_7);
    }
    const Space v1462_9 = intersect(constant_8,v1462_2);
    const Space v1462_10 = (has_head(v1462_9) ? constant_9 : Space{});
    Space v1462_12;
    if (!v1462_10.empty()) {
      const Path v1467_6 = concat_path(p0,v1461_12_head);
      Space v1467_11_result;
      for (int v1467_11_label = 1; v1467_11_label <= 2; ++v1467_11_label) {
        const Space v1467_11_tail = child(v1461_12_tail,v1467_11_label);
        if (v1467_11_tail.empty()) continue;
        const Path v1467_11_head{v1467_11_label};
        const Space v1468_2 = singleton(v1467_11_head);
        const Space v1468_3 = intersect(constant_8,v1468_2);
        const Space v1468_4 = (has_head(v1468_3) ? constant_9 : Space{});
        const Space v1468_5 = subtract(constant_0,v1468_4);
        Space v1468_7;
        if (!v1468_5.empty()) {
          const Space v1469_6 = routine_209(c, v1467_11_head, p1, v1467_6, v1467_11_tail);
          v1468_7 = compose(v1468_5,v1469_6);
        }
        const Space v1468_8 = intersect(constant_8,v1468_2);
        const Space v1468_9 = (has_head(v1468_8) ? constant_9 : Space{});
        Space v1468_11;
        if (!v1468_9.empty()) {
          const Space v1470_10 = routine_210(c, v1467_11_head, p1, v1467_6, v1467_11_tail);
          v1468_11 = compose(v1468_9,v1470_10);
        }
        const Space v1468_12 = unite(v1468_7,v1468_11);
        v1467_11_result = unite(v1467_11_result,v1468_12);
      }
      const Space v1467_11 = std::move(v1467_11_result);
      v1462_12 = compose(v1462_10,v1467_11);
    }
    const Space v1462_13 = unite(v1462_8,v1462_12);
    v1461_12_result = unite(v1461_12_result,v1462_13);
  }
  const Space v1461_12 = std::move(v1461_12_result);
  return v1461_12;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1471_12_result;
  for (int v1471_12_label = 1; v1471_12_label <= 2; ++v1471_12_label) {
    const Space v1471_12_tail = child(s0,v1471_12_label);
    if (v1471_12_tail.empty()) continue;
    const Path v1471_12_head{v1471_12_label};
    const Space v1472_2 = singleton(v1471_12_head);
    const Space v1472_3 = intersect(constant_8,v1472_2);
    const Space v1472_4 = (has_head(v1472_3) ? constant_9 : Space{});
    const Space v1472_5 = subtract(constant_0,v1472_4);
    Space v1472_7;
    if (!v1472_5.empty()) {
      Space v1473_6_result;
      for (int v1473_6_label = 1; v1473_6_label <= 2; ++v1473_6_label) {
        const Space v1473_6_tail = child(v1471_12_tail,v1473_6_label);
        if (v1473_6_tail.empty()) continue;
        const Path v1473_6_head{v1473_6_label};
        const Space v1474_2 = singleton(v1473_6_head);
        const Space v1474_3 = intersect(constant_8,v1474_2);
        const Space v1474_4 = (has_head(v1474_3) ? constant_9 : Space{});
        const Space v1474_5 = subtract(constant_0,v1474_4);
        Space v1474_8;
        if (!v1474_5.empty()) {
          const Path v1475_6 = concat_path(v1471_12_head,v1473_6_head);
          const Space v1475_7 = routine_245(c, v1475_6, p1, p0, v1473_6_tail);
          v1474_8 = compose(v1474_5,v1475_7);
        }
        const Space v1474_9 = intersect(constant_8,v1474_2);
        const Space v1474_10 = (has_head(v1474_9) ? constant_9 : Space{});
        Space v1474_12;
        if (!v1474_10.empty()) {
          const Path v1476_6 = concat_path(v1471_12_head,v1473_6_head);
          const Space v1476_11 = routine_246(c, v1476_6, p1, p0, v1473_6_tail);
          v1474_12 = compose(v1474_10,v1476_11);
        }
        const Space v1474_13 = unite(v1474_8,v1474_12);
        v1473_6_result = unite(v1473_6_result,v1474_13);
      }
      const Space v1473_6 = std::move(v1473_6_result);
      v1472_7 = compose(v1472_5,v1473_6);
    }
    const Space v1472_8 = intersect(constant_8,v1472_2);
    const Space v1472_9 = (has_head(v1472_8) ? constant_9 : Space{});
    Space v1472_11;
    if (!v1472_9.empty()) {
      Space v1477_10_result;
      for (int v1477_10_label = 1; v1477_10_label <= 2; ++v1477_10_label) {
        const Space v1477_10_tail = child(v1471_12_tail,v1477_10_label);
        if (v1477_10_tail.empty()) continue;
        const Path v1477_10_head{v1477_10_label};
        const Space v1478_2 = singleton(v1477_10_head);
        const Space v1478_3 = intersect(constant_8,v1478_2);
        const Space v1478_4 = (has_head(v1478_3) ? constant_9 : Space{});
        const Space v1478_5 = subtract(constant_0,v1478_4);
        Space v1478_8;
        if (!v1478_5.empty()) {
          const Path v1479_6 = concat_path(v1471_12_head,v1477_10_head);
          const Space v1479_7 = routine_245(c, v1479_6, p1, p0, v1477_10_tail);
          v1478_8 = compose(v1478_5,v1479_7);
        }
        const Space v1478_9 = intersect(constant_8,v1478_2);
        const Space v1478_10 = (has_head(v1478_9) ? constant_9 : Space{});
        Space v1478_12;
        if (!v1478_10.empty()) {
          const Path v1480_6 = concat_path(v1471_12_head,v1477_10_head);
          const Space v1480_11 = routine_247(c, v1480_6, p1, p0, v1477_10_tail);
          v1478_12 = compose(v1478_10,v1480_11);
        }
        const Space v1478_13 = unite(v1478_8,v1478_12);
        v1477_10_result = unite(v1477_10_result,v1478_13);
      }
      const Space v1477_10 = std::move(v1477_10_result);
      v1472_11 = compose(v1472_9,v1477_10);
    }
    const Space v1472_12 = unite(v1472_7,v1472_11);
    v1471_12_result = unite(v1471_12_result,v1472_12);
  }
  const Space v1471_12 = std::move(v1471_12_result);
  return v1471_12;
}

static Space routine_163(Context& c, const Path& p0, const Space& s0) {
  Space v1481_4_result;
  for (int v1481_4_label = 1; v1481_4_label <= 2; ++v1481_4_label) {
    const Space v1481_4_tail = child(s0,v1481_4_label);
    if (v1481_4_tail.empty()) continue;
    const Path v1481_4_head{v1481_4_label};
    const Space v1482_2 = singleton(v1481_4_head);
    const Space v1482_3 = intersect(constant_8,v1482_2);
    const Space v1482_4 = (has_head(v1482_3) ? constant_9 : Space{});
    Space v1482_7;
    if (!v1482_4.empty()) {
      const Path v1483_5 = concat_path(p0,v1481_4_head);
      Space v1483_6_result;
      for (int v1483_6_label = 1; v1483_6_label <= 2; ++v1483_6_label) {
        const Space v1483_6_tail = child(v1481_4_tail,v1483_6_label);
        if (v1483_6_tail.empty()) continue;
        const Path v1483_6_head{v1483_6_label};
        const Space v1484_2 = singleton(v1483_6_head);
        const Space v1484_3 = intersect(constant_8,v1484_2);
        const Space v1484_4 = (has_head(v1484_3) ? constant_9 : Space{});
        Space v1484_7;
        if (!v1484_4.empty()) {
          const Path v1485_5 = concat_path(v1483_5,v1483_6_head);
          const Space v1485_6 = routine_86(c, v1485_5, v1483_6_tail);
          v1484_7 = compose(v1484_4,v1485_6);
        }
        v1483_6_result = unite(v1483_6_result,v1484_7);
      }
      const Space v1483_6 = std::move(v1483_6_result);
      v1482_7 = compose(v1482_4,v1483_6);
    }
    v1481_4_result = unite(v1481_4_result,v1482_7);
  }
  const Space v1481_4 = std::move(v1481_4_result);
  return v1481_4;
}

static Space routine_164(Context& c, const Path& p0, const Space& s0) {
  Space v1486_3_result;
  for (int v1486_3_label = 1; v1486_3_label <= 2; ++v1486_3_label) {
    const Space v1486_3_tail = child(s0,v1486_3_label);
    if (v1486_3_tail.empty()) continue;
    const Path v1486_3_head{v1486_3_label};
    const Space v1487_2 = singleton(v1486_3_head);
    const Space v1487_3 = intersect(constant_8,v1487_2);
    const Space v1487_4 = (has_head(v1487_3) ? constant_9 : Space{});
    const Space v1487_5 = compose(v1487_4,v1486_3_tail);
    v1486_3_result = unite(v1486_3_result,v1487_5);
  }
  const Space v1486_3 = std::move(v1486_3_result);
  return v1486_3;
}

static Space routine_165(Context& c, const Path& p0, const Space& s0) {
  Space v1488_4_result;
  for (int v1488_4_label = 1; v1488_4_label <= 2; ++v1488_4_label) {
    const Space v1488_4_tail = child(s0,v1488_4_label);
    if (v1488_4_tail.empty()) continue;
    const Path v1488_4_head{v1488_4_label};
    const Space v1489_2 = singleton(v1488_4_head);
    const Space v1489_3 = intersect(constant_8,v1489_2);
    const Space v1489_4 = (has_head(v1489_3) ? constant_9 : Space{});
    Space v1489_7;
    if (!v1489_4.empty()) {
      const Path v1490_5 = concat_path(p0,v1488_4_head);
      Space v1490_6_result;
      for (int v1490_6_label = 1; v1490_6_label <= 2; ++v1490_6_label) {
        const Space v1490_6_tail = child(v1488_4_tail,v1490_6_label);
        if (v1490_6_tail.empty()) continue;
        const Path v1490_6_head{v1490_6_label};
        const Space v1491_2 = singleton(v1490_6_head);
        const Space v1491_3 = intersect(constant_8,v1491_2);
        const Space v1491_4 = (has_head(v1491_3) ? constant_9 : Space{});
        Space v1491_7;
        if (!v1491_4.empty()) {
          const Path v1492_5 = concat_path(v1490_5,v1490_6_head);
          const Space v1492_6 = routine_89(c, v1492_5, v1490_6_tail);
          v1491_7 = compose(v1491_4,v1492_6);
        }
        v1490_6_result = unite(v1490_6_result,v1491_7);
      }
      const Space v1490_6 = std::move(v1490_6_result);
      v1489_7 = compose(v1489_4,v1490_6);
    }
    v1488_4_result = unite(v1488_4_result,v1489_7);
  }
  const Space v1488_4 = std::move(v1488_4_result);
  return v1488_4;
}

static Space routine_166(Context& c, const Path& p0, const Space& s0) {
  Space v1493_6_result;
  for (int v1493_6_label = 1; v1493_6_label <= 2; ++v1493_6_label) {
    const Space v1493_6_tail = child(s0,v1493_6_label);
    if (v1493_6_tail.empty()) continue;
    const Path v1493_6_head{v1493_6_label};
    const Space v1494_2 = singleton(v1493_6_head);
    const Space v1494_3 = intersect(constant_8,v1494_2);
    const Space v1494_4 = (has_head(v1494_3) ? constant_9 : Space{});
    Space v1494_7;
    if (!v1494_4.empty()) {
      const Path v1495_5 = concat_path(p0,v1493_6_head);
      Space v1495_6_result;
      for (int v1495_6_label = 1; v1495_6_label <= 2; ++v1495_6_label) {
        const Space v1495_6_tail = child(v1493_6_tail,v1495_6_label);
        if (v1495_6_tail.empty()) continue;
        const Path v1495_6_head{v1495_6_label};
        const Space v1496_2 = singleton(v1495_6_head);
        const Space v1496_3 = intersect(constant_8,v1496_2);
        const Space v1496_4 = (has_head(v1496_3) ? constant_9 : Space{});
        const Space v1496_5 = subtract(constant_0,v1496_4);
        Space v1496_7;
        if (!v1496_5.empty()) {
          const Space v1497_6 = routine_124(c, v1495_6_head, v1495_5, v1495_6_tail);
          v1496_7 = compose(v1496_5,v1497_6);
        }
        const Space v1496_8 = intersect(constant_8,v1496_2);
        const Space v1496_9 = (has_head(v1496_8) ? constant_9 : Space{});
        Space v1496_11;
        if (!v1496_9.empty()) {
          const Space v1498_10 = routine_125(c, v1495_6_head, v1495_5, v1495_6_tail);
          v1496_11 = compose(v1496_9,v1498_10);
        }
        const Space v1496_12 = unite(v1496_7,v1496_11);
        v1495_6_result = unite(v1495_6_result,v1496_12);
      }
      const Space v1495_6 = std::move(v1495_6_result);
      v1494_7 = compose(v1494_4,v1495_6);
    }
    v1493_6_result = unite(v1493_6_result,v1494_7);
  }
  const Space v1493_6 = std::move(v1493_6_result);
  return v1493_6;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1499_12_result;
  for (int v1499_12_label = 1; v1499_12_label <= 2; ++v1499_12_label) {
    const Space v1499_12_tail = child(s0,v1499_12_label);
    if (v1499_12_tail.empty()) continue;
    const Path v1499_12_head{v1499_12_label};
    const Space v1500_2 = singleton(v1499_12_head);
    const Space v1500_3 = intersect(constant_8,v1500_2);
    const Space v1500_4 = (has_head(v1500_3) ? constant_9 : Space{});
    const Space v1500_5 = subtract(constant_0,v1500_4);
    Space v1500_8;
    if (!v1500_5.empty()) {
      const Path v1501_6 = concat_path(p0,v1499_12_head);
      Space v1501_7_result;
      for (int v1501_7_label = 1; v1501_7_label <= 2; ++v1501_7_label) {
        const Space v1501_7_tail = child(v1499_12_tail,v1501_7_label);
        if (v1501_7_tail.empty()) continue;
        const Path v1501_7_head{v1501_7_label};
        const Space v1502_2 = singleton(v1501_7_head);
        const Space v1502_3 = intersect(constant_8,v1502_2);
        const Space v1502_4 = (has_head(v1502_3) ? constant_9 : Space{});
        const Space v1502_5 = subtract(constant_0,v1502_4);
        Space v1502_8;
        if (!v1502_5.empty()) {
          const Path v1503_6 = concat_path(v1501_6,v1501_7_head);
          const Space v1503_7 = routine_248(c, v1503_6, p1, v1501_7_tail);
          v1502_8 = compose(v1502_5,v1503_7);
        }
        const Space v1502_9 = intersect(constant_8,v1502_2);
        const Space v1502_10 = (has_head(v1502_9) ? constant_9 : Space{});
        Space v1502_12;
        if (!v1502_10.empty()) {
          const Path v1504_6 = concat_path(v1501_6,v1501_7_head);
          const Space v1504_11 = routine_249(c, v1504_6, p1, v1501_7_tail);
          v1502_12 = compose(v1502_10,v1504_11);
        }
        const Space v1502_13 = unite(v1502_8,v1502_12);
        v1501_7_result = unite(v1501_7_result,v1502_13);
      }
      const Space v1501_7 = std::move(v1501_7_result);
      v1500_8 = compose(v1500_5,v1501_7);
    }
    const Space v1500_9 = intersect(constant_8,v1500_2);
    const Space v1500_10 = (has_head(v1500_9) ? constant_9 : Space{});
    Space v1500_12;
    if (!v1500_10.empty()) {
      const Path v1505_6 = concat_path(p0,v1499_12_head);
      Space v1505_11_result;
      for (int v1505_11_label = 1; v1505_11_label <= 2; ++v1505_11_label) {
        const Space v1505_11_tail = child(v1499_12_tail,v1505_11_label);
        if (v1505_11_tail.empty()) continue;
        const Path v1505_11_head{v1505_11_label};
        const Space v1506_2 = singleton(v1505_11_head);
        const Space v1506_3 = intersect(constant_8,v1506_2);
        const Space v1506_4 = (has_head(v1506_3) ? constant_9 : Space{});
        const Space v1506_5 = subtract(constant_0,v1506_4);
        Space v1506_8;
        if (!v1506_5.empty()) {
          const Path v1507_6 = concat_path(v1505_6,v1505_11_head);
          const Space v1507_7 = routine_248(c, v1507_6, p1, v1505_11_tail);
          v1506_8 = compose(v1506_5,v1507_7);
        }
        const Space v1506_9 = intersect(constant_8,v1506_2);
        const Space v1506_10 = (has_head(v1506_9) ? constant_9 : Space{});
        Space v1506_12;
        if (!v1506_10.empty()) {
          const Path v1508_6 = concat_path(v1505_6,v1505_11_head);
          const Space v1508_11 = routine_169(c, v1508_6, p1, v1505_11_tail);
          v1506_12 = compose(v1506_10,v1508_11);
        }
        const Space v1506_13 = unite(v1506_8,v1506_12);
        v1505_11_result = unite(v1505_11_result,v1506_13);
      }
      const Space v1505_11 = std::move(v1505_11_result);
      v1500_12 = compose(v1500_10,v1505_11);
    }
    const Space v1500_13 = unite(v1500_8,v1500_12);
    v1499_12_result = unite(v1499_12_result,v1500_13);
  }
  const Space v1499_12 = std::move(v1499_12_result);
  return v1499_12;
}

static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1509_12_result;
  for (int v1509_12_label = 1; v1509_12_label <= 2; ++v1509_12_label) {
    const Space v1509_12_tail = child(s0,v1509_12_label);
    if (v1509_12_tail.empty()) continue;
    const Path v1509_12_head{v1509_12_label};
    const Space v1510_2 = singleton(v1509_12_head);
    const Space v1510_3 = intersect(constant_8,v1510_2);
    const Space v1510_4 = (has_head(v1510_3) ? constant_9 : Space{});
    const Space v1510_5 = subtract(constant_0,v1510_4);
    Space v1510_8;
    if (!v1510_5.empty()) {
      const Path v1511_6 = concat_path(p0,v1509_12_head);
      Space v1511_7_result;
      for (int v1511_7_label = 1; v1511_7_label <= 2; ++v1511_7_label) {
        const Space v1511_7_tail = child(v1509_12_tail,v1511_7_label);
        if (v1511_7_tail.empty()) continue;
        const Path v1511_7_head{v1511_7_label};
        const Space v1512_2 = singleton(v1511_7_head);
        const Space v1512_3 = intersect(constant_8,v1512_2);
        const Space v1512_4 = (has_head(v1512_3) ? constant_9 : Space{});
        const Space v1512_5 = subtract(constant_0,v1512_4);
        Space v1512_8;
        if (!v1512_5.empty()) {
          const Path v1513_6 = concat_path(v1511_6,v1511_7_head);
          const Space v1513_7 = routine_248(c, v1513_6, p1, v1511_7_tail);
          v1512_8 = compose(v1512_5,v1513_7);
        }
        const Space v1512_9 = intersect(constant_8,v1512_2);
        const Space v1512_10 = (has_head(v1512_9) ? constant_9 : Space{});
        Space v1512_12;
        if (!v1512_10.empty()) {
          const Path v1514_6 = concat_path(v1511_6,v1511_7_head);
          const Space v1514_11 = routine_249(c, v1514_6, p1, v1511_7_tail);
          v1512_12 = compose(v1512_10,v1514_11);
        }
        const Space v1512_13 = unite(v1512_8,v1512_12);
        v1511_7_result = unite(v1511_7_result,v1512_13);
      }
      const Space v1511_7 = std::move(v1511_7_result);
      v1510_8 = compose(v1510_5,v1511_7);
    }
    const Space v1510_9 = intersect(constant_8,v1510_2);
    const Space v1510_10 = (has_head(v1510_9) ? constant_9 : Space{});
    Space v1510_12;
    if (!v1510_10.empty()) {
      const Path v1515_6 = concat_path(p0,v1509_12_head);
      Space v1515_11_result;
      for (int v1515_11_label = 1; v1515_11_label <= 2; ++v1515_11_label) {
        const Space v1515_11_tail = child(v1509_12_tail,v1515_11_label);
        if (v1515_11_tail.empty()) continue;
        const Path v1515_11_head{v1515_11_label};
        const Space v1516_2 = singleton(v1515_11_head);
        const Space v1516_3 = intersect(constant_8,v1516_2);
        const Space v1516_4 = (has_head(v1516_3) ? constant_9 : Space{});
        const Space v1516_5 = subtract(constant_0,v1516_4);
        Space v1516_7;
        if (!v1516_5.empty()) {
          const Space v1517_6 = routine_217(c, v1515_11_head, p1, v1515_6, v1515_11_tail);
          v1516_7 = compose(v1516_5,v1517_6);
        }
        const Space v1516_8 = intersect(constant_8,v1516_2);
        const Space v1516_9 = (has_head(v1516_8) ? constant_9 : Space{});
        Space v1516_11;
        if (!v1516_9.empty()) {
          const Space v1518_10 = routine_218(c, v1515_11_head, p1, v1515_6, v1515_11_tail);
          v1516_11 = compose(v1516_9,v1518_10);
        }
        const Space v1516_12 = unite(v1516_7,v1516_11);
        v1515_11_result = unite(v1515_11_result,v1516_12);
      }
      const Space v1515_11 = std::move(v1515_11_result);
      v1510_12 = compose(v1510_10,v1515_11);
    }
    const Space v1510_13 = unite(v1510_8,v1510_12);
    v1509_12_result = unite(v1509_12_result,v1510_13);
  }
  const Space v1509_12 = std::move(v1509_12_result);
  return v1509_12;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1519_12_result;
  for (int v1519_12_label = 1; v1519_12_label <= 2; ++v1519_12_label) {
    const Space v1519_12_tail = child(s0,v1519_12_label);
    if (v1519_12_tail.empty()) continue;
    const Path v1519_12_head{v1519_12_label};
    const Space v1520_2 = singleton(v1519_12_head);
    const Space v1520_3 = intersect(constant_8,v1520_2);
    const Space v1520_4 = (has_head(v1520_3) ? constant_9 : Space{});
    const Space v1520_5 = subtract(constant_0,v1520_4);
    Space v1520_7;
    if (!v1520_5.empty()) {
      Space v1521_6_result;
      for (int v1521_6_label = 1; v1521_6_label <= 2; ++v1521_6_label) {
        const Space v1521_6_tail = child(v1519_12_tail,v1521_6_label);
        if (v1521_6_tail.empty()) continue;
        const Path v1521_6_head{v1521_6_label};
        const Space v1522_2 = singleton(v1521_6_head);
        const Space v1522_3 = intersect(constant_8,v1522_2);
        const Space v1522_4 = (has_head(v1522_3) ? constant_9 : Space{});
        const Space v1522_5 = subtract(constant_0,v1522_4);
        Space v1522_8;
        if (!v1522_5.empty()) {
          const Path v1523_6 = concat_path(v1519_12_head,v1521_6_head);
          const Space v1523_7 = routine_250(c, v1523_6, p1, p0, v1521_6_tail);
          v1522_8 = compose(v1522_5,v1523_7);
        }
        const Space v1522_9 = intersect(constant_8,v1522_2);
        const Space v1522_10 = (has_head(v1522_9) ? constant_9 : Space{});
        Space v1522_12;
        if (!v1522_10.empty()) {
          const Path v1524_6 = concat_path(v1519_12_head,v1521_6_head);
          const Space v1524_11 = routine_251(c, v1524_6, p1, p0, v1521_6_tail);
          v1522_12 = compose(v1522_10,v1524_11);
        }
        const Space v1522_13 = unite(v1522_8,v1522_12);
        v1521_6_result = unite(v1521_6_result,v1522_13);
      }
      const Space v1521_6 = std::move(v1521_6_result);
      v1520_7 = compose(v1520_5,v1521_6);
    }
    const Space v1520_8 = intersect(constant_8,v1520_2);
    const Space v1520_9 = (has_head(v1520_8) ? constant_9 : Space{});
    Space v1520_11;
    if (!v1520_9.empty()) {
      Space v1525_10_result;
      for (int v1525_10_label = 1; v1525_10_label <= 2; ++v1525_10_label) {
        const Space v1525_10_tail = child(v1519_12_tail,v1525_10_label);
        if (v1525_10_tail.empty()) continue;
        const Path v1525_10_head{v1525_10_label};
        const Space v1526_2 = singleton(v1525_10_head);
        const Space v1526_3 = intersect(constant_8,v1526_2);
        const Space v1526_4 = (has_head(v1526_3) ? constant_9 : Space{});
        const Space v1526_5 = subtract(constant_0,v1526_4);
        Space v1526_8;
        if (!v1526_5.empty()) {
          const Path v1527_6 = concat_path(v1519_12_head,v1525_10_head);
          const Space v1527_7 = routine_250(c, v1527_6, p1, p0, v1525_10_tail);
          v1526_8 = compose(v1526_5,v1527_7);
        }
        const Space v1526_9 = intersect(constant_8,v1526_2);
        const Space v1526_10 = (has_head(v1526_9) ? constant_9 : Space{});
        Space v1526_12;
        if (!v1526_10.empty()) {
          const Path v1528_6 = concat_path(v1519_12_head,v1525_10_head);
          const Space v1528_11 = routine_252(c, v1528_6, p1, p0, v1525_10_tail);
          v1526_12 = compose(v1526_10,v1528_11);
        }
        const Space v1526_13 = unite(v1526_8,v1526_12);
        v1525_10_result = unite(v1525_10_result,v1526_13);
      }
      const Space v1525_10 = std::move(v1525_10_result);
      v1520_11 = compose(v1520_9,v1525_10);
    }
    const Space v1520_12 = unite(v1520_7,v1520_11);
    v1519_12_result = unite(v1519_12_result,v1520_12);
  }
  const Space v1519_12 = std::move(v1519_12_result);
  return v1519_12;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1529_3 = Space{};
  return v1529_3;
}

static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1530_12_result;
  for (int v1530_12_label = 1; v1530_12_label <= 2; ++v1530_12_label) {
    const Space v1530_12_tail = child(s0,v1530_12_label);
    if (v1530_12_tail.empty()) continue;
    const Path v1530_12_head{v1530_12_label};
    const Space v1531_2 = singleton(v1530_12_head);
    const Space v1531_3 = intersect(constant_8,v1531_2);
    const Space v1531_4 = (has_head(v1531_3) ? constant_9 : Space{});
    Space v1531_11;
    if (!v1531_4.empty()) {
      Space v1532_8;
      if (!constant_0.empty()) {
        const Space v1533_5 = routine_92(c, constant_14, p1, constant_15);
        const Space v1533_6 = routine_93(c, constant_16, p1, constant_17);
        const Space v1533_7 = unite(v1533_5,v1533_6);
        v1532_8 = compose(constant_0,v1533_7);
      }
      const Path v1532_9 = concat_path(p0,v1530_12_head);
      Space v1532_10_result;
      for (int v1532_10_label = 1; v1532_10_label <= 2; ++v1532_10_label) {
        const Space v1532_10_tail = child(v1532_8,v1532_10_label);
        if (v1532_10_tail.empty()) continue;
        const Path v1532_10_head{v1532_10_label};
        const Space v1534_2 = singleton(v1532_10_head);
        const Space v1534_3 = intersect(constant_8,v1534_2);
        const Space v1534_4 = (has_head(v1534_3) ? constant_9 : Space{});
        const Space v1534_5 = subtract(constant_0,v1534_4);
        Space v1534_7;
        if (!v1534_5.empty()) {
          const Space v1535_6 = routine_94(c, v1532_10_head, v1532_9, v1532_10_tail, v1530_12_tail);
          v1534_7 = compose(v1534_5,v1535_6);
        }
        const Space v1534_8 = intersect(constant_8,v1534_2);
        const Space v1534_9 = (has_head(v1534_8) ? constant_9 : Space{});
        Space v1534_11;
        if (!v1534_9.empty()) {
          const Space v1536_10 = routine_95(c, v1532_10_head, v1532_9, v1532_10_tail, v1530_12_tail);
          v1534_11 = compose(v1534_9,v1536_10);
        }
        const Space v1534_12 = unite(v1534_7,v1534_11);
        v1532_10_result = unite(v1532_10_result,v1534_12);
      }
      const Space v1532_10 = std::move(v1532_10_result);
      v1531_11 = compose(v1531_4,v1532_10);
    }
    v1530_12_result = unite(v1530_12_result,v1531_11);
  }
  const Space v1530_12 = std::move(v1530_12_result);
  return v1530_12;
}

static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1537_12_result;
  for (int v1537_12_label = 1; v1537_12_label <= 2; ++v1537_12_label) {
    const Space v1537_12_tail = child(s0,v1537_12_label);
    if (v1537_12_tail.empty()) continue;
    const Path v1537_12_head{v1537_12_label};
    const Space v1538_2 = singleton(v1537_12_head);
    const Space v1538_3 = intersect(constant_8,v1538_2);
    const Space v1538_4 = (has_head(v1538_3) ? constant_9 : Space{});
    const Space v1538_5 = subtract(constant_0,v1538_4);
    Space v1538_8;
    if (!v1538_5.empty()) {
      const Path v1539_6 = concat_path(p0,v1537_12_head);
      Space v1539_7_result;
      for (int v1539_7_label = 1; v1539_7_label <= 2; ++v1539_7_label) {
        const Space v1539_7_tail = child(v1537_12_tail,v1539_7_label);
        if (v1539_7_tail.empty()) continue;
        const Path v1539_7_head{v1539_7_label};
        const Space v1540_2 = singleton(v1539_7_head);
        const Space v1540_3 = intersect(constant_8,v1540_2);
        const Space v1540_4 = (has_head(v1540_3) ? constant_9 : Space{});
        const Space v1540_5 = subtract(constant_0,v1540_4);
        Space v1540_8;
        if (!v1540_5.empty()) {
          const Path v1541_6 = concat_path(v1539_6,v1539_7_head);
          const Space v1541_7 = routine_253(c, v1541_6, p1, v1539_7_tail);
          v1540_8 = compose(v1540_5,v1541_7);
        }
        const Space v1540_9 = intersect(constant_8,v1540_2);
        const Space v1540_10 = (has_head(v1540_9) ? constant_9 : Space{});
        Space v1540_12;
        if (!v1540_10.empty()) {
          const Path v1542_6 = concat_path(v1539_6,v1539_7_head);
          const Space v1542_11 = routine_254(c, v1542_6, p1, v1539_7_tail);
          v1540_12 = compose(v1540_10,v1542_11);
        }
        const Space v1540_13 = unite(v1540_8,v1540_12);
        v1539_7_result = unite(v1539_7_result,v1540_13);
      }
      const Space v1539_7 = std::move(v1539_7_result);
      v1538_8 = compose(v1538_5,v1539_7);
    }
    const Space v1538_9 = intersect(constant_8,v1538_2);
    const Space v1538_10 = (has_head(v1538_9) ? constant_9 : Space{});
    Space v1538_12;
    if (!v1538_10.empty()) {
      const Path v1543_6 = concat_path(p0,v1537_12_head);
      Space v1543_11_result;
      for (int v1543_11_label = 1; v1543_11_label <= 2; ++v1543_11_label) {
        const Space v1543_11_tail = child(v1537_12_tail,v1543_11_label);
        if (v1543_11_tail.empty()) continue;
        const Path v1543_11_head{v1543_11_label};
        const Space v1544_2 = singleton(v1543_11_head);
        const Space v1544_3 = intersect(constant_8,v1544_2);
        const Space v1544_4 = (has_head(v1544_3) ? constant_9 : Space{});
        const Space v1544_5 = subtract(constant_0,v1544_4);
        Space v1544_8;
        if (!v1544_5.empty()) {
          const Path v1545_6 = concat_path(v1543_6,v1543_11_head);
          const Space v1545_7 = routine_253(c, v1545_6, p1, v1543_11_tail);
          v1544_8 = compose(v1544_5,v1545_7);
        }
        const Space v1544_9 = intersect(constant_8,v1544_2);
        const Space v1544_10 = (has_head(v1544_9) ? constant_9 : Space{});
        Space v1544_12;
        if (!v1544_10.empty()) {
          const Path v1546_6 = concat_path(v1543_6,v1543_11_head);
          const Space v1546_11 = routine_130(c, v1546_6, p1, v1543_11_tail);
          v1544_12 = compose(v1544_10,v1546_11);
        }
        const Space v1544_13 = unite(v1544_8,v1544_12);
        v1543_11_result = unite(v1543_11_result,v1544_13);
      }
      const Space v1543_11 = std::move(v1543_11_result);
      v1538_12 = compose(v1538_10,v1543_11);
    }
    const Space v1538_13 = unite(v1538_8,v1538_12);
    v1537_12_result = unite(v1537_12_result,v1538_13);
  }
  const Space v1537_12 = std::move(v1537_12_result);
  return v1537_12;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1547_12_result;
  for (int v1547_12_label = 1; v1547_12_label <= 2; ++v1547_12_label) {
    const Space v1547_12_tail = child(s0,v1547_12_label);
    if (v1547_12_tail.empty()) continue;
    const Path v1547_12_head{v1547_12_label};
    const Space v1548_2 = singleton(v1547_12_head);
    const Space v1548_3 = intersect(constant_8,v1548_2);
    const Space v1548_4 = (has_head(v1548_3) ? constant_9 : Space{});
    const Space v1548_5 = subtract(constant_0,v1548_4);
    Space v1548_8;
    if (!v1548_5.empty()) {
      const Path v1549_6 = concat_path(p0,v1547_12_head);
      Space v1549_7_result;
      for (int v1549_7_label = 1; v1549_7_label <= 2; ++v1549_7_label) {
        const Space v1549_7_tail = child(v1547_12_tail,v1549_7_label);
        if (v1549_7_tail.empty()) continue;
        const Path v1549_7_head{v1549_7_label};
        const Space v1550_2 = singleton(v1549_7_head);
        const Space v1550_3 = intersect(constant_8,v1550_2);
        const Space v1550_4 = (has_head(v1550_3) ? constant_9 : Space{});
        const Space v1550_5 = subtract(constant_0,v1550_4);
        Space v1550_8;
        if (!v1550_5.empty()) {
          const Path v1551_6 = concat_path(v1549_6,v1549_7_head);
          const Space v1551_7 = routine_253(c, v1551_6, p1, v1549_7_tail);
          v1550_8 = compose(v1550_5,v1551_7);
        }
        const Space v1550_9 = intersect(constant_8,v1550_2);
        const Space v1550_10 = (has_head(v1550_9) ? constant_9 : Space{});
        Space v1550_12;
        if (!v1550_10.empty()) {
          const Path v1552_6 = concat_path(v1549_6,v1549_7_head);
          const Space v1552_11 = routine_254(c, v1552_6, p1, v1549_7_tail);
          v1550_12 = compose(v1550_10,v1552_11);
        }
        const Space v1550_13 = unite(v1550_8,v1550_12);
        v1549_7_result = unite(v1549_7_result,v1550_13);
      }
      const Space v1549_7 = std::move(v1549_7_result);
      v1548_8 = compose(v1548_5,v1549_7);
    }
    const Space v1548_9 = intersect(constant_8,v1548_2);
    const Space v1548_10 = (has_head(v1548_9) ? constant_9 : Space{});
    Space v1548_12;
    if (!v1548_10.empty()) {
      const Path v1553_6 = concat_path(p0,v1547_12_head);
      Space v1553_11_result;
      for (int v1553_11_label = 1; v1553_11_label <= 2; ++v1553_11_label) {
        const Space v1553_11_tail = child(v1547_12_tail,v1553_11_label);
        if (v1553_11_tail.empty()) continue;
        const Path v1553_11_head{v1553_11_label};
        const Space v1554_2 = singleton(v1553_11_head);
        const Space v1554_3 = intersect(constant_8,v1554_2);
        const Space v1554_4 = (has_head(v1554_3) ? constant_9 : Space{});
        const Space v1554_5 = subtract(constant_0,v1554_4);
        Space v1554_7;
        if (!v1554_5.empty()) {
          const Space v1555_6 = routine_174(c, v1553_11_head, p1, v1553_6, v1553_11_tail);
          v1554_7 = compose(v1554_5,v1555_6);
        }
        const Space v1554_8 = intersect(constant_8,v1554_2);
        const Space v1554_9 = (has_head(v1554_8) ? constant_9 : Space{});
        Space v1554_11;
        if (!v1554_9.empty()) {
          const Space v1556_10 = routine_175(c, v1553_11_head, p1, v1553_6, v1553_11_tail);
          v1554_11 = compose(v1554_9,v1556_10);
        }
        const Space v1554_12 = unite(v1554_7,v1554_11);
        v1553_11_result = unite(v1553_11_result,v1554_12);
      }
      const Space v1553_11 = std::move(v1553_11_result);
      v1548_12 = compose(v1548_10,v1553_11);
    }
    const Space v1548_13 = unite(v1548_8,v1548_12);
    v1547_12_result = unite(v1547_12_result,v1548_13);
  }
  const Space v1547_12 = std::move(v1547_12_result);
  return v1547_12;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1557_13_result;
  for (int v1557_13_label = 1; v1557_13_label <= 2; ++v1557_13_label) {
    const Space v1557_13_tail = child(s0,v1557_13_label);
    if (v1557_13_tail.empty()) continue;
    const Path v1557_13_head{v1557_13_label};
    const Space v1558_2 = singleton(v1557_13_head);
    const Space v1558_3 = intersect(constant_8,v1558_2);
    const Space v1558_4 = (has_head(v1558_3) ? constant_9 : Space{});
    const Space v1558_5 = subtract(constant_0,v1558_4);
    Space v1558_8;
    if (!v1558_5.empty()) {
      const Path v1559_6 = concat_path(p0,v1557_13_head);
      Space v1559_7_result;
      for (int v1559_7_label = 1; v1559_7_label <= 2; ++v1559_7_label) {
        const Space v1559_7_tail = child(v1557_13_tail,v1559_7_label);
        if (v1559_7_tail.empty()) continue;
        const Path v1559_7_head{v1559_7_label};
        const Space v1560_2 = singleton(v1559_7_head);
        const Space v1560_3 = intersect(constant_8,v1560_2);
        const Space v1560_4 = (has_head(v1560_3) ? constant_9 : Space{});
        const Space v1560_5 = subtract(constant_0,v1560_4);
        Space v1560_8;
        if (!v1560_5.empty()) {
          const Path v1561_6 = concat_path(v1559_6,v1559_7_head);
          const Space v1561_7 = routine_255(c, v1561_6, p1, p2, v1559_7_tail);
          v1560_8 = compose(v1560_5,v1561_7);
        }
        const Space v1560_9 = intersect(constant_8,v1560_2);
        const Space v1560_10 = (has_head(v1560_9) ? constant_9 : Space{});
        Space v1560_12;
        if (!v1560_10.empty()) {
          const Path v1562_6 = concat_path(v1559_6,v1559_7_head);
          const Space v1562_11 = routine_256(c, v1562_6, p1, p2, v1559_7_tail);
          v1560_12 = compose(v1560_10,v1562_11);
        }
        const Space v1560_13 = unite(v1560_8,v1560_12);
        v1559_7_result = unite(v1559_7_result,v1560_13);
      }
      const Space v1559_7 = std::move(v1559_7_result);
      v1558_8 = compose(v1558_5,v1559_7);
    }
    const Space v1558_9 = intersect(constant_8,v1558_2);
    const Space v1558_10 = (has_head(v1558_9) ? constant_9 : Space{});
    Space v1558_12;
    if (!v1558_10.empty()) {
      const Path v1563_6 = concat_path(p0,v1557_13_head);
      Space v1563_11_result;
      for (int v1563_11_label = 1; v1563_11_label <= 2; ++v1563_11_label) {
        const Space v1563_11_tail = child(v1557_13_tail,v1563_11_label);
        if (v1563_11_tail.empty()) continue;
        const Path v1563_11_head{v1563_11_label};
        const Space v1564_2 = singleton(v1563_11_head);
        const Space v1564_3 = intersect(constant_8,v1564_2);
        const Space v1564_4 = (has_head(v1564_3) ? constant_9 : Space{});
        const Space v1564_5 = subtract(constant_0,v1564_4);
        Space v1564_8;
        if (!v1564_5.empty()) {
          const Path v1565_6 = concat_path(v1563_6,v1563_11_head);
          const Space v1565_7 = routine_255(c, v1565_6, p1, p2, v1563_11_tail);
          v1564_8 = compose(v1564_5,v1565_7);
        }
        const Space v1564_9 = intersect(constant_8,v1564_2);
        const Space v1564_10 = (has_head(v1564_9) ? constant_9 : Space{});
        Space v1564_12;
        if (!v1564_10.empty()) {
          const Path v1566_6 = concat_path(v1563_6,v1563_11_head);
          const Space v1566_11 = routine_223(c, v1566_6, p1, p2, v1563_11_tail);
          v1564_12 = compose(v1564_10,v1566_11);
        }
        const Space v1564_13 = unite(v1564_8,v1564_12);
        v1563_11_result = unite(v1563_11_result,v1564_13);
      }
      const Space v1563_11 = std::move(v1563_11_result);
      v1558_12 = compose(v1558_10,v1563_11);
    }
    const Space v1558_13 = unite(v1558_8,v1558_12);
    v1557_13_result = unite(v1557_13_result,v1558_13);
  }
  const Space v1557_13 = std::move(v1557_13_result);
  return v1557_13;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1567_14_result;
  for (int v1567_14_label = 1; v1567_14_label <= 2; ++v1567_14_label) {
    const Space v1567_14_tail = child(s0,v1567_14_label);
    if (v1567_14_tail.empty()) continue;
    const Path v1567_14_head{v1567_14_label};
    const Space v1568_2 = singleton(v1567_14_head);
    const Space v1568_3 = intersect(constant_8,v1568_2);
    const Space v1568_4 = (has_head(v1568_3) ? constant_9 : Space{});
    const Space v1568_5 = subtract(constant_0,v1568_4);
    Space v1568_8;
    if (!v1568_5.empty()) {
      const Path v1569_6 = concat_path(p0,v1567_14_head);
      Space v1569_7_result;
      for (int v1569_7_label = 1; v1569_7_label <= 2; ++v1569_7_label) {
        const Space v1569_7_tail = child(v1567_14_tail,v1569_7_label);
        if (v1569_7_tail.empty()) continue;
        const Path v1569_7_head{v1569_7_label};
        const Space v1570_2 = singleton(v1569_7_head);
        const Space v1570_3 = intersect(constant_8,v1570_2);
        const Space v1570_4 = (has_head(v1570_3) ? constant_9 : Space{});
        const Space v1570_5 = subtract(constant_0,v1570_4);
        Space v1570_8;
        if (!v1570_5.empty()) {
          const Path v1571_6 = concat_path(v1569_6,v1569_7_head);
          const Space v1571_7 = routine_255(c, v1571_6, p1, p2, v1569_7_tail);
          v1570_8 = compose(v1570_5,v1571_7);
        }
        const Space v1570_9 = intersect(constant_8,v1570_2);
        const Space v1570_10 = (has_head(v1570_9) ? constant_9 : Space{});
        Space v1570_12;
        if (!v1570_10.empty()) {
          const Path v1572_6 = concat_path(v1569_6,v1569_7_head);
          const Space v1572_11 = routine_256(c, v1572_6, p1, p2, v1569_7_tail);
          v1570_12 = compose(v1570_10,v1572_11);
        }
        const Space v1570_13 = unite(v1570_8,v1570_12);
        v1569_7_result = unite(v1569_7_result,v1570_13);
      }
      const Space v1569_7 = std::move(v1569_7_result);
      v1568_8 = compose(v1568_5,v1569_7);
    }
    const Space v1568_9 = intersect(constant_8,v1568_2);
    const Space v1568_10 = (has_head(v1568_9) ? constant_9 : Space{});
    Space v1568_17;
    if (!v1568_10.empty()) {
      const Path v1573_6 = concat_path(p0,v1567_14_head);
      Space v1573_11_result;
      for (int v1573_11_label = 1; v1573_11_label <= 2; ++v1573_11_label) {
        const Space v1573_11_tail = child(v1567_14_tail,v1573_11_label);
        if (v1573_11_tail.empty()) continue;
        const Path v1573_11_head{v1573_11_label};
        const Space v1574_2 = singleton(v1573_11_head);
        const Space v1574_3 = intersect(constant_8,v1574_2);
        const Space v1574_4 = (has_head(v1574_3) ? constant_9 : Space{});
        const Space v1574_5 = subtract(constant_0,v1574_4);
        Space v1574_7;
        if (!v1574_5.empty()) {
          const Space v1575_6 = routine_257(c, v1573_11_head, v1573_11_tail);
          v1574_7 = compose(v1574_5,v1575_6);
        }
        const Space v1574_8 = intersect(constant_8,v1574_2);
        const Space v1574_9 = (has_head(v1574_8) ? constant_9 : Space{});
        Space v1574_11;
        if (!v1574_9.empty()) {
          const Space v1576_10 = routine_258(c, v1573_11_head, v1573_11_tail);
          v1574_11 = compose(v1574_9,v1576_10);
        }
        const Space v1574_12 = unite(v1574_7,v1574_11);
        v1573_11_result = unite(v1573_11_result,v1574_12);
      }
      const Space v1573_11 = std::move(v1573_11_result);
      const Space v1573_12 = raffine(constant_25,v1573_11);
      const Space v1573_13 = unite(v1573_12,v1567_14_tail);
      const Path v1573_14 = concat_path(p2,v1573_6);
      const Space v1573_15 = wrap(v1573_13,v1573_14);
      const Space v1573_16 = unwrap(v1573_15,p1);
      v1568_17 = compose(v1568_10,v1573_16);
    }
    const Space v1568_18 = unite(v1568_8,v1568_17);
    v1567_14_result = unite(v1567_14_result,v1568_18);
  }
  const Space v1567_14 = std::move(v1567_14_result);
  return v1567_14;
}

static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1577_13_result;
  for (int v1577_13_label = 1; v1577_13_label <= 2; ++v1577_13_label) {
    const Space v1577_13_tail = child(s0,v1577_13_label);
    if (v1577_13_tail.empty()) continue;
    const Path v1577_13_head{v1577_13_label};
    const Space v1578_2 = singleton(v1577_13_head);
    const Space v1578_3 = intersect(constant_8,v1578_2);
    const Space v1578_4 = (has_head(v1578_3) ? constant_9 : Space{});
    const Space v1578_5 = subtract(constant_0,v1578_4);
    Space v1578_8;
    if (!v1578_5.empty()) {
      const Path v1579_6 = concat_path(p0,v1577_13_head);
      Space v1579_7_result;
      for (int v1579_7_label = 1; v1579_7_label <= 2; ++v1579_7_label) {
        const Space v1579_7_tail = child(v1577_13_tail,v1579_7_label);
        if (v1579_7_tail.empty()) continue;
        const Path v1579_7_head{v1579_7_label};
        const Space v1580_2 = singleton(v1579_7_head);
        const Space v1580_3 = intersect(constant_8,v1580_2);
        const Space v1580_4 = (has_head(v1580_3) ? constant_9 : Space{});
        const Space v1580_5 = subtract(constant_0,v1580_4);
        Space v1580_8;
        if (!v1580_5.empty()) {
          const Path v1581_6 = concat_path(v1579_6,v1579_7_head);
          const Space v1581_7 = routine_259(c, v1581_6, p1, v1579_7_tail, s1);
          v1580_8 = compose(v1580_5,v1581_7);
        }
        const Space v1580_9 = intersect(constant_8,v1580_2);
        const Space v1580_10 = (has_head(v1580_9) ? constant_9 : Space{});
        Space v1580_12;
        if (!v1580_10.empty()) {
          const Path v1582_6 = concat_path(v1579_6,v1579_7_head);
          const Space v1582_11 = routine_260(c, v1582_6, p1, v1579_7_tail, s1);
          v1580_12 = compose(v1580_10,v1582_11);
        }
        const Space v1580_13 = unite(v1580_8,v1580_12);
        v1579_7_result = unite(v1579_7_result,v1580_13);
      }
      const Space v1579_7 = std::move(v1579_7_result);
      v1578_8 = compose(v1578_5,v1579_7);
    }
    const Space v1578_9 = intersect(constant_8,v1578_2);
    const Space v1578_10 = (has_head(v1578_9) ? constant_9 : Space{});
    Space v1578_12;
    if (!v1578_10.empty()) {
      const Path v1583_6 = concat_path(p0,v1577_13_head);
      Space v1583_11_result;
      for (int v1583_11_label = 1; v1583_11_label <= 2; ++v1583_11_label) {
        const Space v1583_11_tail = child(v1577_13_tail,v1583_11_label);
        if (v1583_11_tail.empty()) continue;
        const Path v1583_11_head{v1583_11_label};
        const Space v1584_2 = singleton(v1583_11_head);
        const Space v1584_3 = intersect(constant_8,v1584_2);
        const Space v1584_4 = (has_head(v1584_3) ? constant_9 : Space{});
        const Space v1584_5 = subtract(constant_0,v1584_4);
        Space v1584_8;
        if (!v1584_5.empty()) {
          const Path v1585_6 = concat_path(v1583_6,v1583_11_head);
          const Space v1585_7 = routine_259(c, v1585_6, p1, v1583_11_tail, s1);
          v1584_8 = compose(v1584_5,v1585_7);
        }
        const Space v1584_9 = intersect(constant_8,v1584_2);
        const Space v1584_10 = (has_head(v1584_9) ? constant_9 : Space{});
        Space v1584_12;
        if (!v1584_10.empty()) {
          const Path v1586_6 = concat_path(v1583_6,v1583_11_head);
          const Space v1586_11 = routine_133(c, v1586_6, p1, v1583_11_tail, s1);
          v1584_12 = compose(v1584_10,v1586_11);
        }
        const Space v1584_13 = unite(v1584_8,v1584_12);
        v1583_11_result = unite(v1583_11_result,v1584_13);
      }
      const Space v1583_11 = std::move(v1583_11_result);
      v1578_12 = compose(v1578_10,v1583_11);
    }
    const Space v1578_13 = unite(v1578_8,v1578_12);
    v1577_13_result = unite(v1577_13_result,v1578_13);
  }
  const Space v1577_13 = std::move(v1577_13_result);
  return v1577_13;
}

static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1587_10_result;
  for (int v1587_10_label = 1; v1587_10_label <= 2; ++v1587_10_label) {
    const Space v1587_10_tail = child(s0,v1587_10_label);
    if (v1587_10_tail.empty()) continue;
    const Path v1587_10_head{v1587_10_label};
    const Space v1588_2 = singleton(v1587_10_head);
    const Space v1588_3 = intersect(constant_8,v1588_2);
    const Space v1588_4 = (has_head(v1588_3) ? constant_9 : Space{});
    const Space v1588_5 = subtract(constant_0,v1588_4);
    Space v1588_8;
    if (!v1588_5.empty()) {
      const Path v1589_6 = concat_path(p0,v1587_10_head);
      Space v1589_7_result;
      for (int v1589_7_label = 1; v1589_7_label <= 2; ++v1589_7_label) {
        const Space v1589_7_tail = child(v1587_10_tail,v1589_7_label);
        if (v1589_7_tail.empty()) continue;
        const Path v1589_7_head{v1589_7_label};
        const Space v1590_2 = singleton(v1589_7_head);
        const Space v1590_3 = intersect(constant_8,v1590_2);
        const Space v1590_4 = (has_head(v1590_3) ? constant_9 : Space{});
        const Space v1590_5 = subtract(constant_0,v1590_4);
        Space v1590_8;
        if (!v1590_5.empty()) {
          const Path v1591_6 = concat_path(v1589_6,v1589_7_head);
          const Space v1591_7 = routine_259(c, v1591_6, p1, v1589_7_tail, s1);
          v1590_8 = compose(v1590_5,v1591_7);
        }
        const Space v1590_9 = intersect(constant_8,v1590_2);
        const Space v1590_10 = (has_head(v1590_9) ? constant_9 : Space{});
        Space v1590_12;
        if (!v1590_10.empty()) {
          const Path v1592_6 = concat_path(v1589_6,v1589_7_head);
          const Space v1592_11 = routine_260(c, v1592_6, p1, v1589_7_tail, s1);
          v1590_12 = compose(v1590_10,v1592_11);
        }
        const Space v1590_13 = unite(v1590_8,v1590_12);
        v1589_7_result = unite(v1589_7_result,v1590_13);
      }
      const Space v1589_7 = std::move(v1589_7_result);
      v1588_8 = compose(v1588_5,v1589_7);
    }
    const Space v1588_9 = intersect(constant_8,v1588_2);
    const Space v1588_10 = (has_head(v1588_9) ? constant_9 : Space{});
    const Space v1588_11 = unwrap(v1587_10_tail,p1);
    const Path v1593_6 = concat_path(p0,v1587_10_head);
    const Space v1588_12 = wrap(v1588_11,v1593_6);
    const Space v1588_13 = compose(v1588_12,s1);
    const Space v1588_14 = compose(v1588_10,v1588_13);
    const Space v1588_15 = unite(v1588_8,v1588_14);
    v1587_10_result = unite(v1587_10_result,v1588_15);
  }
  const Space v1587_10 = std::move(v1587_10_result);
  return v1587_10;
}

static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1594_3 = Space{};
  return v1594_3;
}

static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1595_12_result;
  for (int v1595_12_label = 1; v1595_12_label <= 2; ++v1595_12_label) {
    const Space v1595_12_tail = child(s0,v1595_12_label);
    if (v1595_12_tail.empty()) continue;
    const Path v1595_12_head{v1595_12_label};
    const Space v1596_2 = singleton(v1595_12_head);
    const Space v1596_3 = intersect(constant_8,v1596_2);
    const Space v1596_4 = (has_head(v1596_3) ? constant_9 : Space{});
    Space v1596_11;
    if (!v1596_4.empty()) {
      Space v1597_9;
      if (!constant_0.empty()) {
        const Path v1598_5 = concat_path(p0,v1595_12_head);
        const Space v1598_6 = routine_98(c, constant_14, p1, v1598_5, constant_15);
        const Space v1598_7 = routine_99(c, constant_16, p1, v1598_5, constant_17);
        const Space v1598_8 = unite(v1598_6,v1598_7);
        v1597_9 = compose(constant_0,v1598_8);
      }
      Space v1597_10_result;
      for (int v1597_10_label = 1; v1597_10_label <= 2; ++v1597_10_label) {
        const Space v1597_10_tail = child(v1597_9,v1597_10_label);
        if (v1597_10_tail.empty()) continue;
        const Path v1597_10_head{v1597_10_label};
        const Space v1599_2 = singleton(v1597_10_head);
        const Space v1599_3 = intersect(constant_8,v1599_2);
        const Space v1599_4 = (has_head(v1599_3) ? constant_9 : Space{});
        const Space v1599_5 = subtract(constant_0,v1599_4);
        Space v1599_7;
        if (!v1599_5.empty()) {
          const Space v1600_6 = routine_100(c, v1597_10_head, v1597_10_tail, v1595_12_tail);
          v1599_7 = compose(v1599_5,v1600_6);
        }
        const Space v1599_8 = intersect(constant_8,v1599_2);
        const Space v1599_9 = (has_head(v1599_8) ? constant_9 : Space{});
        Space v1599_11;
        if (!v1599_9.empty()) {
          const Space v1601_10 = routine_101(c, v1597_10_head, v1597_10_tail, v1595_12_tail);
          v1599_11 = compose(v1599_9,v1601_10);
        }
        const Space v1599_12 = unite(v1599_7,v1599_11);
        v1597_10_result = unite(v1597_10_result,v1599_12);
      }
      const Space v1597_10 = std::move(v1597_10_result);
      v1596_11 = compose(v1596_4,v1597_10);
    }
    v1595_12_result = unite(v1595_12_result,v1596_11);
  }
  const Space v1595_12 = std::move(v1595_12_result);
  return v1595_12;
}

static Space routine_180(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1602_13_result;
  for (int v1602_13_label = 1; v1602_13_label <= 2; ++v1602_13_label) {
    const Space v1602_13_tail = child(s0,v1602_13_label);
    if (v1602_13_tail.empty()) continue;
    const Path v1602_13_head{v1602_13_label};
    const Space v1603_2 = singleton(v1602_13_head);
    const Space v1603_3 = intersect(constant_8,v1603_2);
    const Space v1603_4 = (has_head(v1603_3) ? constant_9 : Space{});
    const Space v1603_5 = subtract(constant_0,v1603_4);
    Space v1603_8;
    if (!v1603_5.empty()) {
      const Path v1604_6 = concat_path(p0,v1602_13_head);
      Space v1604_7_result;
      for (int v1604_7_label = 1; v1604_7_label <= 2; ++v1604_7_label) {
        const Space v1604_7_tail = child(v1602_13_tail,v1604_7_label);
        if (v1604_7_tail.empty()) continue;
        const Path v1604_7_head{v1604_7_label};
        const Space v1605_2 = singleton(v1604_7_head);
        const Space v1605_3 = intersect(constant_8,v1605_2);
        const Space v1605_4 = (has_head(v1605_3) ? constant_9 : Space{});
        const Space v1605_5 = subtract(constant_0,v1605_4);
        Space v1605_8;
        if (!v1605_5.empty()) {
          const Path v1606_6 = concat_path(v1604_6,v1604_7_head);
          const Space v1606_7 = routine_261(c, v1606_6, p1, p2, v1604_7_tail);
          v1605_8 = compose(v1605_5,v1606_7);
        }
        const Space v1605_9 = intersect(constant_8,v1605_2);
        const Space v1605_10 = (has_head(v1605_9) ? constant_9 : Space{});
        Space v1605_12;
        if (!v1605_10.empty()) {
          const Path v1607_6 = concat_path(v1604_6,v1604_7_head);
          const Space v1607_11 = routine_262(c, v1607_6, p1, p2, v1604_7_tail);
          v1605_12 = compose(v1605_10,v1607_11);
        }
        const Space v1605_13 = unite(v1605_8,v1605_12);
        v1604_7_result = unite(v1604_7_result,v1605_13);
      }
      const Space v1604_7 = std::move(v1604_7_result);
      v1603_8 = compose(v1603_5,v1604_7);
    }
    const Space v1603_9 = intersect(constant_8,v1603_2);
    const Space v1603_10 = (has_head(v1603_9) ? constant_9 : Space{});
    Space v1603_12;
    if (!v1603_10.empty()) {
      const Path v1608_6 = concat_path(p0,v1602_13_head);
      Space v1608_11_result;
      for (int v1608_11_label = 1; v1608_11_label <= 2; ++v1608_11_label) {
        const Space v1608_11_tail = child(v1602_13_tail,v1608_11_label);
        if (v1608_11_tail.empty()) continue;
        const Path v1608_11_head{v1608_11_label};
        const Space v1609_2 = singleton(v1608_11_head);
        const Space v1609_3 = intersect(constant_8,v1609_2);
        const Space v1609_4 = (has_head(v1609_3) ? constant_9 : Space{});
        const Space v1609_5 = subtract(constant_0,v1609_4);
        Space v1609_8;
        if (!v1609_5.empty()) {
          const Path v1610_6 = concat_path(v1608_6,v1608_11_head);
          const Space v1610_7 = routine_261(c, v1610_6, p1, p2, v1608_11_tail);
          v1609_8 = compose(v1609_5,v1610_7);
        }
        const Space v1609_9 = intersect(constant_8,v1609_2);
        const Space v1609_10 = (has_head(v1609_9) ? constant_9 : Space{});
        Space v1609_12;
        if (!v1609_10.empty()) {
          const Path v1611_6 = concat_path(v1608_6,v1608_11_head);
          const Space v1611_11 = routine_138(c, v1611_6, p1, p2, v1608_11_tail);
          v1609_12 = compose(v1609_10,v1611_11);
        }
        const Space v1609_13 = unite(v1609_8,v1609_12);
        v1608_11_result = unite(v1608_11_result,v1609_13);
      }
      const Space v1608_11 = std::move(v1608_11_result);
      v1603_12 = compose(v1603_10,v1608_11);
    }
    const Space v1603_13 = unite(v1603_8,v1603_12);
    v1602_13_result = unite(v1602_13_result,v1603_13);
  }
  const Space v1602_13 = std::move(v1602_13_result);
  return v1602_13;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1612_13_result;
  for (int v1612_13_label = 1; v1612_13_label <= 2; ++v1612_13_label) {
    const Space v1612_13_tail = child(s0,v1612_13_label);
    if (v1612_13_tail.empty()) continue;
    const Path v1612_13_head{v1612_13_label};
    const Space v1613_2 = singleton(v1612_13_head);
    const Space v1613_3 = intersect(constant_8,v1613_2);
    const Space v1613_4 = (has_head(v1613_3) ? constant_9 : Space{});
    const Space v1613_5 = subtract(constant_0,v1613_4);
    Space v1613_8;
    if (!v1613_5.empty()) {
      const Path v1614_6 = concat_path(p0,v1612_13_head);
      Space v1614_7_result;
      for (int v1614_7_label = 1; v1614_7_label <= 2; ++v1614_7_label) {
        const Space v1614_7_tail = child(v1612_13_tail,v1614_7_label);
        if (v1614_7_tail.empty()) continue;
        const Path v1614_7_head{v1614_7_label};
        const Space v1615_2 = singleton(v1614_7_head);
        const Space v1615_3 = intersect(constant_8,v1615_2);
        const Space v1615_4 = (has_head(v1615_3) ? constant_9 : Space{});
        const Space v1615_5 = subtract(constant_0,v1615_4);
        Space v1615_8;
        if (!v1615_5.empty()) {
          const Path v1616_6 = concat_path(v1614_6,v1614_7_head);
          const Space v1616_7 = routine_261(c, v1616_6, p1, p2, v1614_7_tail);
          v1615_8 = compose(v1615_5,v1616_7);
        }
        const Space v1615_9 = intersect(constant_8,v1615_2);
        const Space v1615_10 = (has_head(v1615_9) ? constant_9 : Space{});
        Space v1615_12;
        if (!v1615_10.empty()) {
          const Path v1617_6 = concat_path(v1614_6,v1614_7_head);
          const Space v1617_11 = routine_262(c, v1617_6, p1, p2, v1614_7_tail);
          v1615_12 = compose(v1615_10,v1617_11);
        }
        const Space v1615_13 = unite(v1615_8,v1615_12);
        v1614_7_result = unite(v1614_7_result,v1615_13);
      }
      const Space v1614_7 = std::move(v1614_7_result);
      v1613_8 = compose(v1613_5,v1614_7);
    }
    const Space v1613_9 = intersect(constant_8,v1613_2);
    const Space v1613_10 = (has_head(v1613_9) ? constant_9 : Space{});
    Space v1613_12;
    if (!v1613_10.empty()) {
      const Path v1618_6 = concat_path(p0,v1612_13_head);
      Space v1618_11_result;
      for (int v1618_11_label = 1; v1618_11_label <= 2; ++v1618_11_label) {
        const Space v1618_11_tail = child(v1612_13_tail,v1618_11_label);
        if (v1618_11_tail.empty()) continue;
        const Path v1618_11_head{v1618_11_label};
        const Space v1619_2 = singleton(v1618_11_head);
        const Space v1619_3 = intersect(constant_8,v1619_2);
        const Space v1619_4 = (has_head(v1619_3) ? constant_9 : Space{});
        const Space v1619_5 = subtract(constant_0,v1619_4);
        Space v1619_7;
        if (!v1619_5.empty()) {
          const Space v1620_6 = routine_182(c, v1618_11_head, p1, p2, v1618_6, v1618_11_tail);
          v1619_7 = compose(v1619_5,v1620_6);
        }
        const Space v1619_8 = intersect(constant_8,v1619_2);
        const Space v1619_9 = (has_head(v1619_8) ? constant_9 : Space{});
        Space v1619_11;
        if (!v1619_9.empty()) {
          const Space v1621_10 = routine_183(c, v1618_11_head, p1, p2, v1618_6, v1618_11_tail);
          v1619_11 = compose(v1619_9,v1621_10);
        }
        const Space v1619_12 = unite(v1619_7,v1619_11);
        v1618_11_result = unite(v1618_11_result,v1619_12);
      }
      const Space v1618_11 = std::move(v1618_11_result);
      v1613_12 = compose(v1613_10,v1618_11);
    }
    const Space v1613_13 = unite(v1613_8,v1613_12);
    v1612_13_result = unite(v1612_13_result,v1613_13);
  }
  const Space v1612_13 = std::move(v1612_13_result);
  return v1612_13;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v1622_14_result;
  for (int v1622_14_label = 1; v1622_14_label <= 2; ++v1622_14_label) {
    const Space v1622_14_tail = child(s0,v1622_14_label);
    if (v1622_14_tail.empty()) continue;
    const Path v1622_14_head{v1622_14_label};
    const Space v1623_2 = singleton(v1622_14_head);
    const Space v1623_3 = intersect(constant_8,v1623_2);
    const Space v1623_4 = (has_head(v1623_3) ? constant_9 : Space{});
    const Space v1623_5 = subtract(constant_0,v1623_4);
    Space v1623_8;
    if (!v1623_5.empty()) {
      const Path v1624_6 = concat_path(p0,v1622_14_head);
      Space v1624_7_result;
      for (int v1624_7_label = 1; v1624_7_label <= 2; ++v1624_7_label) {
        const Space v1624_7_tail = child(v1622_14_tail,v1624_7_label);
        if (v1624_7_tail.empty()) continue;
        const Path v1624_7_head{v1624_7_label};
        const Space v1625_2 = singleton(v1624_7_head);
        const Space v1625_3 = intersect(constant_8,v1625_2);
        const Space v1625_4 = (has_head(v1625_3) ? constant_9 : Space{});
        const Space v1625_5 = subtract(constant_0,v1625_4);
        Space v1625_8;
        if (!v1625_5.empty()) {
          const Path v1626_6 = concat_path(v1624_6,v1624_7_head);
          const Space v1626_7 = routine_263(c, v1626_6, p1, p2, p3, v1624_7_tail);
          v1625_8 = compose(v1625_5,v1626_7);
        }
        const Space v1625_9 = intersect(constant_8,v1625_2);
        const Space v1625_10 = (has_head(v1625_9) ? constant_9 : Space{});
        Space v1625_12;
        if (!v1625_10.empty()) {
          const Path v1627_6 = concat_path(v1624_6,v1624_7_head);
          const Space v1627_11 = routine_264(c, v1627_6, p1, p2, p3, v1624_7_tail);
          v1625_12 = compose(v1625_10,v1627_11);
        }
        const Space v1625_13 = unite(v1625_8,v1625_12);
        v1624_7_result = unite(v1624_7_result,v1625_13);
      }
      const Space v1624_7 = std::move(v1624_7_result);
      v1623_8 = compose(v1623_5,v1624_7);
    }
    const Space v1623_9 = intersect(constant_8,v1623_2);
    const Space v1623_10 = (has_head(v1623_9) ? constant_9 : Space{});
    Space v1623_12;
    if (!v1623_10.empty()) {
      const Path v1628_6 = concat_path(p0,v1622_14_head);
      Space v1628_11_result;
      for (int v1628_11_label = 1; v1628_11_label <= 2; ++v1628_11_label) {
        const Space v1628_11_tail = child(v1622_14_tail,v1628_11_label);
        if (v1628_11_tail.empty()) continue;
        const Path v1628_11_head{v1628_11_label};
        const Space v1629_2 = singleton(v1628_11_head);
        const Space v1629_3 = intersect(constant_8,v1629_2);
        const Space v1629_4 = (has_head(v1629_3) ? constant_9 : Space{});
        const Space v1629_5 = subtract(constant_0,v1629_4);
        Space v1629_8;
        if (!v1629_5.empty()) {
          const Path v1630_6 = concat_path(v1628_6,v1628_11_head);
          const Space v1630_7 = routine_263(c, v1630_6, p1, p2, p3, v1628_11_tail);
          v1629_8 = compose(v1629_5,v1630_7);
        }
        const Space v1629_9 = intersect(constant_8,v1629_2);
        const Space v1629_10 = (has_head(v1629_9) ? constant_9 : Space{});
        Space v1629_12;
        if (!v1629_10.empty()) {
          const Path v1631_6 = concat_path(v1628_6,v1628_11_head);
          const Space v1631_11 = routine_230(c, v1631_6, p1, p2, p3, v1628_11_tail);
          v1629_12 = compose(v1629_10,v1631_11);
        }
        const Space v1629_13 = unite(v1629_8,v1629_12);
        v1628_11_result = unite(v1628_11_result,v1629_13);
      }
      const Space v1628_11 = std::move(v1628_11_result);
      v1623_12 = compose(v1623_10,v1628_11);
    }
    const Space v1623_13 = unite(v1623_8,v1623_12);
    v1622_14_result = unite(v1622_14_result,v1623_13);
  }
  const Space v1622_14 = std::move(v1622_14_result);
  return v1622_14;
}

static Space routine_183(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v1632_15_result;
  for (int v1632_15_label = 1; v1632_15_label <= 2; ++v1632_15_label) {
    const Space v1632_15_tail = child(s0,v1632_15_label);
    if (v1632_15_tail.empty()) continue;
    const Path v1632_15_head{v1632_15_label};
    const Space v1633_2 = singleton(v1632_15_head);
    const Space v1633_3 = intersect(constant_8,v1633_2);
    const Space v1633_4 = (has_head(v1633_3) ? constant_9 : Space{});
    const Space v1633_5 = subtract(constant_0,v1633_4);
    Space v1633_8;
    if (!v1633_5.empty()) {
      const Path v1634_6 = concat_path(p0,v1632_15_head);
      Space v1634_7_result;
      for (int v1634_7_label = 1; v1634_7_label <= 2; ++v1634_7_label) {
        const Space v1634_7_tail = child(v1632_15_tail,v1634_7_label);
        if (v1634_7_tail.empty()) continue;
        const Path v1634_7_head{v1634_7_label};
        const Space v1635_2 = singleton(v1634_7_head);
        const Space v1635_3 = intersect(constant_8,v1635_2);
        const Space v1635_4 = (has_head(v1635_3) ? constant_9 : Space{});
        const Space v1635_5 = subtract(constant_0,v1635_4);
        Space v1635_8;
        if (!v1635_5.empty()) {
          const Path v1636_6 = concat_path(v1634_6,v1634_7_head);
          const Space v1636_7 = routine_263(c, v1636_6, p1, p2, p3, v1634_7_tail);
          v1635_8 = compose(v1635_5,v1636_7);
        }
        const Space v1635_9 = intersect(constant_8,v1635_2);
        const Space v1635_10 = (has_head(v1635_9) ? constant_9 : Space{});
        Space v1635_12;
        if (!v1635_10.empty()) {
          const Path v1637_6 = concat_path(v1634_6,v1634_7_head);
          const Space v1637_11 = routine_264(c, v1637_6, p1, p2, p3, v1634_7_tail);
          v1635_12 = compose(v1635_10,v1637_11);
        }
        const Space v1635_13 = unite(v1635_8,v1635_12);
        v1634_7_result = unite(v1634_7_result,v1635_13);
      }
      const Space v1634_7 = std::move(v1634_7_result);
      v1633_8 = compose(v1633_5,v1634_7);
    }
    const Space v1633_9 = intersect(constant_8,v1633_2);
    const Space v1633_10 = (has_head(v1633_9) ? constant_9 : Space{});
    Space v1633_19;
    if (!v1633_10.empty()) {
      const Path v1638_6 = concat_path(p0,v1632_15_head);
      Space v1638_11_result;
      for (int v1638_11_label = 1; v1638_11_label <= 2; ++v1638_11_label) {
        const Space v1638_11_tail = child(v1632_15_tail,v1638_11_label);
        if (v1638_11_tail.empty()) continue;
        const Path v1638_11_head{v1638_11_label};
        const Space v1639_2 = singleton(v1638_11_head);
        const Space v1639_3 = intersect(constant_8,v1639_2);
        const Space v1639_4 = (has_head(v1639_3) ? constant_9 : Space{});
        const Space v1639_5 = subtract(constant_0,v1639_4);
        Space v1639_7;
        if (!v1639_5.empty()) {
          const Space v1640_6 = routine_265(c, v1638_11_head, v1638_11_tail);
          v1639_7 = compose(v1639_5,v1640_6);
        }
        const Space v1639_8 = intersect(constant_8,v1639_2);
        const Space v1639_9 = (has_head(v1639_8) ? constant_9 : Space{});
        Space v1639_11;
        if (!v1639_9.empty()) {
          const Space v1641_10 = routine_266(c, v1638_11_head, v1638_11_tail);
          v1639_11 = compose(v1639_9,v1641_10);
        }
        const Space v1639_12 = unite(v1639_7,v1639_11);
        v1638_11_result = unite(v1638_11_result,v1639_12);
      }
      const Space v1638_11 = std::move(v1638_11_result);
      const Space v1638_12 = raffine(constant_25,v1638_11);
      const Space v1638_13 = unite(v1638_12,v1632_15_tail);
      const Path v1638_14 = concat_path(p3,v1638_6);
      const Space v1638_15 = wrap(v1638_13,v1638_14);
      const Space v1638_16 = unwrap(v1638_15,p1);
      const Space v1638_17 = unwrap(v1638_16,p2);
      const Space v1638_18 = unwrap(v1638_17,p1);
      v1633_19 = compose(v1633_10,v1638_18);
    }
    const Space v1633_20 = unite(v1633_8,v1633_19);
    v1632_15_result = unite(v1632_15_result,v1633_20);
  }
  const Space v1632_15 = std::move(v1632_15_result);
  return v1632_15;
}

static Space routine_184(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1642_12_result;
  for (int v1642_12_label = 1; v1642_12_label <= 2; ++v1642_12_label) {
    const Space v1642_12_tail = child(s0,v1642_12_label);
    if (v1642_12_tail.empty()) continue;
    const Path v1642_12_head{v1642_12_label};
    const Space v1643_2 = singleton(v1642_12_head);
    const Space v1643_3 = intersect(constant_8,v1643_2);
    const Space v1643_4 = (has_head(v1643_3) ? constant_9 : Space{});
    const Space v1643_5 = subtract(constant_0,v1643_4);
    Space v1643_8;
    if (!v1643_5.empty()) {
      const Path v1644_6 = concat_path(p0,v1642_12_head);
      Space v1644_7_result;
      for (int v1644_7_label = 1; v1644_7_label <= 2; ++v1644_7_label) {
        const Space v1644_7_tail = child(v1642_12_tail,v1644_7_label);
        if (v1644_7_tail.empty()) continue;
        const Path v1644_7_head{v1644_7_label};
        const Space v1645_2 = singleton(v1644_7_head);
        const Space v1645_3 = intersect(constant_8,v1645_2);
        const Space v1645_4 = (has_head(v1645_3) ? constant_9 : Space{});
        const Space v1645_5 = subtract(constant_0,v1645_4);
        Space v1645_8;
        if (!v1645_5.empty()) {
          const Path v1646_6 = concat_path(v1644_6,v1644_7_head);
          const Space v1646_7 = routine_267(c, v1646_6, v1644_7_tail, s1);
          v1645_8 = compose(v1645_5,v1646_7);
        }
        const Space v1645_9 = intersect(constant_8,v1645_2);
        const Space v1645_10 = (has_head(v1645_9) ? constant_9 : Space{});
        Space v1645_12;
        if (!v1645_10.empty()) {
          const Path v1647_6 = concat_path(v1644_6,v1644_7_head);
          const Space v1647_11 = routine_268(c, v1647_6, v1644_7_tail, s1);
          v1645_12 = compose(v1645_10,v1647_11);
        }
        const Space v1645_13 = unite(v1645_8,v1645_12);
        v1644_7_result = unite(v1644_7_result,v1645_13);
      }
      const Space v1644_7 = std::move(v1644_7_result);
      v1643_8 = compose(v1643_5,v1644_7);
    }
    const Space v1643_9 = intersect(constant_8,v1643_2);
    const Space v1643_10 = (has_head(v1643_9) ? constant_9 : Space{});
    Space v1643_12;
    if (!v1643_10.empty()) {
      const Path v1648_6 = concat_path(p0,v1642_12_head);
      Space v1648_11_result;
      for (int v1648_11_label = 1; v1648_11_label <= 2; ++v1648_11_label) {
        const Space v1648_11_tail = child(v1642_12_tail,v1648_11_label);
        if (v1648_11_tail.empty()) continue;
        const Path v1648_11_head{v1648_11_label};
        const Space v1649_2 = singleton(v1648_11_head);
        const Space v1649_3 = intersect(constant_8,v1649_2);
        const Space v1649_4 = (has_head(v1649_3) ? constant_9 : Space{});
        const Space v1649_5 = subtract(constant_0,v1649_4);
        Space v1649_8;
        if (!v1649_5.empty()) {
          const Path v1650_6 = concat_path(v1648_6,v1648_11_head);
          const Space v1650_7 = routine_267(c, v1650_6, v1648_11_tail, s1);
          v1649_8 = compose(v1649_5,v1650_7);
        }
        const Space v1649_9 = intersect(constant_8,v1649_2);
        const Space v1649_10 = (has_head(v1649_9) ? constant_9 : Space{});
        Space v1649_12;
        if (!v1649_10.empty()) {
          const Path v1651_6 = concat_path(v1648_6,v1648_11_head);
          const Space v1651_11 = routine_141(c, v1651_6, v1648_11_tail, s1);
          v1649_12 = compose(v1649_10,v1651_11);
        }
        const Space v1649_13 = unite(v1649_8,v1649_12);
        v1648_11_result = unite(v1648_11_result,v1649_13);
      }
      const Space v1648_11 = std::move(v1648_11_result);
      v1643_12 = compose(v1643_10,v1648_11);
    }
    const Space v1643_13 = unite(v1643_8,v1643_12);
    v1642_12_result = unite(v1642_12_result,v1643_13);
  }
  const Space v1642_12 = std::move(v1642_12_result);
  return v1642_12;
}

static Space routine_185(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1652_9_result;
  for (int v1652_9_label = 1; v1652_9_label <= 2; ++v1652_9_label) {
    const Space v1652_9_tail = child(s0,v1652_9_label);
    if (v1652_9_tail.empty()) continue;
    const Path v1652_9_head{v1652_9_label};
    const Space v1653_2 = singleton(v1652_9_head);
    const Space v1653_3 = intersect(constant_8,v1653_2);
    const Space v1653_4 = (has_head(v1653_3) ? constant_9 : Space{});
    const Space v1653_5 = subtract(constant_0,v1653_4);
    Space v1653_8;
    if (!v1653_5.empty()) {
      const Path v1654_6 = concat_path(p0,v1652_9_head);
      Space v1654_7_result;
      for (int v1654_7_label = 1; v1654_7_label <= 2; ++v1654_7_label) {
        const Space v1654_7_tail = child(v1652_9_tail,v1654_7_label);
        if (v1654_7_tail.empty()) continue;
        const Path v1654_7_head{v1654_7_label};
        const Space v1655_2 = singleton(v1654_7_head);
        const Space v1655_3 = intersect(constant_8,v1655_2);
        const Space v1655_4 = (has_head(v1655_3) ? constant_9 : Space{});
        const Space v1655_5 = subtract(constant_0,v1655_4);
        Space v1655_8;
        if (!v1655_5.empty()) {
          const Path v1656_6 = concat_path(v1654_6,v1654_7_head);
          const Space v1656_7 = routine_267(c, v1656_6, v1654_7_tail, s1);
          v1655_8 = compose(v1655_5,v1656_7);
        }
        const Space v1655_9 = intersect(constant_8,v1655_2);
        const Space v1655_10 = (has_head(v1655_9) ? constant_9 : Space{});
        Space v1655_12;
        if (!v1655_10.empty()) {
          const Path v1657_6 = concat_path(v1654_6,v1654_7_head);
          const Space v1657_11 = routine_268(c, v1657_6, v1654_7_tail, s1);
          v1655_12 = compose(v1655_10,v1657_11);
        }
        const Space v1655_13 = unite(v1655_8,v1655_12);
        v1654_7_result = unite(v1654_7_result,v1655_13);
      }
      const Space v1654_7 = std::move(v1654_7_result);
      v1653_8 = compose(v1653_5,v1654_7);
    }
    const Space v1653_9 = intersect(constant_8,v1653_2);
    const Space v1653_10 = (has_head(v1653_9) ? constant_9 : Space{});
    Space v1653_12;
    if (!v1653_10.empty()) {
      const Path v1658_6 = concat_path(p0,v1652_9_head);
      const Space v1658_11 = routine_186(c, v1658_6, s1);
      v1653_12 = compose(v1653_10,v1658_11);
    }
    const Space v1653_13 = unite(v1653_8,v1653_12);
    v1652_9_result = unite(v1652_9_result,v1653_13);
  }
  const Space v1652_9 = std::move(v1652_9_result);
  return v1652_9;
}

static Space routine_186(Context& c, const Path& p0, const Space& s0) {
  const Space v1659_3 = singleton(p0);
  const Space v1659_4 = intersect(constant_10,v1659_3);
  const Space v1659_6 = unwrap(s0,constant_22);
  const Space v1659_8 = unwrap(s0,constant_23);
  const Space v1659_9 = compose(v1659_6,v1659_8);
  const Space v1659_11 = unwrap(s0,constant_6);
  const Space v1659_12 = compose(v1659_9,v1659_11);
  const Space v1659_13 = compose(v1659_4,v1659_12);
  const Space v1659_15 = intersect(constant_11,v1659_3);
  const Space v1659_16 = compose(v1659_6,v1659_11);
  const Space v1659_18 = unwrap(s0,constant_24);
  const Space v1659_19 = compose(v1659_16,v1659_18);
  const Space v1659_20 = compose(v1659_15,v1659_19);
  const Space v1659_21 = unite(v1659_13,v1659_20);
  const Space v1659_23 = intersect(constant_12,v1659_3);
  const Space v1659_24 = compose(v1659_8,v1659_11);
  const Space v1659_25 = compose(v1659_24,v1659_18);
  const Space v1659_26 = compose(v1659_23,v1659_25);
  const Space v1659_27 = unite(v1659_21,v1659_26);
  const Space v1659_29 = intersect(constant_13,v1659_3);
  const Space v1659_30 = compose(v1659_9,v1659_18);
  const Space v1659_31 = compose(v1659_29,v1659_30);
  const Space v1659_32 = unite(v1659_27,v1659_31);
  return v1659_32;
}

static Space routine_187(Context& c, const Path& p0, const Space& s0) {
  const Space v1660_2 = Space{};
  return v1660_2;
}

static Space routine_188(Context& c, const Path& p0, const Space& s0) {
  Space v1661_3_result;
  for (int v1661_3_label = 1; v1661_3_label <= 2; ++v1661_3_label) {
    const Space v1661_3_tail = child(s0,v1661_3_label);
    if (v1661_3_tail.empty()) continue;
    const Path v1661_3_head{v1661_3_label};
    const Space v1662_2 = singleton(v1661_3_head);
    const Space v1662_3 = intersect(constant_8,v1662_2);
    const Space v1662_4 = (has_head(v1662_3) ? constant_9 : Space{});
    const Space v1662_5 = compose(v1662_4,v1661_3_tail);
    v1661_3_result = unite(v1661_3_result,v1662_5);
  }
  const Space v1661_3 = std::move(v1661_3_result);
  return v1661_3;
}

static Space routine_189(Context& c, const Path& p0, const Space& s0) {
  const Space v1663_2 = Space{};
  return v1663_2;
}

static Space routine_190(Context& c, const Path& p0, const Space& s0) {
  Space v1664_6_result;
  for (int v1664_6_label = 1; v1664_6_label <= 2; ++v1664_6_label) {
    const Space v1664_6_tail = child(s0,v1664_6_label);
    if (v1664_6_tail.empty()) continue;
    const Path v1664_6_head{v1664_6_label};
    const Space v1665_2 = singleton(v1664_6_head);
    const Space v1665_3 = intersect(constant_8,v1665_2);
    const Space v1665_4 = (has_head(v1665_3) ? constant_9 : Space{});
    Space v1665_7;
    if (!v1665_4.empty()) {
      const Path v1666_5 = concat_path(p0,v1664_6_head);
      Space v1666_6_result;
      for (int v1666_6_label = 1; v1666_6_label <= 2; ++v1666_6_label) {
        const Space v1666_6_tail = child(v1664_6_tail,v1666_6_label);
        if (v1666_6_tail.empty()) continue;
        const Path v1666_6_head{v1666_6_label};
        const Space v1667_2 = singleton(v1666_6_head);
        const Space v1667_3 = intersect(constant_8,v1667_2);
        const Space v1667_4 = (has_head(v1667_3) ? constant_9 : Space{});
        const Space v1667_5 = subtract(constant_0,v1667_4);
        Space v1667_7;
        if (!v1667_5.empty()) {
          const Space v1668_6 = routine_106(c, v1666_6_head, v1666_5, v1666_6_tail);
          v1667_7 = compose(v1667_5,v1668_6);
        }
        const Space v1667_8 = intersect(constant_8,v1667_2);
        const Space v1667_9 = (has_head(v1667_8) ? constant_9 : Space{});
        Space v1667_11;
        if (!v1667_9.empty()) {
          const Space v1669_10 = routine_107(c, v1666_6_head, v1666_5, v1666_6_tail);
          v1667_11 = compose(v1667_9,v1669_10);
        }
        const Space v1667_12 = unite(v1667_7,v1667_11);
        v1666_6_result = unite(v1666_6_result,v1667_12);
      }
      const Space v1666_6 = std::move(v1666_6_result);
      v1665_7 = compose(v1665_4,v1666_6);
    }
    v1664_6_result = unite(v1664_6_result,v1665_7);
  }
  const Space v1664_6 = std::move(v1664_6_result);
  return v1664_6;
}

static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1670_12_result;
  for (int v1670_12_label = 1; v1670_12_label <= 2; ++v1670_12_label) {
    const Space v1670_12_tail = child(s0,v1670_12_label);
    if (v1670_12_tail.empty()) continue;
    const Path v1670_12_head{v1670_12_label};
    const Space v1671_2 = singleton(v1670_12_head);
    const Space v1671_3 = intersect(constant_8,v1671_2);
    const Space v1671_4 = (has_head(v1671_3) ? constant_9 : Space{});
    const Space v1671_5 = subtract(constant_0,v1671_4);
    Space v1671_8;
    if (!v1671_5.empty()) {
      const Path v1672_6 = concat_path(p0,v1670_12_head);
      Space v1672_7_result;
      for (int v1672_7_label = 1; v1672_7_label <= 2; ++v1672_7_label) {
        const Space v1672_7_tail = child(v1670_12_tail,v1672_7_label);
        if (v1672_7_tail.empty()) continue;
        const Path v1672_7_head{v1672_7_label};
        const Space v1673_2 = singleton(v1672_7_head);
        const Space v1673_3 = intersect(constant_8,v1673_2);
        const Space v1673_4 = (has_head(v1673_3) ? constant_9 : Space{});
        const Space v1673_5 = subtract(constant_0,v1673_4);
        Space v1673_8;
        if (!v1673_5.empty()) {
          const Path v1674_6 = concat_path(v1672_6,v1672_7_head);
          const Space v1674_7 = routine_269(c, v1674_6, p1, v1672_7_tail);
          v1673_8 = compose(v1673_5,v1674_7);
        }
        const Space v1673_9 = intersect(constant_8,v1673_2);
        const Space v1673_10 = (has_head(v1673_9) ? constant_9 : Space{});
        Space v1673_12;
        if (!v1673_10.empty()) {
          const Path v1675_6 = concat_path(v1672_6,v1672_7_head);
          const Space v1675_11 = routine_270(c, v1675_6, p1, v1672_7_tail);
          v1673_12 = compose(v1673_10,v1675_11);
        }
        const Space v1673_13 = unite(v1673_8,v1673_12);
        v1672_7_result = unite(v1672_7_result,v1673_13);
      }
      const Space v1672_7 = std::move(v1672_7_result);
      v1671_8 = compose(v1671_5,v1672_7);
    }
    const Space v1671_9 = intersect(constant_8,v1671_2);
    const Space v1671_10 = (has_head(v1671_9) ? constant_9 : Space{});
    Space v1671_12;
    if (!v1671_10.empty()) {
      const Path v1676_6 = concat_path(p0,v1670_12_head);
      Space v1676_11_result;
      for (int v1676_11_label = 1; v1676_11_label <= 2; ++v1676_11_label) {
        const Space v1676_11_tail = child(v1670_12_tail,v1676_11_label);
        if (v1676_11_tail.empty()) continue;
        const Path v1676_11_head{v1676_11_label};
        const Space v1677_2 = singleton(v1676_11_head);
        const Space v1677_3 = intersect(constant_8,v1677_2);
        const Space v1677_4 = (has_head(v1677_3) ? constant_9 : Space{});
        const Space v1677_5 = subtract(constant_0,v1677_4);
        Space v1677_8;
        if (!v1677_5.empty()) {
          const Path v1678_6 = concat_path(v1676_6,v1676_11_head);
          const Space v1678_7 = routine_269(c, v1678_6, p1, v1676_11_tail);
          v1677_8 = compose(v1677_5,v1678_7);
        }
        const Space v1677_9 = intersect(constant_8,v1677_2);
        const Space v1677_10 = (has_head(v1677_9) ? constant_9 : Space{});
        Space v1677_12;
        if (!v1677_10.empty()) {
          const Path v1679_6 = concat_path(v1676_6,v1676_11_head);
          const Space v1679_11 = routine_148(c, v1679_6, p1, v1676_11_tail);
          v1677_12 = compose(v1677_10,v1679_11);
        }
        const Space v1677_13 = unite(v1677_8,v1677_12);
        v1676_11_result = unite(v1676_11_result,v1677_13);
      }
      const Space v1676_11 = std::move(v1676_11_result);
      v1671_12 = compose(v1671_10,v1676_11);
    }
    const Space v1671_13 = unite(v1671_8,v1671_12);
    v1670_12_result = unite(v1670_12_result,v1671_13);
  }
  const Space v1670_12 = std::move(v1670_12_result);
  return v1670_12;
}

static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1680_12_result;
  for (int v1680_12_label = 1; v1680_12_label <= 2; ++v1680_12_label) {
    const Space v1680_12_tail = child(s0,v1680_12_label);
    if (v1680_12_tail.empty()) continue;
    const Path v1680_12_head{v1680_12_label};
    const Space v1681_2 = singleton(v1680_12_head);
    const Space v1681_3 = intersect(constant_8,v1681_2);
    const Space v1681_4 = (has_head(v1681_3) ? constant_9 : Space{});
    const Space v1681_5 = subtract(constant_0,v1681_4);
    Space v1681_8;
    if (!v1681_5.empty()) {
      const Path v1682_6 = concat_path(p0,v1680_12_head);
      Space v1682_7_result;
      for (int v1682_7_label = 1; v1682_7_label <= 2; ++v1682_7_label) {
        const Space v1682_7_tail = child(v1680_12_tail,v1682_7_label);
        if (v1682_7_tail.empty()) continue;
        const Path v1682_7_head{v1682_7_label};
        const Space v1683_2 = singleton(v1682_7_head);
        const Space v1683_3 = intersect(constant_8,v1683_2);
        const Space v1683_4 = (has_head(v1683_3) ? constant_9 : Space{});
        const Space v1683_5 = subtract(constant_0,v1683_4);
        Space v1683_8;
        if (!v1683_5.empty()) {
          const Path v1684_6 = concat_path(v1682_6,v1682_7_head);
          const Space v1684_7 = routine_269(c, v1684_6, p1, v1682_7_tail);
          v1683_8 = compose(v1683_5,v1684_7);
        }
        const Space v1683_9 = intersect(constant_8,v1683_2);
        const Space v1683_10 = (has_head(v1683_9) ? constant_9 : Space{});
        Space v1683_12;
        if (!v1683_10.empty()) {
          const Path v1685_6 = concat_path(v1682_6,v1682_7_head);
          const Space v1685_11 = routine_270(c, v1685_6, p1, v1682_7_tail);
          v1683_12 = compose(v1683_10,v1685_11);
        }
        const Space v1683_13 = unite(v1683_8,v1683_12);
        v1682_7_result = unite(v1682_7_result,v1683_13);
      }
      const Space v1682_7 = std::move(v1682_7_result);
      v1681_8 = compose(v1681_5,v1682_7);
    }
    const Space v1681_9 = intersect(constant_8,v1681_2);
    const Space v1681_10 = (has_head(v1681_9) ? constant_9 : Space{});
    Space v1681_12;
    if (!v1681_10.empty()) {
      const Path v1686_6 = concat_path(p0,v1680_12_head);
      Space v1686_11_result;
      for (int v1686_11_label = 1; v1686_11_label <= 2; ++v1686_11_label) {
        const Space v1686_11_tail = child(v1680_12_tail,v1686_11_label);
        if (v1686_11_tail.empty()) continue;
        const Path v1686_11_head{v1686_11_label};
        const Space v1687_2 = singleton(v1686_11_head);
        const Space v1687_3 = intersect(constant_8,v1687_2);
        const Space v1687_4 = (has_head(v1687_3) ? constant_9 : Space{});
        const Space v1687_5 = subtract(constant_0,v1687_4);
        Space v1687_7;
        if (!v1687_5.empty()) {
          const Space v1688_6 = routine_193(c, v1686_11_head, p1, v1686_6, v1686_11_tail);
          v1687_7 = compose(v1687_5,v1688_6);
        }
        const Space v1687_8 = intersect(constant_8,v1687_2);
        const Space v1687_9 = (has_head(v1687_8) ? constant_9 : Space{});
        Space v1687_11;
        if (!v1687_9.empty()) {
          const Space v1689_10 = routine_194(c, v1686_11_head, p1, v1686_6, v1686_11_tail);
          v1687_11 = compose(v1687_9,v1689_10);
        }
        const Space v1687_12 = unite(v1687_7,v1687_11);
        v1686_11_result = unite(v1686_11_result,v1687_12);
      }
      const Space v1686_11 = std::move(v1686_11_result);
      v1681_12 = compose(v1681_10,v1686_11);
    }
    const Space v1681_13 = unite(v1681_8,v1681_12);
    v1680_12_result = unite(v1680_12_result,v1681_13);
  }
  const Space v1680_12 = std::move(v1680_12_result);
  return v1680_12;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1690_13_result;
  for (int v1690_13_label = 1; v1690_13_label <= 2; ++v1690_13_label) {
    const Space v1690_13_tail = child(s0,v1690_13_label);
    if (v1690_13_tail.empty()) continue;
    const Path v1690_13_head{v1690_13_label};
    const Space v1691_2 = singleton(v1690_13_head);
    const Space v1691_3 = intersect(constant_8,v1691_2);
    const Space v1691_4 = (has_head(v1691_3) ? constant_9 : Space{});
    const Space v1691_5 = subtract(constant_0,v1691_4);
    Space v1691_8;
    if (!v1691_5.empty()) {
      const Path v1692_6 = concat_path(p0,v1690_13_head);
      Space v1692_7_result;
      for (int v1692_7_label = 1; v1692_7_label <= 2; ++v1692_7_label) {
        const Space v1692_7_tail = child(v1690_13_tail,v1692_7_label);
        if (v1692_7_tail.empty()) continue;
        const Path v1692_7_head{v1692_7_label};
        const Space v1693_2 = singleton(v1692_7_head);
        const Space v1693_3 = intersect(constant_8,v1693_2);
        const Space v1693_4 = (has_head(v1693_3) ? constant_9 : Space{});
        const Space v1693_5 = subtract(constant_0,v1693_4);
        Space v1693_8;
        if (!v1693_5.empty()) {
          const Path v1694_6 = concat_path(v1692_6,v1692_7_head);
          const Space v1694_7 = routine_271(c, v1694_6, p1, p2, v1692_7_tail);
          v1693_8 = compose(v1693_5,v1694_7);
        }
        const Space v1693_9 = intersect(constant_8,v1693_2);
        const Space v1693_10 = (has_head(v1693_9) ? constant_9 : Space{});
        Space v1693_12;
        if (!v1693_10.empty()) {
          const Path v1695_6 = concat_path(v1692_6,v1692_7_head);
          const Space v1695_11 = routine_272(c, v1695_6, p1, p2, v1692_7_tail);
          v1693_12 = compose(v1693_10,v1695_11);
        }
        const Space v1693_13 = unite(v1693_8,v1693_12);
        v1692_7_result = unite(v1692_7_result,v1693_13);
      }
      const Space v1692_7 = std::move(v1692_7_result);
      v1691_8 = compose(v1691_5,v1692_7);
    }
    const Space v1691_9 = intersect(constant_8,v1691_2);
    const Space v1691_10 = (has_head(v1691_9) ? constant_9 : Space{});
    Space v1691_12;
    if (!v1691_10.empty()) {
      const Path v1696_6 = concat_path(p0,v1690_13_head);
      Space v1696_11_result;
      for (int v1696_11_label = 1; v1696_11_label <= 2; ++v1696_11_label) {
        const Space v1696_11_tail = child(v1690_13_tail,v1696_11_label);
        if (v1696_11_tail.empty()) continue;
        const Path v1696_11_head{v1696_11_label};
        const Space v1697_2 = singleton(v1696_11_head);
        const Space v1697_3 = intersect(constant_8,v1697_2);
        const Space v1697_4 = (has_head(v1697_3) ? constant_9 : Space{});
        const Space v1697_5 = subtract(constant_0,v1697_4);
        Space v1697_8;
        if (!v1697_5.empty()) {
          const Path v1698_6 = concat_path(v1696_6,v1696_11_head);
          const Space v1698_7 = routine_271(c, v1698_6, p1, p2, v1696_11_tail);
          v1697_8 = compose(v1697_5,v1698_7);
        }
        const Space v1697_9 = intersect(constant_8,v1697_2);
        const Space v1697_10 = (has_head(v1697_9) ? constant_9 : Space{});
        Space v1697_12;
        if (!v1697_10.empty()) {
          const Path v1699_6 = concat_path(v1696_6,v1696_11_head);
          const Space v1699_11 = routine_237(c, v1699_6, p1, p2, v1696_11_tail);
          v1697_12 = compose(v1697_10,v1699_11);
        }
        const Space v1697_13 = unite(v1697_8,v1697_12);
        v1696_11_result = unite(v1696_11_result,v1697_13);
      }
      const Space v1696_11 = std::move(v1696_11_result);
      v1691_12 = compose(v1691_10,v1696_11);
    }
    const Space v1691_13 = unite(v1691_8,v1691_12);
    v1690_13_result = unite(v1690_13_result,v1691_13);
  }
  const Space v1690_13 = std::move(v1690_13_result);
  return v1690_13;
}

static Space routine_194(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1700_9 = concat_path(constant_23,p2);
  const Space v1700_10 = singleton(v1700_9);
  const Space v1700_11 = unite(constant_26,v1700_10);
  const Path v1700_13 = concat_path(constant_22,p1);
  const Space v1700_14 = singleton(v1700_13);
  const Space v1700_15 = unite(v1700_11,v1700_14);
  Space v1700_20_result;
  for (int v1700_20_label = 1; v1700_20_label <= 2; ++v1700_20_label) {
    const Space v1700_20_tail = child(s0,v1700_20_label);
    if (v1700_20_tail.empty()) continue;
    const Path v1700_20_head{v1700_20_label};
    const Space v1701_2 = singleton(v1700_20_head);
    const Space v1701_3 = intersect(constant_8,v1701_2);
    const Space v1701_4 = (has_head(v1701_3) ? constant_9 : Space{});
    const Space v1701_5 = subtract(constant_0,v1701_4);
    Space v1701_8;
    if (!v1701_5.empty()) {
      const Path v1702_6 = concat_path(p0,v1700_20_head);
      Space v1702_7_result;
      for (int v1702_7_label = 1; v1702_7_label <= 2; ++v1702_7_label) {
        const Space v1702_7_tail = child(v1700_20_tail,v1702_7_label);
        if (v1702_7_tail.empty()) continue;
        const Path v1702_7_head{v1702_7_label};
        const Space v1703_2 = singleton(v1702_7_head);
        const Space v1703_3 = intersect(constant_8,v1703_2);
        const Space v1703_4 = (has_head(v1703_3) ? constant_9 : Space{});
        const Space v1703_5 = subtract(constant_0,v1703_4);
        Space v1703_8;
        if (!v1703_5.empty()) {
          const Path v1704_6 = concat_path(v1702_6,v1702_7_head);
          const Space v1704_7 = routine_271(c, v1704_6, p1, p2, v1702_7_tail);
          v1703_8 = compose(v1703_5,v1704_7);
        }
        const Space v1703_9 = intersect(constant_8,v1703_2);
        const Space v1703_10 = (has_head(v1703_9) ? constant_9 : Space{});
        Space v1703_12;
        if (!v1703_10.empty()) {
          const Path v1705_6 = concat_path(v1702_6,v1702_7_head);
          const Space v1705_11 = routine_272(c, v1705_6, p1, p2, v1702_7_tail);
          v1703_12 = compose(v1703_10,v1705_11);
        }
        const Space v1703_13 = unite(v1703_8,v1703_12);
        v1702_7_result = unite(v1702_7_result,v1703_13);
      }
      const Space v1702_7 = std::move(v1702_7_result);
      v1701_8 = compose(v1701_5,v1702_7);
    }
    const Space v1701_9 = intersect(constant_8,v1701_2);
    const Space v1701_10 = (has_head(v1701_9) ? constant_9 : Space{});
    const Path v1706_6 = concat_path(p0,v1700_20_head);
    const Path v1701_11 = concat_path(constant_6,v1706_6);
    const Space v1701_12 = singleton(v1701_11);
    const Space v1701_13 = unite(v1700_15,v1701_12);
    const Space v1701_14 = compose(v1701_10,v1701_13);
    const Space v1701_15 = unite(v1701_8,v1701_14);
    v1700_20_result = unite(v1700_20_result,v1701_15);
  }
  const Space v1700_20 = std::move(v1700_20_result);
  return v1700_20;
}

static Space routine_195(Context& c, const Path& p0, const Space& s0) {
  const Space v1707_2 = Space{};
  return v1707_2;
}

static Space routine_196(Context& c, const Path& p0, const Space& s0) {
  Space v1708_3_result;
  for (int v1708_3_label = 1; v1708_3_label <= 2; ++v1708_3_label) {
    const Space v1708_3_tail = child(s0,v1708_3_label);
    if (v1708_3_tail.empty()) continue;
    const Path v1708_3_head{v1708_3_label};
    const Space v1709_2 = singleton(v1708_3_head);
    const Space v1709_3 = intersect(constant_8,v1709_2);
    const Space v1709_4 = (has_head(v1709_3) ? constant_9 : Space{});
    const Space v1709_5 = compose(v1709_4,v1708_3_tail);
    v1708_3_result = unite(v1708_3_result,v1709_5);
  }
  const Space v1708_3 = std::move(v1708_3_result);
  return v1708_3;
}

static Space routine_197(Context& c, const Path& p0, const Space& s0) {
  const Space v1710_2 = Space{};
  return v1710_2;
}

static Space routine_198(Context& c, const Path& p0, const Space& s0) {
  Space v1711_6_result;
  for (int v1711_6_label = 1; v1711_6_label <= 2; ++v1711_6_label) {
    const Space v1711_6_tail = child(s0,v1711_6_label);
    if (v1711_6_tail.empty()) continue;
    const Path v1711_6_head{v1711_6_label};
    const Space v1712_2 = singleton(v1711_6_head);
    const Space v1712_3 = intersect(constant_8,v1712_2);
    const Space v1712_4 = (has_head(v1712_3) ? constant_9 : Space{});
    Space v1712_7;
    if (!v1712_4.empty()) {
      const Path v1713_5 = concat_path(p0,v1711_6_head);
      Space v1713_6_result;
      for (int v1713_6_label = 1; v1713_6_label <= 2; ++v1713_6_label) {
        const Space v1713_6_tail = child(v1711_6_tail,v1713_6_label);
        if (v1713_6_tail.empty()) continue;
        const Path v1713_6_head{v1713_6_label};
        const Space v1714_2 = singleton(v1713_6_head);
        const Space v1714_3 = intersect(constant_8,v1714_2);
        const Space v1714_4 = (has_head(v1714_3) ? constant_9 : Space{});
        const Space v1714_5 = subtract(constant_0,v1714_4);
        Space v1714_7;
        if (!v1714_5.empty()) {
          const Space v1715_6 = routine_112(c, v1713_6_head, v1713_5, v1713_6_tail);
          v1714_7 = compose(v1714_5,v1715_6);
        }
        const Space v1714_8 = intersect(constant_8,v1714_2);
        const Space v1714_9 = (has_head(v1714_8) ? constant_9 : Space{});
        Space v1714_11;
        if (!v1714_9.empty()) {
          const Space v1716_10 = routine_113(c, v1713_6_head, v1713_5, v1713_6_tail);
          v1714_11 = compose(v1714_9,v1716_10);
        }
        const Space v1714_12 = unite(v1714_7,v1714_11);
        v1713_6_result = unite(v1713_6_result,v1714_12);
      }
      const Space v1713_6 = std::move(v1713_6_result);
      v1712_7 = compose(v1712_4,v1713_6);
    }
    v1711_6_result = unite(v1711_6_result,v1712_7);
  }
  const Space v1711_6 = std::move(v1711_6_result);
  return v1711_6;
}

static Space routine_199(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1717_12_result;
  for (int v1717_12_label = 1; v1717_12_label <= 2; ++v1717_12_label) {
    const Space v1717_12_tail = child(s0,v1717_12_label);
    if (v1717_12_tail.empty()) continue;
    const Path v1717_12_head{v1717_12_label};
    const Space v1718_2 = singleton(v1717_12_head);
    const Space v1718_3 = intersect(constant_8,v1718_2);
    const Space v1718_4 = (has_head(v1718_3) ? constant_9 : Space{});
    const Space v1718_5 = subtract(constant_0,v1718_4);
    Space v1718_8;
    if (!v1718_5.empty()) {
      const Path v1719_6 = concat_path(p0,v1717_12_head);
      Space v1719_7_result;
      for (int v1719_7_label = 1; v1719_7_label <= 2; ++v1719_7_label) {
        const Space v1719_7_tail = child(v1717_12_tail,v1719_7_label);
        if (v1719_7_tail.empty()) continue;
        const Path v1719_7_head{v1719_7_label};
        const Space v1720_2 = singleton(v1719_7_head);
        const Space v1720_3 = intersect(constant_8,v1720_2);
        const Space v1720_4 = (has_head(v1720_3) ? constant_9 : Space{});
        const Space v1720_5 = subtract(constant_0,v1720_4);
        Space v1720_8;
        if (!v1720_5.empty()) {
          const Path v1721_6 = concat_path(v1719_6,v1719_7_head);
          const Space v1721_7 = routine_273(c, v1721_6, p1, v1719_7_tail);
          v1720_8 = compose(v1720_5,v1721_7);
        }
        const Space v1720_9 = intersect(constant_8,v1720_2);
        const Space v1720_10 = (has_head(v1720_9) ? constant_9 : Space{});
        Space v1720_12;
        if (!v1720_10.empty()) {
          const Path v1722_6 = concat_path(v1719_6,v1719_7_head);
          const Space v1722_11 = routine_274(c, v1722_6, p1, v1719_7_tail);
          v1720_12 = compose(v1720_10,v1722_11);
        }
        const Space v1720_13 = unite(v1720_8,v1720_12);
        v1719_7_result = unite(v1719_7_result,v1720_13);
      }
      const Space v1719_7 = std::move(v1719_7_result);
      v1718_8 = compose(v1718_5,v1719_7);
    }
    const Space v1718_9 = intersect(constant_8,v1718_2);
    const Space v1718_10 = (has_head(v1718_9) ? constant_9 : Space{});
    Space v1718_12;
    if (!v1718_10.empty()) {
      const Path v1723_6 = concat_path(p0,v1717_12_head);
      Space v1723_11_result;
      for (int v1723_11_label = 1; v1723_11_label <= 2; ++v1723_11_label) {
        const Space v1723_11_tail = child(v1717_12_tail,v1723_11_label);
        if (v1723_11_tail.empty()) continue;
        const Path v1723_11_head{v1723_11_label};
        const Space v1724_2 = singleton(v1723_11_head);
        const Space v1724_3 = intersect(constant_8,v1724_2);
        const Space v1724_4 = (has_head(v1724_3) ? constant_9 : Space{});
        const Space v1724_5 = subtract(constant_0,v1724_4);
        Space v1724_8;
        if (!v1724_5.empty()) {
          const Path v1725_6 = concat_path(v1723_6,v1723_11_head);
          const Space v1725_7 = routine_273(c, v1725_6, p1, v1723_11_tail);
          v1724_8 = compose(v1724_5,v1725_7);
        }
        const Space v1724_9 = intersect(constant_8,v1724_2);
        const Space v1724_10 = (has_head(v1724_9) ? constant_9 : Space{});
        Space v1724_12;
        if (!v1724_10.empty()) {
          const Path v1726_6 = concat_path(v1723_6,v1723_11_head);
          const Space v1726_11 = routine_155(c, v1726_6, p1, v1723_11_tail);
          v1724_12 = compose(v1724_10,v1726_11);
        }
        const Space v1724_13 = unite(v1724_8,v1724_12);
        v1723_11_result = unite(v1723_11_result,v1724_13);
      }
      const Space v1723_11 = std::move(v1723_11_result);
      v1718_12 = compose(v1718_10,v1723_11);
    }
    const Space v1718_13 = unite(v1718_8,v1718_12);
    v1717_12_result = unite(v1717_12_result,v1718_13);
  }
  const Space v1717_12 = std::move(v1717_12_result);
  return v1717_12;
}

static Space routine_200(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1727_12_result;
  for (int v1727_12_label = 1; v1727_12_label <= 2; ++v1727_12_label) {
    const Space v1727_12_tail = child(s0,v1727_12_label);
    if (v1727_12_tail.empty()) continue;
    const Path v1727_12_head{v1727_12_label};
    const Space v1728_2 = singleton(v1727_12_head);
    const Space v1728_3 = intersect(constant_8,v1728_2);
    const Space v1728_4 = (has_head(v1728_3) ? constant_9 : Space{});
    const Space v1728_5 = subtract(constant_0,v1728_4);
    Space v1728_8;
    if (!v1728_5.empty()) {
      const Path v1729_6 = concat_path(p0,v1727_12_head);
      Space v1729_7_result;
      for (int v1729_7_label = 1; v1729_7_label <= 2; ++v1729_7_label) {
        const Space v1729_7_tail = child(v1727_12_tail,v1729_7_label);
        if (v1729_7_tail.empty()) continue;
        const Path v1729_7_head{v1729_7_label};
        const Space v1730_2 = singleton(v1729_7_head);
        const Space v1730_3 = intersect(constant_8,v1730_2);
        const Space v1730_4 = (has_head(v1730_3) ? constant_9 : Space{});
        const Space v1730_5 = subtract(constant_0,v1730_4);
        Space v1730_8;
        if (!v1730_5.empty()) {
          const Path v1731_6 = concat_path(v1729_6,v1729_7_head);
          const Space v1731_7 = routine_273(c, v1731_6, p1, v1729_7_tail);
          v1730_8 = compose(v1730_5,v1731_7);
        }
        const Space v1730_9 = intersect(constant_8,v1730_2);
        const Space v1730_10 = (has_head(v1730_9) ? constant_9 : Space{});
        Space v1730_12;
        if (!v1730_10.empty()) {
          const Path v1732_6 = concat_path(v1729_6,v1729_7_head);
          const Space v1732_11 = routine_274(c, v1732_6, p1, v1729_7_tail);
          v1730_12 = compose(v1730_10,v1732_11);
        }
        const Space v1730_13 = unite(v1730_8,v1730_12);
        v1729_7_result = unite(v1729_7_result,v1730_13);
      }
      const Space v1729_7 = std::move(v1729_7_result);
      v1728_8 = compose(v1728_5,v1729_7);
    }
    const Space v1728_9 = intersect(constant_8,v1728_2);
    const Space v1728_10 = (has_head(v1728_9) ? constant_9 : Space{});
    Space v1728_12;
    if (!v1728_10.empty()) {
      const Path v1733_6 = concat_path(p0,v1727_12_head);
      Space v1733_11_result;
      for (int v1733_11_label = 1; v1733_11_label <= 2; ++v1733_11_label) {
        const Space v1733_11_tail = child(v1727_12_tail,v1733_11_label);
        if (v1733_11_tail.empty()) continue;
        const Path v1733_11_head{v1733_11_label};
        const Space v1734_2 = singleton(v1733_11_head);
        const Space v1734_3 = intersect(constant_8,v1734_2);
        const Space v1734_4 = (has_head(v1734_3) ? constant_9 : Space{});
        const Space v1734_5 = subtract(constant_0,v1734_4);
        Space v1734_7;
        if (!v1734_5.empty()) {
          const Space v1735_6 = routine_201(c, v1733_11_head, p1, v1733_6, v1733_11_tail);
          v1734_7 = compose(v1734_5,v1735_6);
        }
        const Space v1734_8 = intersect(constant_8,v1734_2);
        const Space v1734_9 = (has_head(v1734_8) ? constant_9 : Space{});
        Space v1734_11;
        if (!v1734_9.empty()) {
          const Space v1736_10 = routine_202(c, v1733_11_head, p1, v1733_6, v1733_11_tail);
          v1734_11 = compose(v1734_9,v1736_10);
        }
        const Space v1734_12 = unite(v1734_7,v1734_11);
        v1733_11_result = unite(v1733_11_result,v1734_12);
      }
      const Space v1733_11 = std::move(v1733_11_result);
      v1728_12 = compose(v1728_10,v1733_11);
    }
    const Space v1728_13 = unite(v1728_8,v1728_12);
    v1727_12_result = unite(v1727_12_result,v1728_13);
  }
  const Space v1727_12 = std::move(v1727_12_result);
  return v1727_12;
}

static Space routine_201(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1737_13_result;
  for (int v1737_13_label = 1; v1737_13_label <= 2; ++v1737_13_label) {
    const Space v1737_13_tail = child(s0,v1737_13_label);
    if (v1737_13_tail.empty()) continue;
    const Path v1737_13_head{v1737_13_label};
    const Space v1738_2 = singleton(v1737_13_head);
    const Space v1738_3 = intersect(constant_8,v1738_2);
    const Space v1738_4 = (has_head(v1738_3) ? constant_9 : Space{});
    const Space v1738_5 = subtract(constant_0,v1738_4);
    Space v1738_8;
    if (!v1738_5.empty()) {
      const Path v1739_6 = concat_path(p0,v1737_13_head);
      Space v1739_7_result;
      for (int v1739_7_label = 1; v1739_7_label <= 2; ++v1739_7_label) {
        const Space v1739_7_tail = child(v1737_13_tail,v1739_7_label);
        if (v1739_7_tail.empty()) continue;
        const Path v1739_7_head{v1739_7_label};
        const Space v1740_2 = singleton(v1739_7_head);
        const Space v1740_3 = intersect(constant_8,v1740_2);
        const Space v1740_4 = (has_head(v1740_3) ? constant_9 : Space{});
        const Space v1740_5 = subtract(constant_0,v1740_4);
        Space v1740_8;
        if (!v1740_5.empty()) {
          const Path v1741_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1741_7 = routine_275(c, v1741_6, p1, p2, v1739_7_tail);
          v1740_8 = compose(v1740_5,v1741_7);
        }
        const Space v1740_9 = intersect(constant_8,v1740_2);
        const Space v1740_10 = (has_head(v1740_9) ? constant_9 : Space{});
        Space v1740_12;
        if (!v1740_10.empty()) {
          const Path v1742_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1742_11 = routine_276(c, v1742_6, p1, p2, v1739_7_tail);
          v1740_12 = compose(v1740_10,v1742_11);
        }
        const Space v1740_13 = unite(v1740_8,v1740_12);
        v1739_7_result = unite(v1739_7_result,v1740_13);
      }
      const Space v1739_7 = std::move(v1739_7_result);
      v1738_8 = compose(v1738_5,v1739_7);
    }
    const Space v1738_9 = intersect(constant_8,v1738_2);
    const Space v1738_10 = (has_head(v1738_9) ? constant_9 : Space{});
    Space v1738_12;
    if (!v1738_10.empty()) {
      const Path v1743_6 = concat_path(p0,v1737_13_head);
      Space v1743_11_result;
      for (int v1743_11_label = 1; v1743_11_label <= 2; ++v1743_11_label) {
        const Space v1743_11_tail = child(v1737_13_tail,v1743_11_label);
        if (v1743_11_tail.empty()) continue;
        const Path v1743_11_head{v1743_11_label};
        const Space v1744_2 = singleton(v1743_11_head);
        const Space v1744_3 = intersect(constant_8,v1744_2);
        const Space v1744_4 = (has_head(v1744_3) ? constant_9 : Space{});
        const Space v1744_5 = subtract(constant_0,v1744_4);
        Space v1744_8;
        if (!v1744_5.empty()) {
          const Path v1745_6 = concat_path(v1743_6,v1743_11_head);
          const Space v1745_7 = routine_275(c, v1745_6, p1, p2, v1743_11_tail);
          v1744_8 = compose(v1744_5,v1745_7);
        }
        const Space v1744_9 = intersect(constant_8,v1744_2);
        const Space v1744_10 = (has_head(v1744_9) ? constant_9 : Space{});
        Space v1744_12;
        if (!v1744_10.empty()) {
          const Path v1746_6 = concat_path(v1743_6,v1743_11_head);
          const Space v1746_11 = routine_242(c, v1746_6, p1, p2, v1743_11_tail);
          v1744_12 = compose(v1744_10,v1746_11);
        }
        const Space v1744_13 = unite(v1744_8,v1744_12);
        v1743_11_result = unite(v1743_11_result,v1744_13);
      }
      const Space v1743_11 = std::move(v1743_11_result);
      v1738_12 = compose(v1738_10,v1743_11);
    }
    const Space v1738_13 = unite(v1738_8,v1738_12);
    v1737_13_result = unite(v1737_13_result,v1738_13);
  }
  const Space v1737_13 = std::move(v1737_13_result);
  return v1737_13;
}

static Space routine_202(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1747_10 = concat_path(constant_22,p1);
  const Space v1747_11 = singleton(v1747_10);
  const Path v1747_13 = concat_path(constant_6,p2);
  const Space v1747_14 = singleton(v1747_13);
  Space v1747_18_result;
  for (int v1747_18_label = 1; v1747_18_label <= 2; ++v1747_18_label) {
    const Space v1747_18_tail = child(s0,v1747_18_label);
    if (v1747_18_tail.empty()) continue;
    const Path v1747_18_head{v1747_18_label};
    const Space v1748_2 = singleton(v1747_18_head);
    const Space v1748_3 = intersect(constant_8,v1748_2);
    const Space v1748_4 = (has_head(v1748_3) ? constant_9 : Space{});
    const Space v1748_5 = subtract(constant_0,v1748_4);
    Space v1748_8;
    if (!v1748_5.empty()) {
      const Path v1749_6 = concat_path(p0,v1747_18_head);
      Space v1749_7_result;
      for (int v1749_7_label = 1; v1749_7_label <= 2; ++v1749_7_label) {
        const Space v1749_7_tail = child(v1747_18_tail,v1749_7_label);
        if (v1749_7_tail.empty()) continue;
        const Path v1749_7_head{v1749_7_label};
        const Space v1750_2 = singleton(v1749_7_head);
        const Space v1750_3 = intersect(constant_8,v1750_2);
        const Space v1750_4 = (has_head(v1750_3) ? constant_9 : Space{});
        const Space v1750_5 = subtract(constant_0,v1750_4);
        Space v1750_8;
        if (!v1750_5.empty()) {
          const Path v1751_6 = concat_path(v1749_6,v1749_7_head);
          const Space v1751_7 = routine_275(c, v1751_6, p1, p2, v1749_7_tail);
          v1750_8 = compose(v1750_5,v1751_7);
        }
        const Space v1750_9 = intersect(constant_8,v1750_2);
        const Space v1750_10 = (has_head(v1750_9) ? constant_9 : Space{});
        Space v1750_12;
        if (!v1750_10.empty()) {
          const Path v1752_6 = concat_path(v1749_6,v1749_7_head);
          const Space v1752_11 = routine_276(c, v1752_6, p1, p2, v1749_7_tail);
          v1750_12 = compose(v1750_10,v1752_11);
        }
        const Space v1750_13 = unite(v1750_8,v1750_12);
        v1749_7_result = unite(v1749_7_result,v1750_13);
      }
      const Space v1749_7 = std::move(v1749_7_result);
      v1748_8 = compose(v1748_5,v1749_7);
    }
    const Space v1748_9 = intersect(constant_8,v1748_2);
    const Space v1748_10 = (has_head(v1748_9) ? constant_9 : Space{});
    const Path v1753_6 = concat_path(p0,v1747_18_head);
    const Path v1748_11 = concat_path(constant_24,v1753_6);
    const Space v1748_12 = singleton(v1748_11);
    const Space v1748_13 = unite(constant_27,v1748_12);
    const Space v1748_14 = unite(v1748_13,v1747_11);
    const Space v1748_15 = unite(v1748_14,v1747_14);
    const Space v1748_16 = compose(v1748_10,v1748_15);
    const Space v1748_17 = unite(v1748_8,v1748_16);
    v1747_18_result = unite(v1747_18_result,v1748_17);
  }
  const Space v1747_18 = std::move(v1747_18_result);
  return v1747_18;
}

static Space routine_203(Context& c, const Path& p0, const Space& s0) {
  const Space v1754_2 = Space{};
  return v1754_2;
}

static Space routine_204(Context& c, const Path& p0, const Space& s0) {
  Space v1755_3_result;
  for (int v1755_3_label = 1; v1755_3_label <= 2; ++v1755_3_label) {
    const Space v1755_3_tail = child(s0,v1755_3_label);
    if (v1755_3_tail.empty()) continue;
    const Path v1755_3_head{v1755_3_label};
    const Space v1756_2 = singleton(v1755_3_head);
    const Space v1756_3 = intersect(constant_8,v1756_2);
    const Space v1756_4 = (has_head(v1756_3) ? constant_9 : Space{});
    const Space v1756_5 = compose(v1756_4,v1755_3_tail);
    v1755_3_result = unite(v1755_3_result,v1756_5);
  }
  const Space v1755_3 = std::move(v1755_3_result);
  return v1755_3;
}

static Space routine_205(Context& c, const Path& p0, const Space& s0) {
  const Space v1757_2 = Space{};
  return v1757_2;
}

static Space routine_206(Context& c, const Path& p0, const Space& s0) {
  Space v1758_6_result;
  for (int v1758_6_label = 1; v1758_6_label <= 2; ++v1758_6_label) {
    const Space v1758_6_tail = child(s0,v1758_6_label);
    if (v1758_6_tail.empty()) continue;
    const Path v1758_6_head{v1758_6_label};
    const Space v1759_2 = singleton(v1758_6_head);
    const Space v1759_3 = intersect(constant_8,v1759_2);
    const Space v1759_4 = (has_head(v1759_3) ? constant_9 : Space{});
    Space v1759_7;
    if (!v1759_4.empty()) {
      const Path v1760_5 = concat_path(p0,v1758_6_head);
      Space v1760_6_result;
      for (int v1760_6_label = 1; v1760_6_label <= 2; ++v1760_6_label) {
        const Space v1760_6_tail = child(v1758_6_tail,v1760_6_label);
        if (v1760_6_tail.empty()) continue;
        const Path v1760_6_head{v1760_6_label};
        const Space v1761_2 = singleton(v1760_6_head);
        const Space v1761_3 = intersect(constant_8,v1761_2);
        const Space v1761_4 = (has_head(v1761_3) ? constant_9 : Space{});
        const Space v1761_5 = subtract(constant_0,v1761_4);
        Space v1761_7;
        if (!v1761_5.empty()) {
          const Space v1762_6 = routine_118(c, v1760_6_head, v1760_5, v1760_6_tail);
          v1761_7 = compose(v1761_5,v1762_6);
        }
        const Space v1761_8 = intersect(constant_8,v1761_2);
        const Space v1761_9 = (has_head(v1761_8) ? constant_9 : Space{});
        Space v1761_11;
        if (!v1761_9.empty()) {
          const Space v1763_10 = routine_119(c, v1760_6_head, v1760_5, v1760_6_tail);
          v1761_11 = compose(v1761_9,v1763_10);
        }
        const Space v1761_12 = unite(v1761_7,v1761_11);
        v1760_6_result = unite(v1760_6_result,v1761_12);
      }
      const Space v1760_6 = std::move(v1760_6_result);
      v1759_7 = compose(v1759_4,v1760_6);
    }
    v1758_6_result = unite(v1758_6_result,v1759_7);
  }
  const Space v1758_6 = std::move(v1758_6_result);
  return v1758_6;
}

static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1764_12_result;
  for (int v1764_12_label = 1; v1764_12_label <= 2; ++v1764_12_label) {
    const Space v1764_12_tail = child(s0,v1764_12_label);
    if (v1764_12_tail.empty()) continue;
    const Path v1764_12_head{v1764_12_label};
    const Space v1765_2 = singleton(v1764_12_head);
    const Space v1765_3 = intersect(constant_8,v1765_2);
    const Space v1765_4 = (has_head(v1765_3) ? constant_9 : Space{});
    const Space v1765_5 = subtract(constant_0,v1765_4);
    Space v1765_8;
    if (!v1765_5.empty()) {
      const Path v1766_6 = concat_path(p0,v1764_12_head);
      Space v1766_7_result;
      for (int v1766_7_label = 1; v1766_7_label <= 2; ++v1766_7_label) {
        const Space v1766_7_tail = child(v1764_12_tail,v1766_7_label);
        if (v1766_7_tail.empty()) continue;
        const Path v1766_7_head{v1766_7_label};
        const Space v1767_2 = singleton(v1766_7_head);
        const Space v1767_3 = intersect(constant_8,v1767_2);
        const Space v1767_4 = (has_head(v1767_3) ? constant_9 : Space{});
        const Space v1767_5 = subtract(constant_0,v1767_4);
        Space v1767_8;
        if (!v1767_5.empty()) {
          const Path v1768_6 = concat_path(v1766_6,v1766_7_head);
          const Space v1768_7 = routine_277(c, v1768_6, p1, v1766_7_tail);
          v1767_8 = compose(v1767_5,v1768_7);
        }
        const Space v1767_9 = intersect(constant_8,v1767_2);
        const Space v1767_10 = (has_head(v1767_9) ? constant_9 : Space{});
        Space v1767_12;
        if (!v1767_10.empty()) {
          const Path v1769_6 = concat_path(v1766_6,v1766_7_head);
          const Space v1769_11 = routine_278(c, v1769_6, p1, v1766_7_tail);
          v1767_12 = compose(v1767_10,v1769_11);
        }
        const Space v1767_13 = unite(v1767_8,v1767_12);
        v1766_7_result = unite(v1766_7_result,v1767_13);
      }
      const Space v1766_7 = std::move(v1766_7_result);
      v1765_8 = compose(v1765_5,v1766_7);
    }
    const Space v1765_9 = intersect(constant_8,v1765_2);
    const Space v1765_10 = (has_head(v1765_9) ? constant_9 : Space{});
    Space v1765_12;
    if (!v1765_10.empty()) {
      const Path v1770_6 = concat_path(p0,v1764_12_head);
      Space v1770_11_result;
      for (int v1770_11_label = 1; v1770_11_label <= 2; ++v1770_11_label) {
        const Space v1770_11_tail = child(v1764_12_tail,v1770_11_label);
        if (v1770_11_tail.empty()) continue;
        const Path v1770_11_head{v1770_11_label};
        const Space v1771_2 = singleton(v1770_11_head);
        const Space v1771_3 = intersect(constant_8,v1771_2);
        const Space v1771_4 = (has_head(v1771_3) ? constant_9 : Space{});
        const Space v1771_5 = subtract(constant_0,v1771_4);
        Space v1771_8;
        if (!v1771_5.empty()) {
          const Path v1772_6 = concat_path(v1770_6,v1770_11_head);
          const Space v1772_7 = routine_277(c, v1772_6, p1, v1770_11_tail);
          v1771_8 = compose(v1771_5,v1772_7);
        }
        const Space v1771_9 = intersect(constant_8,v1771_2);
        const Space v1771_10 = (has_head(v1771_9) ? constant_9 : Space{});
        Space v1771_12;
        if (!v1771_10.empty()) {
          const Path v1773_6 = concat_path(v1770_6,v1770_11_head);
          const Space v1773_11 = routine_162(c, v1773_6, p1, v1770_11_tail);
          v1771_12 = compose(v1771_10,v1773_11);
        }
        const Space v1771_13 = unite(v1771_8,v1771_12);
        v1770_11_result = unite(v1770_11_result,v1771_13);
      }
      const Space v1770_11 = std::move(v1770_11_result);
      v1765_12 = compose(v1765_10,v1770_11);
    }
    const Space v1765_13 = unite(v1765_8,v1765_12);
    v1764_12_result = unite(v1764_12_result,v1765_13);
  }
  const Space v1764_12 = std::move(v1764_12_result);
  return v1764_12;
}

static Space routine_208(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1774_12_result;
  for (int v1774_12_label = 1; v1774_12_label <= 2; ++v1774_12_label) {
    const Space v1774_12_tail = child(s0,v1774_12_label);
    if (v1774_12_tail.empty()) continue;
    const Path v1774_12_head{v1774_12_label};
    const Space v1775_2 = singleton(v1774_12_head);
    const Space v1775_3 = intersect(constant_8,v1775_2);
    const Space v1775_4 = (has_head(v1775_3) ? constant_9 : Space{});
    const Space v1775_5 = subtract(constant_0,v1775_4);
    Space v1775_8;
    if (!v1775_5.empty()) {
      const Path v1776_6 = concat_path(p0,v1774_12_head);
      Space v1776_7_result;
      for (int v1776_7_label = 1; v1776_7_label <= 2; ++v1776_7_label) {
        const Space v1776_7_tail = child(v1774_12_tail,v1776_7_label);
        if (v1776_7_tail.empty()) continue;
        const Path v1776_7_head{v1776_7_label};
        const Space v1777_2 = singleton(v1776_7_head);
        const Space v1777_3 = intersect(constant_8,v1777_2);
        const Space v1777_4 = (has_head(v1777_3) ? constant_9 : Space{});
        const Space v1777_5 = subtract(constant_0,v1777_4);
        Space v1777_8;
        if (!v1777_5.empty()) {
          const Path v1778_6 = concat_path(v1776_6,v1776_7_head);
          const Space v1778_7 = routine_277(c, v1778_6, p1, v1776_7_tail);
          v1777_8 = compose(v1777_5,v1778_7);
        }
        const Space v1777_9 = intersect(constant_8,v1777_2);
        const Space v1777_10 = (has_head(v1777_9) ? constant_9 : Space{});
        Space v1777_12;
        if (!v1777_10.empty()) {
          const Path v1779_6 = concat_path(v1776_6,v1776_7_head);
          const Space v1779_11 = routine_278(c, v1779_6, p1, v1776_7_tail);
          v1777_12 = compose(v1777_10,v1779_11);
        }
        const Space v1777_13 = unite(v1777_8,v1777_12);
        v1776_7_result = unite(v1776_7_result,v1777_13);
      }
      const Space v1776_7 = std::move(v1776_7_result);
      v1775_8 = compose(v1775_5,v1776_7);
    }
    const Space v1775_9 = intersect(constant_8,v1775_2);
    const Space v1775_10 = (has_head(v1775_9) ? constant_9 : Space{});
    Space v1775_12;
    if (!v1775_10.empty()) {
      const Path v1780_6 = concat_path(p0,v1774_12_head);
      Space v1780_11_result;
      for (int v1780_11_label = 1; v1780_11_label <= 2; ++v1780_11_label) {
        const Space v1780_11_tail = child(v1774_12_tail,v1780_11_label);
        if (v1780_11_tail.empty()) continue;
        const Path v1780_11_head{v1780_11_label};
        const Space v1781_2 = singleton(v1780_11_head);
        const Space v1781_3 = intersect(constant_8,v1781_2);
        const Space v1781_4 = (has_head(v1781_3) ? constant_9 : Space{});
        const Space v1781_5 = subtract(constant_0,v1781_4);
        Space v1781_7;
        if (!v1781_5.empty()) {
          const Space v1782_6 = routine_209(c, v1780_11_head, p1, v1780_6, v1780_11_tail);
          v1781_7 = compose(v1781_5,v1782_6);
        }
        const Space v1781_8 = intersect(constant_8,v1781_2);
        const Space v1781_9 = (has_head(v1781_8) ? constant_9 : Space{});
        Space v1781_11;
        if (!v1781_9.empty()) {
          const Space v1783_10 = routine_210(c, v1780_11_head, p1, v1780_6, v1780_11_tail);
          v1781_11 = compose(v1781_9,v1783_10);
        }
        const Space v1781_12 = unite(v1781_7,v1781_11);
        v1780_11_result = unite(v1780_11_result,v1781_12);
      }
      const Space v1780_11 = std::move(v1780_11_result);
      v1775_12 = compose(v1775_10,v1780_11);
    }
    const Space v1775_13 = unite(v1775_8,v1775_12);
    v1774_12_result = unite(v1774_12_result,v1775_13);
  }
  const Space v1774_12 = std::move(v1774_12_result);
  return v1774_12;
}

static Space routine_209(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1784_13_result;
  for (int v1784_13_label = 1; v1784_13_label <= 2; ++v1784_13_label) {
    const Space v1784_13_tail = child(s0,v1784_13_label);
    if (v1784_13_tail.empty()) continue;
    const Path v1784_13_head{v1784_13_label};
    const Space v1785_2 = singleton(v1784_13_head);
    const Space v1785_3 = intersect(constant_8,v1785_2);
    const Space v1785_4 = (has_head(v1785_3) ? constant_9 : Space{});
    const Space v1785_5 = subtract(constant_0,v1785_4);
    Space v1785_8;
    if (!v1785_5.empty()) {
      const Path v1786_6 = concat_path(p0,v1784_13_head);
      Space v1786_7_result;
      for (int v1786_7_label = 1; v1786_7_label <= 2; ++v1786_7_label) {
        const Space v1786_7_tail = child(v1784_13_tail,v1786_7_label);
        if (v1786_7_tail.empty()) continue;
        const Path v1786_7_head{v1786_7_label};
        const Space v1787_2 = singleton(v1786_7_head);
        const Space v1787_3 = intersect(constant_8,v1787_2);
        const Space v1787_4 = (has_head(v1787_3) ? constant_9 : Space{});
        const Space v1787_5 = subtract(constant_0,v1787_4);
        Space v1787_8;
        if (!v1787_5.empty()) {
          const Path v1788_6 = concat_path(v1786_6,v1786_7_head);
          const Space v1788_7 = routine_279(c, v1788_6, p1, p2, v1786_7_tail);
          v1787_8 = compose(v1787_5,v1788_7);
        }
        const Space v1787_9 = intersect(constant_8,v1787_2);
        const Space v1787_10 = (has_head(v1787_9) ? constant_9 : Space{});
        Space v1787_12;
        if (!v1787_10.empty()) {
          const Path v1789_6 = concat_path(v1786_6,v1786_7_head);
          const Space v1789_11 = routine_280(c, v1789_6, p1, p2, v1786_7_tail);
          v1787_12 = compose(v1787_10,v1789_11);
        }
        const Space v1787_13 = unite(v1787_8,v1787_12);
        v1786_7_result = unite(v1786_7_result,v1787_13);
      }
      const Space v1786_7 = std::move(v1786_7_result);
      v1785_8 = compose(v1785_5,v1786_7);
    }
    const Space v1785_9 = intersect(constant_8,v1785_2);
    const Space v1785_10 = (has_head(v1785_9) ? constant_9 : Space{});
    Space v1785_12;
    if (!v1785_10.empty()) {
      const Path v1790_6 = concat_path(p0,v1784_13_head);
      Space v1790_11_result;
      for (int v1790_11_label = 1; v1790_11_label <= 2; ++v1790_11_label) {
        const Space v1790_11_tail = child(v1784_13_tail,v1790_11_label);
        if (v1790_11_tail.empty()) continue;
        const Path v1790_11_head{v1790_11_label};
        const Space v1791_2 = singleton(v1790_11_head);
        const Space v1791_3 = intersect(constant_8,v1791_2);
        const Space v1791_4 = (has_head(v1791_3) ? constant_9 : Space{});
        const Space v1791_5 = subtract(constant_0,v1791_4);
        Space v1791_8;
        if (!v1791_5.empty()) {
          const Path v1792_6 = concat_path(v1790_6,v1790_11_head);
          const Space v1792_7 = routine_279(c, v1792_6, p1, p2, v1790_11_tail);
          v1791_8 = compose(v1791_5,v1792_7);
        }
        const Space v1791_9 = intersect(constant_8,v1791_2);
        const Space v1791_10 = (has_head(v1791_9) ? constant_9 : Space{});
        Space v1791_12;
        if (!v1791_10.empty()) {
          const Path v1793_6 = concat_path(v1790_6,v1790_11_head);
          const Space v1793_11 = routine_247(c, v1793_6, p1, p2, v1790_11_tail);
          v1791_12 = compose(v1791_10,v1793_11);
        }
        const Space v1791_13 = unite(v1791_8,v1791_12);
        v1790_11_result = unite(v1790_11_result,v1791_13);
      }
      const Space v1790_11 = std::move(v1790_11_result);
      v1785_12 = compose(v1785_10,v1790_11);
    }
    const Space v1785_13 = unite(v1785_8,v1785_12);
    v1784_13_result = unite(v1784_13_result,v1785_13);
  }
  const Space v1784_13 = std::move(v1784_13_result);
  return v1784_13;
}

static Space routine_210(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1794_10 = concat_path(constant_23,p1);
  const Space v1794_11 = singleton(v1794_10);
  const Path v1794_13 = concat_path(constant_6,p2);
  const Space v1794_14 = singleton(v1794_13);
  Space v1794_18_result;
  for (int v1794_18_label = 1; v1794_18_label <= 2; ++v1794_18_label) {
    const Space v1794_18_tail = child(s0,v1794_18_label);
    if (v1794_18_tail.empty()) continue;
    const Path v1794_18_head{v1794_18_label};
    const Space v1795_2 = singleton(v1794_18_head);
    const Space v1795_3 = intersect(constant_8,v1795_2);
    const Space v1795_4 = (has_head(v1795_3) ? constant_9 : Space{});
    const Space v1795_5 = subtract(constant_0,v1795_4);
    Space v1795_8;
    if (!v1795_5.empty()) {
      const Path v1796_6 = concat_path(p0,v1794_18_head);
      Space v1796_7_result;
      for (int v1796_7_label = 1; v1796_7_label <= 2; ++v1796_7_label) {
        const Space v1796_7_tail = child(v1794_18_tail,v1796_7_label);
        if (v1796_7_tail.empty()) continue;
        const Path v1796_7_head{v1796_7_label};
        const Space v1797_2 = singleton(v1796_7_head);
        const Space v1797_3 = intersect(constant_8,v1797_2);
        const Space v1797_4 = (has_head(v1797_3) ? constant_9 : Space{});
        const Space v1797_5 = subtract(constant_0,v1797_4);
        Space v1797_8;
        if (!v1797_5.empty()) {
          const Path v1798_6 = concat_path(v1796_6,v1796_7_head);
          const Space v1798_7 = routine_279(c, v1798_6, p1, p2, v1796_7_tail);
          v1797_8 = compose(v1797_5,v1798_7);
        }
        const Space v1797_9 = intersect(constant_8,v1797_2);
        const Space v1797_10 = (has_head(v1797_9) ? constant_9 : Space{});
        Space v1797_12;
        if (!v1797_10.empty()) {
          const Path v1799_6 = concat_path(v1796_6,v1796_7_head);
          const Space v1799_11 = routine_280(c, v1799_6, p1, p2, v1796_7_tail);
          v1797_12 = compose(v1797_10,v1799_11);
        }
        const Space v1797_13 = unite(v1797_8,v1797_12);
        v1796_7_result = unite(v1796_7_result,v1797_13);
      }
      const Space v1796_7 = std::move(v1796_7_result);
      v1795_8 = compose(v1795_5,v1796_7);
    }
    const Space v1795_9 = intersect(constant_8,v1795_2);
    const Space v1795_10 = (has_head(v1795_9) ? constant_9 : Space{});
    const Path v1800_6 = concat_path(p0,v1794_18_head);
    const Path v1795_11 = concat_path(constant_24,v1800_6);
    const Space v1795_12 = singleton(v1795_11);
    const Space v1795_13 = unite(constant_28,v1795_12);
    const Space v1795_14 = unite(v1795_13,v1794_11);
    const Space v1795_15 = unite(v1795_14,v1794_14);
    const Space v1795_16 = compose(v1795_10,v1795_15);
    const Space v1795_17 = unite(v1795_8,v1795_16);
    v1794_18_result = unite(v1794_18_result,v1795_17);
  }
  const Space v1794_18 = std::move(v1794_18_result);
  return v1794_18;
}

static Space routine_211(Context& c, const Path& p0, const Space& s0) {
  const Space v1801_2 = Space{};
  return v1801_2;
}

static Space routine_212(Context& c, const Path& p0, const Space& s0) {
  Space v1802_3_result;
  for (int v1802_3_label = 1; v1802_3_label <= 2; ++v1802_3_label) {
    const Space v1802_3_tail = child(s0,v1802_3_label);
    if (v1802_3_tail.empty()) continue;
    const Path v1802_3_head{v1802_3_label};
    const Space v1803_2 = singleton(v1802_3_head);
    const Space v1803_3 = intersect(constant_8,v1803_2);
    const Space v1803_4 = (has_head(v1803_3) ? constant_9 : Space{});
    const Space v1803_5 = compose(v1803_4,v1802_3_tail);
    v1802_3_result = unite(v1802_3_result,v1803_5);
  }
  const Space v1802_3 = std::move(v1802_3_result);
  return v1802_3;
}

static Space routine_213(Context& c, const Path& p0, const Space& s0) {
  const Space v1804_2 = Space{};
  return v1804_2;
}

static Space routine_214(Context& c, const Path& p0, const Space& s0) {
  Space v1805_6_result;
  for (int v1805_6_label = 1; v1805_6_label <= 2; ++v1805_6_label) {
    const Space v1805_6_tail = child(s0,v1805_6_label);
    if (v1805_6_tail.empty()) continue;
    const Path v1805_6_head{v1805_6_label};
    const Space v1806_2 = singleton(v1805_6_head);
    const Space v1806_3 = intersect(constant_8,v1806_2);
    const Space v1806_4 = (has_head(v1806_3) ? constant_9 : Space{});
    Space v1806_7;
    if (!v1806_4.empty()) {
      const Path v1807_5 = concat_path(p0,v1805_6_head);
      Space v1807_6_result;
      for (int v1807_6_label = 1; v1807_6_label <= 2; ++v1807_6_label) {
        const Space v1807_6_tail = child(v1805_6_tail,v1807_6_label);
        if (v1807_6_tail.empty()) continue;
        const Path v1807_6_head{v1807_6_label};
        const Space v1808_2 = singleton(v1807_6_head);
        const Space v1808_3 = intersect(constant_8,v1808_2);
        const Space v1808_4 = (has_head(v1808_3) ? constant_9 : Space{});
        const Space v1808_5 = subtract(constant_0,v1808_4);
        Space v1808_7;
        if (!v1808_5.empty()) {
          const Space v1809_6 = routine_124(c, v1807_6_head, v1807_5, v1807_6_tail);
          v1808_7 = compose(v1808_5,v1809_6);
        }
        const Space v1808_8 = intersect(constant_8,v1808_2);
        const Space v1808_9 = (has_head(v1808_8) ? constant_9 : Space{});
        Space v1808_11;
        if (!v1808_9.empty()) {
          const Space v1810_10 = routine_125(c, v1807_6_head, v1807_5, v1807_6_tail);
          v1808_11 = compose(v1808_9,v1810_10);
        }
        const Space v1808_12 = unite(v1808_7,v1808_11);
        v1807_6_result = unite(v1807_6_result,v1808_12);
      }
      const Space v1807_6 = std::move(v1807_6_result);
      v1806_7 = compose(v1806_4,v1807_6);
    }
    v1805_6_result = unite(v1805_6_result,v1806_7);
  }
  const Space v1805_6 = std::move(v1805_6_result);
  return v1805_6;
}

static Space routine_215(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1811_12_result;
  for (int v1811_12_label = 1; v1811_12_label <= 2; ++v1811_12_label) {
    const Space v1811_12_tail = child(s0,v1811_12_label);
    if (v1811_12_tail.empty()) continue;
    const Path v1811_12_head{v1811_12_label};
    const Space v1812_2 = singleton(v1811_12_head);
    const Space v1812_3 = intersect(constant_8,v1812_2);
    const Space v1812_4 = (has_head(v1812_3) ? constant_9 : Space{});
    const Space v1812_5 = subtract(constant_0,v1812_4);
    Space v1812_8;
    if (!v1812_5.empty()) {
      const Path v1813_6 = concat_path(p0,v1811_12_head);
      Space v1813_7_result;
      for (int v1813_7_label = 1; v1813_7_label <= 2; ++v1813_7_label) {
        const Space v1813_7_tail = child(v1811_12_tail,v1813_7_label);
        if (v1813_7_tail.empty()) continue;
        const Path v1813_7_head{v1813_7_label};
        const Space v1814_2 = singleton(v1813_7_head);
        const Space v1814_3 = intersect(constant_8,v1814_2);
        const Space v1814_4 = (has_head(v1814_3) ? constant_9 : Space{});
        const Space v1814_5 = subtract(constant_0,v1814_4);
        Space v1814_8;
        if (!v1814_5.empty()) {
          const Path v1815_6 = concat_path(v1813_6,v1813_7_head);
          const Space v1815_7 = routine_281(c, v1815_6, p1, v1813_7_tail);
          v1814_8 = compose(v1814_5,v1815_7);
        }
        const Space v1814_9 = intersect(constant_8,v1814_2);
        const Space v1814_10 = (has_head(v1814_9) ? constant_9 : Space{});
        Space v1814_12;
        if (!v1814_10.empty()) {
          const Path v1816_6 = concat_path(v1813_6,v1813_7_head);
          const Space v1816_11 = routine_282(c, v1816_6, p1, v1813_7_tail);
          v1814_12 = compose(v1814_10,v1816_11);
        }
        const Space v1814_13 = unite(v1814_8,v1814_12);
        v1813_7_result = unite(v1813_7_result,v1814_13);
      }
      const Space v1813_7 = std::move(v1813_7_result);
      v1812_8 = compose(v1812_5,v1813_7);
    }
    const Space v1812_9 = intersect(constant_8,v1812_2);
    const Space v1812_10 = (has_head(v1812_9) ? constant_9 : Space{});
    Space v1812_12;
    if (!v1812_10.empty()) {
      const Path v1817_6 = concat_path(p0,v1811_12_head);
      Space v1817_11_result;
      for (int v1817_11_label = 1; v1817_11_label <= 2; ++v1817_11_label) {
        const Space v1817_11_tail = child(v1811_12_tail,v1817_11_label);
        if (v1817_11_tail.empty()) continue;
        const Path v1817_11_head{v1817_11_label};
        const Space v1818_2 = singleton(v1817_11_head);
        const Space v1818_3 = intersect(constant_8,v1818_2);
        const Space v1818_4 = (has_head(v1818_3) ? constant_9 : Space{});
        const Space v1818_5 = subtract(constant_0,v1818_4);
        Space v1818_8;
        if (!v1818_5.empty()) {
          const Path v1819_6 = concat_path(v1817_6,v1817_11_head);
          const Space v1819_7 = routine_281(c, v1819_6, p1, v1817_11_tail);
          v1818_8 = compose(v1818_5,v1819_7);
        }
        const Space v1818_9 = intersect(constant_8,v1818_2);
        const Space v1818_10 = (has_head(v1818_9) ? constant_9 : Space{});
        Space v1818_12;
        if (!v1818_10.empty()) {
          const Path v1820_6 = concat_path(v1817_6,v1817_11_head);
          const Space v1820_11 = routine_169(c, v1820_6, p1, v1817_11_tail);
          v1818_12 = compose(v1818_10,v1820_11);
        }
        const Space v1818_13 = unite(v1818_8,v1818_12);
        v1817_11_result = unite(v1817_11_result,v1818_13);
      }
      const Space v1817_11 = std::move(v1817_11_result);
      v1812_12 = compose(v1812_10,v1817_11);
    }
    const Space v1812_13 = unite(v1812_8,v1812_12);
    v1811_12_result = unite(v1811_12_result,v1812_13);
  }
  const Space v1811_12 = std::move(v1811_12_result);
  return v1811_12;
}

static Space routine_216(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1821_12_result;
  for (int v1821_12_label = 1; v1821_12_label <= 2; ++v1821_12_label) {
    const Space v1821_12_tail = child(s0,v1821_12_label);
    if (v1821_12_tail.empty()) continue;
    const Path v1821_12_head{v1821_12_label};
    const Space v1822_2 = singleton(v1821_12_head);
    const Space v1822_3 = intersect(constant_8,v1822_2);
    const Space v1822_4 = (has_head(v1822_3) ? constant_9 : Space{});
    const Space v1822_5 = subtract(constant_0,v1822_4);
    Space v1822_8;
    if (!v1822_5.empty()) {
      const Path v1823_6 = concat_path(p0,v1821_12_head);
      Space v1823_7_result;
      for (int v1823_7_label = 1; v1823_7_label <= 2; ++v1823_7_label) {
        const Space v1823_7_tail = child(v1821_12_tail,v1823_7_label);
        if (v1823_7_tail.empty()) continue;
        const Path v1823_7_head{v1823_7_label};
        const Space v1824_2 = singleton(v1823_7_head);
        const Space v1824_3 = intersect(constant_8,v1824_2);
        const Space v1824_4 = (has_head(v1824_3) ? constant_9 : Space{});
        const Space v1824_5 = subtract(constant_0,v1824_4);
        Space v1824_8;
        if (!v1824_5.empty()) {
          const Path v1825_6 = concat_path(v1823_6,v1823_7_head);
          const Space v1825_7 = routine_281(c, v1825_6, p1, v1823_7_tail);
          v1824_8 = compose(v1824_5,v1825_7);
        }
        const Space v1824_9 = intersect(constant_8,v1824_2);
        const Space v1824_10 = (has_head(v1824_9) ? constant_9 : Space{});
        Space v1824_12;
        if (!v1824_10.empty()) {
          const Path v1826_6 = concat_path(v1823_6,v1823_7_head);
          const Space v1826_11 = routine_282(c, v1826_6, p1, v1823_7_tail);
          v1824_12 = compose(v1824_10,v1826_11);
        }
        const Space v1824_13 = unite(v1824_8,v1824_12);
        v1823_7_result = unite(v1823_7_result,v1824_13);
      }
      const Space v1823_7 = std::move(v1823_7_result);
      v1822_8 = compose(v1822_5,v1823_7);
    }
    const Space v1822_9 = intersect(constant_8,v1822_2);
    const Space v1822_10 = (has_head(v1822_9) ? constant_9 : Space{});
    Space v1822_12;
    if (!v1822_10.empty()) {
      const Path v1827_6 = concat_path(p0,v1821_12_head);
      Space v1827_11_result;
      for (int v1827_11_label = 1; v1827_11_label <= 2; ++v1827_11_label) {
        const Space v1827_11_tail = child(v1821_12_tail,v1827_11_label);
        if (v1827_11_tail.empty()) continue;
        const Path v1827_11_head{v1827_11_label};
        const Space v1828_2 = singleton(v1827_11_head);
        const Space v1828_3 = intersect(constant_8,v1828_2);
        const Space v1828_4 = (has_head(v1828_3) ? constant_9 : Space{});
        const Space v1828_5 = subtract(constant_0,v1828_4);
        Space v1828_7;
        if (!v1828_5.empty()) {
          const Space v1829_6 = routine_217(c, v1827_11_head, p1, v1827_6, v1827_11_tail);
          v1828_7 = compose(v1828_5,v1829_6);
        }
        const Space v1828_8 = intersect(constant_8,v1828_2);
        const Space v1828_9 = (has_head(v1828_8) ? constant_9 : Space{});
        Space v1828_11;
        if (!v1828_9.empty()) {
          const Space v1830_10 = routine_218(c, v1827_11_head, p1, v1827_6, v1827_11_tail);
          v1828_11 = compose(v1828_9,v1830_10);
        }
        const Space v1828_12 = unite(v1828_7,v1828_11);
        v1827_11_result = unite(v1827_11_result,v1828_12);
      }
      const Space v1827_11 = std::move(v1827_11_result);
      v1822_12 = compose(v1822_10,v1827_11);
    }
    const Space v1822_13 = unite(v1822_8,v1822_12);
    v1821_12_result = unite(v1821_12_result,v1822_13);
  }
  const Space v1821_12 = std::move(v1821_12_result);
  return v1821_12;
}

static Space routine_217(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1831_13_result;
  for (int v1831_13_label = 1; v1831_13_label <= 2; ++v1831_13_label) {
    const Space v1831_13_tail = child(s0,v1831_13_label);
    if (v1831_13_tail.empty()) continue;
    const Path v1831_13_head{v1831_13_label};
    const Space v1832_2 = singleton(v1831_13_head);
    const Space v1832_3 = intersect(constant_8,v1832_2);
    const Space v1832_4 = (has_head(v1832_3) ? constant_9 : Space{});
    const Space v1832_5 = subtract(constant_0,v1832_4);
    Space v1832_8;
    if (!v1832_5.empty()) {
      const Path v1833_6 = concat_path(p0,v1831_13_head);
      Space v1833_7_result;
      for (int v1833_7_label = 1; v1833_7_label <= 2; ++v1833_7_label) {
        const Space v1833_7_tail = child(v1831_13_tail,v1833_7_label);
        if (v1833_7_tail.empty()) continue;
        const Path v1833_7_head{v1833_7_label};
        const Space v1834_2 = singleton(v1833_7_head);
        const Space v1834_3 = intersect(constant_8,v1834_2);
        const Space v1834_4 = (has_head(v1834_3) ? constant_9 : Space{});
        const Space v1834_5 = subtract(constant_0,v1834_4);
        Space v1834_8;
        if (!v1834_5.empty()) {
          const Path v1835_6 = concat_path(v1833_6,v1833_7_head);
          const Space v1835_7 = routine_283(c, v1835_6, p1, p2, v1833_7_tail);
          v1834_8 = compose(v1834_5,v1835_7);
        }
        const Space v1834_9 = intersect(constant_8,v1834_2);
        const Space v1834_10 = (has_head(v1834_9) ? constant_9 : Space{});
        Space v1834_12;
        if (!v1834_10.empty()) {
          const Path v1836_6 = concat_path(v1833_6,v1833_7_head);
          const Space v1836_11 = routine_284(c, v1836_6, p1, p2, v1833_7_tail);
          v1834_12 = compose(v1834_10,v1836_11);
        }
        const Space v1834_13 = unite(v1834_8,v1834_12);
        v1833_7_result = unite(v1833_7_result,v1834_13);
      }
      const Space v1833_7 = std::move(v1833_7_result);
      v1832_8 = compose(v1832_5,v1833_7);
    }
    const Space v1832_9 = intersect(constant_8,v1832_2);
    const Space v1832_10 = (has_head(v1832_9) ? constant_9 : Space{});
    Space v1832_12;
    if (!v1832_10.empty()) {
      const Path v1837_6 = concat_path(p0,v1831_13_head);
      Space v1837_11_result;
      for (int v1837_11_label = 1; v1837_11_label <= 2; ++v1837_11_label) {
        const Space v1837_11_tail = child(v1831_13_tail,v1837_11_label);
        if (v1837_11_tail.empty()) continue;
        const Path v1837_11_head{v1837_11_label};
        const Space v1838_2 = singleton(v1837_11_head);
        const Space v1838_3 = intersect(constant_8,v1838_2);
        const Space v1838_4 = (has_head(v1838_3) ? constant_9 : Space{});
        const Space v1838_5 = subtract(constant_0,v1838_4);
        Space v1838_8;
        if (!v1838_5.empty()) {
          const Path v1839_6 = concat_path(v1837_6,v1837_11_head);
          const Space v1839_7 = routine_283(c, v1839_6, p1, p2, v1837_11_tail);
          v1838_8 = compose(v1838_5,v1839_7);
        }
        const Space v1838_9 = intersect(constant_8,v1838_2);
        const Space v1838_10 = (has_head(v1838_9) ? constant_9 : Space{});
        Space v1838_12;
        if (!v1838_10.empty()) {
          const Path v1840_6 = concat_path(v1837_6,v1837_11_head);
          const Space v1840_11 = routine_252(c, v1840_6, p1, p2, v1837_11_tail);
          v1838_12 = compose(v1838_10,v1840_11);
        }
        const Space v1838_13 = unite(v1838_8,v1838_12);
        v1837_11_result = unite(v1837_11_result,v1838_13);
      }
      const Space v1837_11 = std::move(v1837_11_result);
      v1832_12 = compose(v1832_10,v1837_11);
    }
    const Space v1832_13 = unite(v1832_8,v1832_12);
    v1831_13_result = unite(v1831_13_result,v1832_13);
  }
  const Space v1831_13 = std::move(v1831_13_result);
  return v1831_13;
}

static Space routine_218(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1841_10 = concat_path(constant_23,p2);
  const Space v1841_11 = singleton(v1841_10);
  const Path v1841_13 = concat_path(constant_22,p1);
  const Space v1841_14 = singleton(v1841_13);
  Space v1841_18_result;
  for (int v1841_18_label = 1; v1841_18_label <= 2; ++v1841_18_label) {
    const Space v1841_18_tail = child(s0,v1841_18_label);
    if (v1841_18_tail.empty()) continue;
    const Path v1841_18_head{v1841_18_label};
    const Space v1842_2 = singleton(v1841_18_head);
    const Space v1842_3 = intersect(constant_8,v1842_2);
    const Space v1842_4 = (has_head(v1842_3) ? constant_9 : Space{});
    const Space v1842_5 = subtract(constant_0,v1842_4);
    Space v1842_8;
    if (!v1842_5.empty()) {
      const Path v1843_6 = concat_path(p0,v1841_18_head);
      Space v1843_7_result;
      for (int v1843_7_label = 1; v1843_7_label <= 2; ++v1843_7_label) {
        const Space v1843_7_tail = child(v1841_18_tail,v1843_7_label);
        if (v1843_7_tail.empty()) continue;
        const Path v1843_7_head{v1843_7_label};
        const Space v1844_2 = singleton(v1843_7_head);
        const Space v1844_3 = intersect(constant_8,v1844_2);
        const Space v1844_4 = (has_head(v1844_3) ? constant_9 : Space{});
        const Space v1844_5 = subtract(constant_0,v1844_4);
        Space v1844_8;
        if (!v1844_5.empty()) {
          const Path v1845_6 = concat_path(v1843_6,v1843_7_head);
          const Space v1845_7 = routine_283(c, v1845_6, p1, p2, v1843_7_tail);
          v1844_8 = compose(v1844_5,v1845_7);
        }
        const Space v1844_9 = intersect(constant_8,v1844_2);
        const Space v1844_10 = (has_head(v1844_9) ? constant_9 : Space{});
        Space v1844_12;
        if (!v1844_10.empty()) {
          const Path v1846_6 = concat_path(v1843_6,v1843_7_head);
          const Space v1846_11 = routine_284(c, v1846_6, p1, p2, v1843_7_tail);
          v1844_12 = compose(v1844_10,v1846_11);
        }
        const Space v1844_13 = unite(v1844_8,v1844_12);
        v1843_7_result = unite(v1843_7_result,v1844_13);
      }
      const Space v1843_7 = std::move(v1843_7_result);
      v1842_8 = compose(v1842_5,v1843_7);
    }
    const Space v1842_9 = intersect(constant_8,v1842_2);
    const Space v1842_10 = (has_head(v1842_9) ? constant_9 : Space{});
    const Path v1847_6 = concat_path(p0,v1841_18_head);
    const Path v1842_11 = concat_path(constant_24,v1847_6);
    const Space v1842_12 = singleton(v1842_11);
    const Space v1842_13 = unite(constant_29,v1842_12);
    const Space v1842_14 = unite(v1842_13,v1841_11);
    const Space v1842_15 = unite(v1842_14,v1841_14);
    const Space v1842_16 = compose(v1842_10,v1842_15);
    const Space v1842_17 = unite(v1842_8,v1842_16);
    v1841_18_result = unite(v1841_18_result,v1842_17);
  }
  const Space v1841_18 = std::move(v1841_18_result);
  return v1841_18;
}

static Space routine_219(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1848_5_result;
  for (int v1848_5_label = 1; v1848_5_label <= 2; ++v1848_5_label) {
    const Space v1848_5_tail = child(s0,v1848_5_label);
    if (v1848_5_tail.empty()) continue;
    const Path v1848_5_head{v1848_5_label};
    const Space v1849_2 = singleton(v1848_5_head);
    const Space v1849_3 = intersect(constant_8,v1849_2);
    const Space v1849_4 = (has_head(v1849_3) ? constant_9 : Space{});
    Space v1849_7;
    if (!v1849_4.empty()) {
      const Path v1850_5 = concat_path(p0,v1848_5_head);
      Space v1850_6_result;
      for (int v1850_6_label = 1; v1850_6_label <= 2; ++v1850_6_label) {
        const Space v1850_6_tail = child(v1848_5_tail,v1850_6_label);
        if (v1850_6_tail.empty()) continue;
        const Path v1850_6_head{v1850_6_label};
        const Space v1851_2 = singleton(v1850_6_head);
        const Space v1851_3 = intersect(constant_8,v1851_2);
        const Space v1851_4 = (has_head(v1851_3) ? constant_9 : Space{});
        Space v1851_7;
        if (!v1851_4.empty()) {
          const Path v1852_5 = concat_path(v1850_5,v1850_6_head);
          const Space v1852_6 = routine_130(c, v1852_5, p1, v1850_6_tail);
          v1851_7 = compose(v1851_4,v1852_6);
        }
        v1850_6_result = unite(v1850_6_result,v1851_7);
      }
      const Space v1850_6 = std::move(v1850_6_result);
      v1849_7 = compose(v1849_4,v1850_6);
    }
    v1848_5_result = unite(v1848_5_result,v1849_7);
  }
  const Space v1848_5 = std::move(v1848_5_result);
  return v1848_5;
}

static Space routine_220(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1853_7_result;
  for (int v1853_7_label = 1; v1853_7_label <= 2; ++v1853_7_label) {
    const Space v1853_7_tail = child(s0,v1853_7_label);
    if (v1853_7_tail.empty()) continue;
    const Path v1853_7_head{v1853_7_label};
    const Space v1854_2 = singleton(v1853_7_head);
    const Space v1854_3 = intersect(constant_8,v1854_2);
    const Space v1854_4 = (has_head(v1854_3) ? constant_9 : Space{});
    Space v1854_7;
    if (!v1854_4.empty()) {
      const Path v1855_5 = concat_path(p0,v1853_7_head);
      Space v1855_6_result;
      for (int v1855_6_label = 1; v1855_6_label <= 2; ++v1855_6_label) {
        const Space v1855_6_tail = child(v1853_7_tail,v1855_6_label);
        if (v1855_6_tail.empty()) continue;
        const Path v1855_6_head{v1855_6_label};
        const Space v1856_2 = singleton(v1855_6_head);
        const Space v1856_3 = intersect(constant_8,v1856_2);
        const Space v1856_4 = (has_head(v1856_3) ? constant_9 : Space{});
        const Space v1856_5 = subtract(constant_0,v1856_4);
        Space v1856_7;
        if (!v1856_5.empty()) {
          const Space v1857_6 = routine_174(c, v1855_6_head, p1, v1855_5, v1855_6_tail);
          v1856_7 = compose(v1856_5,v1857_6);
        }
        const Space v1856_8 = intersect(constant_8,v1856_2);
        const Space v1856_9 = (has_head(v1856_8) ? constant_9 : Space{});
        Space v1856_11;
        if (!v1856_9.empty()) {
          const Space v1858_10 = routine_175(c, v1855_6_head, p1, v1855_5, v1855_6_tail);
          v1856_11 = compose(v1856_9,v1858_10);
        }
        const Space v1856_12 = unite(v1856_7,v1856_11);
        v1855_6_result = unite(v1855_6_result,v1856_12);
      }
      const Space v1855_6 = std::move(v1855_6_result);
      v1854_7 = compose(v1854_4,v1855_6);
    }
    v1853_7_result = unite(v1853_7_result,v1854_7);
  }
  const Space v1853_7 = std::move(v1853_7_result);
  return v1853_7;
}

static Space routine_221(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1859_13_result;
  for (int v1859_13_label = 1; v1859_13_label <= 2; ++v1859_13_label) {
    const Space v1859_13_tail = child(s0,v1859_13_label);
    if (v1859_13_tail.empty()) continue;
    const Path v1859_13_head{v1859_13_label};
    const Space v1860_2 = singleton(v1859_13_head);
    const Space v1860_3 = intersect(constant_8,v1860_2);
    const Space v1860_4 = (has_head(v1860_3) ? constant_9 : Space{});
    const Space v1860_5 = subtract(constant_0,v1860_4);
    Space v1860_8;
    if (!v1860_5.empty()) {
      const Path v1861_6 = concat_path(p0,v1859_13_head);
      Space v1861_7_result;
      for (int v1861_7_label = 1; v1861_7_label <= 2; ++v1861_7_label) {
        const Space v1861_7_tail = child(v1859_13_tail,v1861_7_label);
        if (v1861_7_tail.empty()) continue;
        const Path v1861_7_head{v1861_7_label};
        const Space v1862_2 = singleton(v1861_7_head);
        const Space v1862_3 = intersect(constant_8,v1862_2);
        const Space v1862_4 = (has_head(v1862_3) ? constant_9 : Space{});
        const Space v1862_5 = subtract(constant_0,v1862_4);
        Space v1862_8;
        if (!v1862_5.empty()) {
          const Path v1863_6 = concat_path(v1861_6,v1861_7_head);
          const Space v1863_7 = routine_285(c, v1863_6, p1, p2, v1861_7_tail);
          v1862_8 = compose(v1862_5,v1863_7);
        }
        const Space v1862_9 = intersect(constant_8,v1862_2);
        const Space v1862_10 = (has_head(v1862_9) ? constant_9 : Space{});
        Space v1862_12;
        if (!v1862_10.empty()) {
          const Path v1864_6 = concat_path(v1861_6,v1861_7_head);
          const Space v1864_11 = routine_286(c, v1864_6, p1, p2, v1861_7_tail);
          v1862_12 = compose(v1862_10,v1864_11);
        }
        const Space v1862_13 = unite(v1862_8,v1862_12);
        v1861_7_result = unite(v1861_7_result,v1862_13);
      }
      const Space v1861_7 = std::move(v1861_7_result);
      v1860_8 = compose(v1860_5,v1861_7);
    }
    const Space v1860_9 = intersect(constant_8,v1860_2);
    const Space v1860_10 = (has_head(v1860_9) ? constant_9 : Space{});
    Space v1860_12;
    if (!v1860_10.empty()) {
      const Path v1865_6 = concat_path(p0,v1859_13_head);
      Space v1865_11_result;
      for (int v1865_11_label = 1; v1865_11_label <= 2; ++v1865_11_label) {
        const Space v1865_11_tail = child(v1859_13_tail,v1865_11_label);
        if (v1865_11_tail.empty()) continue;
        const Path v1865_11_head{v1865_11_label};
        const Space v1866_2 = singleton(v1865_11_head);
        const Space v1866_3 = intersect(constant_8,v1866_2);
        const Space v1866_4 = (has_head(v1866_3) ? constant_9 : Space{});
        const Space v1866_5 = subtract(constant_0,v1866_4);
        Space v1866_8;
        if (!v1866_5.empty()) {
          const Path v1867_6 = concat_path(v1865_6,v1865_11_head);
          const Space v1867_7 = routine_285(c, v1867_6, p1, p2, v1865_11_tail);
          v1866_8 = compose(v1866_5,v1867_7);
        }
        const Space v1866_9 = intersect(constant_8,v1866_2);
        const Space v1866_10 = (has_head(v1866_9) ? constant_9 : Space{});
        Space v1866_12;
        if (!v1866_10.empty()) {
          const Path v1868_6 = concat_path(v1865_6,v1865_11_head);
          const Space v1868_11 = routine_223(c, v1868_6, p1, p2, v1865_11_tail);
          v1866_12 = compose(v1866_10,v1868_11);
        }
        const Space v1866_13 = unite(v1866_8,v1866_12);
        v1865_11_result = unite(v1865_11_result,v1866_13);
      }
      const Space v1865_11 = std::move(v1865_11_result);
      v1860_12 = compose(v1860_10,v1865_11);
    }
    const Space v1860_13 = unite(v1860_8,v1860_12);
    v1859_13_result = unite(v1859_13_result,v1860_13);
  }
  const Space v1859_13 = std::move(v1859_13_result);
  return v1859_13;
}

static Space routine_222(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1869_14_result;
  for (int v1869_14_label = 1; v1869_14_label <= 2; ++v1869_14_label) {
    const Space v1869_14_tail = child(s0,v1869_14_label);
    if (v1869_14_tail.empty()) continue;
    const Path v1869_14_head{v1869_14_label};
    const Space v1870_2 = singleton(v1869_14_head);
    const Space v1870_3 = intersect(constant_8,v1870_2);
    const Space v1870_4 = (has_head(v1870_3) ? constant_9 : Space{});
    const Space v1870_5 = subtract(constant_0,v1870_4);
    Space v1870_8;
    if (!v1870_5.empty()) {
      const Path v1871_6 = concat_path(p0,v1869_14_head);
      Space v1871_7_result;
      for (int v1871_7_label = 1; v1871_7_label <= 2; ++v1871_7_label) {
        const Space v1871_7_tail = child(v1869_14_tail,v1871_7_label);
        if (v1871_7_tail.empty()) continue;
        const Path v1871_7_head{v1871_7_label};
        const Space v1872_2 = singleton(v1871_7_head);
        const Space v1872_3 = intersect(constant_8,v1872_2);
        const Space v1872_4 = (has_head(v1872_3) ? constant_9 : Space{});
        const Space v1872_5 = subtract(constant_0,v1872_4);
        Space v1872_8;
        if (!v1872_5.empty()) {
          const Path v1873_6 = concat_path(v1871_6,v1871_7_head);
          const Space v1873_7 = routine_285(c, v1873_6, p1, p2, v1871_7_tail);
          v1872_8 = compose(v1872_5,v1873_7);
        }
        const Space v1872_9 = intersect(constant_8,v1872_2);
        const Space v1872_10 = (has_head(v1872_9) ? constant_9 : Space{});
        Space v1872_12;
        if (!v1872_10.empty()) {
          const Path v1874_6 = concat_path(v1871_6,v1871_7_head);
          const Space v1874_11 = routine_286(c, v1874_6, p1, p2, v1871_7_tail);
          v1872_12 = compose(v1872_10,v1874_11);
        }
        const Space v1872_13 = unite(v1872_8,v1872_12);
        v1871_7_result = unite(v1871_7_result,v1872_13);
      }
      const Space v1871_7 = std::move(v1871_7_result);
      v1870_8 = compose(v1870_5,v1871_7);
    }
    const Space v1870_9 = intersect(constant_8,v1870_2);
    const Space v1870_10 = (has_head(v1870_9) ? constant_9 : Space{});
    Space v1870_17;
    if (!v1870_10.empty()) {
      const Path v1875_6 = concat_path(p0,v1869_14_head);
      Space v1875_11_result;
      for (int v1875_11_label = 1; v1875_11_label <= 2; ++v1875_11_label) {
        const Space v1875_11_tail = child(v1869_14_tail,v1875_11_label);
        if (v1875_11_tail.empty()) continue;
        const Path v1875_11_head{v1875_11_label};
        const Space v1876_2 = singleton(v1875_11_head);
        const Space v1876_3 = intersect(constant_8,v1876_2);
        const Space v1876_4 = (has_head(v1876_3) ? constant_9 : Space{});
        const Space v1876_5 = subtract(constant_0,v1876_4);
        Space v1876_7;
        if (!v1876_5.empty()) {
          const Space v1877_6 = routine_257(c, v1875_11_head, v1875_11_tail);
          v1876_7 = compose(v1876_5,v1877_6);
        }
        const Space v1876_8 = intersect(constant_8,v1876_2);
        const Space v1876_9 = (has_head(v1876_8) ? constant_9 : Space{});
        Space v1876_11;
        if (!v1876_9.empty()) {
          const Space v1878_10 = routine_258(c, v1875_11_head, v1875_11_tail);
          v1876_11 = compose(v1876_9,v1878_10);
        }
        const Space v1876_12 = unite(v1876_7,v1876_11);
        v1875_11_result = unite(v1875_11_result,v1876_12);
      }
      const Space v1875_11 = std::move(v1875_11_result);
      const Space v1875_12 = raffine(constant_25,v1875_11);
      const Space v1875_13 = unite(v1875_12,v1869_14_tail);
      const Path v1875_14 = concat_path(p2,v1875_6);
      const Space v1875_15 = wrap(v1875_13,v1875_14);
      const Space v1875_16 = unwrap(v1875_15,p1);
      v1870_17 = compose(v1870_10,v1875_16);
    }
    const Space v1870_18 = unite(v1870_8,v1870_17);
    v1869_14_result = unite(v1869_14_result,v1870_18);
  }
  const Space v1869_14 = std::move(v1869_14_result);
  return v1869_14;
}

static Space routine_223(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1879_14_result;
  for (int v1879_14_label = 1; v1879_14_label <= 2; ++v1879_14_label) {
    const Space v1879_14_tail = child(s0,v1879_14_label);
    if (v1879_14_tail.empty()) continue;
    const Path v1879_14_head{v1879_14_label};
    const Space v1880_2 = singleton(v1879_14_head);
    const Space v1880_3 = intersect(constant_8,v1880_2);
    const Space v1880_4 = (has_head(v1880_3) ? constant_9 : Space{});
    const Space v1880_5 = subtract(constant_0,v1880_4);
    Space v1880_7;
    if (!v1880_5.empty()) {
      Space v1881_6_result;
      for (int v1881_6_label = 1; v1881_6_label <= 2; ++v1881_6_label) {
        const Space v1881_6_tail = child(v1879_14_tail,v1881_6_label);
        if (v1881_6_tail.empty()) continue;
        const Path v1881_6_head{v1881_6_label};
        const Space v1882_2 = singleton(v1881_6_head);
        const Space v1882_3 = intersect(constant_8,v1882_2);
        const Space v1882_4 = (has_head(v1882_3) ? constant_9 : Space{});
        const Space v1882_5 = subtract(constant_0,v1882_4);
        Space v1882_8;
        if (!v1882_5.empty()) {
          const Path v1883_6 = concat_path(v1879_14_head,v1881_6_head);
          const Space v1883_7 = routine_287(c, v1883_6, v1881_6_tail);
          v1882_8 = compose(v1882_5,v1883_7);
        }
        const Space v1882_9 = intersect(constant_8,v1882_2);
        const Space v1882_10 = (has_head(v1882_9) ? constant_9 : Space{});
        Space v1882_12;
        if (!v1882_10.empty()) {
          const Path v1884_6 = concat_path(v1879_14_head,v1881_6_head);
          const Space v1884_11 = routine_288(c, v1884_6, v1881_6_tail);
          v1882_12 = compose(v1882_10,v1884_11);
        }
        const Space v1882_13 = unite(v1882_8,v1882_12);
        v1881_6_result = unite(v1881_6_result,v1882_13);
      }
      const Space v1881_6 = std::move(v1881_6_result);
      v1880_7 = compose(v1880_5,v1881_6);
    }
    const Space v1880_8 = intersect(constant_8,v1880_2);
    const Space v1880_9 = (has_head(v1880_8) ? constant_9 : Space{});
    Space v1880_11;
    if (!v1880_9.empty()) {
      Space v1885_10_result;
      for (int v1885_10_label = 1; v1885_10_label <= 2; ++v1885_10_label) {
        const Space v1885_10_tail = child(v1879_14_tail,v1885_10_label);
        if (v1885_10_tail.empty()) continue;
        const Path v1885_10_head{v1885_10_label};
        const Space v1886_2 = singleton(v1885_10_head);
        const Space v1886_3 = intersect(constant_8,v1886_2);
        const Space v1886_4 = (has_head(v1886_3) ? constant_9 : Space{});
        const Space v1886_5 = subtract(constant_0,v1886_4);
        Space v1886_8;
        if (!v1886_5.empty()) {
          const Path v1887_6 = concat_path(v1879_14_head,v1885_10_head);
          const Space v1887_7 = routine_287(c, v1887_6, v1885_10_tail);
          v1886_8 = compose(v1886_5,v1887_7);
        }
        const Space v1886_9 = intersect(constant_8,v1886_2);
        const Space v1886_10 = (has_head(v1886_9) ? constant_9 : Space{});
        Space v1886_12;
        if (!v1886_10.empty()) {
          const Path v1888_6 = concat_path(v1879_14_head,v1885_10_head);
          const Space v1888_11 = routine_289(c, v1888_6, v1885_10_tail);
          v1886_12 = compose(v1886_10,v1888_11);
        }
        const Space v1886_13 = unite(v1886_8,v1886_12);
        v1885_10_result = unite(v1885_10_result,v1886_13);
      }
      const Space v1885_10 = std::move(v1885_10_result);
      v1880_11 = compose(v1880_9,v1885_10);
    }
    const Space v1880_12 = unite(v1880_7,v1880_11);
    v1879_14_result = unite(v1879_14_result,v1880_12);
  }
  const Space v1879_14 = std::move(v1879_14_result);
  const Space v1879_15 = raffine(constant_25,v1879_14);
  const Space v1879_16 = unite(v1879_15,s0);
  const Path v1879_17 = concat_path(p2,p0);
  const Space v1879_18 = wrap(v1879_16,v1879_17);
  const Space v1879_19 = unwrap(v1879_18,p1);
  return v1879_19;
}

static Space routine_224(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1889_6_result;
  for (int v1889_6_label = 1; v1889_6_label <= 2; ++v1889_6_label) {
    const Space v1889_6_tail = child(s0,v1889_6_label);
    if (v1889_6_tail.empty()) continue;
    const Path v1889_6_head{v1889_6_label};
    const Space v1890_2 = singleton(v1889_6_head);
    const Space v1890_3 = intersect(constant_8,v1890_2);
    const Space v1890_4 = (has_head(v1890_3) ? constant_9 : Space{});
    Space v1890_7;
    if (!v1890_4.empty()) {
      const Path v1891_5 = concat_path(p0,v1889_6_head);
      Space v1891_6_result;
      for (int v1891_6_label = 1; v1891_6_label <= 2; ++v1891_6_label) {
        const Space v1891_6_tail = child(v1889_6_tail,v1891_6_label);
        if (v1891_6_tail.empty()) continue;
        const Path v1891_6_head{v1891_6_label};
        const Space v1892_2 = singleton(v1891_6_head);
        const Space v1892_3 = intersect(constant_8,v1892_2);
        const Space v1892_4 = (has_head(v1892_3) ? constant_9 : Space{});
        Space v1892_7;
        if (!v1892_4.empty()) {
          const Path v1893_5 = concat_path(v1891_5,v1891_6_head);
          const Space v1893_6 = routine_133(c, v1893_5, p1, v1891_6_tail, s1);
          v1892_7 = compose(v1892_4,v1893_6);
        }
        v1891_6_result = unite(v1891_6_result,v1892_7);
      }
      const Space v1891_6 = std::move(v1891_6_result);
      v1890_7 = compose(v1890_4,v1891_6);
    }
    v1889_6_result = unite(v1889_6_result,v1890_7);
  }
  const Space v1889_6 = std::move(v1889_6_result);
  return v1889_6;
}

static Space routine_225(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1894_5_result;
  for (int v1894_5_label = 1; v1894_5_label <= 2; ++v1894_5_label) {
    const Space v1894_5_tail = child(s0,v1894_5_label);
    if (v1894_5_tail.empty()) continue;
    const Path v1894_5_head{v1894_5_label};
    const Space v1895_2 = singleton(v1894_5_head);
    const Space v1895_3 = intersect(constant_8,v1895_2);
    const Space v1895_4 = (has_head(v1895_3) ? constant_9 : Space{});
    const Space v1895_5 = unwrap(v1894_5_tail,p1);
    const Path v1895_6 = concat_path(p0,v1894_5_head);
    const Space v1895_7 = wrap(v1895_5,v1895_6);
    const Space v1895_8 = compose(v1895_7,s1);
    const Space v1895_9 = compose(v1895_4,v1895_8);
    v1894_5_result = unite(v1894_5_result,v1895_9);
  }
  const Space v1894_5 = std::move(v1894_5_result);
  return v1894_5;
}

static Space routine_226(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1896_6_result;
  for (int v1896_6_label = 1; v1896_6_label <= 2; ++v1896_6_label) {
    const Space v1896_6_tail = child(s0,v1896_6_label);
    if (v1896_6_tail.empty()) continue;
    const Path v1896_6_head{v1896_6_label};
    const Space v1897_2 = singleton(v1896_6_head);
    const Space v1897_3 = intersect(constant_8,v1897_2);
    const Space v1897_4 = (has_head(v1897_3) ? constant_9 : Space{});
    Space v1897_7;
    if (!v1897_4.empty()) {
      const Path v1898_5 = concat_path(p0,v1896_6_head);
      Space v1898_6_result;
      for (int v1898_6_label = 1; v1898_6_label <= 2; ++v1898_6_label) {
        const Space v1898_6_tail = child(v1896_6_tail,v1898_6_label);
        if (v1898_6_tail.empty()) continue;
        const Path v1898_6_head{v1898_6_label};
        const Space v1899_2 = singleton(v1898_6_head);
        const Space v1899_3 = intersect(constant_8,v1899_2);
        const Space v1899_4 = (has_head(v1899_3) ? constant_9 : Space{});
        Space v1899_7;
        if (!v1899_4.empty()) {
          const Path v1900_5 = concat_path(v1898_5,v1898_6_head);
          const Space v1900_6 = routine_138(c, v1900_5, p1, p2, v1898_6_tail);
          v1899_7 = compose(v1899_4,v1900_6);
        }
        v1898_6_result = unite(v1898_6_result,v1899_7);
      }
      const Space v1898_6 = std::move(v1898_6_result);
      v1897_7 = compose(v1897_4,v1898_6);
    }
    v1896_6_result = unite(v1896_6_result,v1897_7);
  }
  const Space v1896_6 = std::move(v1896_6_result);
  return v1896_6;
}

static Space routine_227(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1901_8_result;
  for (int v1901_8_label = 1; v1901_8_label <= 2; ++v1901_8_label) {
    const Space v1901_8_tail = child(s0,v1901_8_label);
    if (v1901_8_tail.empty()) continue;
    const Path v1901_8_head{v1901_8_label};
    const Space v1902_2 = singleton(v1901_8_head);
    const Space v1902_3 = intersect(constant_8,v1902_2);
    const Space v1902_4 = (has_head(v1902_3) ? constant_9 : Space{});
    Space v1902_7;
    if (!v1902_4.empty()) {
      const Path v1903_5 = concat_path(p0,v1901_8_head);
      Space v1903_6_result;
      for (int v1903_6_label = 1; v1903_6_label <= 2; ++v1903_6_label) {
        const Space v1903_6_tail = child(v1901_8_tail,v1903_6_label);
        if (v1903_6_tail.empty()) continue;
        const Path v1903_6_head{v1903_6_label};
        const Space v1904_2 = singleton(v1903_6_head);
        const Space v1904_3 = intersect(constant_8,v1904_2);
        const Space v1904_4 = (has_head(v1904_3) ? constant_9 : Space{});
        const Space v1904_5 = subtract(constant_0,v1904_4);
        Space v1904_7;
        if (!v1904_5.empty()) {
          const Space v1905_6 = routine_182(c, v1903_6_head, p1, p2, v1903_5, v1903_6_tail);
          v1904_7 = compose(v1904_5,v1905_6);
        }
        const Space v1904_8 = intersect(constant_8,v1904_2);
        const Space v1904_9 = (has_head(v1904_8) ? constant_9 : Space{});
        Space v1904_11;
        if (!v1904_9.empty()) {
          const Space v1906_10 = routine_183(c, v1903_6_head, p1, p2, v1903_5, v1903_6_tail);
          v1904_11 = compose(v1904_9,v1906_10);
        }
        const Space v1904_12 = unite(v1904_7,v1904_11);
        v1903_6_result = unite(v1903_6_result,v1904_12);
      }
      const Space v1903_6 = std::move(v1903_6_result);
      v1902_7 = compose(v1902_4,v1903_6);
    }
    v1901_8_result = unite(v1901_8_result,v1902_7);
  }
  const Space v1901_8 = std::move(v1901_8_result);
  return v1901_8;
}

static Space routine_228(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v1907_14_result;
  for (int v1907_14_label = 1; v1907_14_label <= 2; ++v1907_14_label) {
    const Space v1907_14_tail = child(s0,v1907_14_label);
    if (v1907_14_tail.empty()) continue;
    const Path v1907_14_head{v1907_14_label};
    const Space v1908_2 = singleton(v1907_14_head);
    const Space v1908_3 = intersect(constant_8,v1908_2);
    const Space v1908_4 = (has_head(v1908_3) ? constant_9 : Space{});
    const Space v1908_5 = subtract(constant_0,v1908_4);
    Space v1908_8;
    if (!v1908_5.empty()) {
      const Path v1909_6 = concat_path(p0,v1907_14_head);
      Space v1909_7_result;
      for (int v1909_7_label = 1; v1909_7_label <= 2; ++v1909_7_label) {
        const Space v1909_7_tail = child(v1907_14_tail,v1909_7_label);
        if (v1909_7_tail.empty()) continue;
        const Path v1909_7_head{v1909_7_label};
        const Space v1910_2 = singleton(v1909_7_head);
        const Space v1910_3 = intersect(constant_8,v1910_2);
        const Space v1910_4 = (has_head(v1910_3) ? constant_9 : Space{});
        const Space v1910_5 = subtract(constant_0,v1910_4);
        Space v1910_8;
        if (!v1910_5.empty()) {
          const Path v1911_6 = concat_path(v1909_6,v1909_7_head);
          const Space v1911_7 = routine_290(c, v1911_6, p1, p2, p3, v1909_7_tail);
          v1910_8 = compose(v1910_5,v1911_7);
        }
        const Space v1910_9 = intersect(constant_8,v1910_2);
        const Space v1910_10 = (has_head(v1910_9) ? constant_9 : Space{});
        Space v1910_12;
        if (!v1910_10.empty()) {
          const Path v1912_6 = concat_path(v1909_6,v1909_7_head);
          const Space v1912_11 = routine_291(c, v1912_6, p1, p2, p3, v1909_7_tail);
          v1910_12 = compose(v1910_10,v1912_11);
        }
        const Space v1910_13 = unite(v1910_8,v1910_12);
        v1909_7_result = unite(v1909_7_result,v1910_13);
      }
      const Space v1909_7 = std::move(v1909_7_result);
      v1908_8 = compose(v1908_5,v1909_7);
    }
    const Space v1908_9 = intersect(constant_8,v1908_2);
    const Space v1908_10 = (has_head(v1908_9) ? constant_9 : Space{});
    Space v1908_12;
    if (!v1908_10.empty()) {
      const Path v1913_6 = concat_path(p0,v1907_14_head);
      Space v1913_11_result;
      for (int v1913_11_label = 1; v1913_11_label <= 2; ++v1913_11_label) {
        const Space v1913_11_tail = child(v1907_14_tail,v1913_11_label);
        if (v1913_11_tail.empty()) continue;
        const Path v1913_11_head{v1913_11_label};
        const Space v1914_2 = singleton(v1913_11_head);
        const Space v1914_3 = intersect(constant_8,v1914_2);
        const Space v1914_4 = (has_head(v1914_3) ? constant_9 : Space{});
        const Space v1914_5 = subtract(constant_0,v1914_4);
        Space v1914_8;
        if (!v1914_5.empty()) {
          const Path v1915_6 = concat_path(v1913_6,v1913_11_head);
          const Space v1915_7 = routine_290(c, v1915_6, p1, p2, p3, v1913_11_tail);
          v1914_8 = compose(v1914_5,v1915_7);
        }
        const Space v1914_9 = intersect(constant_8,v1914_2);
        const Space v1914_10 = (has_head(v1914_9) ? constant_9 : Space{});
        Space v1914_12;
        if (!v1914_10.empty()) {
          const Path v1916_6 = concat_path(v1913_6,v1913_11_head);
          const Space v1916_11 = routine_230(c, v1916_6, p1, p2, p3, v1913_11_tail);
          v1914_12 = compose(v1914_10,v1916_11);
        }
        const Space v1914_13 = unite(v1914_8,v1914_12);
        v1913_11_result = unite(v1913_11_result,v1914_13);
      }
      const Space v1913_11 = std::move(v1913_11_result);
      v1908_12 = compose(v1908_10,v1913_11);
    }
    const Space v1908_13 = unite(v1908_8,v1908_12);
    v1907_14_result = unite(v1907_14_result,v1908_13);
  }
  const Space v1907_14 = std::move(v1907_14_result);
  return v1907_14;
}

static Space routine_229(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v1917_15_result;
  for (int v1917_15_label = 1; v1917_15_label <= 2; ++v1917_15_label) {
    const Space v1917_15_tail = child(s0,v1917_15_label);
    if (v1917_15_tail.empty()) continue;
    const Path v1917_15_head{v1917_15_label};
    const Space v1918_2 = singleton(v1917_15_head);
    const Space v1918_3 = intersect(constant_8,v1918_2);
    const Space v1918_4 = (has_head(v1918_3) ? constant_9 : Space{});
    const Space v1918_5 = subtract(constant_0,v1918_4);
    Space v1918_8;
    if (!v1918_5.empty()) {
      const Path v1919_6 = concat_path(p0,v1917_15_head);
      Space v1919_7_result;
      for (int v1919_7_label = 1; v1919_7_label <= 2; ++v1919_7_label) {
        const Space v1919_7_tail = child(v1917_15_tail,v1919_7_label);
        if (v1919_7_tail.empty()) continue;
        const Path v1919_7_head{v1919_7_label};
        const Space v1920_2 = singleton(v1919_7_head);
        const Space v1920_3 = intersect(constant_8,v1920_2);
        const Space v1920_4 = (has_head(v1920_3) ? constant_9 : Space{});
        const Space v1920_5 = subtract(constant_0,v1920_4);
        Space v1920_8;
        if (!v1920_5.empty()) {
          const Path v1921_6 = concat_path(v1919_6,v1919_7_head);
          const Space v1921_7 = routine_290(c, v1921_6, p1, p2, p3, v1919_7_tail);
          v1920_8 = compose(v1920_5,v1921_7);
        }
        const Space v1920_9 = intersect(constant_8,v1920_2);
        const Space v1920_10 = (has_head(v1920_9) ? constant_9 : Space{});
        Space v1920_12;
        if (!v1920_10.empty()) {
          const Path v1922_6 = concat_path(v1919_6,v1919_7_head);
          const Space v1922_11 = routine_291(c, v1922_6, p1, p2, p3, v1919_7_tail);
          v1920_12 = compose(v1920_10,v1922_11);
        }
        const Space v1920_13 = unite(v1920_8,v1920_12);
        v1919_7_result = unite(v1919_7_result,v1920_13);
      }
      const Space v1919_7 = std::move(v1919_7_result);
      v1918_8 = compose(v1918_5,v1919_7);
    }
    const Space v1918_9 = intersect(constant_8,v1918_2);
    const Space v1918_10 = (has_head(v1918_9) ? constant_9 : Space{});
    Space v1918_19;
    if (!v1918_10.empty()) {
      const Path v1923_6 = concat_path(p0,v1917_15_head);
      Space v1923_11_result;
      for (int v1923_11_label = 1; v1923_11_label <= 2; ++v1923_11_label) {
        const Space v1923_11_tail = child(v1917_15_tail,v1923_11_label);
        if (v1923_11_tail.empty()) continue;
        const Path v1923_11_head{v1923_11_label};
        const Space v1924_2 = singleton(v1923_11_head);
        const Space v1924_3 = intersect(constant_8,v1924_2);
        const Space v1924_4 = (has_head(v1924_3) ? constant_9 : Space{});
        const Space v1924_5 = subtract(constant_0,v1924_4);
        Space v1924_7;
        if (!v1924_5.empty()) {
          const Space v1925_6 = routine_265(c, v1923_11_head, v1923_11_tail);
          v1924_7 = compose(v1924_5,v1925_6);
        }
        const Space v1924_8 = intersect(constant_8,v1924_2);
        const Space v1924_9 = (has_head(v1924_8) ? constant_9 : Space{});
        Space v1924_11;
        if (!v1924_9.empty()) {
          const Space v1926_10 = routine_266(c, v1923_11_head, v1923_11_tail);
          v1924_11 = compose(v1924_9,v1926_10);
        }
        const Space v1924_12 = unite(v1924_7,v1924_11);
        v1923_11_result = unite(v1923_11_result,v1924_12);
      }
      const Space v1923_11 = std::move(v1923_11_result);
      const Space v1923_12 = raffine(constant_25,v1923_11);
      const Space v1923_13 = unite(v1923_12,v1917_15_tail);
      const Path v1923_14 = concat_path(p3,v1923_6);
      const Space v1923_15 = wrap(v1923_13,v1923_14);
      const Space v1923_16 = unwrap(v1923_15,p1);
      const Space v1923_17 = unwrap(v1923_16,p2);
      const Space v1923_18 = unwrap(v1923_17,p1);
      v1918_19 = compose(v1918_10,v1923_18);
    }
    const Space v1918_20 = unite(v1918_8,v1918_19);
    v1917_15_result = unite(v1917_15_result,v1918_20);
  }
  const Space v1917_15 = std::move(v1917_15_result);
  return v1917_15;
}

static Space routine_230(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v1927_15_result;
  for (int v1927_15_label = 1; v1927_15_label <= 2; ++v1927_15_label) {
    const Space v1927_15_tail = child(s0,v1927_15_label);
    if (v1927_15_tail.empty()) continue;
    const Path v1927_15_head{v1927_15_label};
    const Space v1928_2 = singleton(v1927_15_head);
    const Space v1928_3 = intersect(constant_8,v1928_2);
    const Space v1928_4 = (has_head(v1928_3) ? constant_9 : Space{});
    const Space v1928_5 = subtract(constant_0,v1928_4);
    Space v1928_7;
    if (!v1928_5.empty()) {
      Space v1929_6_result;
      for (int v1929_6_label = 1; v1929_6_label <= 2; ++v1929_6_label) {
        const Space v1929_6_tail = child(v1927_15_tail,v1929_6_label);
        if (v1929_6_tail.empty()) continue;
        const Path v1929_6_head{v1929_6_label};
        const Space v1930_2 = singleton(v1929_6_head);
        const Space v1930_3 = intersect(constant_8,v1930_2);
        const Space v1930_4 = (has_head(v1930_3) ? constant_9 : Space{});
        const Space v1930_5 = subtract(constant_0,v1930_4);
        Space v1930_8;
        if (!v1930_5.empty()) {
          const Path v1931_6 = concat_path(v1927_15_head,v1929_6_head);
          const Space v1931_7 = routine_292(c, v1931_6, v1929_6_tail);
          v1930_8 = compose(v1930_5,v1931_7);
        }
        const Space v1930_9 = intersect(constant_8,v1930_2);
        const Space v1930_10 = (has_head(v1930_9) ? constant_9 : Space{});
        Space v1930_12;
        if (!v1930_10.empty()) {
          const Path v1932_6 = concat_path(v1927_15_head,v1929_6_head);
          const Space v1932_11 = routine_293(c, v1932_6, v1929_6_tail);
          v1930_12 = compose(v1930_10,v1932_11);
        }
        const Space v1930_13 = unite(v1930_8,v1930_12);
        v1929_6_result = unite(v1929_6_result,v1930_13);
      }
      const Space v1929_6 = std::move(v1929_6_result);
      v1928_7 = compose(v1928_5,v1929_6);
    }
    const Space v1928_8 = intersect(constant_8,v1928_2);
    const Space v1928_9 = (has_head(v1928_8) ? constant_9 : Space{});
    Space v1928_11;
    if (!v1928_9.empty()) {
      Space v1933_10_result;
      for (int v1933_10_label = 1; v1933_10_label <= 2; ++v1933_10_label) {
        const Space v1933_10_tail = child(v1927_15_tail,v1933_10_label);
        if (v1933_10_tail.empty()) continue;
        const Path v1933_10_head{v1933_10_label};
        const Space v1934_2 = singleton(v1933_10_head);
        const Space v1934_3 = intersect(constant_8,v1934_2);
        const Space v1934_4 = (has_head(v1934_3) ? constant_9 : Space{});
        const Space v1934_5 = subtract(constant_0,v1934_4);
        Space v1934_8;
        if (!v1934_5.empty()) {
          const Path v1935_6 = concat_path(v1927_15_head,v1933_10_head);
          const Space v1935_7 = routine_292(c, v1935_6, v1933_10_tail);
          v1934_8 = compose(v1934_5,v1935_7);
        }
        const Space v1934_9 = intersect(constant_8,v1934_2);
        const Space v1934_10 = (has_head(v1934_9) ? constant_9 : Space{});
        Space v1934_12;
        if (!v1934_10.empty()) {
          const Path v1936_6 = concat_path(v1927_15_head,v1933_10_head);
          const Space v1936_11 = routine_294(c, v1936_6, v1933_10_tail);
          v1934_12 = compose(v1934_10,v1936_11);
        }
        const Space v1934_13 = unite(v1934_8,v1934_12);
        v1933_10_result = unite(v1933_10_result,v1934_13);
      }
      const Space v1933_10 = std::move(v1933_10_result);
      v1928_11 = compose(v1928_9,v1933_10);
    }
    const Space v1928_12 = unite(v1928_7,v1928_11);
    v1927_15_result = unite(v1927_15_result,v1928_12);
  }
  const Space v1927_15 = std::move(v1927_15_result);
  const Space v1927_16 = raffine(constant_25,v1927_15);
  const Space v1927_17 = unite(v1927_16,s0);
  const Path v1927_18 = concat_path(p3,p0);
  const Space v1927_19 = wrap(v1927_17,v1927_18);
  const Space v1927_20 = unwrap(v1927_19,p1);
  const Space v1927_21 = unwrap(v1927_20,p2);
  const Space v1927_22 = unwrap(v1927_21,p1);
  return v1927_22;
}

static Space routine_231(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1937_5_result;
  for (int v1937_5_label = 1; v1937_5_label <= 2; ++v1937_5_label) {
    const Space v1937_5_tail = child(s0,v1937_5_label);
    if (v1937_5_tail.empty()) continue;
    const Path v1937_5_head{v1937_5_label};
    const Space v1938_2 = singleton(v1937_5_head);
    const Space v1938_3 = intersect(constant_8,v1938_2);
    const Space v1938_4 = (has_head(v1938_3) ? constant_9 : Space{});
    Space v1938_7;
    if (!v1938_4.empty()) {
      const Path v1939_5 = concat_path(p0,v1937_5_head);
      Space v1939_6_result;
      for (int v1939_6_label = 1; v1939_6_label <= 2; ++v1939_6_label) {
        const Space v1939_6_tail = child(v1937_5_tail,v1939_6_label);
        if (v1939_6_tail.empty()) continue;
        const Path v1939_6_head{v1939_6_label};
        const Space v1940_2 = singleton(v1939_6_head);
        const Space v1940_3 = intersect(constant_8,v1940_2);
        const Space v1940_4 = (has_head(v1940_3) ? constant_9 : Space{});
        Space v1940_7;
        if (!v1940_4.empty()) {
          const Path v1941_5 = concat_path(v1939_5,v1939_6_head);
          const Space v1941_6 = routine_141(c, v1941_5, v1939_6_tail, s1);
          v1940_7 = compose(v1940_4,v1941_6);
        }
        v1939_6_result = unite(v1939_6_result,v1940_7);
      }
      const Space v1939_6 = std::move(v1939_6_result);
      v1938_7 = compose(v1938_4,v1939_6);
    }
    v1937_5_result = unite(v1937_5_result,v1938_7);
  }
  const Space v1937_5 = std::move(v1937_5_result);
  return v1937_5;
}

static Space routine_232(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1942_4_result;
  for (int v1942_4_label = 1; v1942_4_label <= 2; ++v1942_4_label) {
    const Space v1942_4_tail = child(s0,v1942_4_label);
    if (v1942_4_tail.empty()) continue;
    const Path v1942_4_head{v1942_4_label};
    const Space v1943_2 = singleton(v1942_4_head);
    const Space v1943_3 = intersect(constant_8,v1943_2);
    const Space v1943_4 = (has_head(v1943_3) ? constant_9 : Space{});
    Space v1943_7;
    if (!v1943_4.empty()) {
      const Path v1944_5 = concat_path(p0,v1942_4_head);
      const Space v1944_6 = routine_186(c, v1944_5, s1);
      v1943_7 = compose(v1943_4,v1944_6);
    }
    v1942_4_result = unite(v1942_4_result,v1943_7);
  }
  const Space v1942_4 = std::move(v1942_4_result);
  return v1942_4;
}

static Space routine_233(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1945_5_result;
  for (int v1945_5_label = 1; v1945_5_label <= 2; ++v1945_5_label) {
    const Space v1945_5_tail = child(s0,v1945_5_label);
    if (v1945_5_tail.empty()) continue;
    const Path v1945_5_head{v1945_5_label};
    const Space v1946_2 = singleton(v1945_5_head);
    const Space v1946_3 = intersect(constant_8,v1946_2);
    const Space v1946_4 = (has_head(v1946_3) ? constant_9 : Space{});
    Space v1946_7;
    if (!v1946_4.empty()) {
      const Path v1947_5 = concat_path(p0,v1945_5_head);
      Space v1947_6_result;
      for (int v1947_6_label = 1; v1947_6_label <= 2; ++v1947_6_label) {
        const Space v1947_6_tail = child(v1945_5_tail,v1947_6_label);
        if (v1947_6_tail.empty()) continue;
        const Path v1947_6_head{v1947_6_label};
        const Space v1948_2 = singleton(v1947_6_head);
        const Space v1948_3 = intersect(constant_8,v1948_2);
        const Space v1948_4 = (has_head(v1948_3) ? constant_9 : Space{});
        Space v1948_7;
        if (!v1948_4.empty()) {
          const Path v1949_5 = concat_path(v1947_5,v1947_6_head);
          const Space v1949_6 = routine_148(c, v1949_5, p1, v1947_6_tail);
          v1948_7 = compose(v1948_4,v1949_6);
        }
        v1947_6_result = unite(v1947_6_result,v1948_7);
      }
      const Space v1947_6 = std::move(v1947_6_result);
      v1946_7 = compose(v1946_4,v1947_6);
    }
    v1945_5_result = unite(v1945_5_result,v1946_7);
  }
  const Space v1945_5 = std::move(v1945_5_result);
  return v1945_5;
}

static Space routine_234(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1950_7_result;
  for (int v1950_7_label = 1; v1950_7_label <= 2; ++v1950_7_label) {
    const Space v1950_7_tail = child(s0,v1950_7_label);
    if (v1950_7_tail.empty()) continue;
    const Path v1950_7_head{v1950_7_label};
    const Space v1951_2 = singleton(v1950_7_head);
    const Space v1951_3 = intersect(constant_8,v1951_2);
    const Space v1951_4 = (has_head(v1951_3) ? constant_9 : Space{});
    Space v1951_7;
    if (!v1951_4.empty()) {
      const Path v1952_5 = concat_path(p0,v1950_7_head);
      Space v1952_6_result;
      for (int v1952_6_label = 1; v1952_6_label <= 2; ++v1952_6_label) {
        const Space v1952_6_tail = child(v1950_7_tail,v1952_6_label);
        if (v1952_6_tail.empty()) continue;
        const Path v1952_6_head{v1952_6_label};
        const Space v1953_2 = singleton(v1952_6_head);
        const Space v1953_3 = intersect(constant_8,v1953_2);
        const Space v1953_4 = (has_head(v1953_3) ? constant_9 : Space{});
        const Space v1953_5 = subtract(constant_0,v1953_4);
        Space v1953_7;
        if (!v1953_5.empty()) {
          const Space v1954_6 = routine_193(c, v1952_6_head, p1, v1952_5, v1952_6_tail);
          v1953_7 = compose(v1953_5,v1954_6);
        }
        const Space v1953_8 = intersect(constant_8,v1953_2);
        const Space v1953_9 = (has_head(v1953_8) ? constant_9 : Space{});
        Space v1953_11;
        if (!v1953_9.empty()) {
          const Space v1955_10 = routine_194(c, v1952_6_head, p1, v1952_5, v1952_6_tail);
          v1953_11 = compose(v1953_9,v1955_10);
        }
        const Space v1953_12 = unite(v1953_7,v1953_11);
        v1952_6_result = unite(v1952_6_result,v1953_12);
      }
      const Space v1952_6 = std::move(v1952_6_result);
      v1951_7 = compose(v1951_4,v1952_6);
    }
    v1950_7_result = unite(v1950_7_result,v1951_7);
  }
  const Space v1950_7 = std::move(v1950_7_result);
  return v1950_7;
}

static Space routine_235(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1956_13_result;
  for (int v1956_13_label = 1; v1956_13_label <= 2; ++v1956_13_label) {
    const Space v1956_13_tail = child(s0,v1956_13_label);
    if (v1956_13_tail.empty()) continue;
    const Path v1956_13_head{v1956_13_label};
    const Space v1957_2 = singleton(v1956_13_head);
    const Space v1957_3 = intersect(constant_8,v1957_2);
    const Space v1957_4 = (has_head(v1957_3) ? constant_9 : Space{});
    const Space v1957_5 = subtract(constant_0,v1957_4);
    Space v1957_8;
    if (!v1957_5.empty()) {
      const Path v1958_6 = concat_path(p0,v1956_13_head);
      Space v1958_7_result;
      for (int v1958_7_label = 1; v1958_7_label <= 2; ++v1958_7_label) {
        const Space v1958_7_tail = child(v1956_13_tail,v1958_7_label);
        if (v1958_7_tail.empty()) continue;
        const Path v1958_7_head{v1958_7_label};
        const Space v1959_2 = singleton(v1958_7_head);
        const Space v1959_3 = intersect(constant_8,v1959_2);
        const Space v1959_4 = (has_head(v1959_3) ? constant_9 : Space{});
        const Space v1959_5 = subtract(constant_0,v1959_4);
        Space v1959_8;
        if (!v1959_5.empty()) {
          const Path v1960_6 = concat_path(v1958_6,v1958_7_head);
          const Space v1960_7 = routine_295(c, v1960_6, p1, p2, v1958_7_tail);
          v1959_8 = compose(v1959_5,v1960_7);
        }
        const Space v1959_9 = intersect(constant_8,v1959_2);
        const Space v1959_10 = (has_head(v1959_9) ? constant_9 : Space{});
        Space v1959_12;
        if (!v1959_10.empty()) {
          const Path v1961_6 = concat_path(v1958_6,v1958_7_head);
          const Space v1961_11 = routine_296(c, v1961_6, p1, p2, v1958_7_tail);
          v1959_12 = compose(v1959_10,v1961_11);
        }
        const Space v1959_13 = unite(v1959_8,v1959_12);
        v1958_7_result = unite(v1958_7_result,v1959_13);
      }
      const Space v1958_7 = std::move(v1958_7_result);
      v1957_8 = compose(v1957_5,v1958_7);
    }
    const Space v1957_9 = intersect(constant_8,v1957_2);
    const Space v1957_10 = (has_head(v1957_9) ? constant_9 : Space{});
    Space v1957_12;
    if (!v1957_10.empty()) {
      const Path v1962_6 = concat_path(p0,v1956_13_head);
      Space v1962_11_result;
      for (int v1962_11_label = 1; v1962_11_label <= 2; ++v1962_11_label) {
        const Space v1962_11_tail = child(v1956_13_tail,v1962_11_label);
        if (v1962_11_tail.empty()) continue;
        const Path v1962_11_head{v1962_11_label};
        const Space v1963_2 = singleton(v1962_11_head);
        const Space v1963_3 = intersect(constant_8,v1963_2);
        const Space v1963_4 = (has_head(v1963_3) ? constant_9 : Space{});
        const Space v1963_5 = subtract(constant_0,v1963_4);
        Space v1963_8;
        if (!v1963_5.empty()) {
          const Path v1964_6 = concat_path(v1962_6,v1962_11_head);
          const Space v1964_7 = routine_295(c, v1964_6, p1, p2, v1962_11_tail);
          v1963_8 = compose(v1963_5,v1964_7);
        }
        const Space v1963_9 = intersect(constant_8,v1963_2);
        const Space v1963_10 = (has_head(v1963_9) ? constant_9 : Space{});
        Space v1963_12;
        if (!v1963_10.empty()) {
          const Path v1965_6 = concat_path(v1962_6,v1962_11_head);
          const Space v1965_11 = routine_237(c, v1965_6, p1, p2, v1962_11_tail);
          v1963_12 = compose(v1963_10,v1965_11);
        }
        const Space v1963_13 = unite(v1963_8,v1963_12);
        v1962_11_result = unite(v1962_11_result,v1963_13);
      }
      const Space v1962_11 = std::move(v1962_11_result);
      v1957_12 = compose(v1957_10,v1962_11);
    }
    const Space v1957_13 = unite(v1957_8,v1957_12);
    v1956_13_result = unite(v1956_13_result,v1957_13);
  }
  const Space v1956_13 = std::move(v1956_13_result);
  return v1956_13;
}

static Space routine_236(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1966_9 = concat_path(constant_23,p2);
  const Space v1966_10 = singleton(v1966_9);
  const Space v1966_11 = unite(constant_26,v1966_10);
  const Path v1966_13 = concat_path(constant_22,p1);
  const Space v1966_14 = singleton(v1966_13);
  const Space v1966_15 = unite(v1966_11,v1966_14);
  Space v1966_20_result;
  for (int v1966_20_label = 1; v1966_20_label <= 2; ++v1966_20_label) {
    const Space v1966_20_tail = child(s0,v1966_20_label);
    if (v1966_20_tail.empty()) continue;
    const Path v1966_20_head{v1966_20_label};
    const Space v1967_2 = singleton(v1966_20_head);
    const Space v1967_3 = intersect(constant_8,v1967_2);
    const Space v1967_4 = (has_head(v1967_3) ? constant_9 : Space{});
    const Space v1967_5 = subtract(constant_0,v1967_4);
    Space v1967_8;
    if (!v1967_5.empty()) {
      const Path v1968_6 = concat_path(p0,v1966_20_head);
      Space v1968_7_result;
      for (int v1968_7_label = 1; v1968_7_label <= 2; ++v1968_7_label) {
        const Space v1968_7_tail = child(v1966_20_tail,v1968_7_label);
        if (v1968_7_tail.empty()) continue;
        const Path v1968_7_head{v1968_7_label};
        const Space v1969_2 = singleton(v1968_7_head);
        const Space v1969_3 = intersect(constant_8,v1969_2);
        const Space v1969_4 = (has_head(v1969_3) ? constant_9 : Space{});
        const Space v1969_5 = subtract(constant_0,v1969_4);
        Space v1969_8;
        if (!v1969_5.empty()) {
          const Path v1970_6 = concat_path(v1968_6,v1968_7_head);
          const Space v1970_7 = routine_295(c, v1970_6, p1, p2, v1968_7_tail);
          v1969_8 = compose(v1969_5,v1970_7);
        }
        const Space v1969_9 = intersect(constant_8,v1969_2);
        const Space v1969_10 = (has_head(v1969_9) ? constant_9 : Space{});
        Space v1969_12;
        if (!v1969_10.empty()) {
          const Path v1971_6 = concat_path(v1968_6,v1968_7_head);
          const Space v1971_11 = routine_296(c, v1971_6, p1, p2, v1968_7_tail);
          v1969_12 = compose(v1969_10,v1971_11);
        }
        const Space v1969_13 = unite(v1969_8,v1969_12);
        v1968_7_result = unite(v1968_7_result,v1969_13);
      }
      const Space v1968_7 = std::move(v1968_7_result);
      v1967_8 = compose(v1967_5,v1968_7);
    }
    const Space v1967_9 = intersect(constant_8,v1967_2);
    const Space v1967_10 = (has_head(v1967_9) ? constant_9 : Space{});
    const Path v1972_6 = concat_path(p0,v1966_20_head);
    const Path v1967_11 = concat_path(constant_6,v1972_6);
    const Space v1967_12 = singleton(v1967_11);
    const Space v1967_13 = unite(v1966_15,v1967_12);
    const Space v1967_14 = compose(v1967_10,v1967_13);
    const Space v1967_15 = unite(v1967_8,v1967_14);
    v1966_20_result = unite(v1966_20_result,v1967_15);
  }
  const Space v1966_20 = std::move(v1966_20_result);
  return v1966_20;
}

static Space routine_237(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1973_6 = concat_path(constant_23,p2);
  const Space v1973_7 = singleton(v1973_6);
  const Space v1973_8 = unite(constant_26,v1973_7);
  const Path v1973_10 = concat_path(constant_22,p1);
  const Space v1973_11 = singleton(v1973_10);
  const Space v1973_12 = unite(v1973_8,v1973_11);
  const Path v1973_14 = concat_path(constant_6,p0);
  const Space v1973_15 = singleton(v1973_14);
  const Space v1973_16 = unite(v1973_12,v1973_15);
  return v1973_16;
}

static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1974_5_result;
  for (int v1974_5_label = 1; v1974_5_label <= 2; ++v1974_5_label) {
    const Space v1974_5_tail = child(s0,v1974_5_label);
    if (v1974_5_tail.empty()) continue;
    const Path v1974_5_head{v1974_5_label};
    const Space v1975_2 = singleton(v1974_5_head);
    const Space v1975_3 = intersect(constant_8,v1975_2);
    const Space v1975_4 = (has_head(v1975_3) ? constant_9 : Space{});
    Space v1975_7;
    if (!v1975_4.empty()) {
      const Path v1976_5 = concat_path(p0,v1974_5_head);
      Space v1976_6_result;
      for (int v1976_6_label = 1; v1976_6_label <= 2; ++v1976_6_label) {
        const Space v1976_6_tail = child(v1974_5_tail,v1976_6_label);
        if (v1976_6_tail.empty()) continue;
        const Path v1976_6_head{v1976_6_label};
        const Space v1977_2 = singleton(v1976_6_head);
        const Space v1977_3 = intersect(constant_8,v1977_2);
        const Space v1977_4 = (has_head(v1977_3) ? constant_9 : Space{});
        Space v1977_7;
        if (!v1977_4.empty()) {
          const Path v1978_5 = concat_path(v1976_5,v1976_6_head);
          const Space v1978_6 = routine_155(c, v1978_5, p1, v1976_6_tail);
          v1977_7 = compose(v1977_4,v1978_6);
        }
        v1976_6_result = unite(v1976_6_result,v1977_7);
      }
      const Space v1976_6 = std::move(v1976_6_result);
      v1975_7 = compose(v1975_4,v1976_6);
    }
    v1974_5_result = unite(v1974_5_result,v1975_7);
  }
  const Space v1974_5 = std::move(v1974_5_result);
  return v1974_5;
}

static Space routine_239(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1979_7_result;
  for (int v1979_7_label = 1; v1979_7_label <= 2; ++v1979_7_label) {
    const Space v1979_7_tail = child(s0,v1979_7_label);
    if (v1979_7_tail.empty()) continue;
    const Path v1979_7_head{v1979_7_label};
    const Space v1980_2 = singleton(v1979_7_head);
    const Space v1980_3 = intersect(constant_8,v1980_2);
    const Space v1980_4 = (has_head(v1980_3) ? constant_9 : Space{});
    Space v1980_7;
    if (!v1980_4.empty()) {
      const Path v1981_5 = concat_path(p0,v1979_7_head);
      Space v1981_6_result;
      for (int v1981_6_label = 1; v1981_6_label <= 2; ++v1981_6_label) {
        const Space v1981_6_tail = child(v1979_7_tail,v1981_6_label);
        if (v1981_6_tail.empty()) continue;
        const Path v1981_6_head{v1981_6_label};
        const Space v1982_2 = singleton(v1981_6_head);
        const Space v1982_3 = intersect(constant_8,v1982_2);
        const Space v1982_4 = (has_head(v1982_3) ? constant_9 : Space{});
        const Space v1982_5 = subtract(constant_0,v1982_4);
        Space v1982_7;
        if (!v1982_5.empty()) {
          const Space v1983_6 = routine_201(c, v1981_6_head, p1, v1981_5, v1981_6_tail);
          v1982_7 = compose(v1982_5,v1983_6);
        }
        const Space v1982_8 = intersect(constant_8,v1982_2);
        const Space v1982_9 = (has_head(v1982_8) ? constant_9 : Space{});
        Space v1982_11;
        if (!v1982_9.empty()) {
          const Space v1984_10 = routine_202(c, v1981_6_head, p1, v1981_5, v1981_6_tail);
          v1982_11 = compose(v1982_9,v1984_10);
        }
        const Space v1982_12 = unite(v1982_7,v1982_11);
        v1981_6_result = unite(v1981_6_result,v1982_12);
      }
      const Space v1981_6 = std::move(v1981_6_result);
      v1980_7 = compose(v1980_4,v1981_6);
    }
    v1979_7_result = unite(v1979_7_result,v1980_7);
  }
  const Space v1979_7 = std::move(v1979_7_result);
  return v1979_7;
}

static Space routine_240(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1985_13_result;
  for (int v1985_13_label = 1; v1985_13_label <= 2; ++v1985_13_label) {
    const Space v1985_13_tail = child(s0,v1985_13_label);
    if (v1985_13_tail.empty()) continue;
    const Path v1985_13_head{v1985_13_label};
    const Space v1986_2 = singleton(v1985_13_head);
    const Space v1986_3 = intersect(constant_8,v1986_2);
    const Space v1986_4 = (has_head(v1986_3) ? constant_9 : Space{});
    const Space v1986_5 = subtract(constant_0,v1986_4);
    Space v1986_8;
    if (!v1986_5.empty()) {
      const Path v1987_6 = concat_path(p0,v1985_13_head);
      Space v1987_7_result;
      for (int v1987_7_label = 1; v1987_7_label <= 2; ++v1987_7_label) {
        const Space v1987_7_tail = child(v1985_13_tail,v1987_7_label);
        if (v1987_7_tail.empty()) continue;
        const Path v1987_7_head{v1987_7_label};
        const Space v1988_2 = singleton(v1987_7_head);
        const Space v1988_3 = intersect(constant_8,v1988_2);
        const Space v1988_4 = (has_head(v1988_3) ? constant_9 : Space{});
        const Space v1988_5 = subtract(constant_0,v1988_4);
        Space v1988_8;
        if (!v1988_5.empty()) {
          const Path v1989_6 = concat_path(v1987_6,v1987_7_head);
          const Space v1989_7 = routine_297(c, v1989_6, p1, p2, v1987_7_tail);
          v1988_8 = compose(v1988_5,v1989_7);
        }
        const Space v1988_9 = intersect(constant_8,v1988_2);
        const Space v1988_10 = (has_head(v1988_9) ? constant_9 : Space{});
        Space v1988_12;
        if (!v1988_10.empty()) {
          const Path v1990_6 = concat_path(v1987_6,v1987_7_head);
          const Space v1990_11 = routine_298(c, v1990_6, p1, p2, v1987_7_tail);
          v1988_12 = compose(v1988_10,v1990_11);
        }
        const Space v1988_13 = unite(v1988_8,v1988_12);
        v1987_7_result = unite(v1987_7_result,v1988_13);
      }
      const Space v1987_7 = std::move(v1987_7_result);
      v1986_8 = compose(v1986_5,v1987_7);
    }
    const Space v1986_9 = intersect(constant_8,v1986_2);
    const Space v1986_10 = (has_head(v1986_9) ? constant_9 : Space{});
    Space v1986_12;
    if (!v1986_10.empty()) {
      const Path v1991_6 = concat_path(p0,v1985_13_head);
      Space v1991_11_result;
      for (int v1991_11_label = 1; v1991_11_label <= 2; ++v1991_11_label) {
        const Space v1991_11_tail = child(v1985_13_tail,v1991_11_label);
        if (v1991_11_tail.empty()) continue;
        const Path v1991_11_head{v1991_11_label};
        const Space v1992_2 = singleton(v1991_11_head);
        const Space v1992_3 = intersect(constant_8,v1992_2);
        const Space v1992_4 = (has_head(v1992_3) ? constant_9 : Space{});
        const Space v1992_5 = subtract(constant_0,v1992_4);
        Space v1992_8;
        if (!v1992_5.empty()) {
          const Path v1993_6 = concat_path(v1991_6,v1991_11_head);
          const Space v1993_7 = routine_297(c, v1993_6, p1, p2, v1991_11_tail);
          v1992_8 = compose(v1992_5,v1993_7);
        }
        const Space v1992_9 = intersect(constant_8,v1992_2);
        const Space v1992_10 = (has_head(v1992_9) ? constant_9 : Space{});
        Space v1992_12;
        if (!v1992_10.empty()) {
          const Path v1994_6 = concat_path(v1991_6,v1991_11_head);
          const Space v1994_11 = routine_242(c, v1994_6, p1, p2, v1991_11_tail);
          v1992_12 = compose(v1992_10,v1994_11);
        }
        const Space v1992_13 = unite(v1992_8,v1992_12);
        v1991_11_result = unite(v1991_11_result,v1992_13);
      }
      const Space v1991_11 = std::move(v1991_11_result);
      v1986_12 = compose(v1986_10,v1991_11);
    }
    const Space v1986_13 = unite(v1986_8,v1986_12);
    v1985_13_result = unite(v1985_13_result,v1986_13);
  }
  const Space v1985_13 = std::move(v1985_13_result);
  return v1985_13;
}

static Space routine_241(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1995_10 = concat_path(constant_22,p1);
  const Space v1995_11 = singleton(v1995_10);
  const Path v1995_13 = concat_path(constant_6,p2);
  const Space v1995_14 = singleton(v1995_13);
  Space v1995_18_result;
  for (int v1995_18_label = 1; v1995_18_label <= 2; ++v1995_18_label) {
    const Space v1995_18_tail = child(s0,v1995_18_label);
    if (v1995_18_tail.empty()) continue;
    const Path v1995_18_head{v1995_18_label};
    const Space v1996_2 = singleton(v1995_18_head);
    const Space v1996_3 = intersect(constant_8,v1996_2);
    const Space v1996_4 = (has_head(v1996_3) ? constant_9 : Space{});
    const Space v1996_5 = subtract(constant_0,v1996_4);
    Space v1996_8;
    if (!v1996_5.empty()) {
      const Path v1997_6 = concat_path(p0,v1995_18_head);
      Space v1997_7_result;
      for (int v1997_7_label = 1; v1997_7_label <= 2; ++v1997_7_label) {
        const Space v1997_7_tail = child(v1995_18_tail,v1997_7_label);
        if (v1997_7_tail.empty()) continue;
        const Path v1997_7_head{v1997_7_label};
        const Space v1998_2 = singleton(v1997_7_head);
        const Space v1998_3 = intersect(constant_8,v1998_2);
        const Space v1998_4 = (has_head(v1998_3) ? constant_9 : Space{});
        const Space v1998_5 = subtract(constant_0,v1998_4);
        Space v1998_8;
        if (!v1998_5.empty()) {
          const Path v1999_6 = concat_path(v1997_6,v1997_7_head);
          const Space v1999_7 = routine_297(c, v1999_6, p1, p2, v1997_7_tail);
          v1998_8 = compose(v1998_5,v1999_7);
        }
        const Space v1998_9 = intersect(constant_8,v1998_2);
        const Space v1998_10 = (has_head(v1998_9) ? constant_9 : Space{});
        Space v1998_12;
        if (!v1998_10.empty()) {
          const Path v2000_6 = concat_path(v1997_6,v1997_7_head);
          const Space v2000_11 = routine_298(c, v2000_6, p1, p2, v1997_7_tail);
          v1998_12 = compose(v1998_10,v2000_11);
        }
        const Space v1998_13 = unite(v1998_8,v1998_12);
        v1997_7_result = unite(v1997_7_result,v1998_13);
      }
      const Space v1997_7 = std::move(v1997_7_result);
      v1996_8 = compose(v1996_5,v1997_7);
    }
    const Space v1996_9 = intersect(constant_8,v1996_2);
    const Space v1996_10 = (has_head(v1996_9) ? constant_9 : Space{});
    const Path v2001_6 = concat_path(p0,v1995_18_head);
    const Path v1996_11 = concat_path(constant_24,v2001_6);
    const Space v1996_12 = singleton(v1996_11);
    const Space v1996_13 = unite(constant_27,v1996_12);
    const Space v1996_14 = unite(v1996_13,v1995_11);
    const Space v1996_15 = unite(v1996_14,v1995_14);
    const Space v1996_16 = compose(v1996_10,v1996_15);
    const Space v1996_17 = unite(v1996_8,v1996_16);
    v1995_18_result = unite(v1995_18_result,v1996_17);
  }
  const Space v1995_18 = std::move(v1995_18_result);
  return v1995_18;
}

static Space routine_242(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2002_6 = concat_path(constant_24,p0);
  const Space v2002_7 = singleton(v2002_6);
  const Space v2002_8 = unite(constant_27,v2002_7);
  const Path v2002_10 = concat_path(constant_22,p1);
  const Space v2002_11 = singleton(v2002_10);
  const Space v2002_12 = unite(v2002_8,v2002_11);
  const Path v2002_14 = concat_path(constant_6,p2);
  const Space v2002_15 = singleton(v2002_14);
  const Space v2002_16 = unite(v2002_12,v2002_15);
  return v2002_16;
}

static Space routine_243(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2003_5_result;
  for (int v2003_5_label = 1; v2003_5_label <= 2; ++v2003_5_label) {
    const Space v2003_5_tail = child(s0,v2003_5_label);
    if (v2003_5_tail.empty()) continue;
    const Path v2003_5_head{v2003_5_label};
    const Space v2004_2 = singleton(v2003_5_head);
    const Space v2004_3 = intersect(constant_8,v2004_2);
    const Space v2004_4 = (has_head(v2004_3) ? constant_9 : Space{});
    Space v2004_7;
    if (!v2004_4.empty()) {
      const Path v2005_5 = concat_path(p0,v2003_5_head);
      Space v2005_6_result;
      for (int v2005_6_label = 1; v2005_6_label <= 2; ++v2005_6_label) {
        const Space v2005_6_tail = child(v2003_5_tail,v2005_6_label);
        if (v2005_6_tail.empty()) continue;
        const Path v2005_6_head{v2005_6_label};
        const Space v2006_2 = singleton(v2005_6_head);
        const Space v2006_3 = intersect(constant_8,v2006_2);
        const Space v2006_4 = (has_head(v2006_3) ? constant_9 : Space{});
        Space v2006_7;
        if (!v2006_4.empty()) {
          const Path v2007_5 = concat_path(v2005_5,v2005_6_head);
          const Space v2007_6 = routine_162(c, v2007_5, p1, v2005_6_tail);
          v2006_7 = compose(v2006_4,v2007_6);
        }
        v2005_6_result = unite(v2005_6_result,v2006_7);
      }
      const Space v2005_6 = std::move(v2005_6_result);
      v2004_7 = compose(v2004_4,v2005_6);
    }
    v2003_5_result = unite(v2003_5_result,v2004_7);
  }
  const Space v2003_5 = std::move(v2003_5_result);
  return v2003_5;
}

static Space routine_244(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2008_7_result;
  for (int v2008_7_label = 1; v2008_7_label <= 2; ++v2008_7_label) {
    const Space v2008_7_tail = child(s0,v2008_7_label);
    if (v2008_7_tail.empty()) continue;
    const Path v2008_7_head{v2008_7_label};
    const Space v2009_2 = singleton(v2008_7_head);
    const Space v2009_3 = intersect(constant_8,v2009_2);
    const Space v2009_4 = (has_head(v2009_3) ? constant_9 : Space{});
    Space v2009_7;
    if (!v2009_4.empty()) {
      const Path v2010_5 = concat_path(p0,v2008_7_head);
      Space v2010_6_result;
      for (int v2010_6_label = 1; v2010_6_label <= 2; ++v2010_6_label) {
        const Space v2010_6_tail = child(v2008_7_tail,v2010_6_label);
        if (v2010_6_tail.empty()) continue;
        const Path v2010_6_head{v2010_6_label};
        const Space v2011_2 = singleton(v2010_6_head);
        const Space v2011_3 = intersect(constant_8,v2011_2);
        const Space v2011_4 = (has_head(v2011_3) ? constant_9 : Space{});
        const Space v2011_5 = subtract(constant_0,v2011_4);
        Space v2011_7;
        if (!v2011_5.empty()) {
          const Space v2012_6 = routine_209(c, v2010_6_head, p1, v2010_5, v2010_6_tail);
          v2011_7 = compose(v2011_5,v2012_6);
        }
        const Space v2011_8 = intersect(constant_8,v2011_2);
        const Space v2011_9 = (has_head(v2011_8) ? constant_9 : Space{});
        Space v2011_11;
        if (!v2011_9.empty()) {
          const Space v2013_10 = routine_210(c, v2010_6_head, p1, v2010_5, v2010_6_tail);
          v2011_11 = compose(v2011_9,v2013_10);
        }
        const Space v2011_12 = unite(v2011_7,v2011_11);
        v2010_6_result = unite(v2010_6_result,v2011_12);
      }
      const Space v2010_6 = std::move(v2010_6_result);
      v2009_7 = compose(v2009_4,v2010_6);
    }
    v2008_7_result = unite(v2008_7_result,v2009_7);
  }
  const Space v2008_7 = std::move(v2008_7_result);
  return v2008_7;
}

static Space routine_245(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2014_13_result;
  for (int v2014_13_label = 1; v2014_13_label <= 2; ++v2014_13_label) {
    const Space v2014_13_tail = child(s0,v2014_13_label);
    if (v2014_13_tail.empty()) continue;
    const Path v2014_13_head{v2014_13_label};
    const Space v2015_2 = singleton(v2014_13_head);
    const Space v2015_3 = intersect(constant_8,v2015_2);
    const Space v2015_4 = (has_head(v2015_3) ? constant_9 : Space{});
    const Space v2015_5 = subtract(constant_0,v2015_4);
    Space v2015_8;
    if (!v2015_5.empty()) {
      const Path v2016_6 = concat_path(p0,v2014_13_head);
      Space v2016_7_result;
      for (int v2016_7_label = 1; v2016_7_label <= 2; ++v2016_7_label) {
        const Space v2016_7_tail = child(v2014_13_tail,v2016_7_label);
        if (v2016_7_tail.empty()) continue;
        const Path v2016_7_head{v2016_7_label};
        const Space v2017_2 = singleton(v2016_7_head);
        const Space v2017_3 = intersect(constant_8,v2017_2);
        const Space v2017_4 = (has_head(v2017_3) ? constant_9 : Space{});
        const Space v2017_5 = subtract(constant_0,v2017_4);
        Space v2017_8;
        if (!v2017_5.empty()) {
          const Path v2018_6 = concat_path(v2016_6,v2016_7_head);
          const Space v2018_7 = routine_299(c, v2018_6, p1, p2, v2016_7_tail);
          v2017_8 = compose(v2017_5,v2018_7);
        }
        const Space v2017_9 = intersect(constant_8,v2017_2);
        const Space v2017_10 = (has_head(v2017_9) ? constant_9 : Space{});
        Space v2017_12;
        if (!v2017_10.empty()) {
          const Path v2019_6 = concat_path(v2016_6,v2016_7_head);
          const Space v2019_11 = routine_300(c, v2019_6, p1, p2, v2016_7_tail);
          v2017_12 = compose(v2017_10,v2019_11);
        }
        const Space v2017_13 = unite(v2017_8,v2017_12);
        v2016_7_result = unite(v2016_7_result,v2017_13);
      }
      const Space v2016_7 = std::move(v2016_7_result);
      v2015_8 = compose(v2015_5,v2016_7);
    }
    const Space v2015_9 = intersect(constant_8,v2015_2);
    const Space v2015_10 = (has_head(v2015_9) ? constant_9 : Space{});
    Space v2015_12;
    if (!v2015_10.empty()) {
      const Path v2020_6 = concat_path(p0,v2014_13_head);
      Space v2020_11_result;
      for (int v2020_11_label = 1; v2020_11_label <= 2; ++v2020_11_label) {
        const Space v2020_11_tail = child(v2014_13_tail,v2020_11_label);
        if (v2020_11_tail.empty()) continue;
        const Path v2020_11_head{v2020_11_label};
        const Space v2021_2 = singleton(v2020_11_head);
        const Space v2021_3 = intersect(constant_8,v2021_2);
        const Space v2021_4 = (has_head(v2021_3) ? constant_9 : Space{});
        const Space v2021_5 = subtract(constant_0,v2021_4);
        Space v2021_8;
        if (!v2021_5.empty()) {
          const Path v2022_6 = concat_path(v2020_6,v2020_11_head);
          const Space v2022_7 = routine_299(c, v2022_6, p1, p2, v2020_11_tail);
          v2021_8 = compose(v2021_5,v2022_7);
        }
        const Space v2021_9 = intersect(constant_8,v2021_2);
        const Space v2021_10 = (has_head(v2021_9) ? constant_9 : Space{});
        Space v2021_12;
        if (!v2021_10.empty()) {
          const Path v2023_6 = concat_path(v2020_6,v2020_11_head);
          const Space v2023_11 = routine_247(c, v2023_6, p1, p2, v2020_11_tail);
          v2021_12 = compose(v2021_10,v2023_11);
        }
        const Space v2021_13 = unite(v2021_8,v2021_12);
        v2020_11_result = unite(v2020_11_result,v2021_13);
      }
      const Space v2020_11 = std::move(v2020_11_result);
      v2015_12 = compose(v2015_10,v2020_11);
    }
    const Space v2015_13 = unite(v2015_8,v2015_12);
    v2014_13_result = unite(v2014_13_result,v2015_13);
  }
  const Space v2014_13 = std::move(v2014_13_result);
  return v2014_13;
}

static Space routine_246(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2024_10 = concat_path(constant_23,p1);
  const Space v2024_11 = singleton(v2024_10);
  const Path v2024_13 = concat_path(constant_6,p2);
  const Space v2024_14 = singleton(v2024_13);
  Space v2024_18_result;
  for (int v2024_18_label = 1; v2024_18_label <= 2; ++v2024_18_label) {
    const Space v2024_18_tail = child(s0,v2024_18_label);
    if (v2024_18_tail.empty()) continue;
    const Path v2024_18_head{v2024_18_label};
    const Space v2025_2 = singleton(v2024_18_head);
    const Space v2025_3 = intersect(constant_8,v2025_2);
    const Space v2025_4 = (has_head(v2025_3) ? constant_9 : Space{});
    const Space v2025_5 = subtract(constant_0,v2025_4);
    Space v2025_8;
    if (!v2025_5.empty()) {
      const Path v2026_6 = concat_path(p0,v2024_18_head);
      Space v2026_7_result;
      for (int v2026_7_label = 1; v2026_7_label <= 2; ++v2026_7_label) {
        const Space v2026_7_tail = child(v2024_18_tail,v2026_7_label);
        if (v2026_7_tail.empty()) continue;
        const Path v2026_7_head{v2026_7_label};
        const Space v2027_2 = singleton(v2026_7_head);
        const Space v2027_3 = intersect(constant_8,v2027_2);
        const Space v2027_4 = (has_head(v2027_3) ? constant_9 : Space{});
        const Space v2027_5 = subtract(constant_0,v2027_4);
        Space v2027_8;
        if (!v2027_5.empty()) {
          const Path v2028_6 = concat_path(v2026_6,v2026_7_head);
          const Space v2028_7 = routine_299(c, v2028_6, p1, p2, v2026_7_tail);
          v2027_8 = compose(v2027_5,v2028_7);
        }
        const Space v2027_9 = intersect(constant_8,v2027_2);
        const Space v2027_10 = (has_head(v2027_9) ? constant_9 : Space{});
        Space v2027_12;
        if (!v2027_10.empty()) {
          const Path v2029_6 = concat_path(v2026_6,v2026_7_head);
          const Space v2029_11 = routine_300(c, v2029_6, p1, p2, v2026_7_tail);
          v2027_12 = compose(v2027_10,v2029_11);
        }
        const Space v2027_13 = unite(v2027_8,v2027_12);
        v2026_7_result = unite(v2026_7_result,v2027_13);
      }
      const Space v2026_7 = std::move(v2026_7_result);
      v2025_8 = compose(v2025_5,v2026_7);
    }
    const Space v2025_9 = intersect(constant_8,v2025_2);
    const Space v2025_10 = (has_head(v2025_9) ? constant_9 : Space{});
    const Path v2030_6 = concat_path(p0,v2024_18_head);
    const Path v2025_11 = concat_path(constant_24,v2030_6);
    const Space v2025_12 = singleton(v2025_11);
    const Space v2025_13 = unite(constant_28,v2025_12);
    const Space v2025_14 = unite(v2025_13,v2024_11);
    const Space v2025_15 = unite(v2025_14,v2024_14);
    const Space v2025_16 = compose(v2025_10,v2025_15);
    const Space v2025_17 = unite(v2025_8,v2025_16);
    v2024_18_result = unite(v2024_18_result,v2025_17);
  }
  const Space v2024_18 = std::move(v2024_18_result);
  return v2024_18;
}

static Space routine_247(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2031_6 = concat_path(constant_24,p0);
  const Space v2031_7 = singleton(v2031_6);
  const Space v2031_8 = unite(constant_28,v2031_7);
  const Path v2031_10 = concat_path(constant_23,p1);
  const Space v2031_11 = singleton(v2031_10);
  const Space v2031_12 = unite(v2031_8,v2031_11);
  const Path v2031_14 = concat_path(constant_6,p2);
  const Space v2031_15 = singleton(v2031_14);
  const Space v2031_16 = unite(v2031_12,v2031_15);
  return v2031_16;
}

static Space routine_248(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2032_5_result;
  for (int v2032_5_label = 1; v2032_5_label <= 2; ++v2032_5_label) {
    const Space v2032_5_tail = child(s0,v2032_5_label);
    if (v2032_5_tail.empty()) continue;
    const Path v2032_5_head{v2032_5_label};
    const Space v2033_2 = singleton(v2032_5_head);
    const Space v2033_3 = intersect(constant_8,v2033_2);
    const Space v2033_4 = (has_head(v2033_3) ? constant_9 : Space{});
    Space v2033_7;
    if (!v2033_4.empty()) {
      const Path v2034_5 = concat_path(p0,v2032_5_head);
      Space v2034_6_result;
      for (int v2034_6_label = 1; v2034_6_label <= 2; ++v2034_6_label) {
        const Space v2034_6_tail = child(v2032_5_tail,v2034_6_label);
        if (v2034_6_tail.empty()) continue;
        const Path v2034_6_head{v2034_6_label};
        const Space v2035_2 = singleton(v2034_6_head);
        const Space v2035_3 = intersect(constant_8,v2035_2);
        const Space v2035_4 = (has_head(v2035_3) ? constant_9 : Space{});
        Space v2035_7;
        if (!v2035_4.empty()) {
          const Path v2036_5 = concat_path(v2034_5,v2034_6_head);
          const Space v2036_6 = routine_169(c, v2036_5, p1, v2034_6_tail);
          v2035_7 = compose(v2035_4,v2036_6);
        }
        v2034_6_result = unite(v2034_6_result,v2035_7);
      }
      const Space v2034_6 = std::move(v2034_6_result);
      v2033_7 = compose(v2033_4,v2034_6);
    }
    v2032_5_result = unite(v2032_5_result,v2033_7);
  }
  const Space v2032_5 = std::move(v2032_5_result);
  return v2032_5;
}

static Space routine_249(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2037_7_result;
  for (int v2037_7_label = 1; v2037_7_label <= 2; ++v2037_7_label) {
    const Space v2037_7_tail = child(s0,v2037_7_label);
    if (v2037_7_tail.empty()) continue;
    const Path v2037_7_head{v2037_7_label};
    const Space v2038_2 = singleton(v2037_7_head);
    const Space v2038_3 = intersect(constant_8,v2038_2);
    const Space v2038_4 = (has_head(v2038_3) ? constant_9 : Space{});
    Space v2038_7;
    if (!v2038_4.empty()) {
      const Path v2039_5 = concat_path(p0,v2037_7_head);
      Space v2039_6_result;
      for (int v2039_6_label = 1; v2039_6_label <= 2; ++v2039_6_label) {
        const Space v2039_6_tail = child(v2037_7_tail,v2039_6_label);
        if (v2039_6_tail.empty()) continue;
        const Path v2039_6_head{v2039_6_label};
        const Space v2040_2 = singleton(v2039_6_head);
        const Space v2040_3 = intersect(constant_8,v2040_2);
        const Space v2040_4 = (has_head(v2040_3) ? constant_9 : Space{});
        const Space v2040_5 = subtract(constant_0,v2040_4);
        Space v2040_7;
        if (!v2040_5.empty()) {
          const Space v2041_6 = routine_217(c, v2039_6_head, p1, v2039_5, v2039_6_tail);
          v2040_7 = compose(v2040_5,v2041_6);
        }
        const Space v2040_8 = intersect(constant_8,v2040_2);
        const Space v2040_9 = (has_head(v2040_8) ? constant_9 : Space{});
        Space v2040_11;
        if (!v2040_9.empty()) {
          const Space v2042_10 = routine_218(c, v2039_6_head, p1, v2039_5, v2039_6_tail);
          v2040_11 = compose(v2040_9,v2042_10);
        }
        const Space v2040_12 = unite(v2040_7,v2040_11);
        v2039_6_result = unite(v2039_6_result,v2040_12);
      }
      const Space v2039_6 = std::move(v2039_6_result);
      v2038_7 = compose(v2038_4,v2039_6);
    }
    v2037_7_result = unite(v2037_7_result,v2038_7);
  }
  const Space v2037_7 = std::move(v2037_7_result);
  return v2037_7;
}

static Space routine_250(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2043_13_result;
  for (int v2043_13_label = 1; v2043_13_label <= 2; ++v2043_13_label) {
    const Space v2043_13_tail = child(s0,v2043_13_label);
    if (v2043_13_tail.empty()) continue;
    const Path v2043_13_head{v2043_13_label};
    const Space v2044_2 = singleton(v2043_13_head);
    const Space v2044_3 = intersect(constant_8,v2044_2);
    const Space v2044_4 = (has_head(v2044_3) ? constant_9 : Space{});
    const Space v2044_5 = subtract(constant_0,v2044_4);
    Space v2044_8;
    if (!v2044_5.empty()) {
      const Path v2045_6 = concat_path(p0,v2043_13_head);
      Space v2045_7_result;
      for (int v2045_7_label = 1; v2045_7_label <= 2; ++v2045_7_label) {
        const Space v2045_7_tail = child(v2043_13_tail,v2045_7_label);
        if (v2045_7_tail.empty()) continue;
        const Path v2045_7_head{v2045_7_label};
        const Space v2046_2 = singleton(v2045_7_head);
        const Space v2046_3 = intersect(constant_8,v2046_2);
        const Space v2046_4 = (has_head(v2046_3) ? constant_9 : Space{});
        const Space v2046_5 = subtract(constant_0,v2046_4);
        Space v2046_8;
        if (!v2046_5.empty()) {
          const Path v2047_6 = concat_path(v2045_6,v2045_7_head);
          const Space v2047_7 = routine_301(c, v2047_6, p1, p2, v2045_7_tail);
          v2046_8 = compose(v2046_5,v2047_7);
        }
        const Space v2046_9 = intersect(constant_8,v2046_2);
        const Space v2046_10 = (has_head(v2046_9) ? constant_9 : Space{});
        Space v2046_12;
        if (!v2046_10.empty()) {
          const Path v2048_6 = concat_path(v2045_6,v2045_7_head);
          const Space v2048_11 = routine_302(c, v2048_6, p1, p2, v2045_7_tail);
          v2046_12 = compose(v2046_10,v2048_11);
        }
        const Space v2046_13 = unite(v2046_8,v2046_12);
        v2045_7_result = unite(v2045_7_result,v2046_13);
      }
      const Space v2045_7 = std::move(v2045_7_result);
      v2044_8 = compose(v2044_5,v2045_7);
    }
    const Space v2044_9 = intersect(constant_8,v2044_2);
    const Space v2044_10 = (has_head(v2044_9) ? constant_9 : Space{});
    Space v2044_12;
    if (!v2044_10.empty()) {
      const Path v2049_6 = concat_path(p0,v2043_13_head);
      Space v2049_11_result;
      for (int v2049_11_label = 1; v2049_11_label <= 2; ++v2049_11_label) {
        const Space v2049_11_tail = child(v2043_13_tail,v2049_11_label);
        if (v2049_11_tail.empty()) continue;
        const Path v2049_11_head{v2049_11_label};
        const Space v2050_2 = singleton(v2049_11_head);
        const Space v2050_3 = intersect(constant_8,v2050_2);
        const Space v2050_4 = (has_head(v2050_3) ? constant_9 : Space{});
        const Space v2050_5 = subtract(constant_0,v2050_4);
        Space v2050_8;
        if (!v2050_5.empty()) {
          const Path v2051_6 = concat_path(v2049_6,v2049_11_head);
          const Space v2051_7 = routine_301(c, v2051_6, p1, p2, v2049_11_tail);
          v2050_8 = compose(v2050_5,v2051_7);
        }
        const Space v2050_9 = intersect(constant_8,v2050_2);
        const Space v2050_10 = (has_head(v2050_9) ? constant_9 : Space{});
        Space v2050_12;
        if (!v2050_10.empty()) {
          const Path v2052_6 = concat_path(v2049_6,v2049_11_head);
          const Space v2052_11 = routine_252(c, v2052_6, p1, p2, v2049_11_tail);
          v2050_12 = compose(v2050_10,v2052_11);
        }
        const Space v2050_13 = unite(v2050_8,v2050_12);
        v2049_11_result = unite(v2049_11_result,v2050_13);
      }
      const Space v2049_11 = std::move(v2049_11_result);
      v2044_12 = compose(v2044_10,v2049_11);
    }
    const Space v2044_13 = unite(v2044_8,v2044_12);
    v2043_13_result = unite(v2043_13_result,v2044_13);
  }
  const Space v2043_13 = std::move(v2043_13_result);
  return v2043_13;
}

static Space routine_251(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2053_10 = concat_path(constant_23,p2);
  const Space v2053_11 = singleton(v2053_10);
  const Path v2053_13 = concat_path(constant_22,p1);
  const Space v2053_14 = singleton(v2053_13);
  Space v2053_18_result;
  for (int v2053_18_label = 1; v2053_18_label <= 2; ++v2053_18_label) {
    const Space v2053_18_tail = child(s0,v2053_18_label);
    if (v2053_18_tail.empty()) continue;
    const Path v2053_18_head{v2053_18_label};
    const Space v2054_2 = singleton(v2053_18_head);
    const Space v2054_3 = intersect(constant_8,v2054_2);
    const Space v2054_4 = (has_head(v2054_3) ? constant_9 : Space{});
    const Space v2054_5 = subtract(constant_0,v2054_4);
    Space v2054_8;
    if (!v2054_5.empty()) {
      const Path v2055_6 = concat_path(p0,v2053_18_head);
      Space v2055_7_result;
      for (int v2055_7_label = 1; v2055_7_label <= 2; ++v2055_7_label) {
        const Space v2055_7_tail = child(v2053_18_tail,v2055_7_label);
        if (v2055_7_tail.empty()) continue;
        const Path v2055_7_head{v2055_7_label};
        const Space v2056_2 = singleton(v2055_7_head);
        const Space v2056_3 = intersect(constant_8,v2056_2);
        const Space v2056_4 = (has_head(v2056_3) ? constant_9 : Space{});
        const Space v2056_5 = subtract(constant_0,v2056_4);
        Space v2056_8;
        if (!v2056_5.empty()) {
          const Path v2057_6 = concat_path(v2055_6,v2055_7_head);
          const Space v2057_7 = routine_301(c, v2057_6, p1, p2, v2055_7_tail);
          v2056_8 = compose(v2056_5,v2057_7);
        }
        const Space v2056_9 = intersect(constant_8,v2056_2);
        const Space v2056_10 = (has_head(v2056_9) ? constant_9 : Space{});
        Space v2056_12;
        if (!v2056_10.empty()) {
          const Path v2058_6 = concat_path(v2055_6,v2055_7_head);
          const Space v2058_11 = routine_302(c, v2058_6, p1, p2, v2055_7_tail);
          v2056_12 = compose(v2056_10,v2058_11);
        }
        const Space v2056_13 = unite(v2056_8,v2056_12);
        v2055_7_result = unite(v2055_7_result,v2056_13);
      }
      const Space v2055_7 = std::move(v2055_7_result);
      v2054_8 = compose(v2054_5,v2055_7);
    }
    const Space v2054_9 = intersect(constant_8,v2054_2);
    const Space v2054_10 = (has_head(v2054_9) ? constant_9 : Space{});
    const Path v2059_6 = concat_path(p0,v2053_18_head);
    const Path v2054_11 = concat_path(constant_24,v2059_6);
    const Space v2054_12 = singleton(v2054_11);
    const Space v2054_13 = unite(constant_29,v2054_12);
    const Space v2054_14 = unite(v2054_13,v2053_11);
    const Space v2054_15 = unite(v2054_14,v2053_14);
    const Space v2054_16 = compose(v2054_10,v2054_15);
    const Space v2054_17 = unite(v2054_8,v2054_16);
    v2053_18_result = unite(v2053_18_result,v2054_17);
  }
  const Space v2053_18 = std::move(v2053_18_result);
  return v2053_18;
}

static Space routine_252(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2060_6 = concat_path(constant_24,p0);
  const Space v2060_7 = singleton(v2060_6);
  const Space v2060_8 = unite(constant_29,v2060_7);
  const Path v2060_10 = concat_path(constant_23,p2);
  const Space v2060_11 = singleton(v2060_10);
  const Space v2060_12 = unite(v2060_8,v2060_11);
  const Path v2060_14 = concat_path(constant_22,p1);
  const Space v2060_15 = singleton(v2060_14);
  const Space v2060_16 = unite(v2060_12,v2060_15);
  return v2060_16;
}

static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2061_3 = Space{};
  return v2061_3;
}

static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2062_7_result;
  for (int v2062_7_label = 1; v2062_7_label <= 2; ++v2062_7_label) {
    const Space v2062_7_tail = child(s0,v2062_7_label);
    if (v2062_7_tail.empty()) continue;
    const Path v2062_7_head{v2062_7_label};
    const Space v2063_2 = singleton(v2062_7_head);
    const Space v2063_3 = intersect(constant_8,v2063_2);
    const Space v2063_4 = (has_head(v2063_3) ? constant_9 : Space{});
    Space v2063_7;
    if (!v2063_4.empty()) {
      const Path v2064_5 = concat_path(p0,v2062_7_head);
      Space v2064_6_result;
      for (int v2064_6_label = 1; v2064_6_label <= 2; ++v2064_6_label) {
        const Space v2064_6_tail = child(v2062_7_tail,v2064_6_label);
        if (v2064_6_tail.empty()) continue;
        const Path v2064_6_head{v2064_6_label};
        const Space v2065_2 = singleton(v2064_6_head);
        const Space v2065_3 = intersect(constant_8,v2065_2);
        const Space v2065_4 = (has_head(v2065_3) ? constant_9 : Space{});
        const Space v2065_5 = subtract(constant_0,v2065_4);
        Space v2065_7;
        if (!v2065_5.empty()) {
          const Space v2066_6 = routine_174(c, v2064_6_head, p1, v2064_5, v2064_6_tail);
          v2065_7 = compose(v2065_5,v2066_6);
        }
        const Space v2065_8 = intersect(constant_8,v2065_2);
        const Space v2065_9 = (has_head(v2065_8) ? constant_9 : Space{});
        Space v2065_11;
        if (!v2065_9.empty()) {
          const Space v2067_10 = routine_175(c, v2064_6_head, p1, v2064_5, v2064_6_tail);
          v2065_11 = compose(v2065_9,v2067_10);
        }
        const Space v2065_12 = unite(v2065_7,v2065_11);
        v2064_6_result = unite(v2064_6_result,v2065_12);
      }
      const Space v2064_6 = std::move(v2064_6_result);
      v2063_7 = compose(v2063_4,v2064_6);
    }
    v2062_7_result = unite(v2062_7_result,v2063_7);
  }
  const Space v2062_7 = std::move(v2062_7_result);
  return v2062_7;
}

static Space routine_255(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2068_13_result;
  for (int v2068_13_label = 1; v2068_13_label <= 2; ++v2068_13_label) {
    const Space v2068_13_tail = child(s0,v2068_13_label);
    if (v2068_13_tail.empty()) continue;
    const Path v2068_13_head{v2068_13_label};
    const Space v2069_2 = singleton(v2068_13_head);
    const Space v2069_3 = intersect(constant_8,v2069_2);
    const Space v2069_4 = (has_head(v2069_3) ? constant_9 : Space{});
    const Space v2069_5 = subtract(constant_0,v2069_4);
    Space v2069_8;
    if (!v2069_5.empty()) {
      const Path v2070_6 = concat_path(p0,v2068_13_head);
      Space v2070_7_result;
      for (int v2070_7_label = 1; v2070_7_label <= 2; ++v2070_7_label) {
        const Space v2070_7_tail = child(v2068_13_tail,v2070_7_label);
        if (v2070_7_tail.empty()) continue;
        const Path v2070_7_head{v2070_7_label};
        const Space v2071_2 = singleton(v2070_7_head);
        const Space v2071_3 = intersect(constant_8,v2071_2);
        const Space v2071_4 = (has_head(v2071_3) ? constant_9 : Space{});
        const Space v2071_5 = subtract(constant_0,v2071_4);
        Space v2071_8;
        if (!v2071_5.empty()) {
          const Path v2072_6 = concat_path(v2070_6,v2070_7_head);
          const Space v2072_7 = routine_303(c, v2072_6, p1, p2, v2070_7_tail);
          v2071_8 = compose(v2071_5,v2072_7);
        }
        const Space v2071_9 = intersect(constant_8,v2071_2);
        const Space v2071_10 = (has_head(v2071_9) ? constant_9 : Space{});
        Space v2071_12;
        if (!v2071_10.empty()) {
          const Path v2073_6 = concat_path(v2070_6,v2070_7_head);
          const Space v2073_11 = routine_304(c, v2073_6, p1, p2, v2070_7_tail);
          v2071_12 = compose(v2071_10,v2073_11);
        }
        const Space v2071_13 = unite(v2071_8,v2071_12);
        v2070_7_result = unite(v2070_7_result,v2071_13);
      }
      const Space v2070_7 = std::move(v2070_7_result);
      v2069_8 = compose(v2069_5,v2070_7);
    }
    const Space v2069_9 = intersect(constant_8,v2069_2);
    const Space v2069_10 = (has_head(v2069_9) ? constant_9 : Space{});
    Space v2069_12;
    if (!v2069_10.empty()) {
      const Path v2074_6 = concat_path(p0,v2068_13_head);
      Space v2074_11_result;
      for (int v2074_11_label = 1; v2074_11_label <= 2; ++v2074_11_label) {
        const Space v2074_11_tail = child(v2068_13_tail,v2074_11_label);
        if (v2074_11_tail.empty()) continue;
        const Path v2074_11_head{v2074_11_label};
        const Space v2075_2 = singleton(v2074_11_head);
        const Space v2075_3 = intersect(constant_8,v2075_2);
        const Space v2075_4 = (has_head(v2075_3) ? constant_9 : Space{});
        const Space v2075_5 = subtract(constant_0,v2075_4);
        Space v2075_8;
        if (!v2075_5.empty()) {
          const Path v2076_6 = concat_path(v2074_6,v2074_11_head);
          const Space v2076_7 = routine_303(c, v2076_6, p1, p2, v2074_11_tail);
          v2075_8 = compose(v2075_5,v2076_7);
        }
        const Space v2075_9 = intersect(constant_8,v2075_2);
        const Space v2075_10 = (has_head(v2075_9) ? constant_9 : Space{});
        Space v2075_12;
        if (!v2075_10.empty()) {
          const Path v2077_6 = concat_path(v2074_6,v2074_11_head);
          const Space v2077_11 = routine_223(c, v2077_6, p1, p2, v2074_11_tail);
          v2075_12 = compose(v2075_10,v2077_11);
        }
        const Space v2075_13 = unite(v2075_8,v2075_12);
        v2074_11_result = unite(v2074_11_result,v2075_13);
      }
      const Space v2074_11 = std::move(v2074_11_result);
      v2069_12 = compose(v2069_10,v2074_11);
    }
    const Space v2069_13 = unite(v2069_8,v2069_12);
    v2068_13_result = unite(v2068_13_result,v2069_13);
  }
  const Space v2068_13 = std::move(v2068_13_result);
  return v2068_13;
}

static Space routine_256(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2078_14_result;
  for (int v2078_14_label = 1; v2078_14_label <= 2; ++v2078_14_label) {
    const Space v2078_14_tail = child(s0,v2078_14_label);
    if (v2078_14_tail.empty()) continue;
    const Path v2078_14_head{v2078_14_label};
    const Space v2079_2 = singleton(v2078_14_head);
    const Space v2079_3 = intersect(constant_8,v2079_2);
    const Space v2079_4 = (has_head(v2079_3) ? constant_9 : Space{});
    const Space v2079_5 = subtract(constant_0,v2079_4);
    Space v2079_8;
    if (!v2079_5.empty()) {
      const Path v2080_6 = concat_path(p0,v2078_14_head);
      Space v2080_7_result;
      for (int v2080_7_label = 1; v2080_7_label <= 2; ++v2080_7_label) {
        const Space v2080_7_tail = child(v2078_14_tail,v2080_7_label);
        if (v2080_7_tail.empty()) continue;
        const Path v2080_7_head{v2080_7_label};
        const Space v2081_2 = singleton(v2080_7_head);
        const Space v2081_3 = intersect(constant_8,v2081_2);
        const Space v2081_4 = (has_head(v2081_3) ? constant_9 : Space{});
        const Space v2081_5 = subtract(constant_0,v2081_4);
        Space v2081_8;
        if (!v2081_5.empty()) {
          const Path v2082_6 = concat_path(v2080_6,v2080_7_head);
          const Space v2082_7 = routine_303(c, v2082_6, p1, p2, v2080_7_tail);
          v2081_8 = compose(v2081_5,v2082_7);
        }
        const Space v2081_9 = intersect(constant_8,v2081_2);
        const Space v2081_10 = (has_head(v2081_9) ? constant_9 : Space{});
        Space v2081_12;
        if (!v2081_10.empty()) {
          const Path v2083_6 = concat_path(v2080_6,v2080_7_head);
          const Space v2083_11 = routine_304(c, v2083_6, p1, p2, v2080_7_tail);
          v2081_12 = compose(v2081_10,v2083_11);
        }
        const Space v2081_13 = unite(v2081_8,v2081_12);
        v2080_7_result = unite(v2080_7_result,v2081_13);
      }
      const Space v2080_7 = std::move(v2080_7_result);
      v2079_8 = compose(v2079_5,v2080_7);
    }
    const Space v2079_9 = intersect(constant_8,v2079_2);
    const Space v2079_10 = (has_head(v2079_9) ? constant_9 : Space{});
    Space v2079_17;
    if (!v2079_10.empty()) {
      const Path v2084_6 = concat_path(p0,v2078_14_head);
      Space v2084_11_result;
      for (int v2084_11_label = 1; v2084_11_label <= 2; ++v2084_11_label) {
        const Space v2084_11_tail = child(v2078_14_tail,v2084_11_label);
        if (v2084_11_tail.empty()) continue;
        const Path v2084_11_head{v2084_11_label};
        const Space v2085_2 = singleton(v2084_11_head);
        const Space v2085_3 = intersect(constant_8,v2085_2);
        const Space v2085_4 = (has_head(v2085_3) ? constant_9 : Space{});
        const Space v2085_5 = subtract(constant_0,v2085_4);
        Space v2085_7;
        if (!v2085_5.empty()) {
          const Space v2086_6 = routine_257(c, v2084_11_head, v2084_11_tail);
          v2085_7 = compose(v2085_5,v2086_6);
        }
        const Space v2085_8 = intersect(constant_8,v2085_2);
        const Space v2085_9 = (has_head(v2085_8) ? constant_9 : Space{});
        Space v2085_11;
        if (!v2085_9.empty()) {
          const Space v2087_10 = routine_258(c, v2084_11_head, v2084_11_tail);
          v2085_11 = compose(v2085_9,v2087_10);
        }
        const Space v2085_12 = unite(v2085_7,v2085_11);
        v2084_11_result = unite(v2084_11_result,v2085_12);
      }
      const Space v2084_11 = std::move(v2084_11_result);
      const Space v2084_12 = raffine(constant_25,v2084_11);
      const Space v2084_13 = unite(v2084_12,v2078_14_tail);
      const Path v2084_14 = concat_path(p2,v2084_6);
      const Space v2084_15 = wrap(v2084_13,v2084_14);
      const Space v2084_16 = unwrap(v2084_15,p1);
      v2079_17 = compose(v2079_10,v2084_16);
    }
    const Space v2079_18 = unite(v2079_8,v2079_17);
    v2078_14_result = unite(v2078_14_result,v2079_18);
  }
  const Space v2078_14 = std::move(v2078_14_result);
  return v2078_14;
}

static Space routine_257(Context& c, const Path& p0, const Space& s0) {
  Space v2088_11_result;
  for (int v2088_11_label = 1; v2088_11_label <= 2; ++v2088_11_label) {
    const Space v2088_11_tail = child(s0,v2088_11_label);
    if (v2088_11_tail.empty()) continue;
    const Path v2088_11_head{v2088_11_label};
    const Space v2089_2 = singleton(v2088_11_head);
    const Space v2089_3 = intersect(constant_8,v2089_2);
    const Space v2089_4 = (has_head(v2089_3) ? constant_9 : Space{});
    const Space v2089_5 = subtract(constant_0,v2089_4);
    Space v2089_8;
    if (!v2089_5.empty()) {
      const Path v2090_6 = concat_path(p0,v2088_11_head);
      Space v2090_7_result;
      for (int v2090_7_label = 1; v2090_7_label <= 2; ++v2090_7_label) {
        const Space v2090_7_tail = child(v2088_11_tail,v2090_7_label);
        if (v2090_7_tail.empty()) continue;
        const Path v2090_7_head{v2090_7_label};
        const Space v2091_2 = singleton(v2090_7_head);
        const Space v2091_3 = intersect(constant_8,v2091_2);
        const Space v2091_4 = (has_head(v2091_3) ? constant_9 : Space{});
        const Space v2091_5 = subtract(constant_0,v2091_4);
        Space v2091_8;
        if (!v2091_5.empty()) {
          const Path v2092_6 = concat_path(v2090_6,v2090_7_head);
          const Space v2092_7 = routine_305(c, v2092_6, v2090_7_tail);
          v2091_8 = compose(v2091_5,v2092_7);
        }
        const Space v2091_9 = intersect(constant_8,v2091_2);
        const Space v2091_10 = (has_head(v2091_9) ? constant_9 : Space{});
        Space v2091_12;
        if (!v2091_10.empty()) {
          const Path v2093_6 = concat_path(v2090_6,v2090_7_head);
          const Space v2093_11 = routine_306(c, v2093_6, v2090_7_tail);
          v2091_12 = compose(v2091_10,v2093_11);
        }
        const Space v2091_13 = unite(v2091_8,v2091_12);
        v2090_7_result = unite(v2090_7_result,v2091_13);
      }
      const Space v2090_7 = std::move(v2090_7_result);
      v2089_8 = compose(v2089_5,v2090_7);
    }
    const Space v2089_9 = intersect(constant_8,v2089_2);
    const Space v2089_10 = (has_head(v2089_9) ? constant_9 : Space{});
    Space v2089_12;
    if (!v2089_10.empty()) {
      const Path v2094_6 = concat_path(p0,v2088_11_head);
      Space v2094_11_result;
      for (int v2094_11_label = 1; v2094_11_label <= 2; ++v2094_11_label) {
        const Space v2094_11_tail = child(v2088_11_tail,v2094_11_label);
        if (v2094_11_tail.empty()) continue;
        const Path v2094_11_head{v2094_11_label};
        const Space v2095_2 = singleton(v2094_11_head);
        const Space v2095_3 = intersect(constant_8,v2095_2);
        const Space v2095_4 = (has_head(v2095_3) ? constant_9 : Space{});
        const Space v2095_5 = subtract(constant_0,v2095_4);
        Space v2095_8;
        if (!v2095_5.empty()) {
          const Path v2096_6 = concat_path(v2094_6,v2094_11_head);
          const Space v2096_7 = routine_305(c, v2096_6, v2094_11_tail);
          v2095_8 = compose(v2095_5,v2096_7);
        }
        const Space v2095_9 = intersect(constant_8,v2095_2);
        const Space v2095_10 = (has_head(v2095_9) ? constant_9 : Space{});
        Space v2095_12;
        if (!v2095_10.empty()) {
          const Path v2097_6 = concat_path(v2094_6,v2094_11_head);
          const Space v2097_11 = routine_289(c, v2097_6, v2094_11_tail);
          v2095_12 = compose(v2095_10,v2097_11);
        }
        const Space v2095_13 = unite(v2095_8,v2095_12);
        v2094_11_result = unite(v2094_11_result,v2095_13);
      }
      const Space v2094_11 = std::move(v2094_11_result);
      v2089_12 = compose(v2089_10,v2094_11);
    }
    const Space v2089_13 = unite(v2089_8,v2089_12);
    v2088_11_result = unite(v2088_11_result,v2089_13);
  }
  const Space v2088_11 = std::move(v2088_11_result);
  return v2088_11;
}

static Space routine_258(Context& c, const Path& p0, const Space& s0) {
  Space v2098_8_result;
  for (int v2098_8_label = 1; v2098_8_label <= 2; ++v2098_8_label) {
    const Space v2098_8_tail = child(s0,v2098_8_label);
    if (v2098_8_tail.empty()) continue;
    const Path v2098_8_head{v2098_8_label};
    const Space v2099_2 = singleton(v2098_8_head);
    const Space v2099_3 = intersect(constant_8,v2099_2);
    const Space v2099_4 = (has_head(v2099_3) ? constant_9 : Space{});
    const Space v2099_5 = subtract(constant_0,v2099_4);
    Space v2099_8;
    if (!v2099_5.empty()) {
      const Path v2100_6 = concat_path(p0,v2098_8_head);
      Space v2100_7_result;
      for (int v2100_7_label = 1; v2100_7_label <= 2; ++v2100_7_label) {
        const Space v2100_7_tail = child(v2098_8_tail,v2100_7_label);
        if (v2100_7_tail.empty()) continue;
        const Path v2100_7_head{v2100_7_label};
        const Space v2101_2 = singleton(v2100_7_head);
        const Space v2101_3 = intersect(constant_8,v2101_2);
        const Space v2101_4 = (has_head(v2101_3) ? constant_9 : Space{});
        const Space v2101_5 = subtract(constant_0,v2101_4);
        Space v2101_8;
        if (!v2101_5.empty()) {
          const Path v2102_6 = concat_path(v2100_6,v2100_7_head);
          const Space v2102_7 = routine_305(c, v2102_6, v2100_7_tail);
          v2101_8 = compose(v2101_5,v2102_7);
        }
        const Space v2101_9 = intersect(constant_8,v2101_2);
        const Space v2101_10 = (has_head(v2101_9) ? constant_9 : Space{});
        Space v2101_12;
        if (!v2101_10.empty()) {
          const Path v2103_6 = concat_path(v2100_6,v2100_7_head);
          const Space v2103_11 = routine_306(c, v2103_6, v2100_7_tail);
          v2101_12 = compose(v2101_10,v2103_11);
        }
        const Space v2101_13 = unite(v2101_8,v2101_12);
        v2100_7_result = unite(v2100_7_result,v2101_13);
      }
      const Space v2100_7 = std::move(v2100_7_result);
      v2099_8 = compose(v2099_5,v2100_7);
    }
    const Space v2099_9 = intersect(constant_8,v2099_2);
    const Space v2099_10 = (has_head(v2099_9) ? constant_9 : Space{});
    const Path v2104_6 = concat_path(p0,v2098_8_head);
    const Space v2099_11 = singleton(v2104_6);
    const Space v2099_12 = compose(v2099_10,v2099_11);
    const Space v2099_13 = unite(v2099_8,v2099_12);
    v2098_8_result = unite(v2098_8_result,v2099_13);
  }
  const Space v2098_8 = std::move(v2098_8_result);
  return v2098_8;
}

static Space routine_259(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v2105_4 = Space{};
  return v2105_4;
}

static Space routine_260(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v2106_5_result;
  for (int v2106_5_label = 1; v2106_5_label <= 2; ++v2106_5_label) {
    const Space v2106_5_tail = child(s0,v2106_5_label);
    if (v2106_5_tail.empty()) continue;
    const Path v2106_5_head{v2106_5_label};
    const Space v2107_2 = singleton(v2106_5_head);
    const Space v2107_3 = intersect(constant_8,v2107_2);
    const Space v2107_4 = (has_head(v2107_3) ? constant_9 : Space{});
    const Space v2107_5 = unwrap(v2106_5_tail,p1);
    const Path v2107_6 = concat_path(p0,v2106_5_head);
    const Space v2107_7 = wrap(v2107_5,v2107_6);
    const Space v2107_8 = compose(v2107_7,s1);
    const Space v2107_9 = compose(v2107_4,v2107_8);
    v2106_5_result = unite(v2106_5_result,v2107_9);
  }
  const Space v2106_5 = std::move(v2106_5_result);
  return v2106_5;
}

static Space routine_261(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2108_4 = Space{};
  return v2108_4;
}

static Space routine_262(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2109_8_result;
  for (int v2109_8_label = 1; v2109_8_label <= 2; ++v2109_8_label) {
    const Space v2109_8_tail = child(s0,v2109_8_label);
    if (v2109_8_tail.empty()) continue;
    const Path v2109_8_head{v2109_8_label};
    const Space v2110_2 = singleton(v2109_8_head);
    const Space v2110_3 = intersect(constant_8,v2110_2);
    const Space v2110_4 = (has_head(v2110_3) ? constant_9 : Space{});
    Space v2110_7;
    if (!v2110_4.empty()) {
      const Path v2111_5 = concat_path(p0,v2109_8_head);
      Space v2111_6_result;
      for (int v2111_6_label = 1; v2111_6_label <= 2; ++v2111_6_label) {
        const Space v2111_6_tail = child(v2109_8_tail,v2111_6_label);
        if (v2111_6_tail.empty()) continue;
        const Path v2111_6_head{v2111_6_label};
        const Space v2112_2 = singleton(v2111_6_head);
        const Space v2112_3 = intersect(constant_8,v2112_2);
        const Space v2112_4 = (has_head(v2112_3) ? constant_9 : Space{});
        const Space v2112_5 = subtract(constant_0,v2112_4);
        Space v2112_7;
        if (!v2112_5.empty()) {
          const Space v2113_6 = routine_182(c, v2111_6_head, p1, p2, v2111_5, v2111_6_tail);
          v2112_7 = compose(v2112_5,v2113_6);
        }
        const Space v2112_8 = intersect(constant_8,v2112_2);
        const Space v2112_9 = (has_head(v2112_8) ? constant_9 : Space{});
        Space v2112_11;
        if (!v2112_9.empty()) {
          const Space v2114_10 = routine_183(c, v2111_6_head, p1, p2, v2111_5, v2111_6_tail);
          v2112_11 = compose(v2112_9,v2114_10);
        }
        const Space v2112_12 = unite(v2112_7,v2112_11);
        v2111_6_result = unite(v2111_6_result,v2112_12);
      }
      const Space v2111_6 = std::move(v2111_6_result);
      v2110_7 = compose(v2110_4,v2111_6);
    }
    v2109_8_result = unite(v2109_8_result,v2110_7);
  }
  const Space v2109_8 = std::move(v2109_8_result);
  return v2109_8;
}

static Space routine_263(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v2115_14_result;
  for (int v2115_14_label = 1; v2115_14_label <= 2; ++v2115_14_label) {
    const Space v2115_14_tail = child(s0,v2115_14_label);
    if (v2115_14_tail.empty()) continue;
    const Path v2115_14_head{v2115_14_label};
    const Space v2116_2 = singleton(v2115_14_head);
    const Space v2116_3 = intersect(constant_8,v2116_2);
    const Space v2116_4 = (has_head(v2116_3) ? constant_9 : Space{});
    const Space v2116_5 = subtract(constant_0,v2116_4);
    Space v2116_8;
    if (!v2116_5.empty()) {
      const Path v2117_6 = concat_path(p0,v2115_14_head);
      Space v2117_7_result;
      for (int v2117_7_label = 1; v2117_7_label <= 2; ++v2117_7_label) {
        const Space v2117_7_tail = child(v2115_14_tail,v2117_7_label);
        if (v2117_7_tail.empty()) continue;
        const Path v2117_7_head{v2117_7_label};
        const Space v2118_2 = singleton(v2117_7_head);
        const Space v2118_3 = intersect(constant_8,v2118_2);
        const Space v2118_4 = (has_head(v2118_3) ? constant_9 : Space{});
        const Space v2118_5 = subtract(constant_0,v2118_4);
        Space v2118_8;
        if (!v2118_5.empty()) {
          const Path v2119_6 = concat_path(v2117_6,v2117_7_head);
          const Space v2119_7 = routine_307(c, v2119_6, p1, p2, p3, v2117_7_tail);
          v2118_8 = compose(v2118_5,v2119_7);
        }
        const Space v2118_9 = intersect(constant_8,v2118_2);
        const Space v2118_10 = (has_head(v2118_9) ? constant_9 : Space{});
        Space v2118_12;
        if (!v2118_10.empty()) {
          const Path v2120_6 = concat_path(v2117_6,v2117_7_head);
          const Space v2120_11 = routine_308(c, v2120_6, p1, p2, p3, v2117_7_tail);
          v2118_12 = compose(v2118_10,v2120_11);
        }
        const Space v2118_13 = unite(v2118_8,v2118_12);
        v2117_7_result = unite(v2117_7_result,v2118_13);
      }
      const Space v2117_7 = std::move(v2117_7_result);
      v2116_8 = compose(v2116_5,v2117_7);
    }
    const Space v2116_9 = intersect(constant_8,v2116_2);
    const Space v2116_10 = (has_head(v2116_9) ? constant_9 : Space{});
    Space v2116_12;
    if (!v2116_10.empty()) {
      const Path v2121_6 = concat_path(p0,v2115_14_head);
      Space v2121_11_result;
      for (int v2121_11_label = 1; v2121_11_label <= 2; ++v2121_11_label) {
        const Space v2121_11_tail = child(v2115_14_tail,v2121_11_label);
        if (v2121_11_tail.empty()) continue;
        const Path v2121_11_head{v2121_11_label};
        const Space v2122_2 = singleton(v2121_11_head);
        const Space v2122_3 = intersect(constant_8,v2122_2);
        const Space v2122_4 = (has_head(v2122_3) ? constant_9 : Space{});
        const Space v2122_5 = subtract(constant_0,v2122_4);
        Space v2122_8;
        if (!v2122_5.empty()) {
          const Path v2123_6 = concat_path(v2121_6,v2121_11_head);
          const Space v2123_7 = routine_307(c, v2123_6, p1, p2, p3, v2121_11_tail);
          v2122_8 = compose(v2122_5,v2123_7);
        }
        const Space v2122_9 = intersect(constant_8,v2122_2);
        const Space v2122_10 = (has_head(v2122_9) ? constant_9 : Space{});
        Space v2122_12;
        if (!v2122_10.empty()) {
          const Path v2124_6 = concat_path(v2121_6,v2121_11_head);
          const Space v2124_11 = routine_230(c, v2124_6, p1, p2, p3, v2121_11_tail);
          v2122_12 = compose(v2122_10,v2124_11);
        }
        const Space v2122_13 = unite(v2122_8,v2122_12);
        v2121_11_result = unite(v2121_11_result,v2122_13);
      }
      const Space v2121_11 = std::move(v2121_11_result);
      v2116_12 = compose(v2116_10,v2121_11);
    }
    const Space v2116_13 = unite(v2116_8,v2116_12);
    v2115_14_result = unite(v2115_14_result,v2116_13);
  }
  const Space v2115_14 = std::move(v2115_14_result);
  return v2115_14;
}

static Space routine_264(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v2125_15_result;
  for (int v2125_15_label = 1; v2125_15_label <= 2; ++v2125_15_label) {
    const Space v2125_15_tail = child(s0,v2125_15_label);
    if (v2125_15_tail.empty()) continue;
    const Path v2125_15_head{v2125_15_label};
    const Space v2126_2 = singleton(v2125_15_head);
    const Space v2126_3 = intersect(constant_8,v2126_2);
    const Space v2126_4 = (has_head(v2126_3) ? constant_9 : Space{});
    const Space v2126_5 = subtract(constant_0,v2126_4);
    Space v2126_8;
    if (!v2126_5.empty()) {
      const Path v2127_6 = concat_path(p0,v2125_15_head);
      Space v2127_7_result;
      for (int v2127_7_label = 1; v2127_7_label <= 2; ++v2127_7_label) {
        const Space v2127_7_tail = child(v2125_15_tail,v2127_7_label);
        if (v2127_7_tail.empty()) continue;
        const Path v2127_7_head{v2127_7_label};
        const Space v2128_2 = singleton(v2127_7_head);
        const Space v2128_3 = intersect(constant_8,v2128_2);
        const Space v2128_4 = (has_head(v2128_3) ? constant_9 : Space{});
        const Space v2128_5 = subtract(constant_0,v2128_4);
        Space v2128_8;
        if (!v2128_5.empty()) {
          const Path v2129_6 = concat_path(v2127_6,v2127_7_head);
          const Space v2129_7 = routine_307(c, v2129_6, p1, p2, p3, v2127_7_tail);
          v2128_8 = compose(v2128_5,v2129_7);
        }
        const Space v2128_9 = intersect(constant_8,v2128_2);
        const Space v2128_10 = (has_head(v2128_9) ? constant_9 : Space{});
        Space v2128_12;
        if (!v2128_10.empty()) {
          const Path v2130_6 = concat_path(v2127_6,v2127_7_head);
          const Space v2130_11 = routine_308(c, v2130_6, p1, p2, p3, v2127_7_tail);
          v2128_12 = compose(v2128_10,v2130_11);
        }
        const Space v2128_13 = unite(v2128_8,v2128_12);
        v2127_7_result = unite(v2127_7_result,v2128_13);
      }
      const Space v2127_7 = std::move(v2127_7_result);
      v2126_8 = compose(v2126_5,v2127_7);
    }
    const Space v2126_9 = intersect(constant_8,v2126_2);
    const Space v2126_10 = (has_head(v2126_9) ? constant_9 : Space{});
    Space v2126_19;
    if (!v2126_10.empty()) {
      const Path v2131_6 = concat_path(p0,v2125_15_head);
      Space v2131_11_result;
      for (int v2131_11_label = 1; v2131_11_label <= 2; ++v2131_11_label) {
        const Space v2131_11_tail = child(v2125_15_tail,v2131_11_label);
        if (v2131_11_tail.empty()) continue;
        const Path v2131_11_head{v2131_11_label};
        const Space v2132_2 = singleton(v2131_11_head);
        const Space v2132_3 = intersect(constant_8,v2132_2);
        const Space v2132_4 = (has_head(v2132_3) ? constant_9 : Space{});
        const Space v2132_5 = subtract(constant_0,v2132_4);
        Space v2132_7;
        if (!v2132_5.empty()) {
          const Space v2133_6 = routine_265(c, v2131_11_head, v2131_11_tail);
          v2132_7 = compose(v2132_5,v2133_6);
        }
        const Space v2132_8 = intersect(constant_8,v2132_2);
        const Space v2132_9 = (has_head(v2132_8) ? constant_9 : Space{});
        Space v2132_11;
        if (!v2132_9.empty()) {
          const Space v2134_10 = routine_266(c, v2131_11_head, v2131_11_tail);
          v2132_11 = compose(v2132_9,v2134_10);
        }
        const Space v2132_12 = unite(v2132_7,v2132_11);
        v2131_11_result = unite(v2131_11_result,v2132_12);
      }
      const Space v2131_11 = std::move(v2131_11_result);
      const Space v2131_12 = raffine(constant_25,v2131_11);
      const Space v2131_13 = unite(v2131_12,v2125_15_tail);
      const Path v2131_14 = concat_path(p3,v2131_6);
      const Space v2131_15 = wrap(v2131_13,v2131_14);
      const Space v2131_16 = unwrap(v2131_15,p1);
      const Space v2131_17 = unwrap(v2131_16,p2);
      const Space v2131_18 = unwrap(v2131_17,p1);
      v2126_19 = compose(v2126_10,v2131_18);
    }
    const Space v2126_20 = unite(v2126_8,v2126_19);
    v2125_15_result = unite(v2125_15_result,v2126_20);
  }
  const Space v2125_15 = std::move(v2125_15_result);
  return v2125_15;
}

static Space routine_265(Context& c, const Path& p0, const Space& s0) {
  Space v2135_11_result;
  for (int v2135_11_label = 1; v2135_11_label <= 2; ++v2135_11_label) {
    const Space v2135_11_tail = child(s0,v2135_11_label);
    if (v2135_11_tail.empty()) continue;
    const Path v2135_11_head{v2135_11_label};
    const Space v2136_2 = singleton(v2135_11_head);
    const Space v2136_3 = intersect(constant_8,v2136_2);
    const Space v2136_4 = (has_head(v2136_3) ? constant_9 : Space{});
    const Space v2136_5 = subtract(constant_0,v2136_4);
    Space v2136_8;
    if (!v2136_5.empty()) {
      const Path v2137_6 = concat_path(p0,v2135_11_head);
      Space v2137_7_result;
      for (int v2137_7_label = 1; v2137_7_label <= 2; ++v2137_7_label) {
        const Space v2137_7_tail = child(v2135_11_tail,v2137_7_label);
        if (v2137_7_tail.empty()) continue;
        const Path v2137_7_head{v2137_7_label};
        const Space v2138_2 = singleton(v2137_7_head);
        const Space v2138_3 = intersect(constant_8,v2138_2);
        const Space v2138_4 = (has_head(v2138_3) ? constant_9 : Space{});
        const Space v2138_5 = subtract(constant_0,v2138_4);
        Space v2138_8;
        if (!v2138_5.empty()) {
          const Path v2139_6 = concat_path(v2137_6,v2137_7_head);
          const Space v2139_7 = routine_309(c, v2139_6, v2137_7_tail);
          v2138_8 = compose(v2138_5,v2139_7);
        }
        const Space v2138_9 = intersect(constant_8,v2138_2);
        const Space v2138_10 = (has_head(v2138_9) ? constant_9 : Space{});
        Space v2138_12;
        if (!v2138_10.empty()) {
          const Path v2140_6 = concat_path(v2137_6,v2137_7_head);
          const Space v2140_11 = routine_310(c, v2140_6, v2137_7_tail);
          v2138_12 = compose(v2138_10,v2140_11);
        }
        const Space v2138_13 = unite(v2138_8,v2138_12);
        v2137_7_result = unite(v2137_7_result,v2138_13);
      }
      const Space v2137_7 = std::move(v2137_7_result);
      v2136_8 = compose(v2136_5,v2137_7);
    }
    const Space v2136_9 = intersect(constant_8,v2136_2);
    const Space v2136_10 = (has_head(v2136_9) ? constant_9 : Space{});
    Space v2136_12;
    if (!v2136_10.empty()) {
      const Path v2141_6 = concat_path(p0,v2135_11_head);
      Space v2141_11_result;
      for (int v2141_11_label = 1; v2141_11_label <= 2; ++v2141_11_label) {
        const Space v2141_11_tail = child(v2135_11_tail,v2141_11_label);
        if (v2141_11_tail.empty()) continue;
        const Path v2141_11_head{v2141_11_label};
        const Space v2142_2 = singleton(v2141_11_head);
        const Space v2142_3 = intersect(constant_8,v2142_2);
        const Space v2142_4 = (has_head(v2142_3) ? constant_9 : Space{});
        const Space v2142_5 = subtract(constant_0,v2142_4);
        Space v2142_8;
        if (!v2142_5.empty()) {
          const Path v2143_6 = concat_path(v2141_6,v2141_11_head);
          const Space v2143_7 = routine_309(c, v2143_6, v2141_11_tail);
          v2142_8 = compose(v2142_5,v2143_7);
        }
        const Space v2142_9 = intersect(constant_8,v2142_2);
        const Space v2142_10 = (has_head(v2142_9) ? constant_9 : Space{});
        Space v2142_12;
        if (!v2142_10.empty()) {
          const Path v2144_6 = concat_path(v2141_6,v2141_11_head);
          const Space v2144_11 = routine_294(c, v2144_6, v2141_11_tail);
          v2142_12 = compose(v2142_10,v2144_11);
        }
        const Space v2142_13 = unite(v2142_8,v2142_12);
        v2141_11_result = unite(v2141_11_result,v2142_13);
      }
      const Space v2141_11 = std::move(v2141_11_result);
      v2136_12 = compose(v2136_10,v2141_11);
    }
    const Space v2136_13 = unite(v2136_8,v2136_12);
    v2135_11_result = unite(v2135_11_result,v2136_13);
  }
  const Space v2135_11 = std::move(v2135_11_result);
  return v2135_11;
}

static Space routine_266(Context& c, const Path& p0, const Space& s0) {
  Space v2145_8_result;
  for (int v2145_8_label = 1; v2145_8_label <= 2; ++v2145_8_label) {
    const Space v2145_8_tail = child(s0,v2145_8_label);
    if (v2145_8_tail.empty()) continue;
    const Path v2145_8_head{v2145_8_label};
    const Space v2146_2 = singleton(v2145_8_head);
    const Space v2146_3 = intersect(constant_8,v2146_2);
    const Space v2146_4 = (has_head(v2146_3) ? constant_9 : Space{});
    const Space v2146_5 = subtract(constant_0,v2146_4);
    Space v2146_8;
    if (!v2146_5.empty()) {
      const Path v2147_6 = concat_path(p0,v2145_8_head);
      Space v2147_7_result;
      for (int v2147_7_label = 1; v2147_7_label <= 2; ++v2147_7_label) {
        const Space v2147_7_tail = child(v2145_8_tail,v2147_7_label);
        if (v2147_7_tail.empty()) continue;
        const Path v2147_7_head{v2147_7_label};
        const Space v2148_2 = singleton(v2147_7_head);
        const Space v2148_3 = intersect(constant_8,v2148_2);
        const Space v2148_4 = (has_head(v2148_3) ? constant_9 : Space{});
        const Space v2148_5 = subtract(constant_0,v2148_4);
        Space v2148_8;
        if (!v2148_5.empty()) {
          const Path v2149_6 = concat_path(v2147_6,v2147_7_head);
          const Space v2149_7 = routine_309(c, v2149_6, v2147_7_tail);
          v2148_8 = compose(v2148_5,v2149_7);
        }
        const Space v2148_9 = intersect(constant_8,v2148_2);
        const Space v2148_10 = (has_head(v2148_9) ? constant_9 : Space{});
        Space v2148_12;
        if (!v2148_10.empty()) {
          const Path v2150_6 = concat_path(v2147_6,v2147_7_head);
          const Space v2150_11 = routine_310(c, v2150_6, v2147_7_tail);
          v2148_12 = compose(v2148_10,v2150_11);
        }
        const Space v2148_13 = unite(v2148_8,v2148_12);
        v2147_7_result = unite(v2147_7_result,v2148_13);
      }
      const Space v2147_7 = std::move(v2147_7_result);
      v2146_8 = compose(v2146_5,v2147_7);
    }
    const Space v2146_9 = intersect(constant_8,v2146_2);
    const Space v2146_10 = (has_head(v2146_9) ? constant_9 : Space{});
    const Path v2151_6 = concat_path(p0,v2145_8_head);
    const Space v2146_11 = singleton(v2151_6);
    const Space v2146_12 = compose(v2146_10,v2146_11);
    const Space v2146_13 = unite(v2146_8,v2146_12);
    v2145_8_result = unite(v2145_8_result,v2146_13);
  }
  const Space v2145_8 = std::move(v2145_8_result);
  return v2145_8;
}

static Space routine_267(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v2152_3 = Space{};
  return v2152_3;
}

static Space routine_268(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v2153_4_result;
  for (int v2153_4_label = 1; v2153_4_label <= 2; ++v2153_4_label) {
    const Space v2153_4_tail = child(s0,v2153_4_label);
    if (v2153_4_tail.empty()) continue;
    const Path v2153_4_head{v2153_4_label};
    const Space v2154_2 = singleton(v2153_4_head);
    const Space v2154_3 = intersect(constant_8,v2154_2);
    const Space v2154_4 = (has_head(v2154_3) ? constant_9 : Space{});
    Space v2154_7;
    if (!v2154_4.empty()) {
      const Path v2155_5 = concat_path(p0,v2153_4_head);
      const Space v2155_6 = routine_186(c, v2155_5, s1);
      v2154_7 = compose(v2154_4,v2155_6);
    }
    v2153_4_result = unite(v2153_4_result,v2154_7);
  }
  const Space v2153_4 = std::move(v2153_4_result);
  return v2153_4;
}

static Space routine_269(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2156_3 = Space{};
  return v2156_3;
}

static Space routine_270(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2157_7_result;
  for (int v2157_7_label = 1; v2157_7_label <= 2; ++v2157_7_label) {
    const Space v2157_7_tail = child(s0,v2157_7_label);
    if (v2157_7_tail.empty()) continue;
    const Path v2157_7_head{v2157_7_label};
    const Space v2158_2 = singleton(v2157_7_head);
    const Space v2158_3 = intersect(constant_8,v2158_2);
    const Space v2158_4 = (has_head(v2158_3) ? constant_9 : Space{});
    Space v2158_7;
    if (!v2158_4.empty()) {
      const Path v2159_5 = concat_path(p0,v2157_7_head);
      Space v2159_6_result;
      for (int v2159_6_label = 1; v2159_6_label <= 2; ++v2159_6_label) {
        const Space v2159_6_tail = child(v2157_7_tail,v2159_6_label);
        if (v2159_6_tail.empty()) continue;
        const Path v2159_6_head{v2159_6_label};
        const Space v2160_2 = singleton(v2159_6_head);
        const Space v2160_3 = intersect(constant_8,v2160_2);
        const Space v2160_4 = (has_head(v2160_3) ? constant_9 : Space{});
        const Space v2160_5 = subtract(constant_0,v2160_4);
        Space v2160_7;
        if (!v2160_5.empty()) {
          const Space v2161_6 = routine_193(c, v2159_6_head, p1, v2159_5, v2159_6_tail);
          v2160_7 = compose(v2160_5,v2161_6);
        }
        const Space v2160_8 = intersect(constant_8,v2160_2);
        const Space v2160_9 = (has_head(v2160_8) ? constant_9 : Space{});
        Space v2160_11;
        if (!v2160_9.empty()) {
          const Space v2162_10 = routine_194(c, v2159_6_head, p1, v2159_5, v2159_6_tail);
          v2160_11 = compose(v2160_9,v2162_10);
        }
        const Space v2160_12 = unite(v2160_7,v2160_11);
        v2159_6_result = unite(v2159_6_result,v2160_12);
      }
      const Space v2159_6 = std::move(v2159_6_result);
      v2158_7 = compose(v2158_4,v2159_6);
    }
    v2157_7_result = unite(v2157_7_result,v2158_7);
  }
  const Space v2157_7 = std::move(v2157_7_result);
  return v2157_7;
}

static Space routine_271(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2163_13_result;
  for (int v2163_13_label = 1; v2163_13_label <= 2; ++v2163_13_label) {
    const Space v2163_13_tail = child(s0,v2163_13_label);
    if (v2163_13_tail.empty()) continue;
    const Path v2163_13_head{v2163_13_label};
    const Space v2164_2 = singleton(v2163_13_head);
    const Space v2164_3 = intersect(constant_8,v2164_2);
    const Space v2164_4 = (has_head(v2164_3) ? constant_9 : Space{});
    const Space v2164_5 = subtract(constant_0,v2164_4);
    Space v2164_8;
    if (!v2164_5.empty()) {
      const Path v2165_6 = concat_path(p0,v2163_13_head);
      Space v2165_7_result;
      for (int v2165_7_label = 1; v2165_7_label <= 2; ++v2165_7_label) {
        const Space v2165_7_tail = child(v2163_13_tail,v2165_7_label);
        if (v2165_7_tail.empty()) continue;
        const Path v2165_7_head{v2165_7_label};
        const Space v2166_2 = singleton(v2165_7_head);
        const Space v2166_3 = intersect(constant_8,v2166_2);
        const Space v2166_4 = (has_head(v2166_3) ? constant_9 : Space{});
        const Space v2166_5 = subtract(constant_0,v2166_4);
        Space v2166_8;
        if (!v2166_5.empty()) {
          const Path v2167_6 = concat_path(v2165_6,v2165_7_head);
          const Space v2167_7 = routine_311(c, v2167_6, p1, p2, v2165_7_tail);
          v2166_8 = compose(v2166_5,v2167_7);
        }
        const Space v2166_9 = intersect(constant_8,v2166_2);
        const Space v2166_10 = (has_head(v2166_9) ? constant_9 : Space{});
        Space v2166_12;
        if (!v2166_10.empty()) {
          const Path v2168_6 = concat_path(v2165_6,v2165_7_head);
          const Space v2168_11 = routine_312(c, v2168_6, p1, p2, v2165_7_tail);
          v2166_12 = compose(v2166_10,v2168_11);
        }
        const Space v2166_13 = unite(v2166_8,v2166_12);
        v2165_7_result = unite(v2165_7_result,v2166_13);
      }
      const Space v2165_7 = std::move(v2165_7_result);
      v2164_8 = compose(v2164_5,v2165_7);
    }
    const Space v2164_9 = intersect(constant_8,v2164_2);
    const Space v2164_10 = (has_head(v2164_9) ? constant_9 : Space{});
    Space v2164_12;
    if (!v2164_10.empty()) {
      const Path v2169_6 = concat_path(p0,v2163_13_head);
      Space v2169_11_result;
      for (int v2169_11_label = 1; v2169_11_label <= 2; ++v2169_11_label) {
        const Space v2169_11_tail = child(v2163_13_tail,v2169_11_label);
        if (v2169_11_tail.empty()) continue;
        const Path v2169_11_head{v2169_11_label};
        const Space v2170_2 = singleton(v2169_11_head);
        const Space v2170_3 = intersect(constant_8,v2170_2);
        const Space v2170_4 = (has_head(v2170_3) ? constant_9 : Space{});
        const Space v2170_5 = subtract(constant_0,v2170_4);
        Space v2170_8;
        if (!v2170_5.empty()) {
          const Path v2171_6 = concat_path(v2169_6,v2169_11_head);
          const Space v2171_7 = routine_311(c, v2171_6, p1, p2, v2169_11_tail);
          v2170_8 = compose(v2170_5,v2171_7);
        }
        const Space v2170_9 = intersect(constant_8,v2170_2);
        const Space v2170_10 = (has_head(v2170_9) ? constant_9 : Space{});
        Space v2170_12;
        if (!v2170_10.empty()) {
          const Path v2172_6 = concat_path(v2169_6,v2169_11_head);
          const Space v2172_11 = routine_237(c, v2172_6, p1, p2, v2169_11_tail);
          v2170_12 = compose(v2170_10,v2172_11);
        }
        const Space v2170_13 = unite(v2170_8,v2170_12);
        v2169_11_result = unite(v2169_11_result,v2170_13);
      }
      const Space v2169_11 = std::move(v2169_11_result);
      v2164_12 = compose(v2164_10,v2169_11);
    }
    const Space v2164_13 = unite(v2164_8,v2164_12);
    v2163_13_result = unite(v2163_13_result,v2164_13);
  }
  const Space v2163_13 = std::move(v2163_13_result);
  return v2163_13;
}

static Space routine_272(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2173_9 = concat_path(constant_23,p2);
  const Space v2173_10 = singleton(v2173_9);
  const Space v2173_11 = unite(constant_26,v2173_10);
  const Path v2173_13 = concat_path(constant_22,p1);
  const Space v2173_14 = singleton(v2173_13);
  const Space v2173_15 = unite(v2173_11,v2173_14);
  Space v2173_20_result;
  for (int v2173_20_label = 1; v2173_20_label <= 2; ++v2173_20_label) {
    const Space v2173_20_tail = child(s0,v2173_20_label);
    if (v2173_20_tail.empty()) continue;
    const Path v2173_20_head{v2173_20_label};
    const Space v2174_2 = singleton(v2173_20_head);
    const Space v2174_3 = intersect(constant_8,v2174_2);
    const Space v2174_4 = (has_head(v2174_3) ? constant_9 : Space{});
    const Space v2174_5 = subtract(constant_0,v2174_4);
    Space v2174_8;
    if (!v2174_5.empty()) {
      const Path v2175_6 = concat_path(p0,v2173_20_head);
      Space v2175_7_result;
      for (int v2175_7_label = 1; v2175_7_label <= 2; ++v2175_7_label) {
        const Space v2175_7_tail = child(v2173_20_tail,v2175_7_label);
        if (v2175_7_tail.empty()) continue;
        const Path v2175_7_head{v2175_7_label};
        const Space v2176_2 = singleton(v2175_7_head);
        const Space v2176_3 = intersect(constant_8,v2176_2);
        const Space v2176_4 = (has_head(v2176_3) ? constant_9 : Space{});
        const Space v2176_5 = subtract(constant_0,v2176_4);
        Space v2176_8;
        if (!v2176_5.empty()) {
          const Path v2177_6 = concat_path(v2175_6,v2175_7_head);
          const Space v2177_7 = routine_311(c, v2177_6, p1, p2, v2175_7_tail);
          v2176_8 = compose(v2176_5,v2177_7);
        }
        const Space v2176_9 = intersect(constant_8,v2176_2);
        const Space v2176_10 = (has_head(v2176_9) ? constant_9 : Space{});
        Space v2176_12;
        if (!v2176_10.empty()) {
          const Path v2178_6 = concat_path(v2175_6,v2175_7_head);
          const Space v2178_11 = routine_312(c, v2178_6, p1, p2, v2175_7_tail);
          v2176_12 = compose(v2176_10,v2178_11);
        }
        const Space v2176_13 = unite(v2176_8,v2176_12);
        v2175_7_result = unite(v2175_7_result,v2176_13);
      }
      const Space v2175_7 = std::move(v2175_7_result);
      v2174_8 = compose(v2174_5,v2175_7);
    }
    const Space v2174_9 = intersect(constant_8,v2174_2);
    const Space v2174_10 = (has_head(v2174_9) ? constant_9 : Space{});
    const Path v2179_6 = concat_path(p0,v2173_20_head);
    const Path v2174_11 = concat_path(constant_6,v2179_6);
    const Space v2174_12 = singleton(v2174_11);
    const Space v2174_13 = unite(v2173_15,v2174_12);
    const Space v2174_14 = compose(v2174_10,v2174_13);
    const Space v2174_15 = unite(v2174_8,v2174_14);
    v2173_20_result = unite(v2173_20_result,v2174_15);
  }
  const Space v2173_20 = std::move(v2173_20_result);
  return v2173_20;
}

static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2180_3 = Space{};
  return v2180_3;
}

static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2181_7_result;
  for (int v2181_7_label = 1; v2181_7_label <= 2; ++v2181_7_label) {
    const Space v2181_7_tail = child(s0,v2181_7_label);
    if (v2181_7_tail.empty()) continue;
    const Path v2181_7_head{v2181_7_label};
    const Space v2182_2 = singleton(v2181_7_head);
    const Space v2182_3 = intersect(constant_8,v2182_2);
    const Space v2182_4 = (has_head(v2182_3) ? constant_9 : Space{});
    Space v2182_7;
    if (!v2182_4.empty()) {
      const Path v2183_5 = concat_path(p0,v2181_7_head);
      Space v2183_6_result;
      for (int v2183_6_label = 1; v2183_6_label <= 2; ++v2183_6_label) {
        const Space v2183_6_tail = child(v2181_7_tail,v2183_6_label);
        if (v2183_6_tail.empty()) continue;
        const Path v2183_6_head{v2183_6_label};
        const Space v2184_2 = singleton(v2183_6_head);
        const Space v2184_3 = intersect(constant_8,v2184_2);
        const Space v2184_4 = (has_head(v2184_3) ? constant_9 : Space{});
        const Space v2184_5 = subtract(constant_0,v2184_4);
        Space v2184_7;
        if (!v2184_5.empty()) {
          const Space v2185_6 = routine_201(c, v2183_6_head, p1, v2183_5, v2183_6_tail);
          v2184_7 = compose(v2184_5,v2185_6);
        }
        const Space v2184_8 = intersect(constant_8,v2184_2);
        const Space v2184_9 = (has_head(v2184_8) ? constant_9 : Space{});
        Space v2184_11;
        if (!v2184_9.empty()) {
          const Space v2186_10 = routine_202(c, v2183_6_head, p1, v2183_5, v2183_6_tail);
          v2184_11 = compose(v2184_9,v2186_10);
        }
        const Space v2184_12 = unite(v2184_7,v2184_11);
        v2183_6_result = unite(v2183_6_result,v2184_12);
      }
      const Space v2183_6 = std::move(v2183_6_result);
      v2182_7 = compose(v2182_4,v2183_6);
    }
    v2181_7_result = unite(v2181_7_result,v2182_7);
  }
  const Space v2181_7 = std::move(v2181_7_result);
  return v2181_7;
}

static Space routine_275(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2187_13_result;
  for (int v2187_13_label = 1; v2187_13_label <= 2; ++v2187_13_label) {
    const Space v2187_13_tail = child(s0,v2187_13_label);
    if (v2187_13_tail.empty()) continue;
    const Path v2187_13_head{v2187_13_label};
    const Space v2188_2 = singleton(v2187_13_head);
    const Space v2188_3 = intersect(constant_8,v2188_2);
    const Space v2188_4 = (has_head(v2188_3) ? constant_9 : Space{});
    const Space v2188_5 = subtract(constant_0,v2188_4);
    Space v2188_8;
    if (!v2188_5.empty()) {
      const Path v2189_6 = concat_path(p0,v2187_13_head);
      Space v2189_7_result;
      for (int v2189_7_label = 1; v2189_7_label <= 2; ++v2189_7_label) {
        const Space v2189_7_tail = child(v2187_13_tail,v2189_7_label);
        if (v2189_7_tail.empty()) continue;
        const Path v2189_7_head{v2189_7_label};
        const Space v2190_2 = singleton(v2189_7_head);
        const Space v2190_3 = intersect(constant_8,v2190_2);
        const Space v2190_4 = (has_head(v2190_3) ? constant_9 : Space{});
        const Space v2190_5 = subtract(constant_0,v2190_4);
        Space v2190_8;
        if (!v2190_5.empty()) {
          const Path v2191_6 = concat_path(v2189_6,v2189_7_head);
          const Space v2191_7 = routine_313(c, v2191_6, p1, p2, v2189_7_tail);
          v2190_8 = compose(v2190_5,v2191_7);
        }
        const Space v2190_9 = intersect(constant_8,v2190_2);
        const Space v2190_10 = (has_head(v2190_9) ? constant_9 : Space{});
        Space v2190_12;
        if (!v2190_10.empty()) {
          const Path v2192_6 = concat_path(v2189_6,v2189_7_head);
          const Space v2192_11 = routine_314(c, v2192_6, p1, p2, v2189_7_tail);
          v2190_12 = compose(v2190_10,v2192_11);
        }
        const Space v2190_13 = unite(v2190_8,v2190_12);
        v2189_7_result = unite(v2189_7_result,v2190_13);
      }
      const Space v2189_7 = std::move(v2189_7_result);
      v2188_8 = compose(v2188_5,v2189_7);
    }
    const Space v2188_9 = intersect(constant_8,v2188_2);
    const Space v2188_10 = (has_head(v2188_9) ? constant_9 : Space{});
    Space v2188_12;
    if (!v2188_10.empty()) {
      const Path v2193_6 = concat_path(p0,v2187_13_head);
      Space v2193_11_result;
      for (int v2193_11_label = 1; v2193_11_label <= 2; ++v2193_11_label) {
        const Space v2193_11_tail = child(v2187_13_tail,v2193_11_label);
        if (v2193_11_tail.empty()) continue;
        const Path v2193_11_head{v2193_11_label};
        const Space v2194_2 = singleton(v2193_11_head);
        const Space v2194_3 = intersect(constant_8,v2194_2);
        const Space v2194_4 = (has_head(v2194_3) ? constant_9 : Space{});
        const Space v2194_5 = subtract(constant_0,v2194_4);
        Space v2194_8;
        if (!v2194_5.empty()) {
          const Path v2195_6 = concat_path(v2193_6,v2193_11_head);
          const Space v2195_7 = routine_313(c, v2195_6, p1, p2, v2193_11_tail);
          v2194_8 = compose(v2194_5,v2195_7);
        }
        const Space v2194_9 = intersect(constant_8,v2194_2);
        const Space v2194_10 = (has_head(v2194_9) ? constant_9 : Space{});
        Space v2194_12;
        if (!v2194_10.empty()) {
          const Path v2196_6 = concat_path(v2193_6,v2193_11_head);
          const Space v2196_11 = routine_242(c, v2196_6, p1, p2, v2193_11_tail);
          v2194_12 = compose(v2194_10,v2196_11);
        }
        const Space v2194_13 = unite(v2194_8,v2194_12);
        v2193_11_result = unite(v2193_11_result,v2194_13);
      }
      const Space v2193_11 = std::move(v2193_11_result);
      v2188_12 = compose(v2188_10,v2193_11);
    }
    const Space v2188_13 = unite(v2188_8,v2188_12);
    v2187_13_result = unite(v2187_13_result,v2188_13);
  }
  const Space v2187_13 = std::move(v2187_13_result);
  return v2187_13;
}

static Space routine_276(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2197_10 = concat_path(constant_22,p1);
  const Space v2197_11 = singleton(v2197_10);
  const Path v2197_13 = concat_path(constant_6,p2);
  const Space v2197_14 = singleton(v2197_13);
  Space v2197_18_result;
  for (int v2197_18_label = 1; v2197_18_label <= 2; ++v2197_18_label) {
    const Space v2197_18_tail = child(s0,v2197_18_label);
    if (v2197_18_tail.empty()) continue;
    const Path v2197_18_head{v2197_18_label};
    const Space v2198_2 = singleton(v2197_18_head);
    const Space v2198_3 = intersect(constant_8,v2198_2);
    const Space v2198_4 = (has_head(v2198_3) ? constant_9 : Space{});
    const Space v2198_5 = subtract(constant_0,v2198_4);
    Space v2198_8;
    if (!v2198_5.empty()) {
      const Path v2199_6 = concat_path(p0,v2197_18_head);
      Space v2199_7_result;
      for (int v2199_7_label = 1; v2199_7_label <= 2; ++v2199_7_label) {
        const Space v2199_7_tail = child(v2197_18_tail,v2199_7_label);
        if (v2199_7_tail.empty()) continue;
        const Path v2199_7_head{v2199_7_label};
        const Space v2200_2 = singleton(v2199_7_head);
        const Space v2200_3 = intersect(constant_8,v2200_2);
        const Space v2200_4 = (has_head(v2200_3) ? constant_9 : Space{});
        const Space v2200_5 = subtract(constant_0,v2200_4);
        Space v2200_8;
        if (!v2200_5.empty()) {
          const Path v2201_6 = concat_path(v2199_6,v2199_7_head);
          const Space v2201_7 = routine_313(c, v2201_6, p1, p2, v2199_7_tail);
          v2200_8 = compose(v2200_5,v2201_7);
        }
        const Space v2200_9 = intersect(constant_8,v2200_2);
        const Space v2200_10 = (has_head(v2200_9) ? constant_9 : Space{});
        Space v2200_12;
        if (!v2200_10.empty()) {
          const Path v2202_6 = concat_path(v2199_6,v2199_7_head);
          const Space v2202_11 = routine_314(c, v2202_6, p1, p2, v2199_7_tail);
          v2200_12 = compose(v2200_10,v2202_11);
        }
        const Space v2200_13 = unite(v2200_8,v2200_12);
        v2199_7_result = unite(v2199_7_result,v2200_13);
      }
      const Space v2199_7 = std::move(v2199_7_result);
      v2198_8 = compose(v2198_5,v2199_7);
    }
    const Space v2198_9 = intersect(constant_8,v2198_2);
    const Space v2198_10 = (has_head(v2198_9) ? constant_9 : Space{});
    const Path v2203_6 = concat_path(p0,v2197_18_head);
    const Path v2198_11 = concat_path(constant_24,v2203_6);
    const Space v2198_12 = singleton(v2198_11);
    const Space v2198_13 = unite(constant_27,v2198_12);
    const Space v2198_14 = unite(v2198_13,v2197_11);
    const Space v2198_15 = unite(v2198_14,v2197_14);
    const Space v2198_16 = compose(v2198_10,v2198_15);
    const Space v2198_17 = unite(v2198_8,v2198_16);
    v2197_18_result = unite(v2197_18_result,v2198_17);
  }
  const Space v2197_18 = std::move(v2197_18_result);
  return v2197_18;
}

static Space routine_277(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2204_3 = Space{};
  return v2204_3;
}

static Space routine_278(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2205_7_result;
  for (int v2205_7_label = 1; v2205_7_label <= 2; ++v2205_7_label) {
    const Space v2205_7_tail = child(s0,v2205_7_label);
    if (v2205_7_tail.empty()) continue;
    const Path v2205_7_head{v2205_7_label};
    const Space v2206_2 = singleton(v2205_7_head);
    const Space v2206_3 = intersect(constant_8,v2206_2);
    const Space v2206_4 = (has_head(v2206_3) ? constant_9 : Space{});
    Space v2206_7;
    if (!v2206_4.empty()) {
      const Path v2207_5 = concat_path(p0,v2205_7_head);
      Space v2207_6_result;
      for (int v2207_6_label = 1; v2207_6_label <= 2; ++v2207_6_label) {
        const Space v2207_6_tail = child(v2205_7_tail,v2207_6_label);
        if (v2207_6_tail.empty()) continue;
        const Path v2207_6_head{v2207_6_label};
        const Space v2208_2 = singleton(v2207_6_head);
        const Space v2208_3 = intersect(constant_8,v2208_2);
        const Space v2208_4 = (has_head(v2208_3) ? constant_9 : Space{});
        const Space v2208_5 = subtract(constant_0,v2208_4);
        Space v2208_7;
        if (!v2208_5.empty()) {
          const Space v2209_6 = routine_209(c, v2207_6_head, p1, v2207_5, v2207_6_tail);
          v2208_7 = compose(v2208_5,v2209_6);
        }
        const Space v2208_8 = intersect(constant_8,v2208_2);
        const Space v2208_9 = (has_head(v2208_8) ? constant_9 : Space{});
        Space v2208_11;
        if (!v2208_9.empty()) {
          const Space v2210_10 = routine_210(c, v2207_6_head, p1, v2207_5, v2207_6_tail);
          v2208_11 = compose(v2208_9,v2210_10);
        }
        const Space v2208_12 = unite(v2208_7,v2208_11);
        v2207_6_result = unite(v2207_6_result,v2208_12);
      }
      const Space v2207_6 = std::move(v2207_6_result);
      v2206_7 = compose(v2206_4,v2207_6);
    }
    v2205_7_result = unite(v2205_7_result,v2206_7);
  }
  const Space v2205_7 = std::move(v2205_7_result);
  return v2205_7;
}

static Space routine_279(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2211_13_result;
  for (int v2211_13_label = 1; v2211_13_label <= 2; ++v2211_13_label) {
    const Space v2211_13_tail = child(s0,v2211_13_label);
    if (v2211_13_tail.empty()) continue;
    const Path v2211_13_head{v2211_13_label};
    const Space v2212_2 = singleton(v2211_13_head);
    const Space v2212_3 = intersect(constant_8,v2212_2);
    const Space v2212_4 = (has_head(v2212_3) ? constant_9 : Space{});
    const Space v2212_5 = subtract(constant_0,v2212_4);
    Space v2212_8;
    if (!v2212_5.empty()) {
      const Path v2213_6 = concat_path(p0,v2211_13_head);
      Space v2213_7_result;
      for (int v2213_7_label = 1; v2213_7_label <= 2; ++v2213_7_label) {
        const Space v2213_7_tail = child(v2211_13_tail,v2213_7_label);
        if (v2213_7_tail.empty()) continue;
        const Path v2213_7_head{v2213_7_label};
        const Space v2214_2 = singleton(v2213_7_head);
        const Space v2214_3 = intersect(constant_8,v2214_2);
        const Space v2214_4 = (has_head(v2214_3) ? constant_9 : Space{});
        const Space v2214_5 = subtract(constant_0,v2214_4);
        Space v2214_8;
        if (!v2214_5.empty()) {
          const Path v2215_6 = concat_path(v2213_6,v2213_7_head);
          const Space v2215_7 = routine_315(c, v2215_6, p1, p2, v2213_7_tail);
          v2214_8 = compose(v2214_5,v2215_7);
        }
        const Space v2214_9 = intersect(constant_8,v2214_2);
        const Space v2214_10 = (has_head(v2214_9) ? constant_9 : Space{});
        Space v2214_12;
        if (!v2214_10.empty()) {
          const Path v2216_6 = concat_path(v2213_6,v2213_7_head);
          const Space v2216_11 = routine_316(c, v2216_6, p1, p2, v2213_7_tail);
          v2214_12 = compose(v2214_10,v2216_11);
        }
        const Space v2214_13 = unite(v2214_8,v2214_12);
        v2213_7_result = unite(v2213_7_result,v2214_13);
      }
      const Space v2213_7 = std::move(v2213_7_result);
      v2212_8 = compose(v2212_5,v2213_7);
    }
    const Space v2212_9 = intersect(constant_8,v2212_2);
    const Space v2212_10 = (has_head(v2212_9) ? constant_9 : Space{});
    Space v2212_12;
    if (!v2212_10.empty()) {
      const Path v2217_6 = concat_path(p0,v2211_13_head);
      Space v2217_11_result;
      for (int v2217_11_label = 1; v2217_11_label <= 2; ++v2217_11_label) {
        const Space v2217_11_tail = child(v2211_13_tail,v2217_11_label);
        if (v2217_11_tail.empty()) continue;
        const Path v2217_11_head{v2217_11_label};
        const Space v2218_2 = singleton(v2217_11_head);
        const Space v2218_3 = intersect(constant_8,v2218_2);
        const Space v2218_4 = (has_head(v2218_3) ? constant_9 : Space{});
        const Space v2218_5 = subtract(constant_0,v2218_4);
        Space v2218_8;
        if (!v2218_5.empty()) {
          const Path v2219_6 = concat_path(v2217_6,v2217_11_head);
          const Space v2219_7 = routine_315(c, v2219_6, p1, p2, v2217_11_tail);
          v2218_8 = compose(v2218_5,v2219_7);
        }
        const Space v2218_9 = intersect(constant_8,v2218_2);
        const Space v2218_10 = (has_head(v2218_9) ? constant_9 : Space{});
        Space v2218_12;
        if (!v2218_10.empty()) {
          const Path v2220_6 = concat_path(v2217_6,v2217_11_head);
          const Space v2220_11 = routine_247(c, v2220_6, p1, p2, v2217_11_tail);
          v2218_12 = compose(v2218_10,v2220_11);
        }
        const Space v2218_13 = unite(v2218_8,v2218_12);
        v2217_11_result = unite(v2217_11_result,v2218_13);
      }
      const Space v2217_11 = std::move(v2217_11_result);
      v2212_12 = compose(v2212_10,v2217_11);
    }
    const Space v2212_13 = unite(v2212_8,v2212_12);
    v2211_13_result = unite(v2211_13_result,v2212_13);
  }
  const Space v2211_13 = std::move(v2211_13_result);
  return v2211_13;
}

static Space routine_280(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2221_10 = concat_path(constant_23,p1);
  const Space v2221_11 = singleton(v2221_10);
  const Path v2221_13 = concat_path(constant_6,p2);
  const Space v2221_14 = singleton(v2221_13);
  Space v2221_18_result;
  for (int v2221_18_label = 1; v2221_18_label <= 2; ++v2221_18_label) {
    const Space v2221_18_tail = child(s0,v2221_18_label);
    if (v2221_18_tail.empty()) continue;
    const Path v2221_18_head{v2221_18_label};
    const Space v2222_2 = singleton(v2221_18_head);
    const Space v2222_3 = intersect(constant_8,v2222_2);
    const Space v2222_4 = (has_head(v2222_3) ? constant_9 : Space{});
    const Space v2222_5 = subtract(constant_0,v2222_4);
    Space v2222_8;
    if (!v2222_5.empty()) {
      const Path v2223_6 = concat_path(p0,v2221_18_head);
      Space v2223_7_result;
      for (int v2223_7_label = 1; v2223_7_label <= 2; ++v2223_7_label) {
        const Space v2223_7_tail = child(v2221_18_tail,v2223_7_label);
        if (v2223_7_tail.empty()) continue;
        const Path v2223_7_head{v2223_7_label};
        const Space v2224_2 = singleton(v2223_7_head);
        const Space v2224_3 = intersect(constant_8,v2224_2);
        const Space v2224_4 = (has_head(v2224_3) ? constant_9 : Space{});
        const Space v2224_5 = subtract(constant_0,v2224_4);
        Space v2224_8;
        if (!v2224_5.empty()) {
          const Path v2225_6 = concat_path(v2223_6,v2223_7_head);
          const Space v2225_7 = routine_315(c, v2225_6, p1, p2, v2223_7_tail);
          v2224_8 = compose(v2224_5,v2225_7);
        }
        const Space v2224_9 = intersect(constant_8,v2224_2);
        const Space v2224_10 = (has_head(v2224_9) ? constant_9 : Space{});
        Space v2224_12;
        if (!v2224_10.empty()) {
          const Path v2226_6 = concat_path(v2223_6,v2223_7_head);
          const Space v2226_11 = routine_316(c, v2226_6, p1, p2, v2223_7_tail);
          v2224_12 = compose(v2224_10,v2226_11);
        }
        const Space v2224_13 = unite(v2224_8,v2224_12);
        v2223_7_result = unite(v2223_7_result,v2224_13);
      }
      const Space v2223_7 = std::move(v2223_7_result);
      v2222_8 = compose(v2222_5,v2223_7);
    }
    const Space v2222_9 = intersect(constant_8,v2222_2);
    const Space v2222_10 = (has_head(v2222_9) ? constant_9 : Space{});
    const Path v2227_6 = concat_path(p0,v2221_18_head);
    const Path v2222_11 = concat_path(constant_24,v2227_6);
    const Space v2222_12 = singleton(v2222_11);
    const Space v2222_13 = unite(constant_28,v2222_12);
    const Space v2222_14 = unite(v2222_13,v2221_11);
    const Space v2222_15 = unite(v2222_14,v2221_14);
    const Space v2222_16 = compose(v2222_10,v2222_15);
    const Space v2222_17 = unite(v2222_8,v2222_16);
    v2221_18_result = unite(v2221_18_result,v2222_17);
  }
  const Space v2221_18 = std::move(v2221_18_result);
  return v2221_18;
}

static Space routine_281(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2228_3 = Space{};
  return v2228_3;
}

static Space routine_282(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2229_7_result;
  for (int v2229_7_label = 1; v2229_7_label <= 2; ++v2229_7_label) {
    const Space v2229_7_tail = child(s0,v2229_7_label);
    if (v2229_7_tail.empty()) continue;
    const Path v2229_7_head{v2229_7_label};
    const Space v2230_2 = singleton(v2229_7_head);
    const Space v2230_3 = intersect(constant_8,v2230_2);
    const Space v2230_4 = (has_head(v2230_3) ? constant_9 : Space{});
    Space v2230_7;
    if (!v2230_4.empty()) {
      const Path v2231_5 = concat_path(p0,v2229_7_head);
      Space v2231_6_result;
      for (int v2231_6_label = 1; v2231_6_label <= 2; ++v2231_6_label) {
        const Space v2231_6_tail = child(v2229_7_tail,v2231_6_label);
        if (v2231_6_tail.empty()) continue;
        const Path v2231_6_head{v2231_6_label};
        const Space v2232_2 = singleton(v2231_6_head);
        const Space v2232_3 = intersect(constant_8,v2232_2);
        const Space v2232_4 = (has_head(v2232_3) ? constant_9 : Space{});
        const Space v2232_5 = subtract(constant_0,v2232_4);
        Space v2232_7;
        if (!v2232_5.empty()) {
          const Space v2233_6 = routine_217(c, v2231_6_head, p1, v2231_5, v2231_6_tail);
          v2232_7 = compose(v2232_5,v2233_6);
        }
        const Space v2232_8 = intersect(constant_8,v2232_2);
        const Space v2232_9 = (has_head(v2232_8) ? constant_9 : Space{});
        Space v2232_11;
        if (!v2232_9.empty()) {
          const Space v2234_10 = routine_218(c, v2231_6_head, p1, v2231_5, v2231_6_tail);
          v2232_11 = compose(v2232_9,v2234_10);
        }
        const Space v2232_12 = unite(v2232_7,v2232_11);
        v2231_6_result = unite(v2231_6_result,v2232_12);
      }
      const Space v2231_6 = std::move(v2231_6_result);
      v2230_7 = compose(v2230_4,v2231_6);
    }
    v2229_7_result = unite(v2229_7_result,v2230_7);
  }
  const Space v2229_7 = std::move(v2229_7_result);
  return v2229_7;
}

static Space routine_283(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2235_13_result;
  for (int v2235_13_label = 1; v2235_13_label <= 2; ++v2235_13_label) {
    const Space v2235_13_tail = child(s0,v2235_13_label);
    if (v2235_13_tail.empty()) continue;
    const Path v2235_13_head{v2235_13_label};
    const Space v2236_2 = singleton(v2235_13_head);
    const Space v2236_3 = intersect(constant_8,v2236_2);
    const Space v2236_4 = (has_head(v2236_3) ? constant_9 : Space{});
    const Space v2236_5 = subtract(constant_0,v2236_4);
    Space v2236_8;
    if (!v2236_5.empty()) {
      const Path v2237_6 = concat_path(p0,v2235_13_head);
      Space v2237_7_result;
      for (int v2237_7_label = 1; v2237_7_label <= 2; ++v2237_7_label) {
        const Space v2237_7_tail = child(v2235_13_tail,v2237_7_label);
        if (v2237_7_tail.empty()) continue;
        const Path v2237_7_head{v2237_7_label};
        const Space v2238_2 = singleton(v2237_7_head);
        const Space v2238_3 = intersect(constant_8,v2238_2);
        const Space v2238_4 = (has_head(v2238_3) ? constant_9 : Space{});
        const Space v2238_5 = subtract(constant_0,v2238_4);
        Space v2238_8;
        if (!v2238_5.empty()) {
          const Path v2239_6 = concat_path(v2237_6,v2237_7_head);
          const Space v2239_7 = routine_317(c, v2239_6, p1, p2, v2237_7_tail);
          v2238_8 = compose(v2238_5,v2239_7);
        }
        const Space v2238_9 = intersect(constant_8,v2238_2);
        const Space v2238_10 = (has_head(v2238_9) ? constant_9 : Space{});
        Space v2238_12;
        if (!v2238_10.empty()) {
          const Path v2240_6 = concat_path(v2237_6,v2237_7_head);
          const Space v2240_11 = routine_318(c, v2240_6, p1, p2, v2237_7_tail);
          v2238_12 = compose(v2238_10,v2240_11);
        }
        const Space v2238_13 = unite(v2238_8,v2238_12);
        v2237_7_result = unite(v2237_7_result,v2238_13);
      }
      const Space v2237_7 = std::move(v2237_7_result);
      v2236_8 = compose(v2236_5,v2237_7);
    }
    const Space v2236_9 = intersect(constant_8,v2236_2);
    const Space v2236_10 = (has_head(v2236_9) ? constant_9 : Space{});
    Space v2236_12;
    if (!v2236_10.empty()) {
      const Path v2241_6 = concat_path(p0,v2235_13_head);
      Space v2241_11_result;
      for (int v2241_11_label = 1; v2241_11_label <= 2; ++v2241_11_label) {
        const Space v2241_11_tail = child(v2235_13_tail,v2241_11_label);
        if (v2241_11_tail.empty()) continue;
        const Path v2241_11_head{v2241_11_label};
        const Space v2242_2 = singleton(v2241_11_head);
        const Space v2242_3 = intersect(constant_8,v2242_2);
        const Space v2242_4 = (has_head(v2242_3) ? constant_9 : Space{});
        const Space v2242_5 = subtract(constant_0,v2242_4);
        Space v2242_8;
        if (!v2242_5.empty()) {
          const Path v2243_6 = concat_path(v2241_6,v2241_11_head);
          const Space v2243_7 = routine_317(c, v2243_6, p1, p2, v2241_11_tail);
          v2242_8 = compose(v2242_5,v2243_7);
        }
        const Space v2242_9 = intersect(constant_8,v2242_2);
        const Space v2242_10 = (has_head(v2242_9) ? constant_9 : Space{});
        Space v2242_12;
        if (!v2242_10.empty()) {
          const Path v2244_6 = concat_path(v2241_6,v2241_11_head);
          const Space v2244_11 = routine_252(c, v2244_6, p1, p2, v2241_11_tail);
          v2242_12 = compose(v2242_10,v2244_11);
        }
        const Space v2242_13 = unite(v2242_8,v2242_12);
        v2241_11_result = unite(v2241_11_result,v2242_13);
      }
      const Space v2241_11 = std::move(v2241_11_result);
      v2236_12 = compose(v2236_10,v2241_11);
    }
    const Space v2236_13 = unite(v2236_8,v2236_12);
    v2235_13_result = unite(v2235_13_result,v2236_13);
  }
  const Space v2235_13 = std::move(v2235_13_result);
  return v2235_13;
}

static Space routine_284(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2245_10 = concat_path(constant_23,p2);
  const Space v2245_11 = singleton(v2245_10);
  const Path v2245_13 = concat_path(constant_22,p1);
  const Space v2245_14 = singleton(v2245_13);
  Space v2245_18_result;
  for (int v2245_18_label = 1; v2245_18_label <= 2; ++v2245_18_label) {
    const Space v2245_18_tail = child(s0,v2245_18_label);
    if (v2245_18_tail.empty()) continue;
    const Path v2245_18_head{v2245_18_label};
    const Space v2246_2 = singleton(v2245_18_head);
    const Space v2246_3 = intersect(constant_8,v2246_2);
    const Space v2246_4 = (has_head(v2246_3) ? constant_9 : Space{});
    const Space v2246_5 = subtract(constant_0,v2246_4);
    Space v2246_8;
    if (!v2246_5.empty()) {
      const Path v2247_6 = concat_path(p0,v2245_18_head);
      Space v2247_7_result;
      for (int v2247_7_label = 1; v2247_7_label <= 2; ++v2247_7_label) {
        const Space v2247_7_tail = child(v2245_18_tail,v2247_7_label);
        if (v2247_7_tail.empty()) continue;
        const Path v2247_7_head{v2247_7_label};
        const Space v2248_2 = singleton(v2247_7_head);
        const Space v2248_3 = intersect(constant_8,v2248_2);
        const Space v2248_4 = (has_head(v2248_3) ? constant_9 : Space{});
        const Space v2248_5 = subtract(constant_0,v2248_4);
        Space v2248_8;
        if (!v2248_5.empty()) {
          const Path v2249_6 = concat_path(v2247_6,v2247_7_head);
          const Space v2249_7 = routine_317(c, v2249_6, p1, p2, v2247_7_tail);
          v2248_8 = compose(v2248_5,v2249_7);
        }
        const Space v2248_9 = intersect(constant_8,v2248_2);
        const Space v2248_10 = (has_head(v2248_9) ? constant_9 : Space{});
        Space v2248_12;
        if (!v2248_10.empty()) {
          const Path v2250_6 = concat_path(v2247_6,v2247_7_head);
          const Space v2250_11 = routine_318(c, v2250_6, p1, p2, v2247_7_tail);
          v2248_12 = compose(v2248_10,v2250_11);
        }
        const Space v2248_13 = unite(v2248_8,v2248_12);
        v2247_7_result = unite(v2247_7_result,v2248_13);
      }
      const Space v2247_7 = std::move(v2247_7_result);
      v2246_8 = compose(v2246_5,v2247_7);
    }
    const Space v2246_9 = intersect(constant_8,v2246_2);
    const Space v2246_10 = (has_head(v2246_9) ? constant_9 : Space{});
    const Path v2251_6 = concat_path(p0,v2245_18_head);
    const Path v2246_11 = concat_path(constant_24,v2251_6);
    const Space v2246_12 = singleton(v2246_11);
    const Space v2246_13 = unite(constant_29,v2246_12);
    const Space v2246_14 = unite(v2246_13,v2245_11);
    const Space v2246_15 = unite(v2246_14,v2245_14);
    const Space v2246_16 = compose(v2246_10,v2246_15);
    const Space v2246_17 = unite(v2246_8,v2246_16);
    v2245_18_result = unite(v2245_18_result,v2246_17);
  }
  const Space v2245_18 = std::move(v2245_18_result);
  return v2245_18;
}

static Space routine_285(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2252_6_result;
  for (int v2252_6_label = 1; v2252_6_label <= 2; ++v2252_6_label) {
    const Space v2252_6_tail = child(s0,v2252_6_label);
    if (v2252_6_tail.empty()) continue;
    const Path v2252_6_head{v2252_6_label};
    const Space v2253_2 = singleton(v2252_6_head);
    const Space v2253_3 = intersect(constant_8,v2253_2);
    const Space v2253_4 = (has_head(v2253_3) ? constant_9 : Space{});
    Space v2253_7;
    if (!v2253_4.empty()) {
      const Path v2254_5 = concat_path(p0,v2252_6_head);
      Space v2254_6_result;
      for (int v2254_6_label = 1; v2254_6_label <= 2; ++v2254_6_label) {
        const Space v2254_6_tail = child(v2252_6_tail,v2254_6_label);
        if (v2254_6_tail.empty()) continue;
        const Path v2254_6_head{v2254_6_label};
        const Space v2255_2 = singleton(v2254_6_head);
        const Space v2255_3 = intersect(constant_8,v2255_2);
        const Space v2255_4 = (has_head(v2255_3) ? constant_9 : Space{});
        Space v2255_7;
        if (!v2255_4.empty()) {
          const Path v2256_5 = concat_path(v2254_5,v2254_6_head);
          const Space v2256_6 = routine_223(c, v2256_5, p1, p2, v2254_6_tail);
          v2255_7 = compose(v2255_4,v2256_6);
        }
        v2254_6_result = unite(v2254_6_result,v2255_7);
      }
      const Space v2254_6 = std::move(v2254_6_result);
      v2253_7 = compose(v2253_4,v2254_6);
    }
    v2252_6_result = unite(v2252_6_result,v2253_7);
  }
  const Space v2252_6 = std::move(v2252_6_result);
  return v2252_6;
}

static Space routine_286(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2257_9_result;
  for (int v2257_9_label = 1; v2257_9_label <= 2; ++v2257_9_label) {
    const Space v2257_9_tail = child(s0,v2257_9_label);
    if (v2257_9_tail.empty()) continue;
    const Path v2257_9_head{v2257_9_label};
    const Space v2258_2 = singleton(v2257_9_head);
    const Space v2258_3 = intersect(constant_8,v2258_2);
    const Space v2258_4 = (has_head(v2258_3) ? constant_9 : Space{});
    Space v2258_12;
    if (!v2258_4.empty()) {
      Space v2259_5_result;
      for (int v2259_5_label = 1; v2259_5_label <= 2; ++v2259_5_label) {
        const Space v2259_5_tail = child(v2257_9_tail,v2259_5_label);
        if (v2259_5_tail.empty()) continue;
        const Path v2259_5_head{v2259_5_label};
        const Space v2260_2 = singleton(v2259_5_head);
        const Space v2260_3 = intersect(constant_8,v2260_2);
        const Space v2260_4 = (has_head(v2260_3) ? constant_9 : Space{});
        const Space v2260_5 = subtract(constant_0,v2260_4);
        Space v2260_7;
        if (!v2260_5.empty()) {
          const Space v2261_6 = routine_257(c, v2259_5_head, v2259_5_tail);
          v2260_7 = compose(v2260_5,v2261_6);
        }
        const Space v2260_8 = intersect(constant_8,v2260_2);
        const Space v2260_9 = (has_head(v2260_8) ? constant_9 : Space{});
        Space v2260_11;
        if (!v2260_9.empty()) {
          const Space v2262_10 = routine_258(c, v2259_5_head, v2259_5_tail);
          v2260_11 = compose(v2260_9,v2262_10);
        }
        const Space v2260_12 = unite(v2260_7,v2260_11);
        v2259_5_result = unite(v2259_5_result,v2260_12);
      }
      const Space v2259_5 = std::move(v2259_5_result);
      const Space v2259_6 = raffine(constant_25,v2259_5);
      const Space v2259_7 = unite(v2259_6,v2257_9_tail);
      const Path v2259_8 = concat_path(p0,v2257_9_head);
      const Path v2259_9 = concat_path(p2,v2259_8);
      const Space v2259_10 = wrap(v2259_7,v2259_9);
      const Space v2259_11 = unwrap(v2259_10,p1);
      v2258_12 = compose(v2258_4,v2259_11);
    }
    v2257_9_result = unite(v2257_9_result,v2258_12);
  }
  const Space v2257_9 = std::move(v2257_9_result);
  return v2257_9;
}

static Space routine_287(Context& c, const Path& p0, const Space& s0) {
  Space v2263_11_result;
  for (int v2263_11_label = 1; v2263_11_label <= 2; ++v2263_11_label) {
    const Space v2263_11_tail = child(s0,v2263_11_label);
    if (v2263_11_tail.empty()) continue;
    const Path v2263_11_head{v2263_11_label};
    const Space v2264_2 = singleton(v2263_11_head);
    const Space v2264_3 = intersect(constant_8,v2264_2);
    const Space v2264_4 = (has_head(v2264_3) ? constant_9 : Space{});
    const Space v2264_5 = subtract(constant_0,v2264_4);
    Space v2264_8;
    if (!v2264_5.empty()) {
      const Path v2265_6 = concat_path(p0,v2263_11_head);
      Space v2265_7_result;
      for (int v2265_7_label = 1; v2265_7_label <= 2; ++v2265_7_label) {
        const Space v2265_7_tail = child(v2263_11_tail,v2265_7_label);
        if (v2265_7_tail.empty()) continue;
        const Path v2265_7_head{v2265_7_label};
        const Space v2266_2 = singleton(v2265_7_head);
        const Space v2266_3 = intersect(constant_8,v2266_2);
        const Space v2266_4 = (has_head(v2266_3) ? constant_9 : Space{});
        const Space v2266_5 = subtract(constant_0,v2266_4);
        Space v2266_8;
        if (!v2266_5.empty()) {
          const Path v2267_6 = concat_path(v2265_6,v2265_7_head);
          const Space v2267_7 = routine_319(c, v2267_6, v2265_7_tail);
          v2266_8 = compose(v2266_5,v2267_7);
        }
        const Space v2266_9 = intersect(constant_8,v2266_2);
        const Space v2266_10 = (has_head(v2266_9) ? constant_9 : Space{});
        Space v2266_12;
        if (!v2266_10.empty()) {
          const Path v2268_6 = concat_path(v2265_6,v2265_7_head);
          const Space v2268_11 = routine_320(c, v2268_6, v2265_7_tail);
          v2266_12 = compose(v2266_10,v2268_11);
        }
        const Space v2266_13 = unite(v2266_8,v2266_12);
        v2265_7_result = unite(v2265_7_result,v2266_13);
      }
      const Space v2265_7 = std::move(v2265_7_result);
      v2264_8 = compose(v2264_5,v2265_7);
    }
    const Space v2264_9 = intersect(constant_8,v2264_2);
    const Space v2264_10 = (has_head(v2264_9) ? constant_9 : Space{});
    Space v2264_12;
    if (!v2264_10.empty()) {
      const Path v2269_6 = concat_path(p0,v2263_11_head);
      Space v2269_11_result;
      for (int v2269_11_label = 1; v2269_11_label <= 2; ++v2269_11_label) {
        const Space v2269_11_tail = child(v2263_11_tail,v2269_11_label);
        if (v2269_11_tail.empty()) continue;
        const Path v2269_11_head{v2269_11_label};
        const Space v2270_2 = singleton(v2269_11_head);
        const Space v2270_3 = intersect(constant_8,v2270_2);
        const Space v2270_4 = (has_head(v2270_3) ? constant_9 : Space{});
        const Space v2270_5 = subtract(constant_0,v2270_4);
        Space v2270_8;
        if (!v2270_5.empty()) {
          const Path v2271_6 = concat_path(v2269_6,v2269_11_head);
          const Space v2271_7 = routine_319(c, v2271_6, v2269_11_tail);
          v2270_8 = compose(v2270_5,v2271_7);
        }
        const Space v2270_9 = intersect(constant_8,v2270_2);
        const Space v2270_10 = (has_head(v2270_9) ? constant_9 : Space{});
        Space v2270_12;
        if (!v2270_10.empty()) {
          const Path v2272_6 = concat_path(v2269_6,v2269_11_head);
          const Space v2272_11 = routine_289(c, v2272_6, v2269_11_tail);
          v2270_12 = compose(v2270_10,v2272_11);
        }
        const Space v2270_13 = unite(v2270_8,v2270_12);
        v2269_11_result = unite(v2269_11_result,v2270_13);
      }
      const Space v2269_11 = std::move(v2269_11_result);
      v2264_12 = compose(v2264_10,v2269_11);
    }
    const Space v2264_13 = unite(v2264_8,v2264_12);
    v2263_11_result = unite(v2263_11_result,v2264_13);
  }
  const Space v2263_11 = std::move(v2263_11_result);
  return v2263_11;
}

static Space routine_288(Context& c, const Path& p0, const Space& s0) {
  Space v2273_8_result;
  for (int v2273_8_label = 1; v2273_8_label <= 2; ++v2273_8_label) {
    const Space v2273_8_tail = child(s0,v2273_8_label);
    if (v2273_8_tail.empty()) continue;
    const Path v2273_8_head{v2273_8_label};
    const Space v2274_2 = singleton(v2273_8_head);
    const Space v2274_3 = intersect(constant_8,v2274_2);
    const Space v2274_4 = (has_head(v2274_3) ? constant_9 : Space{});
    const Space v2274_5 = subtract(constant_0,v2274_4);
    Space v2274_8;
    if (!v2274_5.empty()) {
      const Path v2275_6 = concat_path(p0,v2273_8_head);
      Space v2275_7_result;
      for (int v2275_7_label = 1; v2275_7_label <= 2; ++v2275_7_label) {
        const Space v2275_7_tail = child(v2273_8_tail,v2275_7_label);
        if (v2275_7_tail.empty()) continue;
        const Path v2275_7_head{v2275_7_label};
        const Space v2276_2 = singleton(v2275_7_head);
        const Space v2276_3 = intersect(constant_8,v2276_2);
        const Space v2276_4 = (has_head(v2276_3) ? constant_9 : Space{});
        const Space v2276_5 = subtract(constant_0,v2276_4);
        Space v2276_8;
        if (!v2276_5.empty()) {
          const Path v2277_6 = concat_path(v2275_6,v2275_7_head);
          const Space v2277_7 = routine_319(c, v2277_6, v2275_7_tail);
          v2276_8 = compose(v2276_5,v2277_7);
        }
        const Space v2276_9 = intersect(constant_8,v2276_2);
        const Space v2276_10 = (has_head(v2276_9) ? constant_9 : Space{});
        Space v2276_12;
        if (!v2276_10.empty()) {
          const Path v2278_6 = concat_path(v2275_6,v2275_7_head);
          const Space v2278_11 = routine_320(c, v2278_6, v2275_7_tail);
          v2276_12 = compose(v2276_10,v2278_11);
        }
        const Space v2276_13 = unite(v2276_8,v2276_12);
        v2275_7_result = unite(v2275_7_result,v2276_13);
      }
      const Space v2275_7 = std::move(v2275_7_result);
      v2274_8 = compose(v2274_5,v2275_7);
    }
    const Space v2274_9 = intersect(constant_8,v2274_2);
    const Space v2274_10 = (has_head(v2274_9) ? constant_9 : Space{});
    const Path v2279_6 = concat_path(p0,v2273_8_head);
    const Space v2274_11 = singleton(v2279_6);
    const Space v2274_12 = compose(v2274_10,v2274_11);
    const Space v2274_13 = unite(v2274_8,v2274_12);
    v2273_8_result = unite(v2273_8_result,v2274_13);
  }
  const Space v2273_8 = std::move(v2273_8_result);
  return v2273_8;
}

static Space routine_289(Context& c, const Path& p0, const Space& s0) {
  const Space v2280_2 = singleton(p0);
  return v2280_2;
}

static Space routine_290(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v2281_7_result;
  for (int v2281_7_label = 1; v2281_7_label <= 2; ++v2281_7_label) {
    const Space v2281_7_tail = child(s0,v2281_7_label);
    if (v2281_7_tail.empty()) continue;
    const Path v2281_7_head{v2281_7_label};
    const Space v2282_2 = singleton(v2281_7_head);
    const Space v2282_3 = intersect(constant_8,v2282_2);
    const Space v2282_4 = (has_head(v2282_3) ? constant_9 : Space{});
    Space v2282_7;
    if (!v2282_4.empty()) {
      const Path v2283_5 = concat_path(p0,v2281_7_head);
      Space v2283_6_result;
      for (int v2283_6_label = 1; v2283_6_label <= 2; ++v2283_6_label) {
        const Space v2283_6_tail = child(v2281_7_tail,v2283_6_label);
        if (v2283_6_tail.empty()) continue;
        const Path v2283_6_head{v2283_6_label};
        const Space v2284_2 = singleton(v2283_6_head);
        const Space v2284_3 = intersect(constant_8,v2284_2);
        const Space v2284_4 = (has_head(v2284_3) ? constant_9 : Space{});
        Space v2284_7;
        if (!v2284_4.empty()) {
          const Path v2285_5 = concat_path(v2283_5,v2283_6_head);
          const Space v2285_6 = routine_230(c, v2285_5, p1, p2, p3, v2283_6_tail);
          v2284_7 = compose(v2284_4,v2285_6);
        }
        v2283_6_result = unite(v2283_6_result,v2284_7);
      }
      const Space v2283_6 = std::move(v2283_6_result);
      v2282_7 = compose(v2282_4,v2283_6);
    }
    v2281_7_result = unite(v2281_7_result,v2282_7);
  }
  const Space v2281_7 = std::move(v2281_7_result);
  return v2281_7;
}

static Space routine_291(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v2286_10_result;
  for (int v2286_10_label = 1; v2286_10_label <= 2; ++v2286_10_label) {
    const Space v2286_10_tail = child(s0,v2286_10_label);
    if (v2286_10_tail.empty()) continue;
    const Path v2286_10_head{v2286_10_label};
    const Space v2287_2 = singleton(v2286_10_head);
    const Space v2287_3 = intersect(constant_8,v2287_2);
    const Space v2287_4 = (has_head(v2287_3) ? constant_9 : Space{});
    Space v2287_14;
    if (!v2287_4.empty()) {
      Space v2288_5_result;
      for (int v2288_5_label = 1; v2288_5_label <= 2; ++v2288_5_label) {
        const Space v2288_5_tail = child(v2286_10_tail,v2288_5_label);
        if (v2288_5_tail.empty()) continue;
        const Path v2288_5_head{v2288_5_label};
        const Space v2289_2 = singleton(v2288_5_head);
        const Space v2289_3 = intersect(constant_8,v2289_2);
        const Space v2289_4 = (has_head(v2289_3) ? constant_9 : Space{});
        const Space v2289_5 = subtract(constant_0,v2289_4);
        Space v2289_7;
        if (!v2289_5.empty()) {
          const Space v2290_6 = routine_265(c, v2288_5_head, v2288_5_tail);
          v2289_7 = compose(v2289_5,v2290_6);
        }
        const Space v2289_8 = intersect(constant_8,v2289_2);
        const Space v2289_9 = (has_head(v2289_8) ? constant_9 : Space{});
        Space v2289_11;
        if (!v2289_9.empty()) {
          const Space v2291_10 = routine_266(c, v2288_5_head, v2288_5_tail);
          v2289_11 = compose(v2289_9,v2291_10);
        }
        const Space v2289_12 = unite(v2289_7,v2289_11);
        v2288_5_result = unite(v2288_5_result,v2289_12);
      }
      const Space v2288_5 = std::move(v2288_5_result);
      const Space v2288_6 = raffine(constant_25,v2288_5);
      const Space v2288_7 = unite(v2288_6,v2286_10_tail);
      const Path v2288_8 = concat_path(p0,v2286_10_head);
      const Path v2288_9 = concat_path(p3,v2288_8);
      const Space v2288_10 = wrap(v2288_7,v2288_9);
      const Space v2288_11 = unwrap(v2288_10,p1);
      const Space v2288_12 = unwrap(v2288_11,p2);
      const Space v2288_13 = unwrap(v2288_12,p1);
      v2287_14 = compose(v2287_4,v2288_13);
    }
    v2286_10_result = unite(v2286_10_result,v2287_14);
  }
  const Space v2286_10 = std::move(v2286_10_result);
  return v2286_10;
}

static Space routine_292(Context& c, const Path& p0, const Space& s0) {
  Space v2292_11_result;
  for (int v2292_11_label = 1; v2292_11_label <= 2; ++v2292_11_label) {
    const Space v2292_11_tail = child(s0,v2292_11_label);
    if (v2292_11_tail.empty()) continue;
    const Path v2292_11_head{v2292_11_label};
    const Space v2293_2 = singleton(v2292_11_head);
    const Space v2293_3 = intersect(constant_8,v2293_2);
    const Space v2293_4 = (has_head(v2293_3) ? constant_9 : Space{});
    const Space v2293_5 = subtract(constant_0,v2293_4);
    Space v2293_8;
    if (!v2293_5.empty()) {
      const Path v2294_6 = concat_path(p0,v2292_11_head);
      Space v2294_7_result;
      for (int v2294_7_label = 1; v2294_7_label <= 2; ++v2294_7_label) {
        const Space v2294_7_tail = child(v2292_11_tail,v2294_7_label);
        if (v2294_7_tail.empty()) continue;
        const Path v2294_7_head{v2294_7_label};
        const Space v2295_2 = singleton(v2294_7_head);
        const Space v2295_3 = intersect(constant_8,v2295_2);
        const Space v2295_4 = (has_head(v2295_3) ? constant_9 : Space{});
        const Space v2295_5 = subtract(constant_0,v2295_4);
        Space v2295_8;
        if (!v2295_5.empty()) {
          const Path v2296_6 = concat_path(v2294_6,v2294_7_head);
          const Space v2296_7 = routine_321(c, v2296_6, v2294_7_tail);
          v2295_8 = compose(v2295_5,v2296_7);
        }
        const Space v2295_9 = intersect(constant_8,v2295_2);
        const Space v2295_10 = (has_head(v2295_9) ? constant_9 : Space{});
        Space v2295_12;
        if (!v2295_10.empty()) {
          const Path v2297_6 = concat_path(v2294_6,v2294_7_head);
          const Space v2297_11 = routine_322(c, v2297_6, v2294_7_tail);
          v2295_12 = compose(v2295_10,v2297_11);
        }
        const Space v2295_13 = unite(v2295_8,v2295_12);
        v2294_7_result = unite(v2294_7_result,v2295_13);
      }
      const Space v2294_7 = std::move(v2294_7_result);
      v2293_8 = compose(v2293_5,v2294_7);
    }
    const Space v2293_9 = intersect(constant_8,v2293_2);
    const Space v2293_10 = (has_head(v2293_9) ? constant_9 : Space{});
    Space v2293_12;
    if (!v2293_10.empty()) {
      const Path v2298_6 = concat_path(p0,v2292_11_head);
      Space v2298_11_result;
      for (int v2298_11_label = 1; v2298_11_label <= 2; ++v2298_11_label) {
        const Space v2298_11_tail = child(v2292_11_tail,v2298_11_label);
        if (v2298_11_tail.empty()) continue;
        const Path v2298_11_head{v2298_11_label};
        const Space v2299_2 = singleton(v2298_11_head);
        const Space v2299_3 = intersect(constant_8,v2299_2);
        const Space v2299_4 = (has_head(v2299_3) ? constant_9 : Space{});
        const Space v2299_5 = subtract(constant_0,v2299_4);
        Space v2299_8;
        if (!v2299_5.empty()) {
          const Path v2300_6 = concat_path(v2298_6,v2298_11_head);
          const Space v2300_7 = routine_321(c, v2300_6, v2298_11_tail);
          v2299_8 = compose(v2299_5,v2300_7);
        }
        const Space v2299_9 = intersect(constant_8,v2299_2);
        const Space v2299_10 = (has_head(v2299_9) ? constant_9 : Space{});
        Space v2299_12;
        if (!v2299_10.empty()) {
          const Path v2301_6 = concat_path(v2298_6,v2298_11_head);
          const Space v2301_11 = routine_294(c, v2301_6, v2298_11_tail);
          v2299_12 = compose(v2299_10,v2301_11);
        }
        const Space v2299_13 = unite(v2299_8,v2299_12);
        v2298_11_result = unite(v2298_11_result,v2299_13);
      }
      const Space v2298_11 = std::move(v2298_11_result);
      v2293_12 = compose(v2293_10,v2298_11);
    }
    const Space v2293_13 = unite(v2293_8,v2293_12);
    v2292_11_result = unite(v2292_11_result,v2293_13);
  }
  const Space v2292_11 = std::move(v2292_11_result);
  return v2292_11;
}

static Space routine_293(Context& c, const Path& p0, const Space& s0) {
  Space v2302_8_result;
  for (int v2302_8_label = 1; v2302_8_label <= 2; ++v2302_8_label) {
    const Space v2302_8_tail = child(s0,v2302_8_label);
    if (v2302_8_tail.empty()) continue;
    const Path v2302_8_head{v2302_8_label};
    const Space v2303_2 = singleton(v2302_8_head);
    const Space v2303_3 = intersect(constant_8,v2303_2);
    const Space v2303_4 = (has_head(v2303_3) ? constant_9 : Space{});
    const Space v2303_5 = subtract(constant_0,v2303_4);
    Space v2303_8;
    if (!v2303_5.empty()) {
      const Path v2304_6 = concat_path(p0,v2302_8_head);
      Space v2304_7_result;
      for (int v2304_7_label = 1; v2304_7_label <= 2; ++v2304_7_label) {
        const Space v2304_7_tail = child(v2302_8_tail,v2304_7_label);
        if (v2304_7_tail.empty()) continue;
        const Path v2304_7_head{v2304_7_label};
        const Space v2305_2 = singleton(v2304_7_head);
        const Space v2305_3 = intersect(constant_8,v2305_2);
        const Space v2305_4 = (has_head(v2305_3) ? constant_9 : Space{});
        const Space v2305_5 = subtract(constant_0,v2305_4);
        Space v2305_8;
        if (!v2305_5.empty()) {
          const Path v2306_6 = concat_path(v2304_6,v2304_7_head);
          const Space v2306_7 = routine_321(c, v2306_6, v2304_7_tail);
          v2305_8 = compose(v2305_5,v2306_7);
        }
        const Space v2305_9 = intersect(constant_8,v2305_2);
        const Space v2305_10 = (has_head(v2305_9) ? constant_9 : Space{});
        Space v2305_12;
        if (!v2305_10.empty()) {
          const Path v2307_6 = concat_path(v2304_6,v2304_7_head);
          const Space v2307_11 = routine_322(c, v2307_6, v2304_7_tail);
          v2305_12 = compose(v2305_10,v2307_11);
        }
        const Space v2305_13 = unite(v2305_8,v2305_12);
        v2304_7_result = unite(v2304_7_result,v2305_13);
      }
      const Space v2304_7 = std::move(v2304_7_result);
      v2303_8 = compose(v2303_5,v2304_7);
    }
    const Space v2303_9 = intersect(constant_8,v2303_2);
    const Space v2303_10 = (has_head(v2303_9) ? constant_9 : Space{});
    const Path v2308_6 = concat_path(p0,v2302_8_head);
    const Space v2303_11 = singleton(v2308_6);
    const Space v2303_12 = compose(v2303_10,v2303_11);
    const Space v2303_13 = unite(v2303_8,v2303_12);
    v2302_8_result = unite(v2302_8_result,v2303_13);
  }
  const Space v2302_8 = std::move(v2302_8_result);
  return v2302_8;
}

static Space routine_294(Context& c, const Path& p0, const Space& s0) {
  const Space v2309_2 = singleton(p0);
  return v2309_2;
}

static Space routine_295(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2310_6_result;
  for (int v2310_6_label = 1; v2310_6_label <= 2; ++v2310_6_label) {
    const Space v2310_6_tail = child(s0,v2310_6_label);
    if (v2310_6_tail.empty()) continue;
    const Path v2310_6_head{v2310_6_label};
    const Space v2311_2 = singleton(v2310_6_head);
    const Space v2311_3 = intersect(constant_8,v2311_2);
    const Space v2311_4 = (has_head(v2311_3) ? constant_9 : Space{});
    Space v2311_7;
    if (!v2311_4.empty()) {
      const Path v2312_5 = concat_path(p0,v2310_6_head);
      Space v2312_6_result;
      for (int v2312_6_label = 1; v2312_6_label <= 2; ++v2312_6_label) {
        const Space v2312_6_tail = child(v2310_6_tail,v2312_6_label);
        if (v2312_6_tail.empty()) continue;
        const Path v2312_6_head{v2312_6_label};
        const Space v2313_2 = singleton(v2312_6_head);
        const Space v2313_3 = intersect(constant_8,v2313_2);
        const Space v2313_4 = (has_head(v2313_3) ? constant_9 : Space{});
        Space v2313_7;
        if (!v2313_4.empty()) {
          const Path v2314_5 = concat_path(v2312_5,v2312_6_head);
          const Space v2314_6 = routine_237(c, v2314_5, p1, p2, v2312_6_tail);
          v2313_7 = compose(v2313_4,v2314_6);
        }
        v2312_6_result = unite(v2312_6_result,v2313_7);
      }
      const Space v2312_6 = std::move(v2312_6_result);
      v2311_7 = compose(v2311_4,v2312_6);
    }
    v2310_6_result = unite(v2310_6_result,v2311_7);
  }
  const Space v2310_6 = std::move(v2310_6_result);
  return v2310_6;
}

static Space routine_296(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2315_7 = concat_path(constant_23,p2);
  const Space v2315_8 = singleton(v2315_7);
  const Space v2315_9 = unite(constant_26,v2315_8);
  const Path v2315_11 = concat_path(constant_22,p1);
  const Space v2315_12 = singleton(v2315_11);
  const Space v2315_13 = unite(v2315_9,v2315_12);
  Space v2315_15_result;
  for (int v2315_15_label = 1; v2315_15_label <= 2; ++v2315_15_label) {
    const Space v2315_15_tail = child(s0,v2315_15_label);
    if (v2315_15_tail.empty()) continue;
    const Path v2315_15_head{v2315_15_label};
    const Space v2316_2 = singleton(v2315_15_head);
    const Space v2316_3 = intersect(constant_8,v2316_2);
    const Space v2316_4 = (has_head(v2316_3) ? constant_9 : Space{});
    const Path v2316_5 = concat_path(p0,v2315_15_head);
    const Path v2316_6 = concat_path(constant_6,v2316_5);
    const Space v2316_7 = singleton(v2316_6);
    const Space v2316_8 = unite(v2315_13,v2316_7);
    const Space v2316_9 = compose(v2316_4,v2316_8);
    v2315_15_result = unite(v2315_15_result,v2316_9);
  }
  const Space v2315_15 = std::move(v2315_15_result);
  return v2315_15;
}

static Space routine_297(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2317_6_result;
  for (int v2317_6_label = 1; v2317_6_label <= 2; ++v2317_6_label) {
    const Space v2317_6_tail = child(s0,v2317_6_label);
    if (v2317_6_tail.empty()) continue;
    const Path v2317_6_head{v2317_6_label};
    const Space v2318_2 = singleton(v2317_6_head);
    const Space v2318_3 = intersect(constant_8,v2318_2);
    const Space v2318_4 = (has_head(v2318_3) ? constant_9 : Space{});
    Space v2318_7;
    if (!v2318_4.empty()) {
      const Path v2319_5 = concat_path(p0,v2317_6_head);
      Space v2319_6_result;
      for (int v2319_6_label = 1; v2319_6_label <= 2; ++v2319_6_label) {
        const Space v2319_6_tail = child(v2317_6_tail,v2319_6_label);
        if (v2319_6_tail.empty()) continue;
        const Path v2319_6_head{v2319_6_label};
        const Space v2320_2 = singleton(v2319_6_head);
        const Space v2320_3 = intersect(constant_8,v2320_2);
        const Space v2320_4 = (has_head(v2320_3) ? constant_9 : Space{});
        Space v2320_7;
        if (!v2320_4.empty()) {
          const Path v2321_5 = concat_path(v2319_5,v2319_6_head);
          const Space v2321_6 = routine_242(c, v2321_5, p1, p2, v2319_6_tail);
          v2320_7 = compose(v2320_4,v2321_6);
        }
        v2319_6_result = unite(v2319_6_result,v2320_7);
      }
      const Space v2319_6 = std::move(v2319_6_result);
      v2318_7 = compose(v2318_4,v2319_6);
    }
    v2317_6_result = unite(v2317_6_result,v2318_7);
  }
  const Space v2317_6 = std::move(v2317_6_result);
  return v2317_6;
}

static Space routine_298(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2322_8 = concat_path(constant_22,p1);
  const Space v2322_9 = singleton(v2322_8);
  const Path v2322_11 = concat_path(constant_6,p2);
  const Space v2322_12 = singleton(v2322_11);
  Space v2322_13_result;
  for (int v2322_13_label = 1; v2322_13_label <= 2; ++v2322_13_label) {
    const Space v2322_13_tail = child(s0,v2322_13_label);
    if (v2322_13_tail.empty()) continue;
    const Path v2322_13_head{v2322_13_label};
    const Space v2323_2 = singleton(v2322_13_head);
    const Space v2323_3 = intersect(constant_8,v2323_2);
    const Space v2323_4 = (has_head(v2323_3) ? constant_9 : Space{});
    const Path v2323_5 = concat_path(p0,v2322_13_head);
    const Path v2323_6 = concat_path(constant_24,v2323_5);
    const Space v2323_7 = singleton(v2323_6);
    const Space v2323_8 = unite(constant_27,v2323_7);
    const Space v2323_9 = unite(v2323_8,v2322_9);
    const Space v2323_10 = unite(v2323_9,v2322_12);
    const Space v2323_11 = compose(v2323_4,v2323_10);
    v2322_13_result = unite(v2322_13_result,v2323_11);
  }
  const Space v2322_13 = std::move(v2322_13_result);
  return v2322_13;
}

static Space routine_299(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2324_6_result;
  for (int v2324_6_label = 1; v2324_6_label <= 2; ++v2324_6_label) {
    const Space v2324_6_tail = child(s0,v2324_6_label);
    if (v2324_6_tail.empty()) continue;
    const Path v2324_6_head{v2324_6_label};
    const Space v2325_2 = singleton(v2324_6_head);
    const Space v2325_3 = intersect(constant_8,v2325_2);
    const Space v2325_4 = (has_head(v2325_3) ? constant_9 : Space{});
    Space v2325_7;
    if (!v2325_4.empty()) {
      const Path v2326_5 = concat_path(p0,v2324_6_head);
      Space v2326_6_result;
      for (int v2326_6_label = 1; v2326_6_label <= 2; ++v2326_6_label) {
        const Space v2326_6_tail = child(v2324_6_tail,v2326_6_label);
        if (v2326_6_tail.empty()) continue;
        const Path v2326_6_head{v2326_6_label};
        const Space v2327_2 = singleton(v2326_6_head);
        const Space v2327_3 = intersect(constant_8,v2327_2);
        const Space v2327_4 = (has_head(v2327_3) ? constant_9 : Space{});
        Space v2327_7;
        if (!v2327_4.empty()) {
          const Path v2328_5 = concat_path(v2326_5,v2326_6_head);
          const Space v2328_6 = routine_247(c, v2328_5, p1, p2, v2326_6_tail);
          v2327_7 = compose(v2327_4,v2328_6);
        }
        v2326_6_result = unite(v2326_6_result,v2327_7);
      }
      const Space v2326_6 = std::move(v2326_6_result);
      v2325_7 = compose(v2325_4,v2326_6);
    }
    v2324_6_result = unite(v2324_6_result,v2325_7);
  }
  const Space v2324_6 = std::move(v2324_6_result);
  return v2324_6;
}

static Space routine_300(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2329_8 = concat_path(constant_23,p1);
  const Space v2329_9 = singleton(v2329_8);
  const Path v2329_11 = concat_path(constant_6,p2);
  const Space v2329_12 = singleton(v2329_11);
  Space v2329_13_result;
  for (int v2329_13_label = 1; v2329_13_label <= 2; ++v2329_13_label) {
    const Space v2329_13_tail = child(s0,v2329_13_label);
    if (v2329_13_tail.empty()) continue;
    const Path v2329_13_head{v2329_13_label};
    const Space v2330_2 = singleton(v2329_13_head);
    const Space v2330_3 = intersect(constant_8,v2330_2);
    const Space v2330_4 = (has_head(v2330_3) ? constant_9 : Space{});
    const Path v2330_5 = concat_path(p0,v2329_13_head);
    const Path v2330_6 = concat_path(constant_24,v2330_5);
    const Space v2330_7 = singleton(v2330_6);
    const Space v2330_8 = unite(constant_28,v2330_7);
    const Space v2330_9 = unite(v2330_8,v2329_9);
    const Space v2330_10 = unite(v2330_9,v2329_12);
    const Space v2330_11 = compose(v2330_4,v2330_10);
    v2329_13_result = unite(v2329_13_result,v2330_11);
  }
  const Space v2329_13 = std::move(v2329_13_result);
  return v2329_13;
}

static Space routine_301(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2331_6_result;
  for (int v2331_6_label = 1; v2331_6_label <= 2; ++v2331_6_label) {
    const Space v2331_6_tail = child(s0,v2331_6_label);
    if (v2331_6_tail.empty()) continue;
    const Path v2331_6_head{v2331_6_label};
    const Space v2332_2 = singleton(v2331_6_head);
    const Space v2332_3 = intersect(constant_8,v2332_2);
    const Space v2332_4 = (has_head(v2332_3) ? constant_9 : Space{});
    Space v2332_7;
    if (!v2332_4.empty()) {
      const Path v2333_5 = concat_path(p0,v2331_6_head);
      Space v2333_6_result;
      for (int v2333_6_label = 1; v2333_6_label <= 2; ++v2333_6_label) {
        const Space v2333_6_tail = child(v2331_6_tail,v2333_6_label);
        if (v2333_6_tail.empty()) continue;
        const Path v2333_6_head{v2333_6_label};
        const Space v2334_2 = singleton(v2333_6_head);
        const Space v2334_3 = intersect(constant_8,v2334_2);
        const Space v2334_4 = (has_head(v2334_3) ? constant_9 : Space{});
        Space v2334_7;
        if (!v2334_4.empty()) {
          const Path v2335_5 = concat_path(v2333_5,v2333_6_head);
          const Space v2335_6 = routine_252(c, v2335_5, p1, p2, v2333_6_tail);
          v2334_7 = compose(v2334_4,v2335_6);
        }
        v2333_6_result = unite(v2333_6_result,v2334_7);
      }
      const Space v2333_6 = std::move(v2333_6_result);
      v2332_7 = compose(v2332_4,v2333_6);
    }
    v2331_6_result = unite(v2331_6_result,v2332_7);
  }
  const Space v2331_6 = std::move(v2331_6_result);
  return v2331_6;
}

static Space routine_302(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2336_8 = concat_path(constant_23,p2);
  const Space v2336_9 = singleton(v2336_8);
  const Path v2336_11 = concat_path(constant_22,p1);
  const Space v2336_12 = singleton(v2336_11);
  Space v2336_13_result;
  for (int v2336_13_label = 1; v2336_13_label <= 2; ++v2336_13_label) {
    const Space v2336_13_tail = child(s0,v2336_13_label);
    if (v2336_13_tail.empty()) continue;
    const Path v2336_13_head{v2336_13_label};
    const Space v2337_2 = singleton(v2336_13_head);
    const Space v2337_3 = intersect(constant_8,v2337_2);
    const Space v2337_4 = (has_head(v2337_3) ? constant_9 : Space{});
    const Path v2337_5 = concat_path(p0,v2336_13_head);
    const Path v2337_6 = concat_path(constant_24,v2337_5);
    const Space v2337_7 = singleton(v2337_6);
    const Space v2337_8 = unite(constant_29,v2337_7);
    const Space v2337_9 = unite(v2337_8,v2336_9);
    const Space v2337_10 = unite(v2337_9,v2336_12);
    const Space v2337_11 = compose(v2337_4,v2337_10);
    v2336_13_result = unite(v2336_13_result,v2337_11);
  }
  const Space v2336_13 = std::move(v2336_13_result);
  return v2336_13;
}

static Space routine_303(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2338_4 = Space{};
  return v2338_4;
}

static Space routine_304(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2339_9_result;
  for (int v2339_9_label = 1; v2339_9_label <= 2; ++v2339_9_label) {
    const Space v2339_9_tail = child(s0,v2339_9_label);
    if (v2339_9_tail.empty()) continue;
    const Path v2339_9_head{v2339_9_label};
    const Space v2340_2 = singleton(v2339_9_head);
    const Space v2340_3 = intersect(constant_8,v2340_2);
    const Space v2340_4 = (has_head(v2340_3) ? constant_9 : Space{});
    Space v2340_12;
    if (!v2340_4.empty()) {
      Space v2341_5_result;
      for (int v2341_5_label = 1; v2341_5_label <= 2; ++v2341_5_label) {
        const Space v2341_5_tail = child(v2339_9_tail,v2341_5_label);
        if (v2341_5_tail.empty()) continue;
        const Path v2341_5_head{v2341_5_label};
        const Space v2342_2 = singleton(v2341_5_head);
        const Space v2342_3 = intersect(constant_8,v2342_2);
        const Space v2342_4 = (has_head(v2342_3) ? constant_9 : Space{});
        const Space v2342_5 = subtract(constant_0,v2342_4);
        Space v2342_7;
        if (!v2342_5.empty()) {
          const Space v2343_6 = routine_257(c, v2341_5_head, v2341_5_tail);
          v2342_7 = compose(v2342_5,v2343_6);
        }
        const Space v2342_8 = intersect(constant_8,v2342_2);
        const Space v2342_9 = (has_head(v2342_8) ? constant_9 : Space{});
        Space v2342_11;
        if (!v2342_9.empty()) {
          const Space v2344_10 = routine_258(c, v2341_5_head, v2341_5_tail);
          v2342_11 = compose(v2342_9,v2344_10);
        }
        const Space v2342_12 = unite(v2342_7,v2342_11);
        v2341_5_result = unite(v2341_5_result,v2342_12);
      }
      const Space v2341_5 = std::move(v2341_5_result);
      const Space v2341_6 = raffine(constant_25,v2341_5);
      const Space v2341_7 = unite(v2341_6,v2339_9_tail);
      const Path v2341_8 = concat_path(p0,v2339_9_head);
      const Path v2341_9 = concat_path(p2,v2341_8);
      const Space v2341_10 = wrap(v2341_7,v2341_9);
      const Space v2341_11 = unwrap(v2341_10,p1);
      v2340_12 = compose(v2340_4,v2341_11);
    }
    v2339_9_result = unite(v2339_9_result,v2340_12);
  }
  const Space v2339_9 = std::move(v2339_9_result);
  return v2339_9;
}

static Space routine_305(Context& c, const Path& p0, const Space& s0) {
  Space v2345_11_result;
  for (int v2345_11_label = 1; v2345_11_label <= 2; ++v2345_11_label) {
    const Space v2345_11_tail = child(s0,v2345_11_label);
    if (v2345_11_tail.empty()) continue;
    const Path v2345_11_head{v2345_11_label};
    const Space v2346_2 = singleton(v2345_11_head);
    const Space v2346_3 = intersect(constant_8,v2346_2);
    const Space v2346_4 = (has_head(v2346_3) ? constant_9 : Space{});
    const Space v2346_5 = subtract(constant_0,v2346_4);
    Space v2346_8;
    if (!v2346_5.empty()) {
      const Path v2347_6 = concat_path(p0,v2345_11_head);
      Space v2347_7_result;
      for (int v2347_7_label = 1; v2347_7_label <= 2; ++v2347_7_label) {
        const Space v2347_7_tail = child(v2345_11_tail,v2347_7_label);
        if (v2347_7_tail.empty()) continue;
        const Path v2347_7_head{v2347_7_label};
        const Space v2348_2 = singleton(v2347_7_head);
        const Space v2348_3 = intersect(constant_8,v2348_2);
        const Space v2348_4 = (has_head(v2348_3) ? constant_9 : Space{});
        const Space v2348_5 = subtract(constant_0,v2348_4);
        Space v2348_8;
        if (!v2348_5.empty()) {
          const Path v2349_6 = concat_path(v2347_6,v2347_7_head);
          const Space v2349_7 = routine_323(c, v2349_6, v2347_7_tail);
          v2348_8 = compose(v2348_5,v2349_7);
        }
        const Space v2348_9 = intersect(constant_8,v2348_2);
        const Space v2348_10 = (has_head(v2348_9) ? constant_9 : Space{});
        Space v2348_12;
        if (!v2348_10.empty()) {
          const Path v2350_6 = concat_path(v2347_6,v2347_7_head);
          const Space v2350_11 = routine_324(c, v2350_6, v2347_7_tail);
          v2348_12 = compose(v2348_10,v2350_11);
        }
        const Space v2348_13 = unite(v2348_8,v2348_12);
        v2347_7_result = unite(v2347_7_result,v2348_13);
      }
      const Space v2347_7 = std::move(v2347_7_result);
      v2346_8 = compose(v2346_5,v2347_7);
    }
    const Space v2346_9 = intersect(constant_8,v2346_2);
    const Space v2346_10 = (has_head(v2346_9) ? constant_9 : Space{});
    Space v2346_12;
    if (!v2346_10.empty()) {
      const Path v2351_6 = concat_path(p0,v2345_11_head);
      Space v2351_11_result;
      for (int v2351_11_label = 1; v2351_11_label <= 2; ++v2351_11_label) {
        const Space v2351_11_tail = child(v2345_11_tail,v2351_11_label);
        if (v2351_11_tail.empty()) continue;
        const Path v2351_11_head{v2351_11_label};
        const Space v2352_2 = singleton(v2351_11_head);
        const Space v2352_3 = intersect(constant_8,v2352_2);
        const Space v2352_4 = (has_head(v2352_3) ? constant_9 : Space{});
        const Space v2352_5 = subtract(constant_0,v2352_4);
        Space v2352_8;
        if (!v2352_5.empty()) {
          const Path v2353_6 = concat_path(v2351_6,v2351_11_head);
          const Space v2353_7 = routine_323(c, v2353_6, v2351_11_tail);
          v2352_8 = compose(v2352_5,v2353_7);
        }
        const Space v2352_9 = intersect(constant_8,v2352_2);
        const Space v2352_10 = (has_head(v2352_9) ? constant_9 : Space{});
        Space v2352_12;
        if (!v2352_10.empty()) {
          const Path v2354_6 = concat_path(v2351_6,v2351_11_head);
          const Space v2354_11 = routine_289(c, v2354_6, v2351_11_tail);
          v2352_12 = compose(v2352_10,v2354_11);
        }
        const Space v2352_13 = unite(v2352_8,v2352_12);
        v2351_11_result = unite(v2351_11_result,v2352_13);
      }
      const Space v2351_11 = std::move(v2351_11_result);
      v2346_12 = compose(v2346_10,v2351_11);
    }
    const Space v2346_13 = unite(v2346_8,v2346_12);
    v2345_11_result = unite(v2345_11_result,v2346_13);
  }
  const Space v2345_11 = std::move(v2345_11_result);
  return v2345_11;
}

static Space routine_306(Context& c, const Path& p0, const Space& s0) {
  Space v2355_8_result;
  for (int v2355_8_label = 1; v2355_8_label <= 2; ++v2355_8_label) {
    const Space v2355_8_tail = child(s0,v2355_8_label);
    if (v2355_8_tail.empty()) continue;
    const Path v2355_8_head{v2355_8_label};
    const Space v2356_2 = singleton(v2355_8_head);
    const Space v2356_3 = intersect(constant_8,v2356_2);
    const Space v2356_4 = (has_head(v2356_3) ? constant_9 : Space{});
    const Space v2356_5 = subtract(constant_0,v2356_4);
    Space v2356_8;
    if (!v2356_5.empty()) {
      const Path v2357_6 = concat_path(p0,v2355_8_head);
      Space v2357_7_result;
      for (int v2357_7_label = 1; v2357_7_label <= 2; ++v2357_7_label) {
        const Space v2357_7_tail = child(v2355_8_tail,v2357_7_label);
        if (v2357_7_tail.empty()) continue;
        const Path v2357_7_head{v2357_7_label};
        const Space v2358_2 = singleton(v2357_7_head);
        const Space v2358_3 = intersect(constant_8,v2358_2);
        const Space v2358_4 = (has_head(v2358_3) ? constant_9 : Space{});
        const Space v2358_5 = subtract(constant_0,v2358_4);
        Space v2358_8;
        if (!v2358_5.empty()) {
          const Path v2359_6 = concat_path(v2357_6,v2357_7_head);
          const Space v2359_7 = routine_323(c, v2359_6, v2357_7_tail);
          v2358_8 = compose(v2358_5,v2359_7);
        }
        const Space v2358_9 = intersect(constant_8,v2358_2);
        const Space v2358_10 = (has_head(v2358_9) ? constant_9 : Space{});
        Space v2358_12;
        if (!v2358_10.empty()) {
          const Path v2360_6 = concat_path(v2357_6,v2357_7_head);
          const Space v2360_11 = routine_324(c, v2360_6, v2357_7_tail);
          v2358_12 = compose(v2358_10,v2360_11);
        }
        const Space v2358_13 = unite(v2358_8,v2358_12);
        v2357_7_result = unite(v2357_7_result,v2358_13);
      }
      const Space v2357_7 = std::move(v2357_7_result);
      v2356_8 = compose(v2356_5,v2357_7);
    }
    const Space v2356_9 = intersect(constant_8,v2356_2);
    const Space v2356_10 = (has_head(v2356_9) ? constant_9 : Space{});
    const Path v2361_6 = concat_path(p0,v2355_8_head);
    const Space v2356_11 = singleton(v2361_6);
    const Space v2356_12 = compose(v2356_10,v2356_11);
    const Space v2356_13 = unite(v2356_8,v2356_12);
    v2355_8_result = unite(v2355_8_result,v2356_13);
  }
  const Space v2355_8 = std::move(v2355_8_result);
  return v2355_8;
}

static Space routine_307(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v2362_5 = Space{};
  return v2362_5;
}

static Space routine_308(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v2363_10_result;
  for (int v2363_10_label = 1; v2363_10_label <= 2; ++v2363_10_label) {
    const Space v2363_10_tail = child(s0,v2363_10_label);
    if (v2363_10_tail.empty()) continue;
    const Path v2363_10_head{v2363_10_label};
    const Space v2364_2 = singleton(v2363_10_head);
    const Space v2364_3 = intersect(constant_8,v2364_2);
    const Space v2364_4 = (has_head(v2364_3) ? constant_9 : Space{});
    Space v2364_14;
    if (!v2364_4.empty()) {
      Space v2365_5_result;
      for (int v2365_5_label = 1; v2365_5_label <= 2; ++v2365_5_label) {
        const Space v2365_5_tail = child(v2363_10_tail,v2365_5_label);
        if (v2365_5_tail.empty()) continue;
        const Path v2365_5_head{v2365_5_label};
        const Space v2366_2 = singleton(v2365_5_head);
        const Space v2366_3 = intersect(constant_8,v2366_2);
        const Space v2366_4 = (has_head(v2366_3) ? constant_9 : Space{});
        const Space v2366_5 = subtract(constant_0,v2366_4);
        Space v2366_7;
        if (!v2366_5.empty()) {
          const Space v2367_6 = routine_265(c, v2365_5_head, v2365_5_tail);
          v2366_7 = compose(v2366_5,v2367_6);
        }
        const Space v2366_8 = intersect(constant_8,v2366_2);
        const Space v2366_9 = (has_head(v2366_8) ? constant_9 : Space{});
        Space v2366_11;
        if (!v2366_9.empty()) {
          const Space v2368_10 = routine_266(c, v2365_5_head, v2365_5_tail);
          v2366_11 = compose(v2366_9,v2368_10);
        }
        const Space v2366_12 = unite(v2366_7,v2366_11);
        v2365_5_result = unite(v2365_5_result,v2366_12);
      }
      const Space v2365_5 = std::move(v2365_5_result);
      const Space v2365_6 = raffine(constant_25,v2365_5);
      const Space v2365_7 = unite(v2365_6,v2363_10_tail);
      const Path v2365_8 = concat_path(p0,v2363_10_head);
      const Path v2365_9 = concat_path(p3,v2365_8);
      const Space v2365_10 = wrap(v2365_7,v2365_9);
      const Space v2365_11 = unwrap(v2365_10,p1);
      const Space v2365_12 = unwrap(v2365_11,p2);
      const Space v2365_13 = unwrap(v2365_12,p1);
      v2364_14 = compose(v2364_4,v2365_13);
    }
    v2363_10_result = unite(v2363_10_result,v2364_14);
  }
  const Space v2363_10 = std::move(v2363_10_result);
  return v2363_10;
}

static Space routine_309(Context& c, const Path& p0, const Space& s0) {
  Space v2369_11_result;
  for (int v2369_11_label = 1; v2369_11_label <= 2; ++v2369_11_label) {
    const Space v2369_11_tail = child(s0,v2369_11_label);
    if (v2369_11_tail.empty()) continue;
    const Path v2369_11_head{v2369_11_label};
    const Space v2370_2 = singleton(v2369_11_head);
    const Space v2370_3 = intersect(constant_8,v2370_2);
    const Space v2370_4 = (has_head(v2370_3) ? constant_9 : Space{});
    const Space v2370_5 = subtract(constant_0,v2370_4);
    Space v2370_8;
    if (!v2370_5.empty()) {
      const Path v2371_6 = concat_path(p0,v2369_11_head);
      Space v2371_7_result;
      for (int v2371_7_label = 1; v2371_7_label <= 2; ++v2371_7_label) {
        const Space v2371_7_tail = child(v2369_11_tail,v2371_7_label);
        if (v2371_7_tail.empty()) continue;
        const Path v2371_7_head{v2371_7_label};
        const Space v2372_2 = singleton(v2371_7_head);
        const Space v2372_3 = intersect(constant_8,v2372_2);
        const Space v2372_4 = (has_head(v2372_3) ? constant_9 : Space{});
        const Space v2372_5 = subtract(constant_0,v2372_4);
        Space v2372_8;
        if (!v2372_5.empty()) {
          const Path v2373_6 = concat_path(v2371_6,v2371_7_head);
          const Space v2373_7 = routine_325(c, v2373_6, v2371_7_tail);
          v2372_8 = compose(v2372_5,v2373_7);
        }
        const Space v2372_9 = intersect(constant_8,v2372_2);
        const Space v2372_10 = (has_head(v2372_9) ? constant_9 : Space{});
        Space v2372_12;
        if (!v2372_10.empty()) {
          const Path v2374_6 = concat_path(v2371_6,v2371_7_head);
          const Space v2374_11 = routine_326(c, v2374_6, v2371_7_tail);
          v2372_12 = compose(v2372_10,v2374_11);
        }
        const Space v2372_13 = unite(v2372_8,v2372_12);
        v2371_7_result = unite(v2371_7_result,v2372_13);
      }
      const Space v2371_7 = std::move(v2371_7_result);
      v2370_8 = compose(v2370_5,v2371_7);
    }
    const Space v2370_9 = intersect(constant_8,v2370_2);
    const Space v2370_10 = (has_head(v2370_9) ? constant_9 : Space{});
    Space v2370_12;
    if (!v2370_10.empty()) {
      const Path v2375_6 = concat_path(p0,v2369_11_head);
      Space v2375_11_result;
      for (int v2375_11_label = 1; v2375_11_label <= 2; ++v2375_11_label) {
        const Space v2375_11_tail = child(v2369_11_tail,v2375_11_label);
        if (v2375_11_tail.empty()) continue;
        const Path v2375_11_head{v2375_11_label};
        const Space v2376_2 = singleton(v2375_11_head);
        const Space v2376_3 = intersect(constant_8,v2376_2);
        const Space v2376_4 = (has_head(v2376_3) ? constant_9 : Space{});
        const Space v2376_5 = subtract(constant_0,v2376_4);
        Space v2376_8;
        if (!v2376_5.empty()) {
          const Path v2377_6 = concat_path(v2375_6,v2375_11_head);
          const Space v2377_7 = routine_325(c, v2377_6, v2375_11_tail);
          v2376_8 = compose(v2376_5,v2377_7);
        }
        const Space v2376_9 = intersect(constant_8,v2376_2);
        const Space v2376_10 = (has_head(v2376_9) ? constant_9 : Space{});
        Space v2376_12;
        if (!v2376_10.empty()) {
          const Path v2378_6 = concat_path(v2375_6,v2375_11_head);
          const Space v2378_11 = routine_294(c, v2378_6, v2375_11_tail);
          v2376_12 = compose(v2376_10,v2378_11);
        }
        const Space v2376_13 = unite(v2376_8,v2376_12);
        v2375_11_result = unite(v2375_11_result,v2376_13);
      }
      const Space v2375_11 = std::move(v2375_11_result);
      v2370_12 = compose(v2370_10,v2375_11);
    }
    const Space v2370_13 = unite(v2370_8,v2370_12);
    v2369_11_result = unite(v2369_11_result,v2370_13);
  }
  const Space v2369_11 = std::move(v2369_11_result);
  return v2369_11;
}

static Space routine_310(Context& c, const Path& p0, const Space& s0) {
  Space v2379_8_result;
  for (int v2379_8_label = 1; v2379_8_label <= 2; ++v2379_8_label) {
    const Space v2379_8_tail = child(s0,v2379_8_label);
    if (v2379_8_tail.empty()) continue;
    const Path v2379_8_head{v2379_8_label};
    const Space v2380_2 = singleton(v2379_8_head);
    const Space v2380_3 = intersect(constant_8,v2380_2);
    const Space v2380_4 = (has_head(v2380_3) ? constant_9 : Space{});
    const Space v2380_5 = subtract(constant_0,v2380_4);
    Space v2380_8;
    if (!v2380_5.empty()) {
      const Path v2381_6 = concat_path(p0,v2379_8_head);
      Space v2381_7_result;
      for (int v2381_7_label = 1; v2381_7_label <= 2; ++v2381_7_label) {
        const Space v2381_7_tail = child(v2379_8_tail,v2381_7_label);
        if (v2381_7_tail.empty()) continue;
        const Path v2381_7_head{v2381_7_label};
        const Space v2382_2 = singleton(v2381_7_head);
        const Space v2382_3 = intersect(constant_8,v2382_2);
        const Space v2382_4 = (has_head(v2382_3) ? constant_9 : Space{});
        const Space v2382_5 = subtract(constant_0,v2382_4);
        Space v2382_8;
        if (!v2382_5.empty()) {
          const Path v2383_6 = concat_path(v2381_6,v2381_7_head);
          const Space v2383_7 = routine_325(c, v2383_6, v2381_7_tail);
          v2382_8 = compose(v2382_5,v2383_7);
        }
        const Space v2382_9 = intersect(constant_8,v2382_2);
        const Space v2382_10 = (has_head(v2382_9) ? constant_9 : Space{});
        Space v2382_12;
        if (!v2382_10.empty()) {
          const Path v2384_6 = concat_path(v2381_6,v2381_7_head);
          const Space v2384_11 = routine_326(c, v2384_6, v2381_7_tail);
          v2382_12 = compose(v2382_10,v2384_11);
        }
        const Space v2382_13 = unite(v2382_8,v2382_12);
        v2381_7_result = unite(v2381_7_result,v2382_13);
      }
      const Space v2381_7 = std::move(v2381_7_result);
      v2380_8 = compose(v2380_5,v2381_7);
    }
    const Space v2380_9 = intersect(constant_8,v2380_2);
    const Space v2380_10 = (has_head(v2380_9) ? constant_9 : Space{});
    const Path v2385_6 = concat_path(p0,v2379_8_head);
    const Space v2380_11 = singleton(v2385_6);
    const Space v2380_12 = compose(v2380_10,v2380_11);
    const Space v2380_13 = unite(v2380_8,v2380_12);
    v2379_8_result = unite(v2379_8_result,v2380_13);
  }
  const Space v2379_8 = std::move(v2379_8_result);
  return v2379_8;
}

static Space routine_311(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2386_4 = Space{};
  return v2386_4;
}

static Space routine_312(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2387_7 = concat_path(constant_23,p2);
  const Space v2387_8 = singleton(v2387_7);
  const Space v2387_9 = unite(constant_26,v2387_8);
  const Path v2387_11 = concat_path(constant_22,p1);
  const Space v2387_12 = singleton(v2387_11);
  const Space v2387_13 = unite(v2387_9,v2387_12);
  Space v2387_15_result;
  for (int v2387_15_label = 1; v2387_15_label <= 2; ++v2387_15_label) {
    const Space v2387_15_tail = child(s0,v2387_15_label);
    if (v2387_15_tail.empty()) continue;
    const Path v2387_15_head{v2387_15_label};
    const Space v2388_2 = singleton(v2387_15_head);
    const Space v2388_3 = intersect(constant_8,v2388_2);
    const Space v2388_4 = (has_head(v2388_3) ? constant_9 : Space{});
    const Path v2388_5 = concat_path(p0,v2387_15_head);
    const Path v2388_6 = concat_path(constant_6,v2388_5);
    const Space v2388_7 = singleton(v2388_6);
    const Space v2388_8 = unite(v2387_13,v2388_7);
    const Space v2388_9 = compose(v2388_4,v2388_8);
    v2387_15_result = unite(v2387_15_result,v2388_9);
  }
  const Space v2387_15 = std::move(v2387_15_result);
  return v2387_15;
}

static Space routine_313(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2389_4 = Space{};
  return v2389_4;
}

static Space routine_314(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2390_8 = concat_path(constant_22,p1);
  const Space v2390_9 = singleton(v2390_8);
  const Path v2390_11 = concat_path(constant_6,p2);
  const Space v2390_12 = singleton(v2390_11);
  Space v2390_13_result;
  for (int v2390_13_label = 1; v2390_13_label <= 2; ++v2390_13_label) {
    const Space v2390_13_tail = child(s0,v2390_13_label);
    if (v2390_13_tail.empty()) continue;
    const Path v2390_13_head{v2390_13_label};
    const Space v2391_2 = singleton(v2390_13_head);
    const Space v2391_3 = intersect(constant_8,v2391_2);
    const Space v2391_4 = (has_head(v2391_3) ? constant_9 : Space{});
    const Path v2391_5 = concat_path(p0,v2390_13_head);
    const Path v2391_6 = concat_path(constant_24,v2391_5);
    const Space v2391_7 = singleton(v2391_6);
    const Space v2391_8 = unite(constant_27,v2391_7);
    const Space v2391_9 = unite(v2391_8,v2390_9);
    const Space v2391_10 = unite(v2391_9,v2390_12);
    const Space v2391_11 = compose(v2391_4,v2391_10);
    v2390_13_result = unite(v2390_13_result,v2391_11);
  }
  const Space v2390_13 = std::move(v2390_13_result);
  return v2390_13;
}

static Space routine_315(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2392_4 = Space{};
  return v2392_4;
}

static Space routine_316(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2393_8 = concat_path(constant_23,p1);
  const Space v2393_9 = singleton(v2393_8);
  const Path v2393_11 = concat_path(constant_6,p2);
  const Space v2393_12 = singleton(v2393_11);
  Space v2393_13_result;
  for (int v2393_13_label = 1; v2393_13_label <= 2; ++v2393_13_label) {
    const Space v2393_13_tail = child(s0,v2393_13_label);
    if (v2393_13_tail.empty()) continue;
    const Path v2393_13_head{v2393_13_label};
    const Space v2394_2 = singleton(v2393_13_head);
    const Space v2394_3 = intersect(constant_8,v2394_2);
    const Space v2394_4 = (has_head(v2394_3) ? constant_9 : Space{});
    const Path v2394_5 = concat_path(p0,v2393_13_head);
    const Path v2394_6 = concat_path(constant_24,v2394_5);
    const Space v2394_7 = singleton(v2394_6);
    const Space v2394_8 = unite(constant_28,v2394_7);
    const Space v2394_9 = unite(v2394_8,v2393_9);
    const Space v2394_10 = unite(v2394_9,v2393_12);
    const Space v2394_11 = compose(v2394_4,v2394_10);
    v2393_13_result = unite(v2393_13_result,v2394_11);
  }
  const Space v2393_13 = std::move(v2393_13_result);
  return v2393_13;
}

static Space routine_317(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v2395_4 = Space{};
  return v2395_4;
}

static Space routine_318(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2396_8 = concat_path(constant_23,p2);
  const Space v2396_9 = singleton(v2396_8);
  const Path v2396_11 = concat_path(constant_22,p1);
  const Space v2396_12 = singleton(v2396_11);
  Space v2396_13_result;
  for (int v2396_13_label = 1; v2396_13_label <= 2; ++v2396_13_label) {
    const Space v2396_13_tail = child(s0,v2396_13_label);
    if (v2396_13_tail.empty()) continue;
    const Path v2396_13_head{v2396_13_label};
    const Space v2397_2 = singleton(v2396_13_head);
    const Space v2397_3 = intersect(constant_8,v2397_2);
    const Space v2397_4 = (has_head(v2397_3) ? constant_9 : Space{});
    const Path v2397_5 = concat_path(p0,v2396_13_head);
    const Path v2397_6 = concat_path(constant_24,v2397_5);
    const Space v2397_7 = singleton(v2397_6);
    const Space v2397_8 = unite(constant_29,v2397_7);
    const Space v2397_9 = unite(v2397_8,v2396_9);
    const Space v2397_10 = unite(v2397_9,v2396_12);
    const Space v2397_11 = compose(v2397_4,v2397_10);
    v2396_13_result = unite(v2396_13_result,v2397_11);
  }
  const Space v2396_13 = std::move(v2396_13_result);
  return v2396_13;
}

static Space routine_319(Context& c, const Path& p0, const Space& s0) {
  Space v2398_4_result;
  for (int v2398_4_label = 1; v2398_4_label <= 2; ++v2398_4_label) {
    const Space v2398_4_tail = child(s0,v2398_4_label);
    if (v2398_4_tail.empty()) continue;
    const Path v2398_4_head{v2398_4_label};
    const Space v2399_2 = singleton(v2398_4_head);
    const Space v2399_3 = intersect(constant_8,v2399_2);
    const Space v2399_4 = (has_head(v2399_3) ? constant_9 : Space{});
    Space v2399_7;
    if (!v2399_4.empty()) {
      const Path v2400_5 = concat_path(p0,v2398_4_head);
      Space v2400_6_result;
      for (int v2400_6_label = 1; v2400_6_label <= 2; ++v2400_6_label) {
        const Space v2400_6_tail = child(v2398_4_tail,v2400_6_label);
        if (v2400_6_tail.empty()) continue;
        const Path v2400_6_head{v2400_6_label};
        const Space v2401_2 = singleton(v2400_6_head);
        const Space v2401_3 = intersect(constant_8,v2401_2);
        const Space v2401_4 = (has_head(v2401_3) ? constant_9 : Space{});
        Space v2401_7;
        if (!v2401_4.empty()) {
          const Path v2402_5 = concat_path(v2400_5,v2400_6_head);
          const Space v2402_6 = routine_289(c, v2402_5, v2400_6_tail);
          v2401_7 = compose(v2401_4,v2402_6);
        }
        v2400_6_result = unite(v2400_6_result,v2401_7);
      }
      const Space v2400_6 = std::move(v2400_6_result);
      v2399_7 = compose(v2399_4,v2400_6);
    }
    v2398_4_result = unite(v2398_4_result,v2399_7);
  }
  const Space v2398_4 = std::move(v2398_4_result);
  return v2398_4;
}

static Space routine_320(Context& c, const Path& p0, const Space& s0) {
  Space v2403_3_result;
  for (int v2403_3_label = 1; v2403_3_label <= 2; ++v2403_3_label) {
    const Space v2403_3_tail = child(s0,v2403_3_label);
    if (v2403_3_tail.empty()) continue;
    const Path v2403_3_head{v2403_3_label};
    const Space v2404_2 = singleton(v2403_3_head);
    const Space v2404_3 = intersect(constant_8,v2404_2);
    const Space v2404_4 = (has_head(v2404_3) ? constant_9 : Space{});
    const Path v2404_5 = concat_path(p0,v2403_3_head);
    const Space v2404_6 = singleton(v2404_5);
    const Space v2404_7 = compose(v2404_4,v2404_6);
    v2403_3_result = unite(v2403_3_result,v2404_7);
  }
  const Space v2403_3 = std::move(v2403_3_result);
  return v2403_3;
}

static Space routine_321(Context& c, const Path& p0, const Space& s0) {
  Space v2405_4_result;
  for (int v2405_4_label = 1; v2405_4_label <= 2; ++v2405_4_label) {
    const Space v2405_4_tail = child(s0,v2405_4_label);
    if (v2405_4_tail.empty()) continue;
    const Path v2405_4_head{v2405_4_label};
    const Space v2406_2 = singleton(v2405_4_head);
    const Space v2406_3 = intersect(constant_8,v2406_2);
    const Space v2406_4 = (has_head(v2406_3) ? constant_9 : Space{});
    Space v2406_7;
    if (!v2406_4.empty()) {
      const Path v2407_5 = concat_path(p0,v2405_4_head);
      Space v2407_6_result;
      for (int v2407_6_label = 1; v2407_6_label <= 2; ++v2407_6_label) {
        const Space v2407_6_tail = child(v2405_4_tail,v2407_6_label);
        if (v2407_6_tail.empty()) continue;
        const Path v2407_6_head{v2407_6_label};
        const Space v2408_2 = singleton(v2407_6_head);
        const Space v2408_3 = intersect(constant_8,v2408_2);
        const Space v2408_4 = (has_head(v2408_3) ? constant_9 : Space{});
        Space v2408_7;
        if (!v2408_4.empty()) {
          const Path v2409_5 = concat_path(v2407_5,v2407_6_head);
          const Space v2409_6 = routine_294(c, v2409_5, v2407_6_tail);
          v2408_7 = compose(v2408_4,v2409_6);
        }
        v2407_6_result = unite(v2407_6_result,v2408_7);
      }
      const Space v2407_6 = std::move(v2407_6_result);
      v2406_7 = compose(v2406_4,v2407_6);
    }
    v2405_4_result = unite(v2405_4_result,v2406_7);
  }
  const Space v2405_4 = std::move(v2405_4_result);
  return v2405_4;
}

static Space routine_322(Context& c, const Path& p0, const Space& s0) {
  Space v2410_3_result;
  for (int v2410_3_label = 1; v2410_3_label <= 2; ++v2410_3_label) {
    const Space v2410_3_tail = child(s0,v2410_3_label);
    if (v2410_3_tail.empty()) continue;
    const Path v2410_3_head{v2410_3_label};
    const Space v2411_2 = singleton(v2410_3_head);
    const Space v2411_3 = intersect(constant_8,v2411_2);
    const Space v2411_4 = (has_head(v2411_3) ? constant_9 : Space{});
    const Path v2411_5 = concat_path(p0,v2410_3_head);
    const Space v2411_6 = singleton(v2411_5);
    const Space v2411_7 = compose(v2411_4,v2411_6);
    v2410_3_result = unite(v2410_3_result,v2411_7);
  }
  const Space v2410_3 = std::move(v2410_3_result);
  return v2410_3;
}

static Space routine_323(Context& c, const Path& p0, const Space& s0) {
  const Space v2412_2 = Space{};
  return v2412_2;
}

static Space routine_324(Context& c, const Path& p0, const Space& s0) {
  Space v2413_3_result;
  for (int v2413_3_label = 1; v2413_3_label <= 2; ++v2413_3_label) {
    const Space v2413_3_tail = child(s0,v2413_3_label);
    if (v2413_3_tail.empty()) continue;
    const Path v2413_3_head{v2413_3_label};
    const Space v2414_2 = singleton(v2413_3_head);
    const Space v2414_3 = intersect(constant_8,v2414_2);
    const Space v2414_4 = (has_head(v2414_3) ? constant_9 : Space{});
    const Path v2414_5 = concat_path(p0,v2413_3_head);
    const Space v2414_6 = singleton(v2414_5);
    const Space v2414_7 = compose(v2414_4,v2414_6);
    v2413_3_result = unite(v2413_3_result,v2414_7);
  }
  const Space v2413_3 = std::move(v2413_3_result);
  return v2413_3;
}

static Space routine_325(Context& c, const Path& p0, const Space& s0) {
  const Space v2415_2 = Space{};
  return v2415_2;
}

static Space routine_326(Context& c, const Path& p0, const Space& s0) {
  Space v2416_3_result;
  for (int v2416_3_label = 1; v2416_3_label <= 2; ++v2416_3_label) {
    const Space v2416_3_tail = child(s0,v2416_3_label);
    if (v2416_3_tail.empty()) continue;
    const Path v2416_3_head{v2416_3_label};
    const Space v2417_2 = singleton(v2416_3_head);
    const Space v2417_3 = intersect(constant_8,v2417_2);
    const Space v2417_4 = (has_head(v2417_3) ? constant_9 : Space{});
    const Path v2417_5 = concat_path(p0,v2416_3_head);
    const Space v2417_6 = singleton(v2417_5);
    const Space v2417_7 = compose(v2417_4,v2417_6);
    v2416_3_result = unite(v2416_3_result,v2417_7);
  }
  const Space v2416_3 = std::move(v2416_3_result);
  return v2416_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
