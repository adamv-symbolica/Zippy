#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,2};
static const Path constant_1 = Path{1,1,1,1};
static const Space constant_2 = literal_text("1 8 1 1 1 3 1 1 1 4");
static const Path constant_3 = Path{1,1,1,5};
static const Path constant_4 = Path{1,1,1,6};
static const Space constant_5 = literal_text("1 8 1 1 1 4 1 1 1 3");
static const Path constant_6 = Path{1,1,1,7};
static const Path constant_7 = Path{1,1,1,3};
static const Space constant_8 = literal_text("1 8 1 1 1 4 1 1 1 2");
static const Space constant_9 = literal_text("1 8 1 1 1 2 1 1 1 4");
static const Path constant_10 = Path{1,1,1,4};
static const Space constant_11 = literal_text("1 8 1 1 1 2 1 1 1 3");
static const Space constant_12 = literal_text("1 8 1 1 1 3 1 1 1 2");
static const Space constant_13 = literal_text("1 4 1 1 1 1");
static const Space constant_14 = literal_text("1 4 1 1 1 5");
static const Space constant_15 = literal_text("1 4 1 1 1 6");
static const Space constant_16 = literal_text("1 4 1 1 1 7");
static const Space constant_17 = literal_text("4 12 1 1 1 9 1 1 1 1 1 1 1 5 12 1 1 1 9 1 1 1 5 1 1 1 1 12 1 1 1 11 1 1 1 1 1 1 1 6 12 1 1 1 11 1 1 1 6 1 1 1 1");
static const Space constant_18 = literal_text("4 12 1 1 1 10 1 1 1 1 1 1 1 5 12 1 1 1 10 1 1 1 5 1 1 1 1 12 1 1 1 11 1 1 1 5 1 1 1 7 12 1 1 1 11 1 1 1 7 1 1 1 5");
static const Space constant_19 = literal_text("4 12 1 1 1 8 1 1 1 1 1 1 1 6 12 1 1 1 8 1 1 1 6 1 1 1 1 12 1 1 1 9 1 1 1 6 1 1 1 7 12 1 1 1 9 1 1 1 7 1 1 1 6");
static const Space constant_20 = literal_text("4 12 1 1 1 8 1 1 1 5 1 1 1 7 12 1 1 1 8 1 1 1 7 1 1 1 5 12 1 1 1 10 1 1 1 6 1 1 1 7 12 1 1 1 10 1 1 1 7 1 1 1 6");
static const Space constant_21 = literal_text("4 8 1 1 1 1 1 1 1 1 8 1 1 1 5 1 1 1 5 8 1 1 1 6 1 1 1 6 8 1 1 1 7 1 1 1 7");
static const Space constant_22 = literal_text("1 8 1 1 1 1 1 1 1 12");
static const Space constant_23 = literal_text("1 8 1 1 1 5 1 1 1 12");
static const Space constant_24 = literal_text("1 8 1 1 1 6 1 1 1 12");
static const Space constant_25 = literal_text("1 8 1 1 1 7 1 1 1 12");
static Space routine_0(Context& c);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_6 = routine_1(c, constant_0, constant_3, constant_2);
  const Space v0_7 = unite(v0_3,v0_6);
  const Space v0_10 = routine_1(c, constant_0, constant_4, constant_5);
  const Space v0_11 = unite(v0_7,v0_10);
  const Space v0_14 = routine_1(c, constant_0, constant_6, constant_5);
  const Space v0_15 = unite(v0_11,v0_14);
  const Space v0_18 = routine_1(c, constant_7, constant_1, constant_8);
  const Space v0_19 = unite(v0_15,v0_18);
  const Space v0_21 = routine_1(c, constant_7, constant_3, constant_8);
  const Space v0_22 = unite(v0_19,v0_21);
  const Space v0_24 = routine_1(c, constant_7, constant_4, constant_9);
  const Space v0_25 = unite(v0_22,v0_24);
  const Space v0_27 = routine_1(c, constant_7, constant_6, constant_9);
  const Space v0_28 = unite(v0_25,v0_27);
  const Space v0_31 = routine_1(c, constant_10, constant_1, constant_11);
  const Space v0_32 = unite(v0_28,v0_31);
  const Space v0_34 = routine_1(c, constant_10, constant_3, constant_11);
  const Space v0_35 = unite(v0_32,v0_34);
  const Space v0_37 = routine_1(c, constant_10, constant_4, constant_12);
  const Space v0_38 = unite(v0_35,v0_37);
  const Space v0_40 = routine_1(c, constant_10, constant_6, constant_12);
  const Space v0_41 = unite(v0_38,v0_40);
  return v0_41;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v1_3_branches = branches(c,s0);
  std::vector<Space> v1_3_outputs;
  v1_3_outputs.reserve(v1_3_branches.size());
  for (const auto& v1_3_branch : v1_3_branches) {
    const Path v1_3_head{v1_3_branch.first};
    const Space& v1_3_tail = v1_3_branch.second;
    const auto v2_2_branches = branches(c,v1_3_tail);
    std::vector<Space> v2_2_outputs;
    v2_2_outputs.reserve(v2_2_branches.size());
    for (const auto& v2_2_branch : v2_2_branches) {
      const Path v2_2_head{v2_2_branch.first};
      const Space& v2_2_tail = v2_2_branch.second;
      const Path v3_2 = concat_path(v1_3_head,v2_2_head);
      const auto v3_3_branches = branches(c,v2_2_tail);
      std::vector<Space> v3_3_outputs;
      v3_3_outputs.reserve(v3_3_branches.size());
      for (const auto& v3_3_branch : v3_3_branches) {
        const Path v3_3_head{v3_3_branch.first};
        const Space& v3_3_tail = v3_3_branch.second;
        const Path v4_2 = concat_path(v3_2,v3_3_head);
        const auto v4_3_branches = branches(c,v3_3_tail);
        std::vector<Space> v4_3_outputs;
        v4_3_outputs.reserve(v4_3_branches.size());
        for (const auto& v4_3_branch : v4_3_branches) {
          const Path v4_3_head{v4_3_branch.first};
          const Space& v4_3_tail = v4_3_branch.second;
          const Path v5_2 = concat_path(v4_2,v4_3_head);
          const auto v5_3_branches = branches(c,v4_3_tail);
          std::vector<Space> v5_3_outputs;
          v5_3_outputs.reserve(v5_3_branches.size());
          for (const auto& v5_3_branch : v5_3_branches) {
            const Path v5_3_head{v5_3_branch.first};
            const Space& v5_3_tail = v5_3_branch.second;
            const auto v6_2_branches = branches(c,v5_3_tail);
            std::vector<Space> v6_2_outputs;
            v6_2_outputs.reserve(v6_2_branches.size());
            for (const auto& v6_2_branch : v6_2_branches) {
              const Path v6_2_head{v6_2_branch.first};
              const Space& v6_2_tail = v6_2_branch.second;
              const Path v7_2 = concat_path(v5_3_head,v6_2_head);
              const auto v7_3_branches = branches(c,v6_2_tail);
              std::vector<Space> v7_3_outputs;
              v7_3_outputs.reserve(v7_3_branches.size());
              for (const auto& v7_3_branch : v7_3_branches) {
                const Path v7_3_head{v7_3_branch.first};
                const Space& v7_3_tail = v7_3_branch.second;
                const Path v8_2 = concat_path(v7_2,v7_3_head);
                const auto v8_3_branches = branches(c,v7_3_tail);
                std::vector<Space> v8_3_outputs;
                v8_3_outputs.reserve(v8_3_branches.size());
                for (const auto& v8_3_branch : v8_3_branches) {
                  const Path v8_3_head{v8_3_branch.first};
                  const Space& v8_3_tail = v8_3_branch.second;
                  const Path v9_2 = concat_path(v8_2,v8_3_head);
                  const Space v9_3 = routine_2(c, v9_2, p1, p0, v5_2, v8_3_tail);
                  v8_3_outputs.push_back(v9_3);
                }
                const Space v8_3 = join_outputs(std::move(v8_3_outputs));
                v7_3_outputs.push_back(v8_3);
              }
              const Space v7_3 = join_outputs(std::move(v7_3_outputs));
              v6_2_outputs.push_back(v7_3);
            }
            const Space v6_2 = join_outputs(std::move(v6_2_outputs));
            v5_3_outputs.push_back(v6_2);
          }
          const Space v5_3 = join_outputs(std::move(v5_3_outputs));
          v4_3_outputs.push_back(v5_3);
        }
        const Space v4_3 = join_outputs(std::move(v4_3_outputs));
        v3_3_outputs.push_back(v4_3);
      }
      const Space v3_3 = join_outputs(std::move(v3_3_outputs));
      v2_2_outputs.push_back(v3_3);
    }
    const Space v2_2 = join_outputs(std::move(v2_2_outputs));
    v1_3_outputs.push_back(v2_2);
  }
  const Space v1_3 = join_outputs(std::move(v1_3_outputs));
  return v1_3;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v10_6 = singleton(p1);
  const Space v10_7 = intersect(constant_13,v10_6);
  const auto v10_8_branches = branches(c,v10_7);
  std::vector<Space> v10_8_outputs;
  v10_8_outputs.reserve(v10_8_branches.size());
  for (const auto& v10_8_branch : v10_8_branches) {
    const Path v10_8_head{v10_8_branch.first};
    const Space& v10_8_tail = v10_8_branch.second;
    const auto v11_2_branches = branches(c,v10_8_tail);
    std::vector<Space> v11_2_outputs;
    v11_2_outputs.reserve(v11_2_branches.size());
    for (const auto& v11_2_branch : v11_2_branches) {
      const Path v11_2_head{v11_2_branch.first};
      const Space& v11_2_tail = v11_2_branch.second;
      const Path v12_2 = concat_path(v10_8_head,v11_2_head);
      const auto v12_3_branches = branches(c,v11_2_tail);
      std::vector<Space> v12_3_outputs;
      v12_3_outputs.reserve(v12_3_branches.size());
      for (const auto& v12_3_branch : v12_3_branches) {
        const Path v12_3_head{v12_3_branch.first};
        const Space& v12_3_tail = v12_3_branch.second;
        const Path v13_2 = concat_path(v12_2,v12_3_head);
        const auto v13_3_branches = branches(c,v12_3_tail);
        std::vector<Space> v13_3_outputs;
        v13_3_outputs.reserve(v13_3_branches.size());
        for (const auto& v13_3_branch : v13_3_branches) {
          const Path v13_3_head{v13_3_branch.first};
          const Space& v13_3_tail = v13_3_branch.second;
          const Path v14_2 = concat_path(v13_2,v13_3_head);
          const Space v14_3 = routine_3(c, v14_2, v13_3_tail);
          v13_3_outputs.push_back(v14_3);
        }
        const Space v13_3 = join_outputs(std::move(v13_3_outputs));
        v12_3_outputs.push_back(v13_3);
      }
      const Space v12_3 = join_outputs(std::move(v12_3_outputs));
      v11_2_outputs.push_back(v12_3);
    }
    const Space v11_2 = join_outputs(std::move(v11_2_outputs));
    v10_8_outputs.push_back(v11_2);
  }
  const Space v10_8 = join_outputs(std::move(v10_8_outputs));
  Space v10_13;
  if (!v10_8.empty()) {
    const Path v15_9 = concat_path(p2,p3);
    const Path v15_10 = concat_path(v15_9,p0);
    const Space v15_11 = singleton(v15_10);
    const auto v15_12_branches = branches(c,v15_11);
    std::vector<Space> v15_12_outputs;
    v15_12_outputs.reserve(v15_12_branches.size());
    for (const auto& v15_12_branch : v15_12_branches) {
      const Path v15_12_head{v15_12_branch.first};
      const Space& v15_12_tail = v15_12_branch.second;
      const auto v16_2_branches = branches(c,v15_12_tail);
      std::vector<Space> v16_2_outputs;
      v16_2_outputs.reserve(v16_2_branches.size());
      for (const auto& v16_2_branch : v16_2_branches) {
        const Path v16_2_head{v16_2_branch.first};
        const Space& v16_2_tail = v16_2_branch.second;
        const Path v17_2 = concat_path(v15_12_head,v16_2_head);
        const auto v17_3_branches = branches(c,v16_2_tail);
        std::vector<Space> v17_3_outputs;
        v17_3_outputs.reserve(v17_3_branches.size());
        for (const auto& v17_3_branch : v17_3_branches) {
          const Path v17_3_head{v17_3_branch.first};
          const Space& v17_3_tail = v17_3_branch.second;
          const Path v18_2 = concat_path(v17_2,v17_3_head);
          const auto v18_3_branches = branches(c,v17_3_tail);
          std::vector<Space> v18_3_outputs;
          v18_3_outputs.reserve(v18_3_branches.size());
          for (const auto& v18_3_branch : v18_3_branches) {
            const Path v18_3_head{v18_3_branch.first};
            const Space& v18_3_tail = v18_3_branch.second;
            const Path v19_2 = concat_path(v18_2,v18_3_head);
            const Space v19_3 = routine_4(c, v19_2, v18_3_tail);
            v18_3_outputs.push_back(v19_3);
          }
          const Space v18_3 = join_outputs(std::move(v18_3_outputs));
          v17_3_outputs.push_back(v18_3);
        }
        const Space v17_3 = join_outputs(std::move(v17_3_outputs));
        v16_2_outputs.push_back(v17_3);
      }
      const Space v16_2 = join_outputs(std::move(v16_2_outputs));
      v15_12_outputs.push_back(v16_2);
    }
    const Space v15_12 = join_outputs(std::move(v15_12_outputs));
    v10_13 = compose(v10_8,v15_12);
  }
  const Space v10_15 = intersect(constant_14,v10_6);
  const auto v10_16_branches = branches(c,v10_15);
  std::vector<Space> v10_16_outputs;
  v10_16_outputs.reserve(v10_16_branches.size());
  for (const auto& v10_16_branch : v10_16_branches) {
    const Path v10_16_head{v10_16_branch.first};
    const Space& v10_16_tail = v10_16_branch.second;
    const auto v20_2_branches = branches(c,v10_16_tail);
    std::vector<Space> v20_2_outputs;
    v20_2_outputs.reserve(v20_2_branches.size());
    for (const auto& v20_2_branch : v20_2_branches) {
      const Path v20_2_head{v20_2_branch.first};
      const Space& v20_2_tail = v20_2_branch.second;
      const Path v21_2 = concat_path(v10_16_head,v20_2_head);
      const auto v21_3_branches = branches(c,v20_2_tail);
      std::vector<Space> v21_3_outputs;
      v21_3_outputs.reserve(v21_3_branches.size());
      for (const auto& v21_3_branch : v21_3_branches) {
        const Path v21_3_head{v21_3_branch.first};
        const Space& v21_3_tail = v21_3_branch.second;
        const Path v22_2 = concat_path(v21_2,v21_3_head);
        const auto v22_3_branches = branches(c,v21_3_tail);
        std::vector<Space> v22_3_outputs;
        v22_3_outputs.reserve(v22_3_branches.size());
        for (const auto& v22_3_branch : v22_3_branches) {
          const Path v22_3_head{v22_3_branch.first};
          const Space& v22_3_tail = v22_3_branch.second;
          const Path v23_2 = concat_path(v22_2,v22_3_head);
          const Space v23_3 = routine_5(c, v23_2, v22_3_tail);
          v22_3_outputs.push_back(v23_3);
        }
        const Space v22_3 = join_outputs(std::move(v22_3_outputs));
        v21_3_outputs.push_back(v22_3);
      }
      const Space v21_3 = join_outputs(std::move(v21_3_outputs));
      v20_2_outputs.push_back(v21_3);
    }
    const Space v20_2 = join_outputs(std::move(v20_2_outputs));
    v10_16_outputs.push_back(v20_2);
  }
  const Space v10_16 = join_outputs(std::move(v10_16_outputs));
  Space v10_18;
  if (!v10_16.empty()) {
    const Path v24_9 = concat_path(p2,p3);
    const Path v24_10 = concat_path(v24_9,p0);
    const Space v24_11 = singleton(v24_10);
    const auto v24_17_branches = branches(c,v24_11);
    std::vector<Space> v24_17_outputs;
    v24_17_outputs.reserve(v24_17_branches.size());
    for (const auto& v24_17_branch : v24_17_branches) {
      const Path v24_17_head{v24_17_branch.first};
      const Space& v24_17_tail = v24_17_branch.second;
      const auto v25_2_branches = branches(c,v24_17_tail);
      std::vector<Space> v25_2_outputs;
      v25_2_outputs.reserve(v25_2_branches.size());
      for (const auto& v25_2_branch : v25_2_branches) {
        const Path v25_2_head{v25_2_branch.first};
        const Space& v25_2_tail = v25_2_branch.second;
        const Path v26_2 = concat_path(v24_17_head,v25_2_head);
        const auto v26_3_branches = branches(c,v25_2_tail);
        std::vector<Space> v26_3_outputs;
        v26_3_outputs.reserve(v26_3_branches.size());
        for (const auto& v26_3_branch : v26_3_branches) {
          const Path v26_3_head{v26_3_branch.first};
          const Space& v26_3_tail = v26_3_branch.second;
          const Path v27_2 = concat_path(v26_2,v26_3_head);
          const auto v27_3_branches = branches(c,v26_3_tail);
          std::vector<Space> v27_3_outputs;
          v27_3_outputs.reserve(v27_3_branches.size());
          for (const auto& v27_3_branch : v27_3_branches) {
            const Path v27_3_head{v27_3_branch.first};
            const Space& v27_3_tail = v27_3_branch.second;
            const Path v28_2 = concat_path(v27_2,v27_3_head);
            const Space v28_3 = routine_6(c, v28_2, v27_3_tail);
            v27_3_outputs.push_back(v28_3);
          }
          const Space v27_3 = join_outputs(std::move(v27_3_outputs));
          v26_3_outputs.push_back(v27_3);
        }
        const Space v26_3 = join_outputs(std::move(v26_3_outputs));
        v25_2_outputs.push_back(v26_3);
      }
      const Space v25_2 = join_outputs(std::move(v25_2_outputs));
      v24_17_outputs.push_back(v25_2);
    }
    const Space v24_17 = join_outputs(std::move(v24_17_outputs));
    v10_18 = compose(v10_16,v24_17);
  }
  const Space v10_19 = unite(v10_13,v10_18);
  const Space v10_21 = intersect(constant_15,v10_6);
  const auto v10_22_branches = branches(c,v10_21);
  std::vector<Space> v10_22_outputs;
  v10_22_outputs.reserve(v10_22_branches.size());
  for (const auto& v10_22_branch : v10_22_branches) {
    const Path v10_22_head{v10_22_branch.first};
    const Space& v10_22_tail = v10_22_branch.second;
    const auto v29_2_branches = branches(c,v10_22_tail);
    std::vector<Space> v29_2_outputs;
    v29_2_outputs.reserve(v29_2_branches.size());
    for (const auto& v29_2_branch : v29_2_branches) {
      const Path v29_2_head{v29_2_branch.first};
      const Space& v29_2_tail = v29_2_branch.second;
      const Path v30_2 = concat_path(v10_22_head,v29_2_head);
      const auto v30_3_branches = branches(c,v29_2_tail);
      std::vector<Space> v30_3_outputs;
      v30_3_outputs.reserve(v30_3_branches.size());
      for (const auto& v30_3_branch : v30_3_branches) {
        const Path v30_3_head{v30_3_branch.first};
        const Space& v30_3_tail = v30_3_branch.second;
        const Path v31_2 = concat_path(v30_2,v30_3_head);
        const auto v31_3_branches = branches(c,v30_3_tail);
        std::vector<Space> v31_3_outputs;
        v31_3_outputs.reserve(v31_3_branches.size());
        for (const auto& v31_3_branch : v31_3_branches) {
          const Path v31_3_head{v31_3_branch.first};
          const Space& v31_3_tail = v31_3_branch.second;
          const Path v32_2 = concat_path(v31_2,v31_3_head);
          const Space v32_3 = routine_7(c, v32_2, v31_3_tail);
          v31_3_outputs.push_back(v32_3);
        }
        const Space v31_3 = join_outputs(std::move(v31_3_outputs));
        v30_3_outputs.push_back(v31_3);
      }
      const Space v30_3 = join_outputs(std::move(v30_3_outputs));
      v29_2_outputs.push_back(v30_3);
    }
    const Space v29_2 = join_outputs(std::move(v29_2_outputs));
    v10_22_outputs.push_back(v29_2);
  }
  const Space v10_22 = join_outputs(std::move(v10_22_outputs));
  Space v10_24;
  if (!v10_22.empty()) {
    const Path v33_9 = concat_path(p2,p3);
    const Path v33_10 = concat_path(v33_9,p0);
    const Space v33_11 = singleton(v33_10);
    const auto v33_23_branches = branches(c,v33_11);
    std::vector<Space> v33_23_outputs;
    v33_23_outputs.reserve(v33_23_branches.size());
    for (const auto& v33_23_branch : v33_23_branches) {
      const Path v33_23_head{v33_23_branch.first};
      const Space& v33_23_tail = v33_23_branch.second;
      const auto v34_2_branches = branches(c,v33_23_tail);
      std::vector<Space> v34_2_outputs;
      v34_2_outputs.reserve(v34_2_branches.size());
      for (const auto& v34_2_branch : v34_2_branches) {
        const Path v34_2_head{v34_2_branch.first};
        const Space& v34_2_tail = v34_2_branch.second;
        const Path v35_2 = concat_path(v33_23_head,v34_2_head);
        const auto v35_3_branches = branches(c,v34_2_tail);
        std::vector<Space> v35_3_outputs;
        v35_3_outputs.reserve(v35_3_branches.size());
        for (const auto& v35_3_branch : v35_3_branches) {
          const Path v35_3_head{v35_3_branch.first};
          const Space& v35_3_tail = v35_3_branch.second;
          const Path v36_2 = concat_path(v35_2,v35_3_head);
          const auto v36_3_branches = branches(c,v35_3_tail);
          std::vector<Space> v36_3_outputs;
          v36_3_outputs.reserve(v36_3_branches.size());
          for (const auto& v36_3_branch : v36_3_branches) {
            const Path v36_3_head{v36_3_branch.first};
            const Space& v36_3_tail = v36_3_branch.second;
            const Path v37_2 = concat_path(v36_2,v36_3_head);
            const Space v37_3 = routine_8(c, v37_2, v36_3_tail);
            v36_3_outputs.push_back(v37_3);
          }
          const Space v36_3 = join_outputs(std::move(v36_3_outputs));
          v35_3_outputs.push_back(v36_3);
        }
        const Space v35_3 = join_outputs(std::move(v35_3_outputs));
        v34_2_outputs.push_back(v35_3);
      }
      const Space v34_2 = join_outputs(std::move(v34_2_outputs));
      v33_23_outputs.push_back(v34_2);
    }
    const Space v33_23 = join_outputs(std::move(v33_23_outputs));
    v10_24 = compose(v10_22,v33_23);
  }
  const Space v10_25 = unite(v10_19,v10_24);
  const Space v10_27 = intersect(constant_16,v10_6);
  const auto v10_28_branches = branches(c,v10_27);
  std::vector<Space> v10_28_outputs;
  v10_28_outputs.reserve(v10_28_branches.size());
  for (const auto& v10_28_branch : v10_28_branches) {
    const Path v10_28_head{v10_28_branch.first};
    const Space& v10_28_tail = v10_28_branch.second;
    const auto v38_2_branches = branches(c,v10_28_tail);
    std::vector<Space> v38_2_outputs;
    v38_2_outputs.reserve(v38_2_branches.size());
    for (const auto& v38_2_branch : v38_2_branches) {
      const Path v38_2_head{v38_2_branch.first};
      const Space& v38_2_tail = v38_2_branch.second;
      const Path v39_2 = concat_path(v10_28_head,v38_2_head);
      const auto v39_3_branches = branches(c,v38_2_tail);
      std::vector<Space> v39_3_outputs;
      v39_3_outputs.reserve(v39_3_branches.size());
      for (const auto& v39_3_branch : v39_3_branches) {
        const Path v39_3_head{v39_3_branch.first};
        const Space& v39_3_tail = v39_3_branch.second;
        const Path v40_2 = concat_path(v39_2,v39_3_head);
        const auto v40_3_branches = branches(c,v39_3_tail);
        std::vector<Space> v40_3_outputs;
        v40_3_outputs.reserve(v40_3_branches.size());
        for (const auto& v40_3_branch : v40_3_branches) {
          const Path v40_3_head{v40_3_branch.first};
          const Space& v40_3_tail = v40_3_branch.second;
          const Path v41_2 = concat_path(v40_2,v40_3_head);
          const Space v41_3 = routine_9(c, v41_2, v40_3_tail);
          v40_3_outputs.push_back(v41_3);
        }
        const Space v40_3 = join_outputs(std::move(v40_3_outputs));
        v39_3_outputs.push_back(v40_3);
      }
      const Space v39_3 = join_outputs(std::move(v39_3_outputs));
      v38_2_outputs.push_back(v39_3);
    }
    const Space v38_2 = join_outputs(std::move(v38_2_outputs));
    v10_28_outputs.push_back(v38_2);
  }
  const Space v10_28 = join_outputs(std::move(v10_28_outputs));
  Space v10_30;
  if (!v10_28.empty()) {
    const Path v42_9 = concat_path(p2,p3);
    const Path v42_10 = concat_path(v42_9,p0);
    const Space v42_11 = singleton(v42_10);
    const auto v42_29_branches = branches(c,v42_11);
    std::vector<Space> v42_29_outputs;
    v42_29_outputs.reserve(v42_29_branches.size());
    for (const auto& v42_29_branch : v42_29_branches) {
      const Path v42_29_head{v42_29_branch.first};
      const Space& v42_29_tail = v42_29_branch.second;
      const auto v43_2_branches = branches(c,v42_29_tail);
      std::vector<Space> v43_2_outputs;
      v43_2_outputs.reserve(v43_2_branches.size());
      for (const auto& v43_2_branch : v43_2_branches) {
        const Path v43_2_head{v43_2_branch.first};
        const Space& v43_2_tail = v43_2_branch.second;
        const Path v44_2 = concat_path(v42_29_head,v43_2_head);
        const auto v44_3_branches = branches(c,v43_2_tail);
        std::vector<Space> v44_3_outputs;
        v44_3_outputs.reserve(v44_3_branches.size());
        for (const auto& v44_3_branch : v44_3_branches) {
          const Path v44_3_head{v44_3_branch.first};
          const Space& v44_3_tail = v44_3_branch.second;
          const Path v45_2 = concat_path(v44_2,v44_3_head);
          const auto v45_3_branches = branches(c,v44_3_tail);
          std::vector<Space> v45_3_outputs;
          v45_3_outputs.reserve(v45_3_branches.size());
          for (const auto& v45_3_branch : v45_3_branches) {
            const Path v45_3_head{v45_3_branch.first};
            const Space& v45_3_tail = v45_3_branch.second;
            const Path v46_2 = concat_path(v45_2,v45_3_head);
            const Space v46_3 = routine_10(c, v46_2, v45_3_tail);
            v45_3_outputs.push_back(v46_3);
          }
          const Space v45_3 = join_outputs(std::move(v45_3_outputs));
          v44_3_outputs.push_back(v45_3);
        }
        const Space v44_3 = join_outputs(std::move(v44_3_outputs));
        v43_2_outputs.push_back(v44_3);
      }
      const Space v43_2 = join_outputs(std::move(v43_2_outputs));
      v42_29_outputs.push_back(v43_2);
    }
    const Space v42_29 = join_outputs(std::move(v42_29_outputs));
    v10_30 = compose(v10_28,v42_29);
  }
  const Space v10_31 = unite(v10_25,v10_30);
  const auto v10_40_branches = branches(c,v10_31);
  std::vector<Space> v10_40_outputs;
  v10_40_outputs.reserve(v10_40_branches.size());
  for (const auto& v10_40_branch : v10_40_branches) {
    const Path v10_40_head{v10_40_branch.first};
    const Space& v10_40_tail = v10_40_branch.second;
    const auto v47_2_branches = branches(c,v10_40_tail);
    std::vector<Space> v47_2_outputs;
    v47_2_outputs.reserve(v47_2_branches.size());
    for (const auto& v47_2_branch : v47_2_branches) {
      const Path v47_2_head{v47_2_branch.first};
      const Space& v47_2_tail = v47_2_branch.second;
      const Path v48_2 = concat_path(v10_40_head,v47_2_head);
      const auto v48_3_branches = branches(c,v47_2_tail);
      std::vector<Space> v48_3_outputs;
      v48_3_outputs.reserve(v48_3_branches.size());
      for (const auto& v48_3_branch : v48_3_branches) {
        const Path v48_3_head{v48_3_branch.first};
        const Space& v48_3_tail = v48_3_branch.second;
        const Path v49_2 = concat_path(v48_2,v48_3_head);
        const auto v49_3_branches = branches(c,v48_3_tail);
        std::vector<Space> v49_3_outputs;
        v49_3_outputs.reserve(v49_3_branches.size());
        for (const auto& v49_3_branch : v49_3_branches) {
          const Path v49_3_head{v49_3_branch.first};
          const Space& v49_3_tail = v49_3_branch.second;
          const Space v50_2 = routine_11(c, constant_1, p1, constant_17);
          const Space v50_3 = routine_11(c, constant_3, p1, constant_18);
          const Space v50_4 = unite(v50_2,v50_3);
          const Space v50_5 = routine_11(c, constant_4, p1, constant_19);
          const Space v50_6 = unite(v50_4,v50_5);
          const Space v50_7 = routine_11(c, constant_6, p1, constant_20);
          const Space v50_8 = unite(v50_6,v50_7);
          const Path v50_9 = concat_path(v49_2,v49_3_head);
          const auto v50_10_branches = branches(c,v50_8);
          std::vector<Space> v50_10_outputs;
          v50_10_outputs.reserve(v50_10_branches.size());
          for (const auto& v50_10_branch : v50_10_branches) {
            const Path v50_10_head{v50_10_branch.first};
            const Space& v50_10_tail = v50_10_branch.second;
            const auto v51_2_branches = branches(c,v50_10_tail);
            std::vector<Space> v51_2_outputs;
            v51_2_outputs.reserve(v51_2_branches.size());
            for (const auto& v51_2_branch : v51_2_branches) {
              const Path v51_2_head{v51_2_branch.first};
              const Space& v51_2_tail = v51_2_branch.second;
              const Path v52_2 = concat_path(v50_10_head,v51_2_head);
              const auto v52_3_branches = branches(c,v51_2_tail);
              std::vector<Space> v52_3_outputs;
              v52_3_outputs.reserve(v52_3_branches.size());
              for (const auto& v52_3_branch : v52_3_branches) {
                const Path v52_3_head{v52_3_branch.first};
                const Space& v52_3_tail = v52_3_branch.second;
                const Path v53_2 = concat_path(v52_2,v52_3_head);
                const auto v53_3_branches = branches(c,v52_3_tail);
                std::vector<Space> v53_3_outputs;
                v53_3_outputs.reserve(v53_3_branches.size());
                for (const auto& v53_3_branch : v53_3_branches) {
                  const Path v53_3_head{v53_3_branch.first};
                  const Space& v53_3_tail = v53_3_branch.second;
                  const Path v54_2 = concat_path(v53_2,v53_3_head);
                  const Space v54_3 = routine_12(c, v54_2, v50_9, v53_3_tail, v49_3_tail);
                  v53_3_outputs.push_back(v54_3);
                }
                const Space v53_3 = join_outputs(std::move(v53_3_outputs));
                v52_3_outputs.push_back(v53_3);
              }
              const Space v52_3 = join_outputs(std::move(v52_3_outputs));
              v51_2_outputs.push_back(v52_3);
            }
            const Space v51_2 = join_outputs(std::move(v51_2_outputs));
            v50_10_outputs.push_back(v51_2);
          }
          const Space v50_10 = join_outputs(std::move(v50_10_outputs));
          v49_3_outputs.push_back(v50_10);
        }
        const Space v49_3 = join_outputs(std::move(v49_3_outputs));
        v48_3_outputs.push_back(v49_3);
      }
      const Space v48_3 = join_outputs(std::move(v48_3_outputs));
      v47_2_outputs.push_back(v48_3);
    }
    const Space v47_2 = join_outputs(std::move(v47_2_outputs));
    v10_40_outputs.push_back(v47_2);
  }
  const Space v10_40 = join_outputs(std::move(v10_40_outputs));
  const auto v10_45_branches = branches(c,v10_40);
  std::vector<Space> v10_45_outputs;
  v10_45_outputs.reserve(v10_45_branches.size());
  for (const auto& v10_45_branch : v10_45_branches) {
    const Path v10_45_head{v10_45_branch.first};
    const Space& v10_45_tail = v10_45_branch.second;
    const auto v55_2_branches = branches(c,v10_45_tail);
    std::vector<Space> v55_2_outputs;
    v55_2_outputs.reserve(v55_2_branches.size());
    for (const auto& v55_2_branch : v55_2_branches) {
      const Path v55_2_head{v55_2_branch.first};
      const Space& v55_2_tail = v55_2_branch.second;
      const Path v56_2 = concat_path(v10_45_head,v55_2_head);
      const auto v56_3_branches = branches(c,v55_2_tail);
      std::vector<Space> v56_3_outputs;
      v56_3_outputs.reserve(v56_3_branches.size());
      for (const auto& v56_3_branch : v56_3_branches) {
        const Path v56_3_head{v56_3_branch.first};
        const Space& v56_3_tail = v56_3_branch.second;
        const Path v57_2 = concat_path(v56_2,v56_3_head);
        const auto v57_3_branches = branches(c,v56_3_tail);
        std::vector<Space> v57_3_outputs;
        v57_3_outputs.reserve(v57_3_branches.size());
        for (const auto& v57_3_branch : v57_3_branches) {
          const Path v57_3_head{v57_3_branch.first};
          const Space& v57_3_tail = v57_3_branch.second;
          const Path v58_2 = concat_path(v57_2,v57_3_head);
          const Space v58_3 = routine_13(c, constant_1, p1, v58_2, constant_17);
          const Space v58_4 = routine_13(c, constant_3, p1, v58_2, constant_18);
          const Space v58_5 = unite(v58_3,v58_4);
          const Space v58_6 = routine_13(c, constant_4, p1, v58_2, constant_19);
          const Space v58_7 = unite(v58_5,v58_6);
          const Space v58_8 = routine_13(c, constant_6, p1, v58_2, constant_20);
          const Space v58_9 = unite(v58_7,v58_8);
          const auto v58_10_branches = branches(c,v58_9);
          std::vector<Space> v58_10_outputs;
          v58_10_outputs.reserve(v58_10_branches.size());
          for (const auto& v58_10_branch : v58_10_branches) {
            const Path v58_10_head{v58_10_branch.first};
            const Space& v58_10_tail = v58_10_branch.second;
            const auto v59_2_branches = branches(c,v58_10_tail);
            std::vector<Space> v59_2_outputs;
            v59_2_outputs.reserve(v59_2_branches.size());
            for (const auto& v59_2_branch : v59_2_branches) {
              const Path v59_2_head{v59_2_branch.first};
              const Space& v59_2_tail = v59_2_branch.second;
              const Path v60_2 = concat_path(v58_10_head,v59_2_head);
              const auto v60_3_branches = branches(c,v59_2_tail);
              std::vector<Space> v60_3_outputs;
              v60_3_outputs.reserve(v60_3_branches.size());
              for (const auto& v60_3_branch : v60_3_branches) {
                const Path v60_3_head{v60_3_branch.first};
                const Space& v60_3_tail = v60_3_branch.second;
                const Path v61_2 = concat_path(v60_2,v60_3_head);
                const auto v61_3_branches = branches(c,v60_3_tail);
                std::vector<Space> v61_3_outputs;
                v61_3_outputs.reserve(v61_3_branches.size());
                for (const auto& v61_3_branch : v61_3_branches) {
                  const Path v61_3_head{v61_3_branch.first};
                  const Space& v61_3_tail = v61_3_branch.second;
                  const Path v62_2 = concat_path(v61_2,v61_3_head);
                  const Space v62_3 = routine_14(c, v62_2, v61_3_tail, v57_3_tail);
                  v61_3_outputs.push_back(v62_3);
                }
                const Space v61_3 = join_outputs(std::move(v61_3_outputs));
                v60_3_outputs.push_back(v61_3);
              }
              const Space v60_3 = join_outputs(std::move(v60_3_outputs));
              v59_2_outputs.push_back(v60_3);
            }
            const Space v59_2 = join_outputs(std::move(v59_2_outputs));
            v58_10_outputs.push_back(v59_2);
          }
          const Space v58_10 = join_outputs(std::move(v58_10_outputs));
          v57_3_outputs.push_back(v58_10);
        }
        const Space v57_3 = join_outputs(std::move(v57_3_outputs));
        v56_3_outputs.push_back(v57_3);
      }
      const Space v56_3 = join_outputs(std::move(v56_3_outputs));
      v55_2_outputs.push_back(v56_3);
    }
    const Space v55_2 = join_outputs(std::move(v55_2_outputs));
    v10_45_outputs.push_back(v55_2);
  }
  const Space v10_45 = join_outputs(std::move(v10_45_outputs));
  return v10_45;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  const auto v64_2_branches = branches(c,s0);
  std::vector<Space> v64_2_outputs;
  v64_2_outputs.reserve(v64_2_branches.size());
  for (const auto& v64_2_branch : v64_2_branches) {
    const Path v64_2_head{v64_2_branch.first};
    const Space& v64_2_tail = v64_2_branch.second;
    const auto v65_2_branches = branches(c,v64_2_tail);
    std::vector<Space> v65_2_outputs;
    v65_2_outputs.reserve(v65_2_branches.size());
    for (const auto& v65_2_branch : v65_2_branches) {
      const Path v65_2_head{v65_2_branch.first};
      const Space& v65_2_tail = v65_2_branch.second;
      const Path v66_2 = concat_path(v64_2_head,v65_2_head);
      const auto v66_3_branches = branches(c,v65_2_tail);
      std::vector<Space> v66_3_outputs;
      v66_3_outputs.reserve(v66_3_branches.size());
      for (const auto& v66_3_branch : v66_3_branches) {
        const Path v66_3_head{v66_3_branch.first};
        const Space& v66_3_tail = v66_3_branch.second;
        const Path v67_2 = concat_path(v66_2,v66_3_head);
        const auto v67_3_branches = branches(c,v66_3_tail);
        std::vector<Space> v67_3_outputs;
        v67_3_outputs.reserve(v67_3_branches.size());
        for (const auto& v67_3_branch : v67_3_branches) {
          const Path v67_3_head{v67_3_branch.first};
          const Space& v67_3_tail = v67_3_branch.second;
          const Path v68_2 = concat_path(v67_2,v67_3_head);
          const auto v68_3_branches = branches(c,v67_3_tail);
          std::vector<Space> v68_3_outputs;
          v68_3_outputs.reserve(v68_3_branches.size());
          for (const auto& v68_3_branch : v68_3_branches) {
            const Path v68_3_head{v68_3_branch.first};
            const Space& v68_3_tail = v68_3_branch.second;
            const auto v69_2_branches = branches(c,v68_3_tail);
            std::vector<Space> v69_2_outputs;
            v69_2_outputs.reserve(v69_2_branches.size());
            for (const auto& v69_2_branch : v69_2_branches) {
              const Path v69_2_head{v69_2_branch.first};
              const Space& v69_2_tail = v69_2_branch.second;
              const Path v70_2 = concat_path(v68_3_head,v69_2_head);
              const auto v70_3_branches = branches(c,v69_2_tail);
              std::vector<Space> v70_3_outputs;
              v70_3_outputs.reserve(v70_3_branches.size());
              for (const auto& v70_3_branch : v70_3_branches) {
                const Path v70_3_head{v70_3_branch.first};
                const Space& v70_3_tail = v70_3_branch.second;
                const Path v71_2 = concat_path(v70_2,v70_3_head);
                const auto v71_3_branches = branches(c,v70_3_tail);
                std::vector<Space> v71_3_outputs;
                v71_3_outputs.reserve(v71_3_branches.size());
                for (const auto& v71_3_branch : v71_3_branches) {
                  const Path v71_3_head{v71_3_branch.first};
                  const Space& v71_3_tail = v71_3_branch.second;
                  const Path v72_2 = concat_path(v71_2,v71_3_head);
                  const Space v72_3 = routine_15(c, v72_2, v68_2, p0, v71_3_tail);
                  v71_3_outputs.push_back(v72_3);
                }
                const Space v71_3 = join_outputs(std::move(v71_3_outputs));
                v70_3_outputs.push_back(v71_3);
              }
              const Space v70_3 = join_outputs(std::move(v70_3_outputs));
              v69_2_outputs.push_back(v70_3);
            }
            const Space v69_2 = join_outputs(std::move(v69_2_outputs));
            v68_3_outputs.push_back(v69_2);
          }
          const Space v68_3 = join_outputs(std::move(v68_3_outputs));
          v67_3_outputs.push_back(v68_3);
        }
        const Space v67_3 = join_outputs(std::move(v67_3_outputs));
        v66_3_outputs.push_back(v67_3);
      }
      const Space v66_3 = join_outputs(std::move(v66_3_outputs));
      v65_2_outputs.push_back(v66_3);
    }
    const Space v65_2 = join_outputs(std::move(v65_2_outputs));
    v64_2_outputs.push_back(v65_2);
  }
  const Space v64_2 = join_outputs(std::move(v64_2_outputs));
  return v64_2;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  const auto v74_2_branches = branches(c,s0);
  std::vector<Space> v74_2_outputs;
  v74_2_outputs.reserve(v74_2_branches.size());
  for (const auto& v74_2_branch : v74_2_branches) {
    const Path v74_2_head{v74_2_branch.first};
    const Space& v74_2_tail = v74_2_branch.second;
    const auto v75_2_branches = branches(c,v74_2_tail);
    std::vector<Space> v75_2_outputs;
    v75_2_outputs.reserve(v75_2_branches.size());
    for (const auto& v75_2_branch : v75_2_branches) {
      const Path v75_2_head{v75_2_branch.first};
      const Space& v75_2_tail = v75_2_branch.second;
      const Path v76_2 = concat_path(v74_2_head,v75_2_head);
      const auto v76_3_branches = branches(c,v75_2_tail);
      std::vector<Space> v76_3_outputs;
      v76_3_outputs.reserve(v76_3_branches.size());
      for (const auto& v76_3_branch : v76_3_branches) {
        const Path v76_3_head{v76_3_branch.first};
        const Space& v76_3_tail = v76_3_branch.second;
        const Path v77_2 = concat_path(v76_2,v76_3_head);
        const auto v77_3_branches = branches(c,v76_3_tail);
        std::vector<Space> v77_3_outputs;
        v77_3_outputs.reserve(v77_3_branches.size());
        for (const auto& v77_3_branch : v77_3_branches) {
          const Path v77_3_head{v77_3_branch.first};
          const Space& v77_3_tail = v77_3_branch.second;
          const Path v78_2 = concat_path(v77_2,v77_3_head);
          const auto v78_3_branches = branches(c,v77_3_tail);
          std::vector<Space> v78_3_outputs;
          v78_3_outputs.reserve(v78_3_branches.size());
          for (const auto& v78_3_branch : v78_3_branches) {
            const Path v78_3_head{v78_3_branch.first};
            const Space& v78_3_tail = v78_3_branch.second;
            const auto v79_2_branches = branches(c,v78_3_tail);
            std::vector<Space> v79_2_outputs;
            v79_2_outputs.reserve(v79_2_branches.size());
            for (const auto& v79_2_branch : v79_2_branches) {
              const Path v79_2_head{v79_2_branch.first};
              const Space& v79_2_tail = v79_2_branch.second;
              const Path v80_2 = concat_path(v78_3_head,v79_2_head);
              const auto v80_3_branches = branches(c,v79_2_tail);
              std::vector<Space> v80_3_outputs;
              v80_3_outputs.reserve(v80_3_branches.size());
              for (const auto& v80_3_branch : v80_3_branches) {
                const Path v80_3_head{v80_3_branch.first};
                const Space& v80_3_tail = v80_3_branch.second;
                const Path v81_2 = concat_path(v80_2,v80_3_head);
                const auto v81_3_branches = branches(c,v80_3_tail);
                std::vector<Space> v81_3_outputs;
                v81_3_outputs.reserve(v81_3_branches.size());
                for (const auto& v81_3_branch : v81_3_branches) {
                  const Path v81_3_head{v81_3_branch.first};
                  const Space& v81_3_tail = v81_3_branch.second;
                  const Path v82_2 = concat_path(v81_2,v81_3_head);
                  const Space v82_3 = routine_16(c, v82_2, p0, v78_2, v81_3_tail);
                  v81_3_outputs.push_back(v82_3);
                }
                const Space v81_3 = join_outputs(std::move(v81_3_outputs));
                v80_3_outputs.push_back(v81_3);
              }
              const Space v80_3 = join_outputs(std::move(v80_3_outputs));
              v79_2_outputs.push_back(v80_3);
            }
            const Space v79_2 = join_outputs(std::move(v79_2_outputs));
            v78_3_outputs.push_back(v79_2);
          }
          const Space v78_3 = join_outputs(std::move(v78_3_outputs));
          v77_3_outputs.push_back(v78_3);
        }
        const Space v77_3 = join_outputs(std::move(v77_3_outputs));
        v76_3_outputs.push_back(v77_3);
      }
      const Space v76_3 = join_outputs(std::move(v76_3_outputs));
      v75_2_outputs.push_back(v76_3);
    }
    const Space v75_2 = join_outputs(std::move(v75_2_outputs));
    v74_2_outputs.push_back(v75_2);
  }
  const Space v74_2 = join_outputs(std::move(v74_2_outputs));
  return v74_2;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  const auto v84_2_branches = branches(c,s0);
  std::vector<Space> v84_2_outputs;
  v84_2_outputs.reserve(v84_2_branches.size());
  for (const auto& v84_2_branch : v84_2_branches) {
    const Path v84_2_head{v84_2_branch.first};
    const Space& v84_2_tail = v84_2_branch.second;
    const auto v85_2_branches = branches(c,v84_2_tail);
    std::vector<Space> v85_2_outputs;
    v85_2_outputs.reserve(v85_2_branches.size());
    for (const auto& v85_2_branch : v85_2_branches) {
      const Path v85_2_head{v85_2_branch.first};
      const Space& v85_2_tail = v85_2_branch.second;
      const Path v86_2 = concat_path(v84_2_head,v85_2_head);
      const auto v86_3_branches = branches(c,v85_2_tail);
      std::vector<Space> v86_3_outputs;
      v86_3_outputs.reserve(v86_3_branches.size());
      for (const auto& v86_3_branch : v86_3_branches) {
        const Path v86_3_head{v86_3_branch.first};
        const Space& v86_3_tail = v86_3_branch.second;
        const Path v87_2 = concat_path(v86_2,v86_3_head);
        const auto v87_3_branches = branches(c,v86_3_tail);
        std::vector<Space> v87_3_outputs;
        v87_3_outputs.reserve(v87_3_branches.size());
        for (const auto& v87_3_branch : v87_3_branches) {
          const Path v87_3_head{v87_3_branch.first};
          const Space& v87_3_tail = v87_3_branch.second;
          const Path v88_2 = concat_path(v87_2,v87_3_head);
          const auto v88_3_branches = branches(c,v87_3_tail);
          std::vector<Space> v88_3_outputs;
          v88_3_outputs.reserve(v88_3_branches.size());
          for (const auto& v88_3_branch : v88_3_branches) {
            const Path v88_3_head{v88_3_branch.first};
            const Space& v88_3_tail = v88_3_branch.second;
            const auto v89_2_branches = branches(c,v88_3_tail);
            std::vector<Space> v89_2_outputs;
            v89_2_outputs.reserve(v89_2_branches.size());
            for (const auto& v89_2_branch : v89_2_branches) {
              const Path v89_2_head{v89_2_branch.first};
              const Space& v89_2_tail = v89_2_branch.second;
              const Path v90_2 = concat_path(v88_3_head,v89_2_head);
              const auto v90_3_branches = branches(c,v89_2_tail);
              std::vector<Space> v90_3_outputs;
              v90_3_outputs.reserve(v90_3_branches.size());
              for (const auto& v90_3_branch : v90_3_branches) {
                const Path v90_3_head{v90_3_branch.first};
                const Space& v90_3_tail = v90_3_branch.second;
                const Path v91_2 = concat_path(v90_2,v90_3_head);
                const auto v91_3_branches = branches(c,v90_3_tail);
                std::vector<Space> v91_3_outputs;
                v91_3_outputs.reserve(v91_3_branches.size());
                for (const auto& v91_3_branch : v91_3_branches) {
                  const Path v91_3_head{v91_3_branch.first};
                  const Space& v91_3_tail = v91_3_branch.second;
                  const Path v92_2 = concat_path(v91_2,v91_3_head);
                  const Space v92_3 = routine_17(c, v92_2, p0, v88_2, v91_3_tail);
                  v91_3_outputs.push_back(v92_3);
                }
                const Space v91_3 = join_outputs(std::move(v91_3_outputs));
                v90_3_outputs.push_back(v91_3);
              }
              const Space v90_3 = join_outputs(std::move(v90_3_outputs));
              v89_2_outputs.push_back(v90_3);
            }
            const Space v89_2 = join_outputs(std::move(v89_2_outputs));
            v88_3_outputs.push_back(v89_2);
          }
          const Space v88_3 = join_outputs(std::move(v88_3_outputs));
          v87_3_outputs.push_back(v88_3);
        }
        const Space v87_3 = join_outputs(std::move(v87_3_outputs));
        v86_3_outputs.push_back(v87_3);
      }
      const Space v86_3 = join_outputs(std::move(v86_3_outputs));
      v85_2_outputs.push_back(v86_3);
    }
    const Space v85_2 = join_outputs(std::move(v85_2_outputs));
    v84_2_outputs.push_back(v85_2);
  }
  const Space v84_2 = join_outputs(std::move(v84_2_outputs));
  return v84_2;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  const auto v94_2_branches = branches(c,s0);
  std::vector<Space> v94_2_outputs;
  v94_2_outputs.reserve(v94_2_branches.size());
  for (const auto& v94_2_branch : v94_2_branches) {
    const Path v94_2_head{v94_2_branch.first};
    const Space& v94_2_tail = v94_2_branch.second;
    const auto v95_2_branches = branches(c,v94_2_tail);
    std::vector<Space> v95_2_outputs;
    v95_2_outputs.reserve(v95_2_branches.size());
    for (const auto& v95_2_branch : v95_2_branches) {
      const Path v95_2_head{v95_2_branch.first};
      const Space& v95_2_tail = v95_2_branch.second;
      const Path v96_2 = concat_path(v94_2_head,v95_2_head);
      const auto v96_3_branches = branches(c,v95_2_tail);
      std::vector<Space> v96_3_outputs;
      v96_3_outputs.reserve(v96_3_branches.size());
      for (const auto& v96_3_branch : v96_3_branches) {
        const Path v96_3_head{v96_3_branch.first};
        const Space& v96_3_tail = v96_3_branch.second;
        const Path v97_2 = concat_path(v96_2,v96_3_head);
        const auto v97_3_branches = branches(c,v96_3_tail);
        std::vector<Space> v97_3_outputs;
        v97_3_outputs.reserve(v97_3_branches.size());
        for (const auto& v97_3_branch : v97_3_branches) {
          const Path v97_3_head{v97_3_branch.first};
          const Space& v97_3_tail = v97_3_branch.second;
          const Path v98_2 = concat_path(v97_2,v97_3_head);
          const auto v98_3_branches = branches(c,v97_3_tail);
          std::vector<Space> v98_3_outputs;
          v98_3_outputs.reserve(v98_3_branches.size());
          for (const auto& v98_3_branch : v98_3_branches) {
            const Path v98_3_head{v98_3_branch.first};
            const Space& v98_3_tail = v98_3_branch.second;
            const auto v99_2_branches = branches(c,v98_3_tail);
            std::vector<Space> v99_2_outputs;
            v99_2_outputs.reserve(v99_2_branches.size());
            for (const auto& v99_2_branch : v99_2_branches) {
              const Path v99_2_head{v99_2_branch.first};
              const Space& v99_2_tail = v99_2_branch.second;
              const Path v100_2 = concat_path(v98_3_head,v99_2_head);
              const auto v100_3_branches = branches(c,v99_2_tail);
              std::vector<Space> v100_3_outputs;
              v100_3_outputs.reserve(v100_3_branches.size());
              for (const auto& v100_3_branch : v100_3_branches) {
                const Path v100_3_head{v100_3_branch.first};
                const Space& v100_3_tail = v100_3_branch.second;
                const Path v101_2 = concat_path(v100_2,v100_3_head);
                const auto v101_3_branches = branches(c,v100_3_tail);
                std::vector<Space> v101_3_outputs;
                v101_3_outputs.reserve(v101_3_branches.size());
                for (const auto& v101_3_branch : v101_3_branches) {
                  const Path v101_3_head{v101_3_branch.first};
                  const Space& v101_3_tail = v101_3_branch.second;
                  const Path v102_2 = concat_path(v101_2,v101_3_head);
                  const Space v102_3 = routine_18(c, v102_2, p0, v98_2, v101_3_tail);
                  v101_3_outputs.push_back(v102_3);
                }
                const Space v101_3 = join_outputs(std::move(v101_3_outputs));
                v100_3_outputs.push_back(v101_3);
              }
              const Space v100_3 = join_outputs(std::move(v100_3_outputs));
              v99_2_outputs.push_back(v100_3);
            }
            const Space v99_2 = join_outputs(std::move(v99_2_outputs));
            v98_3_outputs.push_back(v99_2);
          }
          const Space v98_3 = join_outputs(std::move(v98_3_outputs));
          v97_3_outputs.push_back(v98_3);
        }
        const Space v97_3 = join_outputs(std::move(v97_3_outputs));
        v96_3_outputs.push_back(v97_3);
      }
      const Space v96_3 = join_outputs(std::move(v96_3_outputs));
      v95_2_outputs.push_back(v96_3);
    }
    const Space v95_2 = join_outputs(std::move(v95_2_outputs));
    v94_2_outputs.push_back(v95_2);
  }
  const Space v94_2 = join_outputs(std::move(v94_2_outputs));
  return v94_2;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v103_4_branches = branches(c,s0);
  std::vector<Space> v103_4_outputs;
  v103_4_outputs.reserve(v103_4_branches.size());
  for (const auto& v103_4_branch : v103_4_branches) {
    const Path v103_4_head{v103_4_branch.first};
    const Space& v103_4_tail = v103_4_branch.second;
    const auto v104_2_branches = branches(c,v103_4_tail);
    std::vector<Space> v104_2_outputs;
    v104_2_outputs.reserve(v104_2_branches.size());
    for (const auto& v104_2_branch : v104_2_branches) {
      const Path v104_2_head{v104_2_branch.first};
      const Space& v104_2_tail = v104_2_branch.second;
      const Path v105_2 = concat_path(v103_4_head,v104_2_head);
      const auto v105_3_branches = branches(c,v104_2_tail);
      std::vector<Space> v105_3_outputs;
      v105_3_outputs.reserve(v105_3_branches.size());
      for (const auto& v105_3_branch : v105_3_branches) {
        const Path v105_3_head{v105_3_branch.first};
        const Space& v105_3_tail = v105_3_branch.second;
        const Path v106_2 = concat_path(v105_2,v105_3_head);
        const auto v106_3_branches = branches(c,v105_3_tail);
        std::vector<Space> v106_3_outputs;
        v106_3_outputs.reserve(v106_3_branches.size());
        for (const auto& v106_3_branch : v106_3_branches) {
          const Path v106_3_head{v106_3_branch.first};
          const Space& v106_3_tail = v106_3_branch.second;
          const auto v107_2_branches = branches(c,v106_3_tail);
          std::vector<Space> v107_2_outputs;
          v107_2_outputs.reserve(v107_2_branches.size());
          for (const auto& v107_2_branch : v107_2_branches) {
            const Path v107_2_head{v107_2_branch.first};
            const Space& v107_2_tail = v107_2_branch.second;
            const auto v108_2_branches = branches(c,v107_2_tail);
            std::vector<Space> v108_2_outputs;
            v108_2_outputs.reserve(v108_2_branches.size());
            for (const auto& v108_2_branch : v108_2_branches) {
              const Path v108_2_head{v108_2_branch.first};
              const Space& v108_2_tail = v108_2_branch.second;
              const Path v109_2 = concat_path(v107_2_head,v108_2_head);
              const auto v109_3_branches = branches(c,v108_2_tail);
              std::vector<Space> v109_3_outputs;
              v109_3_outputs.reserve(v109_3_branches.size());
              for (const auto& v109_3_branch : v109_3_branches) {
                const Path v109_3_head{v109_3_branch.first};
                const Space& v109_3_tail = v109_3_branch.second;
                const Path v110_2 = concat_path(v109_2,v109_3_head);
                const auto v110_3_branches = branches(c,v109_3_tail);
                std::vector<Space> v110_3_outputs;
                v110_3_outputs.reserve(v110_3_branches.size());
                for (const auto& v110_3_branch : v110_3_branches) {
                  const Path v110_3_head{v110_3_branch.first};
                  const Space& v110_3_tail = v110_3_branch.second;
                  const Path v111_2 = concat_path(v110_2,v110_3_head);
                  const Space v111_3 = routine_19(c, v111_2, v110_3_tail);
                  v110_3_outputs.push_back(v111_3);
                }
                const Space v110_3 = join_outputs(std::move(v110_3_outputs));
                v109_3_outputs.push_back(v110_3);
              }
              const Space v109_3 = join_outputs(std::move(v109_3_outputs));
              v108_2_outputs.push_back(v109_3);
            }
            const Space v108_2 = join_outputs(std::move(v108_2_outputs));
            v107_2_outputs.push_back(v108_2);
          }
          const Space v107_2 = join_outputs(std::move(v107_2_outputs));
          const Space v107_3 = raffine(constant_21,v107_2);
          const Space v107_4 = unite(v107_3,v106_3_tail);
          const Path v107_5 = concat_path(v106_2,v106_3_head);
          const Path v107_6 = concat_path(p0,v107_5);
          const Space v107_7 = wrap(v107_4,v107_6);
          const Space v107_8 = unwrap(v107_7,p1);
          v106_3_outputs.push_back(v107_8);
        }
        const Space v106_3 = join_outputs(std::move(v106_3_outputs));
        v105_3_outputs.push_back(v106_3);
      }
      const Space v105_3 = join_outputs(std::move(v105_3_outputs));
      v104_2_outputs.push_back(v105_3);
    }
    const Space v104_2 = join_outputs(std::move(v104_2_outputs));
    v103_4_outputs.push_back(v104_2);
  }
  const Space v103_4 = join_outputs(std::move(v103_4_outputs));
  return v103_4;
}

static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v112_4 = unwrap(s0,p1);
  const Space v112_5 = wrap(v112_4,p0);
  const Space v112_6 = compose(v112_5,s1);
  return v112_6;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v113_5_branches = branches(c,s0);
  std::vector<Space> v113_5_outputs;
  v113_5_outputs.reserve(v113_5_branches.size());
  for (const auto& v113_5_branch : v113_5_branches) {
    const Path v113_5_head{v113_5_branch.first};
    const Space& v113_5_tail = v113_5_branch.second;
    const auto v114_2_branches = branches(c,v113_5_tail);
    std::vector<Space> v114_2_outputs;
    v114_2_outputs.reserve(v114_2_branches.size());
    for (const auto& v114_2_branch : v114_2_branches) {
      const Path v114_2_head{v114_2_branch.first};
      const Space& v114_2_tail = v114_2_branch.second;
      const Path v115_2 = concat_path(v113_5_head,v114_2_head);
      const auto v115_3_branches = branches(c,v114_2_tail);
      std::vector<Space> v115_3_outputs;
      v115_3_outputs.reserve(v115_3_branches.size());
      for (const auto& v115_3_branch : v115_3_branches) {
        const Path v115_3_head{v115_3_branch.first};
        const Space& v115_3_tail = v115_3_branch.second;
        const Path v116_2 = concat_path(v115_2,v115_3_head);
        const auto v116_3_branches = branches(c,v115_3_tail);
        std::vector<Space> v116_3_outputs;
        v116_3_outputs.reserve(v116_3_branches.size());
        for (const auto& v116_3_branch : v116_3_branches) {
          const Path v116_3_head{v116_3_branch.first};
          const Space& v116_3_tail = v116_3_branch.second;
          const auto v117_2_branches = branches(c,v116_3_tail);
          std::vector<Space> v117_2_outputs;
          v117_2_outputs.reserve(v117_2_branches.size());
          for (const auto& v117_2_branch : v117_2_branches) {
            const Path v117_2_head{v117_2_branch.first};
            const Space& v117_2_tail = v117_2_branch.second;
            const auto v118_2_branches = branches(c,v117_2_tail);
            std::vector<Space> v118_2_outputs;
            v118_2_outputs.reserve(v118_2_branches.size());
            for (const auto& v118_2_branch : v118_2_branches) {
              const Path v118_2_head{v118_2_branch.first};
              const Space& v118_2_tail = v118_2_branch.second;
              const Path v119_2 = concat_path(v117_2_head,v118_2_head);
              const auto v119_3_branches = branches(c,v118_2_tail);
              std::vector<Space> v119_3_outputs;
              v119_3_outputs.reserve(v119_3_branches.size());
              for (const auto& v119_3_branch : v119_3_branches) {
                const Path v119_3_head{v119_3_branch.first};
                const Space& v119_3_tail = v119_3_branch.second;
                const Path v120_2 = concat_path(v119_2,v119_3_head);
                const auto v120_3_branches = branches(c,v119_3_tail);
                std::vector<Space> v120_3_outputs;
                v120_3_outputs.reserve(v120_3_branches.size());
                for (const auto& v120_3_branch : v120_3_branches) {
                  const Path v120_3_head{v120_3_branch.first};
                  const Space& v120_3_tail = v120_3_branch.second;
                  const Path v121_2 = concat_path(v120_2,v120_3_head);
                  const Space v121_3 = routine_20(c, v121_2, v120_3_tail);
                  v120_3_outputs.push_back(v121_3);
                }
                const Space v120_3 = join_outputs(std::move(v120_3_outputs));
                v119_3_outputs.push_back(v120_3);
              }
              const Space v119_3 = join_outputs(std::move(v119_3_outputs));
              v118_2_outputs.push_back(v119_3);
            }
            const Space v118_2 = join_outputs(std::move(v118_2_outputs));
            v117_2_outputs.push_back(v118_2);
          }
          const Space v117_2 = join_outputs(std::move(v117_2_outputs));
          const Space v117_3 = raffine(constant_21,v117_2);
          const Space v117_4 = unite(v117_3,v116_3_tail);
          const Path v117_5 = concat_path(v116_2,v116_3_head);
          const Path v117_6 = concat_path(p0,v117_5);
          const Space v117_7 = wrap(v117_4,v117_6);
          const Space v117_8 = unwrap(v117_7,p1);
          const Space v117_9 = unwrap(v117_8,p2);
          const Space v117_10 = unwrap(v117_9,p1);
          v116_3_outputs.push_back(v117_10);
        }
        const Space v116_3 = join_outputs(std::move(v116_3_outputs));
        v115_3_outputs.push_back(v116_3);
      }
      const Space v115_3 = join_outputs(std::move(v115_3_outputs));
      v114_2_outputs.push_back(v115_3);
    }
    const Space v114_2 = join_outputs(std::move(v114_2_outputs));
    v113_5_outputs.push_back(v114_2);
  }
  const Space v113_5 = join_outputs(std::move(v113_5_outputs));
  return v113_5;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v122_4 = singleton(p0);
  const Space v122_5 = intersect(constant_13,v122_4);
  const Space v122_7 = unwrap(s1,constant_4);
  const Space v122_9 = unwrap(s1,constant_6);
  const Space v122_10 = compose(v122_7,v122_9);
  const Space v122_12 = unwrap(s1,constant_3);
  const Space v122_13 = compose(v122_10,v122_12);
  const Space v122_14 = compose(v122_5,v122_13);
  const Space v122_16 = intersect(constant_14,v122_4);
  const Space v122_18 = unwrap(s1,constant_1);
  const Space v122_19 = compose(v122_10,v122_18);
  const Space v122_20 = compose(v122_16,v122_19);
  const Space v122_21 = unite(v122_14,v122_20);
  const Space v122_23 = intersect(constant_15,v122_4);
  const Space v122_24 = compose(v122_9,v122_18);
  const Space v122_25 = compose(v122_24,v122_12);
  const Space v122_26 = compose(v122_23,v122_25);
  const Space v122_27 = unite(v122_21,v122_26);
  const Space v122_29 = intersect(constant_16,v122_4);
  const Space v122_30 = compose(v122_7,v122_18);
  const Space v122_31 = compose(v122_30,v122_12);
  const Space v122_32 = compose(v122_29,v122_31);
  const Space v122_33 = unite(v122_27,v122_32);
  return v122_33;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v123_6 = concat_path(constant_3,p0);
  const Space v123_7 = singleton(v123_6);
  const Space v123_8 = unite(constant_22,v123_7);
  const Path v123_10 = concat_path(constant_4,p2);
  const Space v123_11 = singleton(v123_10);
  const Space v123_12 = unite(v123_8,v123_11);
  const Path v123_14 = concat_path(constant_6,p1);
  const Space v123_15 = singleton(v123_14);
  const Space v123_16 = unite(v123_12,v123_15);
  return v123_16;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v124_6 = concat_path(constant_1,p0);
  const Space v124_7 = singleton(v124_6);
  const Space v124_8 = unite(constant_23,v124_7);
  const Path v124_10 = concat_path(constant_4,p1);
  const Space v124_11 = singleton(v124_10);
  const Space v124_12 = unite(v124_8,v124_11);
  const Path v124_14 = concat_path(constant_6,p2);
  const Space v124_15 = singleton(v124_14);
  const Space v124_16 = unite(v124_12,v124_15);
  return v124_16;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v125_6 = concat_path(constant_1,p2);
  const Space v125_7 = singleton(v125_6);
  const Space v125_8 = unite(constant_24,v125_7);
  const Path v125_10 = concat_path(constant_3,p0);
  const Space v125_11 = singleton(v125_10);
  const Space v125_12 = unite(v125_8,v125_11);
  const Path v125_14 = concat_path(constant_6,p1);
  const Space v125_15 = singleton(v125_14);
  const Space v125_16 = unite(v125_12,v125_15);
  return v125_16;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v126_6 = concat_path(constant_1,p2);
  const Space v126_7 = singleton(v126_6);
  const Space v126_8 = unite(constant_25,v126_7);
  const Path v126_10 = concat_path(constant_3,p0);
  const Space v126_11 = singleton(v126_10);
  const Space v126_12 = unite(v126_8,v126_11);
  const Path v126_14 = concat_path(constant_4,p1);
  const Space v126_15 = singleton(v126_14);
  const Space v126_16 = unite(v126_12,v126_15);
  return v126_16;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  const Space v127_2 = singleton(p0);
  return v127_2;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  const Space v128_2 = singleton(p0);
  return v128_2;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
