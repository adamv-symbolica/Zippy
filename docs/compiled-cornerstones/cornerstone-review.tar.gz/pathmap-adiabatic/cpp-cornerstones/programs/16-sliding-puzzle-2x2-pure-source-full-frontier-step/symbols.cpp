#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("12 4 1 2 3 4 4 1 3 4 2 4 1 4 2 3 4 5 2 4 3 4 5 3 2 4 4 5 4 3 2 4 6 2 3 4 4 6 3 4 2 4 6 4 2 3 4 7 2 4 3 4 7 3 2 4 4 7 4 3 2");
static Space routine_0(Context& c);
static Space routine_0(Context& c) {
  return constant_0;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"7 1 2 66 76 2 1 49 3 1 51 4 1 50 5 2 84 76 6 2 66 82 7 2 84 82"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
