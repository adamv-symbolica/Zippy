#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1};
static const Space constant_2 = literal_text("77 13 1 1 1 1 1 2 2 1 1 1 1 2 2 12 1 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 1 2 2 1 1 2 1 2 2 14 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 14 1 1 1 1 2 2 2 1 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 1 1 2 2 12 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 2 2 1 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 13 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 2 2 1 2 1 1 1 2 2 10 1 1 2 1 2 2 1 1 2 2 13 1 1 2 1 2 2 2 1 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 9 1 1 2 2 2 1 1 2 2 13 1 2 1 1 1 2 2 1 1 1 1 2 2 12 1 2 1 1 1 2 2 1 1 1 2 2 11 1 2 1 1 1 2 2 1 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 12 1 2 1 1 1 2 2 1 2 1 2 2 14 1 2 1 1 1 2 2 2 1 2 1 1 2 2 9 1 2 1 1 2 2 1 2 2 12 1 2 1 2 2 1 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 1 2 1 1 1 2 2 12 1 2 1 2 2 1 2 1 1 1 2 2 10 1 2 2 1 1 1 1 1 2 2 9 1 2 2 1 1 2 1 2 2 9 1 2 2 1 2 1 1 2 2 9 1 2 2 2 1 1 1 2 2 9 1 2 2 2 1 2 1 2 2 15 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 13 2 1 1 1 1 2 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 1 1 2 1 1 2 2 13 2 1 1 1 1 2 2 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 2 1 2 1 2 2 14 2 1 1 1 1 2 2 2 1 2 1 1 2 2 11 2 1 1 1 1 2 2 2 1 2 2 14 2 1 1 1 2 2 1 1 2 1 1 1 2 2 10 2 1 1 1 2 2 1 1 2 2 12 2 1 1 1 2 2 1 2 1 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 13 2 1 1 1 2 2 2 1 2 1 1 2 2 13 2 1 1 2 2 1 1 1 1 1 1 2 2 9 2 1 1 2 2 1 1 2 2 12 2 1 1 2 2 1 2 1 1 1 2 2 13 2 1 1 2 2 2 1 1 1 1 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 13 2 1 1 2 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 2 1 1 2 1 2 2 13 2 1 2 1 2 2 2 1 2 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 10 2 1 2 1 2 2 2 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 10 2 1 2 2 1 2 1 1 2 2 11 2 1 2 2 1 2 1 2 1 2 2 7 2 1 2 2 1 2 2 10 2 1 2 2 2 1 2 1 2 2 6 2 2 1 1 2 2 6 2 2 2 1 2 2");
static const Space constant_3 = literal_text("120 16 2 2 1 1 1 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 1 2 2 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 2 2 18 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 1 1 2 2 2 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 17 2 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 16 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 1 2 1 2 2 1 1 2 2 16 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 14 2 2 1 1 1 2 1 2 2 2 1 1 2 2 13 2 2 1 1 1 2 2 1 1 1 1 2 2 12 2 2 1 1 1 2 2 1 2 1 2 2 12 2 2 1 1 1 2 2 2 1 1 2 2 16 2 2 1 1 2 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 1 1 2 2 14 2 2 1 1 2 1 1 1 2 2 1 1 2 2 18 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 17 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 2 1 2 2 17 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 2 12 2 2 1 1 2 1 1 2 2 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 1 1 2 1 2 2 1 1 1 2 2 16 2 2 1 1 2 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 2 2 1 1 1 1 1 2 2 12 2 2 1 1 2 2 1 1 2 1 2 2 12 2 2 1 1 2 2 1 2 1 1 2 2 12 2 2 1 1 2 2 2 1 1 1 2 2 12 2 2 1 1 2 2 2 1 2 1 2 2 18 2 2 1 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 1 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 1 2 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 2 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 2 1 2 1 1 2 2 14 2 2 1 2 1 1 1 1 2 2 2 1 2 2 17 2 2 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 13 2 2 1 2 1 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 1 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 2 1 1 2 2 1 1 1 1 1 1 2 2 12 2 2 1 2 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 1 1 1 1 2 2 14 2 2 1 2 1 1 2 2 2 1 1 1 2 2 13 2 2 1 2 1 1 2 2 2 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 1 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 1 2 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 2 1 1 2 2 15 2 2 1 2 1 2 1 2 2 2 1 2 1 2 2 13 2 2 1 2 1 2 1 2 2 2 1 2 2 14 2 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 2 1 2 1 2 2 1 2 1 1 2 2 14 2 2 1 2 1 2 2 1 2 1 2 1 2 2 10 2 2 1 2 1 2 2 1 2 2 13 2 2 1 2 1 2 2 2 1 2 1 2 2 9 2 2 1 2 2 1 1 2 2 9 2 2 1 2 2 2 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 2 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 1 2 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 2 1 2 2 16 2 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 14 2 2 2 1 1 1 1 2 2 1 1 1 2 2 17 2 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 2 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 2 1 1 2 2 15 2 2 2 1 1 1 2 2 2 1 2 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 2 1 2 1 2 2 14 2 2 2 1 1 2 1 2 2 2 1 1 2 2 14 2 2 2 1 1 2 2 1 1 1 1 1 2 2 13 2 2 2 1 1 2 2 1 1 1 1 2 2 12 2 2 2 1 1 2 2 1 2 1 2 2 14 2 2 2 1 1 2 2 2 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 15 2 2 2 1 2 1 1 2 2 1 2 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 14 2 2 2 1 2 1 2 2 1 1 1 1 2 2 15 2 2 2 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 2 1 2 1 2 2 1 1 1 2 2 16 2 2 2 1 2 1 2 2 1 2 1 1 1 1 2 2 13 2 2 2 1 2 1 2 2 1 2 1 2 2 14 2 2 2 1 2 1 2 2 2 1 2 1 2 2 12 2 2 2 1 2 2 1 1 2 1 2 2 13 2 2 2 1 2 2 1 2 1 1 1 2 2 13 2 2 2 1 2 2 2 1 1 1 1 2 2 12 2 2 2 1 2 2 2 1 1 1 2 2 10 2 2 2 1 2 2 2 1 2 2");
static const Path constant_4 = Path{2};
static const Space constant_5 = literal_text("43 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 2 1 2 2 15 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 15 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 13 1 1 1 1 2 2 1 1 1 2 1 2 2 11 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 2 1 2 1 1 2 2 14 1 1 2 1 2 2 1 1 1 1 1 1 2 2 13 1 1 2 1 2 2 1 1 1 1 1 2 2 14 1 1 2 1 2 2 1 2 1 1 1 1 2 2 13 1 1 2 1 2 2 1 2 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 11 1 1 2 2 2 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 2 1 1 2 2 15 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 13 1 2 1 1 2 2 2 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 1 2 1 2 2 11 1 2 1 2 2 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 2 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 11 1 2 1 2 2 2 1 2 1 2 2 9 1 2 2 1 1 2 1 2 2 10 1 2 2 1 2 1 1 1 2 2 10 1 2 2 2 1 1 1 1 2 2 9 1 2 2 2 1 1 1 2 2 7 1 2 2 2 1 2 2");
static const Space constant_6 = literal_text("1 1 2");
static const Space constant_7 = singleton(Path{});
static const Path constant_8 = Path{2,2};
static const Space constant_9 = literal_text("1 11 1 2 1 1 2 1 1 2 1 2 2");
static const Path constant_10 = Path{};
static const std::vector<Path> constant_11 = paths_text("133 8 1 1 1 2 1 1 2 2 8 1 2 1 2 1 1 2 2 8 1 1 1 1 2 1 2 2 8 2 1 1 1 2 1 2 2 8 1 2 1 1 2 1 2 2 8 1 1 2 1 2 1 2 2 8 2 1 2 1 2 1 2 2 9 1 1 1 1 1 1 1 2 2 9 2 1 1 1 1 1 1 2 2 9 1 2 1 1 1 1 1 2 2 9 1 1 2 1 1 1 1 2 2 8 2 1 1 2 1 1 2 2 9 2 1 2 1 1 1 1 2 2 9 2 1 1 2 1 1 1 2 2 9 1 2 1 2 1 1 1 2 2 9 1 1 1 1 2 1 1 2 2 9 2 1 1 1 2 1 1 2 2 9 1 2 1 1 2 1 1 2 2 9 1 1 2 1 2 1 1 2 2 9 2 1 2 1 2 1 1 2 2 9 1 1 1 1 1 2 1 2 2 9 2 1 1 1 1 2 1 2 2 9 1 1 1 2 1 1 1 2 2 9 1 2 1 1 1 2 1 2 2 9 2 1 2 1 1 2 1 2 2 9 1 1 1 2 1 2 1 2 2 9 2 1 1 2 1 2 1 2 2 9 1 2 1 2 1 2 1 2 2 10 1 1 1 1 1 1 1 1 2 2 10 2 1 1 1 1 1 1 1 2 2 10 1 2 1 1 1 1 1 1 2 2 10 1 1 2 1 1 1 1 1 2 2 10 2 1 2 1 1 1 1 1 2 2 9 1 1 2 1 1 2 1 2 2 10 1 1 1 2 1 1 1 1 2 2 10 1 2 1 2 1 1 1 1 2 2 10 1 1 1 1 2 1 1 1 2 2 10 2 1 1 1 2 1 1 1 2 2 10 1 2 1 1 2 1 1 1 2 2 10 1 1 2 1 2 1 1 1 2 2 10 2 1 2 1 2 1 1 1 2 2 10 1 1 1 1 1 2 1 1 2 2 10 2 1 1 1 1 2 1 1 2 2 10 1 2 1 1 1 2 1 1 2 2 10 2 1 1 2 1 1 1 1 2 2 10 1 1 2 1 1 2 1 1 2 2 10 1 1 1 2 1 2 1 1 2 2 10 2 1 1 2 1 2 1 1 2 2 10 1 2 1 2 1 2 1 1 2 2 10 1 1 1 1 1 1 2 1 2 2 10 2 1 1 1 1 1 2 1 2 2 10 1 2 1 1 1 1 2 1 2 2 10 1 1 2 1 1 1 2 1 2 2 10 2 1 2 1 1 1 2 1 2 2 10 1 1 1 2 1 1 2 1 2 2 10 2 1 2 1 1 2 1 1 2 2 10 2 1 1 2 1 1 2 1 2 2 10 1 1 1 1 2 1 2 1 2 2 10 2 1 1 1 2 1 2 1 2 2 10 1 2 1 1 2 1 2 1 2 2 10 1 1 2 1 2 1 2 1 2 2 10 2 1 2 1 2 1 2 1 2 2 10 1 2 1 2 1 1 2 1 2 2 11 1 1 1 1 1 1 1 1 1 2 2 11 2 1 1 1 1 1 1 1 1 2 2 3 1 2 2 5 1 1 1 2 2 4 1 1 2 2 4 2 1 2 2 6 2 1 1 1 2 2 5 2 1 1 2 2 5 1 2 1 2 2 8 1 1 1 1 1 1 2 2 7 1 1 2 1 1 2 2 8 2 1 1 1 1 1 2 2 6 1 2 1 1 2 2 7 2 1 2 1 1 2 2 7 1 1 1 2 1 2 2 6 1 1 1 1 2 2 7 2 1 1 2 1 2 2 8 2 1 2 1 1 1 2 2 6 1 1 2 1 2 2 11 1 2 1 1 1 1 1 1 1 2 2 11 1 1 2 1 1 1 1 1 1 2 2 11 2 1 2 1 1 1 1 1 1 2 2 11 1 1 1 2 1 1 1 1 1 2 2 11 2 1 1 2 1 1 1 1 1 2 2 11 1 2 1 2 1 1 1 1 1 2 2 7 2 1 1 1 1 2 2 11 1 1 1 1 2 1 1 1 1 2 2 11 2 1 1 1 2 1 1 1 1 2 2 11 1 2 1 1 2 1 1 1 1 2 2 11 1 1 2 1 2 1 1 1 1 2 2 11 2 1 2 1 2 1 1 1 1 2 2 11 1 1 1 1 1 2 1 1 1 2 2 11 2 1 1 1 1 2 1 1 1 2 2 11 1 2 1 1 1 2 1 1 1 2 2 11 1 1 2 1 1 2 1 1 1 2 2 11 2 1 2 1 1 2 1 1 1 2 2 8 1 2 1 1 1 1 2 2 11 1 1 1 2 1 2 1 1 1 2 2 11 2 1 1 2 1 2 1 1 1 2 2 11 1 2 1 2 1 2 1 1 1 2 2 11 1 1 1 1 1 1 2 1 1 2 2 11 2 1 1 1 1 1 2 1 1 2 2 11 1 2 1 1 1 1 2 1 1 2 2 11 1 1 2 1 1 1 2 1 1 2 2 11 2 1 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 1 1 2 2 11 2 1 1 2 1 1 2 1 1 2 2 7 1 2 1 1 1 2 2 11 1 2 1 2 1 1 2 1 1 2 2 11 1 1 1 1 2 1 2 1 1 2 2 11 2 1 1 1 2 1 2 1 1 2 2 11 1 2 1 1 2 1 2 1 1 2 2 11 1 1 2 1 2 1 2 1 1 2 2 11 2 1 2 1 2 1 2 1 1 2 2 11 1 1 1 1 1 1 1 2 1 2 2 11 2 1 1 1 1 1 1 2 1 2 2 11 1 2 1 1 1 1 1 2 1 2 2 11 1 1 2 1 1 1 1 2 1 2 2 6 2 1 2 1 2 2 11 2 1 2 1 1 1 1 2 1 2 2 11 1 1 1 2 1 1 1 2 1 2 2 11 2 1 1 2 1 1 1 2 1 2 2 11 1 2 1 2 1 1 1 2 1 2 2 11 1 1 1 1 2 1 1 2 1 2 2 11 2 1 1 1 2 1 1 2 1 2 2 8 1 1 2 1 1 1 2 2 7 1 2 1 2 1 2 2 7 1 1 1 1 1 2 2 2 2 2 11 1 2 1 1 2 1 1 2 1 2 2");
static const Space constant_12 = literal_text("387 22 1 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 1 2 2 21 1 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 1 2 1 2 2 22 1 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 20 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 19 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 2 1 2 2 20 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 2 1 1 2 2 18 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 17 1 1 1 1 1 1 1 2 2 2 1 2 1 2 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 1 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 13 1 1 1 1 1 1 2 2 1 2 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 11 1 1 1 1 1 2 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 2 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 2 1 1 1 2 1 1 2 1 2 2 18 1 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 1 1 1 2 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 1 2 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 2 1 2 1 1 2 2 16 1 1 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 1 1 1 1 2 2 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 1 2 1 1 1 2 2 1 1 1 2 1 1 1 2 2 18 1 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 2 2 17 1 1 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 2 1 2 2 16 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 18 1 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 2 1 2 1 1 2 1 2 2 14 1 1 1 2 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 1 2 2 1 1 1 2 2 14 1 1 1 2 1 2 2 2 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 10 1 1 1 2 2 1 1 1 2 2 8 1 1 1 2 2 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 15 1 1 2 1 1 1 2 2 1 2 1 2 1 2 2 14 1 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 2 1 1 2 1 2 2 19 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 1 1 2 2 15 1 1 2 1 1 2 2 1 1 1 1 1 1 2 2 14 1 1 2 1 1 2 2 1 1 2 1 1 2 2 15 1 1 2 1 1 2 2 2 1 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 12 1 1 2 1 2 2 1 1 2 1 2 2 17 1 1 2 1 2 2 1 2 1 1 1 1 1 1 1 2 2 14 1 1 2 1 2 2 2 1 2 1 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 8 1 1 2 2 1 1 2 2 8 1 1 2 2 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 17 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 15 1 2 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 2 1 2 1 1 2 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 13 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 2 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 14 1 2 1 1 2 2 2 1 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 2 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 1 2 1 2 1 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 2 1 2 1 1 1 2 2 2 1 1 2 1 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 21 1 2 1 2 1 1 2 1 2 2 1 1 1 1 1 1 1 1 1 2 2 20 1 2 1 2 1 1 2 1 2 2 1 2 1 2 1 1 2 1 2 2 20 1 2 1 2 1 1 2 1 2 2 2 1 2 1 1 2 1 1 2 2 16 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 2 16 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 2 19 1 2 1 2 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 19 1 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 1 2 2 18 1 2 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 1 2 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 14 1 2 1 2 1 2 2 1 1 1 1 1 2 2 15 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 14 1 2 1 2 1 2 2 1 2 1 2 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 10 1 2 1 2 2 2 1 1 2 2 11 1 2 2 1 1 1 2 1 1 2 2 8 1 2 2 1 1 1 2 2 6 1 2 2 1 2 2 22 2 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 1 2 2 19 2 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 1 2 2 22 2 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 15 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 2 1 1 1 1 1 2 2 1 2 1 1 2 2 16 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 1 1 2 1 2 2 15 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 2 1 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 2 16 2 1 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 11 2 1 1 1 2 2 2 1 1 2 2 10 2 1 1 1 2 2 2 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 19 2 1 1 2 1 1 1 1 2 2 1 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 1 2 2 20 2 1 1 2 1 1 1 1 2 2 2 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 2 1 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 1 2 1 1 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 17 2 1 1 2 1 1 2 2 1 1 1 2 1 1 1 2 2 16 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 16 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 18 2 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 13 2 1 1 2 1 2 2 1 1 1 1 2 2 14 2 1 1 2 1 2 2 2 1 1 2 1 2 2 15 2 1 1 2 1 2 2 2 1 2 1 1 1 2 2 10 2 1 1 2 2 1 2 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 2 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 14 2 1 2 1 1 1 2 2 1 1 2 1 2 2 15 2 1 2 1 1 1 2 2 2 1 1 2 1 2 2 16 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 2 1 1 2 1 1 2 2 18 2 1 2 1 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 2 1 2 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 2 1 2 1 1 2 1 2 2 2 1 2 1 1 2 1 2 2 13 2 1 2 1 1 2 2 1 1 1 1 2 2 13 2 1 2 1 1 2 2 1 2 1 1 2 2 14 2 1 2 1 1 2 2 2 1 2 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 17 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 2 2 16 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 14 2 1 2 1 2 2 1 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 8 2 1 2 2 1 1 2 2 10 2 1 2 2 2 1 1 1 2 2 8 2 1 2 2 2 1 2 2");
static Space routine_0(Context& c);
static Space routine_124(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_66(Context& c, const Space& s0);
static Space routine_65(Context& c, const Space& s0);
static Space routine_101(Context& c, const Space& s0);
static Space routine_213(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_235(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_261(Context& c, const Path& p0, const Space& s0);
static Space routine_265(Context& c, const Path& p0, const Space& s0);
static Space routine_267(Context& c, const Path& p0, const Space& s0);
static Space routine_269(Context& c, const Path& p0, const Space& s0);
static Space routine_237(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_255(Context& c, const Path& p0, const Space& s0);
static Space routine_257(Context& c, const Path& p0, const Space& s0);
static Space routine_259(Context& c, const Path& p0, const Space& s0);
static Space routine_214(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_236(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_262(Context& c, const Path& p0, const Space& s0);
static Space routine_266(Context& c, const Path& p0, const Space& s0);
static Space routine_268(Context& c, const Path& p0, const Space& s0);
static Space routine_270(Context& c, const Path& p0, const Space& s0);
static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_256(Context& c, const Path& p0, const Space& s0);
static Space routine_258(Context& c, const Path& p0, const Space& s0);
static Space routine_260(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_64(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_82(Context& c, const Path& p0, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Space& s0);
static Space routine_157(Context& c, const Path& p0, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_125(Context& c, const Path& p0, const Space& s0);
static Space routine_127(Context& c, const Path& p0, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_156(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Space& s0);
static Space routine_217(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_139(Context& c, const Path& p0, const Space& s0);
static Space routine_141(Context& c, const Path& p0, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Space& s0);
static Space routine_218(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_183(Context& c, const Path& p0, const Space& s0);
static Space routine_199(Context& c, const Path& p0, const Space& s0);
static Space routine_201(Context& c, const Path& p0, const Space& s0);
static Space routine_227(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_203(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_175(Context& c, const Path& p0, const Space& s0);
static Space routine_177(Context& c, const Path& p0, const Space& s0);
static Space routine_179(Context& c, const Path& p0, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_184(Context& c, const Path& p0, const Space& s0);
static Space routine_200(Context& c, const Path& p0, const Space& s0);
static Space routine_202(Context& c, const Path& p0, const Space& s0);
static Space routine_204(Context& c, const Path& p0, const Space& s0);
static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Space& s0);
static Space routine_178(Context& c, const Path& p0, const Space& s0);
static Space routine_180(Context& c, const Path& p0, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_215(Context& c, const Path& p0, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Space& s0);
static Space routine_207(Context& c, const Path& p0, const Space& s0);
static Space routine_209(Context& c, const Path& p0, const Space& s0);
static Space routine_211(Context& c, const Path& p0, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_187(Context& c, const Path& p0, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Space& s0);
static Space routine_191(Context& c, const Path& p0, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_216(Context& c, const Path& p0, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Space& s0);
static Space routine_208(Context& c, const Path& p0, const Space& s0);
static Space routine_210(Context& c, const Path& p0, const Space& s0);
static Space routine_212(Context& c, const Path& p0, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Space& s0);
static Space routine_190(Context& c, const Path& p0, const Space& s0);
static Space routine_192(Context& c, const Path& p0, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_225(Context& c, const Path& p0, const Space& s0);
static Space routine_239(Context& c, const Path& p0, const Space& s0);
static Space routine_241(Context& c, const Path& p0, const Space& s0);
static Space routine_243(Context& c, const Path& p0, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_219(Context& c, const Path& p0, const Space& s0);
static Space routine_221(Context& c, const Path& p0, const Space& s0);
static Space routine_223(Context& c, const Path& p0, const Space& s0);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_226(Context& c, const Path& p0, const Space& s0);
static Space routine_240(Context& c, const Path& p0, const Space& s0);
static Space routine_242(Context& c, const Path& p0, const Space& s0);
static Space routine_244(Context& c, const Path& p0, const Space& s0);
static Space routine_198(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_220(Context& c, const Path& p0, const Space& s0);
static Space routine_222(Context& c, const Path& p0, const Space& s0);
static Space routine_224(Context& c, const Path& p0, const Space& s0);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Space& s0);
static Space routine_251(Context& c, const Path& p0, const Space& s0);
static Space routine_245(Context& c, const Path& p0, const Space& s0);
static Space routine_247(Context& c, const Path& p0, const Space& s0);
static Space routine_249(Context& c, const Path& p0, const Space& s0);
static Space routine_205(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_151(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_271(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_229(Context& c, const Path& p0, const Space& s0);
static Space routine_231(Context& c, const Path& p0, const Space& s0);
static Space routine_233(Context& c, const Path& p0, const Space& s0);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Space& s0);
static Space routine_252(Context& c, const Path& p0, const Space& s0);
static Space routine_246(Context& c, const Path& p0, const Space& s0);
static Space routine_248(Context& c, const Path& p0, const Space& s0);
static Space routine_250(Context& c, const Path& p0, const Space& s0);
static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_152(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_272(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_230(Context& c, const Path& p0, const Space& s0);
static Space routine_232(Context& c, const Path& p0, const Space& s0);
static Space routine_234(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Space& s0);
static Space routine_54(Context& c, const Space& s0);
static Space routine_30(Context& c, const Space& s0);
static Space routine_33(Context& c, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0);
static Space routine_0(Context& c) {
  Space v0_10;
  if (!constant_0.empty()) {
    const Space v1_4 = routine_1(c, constant_1, constant_2, constant_3);
    const Space v1_8 = routine_2(c, constant_4, constant_5, constant_3);
    const Space v1_9 = unite(v1_4,v1_8);
    v0_10 = compose(constant_0,v1_9);
  }
  Space v0_17;
  if (!constant_0.empty()) {
    const Space v2_13 = routine_3(c, constant_1, constant_2);
    const Space v2_15 = routine_4(c, constant_4, constant_5);
    const Space v2_16 = unite(v2_13,v2_15);
    v0_17 = compose(constant_0,v2_16);
  }
  Space v0_23_result;
  for (int v0_23_label = 1; v0_23_label <= 2; ++v0_23_label) {
    const Space v0_23_tail = child(v0_17,v0_23_label);
    if (v0_23_tail.empty()) continue;
    const Path v0_23_head{v0_23_label};
    const Space v3_2 = singleton(v0_23_head);
    const Space v3_3 = intersect(constant_6,v3_2);
    const Space v3_4 = (has_head(v3_3) ? constant_7 : Space{});
    const Space v3_5 = subtract(constant_0,v3_4);
    Space v3_7;
    if (!v3_5.empty()) {
      const Space v4_6 = routine_5(c, v0_23_head, v0_23_tail, constant_3);
      v3_7 = compose(v3_5,v4_6);
    }
    const Space v3_8 = intersect(constant_6,v3_2);
    const Space v3_9 = (has_head(v3_8) ? constant_7 : Space{});
    Space v3_11;
    if (!v3_9.empty()) {
      const Space v5_10 = routine_6(c, v0_23_head, v0_23_tail, constant_3);
      v3_11 = compose(v3_9,v5_10);
    }
    const Space v3_12 = unite(v3_7,v3_11);
    v0_23_result = unite(v0_23_result,v3_12);
  }
  const Space v0_23 = std::move(v0_23_result);
  const Space v0_24 = unite(v0_10,v0_23);
  const Space v0_26 = wrap(v0_24,constant_8);
  return v0_26;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v6_12_result;
  for (int v6_12_label = 1; v6_12_label <= 2; ++v6_12_label) {
    const Space v6_12_tail = child(s0,v6_12_label);
    if (v6_12_tail.empty()) continue;
    const Path v6_12_head{v6_12_label};
    const Space v7_2 = singleton(v6_12_head);
    const Space v7_3 = intersect(constant_6,v7_2);
    const Space v7_4 = (has_head(v7_3) ? constant_7 : Space{});
    const Space v7_5 = subtract(constant_0,v7_4);
    Space v7_8;
    if (!v7_5.empty()) {
      const Path v8_6 = concat_path(p0,v6_12_head);
      Space v8_7_result;
      for (int v8_7_label = 1; v8_7_label <= 2; ++v8_7_label) {
        const Space v8_7_tail = child(v6_12_tail,v8_7_label);
        if (v8_7_tail.empty()) continue;
        const Path v8_7_head{v8_7_label};
        const Space v9_2 = singleton(v8_7_head);
        const Space v9_3 = intersect(constant_6,v9_2);
        const Space v9_4 = (has_head(v9_3) ? constant_7 : Space{});
        const Space v9_5 = subtract(constant_0,v9_4);
        Space v9_8;
        if (!v9_5.empty()) {
          const Path v10_6 = concat_path(v8_6,v8_7_head);
          const Space v10_7 = routine_7(c, v10_6, v8_7_tail, s1);
          v9_8 = compose(v9_5,v10_7);
        }
        const Space v9_9 = intersect(constant_6,v9_2);
        const Space v9_10 = (has_head(v9_9) ? constant_7 : Space{});
        Space v9_12;
        if (!v9_10.empty()) {
          const Path v11_6 = concat_path(v8_6,v8_7_head);
          const Space v11_11 = routine_8(c, v11_6, v8_7_tail, s1);
          v9_12 = compose(v9_10,v11_11);
        }
        const Space v9_13 = unite(v9_8,v9_12);
        v8_7_result = unite(v8_7_result,v9_13);
      }
      const Space v8_7 = std::move(v8_7_result);
      v7_8 = compose(v7_5,v8_7);
    }
    const Space v7_9 = intersect(constant_6,v7_2);
    const Space v7_10 = (has_head(v7_9) ? constant_7 : Space{});
    Space v7_12;
    if (!v7_10.empty()) {
      const Path v12_6 = concat_path(p0,v6_12_head);
      Space v12_11_result;
      for (int v12_11_label = 1; v12_11_label <= 2; ++v12_11_label) {
        const Space v12_11_tail = child(v6_12_tail,v12_11_label);
        if (v12_11_tail.empty()) continue;
        const Path v12_11_head{v12_11_label};
        const Space v13_2 = singleton(v12_11_head);
        const Space v13_3 = intersect(constant_6,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_7 : Space{});
        const Space v13_5 = subtract(constant_0,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_11_head);
          const Space v14_7 = routine_7(c, v14_6, v12_11_tail, s1);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_6,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_7 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_11_head);
          const Space v15_11 = routine_9(c, v15_6, v12_11_tail, s1);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_11_result = unite(v12_11_result,v13_13);
      }
      const Space v12_11 = std::move(v12_11_result);
      v7_12 = compose(v7_10,v12_11);
    }
    const Space v7_13 = unite(v7_8,v7_12);
    v6_12_result = unite(v6_12_result,v7_13);
  }
  const Space v6_12 = std::move(v6_12_result);
  return v6_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v16_12_result;
  for (int v16_12_label = 1; v16_12_label <= 2; ++v16_12_label) {
    const Space v16_12_tail = child(s0,v16_12_label);
    if (v16_12_tail.empty()) continue;
    const Path v16_12_head{v16_12_label};
    const Space v17_2 = singleton(v16_12_head);
    const Space v17_3 = intersect(constant_6,v17_2);
    const Space v17_4 = (has_head(v17_3) ? constant_7 : Space{});
    const Space v17_5 = subtract(constant_0,v17_4);
    Space v17_8;
    if (!v17_5.empty()) {
      const Path v18_6 = concat_path(p0,v16_12_head);
      Space v18_7_result;
      for (int v18_7_label = 1; v18_7_label <= 2; ++v18_7_label) {
        const Space v18_7_tail = child(v16_12_tail,v18_7_label);
        if (v18_7_tail.empty()) continue;
        const Path v18_7_head{v18_7_label};
        const Space v19_2 = singleton(v18_7_head);
        const Space v19_3 = intersect(constant_6,v19_2);
        const Space v19_4 = (has_head(v19_3) ? constant_7 : Space{});
        const Space v19_5 = subtract(constant_0,v19_4);
        Space v19_8;
        if (!v19_5.empty()) {
          const Path v20_6 = concat_path(v18_6,v18_7_head);
          const Space v20_7 = routine_7(c, v20_6, v18_7_tail, s1);
          v19_8 = compose(v19_5,v20_7);
        }
        const Space v19_9 = intersect(constant_6,v19_2);
        const Space v19_10 = (has_head(v19_9) ? constant_7 : Space{});
        Space v19_12;
        if (!v19_10.empty()) {
          const Path v21_6 = concat_path(v18_6,v18_7_head);
          const Space v21_11 = routine_8(c, v21_6, v18_7_tail, s1);
          v19_12 = compose(v19_10,v21_11);
        }
        const Space v19_13 = unite(v19_8,v19_12);
        v18_7_result = unite(v18_7_result,v19_13);
      }
      const Space v18_7 = std::move(v18_7_result);
      v17_8 = compose(v17_5,v18_7);
    }
    const Space v17_9 = intersect(constant_6,v17_2);
    const Space v17_10 = (has_head(v17_9) ? constant_7 : Space{});
    Space v17_12;
    if (!v17_10.empty()) {
      const Path v22_6 = concat_path(p0,v16_12_head);
      Space v22_11_result;
      for (int v22_11_label = 1; v22_11_label <= 2; ++v22_11_label) {
        const Space v22_11_tail = child(v16_12_tail,v22_11_label);
        if (v22_11_tail.empty()) continue;
        const Path v22_11_head{v22_11_label};
        const Space v23_2 = singleton(v22_11_head);
        const Space v23_3 = intersect(constant_6,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_7 : Space{});
        const Space v23_5 = subtract(constant_0,v23_4);
        Space v23_7;
        if (!v23_5.empty()) {
          const Space v24_6 = routine_10(c, v22_11_head, v22_6, v22_11_tail, s1);
          v23_7 = compose(v23_5,v24_6);
        }
        const Space v23_8 = intersect(constant_6,v23_2);
        const Space v23_9 = (has_head(v23_8) ? constant_7 : Space{});
        Space v23_11;
        if (!v23_9.empty()) {
          const Space v25_10 = routine_11(c, v22_11_head, v22_6, v22_11_tail, s1);
          v23_11 = compose(v23_9,v25_10);
        }
        const Space v23_12 = unite(v23_7,v23_11);
        v22_11_result = unite(v22_11_result,v23_12);
      }
      const Space v22_11 = std::move(v22_11_result);
      v17_12 = compose(v17_10,v22_11);
    }
    const Space v17_13 = unite(v17_8,v17_12);
    v16_12_result = unite(v16_12_result,v17_13);
  }
  const Space v16_12 = std::move(v16_12_result);
  return v16_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v26_11_result;
  for (int v26_11_label = 1; v26_11_label <= 2; ++v26_11_label) {
    const Space v26_11_tail = child(s0,v26_11_label);
    if (v26_11_tail.empty()) continue;
    const Path v26_11_head{v26_11_label};
    const Space v27_2 = singleton(v26_11_head);
    const Space v27_3 = intersect(constant_6,v27_2);
    const Space v27_4 = (has_head(v27_3) ? constant_7 : Space{});
    const Space v27_5 = subtract(constant_0,v27_4);
    Space v27_8;
    if (!v27_5.empty()) {
      const Path v28_6 = concat_path(p0,v26_11_head);
      Space v28_7_result;
      for (int v28_7_label = 1; v28_7_label <= 2; ++v28_7_label) {
        const Space v28_7_tail = child(v26_11_tail,v28_7_label);
        if (v28_7_tail.empty()) continue;
        const Path v28_7_head{v28_7_label};
        const Space v29_2 = singleton(v28_7_head);
        const Space v29_3 = intersect(constant_6,v29_2);
        const Space v29_4 = (has_head(v29_3) ? constant_7 : Space{});
        const Space v29_5 = subtract(constant_0,v29_4);
        Space v29_8;
        if (!v29_5.empty()) {
          const Path v30_6 = concat_path(v28_6,v28_7_head);
          const Space v30_7 = routine_12(c, v30_6, v28_7_tail);
          v29_8 = compose(v29_5,v30_7);
        }
        const Space v29_9 = intersect(constant_6,v29_2);
        const Space v29_10 = (has_head(v29_9) ? constant_7 : Space{});
        Space v29_12;
        if (!v29_10.empty()) {
          const Path v31_6 = concat_path(v28_6,v28_7_head);
          const Space v31_11 = routine_13(c, v31_6, v28_7_tail);
          v29_12 = compose(v29_10,v31_11);
        }
        const Space v29_13 = unite(v29_8,v29_12);
        v28_7_result = unite(v28_7_result,v29_13);
      }
      const Space v28_7 = std::move(v28_7_result);
      v27_8 = compose(v27_5,v28_7);
    }
    const Space v27_9 = intersect(constant_6,v27_2);
    const Space v27_10 = (has_head(v27_9) ? constant_7 : Space{});
    Space v27_12;
    if (!v27_10.empty()) {
      const Path v32_6 = concat_path(p0,v26_11_head);
      Space v32_11_result;
      for (int v32_11_label = 1; v32_11_label <= 2; ++v32_11_label) {
        const Space v32_11_tail = child(v26_11_tail,v32_11_label);
        if (v32_11_tail.empty()) continue;
        const Path v32_11_head{v32_11_label};
        const Space v33_2 = singleton(v32_11_head);
        const Space v33_3 = intersect(constant_6,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_7 : Space{});
        const Space v33_5 = subtract(constant_0,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v32_6,v32_11_head);
          const Space v34_7 = routine_12(c, v34_6, v32_11_tail);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_6,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_7 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v32_6,v32_11_head);
          const Space v35_11 = routine_14(c, v35_6, v32_11_tail);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_11_result = unite(v32_11_result,v33_13);
      }
      const Space v32_11 = std::move(v32_11_result);
      v27_12 = compose(v27_10,v32_11);
    }
    const Space v27_13 = unite(v27_8,v27_12);
    v26_11_result = unite(v26_11_result,v27_13);
  }
  const Space v26_11 = std::move(v26_11_result);
  return v26_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v36_11_result;
  for (int v36_11_label = 1; v36_11_label <= 2; ++v36_11_label) {
    const Space v36_11_tail = child(s0,v36_11_label);
    if (v36_11_tail.empty()) continue;
    const Path v36_11_head{v36_11_label};
    const Space v37_2 = singleton(v36_11_head);
    const Space v37_3 = intersect(constant_6,v37_2);
    const Space v37_4 = (has_head(v37_3) ? constant_7 : Space{});
    const Space v37_5 = subtract(constant_0,v37_4);
    Space v37_8;
    if (!v37_5.empty()) {
      const Path v38_6 = concat_path(p0,v36_11_head);
      Space v38_7_result;
      for (int v38_7_label = 1; v38_7_label <= 2; ++v38_7_label) {
        const Space v38_7_tail = child(v36_11_tail,v38_7_label);
        if (v38_7_tail.empty()) continue;
        const Path v38_7_head{v38_7_label};
        const Space v39_2 = singleton(v38_7_head);
        const Space v39_3 = intersect(constant_6,v39_2);
        const Space v39_4 = (has_head(v39_3) ? constant_7 : Space{});
        const Space v39_5 = subtract(constant_0,v39_4);
        Space v39_8;
        if (!v39_5.empty()) {
          const Path v40_6 = concat_path(v38_6,v38_7_head);
          const Space v40_7 = routine_12(c, v40_6, v38_7_tail);
          v39_8 = compose(v39_5,v40_7);
        }
        const Space v39_9 = intersect(constant_6,v39_2);
        const Space v39_10 = (has_head(v39_9) ? constant_7 : Space{});
        Space v39_12;
        if (!v39_10.empty()) {
          const Path v41_6 = concat_path(v38_6,v38_7_head);
          const Space v41_11 = routine_13(c, v41_6, v38_7_tail);
          v39_12 = compose(v39_10,v41_11);
        }
        const Space v39_13 = unite(v39_8,v39_12);
        v38_7_result = unite(v38_7_result,v39_13);
      }
      const Space v38_7 = std::move(v38_7_result);
      v37_8 = compose(v37_5,v38_7);
    }
    const Space v37_9 = intersect(constant_6,v37_2);
    const Space v37_10 = (has_head(v37_9) ? constant_7 : Space{});
    Space v37_12;
    if (!v37_10.empty()) {
      const Path v42_6 = concat_path(p0,v36_11_head);
      Space v42_11_result;
      for (int v42_11_label = 1; v42_11_label <= 2; ++v42_11_label) {
        const Space v42_11_tail = child(v36_11_tail,v42_11_label);
        if (v42_11_tail.empty()) continue;
        const Path v42_11_head{v42_11_label};
        const Space v43_2 = singleton(v42_11_head);
        const Space v43_3 = intersect(constant_6,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_7 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_7;
        if (!v43_5.empty()) {
          const Space v44_6 = routine_15(c, v42_11_head, v42_6, v42_11_tail);
          v43_7 = compose(v43_5,v44_6);
        }
        const Space v43_8 = intersect(constant_6,v43_2);
        const Space v43_9 = (has_head(v43_8) ? constant_7 : Space{});
        Space v43_11;
        if (!v43_9.empty()) {
          const Space v45_10 = routine_16(c, v42_11_head, v42_6, v42_11_tail);
          v43_11 = compose(v43_9,v45_10);
        }
        const Space v43_12 = unite(v43_7,v43_11);
        v42_11_result = unite(v42_11_result,v43_12);
      }
      const Space v42_11 = std::move(v42_11_result);
      v37_12 = compose(v37_10,v42_11);
    }
    const Space v37_13 = unite(v37_8,v37_12);
    v36_11_result = unite(v36_11_result,v37_13);
  }
  const Space v36_11 = std::move(v36_11_result);
  return v36_11;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v46_12_result;
  for (int v46_12_label = 1; v46_12_label <= 2; ++v46_12_label) {
    const Space v46_12_tail = child(s0,v46_12_label);
    if (v46_12_tail.empty()) continue;
    const Path v46_12_head{v46_12_label};
    const Space v47_2 = singleton(v46_12_head);
    const Space v47_3 = intersect(constant_6,v47_2);
    const Space v47_4 = (has_head(v47_3) ? constant_7 : Space{});
    const Space v47_5 = subtract(constant_0,v47_4);
    Space v47_8;
    if (!v47_5.empty()) {
      const Path v48_6 = concat_path(p0,v46_12_head);
      Space v48_7_result;
      for (int v48_7_label = 1; v48_7_label <= 2; ++v48_7_label) {
        const Space v48_7_tail = child(v46_12_tail,v48_7_label);
        if (v48_7_tail.empty()) continue;
        const Path v48_7_head{v48_7_label};
        const Space v49_2 = singleton(v48_7_head);
        const Space v49_3 = intersect(constant_6,v49_2);
        const Space v49_4 = (has_head(v49_3) ? constant_7 : Space{});
        const Space v49_5 = subtract(constant_0,v49_4);
        Space v49_8;
        if (!v49_5.empty()) {
          const Path v50_6 = concat_path(v48_6,v48_7_head);
          const Space v50_7 = routine_17(c, v50_6, v48_7_tail, s1);
          v49_8 = compose(v49_5,v50_7);
        }
        const Space v49_9 = intersect(constant_6,v49_2);
        const Space v49_10 = (has_head(v49_9) ? constant_7 : Space{});
        Space v49_12;
        if (!v49_10.empty()) {
          const Path v51_6 = concat_path(v48_6,v48_7_head);
          const Space v51_11 = routine_18(c, v51_6, v48_7_tail, s1);
          v49_12 = compose(v49_10,v51_11);
        }
        const Space v49_13 = unite(v49_8,v49_12);
        v48_7_result = unite(v48_7_result,v49_13);
      }
      const Space v48_7 = std::move(v48_7_result);
      v47_8 = compose(v47_5,v48_7);
    }
    const Space v47_9 = intersect(constant_6,v47_2);
    const Space v47_10 = (has_head(v47_9) ? constant_7 : Space{});
    Space v47_12;
    if (!v47_10.empty()) {
      const Path v52_6 = concat_path(p0,v46_12_head);
      Space v52_11_result;
      for (int v52_11_label = 1; v52_11_label <= 2; ++v52_11_label) {
        const Space v52_11_tail = child(v46_12_tail,v52_11_label);
        if (v52_11_tail.empty()) continue;
        const Path v52_11_head{v52_11_label};
        const Space v53_2 = singleton(v52_11_head);
        const Space v53_3 = intersect(constant_6,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_7 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_11_head);
          const Space v54_7 = routine_17(c, v54_6, v52_11_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_6,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_7 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_11_head);
          const Space v55_11 = routine_19(c, v55_6, v52_11_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_11_result = unite(v52_11_result,v53_13);
      }
      const Space v52_11 = std::move(v52_11_result);
      v47_12 = compose(v47_10,v52_11);
    }
    const Space v47_13 = unite(v47_8,v47_12);
    v46_12_result = unite(v46_12_result,v47_13);
  }
  const Space v46_12 = std::move(v46_12_result);
  return v46_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v56_12_result;
  for (int v56_12_label = 1; v56_12_label <= 2; ++v56_12_label) {
    const Space v56_12_tail = child(s0,v56_12_label);
    if (v56_12_tail.empty()) continue;
    const Path v56_12_head{v56_12_label};
    const Space v57_2 = singleton(v56_12_head);
    const Space v57_3 = intersect(constant_6,v57_2);
    const Space v57_4 = (has_head(v57_3) ? constant_7 : Space{});
    const Space v57_5 = subtract(constant_0,v57_4);
    Space v57_8;
    if (!v57_5.empty()) {
      const Path v58_6 = concat_path(p0,v56_12_head);
      Space v58_7_result;
      for (int v58_7_label = 1; v58_7_label <= 2; ++v58_7_label) {
        const Space v58_7_tail = child(v56_12_tail,v58_7_label);
        if (v58_7_tail.empty()) continue;
        const Path v58_7_head{v58_7_label};
        const Space v59_2 = singleton(v58_7_head);
        const Space v59_3 = intersect(constant_6,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_7 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v58_6,v58_7_head);
          const Space v60_7 = routine_17(c, v60_6, v58_7_tail, s1);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_6,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_7 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v58_6,v58_7_head);
          const Space v61_11 = routine_18(c, v61_6, v58_7_tail, s1);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_7_result = unite(v58_7_result,v59_13);
      }
      const Space v58_7 = std::move(v58_7_result);
      v57_8 = compose(v57_5,v58_7);
    }
    const Space v57_9 = intersect(constant_6,v57_2);
    const Space v57_10 = (has_head(v57_9) ? constant_7 : Space{});
    Space v57_12;
    if (!v57_10.empty()) {
      const Path v62_6 = concat_path(p0,v56_12_head);
      Space v62_11_result;
      for (int v62_11_label = 1; v62_11_label <= 2; ++v62_11_label) {
        const Space v62_11_tail = child(v56_12_tail,v62_11_label);
        if (v62_11_tail.empty()) continue;
        const Path v62_11_head{v62_11_label};
        const Space v63_2 = singleton(v62_11_head);
        const Space v63_3 = intersect(constant_6,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_7 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_7;
        if (!v63_5.empty()) {
          const Space v64_6 = routine_20(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_7 = compose(v63_5,v64_6);
        }
        const Space v63_8 = intersect(constant_6,v63_2);
        const Space v63_9 = (has_head(v63_8) ? constant_7 : Space{});
        Space v63_11;
        if (!v63_9.empty()) {
          const Space v65_10 = routine_21(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_11 = compose(v63_9,v65_10);
        }
        const Space v63_12 = unite(v63_7,v63_11);
        v62_11_result = unite(v62_11_result,v63_12);
      }
      const Space v62_11 = std::move(v62_11_result);
      v57_12 = compose(v57_10,v62_11);
    }
    const Space v57_13 = unite(v57_8,v57_12);
    v56_12_result = unite(v56_12_result,v57_13);
  }
  const Space v56_12 = std::move(v56_12_result);
  return v56_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v66_12_result;
  for (int v66_12_label = 1; v66_12_label <= 2; ++v66_12_label) {
    const Space v66_12_tail = child(s0,v66_12_label);
    if (v66_12_tail.empty()) continue;
    const Path v66_12_head{v66_12_label};
    const Space v67_2 = singleton(v66_12_head);
    const Space v67_3 = intersect(constant_6,v67_2);
    const Space v67_4 = (has_head(v67_3) ? constant_7 : Space{});
    const Space v67_5 = subtract(constant_0,v67_4);
    Space v67_8;
    if (!v67_5.empty()) {
      const Path v68_6 = concat_path(p0,v66_12_head);
      Space v68_7_result;
      for (int v68_7_label = 1; v68_7_label <= 2; ++v68_7_label) {
        const Space v68_7_tail = child(v66_12_tail,v68_7_label);
        if (v68_7_tail.empty()) continue;
        const Path v68_7_head{v68_7_label};
        const Space v69_2 = singleton(v68_7_head);
        const Space v69_3 = intersect(constant_6,v69_2);
        const Space v69_4 = (has_head(v69_3) ? constant_7 : Space{});
        const Space v69_5 = subtract(constant_0,v69_4);
        Space v69_8;
        if (!v69_5.empty()) {
          const Path v70_6 = concat_path(v68_6,v68_7_head);
          const Space v70_7 = routine_22(c, v70_6, v68_7_tail, s1);
          v69_8 = compose(v69_5,v70_7);
        }
        const Space v69_9 = intersect(constant_6,v69_2);
        const Space v69_10 = (has_head(v69_9) ? constant_7 : Space{});
        Space v69_12;
        if (!v69_10.empty()) {
          const Path v71_6 = concat_path(v68_6,v68_7_head);
          const Space v71_11 = routine_23(c, v71_6, v68_7_tail, s1);
          v69_12 = compose(v69_10,v71_11);
        }
        const Space v69_13 = unite(v69_8,v69_12);
        v68_7_result = unite(v68_7_result,v69_13);
      }
      const Space v68_7 = std::move(v68_7_result);
      v67_8 = compose(v67_5,v68_7);
    }
    const Space v67_9 = intersect(constant_6,v67_2);
    const Space v67_10 = (has_head(v67_9) ? constant_7 : Space{});
    Space v67_12;
    if (!v67_10.empty()) {
      const Path v72_6 = concat_path(p0,v66_12_head);
      Space v72_11_result;
      for (int v72_11_label = 1; v72_11_label <= 2; ++v72_11_label) {
        const Space v72_11_tail = child(v66_12_tail,v72_11_label);
        if (v72_11_tail.empty()) continue;
        const Path v72_11_head{v72_11_label};
        const Space v73_2 = singleton(v72_11_head);
        const Space v73_3 = intersect(constant_6,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_7 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_11_head);
          const Space v74_7 = routine_22(c, v74_6, v72_11_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_6,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_7 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_11_head);
          const Space v75_11 = routine_9(c, v75_6, v72_11_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_11_result = unite(v72_11_result,v73_13);
      }
      const Space v72_11 = std::move(v72_11_result);
      v67_12 = compose(v67_10,v72_11);
    }
    const Space v67_13 = unite(v67_8,v67_12);
    v66_12_result = unite(v66_12_result,v67_13);
  }
  const Space v66_12 = std::move(v66_12_result);
  return v66_12;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v76_12_result;
  for (int v76_12_label = 1; v76_12_label <= 2; ++v76_12_label) {
    const Space v76_12_tail = child(s0,v76_12_label);
    if (v76_12_tail.empty()) continue;
    const Path v76_12_head{v76_12_label};
    const Space v77_2 = singleton(v76_12_head);
    const Space v77_3 = intersect(constant_6,v77_2);
    const Space v77_4 = (has_head(v77_3) ? constant_7 : Space{});
    const Space v77_5 = subtract(constant_0,v77_4);
    Space v77_8;
    if (!v77_5.empty()) {
      const Path v78_6 = concat_path(p0,v76_12_head);
      Space v78_7_result;
      for (int v78_7_label = 1; v78_7_label <= 2; ++v78_7_label) {
        const Space v78_7_tail = child(v76_12_tail,v78_7_label);
        if (v78_7_tail.empty()) continue;
        const Path v78_7_head{v78_7_label};
        const Space v79_2 = singleton(v78_7_head);
        const Space v79_3 = intersect(constant_6,v79_2);
        const Space v79_4 = (has_head(v79_3) ? constant_7 : Space{});
        const Space v79_5 = subtract(constant_0,v79_4);
        Space v79_8;
        if (!v79_5.empty()) {
          const Path v80_6 = concat_path(v78_6,v78_7_head);
          const Space v80_7 = routine_22(c, v80_6, v78_7_tail, s1);
          v79_8 = compose(v79_5,v80_7);
        }
        const Space v79_9 = intersect(constant_6,v79_2);
        const Space v79_10 = (has_head(v79_9) ? constant_7 : Space{});
        Space v79_12;
        if (!v79_10.empty()) {
          const Path v81_6 = concat_path(v78_6,v78_7_head);
          const Space v81_11 = routine_23(c, v81_6, v78_7_tail, s1);
          v79_12 = compose(v79_10,v81_11);
        }
        const Space v79_13 = unite(v79_8,v79_12);
        v78_7_result = unite(v78_7_result,v79_13);
      }
      const Space v78_7 = std::move(v78_7_result);
      v77_8 = compose(v77_5,v78_7);
    }
    const Space v77_9 = intersect(constant_6,v77_2);
    const Space v77_10 = (has_head(v77_9) ? constant_7 : Space{});
    Space v77_12;
    if (!v77_10.empty()) {
      const Path v82_6 = concat_path(p0,v76_12_head);
      Space v82_11_result;
      for (int v82_11_label = 1; v82_11_label <= 2; ++v82_11_label) {
        const Space v82_11_tail = child(v76_12_tail,v82_11_label);
        if (v82_11_tail.empty()) continue;
        const Path v82_11_head{v82_11_label};
        const Space v83_2 = singleton(v82_11_head);
        const Space v83_3 = intersect(constant_6,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_7 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_7;
        if (!v83_5.empty()) {
          const Space v84_6 = routine_10(c, v82_11_head, v82_6, v82_11_tail, s1);
          v83_7 = compose(v83_5,v84_6);
        }
        const Space v83_8 = intersect(constant_6,v83_2);
        const Space v83_9 = (has_head(v83_8) ? constant_7 : Space{});
        Space v83_11;
        if (!v83_9.empty()) {
          const Space v85_10 = routine_11(c, v82_11_head, v82_6, v82_11_tail, s1);
          v83_11 = compose(v83_9,v85_10);
        }
        const Space v83_12 = unite(v83_7,v83_11);
        v82_11_result = unite(v82_11_result,v83_12);
      }
      const Space v82_11 = std::move(v82_11_result);
      v77_12 = compose(v77_10,v82_11);
    }
    const Space v77_13 = unite(v77_8,v77_12);
    v76_12_result = unite(v76_12_result,v77_13);
  }
  const Space v76_12 = std::move(v76_12_result);
  return v76_12;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v86_12_result;
  for (int v86_12_label = 1; v86_12_label <= 2; ++v86_12_label) {
    const Space v86_12_tail = child(s0,v86_12_label);
    if (v86_12_tail.empty()) continue;
    const Path v86_12_head{v86_12_label};
    const Space v87_2 = singleton(v86_12_head);
    const Space v87_3 = intersect(constant_6,v87_2);
    const Space v87_4 = (has_head(v87_3) ? constant_7 : Space{});
    const Space v87_5 = subtract(constant_0,v87_4);
    Space v87_7;
    if (!v87_5.empty()) {
      Space v88_6_result;
      for (int v88_6_label = 1; v88_6_label <= 2; ++v88_6_label) {
        const Space v88_6_tail = child(v86_12_tail,v88_6_label);
        if (v88_6_tail.empty()) continue;
        const Path v88_6_head{v88_6_label};
        const Space v89_2 = singleton(v88_6_head);
        const Space v89_3 = intersect(constant_6,v89_2);
        const Space v89_4 = (has_head(v89_3) ? constant_7 : Space{});
        const Space v89_5 = subtract(constant_0,v89_4);
        Space v89_8;
        if (!v89_5.empty()) {
          const Path v90_6 = concat_path(v86_12_head,v88_6_head);
          const Space v90_7 = routine_24(c, v90_6, p0, v88_6_tail, s1);
          v89_8 = compose(v89_5,v90_7);
        }
        const Space v89_9 = intersect(constant_6,v89_2);
        const Space v89_10 = (has_head(v89_9) ? constant_7 : Space{});
        Space v89_12;
        if (!v89_10.empty()) {
          const Path v91_6 = concat_path(v86_12_head,v88_6_head);
          const Space v91_11 = routine_25(c, v91_6, p0, v88_6_tail, s1);
          v89_12 = compose(v89_10,v91_11);
        }
        const Space v89_13 = unite(v89_8,v89_12);
        v88_6_result = unite(v88_6_result,v89_13);
      }
      const Space v88_6 = std::move(v88_6_result);
      v87_7 = compose(v87_5,v88_6);
    }
    const Space v87_8 = intersect(constant_6,v87_2);
    const Space v87_9 = (has_head(v87_8) ? constant_7 : Space{});
    Space v87_11;
    if (!v87_9.empty()) {
      Space v92_10_result;
      for (int v92_10_label = 1; v92_10_label <= 2; ++v92_10_label) {
        const Space v92_10_tail = child(v86_12_tail,v92_10_label);
        if (v92_10_tail.empty()) continue;
        const Path v92_10_head{v92_10_label};
        const Space v93_2 = singleton(v92_10_head);
        const Space v93_3 = intersect(constant_6,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_7 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v86_12_head,v92_10_head);
          const Space v94_7 = routine_24(c, v94_6, p0, v92_10_tail, s1);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_6,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_7 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v86_12_head,v92_10_head);
          const Space v95_11 = routine_26(c, v95_6, p0, v92_10_tail, s1);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_10_result = unite(v92_10_result,v93_13);
      }
      const Space v92_10 = std::move(v92_10_result);
      v87_11 = compose(v87_9,v92_10);
    }
    const Space v87_12 = unite(v87_7,v87_11);
    v86_12_result = unite(v86_12_result,v87_12);
  }
  const Space v86_12 = std::move(v86_12_result);
  return v86_12;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v96_13_result;
  for (int v96_13_label = 1; v96_13_label <= 2; ++v96_13_label) {
    const Space v96_13_tail = child(s0,v96_13_label);
    if (v96_13_tail.empty()) continue;
    const Path v96_13_head{v96_13_label};
    const Space v97_2 = singleton(v96_13_head);
    const Space v97_3 = intersect(constant_6,v97_2);
    const Space v97_4 = (has_head(v97_3) ? constant_7 : Space{});
    const Space v97_5 = subtract(constant_0,v97_4);
    Space v97_8;
    if (!v97_5.empty()) {
      const Path v98_6 = concat_path(p0,v96_13_head);
      Space v98_7_result;
      for (int v98_7_label = 1; v98_7_label <= 2; ++v98_7_label) {
        const Space v98_7_tail = child(v96_13_tail,v98_7_label);
        if (v98_7_tail.empty()) continue;
        const Path v98_7_head{v98_7_label};
        const Space v99_2 = singleton(v98_7_head);
        const Space v99_3 = intersect(constant_6,v99_2);
        const Space v99_4 = (has_head(v99_3) ? constant_7 : Space{});
        const Space v99_5 = subtract(constant_0,v99_4);
        Space v99_8;
        if (!v99_5.empty()) {
          const Path v100_6 = concat_path(v98_6,v98_7_head);
          const Space v100_7 = routine_27(c, v100_6, p1, v98_7_tail, s1);
          v99_8 = compose(v99_5,v100_7);
        }
        const Space v99_9 = intersect(constant_6,v99_2);
        const Space v99_10 = (has_head(v99_9) ? constant_7 : Space{});
        Space v99_12;
        if (!v99_10.empty()) {
          const Path v101_6 = concat_path(v98_6,v98_7_head);
          const Space v101_11 = routine_28(c, v101_6, p1, v98_7_tail, s1);
          v99_12 = compose(v99_10,v101_11);
        }
        const Space v99_13 = unite(v99_8,v99_12);
        v98_7_result = unite(v98_7_result,v99_13);
      }
      const Space v98_7 = std::move(v98_7_result);
      v97_8 = compose(v97_5,v98_7);
    }
    const Space v97_9 = intersect(constant_6,v97_2);
    const Space v97_10 = (has_head(v97_9) ? constant_7 : Space{});
    Space v97_12;
    if (!v97_10.empty()) {
      const Path v102_6 = concat_path(p0,v96_13_head);
      Space v102_11_result;
      for (int v102_11_label = 1; v102_11_label <= 2; ++v102_11_label) {
        const Space v102_11_tail = child(v96_13_tail,v102_11_label);
        if (v102_11_tail.empty()) continue;
        const Path v102_11_head{v102_11_label};
        const Space v103_2 = singleton(v102_11_head);
        const Space v103_3 = intersect(constant_6,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_7 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_11_head);
          const Space v104_7 = routine_27(c, v104_6, p1, v102_11_tail, s1);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_6,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_7 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_11_head);
          const Space v105_11 = routine_26(c, v105_6, p1, v102_11_tail, s1);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_11_result = unite(v102_11_result,v103_13);
      }
      const Space v102_11 = std::move(v102_11_result);
      v97_12 = compose(v97_10,v102_11);
    }
    const Space v97_13 = unite(v97_8,v97_12);
    v96_13_result = unite(v96_13_result,v97_13);
  }
  const Space v96_13 = std::move(v96_13_result);
  return v96_13;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v106_8 = unwrap(s1,constant_8);
  Space v106_21_result;
  for (int v106_21_label = 1; v106_21_label <= 2; ++v106_21_label) {
    const Space v106_21_tail = child(s0,v106_21_label);
    if (v106_21_tail.empty()) continue;
    const Path v106_21_head{v106_21_label};
    const Space v107_2 = singleton(v106_21_head);
    const Space v107_3 = intersect(constant_6,v107_2);
    const Space v107_4 = (has_head(v107_3) ? constant_7 : Space{});
    const Space v107_5 = subtract(constant_0,v107_4);
    Space v107_8;
    if (!v107_5.empty()) {
      const Path v108_6 = concat_path(p0,v106_21_head);
      Space v108_7_result;
      for (int v108_7_label = 1; v108_7_label <= 2; ++v108_7_label) {
        const Space v108_7_tail = child(v106_21_tail,v108_7_label);
        if (v108_7_tail.empty()) continue;
        const Path v108_7_head{v108_7_label};
        const Space v109_2 = singleton(v108_7_head);
        const Space v109_3 = intersect(constant_6,v109_2);
        const Space v109_4 = (has_head(v109_3) ? constant_7 : Space{});
        const Space v109_5 = subtract(constant_0,v109_4);
        Space v109_8;
        if (!v109_5.empty()) {
          const Path v110_6 = concat_path(v108_6,v108_7_head);
          const Space v110_7 = routine_27(c, v110_6, p1, v108_7_tail, s1);
          v109_8 = compose(v109_5,v110_7);
        }
        const Space v109_9 = intersect(constant_6,v109_2);
        const Space v109_10 = (has_head(v109_9) ? constant_7 : Space{});
        Space v109_12;
        if (!v109_10.empty()) {
          const Path v111_6 = concat_path(v108_6,v108_7_head);
          const Space v111_11 = routine_28(c, v111_6, p1, v108_7_tail, s1);
          v109_12 = compose(v109_10,v111_11);
        }
        const Space v109_13 = unite(v109_8,v109_12);
        v108_7_result = unite(v108_7_result,v109_13);
      }
      const Space v108_7 = std::move(v108_7_result);
      v107_8 = compose(v107_5,v108_7);
    }
    const Space v107_9 = intersect(constant_6,v107_2);
    const Space v107_10 = (has_head(v107_9) ? constant_7 : Space{});
    Space v107_22;
    if (!v107_10.empty()) {
      const Path v112_6 = concat_path(p0,v106_21_head);
      const Path v112_11 = concat_path(p1,v112_6);
      const Space v112_12 = routine_29(c, v112_11);
      const Space v112_13 = intersect(v106_8,v112_12);
      const Space v112_14 = routine_30(c, v112_13);
      Space v112_15_result;
      for (int v112_15_label = 1; v112_15_label <= 2; ++v112_15_label) {
        const Space v112_15_tail = child(v112_14,v112_15_label);
        if (v112_15_tail.empty()) continue;
        const Path v112_15_head{v112_15_label};
        const Space v113_2 = singleton(v112_15_head);
        const Space v113_3 = intersect(constant_6,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_7 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_7;
        if (!v113_5.empty()) {
          const Space v114_6 = routine_31(c, v112_15_head, v112_15_tail);
          v113_7 = compose(v113_5,v114_6);
        }
        const Space v113_8 = intersect(constant_6,v113_2);
        const Space v113_9 = (has_head(v113_8) ? constant_7 : Space{});
        Space v113_11;
        if (!v113_9.empty()) {
          const Space v115_10 = routine_32(c, v112_15_head, v112_15_tail);
          v113_11 = compose(v113_9,v115_10);
        }
        const Space v113_12 = unite(v113_7,v113_11);
        v112_15_result = unite(v112_15_result,v113_12);
      }
      const Space v112_15 = std::move(v112_15_result);
      const Space v112_16 = routine_33(c, v112_13);
      Space v112_17_result;
      for (int v112_17_label = 1; v112_17_label <= 2; ++v112_17_label) {
        const Space v112_17_tail = child(v112_16,v112_17_label);
        if (v112_17_tail.empty()) continue;
        const Path v112_17_head{v112_17_label};
        const Space v116_2 = singleton(v112_17_head);
        const Space v116_3 = intersect(constant_6,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_7 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_7;
        if (!v116_5.empty()) {
          const Space v117_6 = routine_34(c, v112_17_head, v112_17_tail);
          v116_7 = compose(v116_5,v117_6);
        }
        const Space v116_8 = intersect(constant_6,v116_2);
        const Space v116_9 = (has_head(v116_8) ? constant_7 : Space{});
        Space v116_11;
        if (!v116_9.empty()) {
          const Space v118_10 = routine_35(c, v112_17_head, v112_17_tail);
          v116_11 = compose(v116_9,v118_10);
        }
        const Space v116_12 = unite(v116_7,v116_11);
        v112_17_result = unite(v112_17_result,v116_12);
      }
      const Space v112_17 = std::move(v112_17_result);
      const Space v112_18 = subtract(v112_15,v112_17);
      const Space v112_19 = singleton(v112_11);
      const Space v112_20 = compose(v112_18,v112_19);
      Space v112_21_result;
      for (int v112_21_label = 1; v112_21_label <= 2; ++v112_21_label) {
        const Space v112_21_tail = child(v112_20,v112_21_label);
        if (v112_21_tail.empty()) continue;
        const Path v112_21_head{v112_21_label};
        const Space v119_2 = singleton(v112_21_head);
        const Space v119_3 = intersect(constant_6,v119_2);
        const Space v119_4 = (has_head(v119_3) ? constant_7 : Space{});
        const Space v119_5 = subtract(constant_0,v119_4);
        Space v119_7;
        if (!v119_5.empty()) {
          const Space v120_6 = routine_36(c, v112_21_head, v112_21_tail);
          v119_7 = compose(v119_5,v120_6);
        }
        const Space v119_8 = intersect(constant_6,v119_2);
        const Space v119_9 = (has_head(v119_8) ? constant_7 : Space{});
        Space v119_11;
        if (!v119_9.empty()) {
          const Space v121_10 = routine_37(c, v112_21_head, v112_21_tail);
          v119_11 = compose(v119_9,v121_10);
        }
        const Space v119_12 = unite(v119_7,v119_11);
        v112_21_result = unite(v112_21_result,v119_12);
      }
      const Space v112_21 = std::move(v112_21_result);
      v107_22 = compose(v107_10,v112_21);
    }
    const Space v107_23 = unite(v107_8,v107_22);
    v106_21_result = unite(v106_21_result,v107_23);
  }
  const Space v106_21 = std::move(v106_21_result);
  return v106_21;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v122_11_result;
  for (int v122_11_label = 1; v122_11_label <= 2; ++v122_11_label) {
    const Space v122_11_tail = child(s0,v122_11_label);
    if (v122_11_tail.empty()) continue;
    const Path v122_11_head{v122_11_label};
    const Space v123_2 = singleton(v122_11_head);
    const Space v123_3 = intersect(constant_6,v123_2);
    const Space v123_4 = (has_head(v123_3) ? constant_7 : Space{});
    const Space v123_5 = subtract(constant_0,v123_4);
    Space v123_8;
    if (!v123_5.empty()) {
      const Path v124_6 = concat_path(p0,v122_11_head);
      Space v124_7_result;
      for (int v124_7_label = 1; v124_7_label <= 2; ++v124_7_label) {
        const Space v124_7_tail = child(v122_11_tail,v124_7_label);
        if (v124_7_tail.empty()) continue;
        const Path v124_7_head{v124_7_label};
        const Space v125_2 = singleton(v124_7_head);
        const Space v125_3 = intersect(constant_6,v125_2);
        const Space v125_4 = (has_head(v125_3) ? constant_7 : Space{});
        const Space v125_5 = subtract(constant_0,v125_4);
        Space v125_8;
        if (!v125_5.empty()) {
          const Path v126_6 = concat_path(v124_6,v124_7_head);
          const Space v126_7 = routine_38(c, v126_6, v124_7_tail);
          v125_8 = compose(v125_5,v126_7);
        }
        const Space v125_9 = intersect(constant_6,v125_2);
        const Space v125_10 = (has_head(v125_9) ? constant_7 : Space{});
        Space v125_12;
        if (!v125_10.empty()) {
          const Path v127_6 = concat_path(v124_6,v124_7_head);
          const Space v127_11 = routine_39(c, v127_6, v124_7_tail);
          v125_12 = compose(v125_10,v127_11);
        }
        const Space v125_13 = unite(v125_8,v125_12);
        v124_7_result = unite(v124_7_result,v125_13);
      }
      const Space v124_7 = std::move(v124_7_result);
      v123_8 = compose(v123_5,v124_7);
    }
    const Space v123_9 = intersect(constant_6,v123_2);
    const Space v123_10 = (has_head(v123_9) ? constant_7 : Space{});
    Space v123_12;
    if (!v123_10.empty()) {
      const Path v128_6 = concat_path(p0,v122_11_head);
      Space v128_11_result;
      for (int v128_11_label = 1; v128_11_label <= 2; ++v128_11_label) {
        const Space v128_11_tail = child(v122_11_tail,v128_11_label);
        if (v128_11_tail.empty()) continue;
        const Path v128_11_head{v128_11_label};
        const Space v129_2 = singleton(v128_11_head);
        const Space v129_3 = intersect(constant_6,v129_2);
        const Space v129_4 = (has_head(v129_3) ? constant_7 : Space{});
        const Space v129_5 = subtract(constant_0,v129_4);
        Space v129_8;
        if (!v129_5.empty()) {
          const Path v130_6 = concat_path(v128_6,v128_11_head);
          const Space v130_7 = routine_38(c, v130_6, v128_11_tail);
          v129_8 = compose(v129_5,v130_7);
        }
        const Space v129_9 = intersect(constant_6,v129_2);
        const Space v129_10 = (has_head(v129_9) ? constant_7 : Space{});
        Space v129_12;
        if (!v129_10.empty()) {
          const Path v131_6 = concat_path(v128_6,v128_11_head);
          const Space v131_11 = routine_14(c, v131_6, v128_11_tail);
          v129_12 = compose(v129_10,v131_11);
        }
        const Space v129_13 = unite(v129_8,v129_12);
        v128_11_result = unite(v128_11_result,v129_13);
      }
      const Space v128_11 = std::move(v128_11_result);
      v123_12 = compose(v123_10,v128_11);
    }
    const Space v123_13 = unite(v123_8,v123_12);
    v122_11_result = unite(v122_11_result,v123_13);
  }
  const Space v122_11 = std::move(v122_11_result);
  return v122_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v132_11_result;
  for (int v132_11_label = 1; v132_11_label <= 2; ++v132_11_label) {
    const Space v132_11_tail = child(s0,v132_11_label);
    if (v132_11_tail.empty()) continue;
    const Path v132_11_head{v132_11_label};
    const Space v133_2 = singleton(v132_11_head);
    const Space v133_3 = intersect(constant_6,v133_2);
    const Space v133_4 = (has_head(v133_3) ? constant_7 : Space{});
    const Space v133_5 = subtract(constant_0,v133_4);
    Space v133_8;
    if (!v133_5.empty()) {
      const Path v134_6 = concat_path(p0,v132_11_head);
      Space v134_7_result;
      for (int v134_7_label = 1; v134_7_label <= 2; ++v134_7_label) {
        const Space v134_7_tail = child(v132_11_tail,v134_7_label);
        if (v134_7_tail.empty()) continue;
        const Path v134_7_head{v134_7_label};
        const Space v135_2 = singleton(v134_7_head);
        const Space v135_3 = intersect(constant_6,v135_2);
        const Space v135_4 = (has_head(v135_3) ? constant_7 : Space{});
        const Space v135_5 = subtract(constant_0,v135_4);
        Space v135_8;
        if (!v135_5.empty()) {
          const Path v136_6 = concat_path(v134_6,v134_7_head);
          const Space v136_7 = routine_38(c, v136_6, v134_7_tail);
          v135_8 = compose(v135_5,v136_7);
        }
        const Space v135_9 = intersect(constant_6,v135_2);
        const Space v135_10 = (has_head(v135_9) ? constant_7 : Space{});
        Space v135_12;
        if (!v135_10.empty()) {
          const Path v137_6 = concat_path(v134_6,v134_7_head);
          const Space v137_11 = routine_39(c, v137_6, v134_7_tail);
          v135_12 = compose(v135_10,v137_11);
        }
        const Space v135_13 = unite(v135_8,v135_12);
        v134_7_result = unite(v134_7_result,v135_13);
      }
      const Space v134_7 = std::move(v134_7_result);
      v133_8 = compose(v133_5,v134_7);
    }
    const Space v133_9 = intersect(constant_6,v133_2);
    const Space v133_10 = (has_head(v133_9) ? constant_7 : Space{});
    Space v133_12;
    if (!v133_10.empty()) {
      const Path v138_6 = concat_path(p0,v132_11_head);
      Space v138_11_result;
      for (int v138_11_label = 1; v138_11_label <= 2; ++v138_11_label) {
        const Space v138_11_tail = child(v132_11_tail,v138_11_label);
        if (v138_11_tail.empty()) continue;
        const Path v138_11_head{v138_11_label};
        const Space v139_2 = singleton(v138_11_head);
        const Space v139_3 = intersect(constant_6,v139_2);
        const Space v139_4 = (has_head(v139_3) ? constant_7 : Space{});
        const Space v139_5 = subtract(constant_0,v139_4);
        Space v139_7;
        if (!v139_5.empty()) {
          const Space v140_6 = routine_15(c, v138_11_head, v138_6, v138_11_tail);
          v139_7 = compose(v139_5,v140_6);
        }
        const Space v139_8 = intersect(constant_6,v139_2);
        const Space v139_9 = (has_head(v139_8) ? constant_7 : Space{});
        Space v139_11;
        if (!v139_9.empty()) {
          const Space v141_10 = routine_16(c, v138_11_head, v138_6, v138_11_tail);
          v139_11 = compose(v139_9,v141_10);
        }
        const Space v139_12 = unite(v139_7,v139_11);
        v138_11_result = unite(v138_11_result,v139_12);
      }
      const Space v138_11 = std::move(v138_11_result);
      v133_12 = compose(v133_10,v138_11);
    }
    const Space v133_13 = unite(v133_8,v133_12);
    v132_11_result = unite(v132_11_result,v133_13);
  }
  const Space v132_11 = std::move(v132_11_result);
  return v132_11;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  Space v142_11_result;
  for (int v142_11_label = 1; v142_11_label <= 2; ++v142_11_label) {
    const Space v142_11_tail = child(s0,v142_11_label);
    if (v142_11_tail.empty()) continue;
    const Path v142_11_head{v142_11_label};
    const Space v143_2 = singleton(v142_11_head);
    const Space v143_3 = intersect(constant_6,v143_2);
    const Space v143_4 = (has_head(v143_3) ? constant_7 : Space{});
    const Space v143_5 = subtract(constant_0,v143_4);
    Space v143_7;
    if (!v143_5.empty()) {
      Space v144_6_result;
      for (int v144_6_label = 1; v144_6_label <= 2; ++v144_6_label) {
        const Space v144_6_tail = child(v142_11_tail,v144_6_label);
        if (v144_6_tail.empty()) continue;
        const Path v144_6_head{v144_6_label};
        const Space v145_2 = singleton(v144_6_head);
        const Space v145_3 = intersect(constant_6,v145_2);
        const Space v145_4 = (has_head(v145_3) ? constant_7 : Space{});
        const Space v145_5 = subtract(constant_0,v145_4);
        Space v145_8;
        if (!v145_5.empty()) {
          const Path v146_6 = concat_path(v142_11_head,v144_6_head);
          const Space v146_7 = routine_40(c, v146_6, p0, v144_6_tail);
          v145_8 = compose(v145_5,v146_7);
        }
        const Space v145_9 = intersect(constant_6,v145_2);
        const Space v145_10 = (has_head(v145_9) ? constant_7 : Space{});
        Space v145_12;
        if (!v145_10.empty()) {
          const Path v147_6 = concat_path(v142_11_head,v144_6_head);
          const Space v147_11 = routine_41(c, v147_6, p0, v144_6_tail);
          v145_12 = compose(v145_10,v147_11);
        }
        const Space v145_13 = unite(v145_8,v145_12);
        v144_6_result = unite(v144_6_result,v145_13);
      }
      const Space v144_6 = std::move(v144_6_result);
      v143_7 = compose(v143_5,v144_6);
    }
    const Space v143_8 = intersect(constant_6,v143_2);
    const Space v143_9 = (has_head(v143_8) ? constant_7 : Space{});
    Space v143_11;
    if (!v143_9.empty()) {
      Space v148_10_result;
      for (int v148_10_label = 1; v148_10_label <= 2; ++v148_10_label) {
        const Space v148_10_tail = child(v142_11_tail,v148_10_label);
        if (v148_10_tail.empty()) continue;
        const Path v148_10_head{v148_10_label};
        const Space v149_2 = singleton(v148_10_head);
        const Space v149_3 = intersect(constant_6,v149_2);
        const Space v149_4 = (has_head(v149_3) ? constant_7 : Space{});
        const Space v149_5 = subtract(constant_0,v149_4);
        Space v149_8;
        if (!v149_5.empty()) {
          const Path v150_6 = concat_path(v142_11_head,v148_10_head);
          const Space v150_7 = routine_40(c, v150_6, p0, v148_10_tail);
          v149_8 = compose(v149_5,v150_7);
        }
        const Space v149_9 = intersect(constant_6,v149_2);
        const Space v149_10 = (has_head(v149_9) ? constant_7 : Space{});
        Space v149_12;
        if (!v149_10.empty()) {
          const Path v151_6 = concat_path(v142_11_head,v148_10_head);
          const Space v151_11 = routine_42(c, v151_6, p0, v148_10_tail);
          v149_12 = compose(v149_10,v151_11);
        }
        const Space v149_13 = unite(v149_8,v149_12);
        v148_10_result = unite(v148_10_result,v149_13);
      }
      const Space v148_10 = std::move(v148_10_result);
      v143_11 = compose(v143_9,v148_10);
    }
    const Space v143_12 = unite(v143_7,v143_11);
    v142_11_result = unite(v142_11_result,v143_12);
  }
  const Space v142_11 = std::move(v142_11_result);
  return v142_11;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v152_12_result;
  for (int v152_12_label = 1; v152_12_label <= 2; ++v152_12_label) {
    const Space v152_12_tail = child(s0,v152_12_label);
    if (v152_12_tail.empty()) continue;
    const Path v152_12_head{v152_12_label};
    const Space v153_2 = singleton(v152_12_head);
    const Space v153_3 = intersect(constant_6,v153_2);
    const Space v153_4 = (has_head(v153_3) ? constant_7 : Space{});
    const Space v153_5 = subtract(constant_0,v153_4);
    Space v153_8;
    if (!v153_5.empty()) {
      const Path v154_6 = concat_path(p0,v152_12_head);
      Space v154_7_result;
      for (int v154_7_label = 1; v154_7_label <= 2; ++v154_7_label) {
        const Space v154_7_tail = child(v152_12_tail,v154_7_label);
        if (v154_7_tail.empty()) continue;
        const Path v154_7_head{v154_7_label};
        const Space v155_2 = singleton(v154_7_head);
        const Space v155_3 = intersect(constant_6,v155_2);
        const Space v155_4 = (has_head(v155_3) ? constant_7 : Space{});
        const Space v155_5 = subtract(constant_0,v155_4);
        Space v155_8;
        if (!v155_5.empty()) {
          const Path v156_6 = concat_path(v154_6,v154_7_head);
          const Space v156_7 = routine_43(c, v156_6, p1, v154_7_tail);
          v155_8 = compose(v155_5,v156_7);
        }
        const Space v155_9 = intersect(constant_6,v155_2);
        const Space v155_10 = (has_head(v155_9) ? constant_7 : Space{});
        Space v155_12;
        if (!v155_10.empty()) {
          const Path v157_6 = concat_path(v154_6,v154_7_head);
          const Space v157_11 = routine_44(c, v157_6, p1, v154_7_tail);
          v155_12 = compose(v155_10,v157_11);
        }
        const Space v155_13 = unite(v155_8,v155_12);
        v154_7_result = unite(v154_7_result,v155_13);
      }
      const Space v154_7 = std::move(v154_7_result);
      v153_8 = compose(v153_5,v154_7);
    }
    const Space v153_9 = intersect(constant_6,v153_2);
    const Space v153_10 = (has_head(v153_9) ? constant_7 : Space{});
    Space v153_12;
    if (!v153_10.empty()) {
      const Path v158_6 = concat_path(p0,v152_12_head);
      Space v158_11_result;
      for (int v158_11_label = 1; v158_11_label <= 2; ++v158_11_label) {
        const Space v158_11_tail = child(v152_12_tail,v158_11_label);
        if (v158_11_tail.empty()) continue;
        const Path v158_11_head{v158_11_label};
        const Space v159_2 = singleton(v158_11_head);
        const Space v159_3 = intersect(constant_6,v159_2);
        const Space v159_4 = (has_head(v159_3) ? constant_7 : Space{});
        const Space v159_5 = subtract(constant_0,v159_4);
        Space v159_8;
        if (!v159_5.empty()) {
          const Path v160_6 = concat_path(v158_6,v158_11_head);
          const Space v160_7 = routine_43(c, v160_6, p1, v158_11_tail);
          v159_8 = compose(v159_5,v160_7);
        }
        const Space v159_9 = intersect(constant_6,v159_2);
        const Space v159_10 = (has_head(v159_9) ? constant_7 : Space{});
        Space v159_12;
        if (!v159_10.empty()) {
          const Path v161_6 = concat_path(v158_6,v158_11_head);
          const Space v161_11 = routine_42(c, v161_6, p1, v158_11_tail);
          v159_12 = compose(v159_10,v161_11);
        }
        const Space v159_13 = unite(v159_8,v159_12);
        v158_11_result = unite(v158_11_result,v159_13);
      }
      const Space v158_11 = std::move(v158_11_result);
      v153_12 = compose(v153_10,v158_11);
    }
    const Space v153_13 = unite(v153_8,v153_12);
    v152_12_result = unite(v152_12_result,v153_13);
  }
  const Space v152_12 = std::move(v152_12_result);
  return v152_12;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v162_9_result;
  for (int v162_9_label = 1; v162_9_label <= 2; ++v162_9_label) {
    const Space v162_9_tail = child(s0,v162_9_label);
    if (v162_9_tail.empty()) continue;
    const Path v162_9_head{v162_9_label};
    const Space v163_2 = singleton(v162_9_head);
    const Space v163_3 = intersect(constant_6,v163_2);
    const Space v163_4 = (has_head(v163_3) ? constant_7 : Space{});
    const Space v163_5 = subtract(constant_0,v163_4);
    Space v163_8;
    if (!v163_5.empty()) {
      const Path v164_6 = concat_path(p0,v162_9_head);
      Space v164_7_result;
      for (int v164_7_label = 1; v164_7_label <= 2; ++v164_7_label) {
        const Space v164_7_tail = child(v162_9_tail,v164_7_label);
        if (v164_7_tail.empty()) continue;
        const Path v164_7_head{v164_7_label};
        const Space v165_2 = singleton(v164_7_head);
        const Space v165_3 = intersect(constant_6,v165_2);
        const Space v165_4 = (has_head(v165_3) ? constant_7 : Space{});
        const Space v165_5 = subtract(constant_0,v165_4);
        Space v165_8;
        if (!v165_5.empty()) {
          const Path v166_6 = concat_path(v164_6,v164_7_head);
          const Space v166_7 = routine_43(c, v166_6, p1, v164_7_tail);
          v165_8 = compose(v165_5,v166_7);
        }
        const Space v165_9 = intersect(constant_6,v165_2);
        const Space v165_10 = (has_head(v165_9) ? constant_7 : Space{});
        Space v165_12;
        if (!v165_10.empty()) {
          const Path v167_6 = concat_path(v164_6,v164_7_head);
          const Space v167_11 = routine_44(c, v167_6, p1, v164_7_tail);
          v165_12 = compose(v165_10,v167_11);
        }
        const Space v165_13 = unite(v165_8,v165_12);
        v164_7_result = unite(v164_7_result,v165_13);
      }
      const Space v164_7 = std::move(v164_7_result);
      v163_8 = compose(v163_5,v164_7);
    }
    const Space v163_9 = intersect(constant_6,v163_2);
    const Space v163_10 = (has_head(v163_9) ? constant_7 : Space{});
    Space v163_13;
    if (!v163_10.empty()) {
      const Path v168_6 = concat_path(p0,v162_9_head);
      const Path v168_11 = concat_path(p1,v168_6);
      const Space v168_12 = routine_29(c, v168_11);
      v163_13 = compose(v163_10,v168_12);
    }
    const Space v163_14 = unite(v163_8,v163_13);
    v162_9_result = unite(v162_9_result,v163_14);
  }
  const Space v162_9 = std::move(v162_9_result);
  return v162_9;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v169_12_result;
  for (int v169_12_label = 1; v169_12_label <= 2; ++v169_12_label) {
    const Space v169_12_tail = child(s0,v169_12_label);
    if (v169_12_tail.empty()) continue;
    const Path v169_12_head{v169_12_label};
    const Space v170_2 = singleton(v169_12_head);
    const Space v170_3 = intersect(constant_6,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_7 : Space{});
    const Space v170_5 = subtract(constant_0,v170_4);
    Space v170_8;
    if (!v170_5.empty()) {
      const Path v171_6 = concat_path(p0,v169_12_head);
      Space v171_7_result;
      for (int v171_7_label = 1; v171_7_label <= 2; ++v171_7_label) {
        const Space v171_7_tail = child(v169_12_tail,v171_7_label);
        if (v171_7_tail.empty()) continue;
        const Path v171_7_head{v171_7_label};
        const Space v172_2 = singleton(v171_7_head);
        const Space v172_3 = intersect(constant_6,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_7 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v171_6,v171_7_head);
          const Space v173_7 = routine_45(c, v173_6, v171_7_tail, s1);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_6,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_7 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v171_6,v171_7_head);
          const Space v174_11 = routine_46(c, v174_6, v171_7_tail, s1);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_7_result = unite(v171_7_result,v172_13);
      }
      const Space v171_7 = std::move(v171_7_result);
      v170_8 = compose(v170_5,v171_7);
    }
    const Space v170_9 = intersect(constant_6,v170_2);
    const Space v170_10 = (has_head(v170_9) ? constant_7 : Space{});
    Space v170_12;
    if (!v170_10.empty()) {
      const Path v175_6 = concat_path(p0,v169_12_head);
      Space v175_11_result;
      for (int v175_11_label = 1; v175_11_label <= 2; ++v175_11_label) {
        const Space v175_11_tail = child(v169_12_tail,v175_11_label);
        if (v175_11_tail.empty()) continue;
        const Path v175_11_head{v175_11_label};
        const Space v176_2 = singleton(v175_11_head);
        const Space v176_3 = intersect(constant_6,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_7 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_11_head);
          const Space v177_7 = routine_45(c, v177_6, v175_11_tail, s1);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_6,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_7 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_11_head);
          const Space v178_11 = routine_19(c, v178_6, v175_11_tail, s1);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_11_result = unite(v175_11_result,v176_13);
      }
      const Space v175_11 = std::move(v175_11_result);
      v170_12 = compose(v170_10,v175_11);
    }
    const Space v170_13 = unite(v170_8,v170_12);
    v169_12_result = unite(v169_12_result,v170_13);
  }
  const Space v169_12 = std::move(v169_12_result);
  return v169_12;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v179_12_result;
  for (int v179_12_label = 1; v179_12_label <= 2; ++v179_12_label) {
    const Space v179_12_tail = child(s0,v179_12_label);
    if (v179_12_tail.empty()) continue;
    const Path v179_12_head{v179_12_label};
    const Space v180_2 = singleton(v179_12_head);
    const Space v180_3 = intersect(constant_6,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_7 : Space{});
    const Space v180_5 = subtract(constant_0,v180_4);
    Space v180_8;
    if (!v180_5.empty()) {
      const Path v181_6 = concat_path(p0,v179_12_head);
      Space v181_7_result;
      for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
        const Space v181_7_tail = child(v179_12_tail,v181_7_label);
        if (v181_7_tail.empty()) continue;
        const Path v181_7_head{v181_7_label};
        const Space v182_2 = singleton(v181_7_head);
        const Space v182_3 = intersect(constant_6,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_7 : Space{});
        const Space v182_5 = subtract(constant_0,v182_4);
        Space v182_8;
        if (!v182_5.empty()) {
          const Path v183_6 = concat_path(v181_6,v181_7_head);
          const Space v183_7 = routine_45(c, v183_6, v181_7_tail, s1);
          v182_8 = compose(v182_5,v183_7);
        }
        const Space v182_9 = intersect(constant_6,v182_2);
        const Space v182_10 = (has_head(v182_9) ? constant_7 : Space{});
        Space v182_12;
        if (!v182_10.empty()) {
          const Path v184_6 = concat_path(v181_6,v181_7_head);
          const Space v184_11 = routine_46(c, v184_6, v181_7_tail, s1);
          v182_12 = compose(v182_10,v184_11);
        }
        const Space v182_13 = unite(v182_8,v182_12);
        v181_7_result = unite(v181_7_result,v182_13);
      }
      const Space v181_7 = std::move(v181_7_result);
      v180_8 = compose(v180_5,v181_7);
    }
    const Space v180_9 = intersect(constant_6,v180_2);
    const Space v180_10 = (has_head(v180_9) ? constant_7 : Space{});
    Space v180_12;
    if (!v180_10.empty()) {
      const Path v185_6 = concat_path(p0,v179_12_head);
      Space v185_11_result;
      for (int v185_11_label = 1; v185_11_label <= 2; ++v185_11_label) {
        const Space v185_11_tail = child(v179_12_tail,v185_11_label);
        if (v185_11_tail.empty()) continue;
        const Path v185_11_head{v185_11_label};
        const Space v186_2 = singleton(v185_11_head);
        const Space v186_3 = intersect(constant_6,v186_2);
        const Space v186_4 = (has_head(v186_3) ? constant_7 : Space{});
        const Space v186_5 = subtract(constant_0,v186_4);
        Space v186_7;
        if (!v186_5.empty()) {
          const Space v187_6 = routine_20(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_7 = compose(v186_5,v187_6);
        }
        const Space v186_8 = intersect(constant_6,v186_2);
        const Space v186_9 = (has_head(v186_8) ? constant_7 : Space{});
        Space v186_11;
        if (!v186_9.empty()) {
          const Space v188_10 = routine_21(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_11 = compose(v186_9,v188_10);
        }
        const Space v186_12 = unite(v186_7,v186_11);
        v185_11_result = unite(v185_11_result,v186_12);
      }
      const Space v185_11 = std::move(v185_11_result);
      v180_12 = compose(v180_10,v185_11);
    }
    const Space v180_13 = unite(v180_8,v180_12);
    v179_12_result = unite(v179_12_result,v180_13);
  }
  const Space v179_12 = std::move(v179_12_result);
  return v179_12;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v189_12_result;
  for (int v189_12_label = 1; v189_12_label <= 2; ++v189_12_label) {
    const Space v189_12_tail = child(s0,v189_12_label);
    if (v189_12_tail.empty()) continue;
    const Path v189_12_head{v189_12_label};
    const Space v190_2 = singleton(v189_12_head);
    const Space v190_3 = intersect(constant_6,v190_2);
    const Space v190_4 = (has_head(v190_3) ? constant_7 : Space{});
    const Space v190_5 = subtract(constant_0,v190_4);
    Space v190_7;
    if (!v190_5.empty()) {
      Space v191_6_result;
      for (int v191_6_label = 1; v191_6_label <= 2; ++v191_6_label) {
        const Space v191_6_tail = child(v189_12_tail,v191_6_label);
        if (v191_6_tail.empty()) continue;
        const Path v191_6_head{v191_6_label};
        const Space v192_2 = singleton(v191_6_head);
        const Space v192_3 = intersect(constant_6,v192_2);
        const Space v192_4 = (has_head(v192_3) ? constant_7 : Space{});
        const Space v192_5 = subtract(constant_0,v192_4);
        Space v192_8;
        if (!v192_5.empty()) {
          const Path v193_6 = concat_path(v189_12_head,v191_6_head);
          const Space v193_7 = routine_47(c, v193_6, p0, v191_6_tail, s1);
          v192_8 = compose(v192_5,v193_7);
        }
        const Space v192_9 = intersect(constant_6,v192_2);
        const Space v192_10 = (has_head(v192_9) ? constant_7 : Space{});
        Space v192_12;
        if (!v192_10.empty()) {
          const Path v194_6 = concat_path(v189_12_head,v191_6_head);
          const Space v194_11 = routine_48(c, v194_6, p0, v191_6_tail, s1);
          v192_12 = compose(v192_10,v194_11);
        }
        const Space v192_13 = unite(v192_8,v192_12);
        v191_6_result = unite(v191_6_result,v192_13);
      }
      const Space v191_6 = std::move(v191_6_result);
      v190_7 = compose(v190_5,v191_6);
    }
    const Space v190_8 = intersect(constant_6,v190_2);
    const Space v190_9 = (has_head(v190_8) ? constant_7 : Space{});
    Space v190_11;
    if (!v190_9.empty()) {
      Space v195_10_result;
      for (int v195_10_label = 1; v195_10_label <= 2; ++v195_10_label) {
        const Space v195_10_tail = child(v189_12_tail,v195_10_label);
        if (v195_10_tail.empty()) continue;
        const Path v195_10_head{v195_10_label};
        const Space v196_2 = singleton(v195_10_head);
        const Space v196_3 = intersect(constant_6,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_7 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v189_12_head,v195_10_head);
          const Space v197_7 = routine_47(c, v197_6, p0, v195_10_tail, s1);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_6,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_7 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v189_12_head,v195_10_head);
          const Space v198_11 = routine_49(c, v198_6, p0, v195_10_tail, s1);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_10_result = unite(v195_10_result,v196_13);
      }
      const Space v195_10 = std::move(v195_10_result);
      v190_11 = compose(v190_9,v195_10);
    }
    const Space v190_12 = unite(v190_7,v190_11);
    v189_12_result = unite(v189_12_result,v190_12);
  }
  const Space v189_12 = std::move(v189_12_result);
  return v189_12;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v199_13_result;
  for (int v199_13_label = 1; v199_13_label <= 2; ++v199_13_label) {
    const Space v199_13_tail = child(s0,v199_13_label);
    if (v199_13_tail.empty()) continue;
    const Path v199_13_head{v199_13_label};
    const Space v200_2 = singleton(v199_13_head);
    const Space v200_3 = intersect(constant_6,v200_2);
    const Space v200_4 = (has_head(v200_3) ? constant_7 : Space{});
    const Space v200_5 = subtract(constant_0,v200_4);
    Space v200_8;
    if (!v200_5.empty()) {
      const Path v201_6 = concat_path(p0,v199_13_head);
      Space v201_7_result;
      for (int v201_7_label = 1; v201_7_label <= 2; ++v201_7_label) {
        const Space v201_7_tail = child(v199_13_tail,v201_7_label);
        if (v201_7_tail.empty()) continue;
        const Path v201_7_head{v201_7_label};
        const Space v202_2 = singleton(v201_7_head);
        const Space v202_3 = intersect(constant_6,v202_2);
        const Space v202_4 = (has_head(v202_3) ? constant_7 : Space{});
        const Space v202_5 = subtract(constant_0,v202_4);
        Space v202_8;
        if (!v202_5.empty()) {
          const Path v203_6 = concat_path(v201_6,v201_7_head);
          const Space v203_7 = routine_50(c, v203_6, p1, v201_7_tail, s1);
          v202_8 = compose(v202_5,v203_7);
        }
        const Space v202_9 = intersect(constant_6,v202_2);
        const Space v202_10 = (has_head(v202_9) ? constant_7 : Space{});
        Space v202_12;
        if (!v202_10.empty()) {
          const Path v204_6 = concat_path(v201_6,v201_7_head);
          const Space v204_11 = routine_51(c, v204_6, p1, v201_7_tail, s1);
          v202_12 = compose(v202_10,v204_11);
        }
        const Space v202_13 = unite(v202_8,v202_12);
        v201_7_result = unite(v201_7_result,v202_13);
      }
      const Space v201_7 = std::move(v201_7_result);
      v200_8 = compose(v200_5,v201_7);
    }
    const Space v200_9 = intersect(constant_6,v200_2);
    const Space v200_10 = (has_head(v200_9) ? constant_7 : Space{});
    Space v200_12;
    if (!v200_10.empty()) {
      const Path v205_6 = concat_path(p0,v199_13_head);
      Space v205_11_result;
      for (int v205_11_label = 1; v205_11_label <= 2; ++v205_11_label) {
        const Space v205_11_tail = child(v199_13_tail,v205_11_label);
        if (v205_11_tail.empty()) continue;
        const Path v205_11_head{v205_11_label};
        const Space v206_2 = singleton(v205_11_head);
        const Space v206_3 = intersect(constant_6,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_7 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_11_head);
          const Space v207_7 = routine_50(c, v207_6, p1, v205_11_tail, s1);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_6,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_7 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_11_head);
          const Space v208_11 = routine_49(c, v208_6, p1, v205_11_tail, s1);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_11_result = unite(v205_11_result,v206_13);
      }
      const Space v205_11 = std::move(v205_11_result);
      v200_12 = compose(v200_10,v205_11);
    }
    const Space v200_13 = unite(v200_8,v200_12);
    v199_13_result = unite(v199_13_result,v200_13);
  }
  const Space v199_13 = std::move(v199_13_result);
  return v199_13;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v209_8 = unwrap(s1,constant_8);
  Space v209_21_result;
  for (int v209_21_label = 1; v209_21_label <= 2; ++v209_21_label) {
    const Space v209_21_tail = child(s0,v209_21_label);
    if (v209_21_tail.empty()) continue;
    const Path v209_21_head{v209_21_label};
    const Space v210_2 = singleton(v209_21_head);
    const Space v210_3 = intersect(constant_6,v210_2);
    const Space v210_4 = (has_head(v210_3) ? constant_7 : Space{});
    const Space v210_5 = subtract(constant_0,v210_4);
    Space v210_8;
    if (!v210_5.empty()) {
      const Path v211_6 = concat_path(p0,v209_21_head);
      Space v211_7_result;
      for (int v211_7_label = 1; v211_7_label <= 2; ++v211_7_label) {
        const Space v211_7_tail = child(v209_21_tail,v211_7_label);
        if (v211_7_tail.empty()) continue;
        const Path v211_7_head{v211_7_label};
        const Space v212_2 = singleton(v211_7_head);
        const Space v212_3 = intersect(constant_6,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_7 : Space{});
        const Space v212_5 = subtract(constant_0,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_7_head);
          const Space v213_7 = routine_50(c, v213_6, p1, v211_7_tail, s1);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_6,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_7 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_7_head);
          const Space v214_11 = routine_51(c, v214_6, p1, v211_7_tail, s1);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_7_result = unite(v211_7_result,v212_13);
      }
      const Space v211_7 = std::move(v211_7_result);
      v210_8 = compose(v210_5,v211_7);
    }
    const Space v210_9 = intersect(constant_6,v210_2);
    const Space v210_10 = (has_head(v210_9) ? constant_7 : Space{});
    Space v210_22;
    if (!v210_10.empty()) {
      const Path v215_6 = concat_path(p0,v209_21_head);
      const Path v215_11 = concat_path(p1,v215_6);
      const Space v215_12 = routine_29(c, v215_11);
      const Space v215_13 = intersect(v209_8,v215_12);
      const Space v215_14 = routine_33(c, v215_13);
      Space v215_15_result;
      for (int v215_15_label = 1; v215_15_label <= 2; ++v215_15_label) {
        const Space v215_15_tail = child(v215_14,v215_15_label);
        if (v215_15_tail.empty()) continue;
        const Path v215_15_head{v215_15_label};
        const Space v216_2 = singleton(v215_15_head);
        const Space v216_3 = intersect(constant_6,v216_2);
        const Space v216_4 = (has_head(v216_3) ? constant_7 : Space{});
        const Space v216_5 = subtract(constant_0,v216_4);
        Space v216_7;
        if (!v216_5.empty()) {
          const Space v217_6 = routine_52(c, v215_15_head, v215_15_tail);
          v216_7 = compose(v216_5,v217_6);
        }
        const Space v216_8 = intersect(constant_6,v216_2);
        const Space v216_9 = (has_head(v216_8) ? constant_7 : Space{});
        Space v216_11;
        if (!v216_9.empty()) {
          const Space v218_10 = routine_53(c, v215_15_head, v215_15_tail);
          v216_11 = compose(v216_9,v218_10);
        }
        const Space v216_12 = unite(v216_7,v216_11);
        v215_15_result = unite(v215_15_result,v216_12);
      }
      const Space v215_15 = std::move(v215_15_result);
      const Space v215_16 = routine_54(c, v215_13);
      Space v215_17_result;
      for (int v215_17_label = 1; v215_17_label <= 2; ++v215_17_label) {
        const Space v215_17_tail = child(v215_16,v215_17_label);
        if (v215_17_tail.empty()) continue;
        const Path v215_17_head{v215_17_label};
        const Space v219_2 = singleton(v215_17_head);
        const Space v219_3 = intersect(constant_6,v219_2);
        const Space v219_4 = (has_head(v219_3) ? constant_7 : Space{});
        const Space v219_5 = subtract(constant_0,v219_4);
        Space v219_7;
        if (!v219_5.empty()) {
          const Space v220_6 = routine_55(c, v215_17_head, v215_17_tail);
          v219_7 = compose(v219_5,v220_6);
        }
        const Space v219_8 = intersect(constant_6,v219_2);
        const Space v219_9 = (has_head(v219_8) ? constant_7 : Space{});
        Space v219_11;
        if (!v219_9.empty()) {
          const Space v221_10 = routine_56(c, v215_17_head, v215_17_tail);
          v219_11 = compose(v219_9,v221_10);
        }
        const Space v219_12 = unite(v219_7,v219_11);
        v215_17_result = unite(v215_17_result,v219_12);
      }
      const Space v215_17 = std::move(v215_17_result);
      const Space v215_18 = subtract(v215_15,v215_17);
      const Space v215_19 = singleton(v215_11);
      const Space v215_20 = compose(v215_18,v215_19);
      Space v215_21_result;
      for (int v215_21_label = 1; v215_21_label <= 2; ++v215_21_label) {
        const Space v215_21_tail = child(v215_20,v215_21_label);
        if (v215_21_tail.empty()) continue;
        const Path v215_21_head{v215_21_label};
        const Space v222_2 = singleton(v215_21_head);
        const Space v222_3 = intersect(constant_6,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_7 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_57(c, v215_21_head, v215_21_tail);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_6,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_7 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_58(c, v215_21_head, v215_21_tail);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v215_21_result = unite(v215_21_result,v222_12);
      }
      const Space v215_21 = std::move(v215_21_result);
      v210_22 = compose(v210_10,v215_21);
    }
    const Space v210_23 = unite(v210_8,v210_22);
    v209_21_result = unite(v209_21_result,v210_23);
  }
  const Space v209_21 = std::move(v209_21_result);
  return v209_21;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v225_12_result;
  for (int v225_12_label = 1; v225_12_label <= 2; ++v225_12_label) {
    const Space v225_12_tail = child(s0,v225_12_label);
    if (v225_12_tail.empty()) continue;
    const Path v225_12_head{v225_12_label};
    const Space v226_2 = singleton(v225_12_head);
    const Space v226_3 = intersect(constant_6,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_7 : Space{});
    const Space v226_5 = subtract(constant_0,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_12_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_12_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_6,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_7 : Space{});
        const Space v228_5 = subtract(constant_0,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_59(c, v229_6, v227_7_tail, s1);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_6,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_7 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_60(c, v230_6, v227_7_tail, s1);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_6,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_7 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_12_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_12_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_6,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_7 : Space{});
        const Space v232_5 = subtract(constant_0,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_59(c, v233_6, v231_11_tail, s1);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_6,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_7 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_9(c, v234_6, v231_11_tail, s1);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_12_result = unite(v225_12_result,v226_13);
  }
  const Space v225_12 = std::move(v225_12_result);
  return v225_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v235_12_result;
  for (int v235_12_label = 1; v235_12_label <= 2; ++v235_12_label) {
    const Space v235_12_tail = child(s0,v235_12_label);
    if (v235_12_tail.empty()) continue;
    const Path v235_12_head{v235_12_label};
    const Space v236_2 = singleton(v235_12_head);
    const Space v236_3 = intersect(constant_6,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_7 : Space{});
    const Space v236_5 = subtract(constant_0,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_12_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_12_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_6,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_7 : Space{});
        const Space v238_5 = subtract(constant_0,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_59(c, v239_6, v237_7_tail, s1);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_6,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_7 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_60(c, v240_6, v237_7_tail, s1);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_6,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_7 : Space{});
    Space v236_12;
    if (!v236_10.empty()) {
      const Path v241_6 = concat_path(p0,v235_12_head);
      Space v241_11_result;
      for (int v241_11_label = 1; v241_11_label <= 2; ++v241_11_label) {
        const Space v241_11_tail = child(v235_12_tail,v241_11_label);
        if (v241_11_tail.empty()) continue;
        const Path v241_11_head{v241_11_label};
        const Space v242_2 = singleton(v241_11_head);
        const Space v242_3 = intersect(constant_6,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_7 : Space{});
        const Space v242_5 = subtract(constant_0,v242_4);
        Space v242_7;
        if (!v242_5.empty()) {
          const Space v243_6 = routine_10(c, v241_11_head, v241_6, v241_11_tail, s1);
          v242_7 = compose(v242_5,v243_6);
        }
        const Space v242_8 = intersect(constant_6,v242_2);
        const Space v242_9 = (has_head(v242_8) ? constant_7 : Space{});
        Space v242_11;
        if (!v242_9.empty()) {
          const Space v244_10 = routine_11(c, v241_11_head, v241_6, v241_11_tail, s1);
          v242_11 = compose(v242_9,v244_10);
        }
        const Space v242_12 = unite(v242_7,v242_11);
        v241_11_result = unite(v241_11_result,v242_12);
      }
      const Space v241_11 = std::move(v241_11_result);
      v236_12 = compose(v236_10,v241_11);
    }
    const Space v236_13 = unite(v236_8,v236_12);
    v235_12_result = unite(v235_12_result,v236_13);
  }
  const Space v235_12 = std::move(v235_12_result);
  return v235_12;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v245_13_result;
  for (int v245_13_label = 1; v245_13_label <= 2; ++v245_13_label) {
    const Space v245_13_tail = child(s0,v245_13_label);
    if (v245_13_tail.empty()) continue;
    const Path v245_13_head{v245_13_label};
    const Space v246_2 = singleton(v245_13_head);
    const Space v246_3 = intersect(constant_6,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_7 : Space{});
    const Space v246_5 = subtract(constant_0,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_13_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_13_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_6,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_7 : Space{});
        const Space v248_5 = subtract(constant_0,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_61(c, v249_6, p1, v247_7_tail, s1);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_6,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_7 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_62(c, v250_6, p1, v247_7_tail, s1);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_6,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_7 : Space{});
    Space v246_12;
    if (!v246_10.empty()) {
      const Path v251_6 = concat_path(p0,v245_13_head);
      Space v251_11_result;
      for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
        const Space v251_11_tail = child(v245_13_tail,v251_11_label);
        if (v251_11_tail.empty()) continue;
        const Path v251_11_head{v251_11_label};
        const Space v252_2 = singleton(v251_11_head);
        const Space v252_3 = intersect(constant_6,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_7 : Space{});
        const Space v252_5 = subtract(constant_0,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_11_head);
          const Space v253_7 = routine_61(c, v253_6, p1, v251_11_tail, s1);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_6,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_7 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_11_head);
          const Space v254_11 = routine_26(c, v254_6, p1, v251_11_tail, s1);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_11_result = unite(v251_11_result,v252_13);
      }
      const Space v251_11 = std::move(v251_11_result);
      v246_12 = compose(v246_10,v251_11);
    }
    const Space v246_13 = unite(v246_8,v246_12);
    v245_13_result = unite(v245_13_result,v246_13);
  }
  const Space v245_13 = std::move(v245_13_result);
  return v245_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v255_8 = unwrap(s1,constant_8);
  Space v255_21_result;
  for (int v255_21_label = 1; v255_21_label <= 2; ++v255_21_label) {
    const Space v255_21_tail = child(s0,v255_21_label);
    if (v255_21_tail.empty()) continue;
    const Path v255_21_head{v255_21_label};
    const Space v256_2 = singleton(v255_21_head);
    const Space v256_3 = intersect(constant_6,v256_2);
    const Space v256_4 = (has_head(v256_3) ? constant_7 : Space{});
    const Space v256_5 = subtract(constant_0,v256_4);
    Space v256_8;
    if (!v256_5.empty()) {
      const Path v257_6 = concat_path(p0,v255_21_head);
      Space v257_7_result;
      for (int v257_7_label = 1; v257_7_label <= 2; ++v257_7_label) {
        const Space v257_7_tail = child(v255_21_tail,v257_7_label);
        if (v257_7_tail.empty()) continue;
        const Path v257_7_head{v257_7_label};
        const Space v258_2 = singleton(v257_7_head);
        const Space v258_3 = intersect(constant_6,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_7 : Space{});
        const Space v258_5 = subtract(constant_0,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_7_head);
          const Space v259_7 = routine_61(c, v259_6, p1, v257_7_tail, s1);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_6,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_7 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_7_head);
          const Space v260_11 = routine_62(c, v260_6, p1, v257_7_tail, s1);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_7_result = unite(v257_7_result,v258_13);
      }
      const Space v257_7 = std::move(v257_7_result);
      v256_8 = compose(v256_5,v257_7);
    }
    const Space v256_9 = intersect(constant_6,v256_2);
    const Space v256_10 = (has_head(v256_9) ? constant_7 : Space{});
    Space v256_22;
    if (!v256_10.empty()) {
      const Path v261_6 = concat_path(p0,v255_21_head);
      const Path v261_11 = concat_path(p1,v261_6);
      const Space v261_12 = routine_29(c, v261_11);
      const Space v261_13 = intersect(v255_8,v261_12);
      const Space v261_14 = routine_30(c, v261_13);
      Space v261_15_result;
      for (int v261_15_label = 1; v261_15_label <= 2; ++v261_15_label) {
        const Space v261_15_tail = child(v261_14,v261_15_label);
        if (v261_15_tail.empty()) continue;
        const Path v261_15_head{v261_15_label};
        const Space v262_2 = singleton(v261_15_head);
        const Space v262_3 = intersect(constant_6,v262_2);
        const Space v262_4 = (has_head(v262_3) ? constant_7 : Space{});
        const Space v262_5 = subtract(constant_0,v262_4);
        Space v262_7;
        if (!v262_5.empty()) {
          const Space v263_6 = routine_31(c, v261_15_head, v261_15_tail);
          v262_7 = compose(v262_5,v263_6);
        }
        const Space v262_8 = intersect(constant_6,v262_2);
        const Space v262_9 = (has_head(v262_8) ? constant_7 : Space{});
        Space v262_11;
        if (!v262_9.empty()) {
          const Space v264_10 = routine_32(c, v261_15_head, v261_15_tail);
          v262_11 = compose(v262_9,v264_10);
        }
        const Space v262_12 = unite(v262_7,v262_11);
        v261_15_result = unite(v261_15_result,v262_12);
      }
      const Space v261_15 = std::move(v261_15_result);
      const Space v261_16 = routine_33(c, v261_13);
      Space v261_17_result;
      for (int v261_17_label = 1; v261_17_label <= 2; ++v261_17_label) {
        const Space v261_17_tail = child(v261_16,v261_17_label);
        if (v261_17_tail.empty()) continue;
        const Path v261_17_head{v261_17_label};
        const Space v265_2 = singleton(v261_17_head);
        const Space v265_3 = intersect(constant_6,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_7 : Space{});
        const Space v265_5 = subtract(constant_0,v265_4);
        Space v265_7;
        if (!v265_5.empty()) {
          const Space v266_6 = routine_34(c, v261_17_head, v261_17_tail);
          v265_7 = compose(v265_5,v266_6);
        }
        const Space v265_8 = intersect(constant_6,v265_2);
        const Space v265_9 = (has_head(v265_8) ? constant_7 : Space{});
        Space v265_11;
        if (!v265_9.empty()) {
          const Space v267_10 = routine_35(c, v261_17_head, v261_17_tail);
          v265_11 = compose(v265_9,v267_10);
        }
        const Space v265_12 = unite(v265_7,v265_11);
        v261_17_result = unite(v261_17_result,v265_12);
      }
      const Space v261_17 = std::move(v261_17_result);
      const Space v261_18 = subtract(v261_15,v261_17);
      const Space v261_19 = singleton(v261_11);
      const Space v261_20 = compose(v261_18,v261_19);
      Space v261_21_result;
      for (int v261_21_label = 1; v261_21_label <= 2; ++v261_21_label) {
        const Space v261_21_tail = child(v261_20,v261_21_label);
        if (v261_21_tail.empty()) continue;
        const Path v261_21_head{v261_21_label};
        const Space v268_2 = singleton(v261_21_head);
        const Space v268_3 = intersect(constant_6,v268_2);
        const Space v268_4 = (has_head(v268_3) ? constant_7 : Space{});
        const Space v268_5 = subtract(constant_0,v268_4);
        Space v268_7;
        if (!v268_5.empty()) {
          const Space v269_6 = routine_36(c, v261_21_head, v261_21_tail);
          v268_7 = compose(v268_5,v269_6);
        }
        const Space v268_8 = intersect(constant_6,v268_2);
        const Space v268_9 = (has_head(v268_8) ? constant_7 : Space{});
        Space v268_11;
        if (!v268_9.empty()) {
          const Space v270_10 = routine_37(c, v261_21_head, v261_21_tail);
          v268_11 = compose(v268_9,v270_10);
        }
        const Space v268_12 = unite(v268_7,v268_11);
        v261_21_result = unite(v261_21_result,v268_12);
      }
      const Space v261_21 = std::move(v261_21_result);
      v256_22 = compose(v256_10,v261_21);
    }
    const Space v256_23 = unite(v256_8,v256_22);
    v255_21_result = unite(v255_21_result,v256_23);
  }
  const Space v255_21 = std::move(v255_21_result);
  return v255_21;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v271_5 = unwrap(s1,constant_8);
  const Path v271_6 = concat_path(p1,p0);
  const Space v271_7 = singleton(v271_6);
  Space v271_11_result;
  for (int v271_11_label = 1; v271_11_label <= 2; ++v271_11_label) {
    const Space v271_11_tail = child(v271_7,v271_11_label);
    if (v271_11_tail.empty()) continue;
    const Path v271_11_head{v271_11_label};
    const Space v272_2 = singleton(v271_11_head);
    const Space v272_3 = intersect(constant_6,v272_2);
    const Space v272_4 = (has_head(v272_3) ? constant_7 : Space{});
    const Space v272_5 = subtract(constant_0,v272_4);
    Space v272_7;
    if (!v272_5.empty()) {
      const Space v273_6 = routine_63(c, v271_11_head, v271_11_tail);
      v272_7 = compose(v272_5,v273_6);
    }
    const Space v272_8 = intersect(constant_6,v272_2);
    const Space v272_9 = (has_head(v272_8) ? constant_7 : Space{});
    Space v272_11;
    if (!v272_9.empty()) {
      const Space v274_10 = routine_64(c, v271_11_head, v271_11_tail);
      v272_11 = compose(v272_9,v274_10);
    }
    const Space v272_12 = unite(v272_7,v272_11);
    v271_11_result = unite(v271_11_result,v272_12);
  }
  const Space v271_11 = std::move(v271_11_result);
  const Space v271_12 = intersect(v271_5,v271_11);
  Space v271_16_result;
  for (int v271_16_label = 1; v271_16_label <= 2; ++v271_16_label) {
    const Space v271_16_tail = child(v271_7,v271_16_label);
    if (v271_16_tail.empty()) continue;
    const Path v271_16_head{v271_16_label};
    const Space v275_2 = singleton(v271_16_head);
    const Space v275_3 = intersect(constant_6,v275_2);
    const Space v275_4 = (has_head(v275_3) ? constant_7 : Space{});
    const Space v275_5 = subtract(constant_0,v275_4);
    Space v275_7;
    if (!v275_5.empty()) {
      const Space v276_6 = routine_63(c, v271_16_head, v271_16_tail);
      v275_7 = compose(v275_5,v276_6);
    }
    const Space v275_8 = intersect(constant_6,v275_2);
    const Space v275_9 = (has_head(v275_8) ? constant_7 : Space{});
    Space v275_11;
    if (!v275_9.empty()) {
      const Space v277_10 = routine_64(c, v271_16_head, v271_16_tail);
      v275_11 = compose(v275_9,v277_10);
    }
    const Space v275_12 = unite(v275_7,v275_11);
    v271_16_result = unite(v271_16_result,v275_12);
  }
  const Space v271_16 = std::move(v271_16_result);
  const Space v271_17 = intersect(v271_5,v271_16);
  const Space v271_18 = routine_65(c, v271_17);
  const Space v271_19 = subtract(v271_12,v271_18);
  Space v271_23_result;
  for (int v271_23_label = 1; v271_23_label <= 2; ++v271_23_label) {
    const Space v271_23_tail = child(v271_7,v271_23_label);
    if (v271_23_tail.empty()) continue;
    const Path v271_23_head{v271_23_label};
    const Space v278_2 = singleton(v271_23_head);
    const Space v278_3 = intersect(constant_6,v278_2);
    const Space v278_4 = (has_head(v278_3) ? constant_7 : Space{});
    const Space v278_5 = subtract(constant_0,v278_4);
    Space v278_7;
    if (!v278_5.empty()) {
      const Space v279_6 = routine_63(c, v271_23_head, v271_23_tail);
      v278_7 = compose(v278_5,v279_6);
    }
    const Space v278_8 = intersect(constant_6,v278_2);
    const Space v278_9 = (has_head(v278_8) ? constant_7 : Space{});
    Space v278_11;
    if (!v278_9.empty()) {
      const Space v280_10 = routine_64(c, v271_23_head, v271_23_tail);
      v278_11 = compose(v278_9,v280_10);
    }
    const Space v278_12 = unite(v278_7,v278_11);
    v271_23_result = unite(v271_23_result,v278_12);
  }
  const Space v271_23 = std::move(v271_23_result);
  const Space v271_24 = intersect(v271_5,v271_23);
  const Space v271_25 = routine_66(c, v271_24);
  const Space v271_26 = intersect(v271_19,v271_25);
  Space v271_36_result;
  for (int v271_36_label = 1; v271_36_label <= 2; ++v271_36_label) {
    const Space v271_36_tail = child(v271_26,v271_36_label);
    if (v271_36_tail.empty()) continue;
    const Path v271_36_head{v271_36_label};
    const Space v281_2 = singleton(v271_36_head);
    const Space v281_3 = intersect(constant_6,v281_2);
    const Space v281_4 = (has_head(v281_3) ? constant_7 : Space{});
    const Space v281_5 = subtract(constant_0,v281_4);
    Space v281_7;
    if (!v281_5.empty()) {
      Space v282_6_result;
      for (int v282_6_label = 1; v282_6_label <= 2; ++v282_6_label) {
        const Space v282_6_tail = child(v271_36_tail,v282_6_label);
        if (v282_6_tail.empty()) continue;
        const Path v282_6_head{v282_6_label};
        const Space v283_2 = singleton(v282_6_head);
        const Space v283_3 = intersect(constant_6,v283_2);
        const Space v283_4 = (has_head(v283_3) ? constant_7 : Space{});
        const Space v283_5 = subtract(constant_0,v283_4);
        Space v283_8;
        if (!v283_5.empty()) {
          const Path v284_6 = concat_path(v271_36_head,v282_6_head);
          const Space v284_7 = routine_67(c, v284_6, v282_6_tail);
          v283_8 = compose(v283_5,v284_7);
        }
        const Space v283_9 = intersect(constant_6,v283_2);
        const Space v283_10 = (has_head(v283_9) ? constant_7 : Space{});
        Space v283_12;
        if (!v283_10.empty()) {
          const Path v285_6 = concat_path(v271_36_head,v282_6_head);
          const Space v285_11 = routine_68(c, v285_6, v282_6_tail);
          v283_12 = compose(v283_10,v285_11);
        }
        const Space v283_13 = unite(v283_8,v283_12);
        v282_6_result = unite(v282_6_result,v283_13);
      }
      const Space v282_6 = std::move(v282_6_result);
      v281_7 = compose(v281_5,v282_6);
    }
    const Space v281_8 = intersect(constant_6,v281_2);
    const Space v281_9 = (has_head(v281_8) ? constant_7 : Space{});
    Space v281_11;
    if (!v281_9.empty()) {
      Space v286_10_result;
      for (int v286_10_label = 1; v286_10_label <= 2; ++v286_10_label) {
        const Space v286_10_tail = child(v271_36_tail,v286_10_label);
        if (v286_10_tail.empty()) continue;
        const Path v286_10_head{v286_10_label};
        const Space v287_2 = singleton(v286_10_head);
        const Space v287_3 = intersect(constant_6,v287_2);
        const Space v287_4 = (has_head(v287_3) ? constant_7 : Space{});
        const Space v287_5 = subtract(constant_0,v287_4);
        Space v287_8;
        if (!v287_5.empty()) {
          const Path v288_6 = concat_path(v271_36_head,v286_10_head);
          const Space v288_7 = routine_67(c, v288_6, v286_10_tail);
          v287_8 = compose(v287_5,v288_7);
        }
        const Space v287_9 = intersect(constant_6,v287_2);
        const Space v287_10 = (has_head(v287_9) ? constant_7 : Space{});
        Space v287_12;
        if (!v287_10.empty()) {
          const Path v289_6 = concat_path(v271_36_head,v286_10_head);
          const Space v289_11 = routine_69(c, v289_6, v286_10_tail);
          v287_12 = compose(v287_10,v289_11);
        }
        const Space v287_13 = unite(v287_8,v287_12);
        v286_10_result = unite(v286_10_result,v287_13);
      }
      const Space v286_10 = std::move(v286_10_result);
      v281_11 = compose(v281_9,v286_10);
    }
    const Space v281_12 = unite(v281_7,v281_11);
    v271_36_result = unite(v271_36_result,v281_12);
  }
  const Space v271_36 = std::move(v271_36_result);
  Space v271_40_result;
  for (int v271_40_label = 1; v271_40_label <= 2; ++v271_40_label) {
    const Space v271_40_tail = child(v271_7,v271_40_label);
    if (v271_40_tail.empty()) continue;
    const Path v271_40_head{v271_40_label};
    const Space v290_2 = singleton(v271_40_head);
    const Space v290_3 = intersect(constant_6,v290_2);
    const Space v290_4 = (has_head(v290_3) ? constant_7 : Space{});
    const Space v290_5 = subtract(constant_0,v290_4);
    Space v290_7;
    if (!v290_5.empty()) {
      const Space v291_6 = routine_63(c, v271_40_head, v271_40_tail);
      v290_7 = compose(v290_5,v291_6);
    }
    const Space v290_8 = intersect(constant_6,v290_2);
    const Space v290_9 = (has_head(v290_8) ? constant_7 : Space{});
    Space v290_11;
    if (!v290_9.empty()) {
      const Space v292_10 = routine_64(c, v271_40_head, v271_40_tail);
      v290_11 = compose(v290_9,v292_10);
    }
    const Space v290_12 = unite(v290_7,v290_11);
    v271_40_result = unite(v271_40_result,v290_12);
  }
  const Space v271_40 = std::move(v271_40_result);
  const Space v271_41 = intersect(v271_5,v271_40);
  Space v271_45_result;
  for (int v271_45_label = 1; v271_45_label <= 2; ++v271_45_label) {
    const Space v271_45_tail = child(v271_7,v271_45_label);
    if (v271_45_tail.empty()) continue;
    const Path v271_45_head{v271_45_label};
    const Space v293_2 = singleton(v271_45_head);
    const Space v293_3 = intersect(constant_6,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_7 : Space{});
    const Space v293_5 = subtract(constant_0,v293_4);
    Space v293_7;
    if (!v293_5.empty()) {
      const Space v294_6 = routine_63(c, v271_45_head, v271_45_tail);
      v293_7 = compose(v293_5,v294_6);
    }
    const Space v293_8 = intersect(constant_6,v293_2);
    const Space v293_9 = (has_head(v293_8) ? constant_7 : Space{});
    Space v293_11;
    if (!v293_9.empty()) {
      const Space v295_10 = routine_64(c, v271_45_head, v271_45_tail);
      v293_11 = compose(v293_9,v295_10);
    }
    const Space v293_12 = unite(v293_7,v293_11);
    v271_45_result = unite(v271_45_result,v293_12);
  }
  const Space v271_45 = std::move(v271_45_result);
  const Space v271_46 = intersect(v271_5,v271_45);
  const Space v271_47 = routine_66(c, v271_46);
  const Space v271_48 = routine_65(c, v271_47);
  const Space v271_49 = subtract(v271_41,v271_48);
  Space v271_53_result;
  for (int v271_53_label = 1; v271_53_label <= 2; ++v271_53_label) {
    const Space v271_53_tail = child(v271_7,v271_53_label);
    if (v271_53_tail.empty()) continue;
    const Path v271_53_head{v271_53_label};
    const Space v296_2 = singleton(v271_53_head);
    const Space v296_3 = intersect(constant_6,v296_2);
    const Space v296_4 = (has_head(v296_3) ? constant_7 : Space{});
    const Space v296_5 = subtract(constant_0,v296_4);
    Space v296_7;
    if (!v296_5.empty()) {
      const Space v297_6 = routine_63(c, v271_53_head, v271_53_tail);
      v296_7 = compose(v296_5,v297_6);
    }
    const Space v296_8 = intersect(constant_6,v296_2);
    const Space v296_9 = (has_head(v296_8) ? constant_7 : Space{});
    Space v296_11;
    if (!v296_9.empty()) {
      const Space v298_10 = routine_64(c, v271_53_head, v271_53_tail);
      v296_11 = compose(v296_9,v298_10);
    }
    const Space v296_12 = unite(v296_7,v296_11);
    v271_53_result = unite(v271_53_result,v296_12);
  }
  const Space v271_53 = std::move(v271_53_result);
  const Space v271_54 = intersect(v271_5,v271_53);
  const Space v271_55 = routine_65(c, v271_54);
  const Space v271_56 = intersect(v271_49,v271_55);
  Space v271_66_result;
  for (int v271_66_label = 1; v271_66_label <= 2; ++v271_66_label) {
    const Space v271_66_tail = child(v271_56,v271_66_label);
    if (v271_66_tail.empty()) continue;
    const Path v271_66_head{v271_66_label};
    const Space v299_2 = singleton(v271_66_head);
    const Space v299_3 = intersect(constant_6,v299_2);
    const Space v299_4 = (has_head(v299_3) ? constant_7 : Space{});
    const Space v299_5 = subtract(constant_0,v299_4);
    Space v299_7;
    if (!v299_5.empty()) {
      Space v300_6_result;
      for (int v300_6_label = 1; v300_6_label <= 2; ++v300_6_label) {
        const Space v300_6_tail = child(v271_66_tail,v300_6_label);
        if (v300_6_tail.empty()) continue;
        const Path v300_6_head{v300_6_label};
        const Space v301_2 = singleton(v300_6_head);
        const Space v301_3 = intersect(constant_6,v301_2);
        const Space v301_4 = (has_head(v301_3) ? constant_7 : Space{});
        const Space v301_5 = subtract(constant_0,v301_4);
        Space v301_8;
        if (!v301_5.empty()) {
          const Path v302_6 = concat_path(v271_66_head,v300_6_head);
          const Space v302_7 = routine_70(c, v302_6, v300_6_tail);
          v301_8 = compose(v301_5,v302_7);
        }
        const Space v301_9 = intersect(constant_6,v301_2);
        const Space v301_10 = (has_head(v301_9) ? constant_7 : Space{});
        Space v301_12;
        if (!v301_10.empty()) {
          const Path v303_6 = concat_path(v271_66_head,v300_6_head);
          const Space v303_11 = routine_71(c, v303_6, v300_6_tail);
          v301_12 = compose(v301_10,v303_11);
        }
        const Space v301_13 = unite(v301_8,v301_12);
        v300_6_result = unite(v300_6_result,v301_13);
      }
      const Space v300_6 = std::move(v300_6_result);
      v299_7 = compose(v299_5,v300_6);
    }
    const Space v299_8 = intersect(constant_6,v299_2);
    const Space v299_9 = (has_head(v299_8) ? constant_7 : Space{});
    Space v299_11;
    if (!v299_9.empty()) {
      Space v304_10_result;
      for (int v304_10_label = 1; v304_10_label <= 2; ++v304_10_label) {
        const Space v304_10_tail = child(v271_66_tail,v304_10_label);
        if (v304_10_tail.empty()) continue;
        const Path v304_10_head{v304_10_label};
        const Space v305_2 = singleton(v304_10_head);
        const Space v305_3 = intersect(constant_6,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_7 : Space{});
        const Space v305_5 = subtract(constant_0,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v271_66_head,v304_10_head);
          const Space v306_7 = routine_70(c, v306_6, v304_10_tail);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_6,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_7 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v271_66_head,v304_10_head);
          const Space v307_11 = routine_72(c, v307_6, v304_10_tail);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_10_result = unite(v304_10_result,v305_13);
      }
      const Space v304_10 = std::move(v304_10_result);
      v299_11 = compose(v299_9,v304_10);
    }
    const Space v299_12 = unite(v299_7,v299_11);
    v271_66_result = unite(v271_66_result,v299_12);
  }
  const Space v271_66 = std::move(v271_66_result);
  const Space v271_67 = subtract(v271_36,v271_66);
  const Space v271_68 = compose(v271_67,v271_7);
  Space v271_78_result;
  for (int v271_78_label = 1; v271_78_label <= 2; ++v271_78_label) {
    const Space v271_78_tail = child(v271_68,v271_78_label);
    if (v271_78_tail.empty()) continue;
    const Path v271_78_head{v271_78_label};
    const Space v308_2 = singleton(v271_78_head);
    const Space v308_3 = intersect(constant_6,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_7 : Space{});
    const Space v308_5 = subtract(constant_0,v308_4);
    Space v308_7;
    if (!v308_5.empty()) {
      Space v309_6_result;
      for (int v309_6_label = 1; v309_6_label <= 2; ++v309_6_label) {
        const Space v309_6_tail = child(v271_78_tail,v309_6_label);
        if (v309_6_tail.empty()) continue;
        const Path v309_6_head{v309_6_label};
        const Space v310_2 = singleton(v309_6_head);
        const Space v310_3 = intersect(constant_6,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_7 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v271_78_head,v309_6_head);
          const Space v311_7 = routine_73(c, v311_6, v309_6_tail);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_6,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_7 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v271_78_head,v309_6_head);
          const Space v312_11 = routine_74(c, v312_6, v309_6_tail);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_6_result = unite(v309_6_result,v310_13);
      }
      const Space v309_6 = std::move(v309_6_result);
      v308_7 = compose(v308_5,v309_6);
    }
    const Space v308_8 = intersect(constant_6,v308_2);
    const Space v308_9 = (has_head(v308_8) ? constant_7 : Space{});
    Space v308_11;
    if (!v308_9.empty()) {
      Space v313_10_result;
      for (int v313_10_label = 1; v313_10_label <= 2; ++v313_10_label) {
        const Space v313_10_tail = child(v271_78_tail,v313_10_label);
        if (v313_10_tail.empty()) continue;
        const Path v313_10_head{v313_10_label};
        const Space v314_2 = singleton(v313_10_head);
        const Space v314_3 = intersect(constant_6,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_7 : Space{});
        const Space v314_5 = subtract(constant_0,v314_4);
        Space v314_8;
        if (!v314_5.empty()) {
          const Path v315_6 = concat_path(v271_78_head,v313_10_head);
          const Space v315_7 = routine_73(c, v315_6, v313_10_tail);
          v314_8 = compose(v314_5,v315_7);
        }
        const Space v314_9 = intersect(constant_6,v314_2);
        const Space v314_10 = (has_head(v314_9) ? constant_7 : Space{});
        Space v314_12;
        if (!v314_10.empty()) {
          const Path v316_6 = concat_path(v271_78_head,v313_10_head);
          const Space v316_11 = routine_75(c, v316_6, v313_10_tail);
          v314_12 = compose(v314_10,v316_11);
        }
        const Space v314_13 = unite(v314_8,v314_12);
        v313_10_result = unite(v313_10_result,v314_13);
      }
      const Space v313_10 = std::move(v313_10_result);
      v308_11 = compose(v308_9,v313_10);
    }
    const Space v308_12 = unite(v308_7,v308_11);
    v271_78_result = unite(v271_78_result,v308_12);
  }
  const Space v271_78 = std::move(v271_78_result);
  return v271_78;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v317_13_result;
  for (int v317_13_label = 1; v317_13_label <= 2; ++v317_13_label) {
    const Space v317_13_tail = child(s0,v317_13_label);
    if (v317_13_tail.empty()) continue;
    const Path v317_13_head{v317_13_label};
    const Space v318_2 = singleton(v317_13_head);
    const Space v318_3 = intersect(constant_6,v318_2);
    const Space v318_4 = (has_head(v318_3) ? constant_7 : Space{});
    const Space v318_5 = subtract(constant_0,v318_4);
    Space v318_8;
    if (!v318_5.empty()) {
      const Path v319_6 = concat_path(p0,v317_13_head);
      Space v319_7_result;
      for (int v319_7_label = 1; v319_7_label <= 2; ++v319_7_label) {
        const Space v319_7_tail = child(v317_13_tail,v319_7_label);
        if (v319_7_tail.empty()) continue;
        const Path v319_7_head{v319_7_label};
        const Space v320_2 = singleton(v319_7_head);
        const Space v320_3 = intersect(constant_6,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_7 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_7_head);
          const Space v321_7 = routine_76(c, v321_6, p1, v319_7_tail, s1);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_6,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_7 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_7_head);
          const Space v322_11 = routine_77(c, v322_6, p1, v319_7_tail, s1);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_7_result = unite(v319_7_result,v320_13);
      }
      const Space v319_7 = std::move(v319_7_result);
      v318_8 = compose(v318_5,v319_7);
    }
    const Space v318_9 = intersect(constant_6,v318_2);
    const Space v318_10 = (has_head(v318_9) ? constant_7 : Space{});
    Space v318_12;
    if (!v318_10.empty()) {
      const Path v323_6 = concat_path(p0,v317_13_head);
      Space v323_11_result;
      for (int v323_11_label = 1; v323_11_label <= 2; ++v323_11_label) {
        const Space v323_11_tail = child(v317_13_tail,v323_11_label);
        if (v323_11_tail.empty()) continue;
        const Path v323_11_head{v323_11_label};
        const Space v324_2 = singleton(v323_11_head);
        const Space v324_3 = intersect(constant_6,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_7 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_11_head);
          const Space v325_7 = routine_76(c, v325_6, p1, v323_11_tail, s1);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_6,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_7 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_11_head);
          const Space v326_11 = routine_26(c, v326_6, p1, v323_11_tail, s1);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_11_result = unite(v323_11_result,v324_13);
      }
      const Space v323_11 = std::move(v323_11_result);
      v318_12 = compose(v318_10,v323_11);
    }
    const Space v318_13 = unite(v318_8,v318_12);
    v317_13_result = unite(v317_13_result,v318_13);
  }
  const Space v317_13 = std::move(v317_13_result);
  return v317_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v327_8 = unwrap(s1,constant_8);
  Space v327_21_result;
  for (int v327_21_label = 1; v327_21_label <= 2; ++v327_21_label) {
    const Space v327_21_tail = child(s0,v327_21_label);
    if (v327_21_tail.empty()) continue;
    const Path v327_21_head{v327_21_label};
    const Space v328_2 = singleton(v327_21_head);
    const Space v328_3 = intersect(constant_6,v328_2);
    const Space v328_4 = (has_head(v328_3) ? constant_7 : Space{});
    const Space v328_5 = subtract(constant_0,v328_4);
    Space v328_8;
    if (!v328_5.empty()) {
      const Path v329_6 = concat_path(p0,v327_21_head);
      Space v329_7_result;
      for (int v329_7_label = 1; v329_7_label <= 2; ++v329_7_label) {
        const Space v329_7_tail = child(v327_21_tail,v329_7_label);
        if (v329_7_tail.empty()) continue;
        const Path v329_7_head{v329_7_label};
        const Space v330_2 = singleton(v329_7_head);
        const Space v330_3 = intersect(constant_6,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_7 : Space{});
        const Space v330_5 = subtract(constant_0,v330_4);
        Space v330_8;
        if (!v330_5.empty()) {
          const Path v331_6 = concat_path(v329_6,v329_7_head);
          const Space v331_7 = routine_76(c, v331_6, p1, v329_7_tail, s1);
          v330_8 = compose(v330_5,v331_7);
        }
        const Space v330_9 = intersect(constant_6,v330_2);
        const Space v330_10 = (has_head(v330_9) ? constant_7 : Space{});
        Space v330_12;
        if (!v330_10.empty()) {
          const Path v332_6 = concat_path(v329_6,v329_7_head);
          const Space v332_11 = routine_77(c, v332_6, p1, v329_7_tail, s1);
          v330_12 = compose(v330_10,v332_11);
        }
        const Space v330_13 = unite(v330_8,v330_12);
        v329_7_result = unite(v329_7_result,v330_13);
      }
      const Space v329_7 = std::move(v329_7_result);
      v328_8 = compose(v328_5,v329_7);
    }
    const Space v328_9 = intersect(constant_6,v328_2);
    const Space v328_10 = (has_head(v328_9) ? constant_7 : Space{});
    Space v328_22;
    if (!v328_10.empty()) {
      const Path v333_6 = concat_path(p0,v327_21_head);
      const Path v333_11 = concat_path(p1,v333_6);
      const Space v333_12 = routine_29(c, v333_11);
      const Space v333_13 = intersect(v327_8,v333_12);
      const Space v333_14 = routine_30(c, v333_13);
      Space v333_15_result;
      for (int v333_15_label = 1; v333_15_label <= 2; ++v333_15_label) {
        const Space v333_15_tail = child(v333_14,v333_15_label);
        if (v333_15_tail.empty()) continue;
        const Path v333_15_head{v333_15_label};
        const Space v334_2 = singleton(v333_15_head);
        const Space v334_3 = intersect(constant_6,v334_2);
        const Space v334_4 = (has_head(v334_3) ? constant_7 : Space{});
        const Space v334_5 = subtract(constant_0,v334_4);
        Space v334_7;
        if (!v334_5.empty()) {
          const Space v335_6 = routine_31(c, v333_15_head, v333_15_tail);
          v334_7 = compose(v334_5,v335_6);
        }
        const Space v334_8 = intersect(constant_6,v334_2);
        const Space v334_9 = (has_head(v334_8) ? constant_7 : Space{});
        Space v334_11;
        if (!v334_9.empty()) {
          const Space v336_10 = routine_32(c, v333_15_head, v333_15_tail);
          v334_11 = compose(v334_9,v336_10);
        }
        const Space v334_12 = unite(v334_7,v334_11);
        v333_15_result = unite(v333_15_result,v334_12);
      }
      const Space v333_15 = std::move(v333_15_result);
      const Space v333_16 = routine_33(c, v333_13);
      Space v333_17_result;
      for (int v333_17_label = 1; v333_17_label <= 2; ++v333_17_label) {
        const Space v333_17_tail = child(v333_16,v333_17_label);
        if (v333_17_tail.empty()) continue;
        const Path v333_17_head{v333_17_label};
        const Space v337_2 = singleton(v333_17_head);
        const Space v337_3 = intersect(constant_6,v337_2);
        const Space v337_4 = (has_head(v337_3) ? constant_7 : Space{});
        const Space v337_5 = subtract(constant_0,v337_4);
        Space v337_7;
        if (!v337_5.empty()) {
          const Space v338_6 = routine_34(c, v333_17_head, v333_17_tail);
          v337_7 = compose(v337_5,v338_6);
        }
        const Space v337_8 = intersect(constant_6,v337_2);
        const Space v337_9 = (has_head(v337_8) ? constant_7 : Space{});
        Space v337_11;
        if (!v337_9.empty()) {
          const Space v339_10 = routine_35(c, v333_17_head, v333_17_tail);
          v337_11 = compose(v337_9,v339_10);
        }
        const Space v337_12 = unite(v337_7,v337_11);
        v333_17_result = unite(v333_17_result,v337_12);
      }
      const Space v333_17 = std::move(v333_17_result);
      const Space v333_18 = subtract(v333_15,v333_17);
      const Space v333_19 = singleton(v333_11);
      const Space v333_20 = compose(v333_18,v333_19);
      Space v333_21_result;
      for (int v333_21_label = 1; v333_21_label <= 2; ++v333_21_label) {
        const Space v333_21_tail = child(v333_20,v333_21_label);
        if (v333_21_tail.empty()) continue;
        const Path v333_21_head{v333_21_label};
        const Space v340_2 = singleton(v333_21_head);
        const Space v340_3 = intersect(constant_6,v340_2);
        const Space v340_4 = (has_head(v340_3) ? constant_7 : Space{});
        const Space v340_5 = subtract(constant_0,v340_4);
        Space v340_7;
        if (!v340_5.empty()) {
          const Space v341_6 = routine_36(c, v333_21_head, v333_21_tail);
          v340_7 = compose(v340_5,v341_6);
        }
        const Space v340_8 = intersect(constant_6,v340_2);
        const Space v340_9 = (has_head(v340_8) ? constant_7 : Space{});
        Space v340_11;
        if (!v340_9.empty()) {
          const Space v342_10 = routine_37(c, v333_21_head, v333_21_tail);
          v340_11 = compose(v340_9,v342_10);
        }
        const Space v340_12 = unite(v340_7,v340_11);
        v333_21_result = unite(v333_21_result,v340_12);
      }
      const Space v333_21 = std::move(v333_21_result);
      v328_22 = compose(v328_10,v333_21);
    }
    const Space v328_23 = unite(v328_8,v328_22);
    v327_21_result = unite(v327_21_result,v328_23);
  }
  const Space v327_21 = std::move(v327_21_result);
  return v327_21;
}

static Space routine_29(Context& c, const Path& p0) {
  const Space v343_1 = singleton(p0);
  Space v343_11_result;
  for (int v343_11_label = 1; v343_11_label <= 2; ++v343_11_label) {
    const Space v343_11_tail = child(v343_1,v343_11_label);
    if (v343_11_tail.empty()) continue;
    const Path v343_11_head{v343_11_label};
    const Space v344_2 = singleton(v343_11_head);
    const Space v344_3 = intersect(constant_6,v344_2);
    const Space v344_4 = (has_head(v344_3) ? constant_7 : Space{});
    const Space v344_5 = subtract(constant_0,v344_4);
    Space v344_7;
    if (!v344_5.empty()) {
      Space v345_6_result;
      for (int v345_6_label = 1; v345_6_label <= 2; ++v345_6_label) {
        const Space v345_6_tail = child(v343_11_tail,v345_6_label);
        if (v345_6_tail.empty()) continue;
        const Path v345_6_head{v345_6_label};
        const Space v346_2 = singleton(v345_6_head);
        const Space v346_3 = intersect(constant_6,v346_2);
        const Space v346_4 = (has_head(v346_3) ? constant_7 : Space{});
        const Space v346_5 = subtract(constant_0,v346_4);
        Space v346_8;
        if (!v346_5.empty()) {
          const Path v347_6 = concat_path(v343_11_head,v345_6_head);
          const Space v347_7 = routine_78(c, v347_6, v345_6_tail);
          v346_8 = compose(v346_5,v347_7);
        }
        const Space v346_9 = intersect(constant_6,v346_2);
        const Space v346_10 = (has_head(v346_9) ? constant_7 : Space{});
        Space v346_12;
        if (!v346_10.empty()) {
          const Path v348_6 = concat_path(v343_11_head,v345_6_head);
          const Space v348_11 = routine_79(c, v348_6, v345_6_tail);
          v346_12 = compose(v346_10,v348_11);
        }
        const Space v346_13 = unite(v346_8,v346_12);
        v345_6_result = unite(v345_6_result,v346_13);
      }
      const Space v345_6 = std::move(v345_6_result);
      v344_7 = compose(v344_5,v345_6);
    }
    const Space v344_8 = intersect(constant_6,v344_2);
    const Space v344_9 = (has_head(v344_8) ? constant_7 : Space{});
    Space v344_11;
    if (!v344_9.empty()) {
      Space v349_10_result;
      for (int v349_10_label = 1; v349_10_label <= 2; ++v349_10_label) {
        const Space v349_10_tail = child(v343_11_tail,v349_10_label);
        if (v349_10_tail.empty()) continue;
        const Path v349_10_head{v349_10_label};
        const Space v350_2 = singleton(v349_10_head);
        const Space v350_3 = intersect(constant_6,v350_2);
        const Space v350_4 = (has_head(v350_3) ? constant_7 : Space{});
        const Space v350_5 = subtract(constant_0,v350_4);
        Space v350_8;
        if (!v350_5.empty()) {
          const Path v351_6 = concat_path(v343_11_head,v349_10_head);
          const Space v351_7 = routine_78(c, v351_6, v349_10_tail);
          v350_8 = compose(v350_5,v351_7);
        }
        const Space v350_9 = intersect(constant_6,v350_2);
        const Space v350_10 = (has_head(v350_9) ? constant_7 : Space{});
        Space v350_12;
        if (!v350_10.empty()) {
          const Path v352_6 = concat_path(v343_11_head,v349_10_head);
          const Space v352_11 = routine_80(c, v352_6, v349_10_tail);
          v350_12 = compose(v350_10,v352_11);
        }
        const Space v350_13 = unite(v350_8,v350_12);
        v349_10_result = unite(v349_10_result,v350_13);
      }
      const Space v349_10 = std::move(v349_10_result);
      v344_11 = compose(v344_9,v349_10);
    }
    const Space v344_12 = unite(v344_7,v344_11);
    v343_11_result = unite(v343_11_result,v344_12);
  }
  const Space v343_11 = std::move(v343_11_result);
  return v343_11;
}

static Space routine_30(Context& c, const Space& s0) {
  const Space v353_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v353_2 = first_matching(s0,constant_0,false);
  const Space v353_3 = unite(v353_1,v353_2);
  Space v353_6;
  if (!v353_3.empty()) {
    const Space v354_4 = routine_81(c, s0);
    const Space v354_5 = subtract(s0,v354_4);
    v353_6 = compose(v353_3,v354_5);
  }
  Space v353_9;
  if (!v353_3.empty()) {
    const Space v355_7 = routine_66(c, s0);
    const Space v355_8 = routine_66(c, v355_7);
    v353_9 = compose(v353_3,v355_8);
  }
  const Space v353_10 = subtract(s0,v353_9);
  const Space v353_11 = intersect(v353_6,v353_10);
  return v353_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v356_11_result;
  for (int v356_11_label = 1; v356_11_label <= 2; ++v356_11_label) {
    const Space v356_11_tail = child(s0,v356_11_label);
    if (v356_11_tail.empty()) continue;
    const Path v356_11_head{v356_11_label};
    const Space v357_2 = singleton(v356_11_head);
    const Space v357_3 = intersect(constant_6,v357_2);
    const Space v357_4 = (has_head(v357_3) ? constant_7 : Space{});
    const Space v357_5 = subtract(constant_0,v357_4);
    Space v357_8;
    if (!v357_5.empty()) {
      const Path v358_6 = concat_path(p0,v356_11_head);
      Space v358_7_result;
      for (int v358_7_label = 1; v358_7_label <= 2; ++v358_7_label) {
        const Space v358_7_tail = child(v356_11_tail,v358_7_label);
        if (v358_7_tail.empty()) continue;
        const Path v358_7_head{v358_7_label};
        const Space v359_2 = singleton(v358_7_head);
        const Space v359_3 = intersect(constant_6,v359_2);
        const Space v359_4 = (has_head(v359_3) ? constant_7 : Space{});
        const Space v359_5 = subtract(constant_0,v359_4);
        Space v359_8;
        if (!v359_5.empty()) {
          const Path v360_6 = concat_path(v358_6,v358_7_head);
          const Space v360_7 = routine_82(c, v360_6, v358_7_tail);
          v359_8 = compose(v359_5,v360_7);
        }
        const Space v359_9 = intersect(constant_6,v359_2);
        const Space v359_10 = (has_head(v359_9) ? constant_7 : Space{});
        Space v359_12;
        if (!v359_10.empty()) {
          const Path v361_6 = concat_path(v358_6,v358_7_head);
          const Space v361_11 = routine_83(c, v361_6, v358_7_tail);
          v359_12 = compose(v359_10,v361_11);
        }
        const Space v359_13 = unite(v359_8,v359_12);
        v358_7_result = unite(v358_7_result,v359_13);
      }
      const Space v358_7 = std::move(v358_7_result);
      v357_8 = compose(v357_5,v358_7);
    }
    const Space v357_9 = intersect(constant_6,v357_2);
    const Space v357_10 = (has_head(v357_9) ? constant_7 : Space{});
    Space v357_12;
    if (!v357_10.empty()) {
      const Path v362_6 = concat_path(p0,v356_11_head);
      Space v362_11_result;
      for (int v362_11_label = 1; v362_11_label <= 2; ++v362_11_label) {
        const Space v362_11_tail = child(v356_11_tail,v362_11_label);
        if (v362_11_tail.empty()) continue;
        const Path v362_11_head{v362_11_label};
        const Space v363_2 = singleton(v362_11_head);
        const Space v363_3 = intersect(constant_6,v363_2);
        const Space v363_4 = (has_head(v363_3) ? constant_7 : Space{});
        const Space v363_5 = subtract(constant_0,v363_4);
        Space v363_8;
        if (!v363_5.empty()) {
          const Path v364_6 = concat_path(v362_6,v362_11_head);
          const Space v364_7 = routine_82(c, v364_6, v362_11_tail);
          v363_8 = compose(v363_5,v364_7);
        }
        const Space v363_9 = intersect(constant_6,v363_2);
        const Space v363_10 = (has_head(v363_9) ? constant_7 : Space{});
        Space v363_12;
        if (!v363_10.empty()) {
          const Path v365_6 = concat_path(v362_6,v362_11_head);
          const Space v365_11 = routine_69(c, v365_6, v362_11_tail);
          v363_12 = compose(v363_10,v365_11);
        }
        const Space v363_13 = unite(v363_8,v363_12);
        v362_11_result = unite(v362_11_result,v363_13);
      }
      const Space v362_11 = std::move(v362_11_result);
      v357_12 = compose(v357_10,v362_11);
    }
    const Space v357_13 = unite(v357_8,v357_12);
    v356_11_result = unite(v356_11_result,v357_13);
  }
  const Space v356_11 = std::move(v356_11_result);
  return v356_11;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  Space v366_9_result;
  for (int v366_9_label = 1; v366_9_label <= 2; ++v366_9_label) {
    const Space v366_9_tail = child(s0,v366_9_label);
    if (v366_9_tail.empty()) continue;
    const Path v366_9_head{v366_9_label};
    const Space v367_2 = singleton(v366_9_head);
    const Space v367_3 = intersect(constant_6,v367_2);
    const Space v367_4 = (has_head(v367_3) ? constant_7 : Space{});
    const Space v367_5 = subtract(constant_0,v367_4);
    Space v367_8;
    if (!v367_5.empty()) {
      const Path v368_6 = concat_path(p0,v366_9_head);
      Space v368_7_result;
      for (int v368_7_label = 1; v368_7_label <= 2; ++v368_7_label) {
        const Space v368_7_tail = child(v366_9_tail,v368_7_label);
        if (v368_7_tail.empty()) continue;
        const Path v368_7_head{v368_7_label};
        const Space v369_2 = singleton(v368_7_head);
        const Space v369_3 = intersect(constant_6,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_7 : Space{});
        const Space v369_5 = subtract(constant_0,v369_4);
        Space v369_8;
        if (!v369_5.empty()) {
          const Path v370_6 = concat_path(v368_6,v368_7_head);
          const Space v370_7 = routine_82(c, v370_6, v368_7_tail);
          v369_8 = compose(v369_5,v370_7);
        }
        const Space v369_9 = intersect(constant_6,v369_2);
        const Space v369_10 = (has_head(v369_9) ? constant_7 : Space{});
        Space v369_12;
        if (!v369_10.empty()) {
          const Path v371_6 = concat_path(v368_6,v368_7_head);
          const Space v371_11 = routine_83(c, v371_6, v368_7_tail);
          v369_12 = compose(v369_10,v371_11);
        }
        const Space v369_13 = unite(v369_8,v369_12);
        v368_7_result = unite(v368_7_result,v369_13);
      }
      const Space v368_7 = std::move(v368_7_result);
      v367_8 = compose(v367_5,v368_7);
    }
    const Space v367_9 = intersect(constant_6,v367_2);
    const Space v367_10 = (has_head(v367_9) ? constant_7 : Space{});
    const Space v367_11 = compose(v367_10,constant_9);
    const Space v367_12 = unite(v367_8,v367_11);
    v366_9_result = unite(v366_9_result,v367_12);
  }
  const Space v366_9 = std::move(v366_9_result);
  return v366_9;
}

static Space routine_33(Context& c, const Space& s0) {
  const Space v372_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v372_2 = first_matching(s0,constant_0,false);
  const Space v372_3 = unite(v372_1,v372_2);
  Space v372_6;
  if (!v372_3.empty()) {
    const Space v373_4 = routine_66(c, s0);
    const Space v373_5 = routine_66(c, v373_4);
    v372_6 = compose(v372_3,v373_5);
  }
  Space v372_9;
  if (!v372_3.empty()) {
    const Space v374_7 = routine_81(c, s0);
    const Space v374_8 = subtract(s0,v374_7);
    v372_9 = compose(v372_3,v374_8);
  }
  const Space v372_10 = (has_head(v372_9) ? constant_7 : Space{});
  const Space v372_11 = first_matching(v372_9,constant_0,false);
  const Space v372_12 = unite(v372_10,v372_11);
  Space v372_15;
  if (!v372_12.empty()) {
    const Space v375_13 = routine_66(c, v372_9);
    const Space v375_14 = routine_66(c, v375_13);
    v372_15 = compose(v372_12,v375_14);
  }
  const Space v372_16 = subtract(s0,v372_15);
  const Space v372_17 = intersect(v372_6,v372_16);
  return v372_17;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  Space v376_11_result;
  for (int v376_11_label = 1; v376_11_label <= 2; ++v376_11_label) {
    const Space v376_11_tail = child(s0,v376_11_label);
    if (v376_11_tail.empty()) continue;
    const Path v376_11_head{v376_11_label};
    const Space v377_2 = singleton(v376_11_head);
    const Space v377_3 = intersect(constant_6,v377_2);
    const Space v377_4 = (has_head(v377_3) ? constant_7 : Space{});
    const Space v377_5 = subtract(constant_0,v377_4);
    Space v377_8;
    if (!v377_5.empty()) {
      const Path v378_6 = concat_path(p0,v376_11_head);
      Space v378_7_result;
      for (int v378_7_label = 1; v378_7_label <= 2; ++v378_7_label) {
        const Space v378_7_tail = child(v376_11_tail,v378_7_label);
        if (v378_7_tail.empty()) continue;
        const Path v378_7_head{v378_7_label};
        const Space v379_2 = singleton(v378_7_head);
        const Space v379_3 = intersect(constant_6,v379_2);
        const Space v379_4 = (has_head(v379_3) ? constant_7 : Space{});
        const Space v379_5 = subtract(constant_0,v379_4);
        Space v379_8;
        if (!v379_5.empty()) {
          const Path v380_6 = concat_path(v378_6,v378_7_head);
          const Space v380_7 = routine_84(c, v380_6, v378_7_tail);
          v379_8 = compose(v379_5,v380_7);
        }
        const Space v379_9 = intersect(constant_6,v379_2);
        const Space v379_10 = (has_head(v379_9) ? constant_7 : Space{});
        Space v379_12;
        if (!v379_10.empty()) {
          const Path v381_6 = concat_path(v378_6,v378_7_head);
          const Space v381_11 = routine_85(c, v381_6, v378_7_tail);
          v379_12 = compose(v379_10,v381_11);
        }
        const Space v379_13 = unite(v379_8,v379_12);
        v378_7_result = unite(v378_7_result,v379_13);
      }
      const Space v378_7 = std::move(v378_7_result);
      v377_8 = compose(v377_5,v378_7);
    }
    const Space v377_9 = intersect(constant_6,v377_2);
    const Space v377_10 = (has_head(v377_9) ? constant_7 : Space{});
    Space v377_12;
    if (!v377_10.empty()) {
      const Path v382_6 = concat_path(p0,v376_11_head);
      Space v382_11_result;
      for (int v382_11_label = 1; v382_11_label <= 2; ++v382_11_label) {
        const Space v382_11_tail = child(v376_11_tail,v382_11_label);
        if (v382_11_tail.empty()) continue;
        const Path v382_11_head{v382_11_label};
        const Space v383_2 = singleton(v382_11_head);
        const Space v383_3 = intersect(constant_6,v383_2);
        const Space v383_4 = (has_head(v383_3) ? constant_7 : Space{});
        const Space v383_5 = subtract(constant_0,v383_4);
        Space v383_8;
        if (!v383_5.empty()) {
          const Path v384_6 = concat_path(v382_6,v382_11_head);
          const Space v384_7 = routine_84(c, v384_6, v382_11_tail);
          v383_8 = compose(v383_5,v384_7);
        }
        const Space v383_9 = intersect(constant_6,v383_2);
        const Space v383_10 = (has_head(v383_9) ? constant_7 : Space{});
        Space v383_12;
        if (!v383_10.empty()) {
          const Path v385_6 = concat_path(v382_6,v382_11_head);
          const Space v385_11 = routine_72(c, v385_6, v382_11_tail);
          v383_12 = compose(v383_10,v385_11);
        }
        const Space v383_13 = unite(v383_8,v383_12);
        v382_11_result = unite(v382_11_result,v383_13);
      }
      const Space v382_11 = std::move(v382_11_result);
      v377_12 = compose(v377_10,v382_11);
    }
    const Space v377_13 = unite(v377_8,v377_12);
    v376_11_result = unite(v376_11_result,v377_13);
  }
  const Space v376_11 = std::move(v376_11_result);
  return v376_11;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  Space v386_9_result;
  for (int v386_9_label = 1; v386_9_label <= 2; ++v386_9_label) {
    const Space v386_9_tail = child(s0,v386_9_label);
    if (v386_9_tail.empty()) continue;
    const Path v386_9_head{v386_9_label};
    const Space v387_2 = singleton(v386_9_head);
    const Space v387_3 = intersect(constant_6,v387_2);
    const Space v387_4 = (has_head(v387_3) ? constant_7 : Space{});
    const Space v387_5 = subtract(constant_0,v387_4);
    Space v387_8;
    if (!v387_5.empty()) {
      const Path v388_6 = concat_path(p0,v386_9_head);
      Space v388_7_result;
      for (int v388_7_label = 1; v388_7_label <= 2; ++v388_7_label) {
        const Space v388_7_tail = child(v386_9_tail,v388_7_label);
        if (v388_7_tail.empty()) continue;
        const Path v388_7_head{v388_7_label};
        const Space v389_2 = singleton(v388_7_head);
        const Space v389_3 = intersect(constant_6,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_7 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_8;
        if (!v389_5.empty()) {
          const Path v390_6 = concat_path(v388_6,v388_7_head);
          const Space v390_7 = routine_84(c, v390_6, v388_7_tail);
          v389_8 = compose(v389_5,v390_7);
        }
        const Space v389_9 = intersect(constant_6,v389_2);
        const Space v389_10 = (has_head(v389_9) ? constant_7 : Space{});
        Space v389_12;
        if (!v389_10.empty()) {
          const Path v391_6 = concat_path(v388_6,v388_7_head);
          const Space v391_11 = routine_85(c, v391_6, v388_7_tail);
          v389_12 = compose(v389_10,v391_11);
        }
        const Space v389_13 = unite(v389_8,v389_12);
        v388_7_result = unite(v388_7_result,v389_13);
      }
      const Space v388_7 = std::move(v388_7_result);
      v387_8 = compose(v387_5,v388_7);
    }
    const Space v387_9 = intersect(constant_6,v387_2);
    const Space v387_10 = (has_head(v387_9) ? constant_7 : Space{});
    const Space v387_11 = compose(v387_10,constant_9);
    const Space v387_12 = unite(v387_8,v387_11);
    v386_9_result = unite(v386_9_result,v387_12);
  }
  const Space v386_9 = std::move(v386_9_result);
  return v386_9;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  Space v392_11_result;
  for (int v392_11_label = 1; v392_11_label <= 2; ++v392_11_label) {
    const Space v392_11_tail = child(s0,v392_11_label);
    if (v392_11_tail.empty()) continue;
    const Path v392_11_head{v392_11_label};
    const Space v393_2 = singleton(v392_11_head);
    const Space v393_3 = intersect(constant_6,v393_2);
    const Space v393_4 = (has_head(v393_3) ? constant_7 : Space{});
    const Space v393_5 = subtract(constant_0,v393_4);
    Space v393_8;
    if (!v393_5.empty()) {
      const Path v394_6 = concat_path(p0,v392_11_head);
      Space v394_7_result;
      for (int v394_7_label = 1; v394_7_label <= 2; ++v394_7_label) {
        const Space v394_7_tail = child(v392_11_tail,v394_7_label);
        if (v394_7_tail.empty()) continue;
        const Path v394_7_head{v394_7_label};
        const Space v395_2 = singleton(v394_7_head);
        const Space v395_3 = intersect(constant_6,v395_2);
        const Space v395_4 = (has_head(v395_3) ? constant_7 : Space{});
        const Space v395_5 = subtract(constant_0,v395_4);
        Space v395_8;
        if (!v395_5.empty()) {
          const Path v396_6 = concat_path(v394_6,v394_7_head);
          const Space v396_7 = routine_86(c, v396_6, v394_7_tail);
          v395_8 = compose(v395_5,v396_7);
        }
        const Space v395_9 = intersect(constant_6,v395_2);
        const Space v395_10 = (has_head(v395_9) ? constant_7 : Space{});
        Space v395_12;
        if (!v395_10.empty()) {
          const Path v397_6 = concat_path(v394_6,v394_7_head);
          const Space v397_11 = routine_87(c, v397_6, v394_7_tail);
          v395_12 = compose(v395_10,v397_11);
        }
        const Space v395_13 = unite(v395_8,v395_12);
        v394_7_result = unite(v394_7_result,v395_13);
      }
      const Space v394_7 = std::move(v394_7_result);
      v393_8 = compose(v393_5,v394_7);
    }
    const Space v393_9 = intersect(constant_6,v393_2);
    const Space v393_10 = (has_head(v393_9) ? constant_7 : Space{});
    Space v393_12;
    if (!v393_10.empty()) {
      const Path v398_6 = concat_path(p0,v392_11_head);
      Space v398_11_result;
      for (int v398_11_label = 1; v398_11_label <= 2; ++v398_11_label) {
        const Space v398_11_tail = child(v392_11_tail,v398_11_label);
        if (v398_11_tail.empty()) continue;
        const Path v398_11_head{v398_11_label};
        const Space v399_2 = singleton(v398_11_head);
        const Space v399_3 = intersect(constant_6,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_7 : Space{});
        const Space v399_5 = subtract(constant_0,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_11_head);
          const Space v400_7 = routine_86(c, v400_6, v398_11_tail);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_6,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_7 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_11_head);
          const Space v401_11 = routine_75(c, v401_6, v398_11_tail);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_11_result = unite(v398_11_result,v399_13);
      }
      const Space v398_11 = std::move(v398_11_result);
      v393_12 = compose(v393_10,v398_11);
    }
    const Space v393_13 = unite(v393_8,v393_12);
    v392_11_result = unite(v392_11_result,v393_13);
  }
  const Space v392_11 = std::move(v392_11_result);
  return v392_11;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v402_8_result;
  for (int v402_8_label = 1; v402_8_label <= 2; ++v402_8_label) {
    const Space v402_8_tail = child(s0,v402_8_label);
    if (v402_8_tail.empty()) continue;
    const Path v402_8_head{v402_8_label};
    const Space v403_2 = singleton(v402_8_head);
    const Space v403_3 = intersect(constant_6,v403_2);
    const Space v403_4 = (has_head(v403_3) ? constant_7 : Space{});
    const Space v403_5 = subtract(constant_0,v403_4);
    Space v403_8;
    if (!v403_5.empty()) {
      const Path v404_6 = concat_path(p0,v402_8_head);
      Space v404_7_result;
      for (int v404_7_label = 1; v404_7_label <= 2; ++v404_7_label) {
        const Space v404_7_tail = child(v402_8_tail,v404_7_label);
        if (v404_7_tail.empty()) continue;
        const Path v404_7_head{v404_7_label};
        const Space v405_2 = singleton(v404_7_head);
        const Space v405_3 = intersect(constant_6,v405_2);
        const Space v405_4 = (has_head(v405_3) ? constant_7 : Space{});
        const Space v405_5 = subtract(constant_0,v405_4);
        Space v405_8;
        if (!v405_5.empty()) {
          const Path v406_6 = concat_path(v404_6,v404_7_head);
          const Space v406_7 = routine_86(c, v406_6, v404_7_tail);
          v405_8 = compose(v405_5,v406_7);
        }
        const Space v405_9 = intersect(constant_6,v405_2);
        const Space v405_10 = (has_head(v405_9) ? constant_7 : Space{});
        Space v405_12;
        if (!v405_10.empty()) {
          const Path v407_6 = concat_path(v404_6,v404_7_head);
          const Space v407_11 = routine_87(c, v407_6, v404_7_tail);
          v405_12 = compose(v405_10,v407_11);
        }
        const Space v405_13 = unite(v405_8,v405_12);
        v404_7_result = unite(v404_7_result,v405_13);
      }
      const Space v404_7 = std::move(v404_7_result);
      v403_8 = compose(v403_5,v404_7);
    }
    const Space v403_9 = intersect(constant_6,v403_2);
    const Space v403_10 = (has_head(v403_9) ? constant_7 : Space{});
    const Space v403_11 = compose(v403_10,v402_8_tail);
    const Space v403_12 = unite(v403_8,v403_11);
    v402_8_result = unite(v402_8_result,v403_12);
  }
  const Space v402_8 = std::move(v402_8_result);
  return v402_8;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  Space v408_11_result;
  for (int v408_11_label = 1; v408_11_label <= 2; ++v408_11_label) {
    const Space v408_11_tail = child(s0,v408_11_label);
    if (v408_11_tail.empty()) continue;
    const Path v408_11_head{v408_11_label};
    const Space v409_2 = singleton(v408_11_head);
    const Space v409_3 = intersect(constant_6,v409_2);
    const Space v409_4 = (has_head(v409_3) ? constant_7 : Space{});
    const Space v409_5 = subtract(constant_0,v409_4);
    Space v409_8;
    if (!v409_5.empty()) {
      const Path v410_6 = concat_path(p0,v408_11_head);
      Space v410_7_result;
      for (int v410_7_label = 1; v410_7_label <= 2; ++v410_7_label) {
        const Space v410_7_tail = child(v408_11_tail,v410_7_label);
        if (v410_7_tail.empty()) continue;
        const Path v410_7_head{v410_7_label};
        const Space v411_2 = singleton(v410_7_head);
        const Space v411_3 = intersect(constant_6,v411_2);
        const Space v411_4 = (has_head(v411_3) ? constant_7 : Space{});
        const Space v411_5 = subtract(constant_0,v411_4);
        Space v411_8;
        if (!v411_5.empty()) {
          const Path v412_6 = concat_path(v410_6,v410_7_head);
          const Space v412_7 = routine_88(c, v412_6, v410_7_tail);
          v411_8 = compose(v411_5,v412_7);
        }
        const Space v411_9 = intersect(constant_6,v411_2);
        const Space v411_10 = (has_head(v411_9) ? constant_7 : Space{});
        Space v411_12;
        if (!v411_10.empty()) {
          const Path v413_6 = concat_path(v410_6,v410_7_head);
          const Space v413_11 = routine_89(c, v413_6, v410_7_tail);
          v411_12 = compose(v411_10,v413_11);
        }
        const Space v411_13 = unite(v411_8,v411_12);
        v410_7_result = unite(v410_7_result,v411_13);
      }
      const Space v410_7 = std::move(v410_7_result);
      v409_8 = compose(v409_5,v410_7);
    }
    const Space v409_9 = intersect(constant_6,v409_2);
    const Space v409_10 = (has_head(v409_9) ? constant_7 : Space{});
    Space v409_12;
    if (!v409_10.empty()) {
      const Path v414_6 = concat_path(p0,v408_11_head);
      Space v414_11_result;
      for (int v414_11_label = 1; v414_11_label <= 2; ++v414_11_label) {
        const Space v414_11_tail = child(v408_11_tail,v414_11_label);
        if (v414_11_tail.empty()) continue;
        const Path v414_11_head{v414_11_label};
        const Space v415_2 = singleton(v414_11_head);
        const Space v415_3 = intersect(constant_6,v415_2);
        const Space v415_4 = (has_head(v415_3) ? constant_7 : Space{});
        const Space v415_5 = subtract(constant_0,v415_4);
        Space v415_8;
        if (!v415_5.empty()) {
          const Path v416_6 = concat_path(v414_6,v414_11_head);
          const Space v416_7 = routine_88(c, v416_6, v414_11_tail);
          v415_8 = compose(v415_5,v416_7);
        }
        const Space v415_9 = intersect(constant_6,v415_2);
        const Space v415_10 = (has_head(v415_9) ? constant_7 : Space{});
        Space v415_12;
        if (!v415_10.empty()) {
          const Path v417_6 = concat_path(v414_6,v414_11_head);
          const Space v417_11 = routine_14(c, v417_6, v414_11_tail);
          v415_12 = compose(v415_10,v417_11);
        }
        const Space v415_13 = unite(v415_8,v415_12);
        v414_11_result = unite(v414_11_result,v415_13);
      }
      const Space v414_11 = std::move(v414_11_result);
      v409_12 = compose(v409_10,v414_11);
    }
    const Space v409_13 = unite(v409_8,v409_12);
    v408_11_result = unite(v408_11_result,v409_13);
  }
  const Space v408_11 = std::move(v408_11_result);
  return v408_11;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  Space v418_11_result;
  for (int v418_11_label = 1; v418_11_label <= 2; ++v418_11_label) {
    const Space v418_11_tail = child(s0,v418_11_label);
    if (v418_11_tail.empty()) continue;
    const Path v418_11_head{v418_11_label};
    const Space v419_2 = singleton(v418_11_head);
    const Space v419_3 = intersect(constant_6,v419_2);
    const Space v419_4 = (has_head(v419_3) ? constant_7 : Space{});
    const Space v419_5 = subtract(constant_0,v419_4);
    Space v419_8;
    if (!v419_5.empty()) {
      const Path v420_6 = concat_path(p0,v418_11_head);
      Space v420_7_result;
      for (int v420_7_label = 1; v420_7_label <= 2; ++v420_7_label) {
        const Space v420_7_tail = child(v418_11_tail,v420_7_label);
        if (v420_7_tail.empty()) continue;
        const Path v420_7_head{v420_7_label};
        const Space v421_2 = singleton(v420_7_head);
        const Space v421_3 = intersect(constant_6,v421_2);
        const Space v421_4 = (has_head(v421_3) ? constant_7 : Space{});
        const Space v421_5 = subtract(constant_0,v421_4);
        Space v421_8;
        if (!v421_5.empty()) {
          const Path v422_6 = concat_path(v420_6,v420_7_head);
          const Space v422_7 = routine_88(c, v422_6, v420_7_tail);
          v421_8 = compose(v421_5,v422_7);
        }
        const Space v421_9 = intersect(constant_6,v421_2);
        const Space v421_10 = (has_head(v421_9) ? constant_7 : Space{});
        Space v421_12;
        if (!v421_10.empty()) {
          const Path v423_6 = concat_path(v420_6,v420_7_head);
          const Space v423_11 = routine_89(c, v423_6, v420_7_tail);
          v421_12 = compose(v421_10,v423_11);
        }
        const Space v421_13 = unite(v421_8,v421_12);
        v420_7_result = unite(v420_7_result,v421_13);
      }
      const Space v420_7 = std::move(v420_7_result);
      v419_8 = compose(v419_5,v420_7);
    }
    const Space v419_9 = intersect(constant_6,v419_2);
    const Space v419_10 = (has_head(v419_9) ? constant_7 : Space{});
    Space v419_12;
    if (!v419_10.empty()) {
      const Path v424_6 = concat_path(p0,v418_11_head);
      Space v424_11_result;
      for (int v424_11_label = 1; v424_11_label <= 2; ++v424_11_label) {
        const Space v424_11_tail = child(v418_11_tail,v424_11_label);
        if (v424_11_tail.empty()) continue;
        const Path v424_11_head{v424_11_label};
        const Space v425_2 = singleton(v424_11_head);
        const Space v425_3 = intersect(constant_6,v425_2);
        const Space v425_4 = (has_head(v425_3) ? constant_7 : Space{});
        const Space v425_5 = subtract(constant_0,v425_4);
        Space v425_7;
        if (!v425_5.empty()) {
          const Space v426_6 = routine_15(c, v424_11_head, v424_6, v424_11_tail);
          v425_7 = compose(v425_5,v426_6);
        }
        const Space v425_8 = intersect(constant_6,v425_2);
        const Space v425_9 = (has_head(v425_8) ? constant_7 : Space{});
        Space v425_11;
        if (!v425_9.empty()) {
          const Space v427_10 = routine_16(c, v424_11_head, v424_6, v424_11_tail);
          v425_11 = compose(v425_9,v427_10);
        }
        const Space v425_12 = unite(v425_7,v425_11);
        v424_11_result = unite(v424_11_result,v425_12);
      }
      const Space v424_11 = std::move(v424_11_result);
      v419_12 = compose(v419_10,v424_11);
    }
    const Space v419_13 = unite(v419_8,v419_12);
    v418_11_result = unite(v418_11_result,v419_13);
  }
  const Space v418_11 = std::move(v418_11_result);
  return v418_11;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v428_12_result;
  for (int v428_12_label = 1; v428_12_label <= 2; ++v428_12_label) {
    const Space v428_12_tail = child(s0,v428_12_label);
    if (v428_12_tail.empty()) continue;
    const Path v428_12_head{v428_12_label};
    const Space v429_2 = singleton(v428_12_head);
    const Space v429_3 = intersect(constant_6,v429_2);
    const Space v429_4 = (has_head(v429_3) ? constant_7 : Space{});
    const Space v429_5 = subtract(constant_0,v429_4);
    Space v429_8;
    if (!v429_5.empty()) {
      const Path v430_6 = concat_path(p0,v428_12_head);
      Space v430_7_result;
      for (int v430_7_label = 1; v430_7_label <= 2; ++v430_7_label) {
        const Space v430_7_tail = child(v428_12_tail,v430_7_label);
        if (v430_7_tail.empty()) continue;
        const Path v430_7_head{v430_7_label};
        const Space v431_2 = singleton(v430_7_head);
        const Space v431_3 = intersect(constant_6,v431_2);
        const Space v431_4 = (has_head(v431_3) ? constant_7 : Space{});
        const Space v431_5 = subtract(constant_0,v431_4);
        Space v431_8;
        if (!v431_5.empty()) {
          const Path v432_6 = concat_path(v430_6,v430_7_head);
          const Space v432_7 = routine_90(c, v432_6, p1, v430_7_tail);
          v431_8 = compose(v431_5,v432_7);
        }
        const Space v431_9 = intersect(constant_6,v431_2);
        const Space v431_10 = (has_head(v431_9) ? constant_7 : Space{});
        Space v431_12;
        if (!v431_10.empty()) {
          const Path v433_6 = concat_path(v430_6,v430_7_head);
          const Space v433_11 = routine_91(c, v433_6, p1, v430_7_tail);
          v431_12 = compose(v431_10,v433_11);
        }
        const Space v431_13 = unite(v431_8,v431_12);
        v430_7_result = unite(v430_7_result,v431_13);
      }
      const Space v430_7 = std::move(v430_7_result);
      v429_8 = compose(v429_5,v430_7);
    }
    const Space v429_9 = intersect(constant_6,v429_2);
    const Space v429_10 = (has_head(v429_9) ? constant_7 : Space{});
    Space v429_12;
    if (!v429_10.empty()) {
      const Path v434_6 = concat_path(p0,v428_12_head);
      Space v434_11_result;
      for (int v434_11_label = 1; v434_11_label <= 2; ++v434_11_label) {
        const Space v434_11_tail = child(v428_12_tail,v434_11_label);
        if (v434_11_tail.empty()) continue;
        const Path v434_11_head{v434_11_label};
        const Space v435_2 = singleton(v434_11_head);
        const Space v435_3 = intersect(constant_6,v435_2);
        const Space v435_4 = (has_head(v435_3) ? constant_7 : Space{});
        const Space v435_5 = subtract(constant_0,v435_4);
        Space v435_8;
        if (!v435_5.empty()) {
          const Path v436_6 = concat_path(v434_6,v434_11_head);
          const Space v436_7 = routine_90(c, v436_6, p1, v434_11_tail);
          v435_8 = compose(v435_5,v436_7);
        }
        const Space v435_9 = intersect(constant_6,v435_2);
        const Space v435_10 = (has_head(v435_9) ? constant_7 : Space{});
        Space v435_12;
        if (!v435_10.empty()) {
          const Path v437_6 = concat_path(v434_6,v434_11_head);
          const Space v437_11 = routine_42(c, v437_6, p1, v434_11_tail);
          v435_12 = compose(v435_10,v437_11);
        }
        const Space v435_13 = unite(v435_8,v435_12);
        v434_11_result = unite(v434_11_result,v435_13);
      }
      const Space v434_11 = std::move(v434_11_result);
      v429_12 = compose(v429_10,v434_11);
    }
    const Space v429_13 = unite(v429_8,v429_12);
    v428_12_result = unite(v428_12_result,v429_13);
  }
  const Space v428_12 = std::move(v428_12_result);
  return v428_12;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v438_9_result;
  for (int v438_9_label = 1; v438_9_label <= 2; ++v438_9_label) {
    const Space v438_9_tail = child(s0,v438_9_label);
    if (v438_9_tail.empty()) continue;
    const Path v438_9_head{v438_9_label};
    const Space v439_2 = singleton(v438_9_head);
    const Space v439_3 = intersect(constant_6,v439_2);
    const Space v439_4 = (has_head(v439_3) ? constant_7 : Space{});
    const Space v439_5 = subtract(constant_0,v439_4);
    Space v439_8;
    if (!v439_5.empty()) {
      const Path v440_6 = concat_path(p0,v438_9_head);
      Space v440_7_result;
      for (int v440_7_label = 1; v440_7_label <= 2; ++v440_7_label) {
        const Space v440_7_tail = child(v438_9_tail,v440_7_label);
        if (v440_7_tail.empty()) continue;
        const Path v440_7_head{v440_7_label};
        const Space v441_2 = singleton(v440_7_head);
        const Space v441_3 = intersect(constant_6,v441_2);
        const Space v441_4 = (has_head(v441_3) ? constant_7 : Space{});
        const Space v441_5 = subtract(constant_0,v441_4);
        Space v441_8;
        if (!v441_5.empty()) {
          const Path v442_6 = concat_path(v440_6,v440_7_head);
          const Space v442_7 = routine_90(c, v442_6, p1, v440_7_tail);
          v441_8 = compose(v441_5,v442_7);
        }
        const Space v441_9 = intersect(constant_6,v441_2);
        const Space v441_10 = (has_head(v441_9) ? constant_7 : Space{});
        Space v441_12;
        if (!v441_10.empty()) {
          const Path v443_6 = concat_path(v440_6,v440_7_head);
          const Space v443_11 = routine_91(c, v443_6, p1, v440_7_tail);
          v441_12 = compose(v441_10,v443_11);
        }
        const Space v441_13 = unite(v441_8,v441_12);
        v440_7_result = unite(v440_7_result,v441_13);
      }
      const Space v440_7 = std::move(v440_7_result);
      v439_8 = compose(v439_5,v440_7);
    }
    const Space v439_9 = intersect(constant_6,v439_2);
    const Space v439_10 = (has_head(v439_9) ? constant_7 : Space{});
    Space v439_13;
    if (!v439_10.empty()) {
      const Path v444_6 = concat_path(p0,v438_9_head);
      const Path v444_11 = concat_path(p1,v444_6);
      const Space v444_12 = routine_29(c, v444_11);
      v439_13 = compose(v439_10,v444_12);
    }
    const Space v439_14 = unite(v439_8,v439_13);
    v438_9_result = unite(v438_9_result,v439_14);
  }
  const Space v438_9 = std::move(v438_9_result);
  return v438_9;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v445_3 = concat_path(p1,p0);
  const Space v445_4 = singleton(v445_3);
  Space v445_8_result;
  for (int v445_8_label = 1; v445_8_label <= 2; ++v445_8_label) {
    const Space v445_8_tail = child(v445_4,v445_8_label);
    if (v445_8_tail.empty()) continue;
    const Path v445_8_head{v445_8_label};
    const Space v446_2 = singleton(v445_8_head);
    const Space v446_3 = intersect(constant_6,v446_2);
    const Space v446_4 = (has_head(v446_3) ? constant_7 : Space{});
    const Space v446_5 = subtract(constant_0,v446_4);
    Space v446_7;
    if (!v446_5.empty()) {
      const Space v447_6 = routine_63(c, v445_8_head, v445_8_tail);
      v446_7 = compose(v446_5,v447_6);
    }
    const Space v446_8 = intersect(constant_6,v446_2);
    const Space v446_9 = (has_head(v446_8) ? constant_7 : Space{});
    Space v446_11;
    if (!v446_9.empty()) {
      const Space v448_10 = routine_64(c, v445_8_head, v445_8_tail);
      v446_11 = compose(v446_9,v448_10);
    }
    const Space v446_12 = unite(v446_7,v446_11);
    v445_8_result = unite(v445_8_result,v446_12);
  }
  const Space v445_8 = std::move(v445_8_result);
  return v445_8;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v449_12_result;
  for (int v449_12_label = 1; v449_12_label <= 2; ++v449_12_label) {
    const Space v449_12_tail = child(s0,v449_12_label);
    if (v449_12_tail.empty()) continue;
    const Path v449_12_head{v449_12_label};
    const Space v450_2 = singleton(v449_12_head);
    const Space v450_3 = intersect(constant_6,v450_2);
    const Space v450_4 = (has_head(v450_3) ? constant_7 : Space{});
    const Space v450_5 = subtract(constant_0,v450_4);
    Space v450_8;
    if (!v450_5.empty()) {
      const Path v451_6 = concat_path(p0,v449_12_head);
      Space v451_7_result;
      for (int v451_7_label = 1; v451_7_label <= 2; ++v451_7_label) {
        const Space v451_7_tail = child(v449_12_tail,v451_7_label);
        if (v451_7_tail.empty()) continue;
        const Path v451_7_head{v451_7_label};
        const Space v452_2 = singleton(v451_7_head);
        const Space v452_3 = intersect(constant_6,v452_2);
        const Space v452_4 = (has_head(v452_3) ? constant_7 : Space{});
        const Space v452_5 = subtract(constant_0,v452_4);
        Space v452_8;
        if (!v452_5.empty()) {
          const Path v453_6 = concat_path(v451_6,v451_7_head);
          const Space v453_7 = routine_92(c, v453_6, p1, v451_7_tail);
          v452_8 = compose(v452_5,v453_7);
        }
        const Space v452_9 = intersect(constant_6,v452_2);
        const Space v452_10 = (has_head(v452_9) ? constant_7 : Space{});
        Space v452_12;
        if (!v452_10.empty()) {
          const Path v454_6 = concat_path(v451_6,v451_7_head);
          const Space v454_11 = routine_93(c, v454_6, p1, v451_7_tail);
          v452_12 = compose(v452_10,v454_11);
        }
        const Space v452_13 = unite(v452_8,v452_12);
        v451_7_result = unite(v451_7_result,v452_13);
      }
      const Space v451_7 = std::move(v451_7_result);
      v450_8 = compose(v450_5,v451_7);
    }
    const Space v450_9 = intersect(constant_6,v450_2);
    const Space v450_10 = (has_head(v450_9) ? constant_7 : Space{});
    Space v450_12;
    if (!v450_10.empty()) {
      const Path v455_6 = concat_path(p0,v449_12_head);
      Space v455_11_result;
      for (int v455_11_label = 1; v455_11_label <= 2; ++v455_11_label) {
        const Space v455_11_tail = child(v449_12_tail,v455_11_label);
        if (v455_11_tail.empty()) continue;
        const Path v455_11_head{v455_11_label};
        const Space v456_2 = singleton(v455_11_head);
        const Space v456_3 = intersect(constant_6,v456_2);
        const Space v456_4 = (has_head(v456_3) ? constant_7 : Space{});
        const Space v456_5 = subtract(constant_0,v456_4);
        Space v456_8;
        if (!v456_5.empty()) {
          const Path v457_6 = concat_path(v455_6,v455_11_head);
          const Space v457_7 = routine_92(c, v457_6, p1, v455_11_tail);
          v456_8 = compose(v456_5,v457_7);
        }
        const Space v456_9 = intersect(constant_6,v456_2);
        const Space v456_10 = (has_head(v456_9) ? constant_7 : Space{});
        Space v456_12;
        if (!v456_10.empty()) {
          const Path v458_6 = concat_path(v455_6,v455_11_head);
          const Space v458_11 = routine_42(c, v458_6, p1, v455_11_tail);
          v456_12 = compose(v456_10,v458_11);
        }
        const Space v456_13 = unite(v456_8,v456_12);
        v455_11_result = unite(v455_11_result,v456_13);
      }
      const Space v455_11 = std::move(v455_11_result);
      v450_12 = compose(v450_10,v455_11);
    }
    const Space v450_13 = unite(v450_8,v450_12);
    v449_12_result = unite(v449_12_result,v450_13);
  }
  const Space v449_12 = std::move(v449_12_result);
  return v449_12;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v459_9_result;
  for (int v459_9_label = 1; v459_9_label <= 2; ++v459_9_label) {
    const Space v459_9_tail = child(s0,v459_9_label);
    if (v459_9_tail.empty()) continue;
    const Path v459_9_head{v459_9_label};
    const Space v460_2 = singleton(v459_9_head);
    const Space v460_3 = intersect(constant_6,v460_2);
    const Space v460_4 = (has_head(v460_3) ? constant_7 : Space{});
    const Space v460_5 = subtract(constant_0,v460_4);
    Space v460_8;
    if (!v460_5.empty()) {
      const Path v461_6 = concat_path(p0,v459_9_head);
      Space v461_7_result;
      for (int v461_7_label = 1; v461_7_label <= 2; ++v461_7_label) {
        const Space v461_7_tail = child(v459_9_tail,v461_7_label);
        if (v461_7_tail.empty()) continue;
        const Path v461_7_head{v461_7_label};
        const Space v462_2 = singleton(v461_7_head);
        const Space v462_3 = intersect(constant_6,v462_2);
        const Space v462_4 = (has_head(v462_3) ? constant_7 : Space{});
        const Space v462_5 = subtract(constant_0,v462_4);
        Space v462_8;
        if (!v462_5.empty()) {
          const Path v463_6 = concat_path(v461_6,v461_7_head);
          const Space v463_7 = routine_92(c, v463_6, p1, v461_7_tail);
          v462_8 = compose(v462_5,v463_7);
        }
        const Space v462_9 = intersect(constant_6,v462_2);
        const Space v462_10 = (has_head(v462_9) ? constant_7 : Space{});
        Space v462_12;
        if (!v462_10.empty()) {
          const Path v464_6 = concat_path(v461_6,v461_7_head);
          const Space v464_11 = routine_93(c, v464_6, p1, v461_7_tail);
          v462_12 = compose(v462_10,v464_11);
        }
        const Space v462_13 = unite(v462_8,v462_12);
        v461_7_result = unite(v461_7_result,v462_13);
      }
      const Space v461_7 = std::move(v461_7_result);
      v460_8 = compose(v460_5,v461_7);
    }
    const Space v460_9 = intersect(constant_6,v460_2);
    const Space v460_10 = (has_head(v460_9) ? constant_7 : Space{});
    Space v460_13;
    if (!v460_10.empty()) {
      const Path v465_6 = concat_path(p0,v459_9_head);
      const Path v465_11 = concat_path(p1,v465_6);
      const Space v465_12 = routine_29(c, v465_11);
      v460_13 = compose(v460_10,v465_12);
    }
    const Space v460_14 = unite(v460_8,v460_13);
    v459_9_result = unite(v459_9_result,v460_14);
  }
  const Space v459_9 = std::move(v459_9_result);
  return v459_9;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v466_12_result;
  for (int v466_12_label = 1; v466_12_label <= 2; ++v466_12_label) {
    const Space v466_12_tail = child(s0,v466_12_label);
    if (v466_12_tail.empty()) continue;
    const Path v466_12_head{v466_12_label};
    const Space v467_2 = singleton(v466_12_head);
    const Space v467_3 = intersect(constant_6,v467_2);
    const Space v467_4 = (has_head(v467_3) ? constant_7 : Space{});
    const Space v467_5 = subtract(constant_0,v467_4);
    Space v467_8;
    if (!v467_5.empty()) {
      const Path v468_6 = concat_path(p0,v466_12_head);
      Space v468_7_result;
      for (int v468_7_label = 1; v468_7_label <= 2; ++v468_7_label) {
        const Space v468_7_tail = child(v466_12_tail,v468_7_label);
        if (v468_7_tail.empty()) continue;
        const Path v468_7_head{v468_7_label};
        const Space v469_2 = singleton(v468_7_head);
        const Space v469_3 = intersect(constant_6,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_7 : Space{});
        const Space v469_5 = subtract(constant_0,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_7_head);
          const Space v470_7 = routine_94(c, v470_6, v468_7_tail, s1);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_6,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_7 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_7_head);
          const Space v471_11 = routine_95(c, v471_6, v468_7_tail, s1);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_7_result = unite(v468_7_result,v469_13);
      }
      const Space v468_7 = std::move(v468_7_result);
      v467_8 = compose(v467_5,v468_7);
    }
    const Space v467_9 = intersect(constant_6,v467_2);
    const Space v467_10 = (has_head(v467_9) ? constant_7 : Space{});
    Space v467_12;
    if (!v467_10.empty()) {
      const Path v472_6 = concat_path(p0,v466_12_head);
      Space v472_11_result;
      for (int v472_11_label = 1; v472_11_label <= 2; ++v472_11_label) {
        const Space v472_11_tail = child(v466_12_tail,v472_11_label);
        if (v472_11_tail.empty()) continue;
        const Path v472_11_head{v472_11_label};
        const Space v473_2 = singleton(v472_11_head);
        const Space v473_3 = intersect(constant_6,v473_2);
        const Space v473_4 = (has_head(v473_3) ? constant_7 : Space{});
        const Space v473_5 = subtract(constant_0,v473_4);
        Space v473_8;
        if (!v473_5.empty()) {
          const Path v474_6 = concat_path(v472_6,v472_11_head);
          const Space v474_7 = routine_94(c, v474_6, v472_11_tail, s1);
          v473_8 = compose(v473_5,v474_7);
        }
        const Space v473_9 = intersect(constant_6,v473_2);
        const Space v473_10 = (has_head(v473_9) ? constant_7 : Space{});
        Space v473_12;
        if (!v473_10.empty()) {
          const Path v475_6 = concat_path(v472_6,v472_11_head);
          const Space v475_11 = routine_19(c, v475_6, v472_11_tail, s1);
          v473_12 = compose(v473_10,v475_11);
        }
        const Space v473_13 = unite(v473_8,v473_12);
        v472_11_result = unite(v472_11_result,v473_13);
      }
      const Space v472_11 = std::move(v472_11_result);
      v467_12 = compose(v467_10,v472_11);
    }
    const Space v467_13 = unite(v467_8,v467_12);
    v466_12_result = unite(v466_12_result,v467_13);
  }
  const Space v466_12 = std::move(v466_12_result);
  return v466_12;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v476_12_result;
  for (int v476_12_label = 1; v476_12_label <= 2; ++v476_12_label) {
    const Space v476_12_tail = child(s0,v476_12_label);
    if (v476_12_tail.empty()) continue;
    const Path v476_12_head{v476_12_label};
    const Space v477_2 = singleton(v476_12_head);
    const Space v477_3 = intersect(constant_6,v477_2);
    const Space v477_4 = (has_head(v477_3) ? constant_7 : Space{});
    const Space v477_5 = subtract(constant_0,v477_4);
    Space v477_8;
    if (!v477_5.empty()) {
      const Path v478_6 = concat_path(p0,v476_12_head);
      Space v478_7_result;
      for (int v478_7_label = 1; v478_7_label <= 2; ++v478_7_label) {
        const Space v478_7_tail = child(v476_12_tail,v478_7_label);
        if (v478_7_tail.empty()) continue;
        const Path v478_7_head{v478_7_label};
        const Space v479_2 = singleton(v478_7_head);
        const Space v479_3 = intersect(constant_6,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_7 : Space{});
        const Space v479_5 = subtract(constant_0,v479_4);
        Space v479_8;
        if (!v479_5.empty()) {
          const Path v480_6 = concat_path(v478_6,v478_7_head);
          const Space v480_7 = routine_94(c, v480_6, v478_7_tail, s1);
          v479_8 = compose(v479_5,v480_7);
        }
        const Space v479_9 = intersect(constant_6,v479_2);
        const Space v479_10 = (has_head(v479_9) ? constant_7 : Space{});
        Space v479_12;
        if (!v479_10.empty()) {
          const Path v481_6 = concat_path(v478_6,v478_7_head);
          const Space v481_11 = routine_95(c, v481_6, v478_7_tail, s1);
          v479_12 = compose(v479_10,v481_11);
        }
        const Space v479_13 = unite(v479_8,v479_12);
        v478_7_result = unite(v478_7_result,v479_13);
      }
      const Space v478_7 = std::move(v478_7_result);
      v477_8 = compose(v477_5,v478_7);
    }
    const Space v477_9 = intersect(constant_6,v477_2);
    const Space v477_10 = (has_head(v477_9) ? constant_7 : Space{});
    Space v477_12;
    if (!v477_10.empty()) {
      const Path v482_6 = concat_path(p0,v476_12_head);
      Space v482_11_result;
      for (int v482_11_label = 1; v482_11_label <= 2; ++v482_11_label) {
        const Space v482_11_tail = child(v476_12_tail,v482_11_label);
        if (v482_11_tail.empty()) continue;
        const Path v482_11_head{v482_11_label};
        const Space v483_2 = singleton(v482_11_head);
        const Space v483_3 = intersect(constant_6,v483_2);
        const Space v483_4 = (has_head(v483_3) ? constant_7 : Space{});
        const Space v483_5 = subtract(constant_0,v483_4);
        Space v483_7;
        if (!v483_5.empty()) {
          const Space v484_6 = routine_20(c, v482_11_head, v482_6, v482_11_tail, s1);
          v483_7 = compose(v483_5,v484_6);
        }
        const Space v483_8 = intersect(constant_6,v483_2);
        const Space v483_9 = (has_head(v483_8) ? constant_7 : Space{});
        Space v483_11;
        if (!v483_9.empty()) {
          const Space v485_10 = routine_21(c, v482_11_head, v482_6, v482_11_tail, s1);
          v483_11 = compose(v483_9,v485_10);
        }
        const Space v483_12 = unite(v483_7,v483_11);
        v482_11_result = unite(v482_11_result,v483_12);
      }
      const Space v482_11 = std::move(v482_11_result);
      v477_12 = compose(v477_10,v482_11);
    }
    const Space v477_13 = unite(v477_8,v477_12);
    v476_12_result = unite(v476_12_result,v477_13);
  }
  const Space v476_12 = std::move(v476_12_result);
  return v476_12;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v486_13_result;
  for (int v486_13_label = 1; v486_13_label <= 2; ++v486_13_label) {
    const Space v486_13_tail = child(s0,v486_13_label);
    if (v486_13_tail.empty()) continue;
    const Path v486_13_head{v486_13_label};
    const Space v487_2 = singleton(v486_13_head);
    const Space v487_3 = intersect(constant_6,v487_2);
    const Space v487_4 = (has_head(v487_3) ? constant_7 : Space{});
    const Space v487_5 = subtract(constant_0,v487_4);
    Space v487_8;
    if (!v487_5.empty()) {
      const Path v488_6 = concat_path(p0,v486_13_head);
      Space v488_7_result;
      for (int v488_7_label = 1; v488_7_label <= 2; ++v488_7_label) {
        const Space v488_7_tail = child(v486_13_tail,v488_7_label);
        if (v488_7_tail.empty()) continue;
        const Path v488_7_head{v488_7_label};
        const Space v489_2 = singleton(v488_7_head);
        const Space v489_3 = intersect(constant_6,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_7 : Space{});
        const Space v489_5 = subtract(constant_0,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v488_6,v488_7_head);
          const Space v490_7 = routine_96(c, v490_6, p1, v488_7_tail, s1);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_6,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_7 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v488_6,v488_7_head);
          const Space v491_11 = routine_97(c, v491_6, p1, v488_7_tail, s1);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_7_result = unite(v488_7_result,v489_13);
      }
      const Space v488_7 = std::move(v488_7_result);
      v487_8 = compose(v487_5,v488_7);
    }
    const Space v487_9 = intersect(constant_6,v487_2);
    const Space v487_10 = (has_head(v487_9) ? constant_7 : Space{});
    Space v487_12;
    if (!v487_10.empty()) {
      const Path v492_6 = concat_path(p0,v486_13_head);
      Space v492_11_result;
      for (int v492_11_label = 1; v492_11_label <= 2; ++v492_11_label) {
        const Space v492_11_tail = child(v486_13_tail,v492_11_label);
        if (v492_11_tail.empty()) continue;
        const Path v492_11_head{v492_11_label};
        const Space v493_2 = singleton(v492_11_head);
        const Space v493_3 = intersect(constant_6,v493_2);
        const Space v493_4 = (has_head(v493_3) ? constant_7 : Space{});
        const Space v493_5 = subtract(constant_0,v493_4);
        Space v493_8;
        if (!v493_5.empty()) {
          const Path v494_6 = concat_path(v492_6,v492_11_head);
          const Space v494_7 = routine_96(c, v494_6, p1, v492_11_tail, s1);
          v493_8 = compose(v493_5,v494_7);
        }
        const Space v493_9 = intersect(constant_6,v493_2);
        const Space v493_10 = (has_head(v493_9) ? constant_7 : Space{});
        Space v493_12;
        if (!v493_10.empty()) {
          const Path v495_6 = concat_path(v492_6,v492_11_head);
          const Space v495_11 = routine_49(c, v495_6, p1, v492_11_tail, s1);
          v493_12 = compose(v493_10,v495_11);
        }
        const Space v493_13 = unite(v493_8,v493_12);
        v492_11_result = unite(v492_11_result,v493_13);
      }
      const Space v492_11 = std::move(v492_11_result);
      v487_12 = compose(v487_10,v492_11);
    }
    const Space v487_13 = unite(v487_8,v487_12);
    v486_13_result = unite(v486_13_result,v487_13);
  }
  const Space v486_13 = std::move(v486_13_result);
  return v486_13;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v496_8 = unwrap(s1,constant_8);
  Space v496_21_result;
  for (int v496_21_label = 1; v496_21_label <= 2; ++v496_21_label) {
    const Space v496_21_tail = child(s0,v496_21_label);
    if (v496_21_tail.empty()) continue;
    const Path v496_21_head{v496_21_label};
    const Space v497_2 = singleton(v496_21_head);
    const Space v497_3 = intersect(constant_6,v497_2);
    const Space v497_4 = (has_head(v497_3) ? constant_7 : Space{});
    const Space v497_5 = subtract(constant_0,v497_4);
    Space v497_8;
    if (!v497_5.empty()) {
      const Path v498_6 = concat_path(p0,v496_21_head);
      Space v498_7_result;
      for (int v498_7_label = 1; v498_7_label <= 2; ++v498_7_label) {
        const Space v498_7_tail = child(v496_21_tail,v498_7_label);
        if (v498_7_tail.empty()) continue;
        const Path v498_7_head{v498_7_label};
        const Space v499_2 = singleton(v498_7_head);
        const Space v499_3 = intersect(constant_6,v499_2);
        const Space v499_4 = (has_head(v499_3) ? constant_7 : Space{});
        const Space v499_5 = subtract(constant_0,v499_4);
        Space v499_8;
        if (!v499_5.empty()) {
          const Path v500_6 = concat_path(v498_6,v498_7_head);
          const Space v500_7 = routine_96(c, v500_6, p1, v498_7_tail, s1);
          v499_8 = compose(v499_5,v500_7);
        }
        const Space v499_9 = intersect(constant_6,v499_2);
        const Space v499_10 = (has_head(v499_9) ? constant_7 : Space{});
        Space v499_12;
        if (!v499_10.empty()) {
          const Path v501_6 = concat_path(v498_6,v498_7_head);
          const Space v501_11 = routine_97(c, v501_6, p1, v498_7_tail, s1);
          v499_12 = compose(v499_10,v501_11);
        }
        const Space v499_13 = unite(v499_8,v499_12);
        v498_7_result = unite(v498_7_result,v499_13);
      }
      const Space v498_7 = std::move(v498_7_result);
      v497_8 = compose(v497_5,v498_7);
    }
    const Space v497_9 = intersect(constant_6,v497_2);
    const Space v497_10 = (has_head(v497_9) ? constant_7 : Space{});
    Space v497_22;
    if (!v497_10.empty()) {
      const Path v502_6 = concat_path(p0,v496_21_head);
      const Path v502_11 = concat_path(p1,v502_6);
      const Space v502_12 = routine_29(c, v502_11);
      const Space v502_13 = intersect(v496_8,v502_12);
      const Space v502_14 = routine_33(c, v502_13);
      Space v502_15_result;
      for (int v502_15_label = 1; v502_15_label <= 2; ++v502_15_label) {
        const Space v502_15_tail = child(v502_14,v502_15_label);
        if (v502_15_tail.empty()) continue;
        const Path v502_15_head{v502_15_label};
        const Space v503_2 = singleton(v502_15_head);
        const Space v503_3 = intersect(constant_6,v503_2);
        const Space v503_4 = (has_head(v503_3) ? constant_7 : Space{});
        const Space v503_5 = subtract(constant_0,v503_4);
        Space v503_7;
        if (!v503_5.empty()) {
          const Space v504_6 = routine_52(c, v502_15_head, v502_15_tail);
          v503_7 = compose(v503_5,v504_6);
        }
        const Space v503_8 = intersect(constant_6,v503_2);
        const Space v503_9 = (has_head(v503_8) ? constant_7 : Space{});
        Space v503_11;
        if (!v503_9.empty()) {
          const Space v505_10 = routine_53(c, v502_15_head, v502_15_tail);
          v503_11 = compose(v503_9,v505_10);
        }
        const Space v503_12 = unite(v503_7,v503_11);
        v502_15_result = unite(v502_15_result,v503_12);
      }
      const Space v502_15 = std::move(v502_15_result);
      const Space v502_16 = routine_54(c, v502_13);
      Space v502_17_result;
      for (int v502_17_label = 1; v502_17_label <= 2; ++v502_17_label) {
        const Space v502_17_tail = child(v502_16,v502_17_label);
        if (v502_17_tail.empty()) continue;
        const Path v502_17_head{v502_17_label};
        const Space v506_2 = singleton(v502_17_head);
        const Space v506_3 = intersect(constant_6,v506_2);
        const Space v506_4 = (has_head(v506_3) ? constant_7 : Space{});
        const Space v506_5 = subtract(constant_0,v506_4);
        Space v506_7;
        if (!v506_5.empty()) {
          const Space v507_6 = routine_55(c, v502_17_head, v502_17_tail);
          v506_7 = compose(v506_5,v507_6);
        }
        const Space v506_8 = intersect(constant_6,v506_2);
        const Space v506_9 = (has_head(v506_8) ? constant_7 : Space{});
        Space v506_11;
        if (!v506_9.empty()) {
          const Space v508_10 = routine_56(c, v502_17_head, v502_17_tail);
          v506_11 = compose(v506_9,v508_10);
        }
        const Space v506_12 = unite(v506_7,v506_11);
        v502_17_result = unite(v502_17_result,v506_12);
      }
      const Space v502_17 = std::move(v502_17_result);
      const Space v502_18 = subtract(v502_15,v502_17);
      const Space v502_19 = singleton(v502_11);
      const Space v502_20 = compose(v502_18,v502_19);
      Space v502_21_result;
      for (int v502_21_label = 1; v502_21_label <= 2; ++v502_21_label) {
        const Space v502_21_tail = child(v502_20,v502_21_label);
        if (v502_21_tail.empty()) continue;
        const Path v502_21_head{v502_21_label};
        const Space v509_2 = singleton(v502_21_head);
        const Space v509_3 = intersect(constant_6,v509_2);
        const Space v509_4 = (has_head(v509_3) ? constant_7 : Space{});
        const Space v509_5 = subtract(constant_0,v509_4);
        Space v509_7;
        if (!v509_5.empty()) {
          const Space v510_6 = routine_57(c, v502_21_head, v502_21_tail);
          v509_7 = compose(v509_5,v510_6);
        }
        const Space v509_8 = intersect(constant_6,v509_2);
        const Space v509_9 = (has_head(v509_8) ? constant_7 : Space{});
        Space v509_11;
        if (!v509_9.empty()) {
          const Space v511_10 = routine_58(c, v502_21_head, v502_21_tail);
          v509_11 = compose(v509_9,v511_10);
        }
        const Space v509_12 = unite(v509_7,v509_11);
        v502_21_result = unite(v502_21_result,v509_12);
      }
      const Space v502_21 = std::move(v502_21_result);
      v497_22 = compose(v497_10,v502_21);
    }
    const Space v497_23 = unite(v497_8,v497_22);
    v496_21_result = unite(v496_21_result,v497_23);
  }
  const Space v496_21 = std::move(v496_21_result);
  return v496_21;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v512_5 = unwrap(s1,constant_8);
  const Path v512_6 = concat_path(p1,p0);
  const Space v512_7 = singleton(v512_6);
  Space v512_11_result;
  for (int v512_11_label = 1; v512_11_label <= 2; ++v512_11_label) {
    const Space v512_11_tail = child(v512_7,v512_11_label);
    if (v512_11_tail.empty()) continue;
    const Path v512_11_head{v512_11_label};
    const Space v513_2 = singleton(v512_11_head);
    const Space v513_3 = intersect(constant_6,v513_2);
    const Space v513_4 = (has_head(v513_3) ? constant_7 : Space{});
    const Space v513_5 = subtract(constant_0,v513_4);
    Space v513_7;
    if (!v513_5.empty()) {
      const Space v514_6 = routine_63(c, v512_11_head, v512_11_tail);
      v513_7 = compose(v513_5,v514_6);
    }
    const Space v513_8 = intersect(constant_6,v513_2);
    const Space v513_9 = (has_head(v513_8) ? constant_7 : Space{});
    Space v513_11;
    if (!v513_9.empty()) {
      const Space v515_10 = routine_64(c, v512_11_head, v512_11_tail);
      v513_11 = compose(v513_9,v515_10);
    }
    const Space v513_12 = unite(v513_7,v513_11);
    v512_11_result = unite(v512_11_result,v513_12);
  }
  const Space v512_11 = std::move(v512_11_result);
  const Space v512_12 = intersect(v512_5,v512_11);
  Space v512_16_result;
  for (int v512_16_label = 1; v512_16_label <= 2; ++v512_16_label) {
    const Space v512_16_tail = child(v512_7,v512_16_label);
    if (v512_16_tail.empty()) continue;
    const Path v512_16_head{v512_16_label};
    const Space v516_2 = singleton(v512_16_head);
    const Space v516_3 = intersect(constant_6,v516_2);
    const Space v516_4 = (has_head(v516_3) ? constant_7 : Space{});
    const Space v516_5 = subtract(constant_0,v516_4);
    Space v516_7;
    if (!v516_5.empty()) {
      const Space v517_6 = routine_63(c, v512_16_head, v512_16_tail);
      v516_7 = compose(v516_5,v517_6);
    }
    const Space v516_8 = intersect(constant_6,v516_2);
    const Space v516_9 = (has_head(v516_8) ? constant_7 : Space{});
    Space v516_11;
    if (!v516_9.empty()) {
      const Space v518_10 = routine_64(c, v512_16_head, v512_16_tail);
      v516_11 = compose(v516_9,v518_10);
    }
    const Space v516_12 = unite(v516_7,v516_11);
    v512_16_result = unite(v512_16_result,v516_12);
  }
  const Space v512_16 = std::move(v512_16_result);
  const Space v512_17 = intersect(v512_5,v512_16);
  const Space v512_18 = routine_66(c, v512_17);
  const Space v512_19 = routine_65(c, v512_18);
  const Space v512_20 = subtract(v512_12,v512_19);
  Space v512_24_result;
  for (int v512_24_label = 1; v512_24_label <= 2; ++v512_24_label) {
    const Space v512_24_tail = child(v512_7,v512_24_label);
    if (v512_24_tail.empty()) continue;
    const Path v512_24_head{v512_24_label};
    const Space v519_2 = singleton(v512_24_head);
    const Space v519_3 = intersect(constant_6,v519_2);
    const Space v519_4 = (has_head(v519_3) ? constant_7 : Space{});
    const Space v519_5 = subtract(constant_0,v519_4);
    Space v519_7;
    if (!v519_5.empty()) {
      const Space v520_6 = routine_63(c, v512_24_head, v512_24_tail);
      v519_7 = compose(v519_5,v520_6);
    }
    const Space v519_8 = intersect(constant_6,v519_2);
    const Space v519_9 = (has_head(v519_8) ? constant_7 : Space{});
    Space v519_11;
    if (!v519_9.empty()) {
      const Space v521_10 = routine_64(c, v512_24_head, v512_24_tail);
      v519_11 = compose(v519_9,v521_10);
    }
    const Space v519_12 = unite(v519_7,v519_11);
    v512_24_result = unite(v512_24_result,v519_12);
  }
  const Space v512_24 = std::move(v512_24_result);
  const Space v512_25 = intersect(v512_5,v512_24);
  const Space v512_26 = routine_65(c, v512_25);
  const Space v512_27 = intersect(v512_20,v512_26);
  Space v512_37_result;
  for (int v512_37_label = 1; v512_37_label <= 2; ++v512_37_label) {
    const Space v512_37_tail = child(v512_27,v512_37_label);
    if (v512_37_tail.empty()) continue;
    const Path v512_37_head{v512_37_label};
    const Space v522_2 = singleton(v512_37_head);
    const Space v522_3 = intersect(constant_6,v522_2);
    const Space v522_4 = (has_head(v522_3) ? constant_7 : Space{});
    const Space v522_5 = subtract(constant_0,v522_4);
    Space v522_7;
    if (!v522_5.empty()) {
      Space v523_6_result;
      for (int v523_6_label = 1; v523_6_label <= 2; ++v523_6_label) {
        const Space v523_6_tail = child(v512_37_tail,v523_6_label);
        if (v523_6_tail.empty()) continue;
        const Path v523_6_head{v523_6_label};
        const Space v524_2 = singleton(v523_6_head);
        const Space v524_3 = intersect(constant_6,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_7 : Space{});
        const Space v524_5 = subtract(constant_0,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v512_37_head,v523_6_head);
          const Space v525_7 = routine_98(c, v525_6, v523_6_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_6,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_7 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v512_37_head,v523_6_head);
          const Space v526_11 = routine_99(c, v526_6, v523_6_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_6_result = unite(v523_6_result,v524_13);
      }
      const Space v523_6 = std::move(v523_6_result);
      v522_7 = compose(v522_5,v523_6);
    }
    const Space v522_8 = intersect(constant_6,v522_2);
    const Space v522_9 = (has_head(v522_8) ? constant_7 : Space{});
    Space v522_11;
    if (!v522_9.empty()) {
      Space v527_10_result;
      for (int v527_10_label = 1; v527_10_label <= 2; ++v527_10_label) {
        const Space v527_10_tail = child(v512_37_tail,v527_10_label);
        if (v527_10_tail.empty()) continue;
        const Path v527_10_head{v527_10_label};
        const Space v528_2 = singleton(v527_10_head);
        const Space v528_3 = intersect(constant_6,v528_2);
        const Space v528_4 = (has_head(v528_3) ? constant_7 : Space{});
        const Space v528_5 = subtract(constant_0,v528_4);
        Space v528_8;
        if (!v528_5.empty()) {
          const Path v529_6 = concat_path(v512_37_head,v527_10_head);
          const Space v529_7 = routine_98(c, v529_6, v527_10_tail);
          v528_8 = compose(v528_5,v529_7);
        }
        const Space v528_9 = intersect(constant_6,v528_2);
        const Space v528_10 = (has_head(v528_9) ? constant_7 : Space{});
        Space v528_12;
        if (!v528_10.empty()) {
          const Path v530_6 = concat_path(v512_37_head,v527_10_head);
          const Space v530_11 = routine_100(c, v530_6, v527_10_tail);
          v528_12 = compose(v528_10,v530_11);
        }
        const Space v528_13 = unite(v528_8,v528_12);
        v527_10_result = unite(v527_10_result,v528_13);
      }
      const Space v527_10 = std::move(v527_10_result);
      v522_11 = compose(v522_9,v527_10);
    }
    const Space v522_12 = unite(v522_7,v522_11);
    v512_37_result = unite(v512_37_result,v522_12);
  }
  const Space v512_37 = std::move(v512_37_result);
  Space v512_41_result;
  for (int v512_41_label = 1; v512_41_label <= 2; ++v512_41_label) {
    const Space v512_41_tail = child(v512_7,v512_41_label);
    if (v512_41_tail.empty()) continue;
    const Path v512_41_head{v512_41_label};
    const Space v531_2 = singleton(v512_41_head);
    const Space v531_3 = intersect(constant_6,v531_2);
    const Space v531_4 = (has_head(v531_3) ? constant_7 : Space{});
    const Space v531_5 = subtract(constant_0,v531_4);
    Space v531_7;
    if (!v531_5.empty()) {
      const Space v532_6 = routine_63(c, v512_41_head, v512_41_tail);
      v531_7 = compose(v531_5,v532_6);
    }
    const Space v531_8 = intersect(constant_6,v531_2);
    const Space v531_9 = (has_head(v531_8) ? constant_7 : Space{});
    Space v531_11;
    if (!v531_9.empty()) {
      const Space v533_10 = routine_64(c, v512_41_head, v512_41_tail);
      v531_11 = compose(v531_9,v533_10);
    }
    const Space v531_12 = unite(v531_7,v531_11);
    v512_41_result = unite(v512_41_result,v531_12);
  }
  const Space v512_41 = std::move(v512_41_result);
  const Space v512_42 = intersect(v512_5,v512_41);
  Space v512_46_result;
  for (int v512_46_label = 1; v512_46_label <= 2; ++v512_46_label) {
    const Space v512_46_tail = child(v512_7,v512_46_label);
    if (v512_46_tail.empty()) continue;
    const Path v512_46_head{v512_46_label};
    const Space v534_2 = singleton(v512_46_head);
    const Space v534_3 = intersect(constant_6,v534_2);
    const Space v534_4 = (has_head(v534_3) ? constant_7 : Space{});
    const Space v534_5 = subtract(constant_0,v534_4);
    Space v534_7;
    if (!v534_5.empty()) {
      const Space v535_6 = routine_63(c, v512_46_head, v512_46_tail);
      v534_7 = compose(v534_5,v535_6);
    }
    const Space v534_8 = intersect(constant_6,v534_2);
    const Space v534_9 = (has_head(v534_8) ? constant_7 : Space{});
    Space v534_11;
    if (!v534_9.empty()) {
      const Space v536_10 = routine_64(c, v512_46_head, v512_46_tail);
      v534_11 = compose(v534_9,v536_10);
    }
    const Space v534_12 = unite(v534_7,v534_11);
    v512_46_result = unite(v512_46_result,v534_12);
  }
  const Space v512_46 = std::move(v512_46_result);
  const Space v512_47 = intersect(v512_5,v512_46);
  const Space v512_48 = routine_101(c, v512_47);
  const Space v512_49 = subtract(v512_42,v512_48);
  Space v512_53_result;
  for (int v512_53_label = 1; v512_53_label <= 2; ++v512_53_label) {
    const Space v512_53_tail = child(v512_7,v512_53_label);
    if (v512_53_tail.empty()) continue;
    const Path v512_53_head{v512_53_label};
    const Space v537_2 = singleton(v512_53_head);
    const Space v537_3 = intersect(constant_6,v537_2);
    const Space v537_4 = (has_head(v537_3) ? constant_7 : Space{});
    const Space v537_5 = subtract(constant_0,v537_4);
    Space v537_7;
    if (!v537_5.empty()) {
      const Space v538_6 = routine_63(c, v512_53_head, v512_53_tail);
      v537_7 = compose(v537_5,v538_6);
    }
    const Space v537_8 = intersect(constant_6,v537_2);
    const Space v537_9 = (has_head(v537_8) ? constant_7 : Space{});
    Space v537_11;
    if (!v537_9.empty()) {
      const Space v539_10 = routine_64(c, v512_53_head, v512_53_tail);
      v537_11 = compose(v537_9,v539_10);
    }
    const Space v537_12 = unite(v537_7,v537_11);
    v512_53_result = unite(v512_53_result,v537_12);
  }
  const Space v512_53 = std::move(v512_53_result);
  const Space v512_54 = intersect(v512_5,v512_53);
  const Space v512_55 = routine_66(c, v512_54);
  const Space v512_56 = routine_65(c, v512_55);
  const Space v512_57 = intersect(v512_49,v512_56);
  Space v512_67_result;
  for (int v512_67_label = 1; v512_67_label <= 2; ++v512_67_label) {
    const Space v512_67_tail = child(v512_57,v512_67_label);
    if (v512_67_tail.empty()) continue;
    const Path v512_67_head{v512_67_label};
    const Space v540_2 = singleton(v512_67_head);
    const Space v540_3 = intersect(constant_6,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_7 : Space{});
    const Space v540_5 = subtract(constant_0,v540_4);
    Space v540_7;
    if (!v540_5.empty()) {
      Space v541_6_result;
      for (int v541_6_label = 1; v541_6_label <= 2; ++v541_6_label) {
        const Space v541_6_tail = child(v512_67_tail,v541_6_label);
        if (v541_6_tail.empty()) continue;
        const Path v541_6_head{v541_6_label};
        const Space v542_2 = singleton(v541_6_head);
        const Space v542_3 = intersect(constant_6,v542_2);
        const Space v542_4 = (has_head(v542_3) ? constant_7 : Space{});
        const Space v542_5 = subtract(constant_0,v542_4);
        Space v542_8;
        if (!v542_5.empty()) {
          const Path v543_6 = concat_path(v512_67_head,v541_6_head);
          const Space v543_7 = routine_102(c, v543_6, v541_6_tail);
          v542_8 = compose(v542_5,v543_7);
        }
        const Space v542_9 = intersect(constant_6,v542_2);
        const Space v542_10 = (has_head(v542_9) ? constant_7 : Space{});
        Space v542_12;
        if (!v542_10.empty()) {
          const Path v544_6 = concat_path(v512_67_head,v541_6_head);
          const Space v544_11 = routine_103(c, v544_6, v541_6_tail);
          v542_12 = compose(v542_10,v544_11);
        }
        const Space v542_13 = unite(v542_8,v542_12);
        v541_6_result = unite(v541_6_result,v542_13);
      }
      const Space v541_6 = std::move(v541_6_result);
      v540_7 = compose(v540_5,v541_6);
    }
    const Space v540_8 = intersect(constant_6,v540_2);
    const Space v540_9 = (has_head(v540_8) ? constant_7 : Space{});
    Space v540_11;
    if (!v540_9.empty()) {
      Space v545_10_result;
      for (int v545_10_label = 1; v545_10_label <= 2; ++v545_10_label) {
        const Space v545_10_tail = child(v512_67_tail,v545_10_label);
        if (v545_10_tail.empty()) continue;
        const Path v545_10_head{v545_10_label};
        const Space v546_2 = singleton(v545_10_head);
        const Space v546_3 = intersect(constant_6,v546_2);
        const Space v546_4 = (has_head(v546_3) ? constant_7 : Space{});
        const Space v546_5 = subtract(constant_0,v546_4);
        Space v546_8;
        if (!v546_5.empty()) {
          const Path v547_6 = concat_path(v512_67_head,v545_10_head);
          const Space v547_7 = routine_102(c, v547_6, v545_10_tail);
          v546_8 = compose(v546_5,v547_7);
        }
        const Space v546_9 = intersect(constant_6,v546_2);
        const Space v546_10 = (has_head(v546_9) ? constant_7 : Space{});
        Space v546_12;
        if (!v546_10.empty()) {
          const Path v548_6 = concat_path(v512_67_head,v545_10_head);
          const Space v548_11 = routine_104(c, v548_6, v545_10_tail);
          v546_12 = compose(v546_10,v548_11);
        }
        const Space v546_13 = unite(v546_8,v546_12);
        v545_10_result = unite(v545_10_result,v546_13);
      }
      const Space v545_10 = std::move(v545_10_result);
      v540_11 = compose(v540_9,v545_10);
    }
    const Space v540_12 = unite(v540_7,v540_11);
    v512_67_result = unite(v512_67_result,v540_12);
  }
  const Space v512_67 = std::move(v512_67_result);
  const Space v512_68 = subtract(v512_37,v512_67);
  const Space v512_69 = compose(v512_68,v512_7);
  Space v512_79_result;
  for (int v512_79_label = 1; v512_79_label <= 2; ++v512_79_label) {
    const Space v512_79_tail = child(v512_69,v512_79_label);
    if (v512_79_tail.empty()) continue;
    const Path v512_79_head{v512_79_label};
    const Space v549_2 = singleton(v512_79_head);
    const Space v549_3 = intersect(constant_6,v549_2);
    const Space v549_4 = (has_head(v549_3) ? constant_7 : Space{});
    const Space v549_5 = subtract(constant_0,v549_4);
    Space v549_7;
    if (!v549_5.empty()) {
      Space v550_6_result;
      for (int v550_6_label = 1; v550_6_label <= 2; ++v550_6_label) {
        const Space v550_6_tail = child(v512_79_tail,v550_6_label);
        if (v550_6_tail.empty()) continue;
        const Path v550_6_head{v550_6_label};
        const Space v551_2 = singleton(v550_6_head);
        const Space v551_3 = intersect(constant_6,v551_2);
        const Space v551_4 = (has_head(v551_3) ? constant_7 : Space{});
        const Space v551_5 = subtract(constant_0,v551_4);
        Space v551_8;
        if (!v551_5.empty()) {
          const Path v552_6 = concat_path(v512_79_head,v550_6_head);
          const Space v552_7 = routine_105(c, v552_6, v550_6_tail);
          v551_8 = compose(v551_5,v552_7);
        }
        const Space v551_9 = intersect(constant_6,v551_2);
        const Space v551_10 = (has_head(v551_9) ? constant_7 : Space{});
        Space v551_12;
        if (!v551_10.empty()) {
          const Path v553_6 = concat_path(v512_79_head,v550_6_head);
          const Space v553_11 = routine_106(c, v553_6, v550_6_tail);
          v551_12 = compose(v551_10,v553_11);
        }
        const Space v551_13 = unite(v551_8,v551_12);
        v550_6_result = unite(v550_6_result,v551_13);
      }
      const Space v550_6 = std::move(v550_6_result);
      v549_7 = compose(v549_5,v550_6);
    }
    const Space v549_8 = intersect(constant_6,v549_2);
    const Space v549_9 = (has_head(v549_8) ? constant_7 : Space{});
    Space v549_11;
    if (!v549_9.empty()) {
      Space v554_10_result;
      for (int v554_10_label = 1; v554_10_label <= 2; ++v554_10_label) {
        const Space v554_10_tail = child(v512_79_tail,v554_10_label);
        if (v554_10_tail.empty()) continue;
        const Path v554_10_head{v554_10_label};
        const Space v555_2 = singleton(v554_10_head);
        const Space v555_3 = intersect(constant_6,v555_2);
        const Space v555_4 = (has_head(v555_3) ? constant_7 : Space{});
        const Space v555_5 = subtract(constant_0,v555_4);
        Space v555_8;
        if (!v555_5.empty()) {
          const Path v556_6 = concat_path(v512_79_head,v554_10_head);
          const Space v556_7 = routine_105(c, v556_6, v554_10_tail);
          v555_8 = compose(v555_5,v556_7);
        }
        const Space v555_9 = intersect(constant_6,v555_2);
        const Space v555_10 = (has_head(v555_9) ? constant_7 : Space{});
        Space v555_12;
        if (!v555_10.empty()) {
          const Path v557_6 = concat_path(v512_79_head,v554_10_head);
          const Space v557_11 = routine_107(c, v557_6, v554_10_tail);
          v555_12 = compose(v555_10,v557_11);
        }
        const Space v555_13 = unite(v555_8,v555_12);
        v554_10_result = unite(v554_10_result,v555_13);
      }
      const Space v554_10 = std::move(v554_10_result);
      v549_11 = compose(v549_9,v554_10);
    }
    const Space v549_12 = unite(v549_7,v549_11);
    v512_79_result = unite(v512_79_result,v549_12);
  }
  const Space v512_79 = std::move(v512_79_result);
  return v512_79;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v558_13_result;
  for (int v558_13_label = 1; v558_13_label <= 2; ++v558_13_label) {
    const Space v558_13_tail = child(s0,v558_13_label);
    if (v558_13_tail.empty()) continue;
    const Path v558_13_head{v558_13_label};
    const Space v559_2 = singleton(v558_13_head);
    const Space v559_3 = intersect(constant_6,v559_2);
    const Space v559_4 = (has_head(v559_3) ? constant_7 : Space{});
    const Space v559_5 = subtract(constant_0,v559_4);
    Space v559_8;
    if (!v559_5.empty()) {
      const Path v560_6 = concat_path(p0,v558_13_head);
      Space v560_7_result;
      for (int v560_7_label = 1; v560_7_label <= 2; ++v560_7_label) {
        const Space v560_7_tail = child(v558_13_tail,v560_7_label);
        if (v560_7_tail.empty()) continue;
        const Path v560_7_head{v560_7_label};
        const Space v561_2 = singleton(v560_7_head);
        const Space v561_3 = intersect(constant_6,v561_2);
        const Space v561_4 = (has_head(v561_3) ? constant_7 : Space{});
        const Space v561_5 = subtract(constant_0,v561_4);
        Space v561_8;
        if (!v561_5.empty()) {
          const Path v562_6 = concat_path(v560_6,v560_7_head);
          const Space v562_7 = routine_108(c, v562_6, p1, v560_7_tail, s1);
          v561_8 = compose(v561_5,v562_7);
        }
        const Space v561_9 = intersect(constant_6,v561_2);
        const Space v561_10 = (has_head(v561_9) ? constant_7 : Space{});
        Space v561_12;
        if (!v561_10.empty()) {
          const Path v563_6 = concat_path(v560_6,v560_7_head);
          const Space v563_11 = routine_109(c, v563_6, p1, v560_7_tail, s1);
          v561_12 = compose(v561_10,v563_11);
        }
        const Space v561_13 = unite(v561_8,v561_12);
        v560_7_result = unite(v560_7_result,v561_13);
      }
      const Space v560_7 = std::move(v560_7_result);
      v559_8 = compose(v559_5,v560_7);
    }
    const Space v559_9 = intersect(constant_6,v559_2);
    const Space v559_10 = (has_head(v559_9) ? constant_7 : Space{});
    Space v559_12;
    if (!v559_10.empty()) {
      const Path v564_6 = concat_path(p0,v558_13_head);
      Space v564_11_result;
      for (int v564_11_label = 1; v564_11_label <= 2; ++v564_11_label) {
        const Space v564_11_tail = child(v558_13_tail,v564_11_label);
        if (v564_11_tail.empty()) continue;
        const Path v564_11_head{v564_11_label};
        const Space v565_2 = singleton(v564_11_head);
        const Space v565_3 = intersect(constant_6,v565_2);
        const Space v565_4 = (has_head(v565_3) ? constant_7 : Space{});
        const Space v565_5 = subtract(constant_0,v565_4);
        Space v565_8;
        if (!v565_5.empty()) {
          const Path v566_6 = concat_path(v564_6,v564_11_head);
          const Space v566_7 = routine_108(c, v566_6, p1, v564_11_tail, s1);
          v565_8 = compose(v565_5,v566_7);
        }
        const Space v565_9 = intersect(constant_6,v565_2);
        const Space v565_10 = (has_head(v565_9) ? constant_7 : Space{});
        Space v565_12;
        if (!v565_10.empty()) {
          const Path v567_6 = concat_path(v564_6,v564_11_head);
          const Space v567_11 = routine_49(c, v567_6, p1, v564_11_tail, s1);
          v565_12 = compose(v565_10,v567_11);
        }
        const Space v565_13 = unite(v565_8,v565_12);
        v564_11_result = unite(v564_11_result,v565_13);
      }
      const Space v564_11 = std::move(v564_11_result);
      v559_12 = compose(v559_10,v564_11);
    }
    const Space v559_13 = unite(v559_8,v559_12);
    v558_13_result = unite(v558_13_result,v559_13);
  }
  const Space v558_13 = std::move(v558_13_result);
  return v558_13;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v568_8 = unwrap(s1,constant_8);
  Space v568_21_result;
  for (int v568_21_label = 1; v568_21_label <= 2; ++v568_21_label) {
    const Space v568_21_tail = child(s0,v568_21_label);
    if (v568_21_tail.empty()) continue;
    const Path v568_21_head{v568_21_label};
    const Space v569_2 = singleton(v568_21_head);
    const Space v569_3 = intersect(constant_6,v569_2);
    const Space v569_4 = (has_head(v569_3) ? constant_7 : Space{});
    const Space v569_5 = subtract(constant_0,v569_4);
    Space v569_8;
    if (!v569_5.empty()) {
      const Path v570_6 = concat_path(p0,v568_21_head);
      Space v570_7_result;
      for (int v570_7_label = 1; v570_7_label <= 2; ++v570_7_label) {
        const Space v570_7_tail = child(v568_21_tail,v570_7_label);
        if (v570_7_tail.empty()) continue;
        const Path v570_7_head{v570_7_label};
        const Space v571_2 = singleton(v570_7_head);
        const Space v571_3 = intersect(constant_6,v571_2);
        const Space v571_4 = (has_head(v571_3) ? constant_7 : Space{});
        const Space v571_5 = subtract(constant_0,v571_4);
        Space v571_8;
        if (!v571_5.empty()) {
          const Path v572_6 = concat_path(v570_6,v570_7_head);
          const Space v572_7 = routine_108(c, v572_6, p1, v570_7_tail, s1);
          v571_8 = compose(v571_5,v572_7);
        }
        const Space v571_9 = intersect(constant_6,v571_2);
        const Space v571_10 = (has_head(v571_9) ? constant_7 : Space{});
        Space v571_12;
        if (!v571_10.empty()) {
          const Path v573_6 = concat_path(v570_6,v570_7_head);
          const Space v573_11 = routine_109(c, v573_6, p1, v570_7_tail, s1);
          v571_12 = compose(v571_10,v573_11);
        }
        const Space v571_13 = unite(v571_8,v571_12);
        v570_7_result = unite(v570_7_result,v571_13);
      }
      const Space v570_7 = std::move(v570_7_result);
      v569_8 = compose(v569_5,v570_7);
    }
    const Space v569_9 = intersect(constant_6,v569_2);
    const Space v569_10 = (has_head(v569_9) ? constant_7 : Space{});
    Space v569_22;
    if (!v569_10.empty()) {
      const Path v574_6 = concat_path(p0,v568_21_head);
      const Path v574_11 = concat_path(p1,v574_6);
      const Space v574_12 = routine_29(c, v574_11);
      const Space v574_13 = intersect(v568_8,v574_12);
      const Space v574_14 = routine_33(c, v574_13);
      Space v574_15_result;
      for (int v574_15_label = 1; v574_15_label <= 2; ++v574_15_label) {
        const Space v574_15_tail = child(v574_14,v574_15_label);
        if (v574_15_tail.empty()) continue;
        const Path v574_15_head{v574_15_label};
        const Space v575_2 = singleton(v574_15_head);
        const Space v575_3 = intersect(constant_6,v575_2);
        const Space v575_4 = (has_head(v575_3) ? constant_7 : Space{});
        const Space v575_5 = subtract(constant_0,v575_4);
        Space v575_7;
        if (!v575_5.empty()) {
          const Space v576_6 = routine_52(c, v574_15_head, v574_15_tail);
          v575_7 = compose(v575_5,v576_6);
        }
        const Space v575_8 = intersect(constant_6,v575_2);
        const Space v575_9 = (has_head(v575_8) ? constant_7 : Space{});
        Space v575_11;
        if (!v575_9.empty()) {
          const Space v577_10 = routine_53(c, v574_15_head, v574_15_tail);
          v575_11 = compose(v575_9,v577_10);
        }
        const Space v575_12 = unite(v575_7,v575_11);
        v574_15_result = unite(v574_15_result,v575_12);
      }
      const Space v574_15 = std::move(v574_15_result);
      const Space v574_16 = routine_54(c, v574_13);
      Space v574_17_result;
      for (int v574_17_label = 1; v574_17_label <= 2; ++v574_17_label) {
        const Space v574_17_tail = child(v574_16,v574_17_label);
        if (v574_17_tail.empty()) continue;
        const Path v574_17_head{v574_17_label};
        const Space v578_2 = singleton(v574_17_head);
        const Space v578_3 = intersect(constant_6,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_7 : Space{});
        const Space v578_5 = subtract(constant_0,v578_4);
        Space v578_7;
        if (!v578_5.empty()) {
          const Space v579_6 = routine_55(c, v574_17_head, v574_17_tail);
          v578_7 = compose(v578_5,v579_6);
        }
        const Space v578_8 = intersect(constant_6,v578_2);
        const Space v578_9 = (has_head(v578_8) ? constant_7 : Space{});
        Space v578_11;
        if (!v578_9.empty()) {
          const Space v580_10 = routine_56(c, v574_17_head, v574_17_tail);
          v578_11 = compose(v578_9,v580_10);
        }
        const Space v578_12 = unite(v578_7,v578_11);
        v574_17_result = unite(v574_17_result,v578_12);
      }
      const Space v574_17 = std::move(v574_17_result);
      const Space v574_18 = subtract(v574_15,v574_17);
      const Space v574_19 = singleton(v574_11);
      const Space v574_20 = compose(v574_18,v574_19);
      Space v574_21_result;
      for (int v574_21_label = 1; v574_21_label <= 2; ++v574_21_label) {
        const Space v574_21_tail = child(v574_20,v574_21_label);
        if (v574_21_tail.empty()) continue;
        const Path v574_21_head{v574_21_label};
        const Space v581_2 = singleton(v574_21_head);
        const Space v581_3 = intersect(constant_6,v581_2);
        const Space v581_4 = (has_head(v581_3) ? constant_7 : Space{});
        const Space v581_5 = subtract(constant_0,v581_4);
        Space v581_7;
        if (!v581_5.empty()) {
          const Space v582_6 = routine_57(c, v574_21_head, v574_21_tail);
          v581_7 = compose(v581_5,v582_6);
        }
        const Space v581_8 = intersect(constant_6,v581_2);
        const Space v581_9 = (has_head(v581_8) ? constant_7 : Space{});
        Space v581_11;
        if (!v581_9.empty()) {
          const Space v583_10 = routine_58(c, v574_21_head, v574_21_tail);
          v581_11 = compose(v581_9,v583_10);
        }
        const Space v581_12 = unite(v581_7,v581_11);
        v574_21_result = unite(v574_21_result,v581_12);
      }
      const Space v574_21 = std::move(v574_21_result);
      v569_22 = compose(v569_10,v574_21);
    }
    const Space v569_23 = unite(v569_8,v569_22);
    v568_21_result = unite(v568_21_result,v569_23);
  }
  const Space v568_21 = std::move(v568_21_result);
  return v568_21;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v584_11_result;
  for (int v584_11_label = 1; v584_11_label <= 2; ++v584_11_label) {
    const Space v584_11_tail = child(s0,v584_11_label);
    if (v584_11_tail.empty()) continue;
    const Path v584_11_head{v584_11_label};
    const Space v585_2 = singleton(v584_11_head);
    const Space v585_3 = intersect(constant_6,v585_2);
    const Space v585_4 = (has_head(v585_3) ? constant_7 : Space{});
    const Space v585_5 = subtract(constant_0,v585_4);
    Space v585_8;
    if (!v585_5.empty()) {
      const Path v586_6 = concat_path(p0,v584_11_head);
      Space v586_7_result;
      for (int v586_7_label = 1; v586_7_label <= 2; ++v586_7_label) {
        const Space v586_7_tail = child(v584_11_tail,v586_7_label);
        if (v586_7_tail.empty()) continue;
        const Path v586_7_head{v586_7_label};
        const Space v587_2 = singleton(v586_7_head);
        const Space v587_3 = intersect(constant_6,v587_2);
        const Space v587_4 = (has_head(v587_3) ? constant_7 : Space{});
        const Space v587_5 = subtract(constant_0,v587_4);
        Space v587_8;
        if (!v587_5.empty()) {
          const Path v588_6 = concat_path(v586_6,v586_7_head);
          const Space v588_7 = routine_110(c, v588_6, v586_7_tail);
          v587_8 = compose(v587_5,v588_7);
        }
        const Space v587_9 = intersect(constant_6,v587_2);
        const Space v587_10 = (has_head(v587_9) ? constant_7 : Space{});
        Space v587_12;
        if (!v587_10.empty()) {
          const Path v589_6 = concat_path(v586_6,v586_7_head);
          const Space v589_11 = routine_111(c, v589_6, v586_7_tail);
          v587_12 = compose(v587_10,v589_11);
        }
        const Space v587_13 = unite(v587_8,v587_12);
        v586_7_result = unite(v586_7_result,v587_13);
      }
      const Space v586_7 = std::move(v586_7_result);
      v585_8 = compose(v585_5,v586_7);
    }
    const Space v585_9 = intersect(constant_6,v585_2);
    const Space v585_10 = (has_head(v585_9) ? constant_7 : Space{});
    Space v585_12;
    if (!v585_10.empty()) {
      const Path v590_6 = concat_path(p0,v584_11_head);
      Space v590_11_result;
      for (int v590_11_label = 1; v590_11_label <= 2; ++v590_11_label) {
        const Space v590_11_tail = child(v584_11_tail,v590_11_label);
        if (v590_11_tail.empty()) continue;
        const Path v590_11_head{v590_11_label};
        const Space v591_2 = singleton(v590_11_head);
        const Space v591_3 = intersect(constant_6,v591_2);
        const Space v591_4 = (has_head(v591_3) ? constant_7 : Space{});
        const Space v591_5 = subtract(constant_0,v591_4);
        Space v591_8;
        if (!v591_5.empty()) {
          const Path v592_6 = concat_path(v590_6,v590_11_head);
          const Space v592_7 = routine_110(c, v592_6, v590_11_tail);
          v591_8 = compose(v591_5,v592_7);
        }
        const Space v591_9 = intersect(constant_6,v591_2);
        const Space v591_10 = (has_head(v591_9) ? constant_7 : Space{});
        Space v591_12;
        if (!v591_10.empty()) {
          const Path v593_6 = concat_path(v590_6,v590_11_head);
          const Space v593_11 = routine_100(c, v593_6, v590_11_tail);
          v591_12 = compose(v591_10,v593_11);
        }
        const Space v591_13 = unite(v591_8,v591_12);
        v590_11_result = unite(v590_11_result,v591_13);
      }
      const Space v590_11 = std::move(v590_11_result);
      v585_12 = compose(v585_10,v590_11);
    }
    const Space v585_13 = unite(v585_8,v585_12);
    v584_11_result = unite(v584_11_result,v585_13);
  }
  const Space v584_11 = std::move(v584_11_result);
  return v584_11;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0) {
  Space v594_9_result;
  for (int v594_9_label = 1; v594_9_label <= 2; ++v594_9_label) {
    const Space v594_9_tail = child(s0,v594_9_label);
    if (v594_9_tail.empty()) continue;
    const Path v594_9_head{v594_9_label};
    const Space v595_2 = singleton(v594_9_head);
    const Space v595_3 = intersect(constant_6,v595_2);
    const Space v595_4 = (has_head(v595_3) ? constant_7 : Space{});
    const Space v595_5 = subtract(constant_0,v595_4);
    Space v595_8;
    if (!v595_5.empty()) {
      const Path v596_6 = concat_path(p0,v594_9_head);
      Space v596_7_result;
      for (int v596_7_label = 1; v596_7_label <= 2; ++v596_7_label) {
        const Space v596_7_tail = child(v594_9_tail,v596_7_label);
        if (v596_7_tail.empty()) continue;
        const Path v596_7_head{v596_7_label};
        const Space v597_2 = singleton(v596_7_head);
        const Space v597_3 = intersect(constant_6,v597_2);
        const Space v597_4 = (has_head(v597_3) ? constant_7 : Space{});
        const Space v597_5 = subtract(constant_0,v597_4);
        Space v597_8;
        if (!v597_5.empty()) {
          const Path v598_6 = concat_path(v596_6,v596_7_head);
          const Space v598_7 = routine_110(c, v598_6, v596_7_tail);
          v597_8 = compose(v597_5,v598_7);
        }
        const Space v597_9 = intersect(constant_6,v597_2);
        const Space v597_10 = (has_head(v597_9) ? constant_7 : Space{});
        Space v597_12;
        if (!v597_10.empty()) {
          const Path v599_6 = concat_path(v596_6,v596_7_head);
          const Space v599_11 = routine_111(c, v599_6, v596_7_tail);
          v597_12 = compose(v597_10,v599_11);
        }
        const Space v597_13 = unite(v597_8,v597_12);
        v596_7_result = unite(v596_7_result,v597_13);
      }
      const Space v596_7 = std::move(v596_7_result);
      v595_8 = compose(v595_5,v596_7);
    }
    const Space v595_9 = intersect(constant_6,v595_2);
    const Space v595_10 = (has_head(v595_9) ? constant_7 : Space{});
    const Space v595_11 = compose(v595_10,constant_9);
    const Space v595_12 = unite(v595_8,v595_11);
    v594_9_result = unite(v594_9_result,v595_12);
  }
  const Space v594_9 = std::move(v594_9_result);
  return v594_9;
}

static Space routine_54(Context& c, const Space& s0) {
  const Space v600_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v600_2 = first_matching(s0,constant_0,false);
  const Space v600_3 = unite(v600_1,v600_2);
  Space v600_6;
  if (!v600_3.empty()) {
    const Space v601_4 = routine_81(c, s0);
    const Space v601_5 = subtract(s0,v601_4);
    v600_6 = compose(v600_3,v601_5);
  }
  const Space v600_7 = (has_head(v600_6) ? constant_7 : Space{});
  const Space v600_8 = first_matching(v600_6,constant_0,false);
  const Space v600_9 = unite(v600_7,v600_8);
  Space v600_12;
  if (!v600_9.empty()) {
    const Space v602_10 = routine_66(c, v600_6);
    const Space v602_11 = routine_66(c, v602_10);
    v600_12 = compose(v600_9,v602_11);
  }
  Space v600_15;
  if (!v600_3.empty()) {
    const Space v603_13 = routine_65(c, s0);
    const Space v603_14 = routine_65(c, v603_13);
    v600_15 = compose(v600_3,v603_14);
  }
  const Space v600_16 = subtract(s0,v600_15);
  const Space v600_17 = intersect(v600_12,v600_16);
  return v600_17;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v604_11_result;
  for (int v604_11_label = 1; v604_11_label <= 2; ++v604_11_label) {
    const Space v604_11_tail = child(s0,v604_11_label);
    if (v604_11_tail.empty()) continue;
    const Path v604_11_head{v604_11_label};
    const Space v605_2 = singleton(v604_11_head);
    const Space v605_3 = intersect(constant_6,v605_2);
    const Space v605_4 = (has_head(v605_3) ? constant_7 : Space{});
    const Space v605_5 = subtract(constant_0,v605_4);
    Space v605_8;
    if (!v605_5.empty()) {
      const Path v606_6 = concat_path(p0,v604_11_head);
      Space v606_7_result;
      for (int v606_7_label = 1; v606_7_label <= 2; ++v606_7_label) {
        const Space v606_7_tail = child(v604_11_tail,v606_7_label);
        if (v606_7_tail.empty()) continue;
        const Path v606_7_head{v606_7_label};
        const Space v607_2 = singleton(v606_7_head);
        const Space v607_3 = intersect(constant_6,v607_2);
        const Space v607_4 = (has_head(v607_3) ? constant_7 : Space{});
        const Space v607_5 = subtract(constant_0,v607_4);
        Space v607_8;
        if (!v607_5.empty()) {
          const Path v608_6 = concat_path(v606_6,v606_7_head);
          const Space v608_7 = routine_112(c, v608_6, v606_7_tail);
          v607_8 = compose(v607_5,v608_7);
        }
        const Space v607_9 = intersect(constant_6,v607_2);
        const Space v607_10 = (has_head(v607_9) ? constant_7 : Space{});
        Space v607_12;
        if (!v607_10.empty()) {
          const Path v609_6 = concat_path(v606_6,v606_7_head);
          const Space v609_11 = routine_113(c, v609_6, v606_7_tail);
          v607_12 = compose(v607_10,v609_11);
        }
        const Space v607_13 = unite(v607_8,v607_12);
        v606_7_result = unite(v606_7_result,v607_13);
      }
      const Space v606_7 = std::move(v606_7_result);
      v605_8 = compose(v605_5,v606_7);
    }
    const Space v605_9 = intersect(constant_6,v605_2);
    const Space v605_10 = (has_head(v605_9) ? constant_7 : Space{});
    Space v605_12;
    if (!v605_10.empty()) {
      const Path v610_6 = concat_path(p0,v604_11_head);
      Space v610_11_result;
      for (int v610_11_label = 1; v610_11_label <= 2; ++v610_11_label) {
        const Space v610_11_tail = child(v604_11_tail,v610_11_label);
        if (v610_11_tail.empty()) continue;
        const Path v610_11_head{v610_11_label};
        const Space v611_2 = singleton(v610_11_head);
        const Space v611_3 = intersect(constant_6,v611_2);
        const Space v611_4 = (has_head(v611_3) ? constant_7 : Space{});
        const Space v611_5 = subtract(constant_0,v611_4);
        Space v611_8;
        if (!v611_5.empty()) {
          const Path v612_6 = concat_path(v610_6,v610_11_head);
          const Space v612_7 = routine_112(c, v612_6, v610_11_tail);
          v611_8 = compose(v611_5,v612_7);
        }
        const Space v611_9 = intersect(constant_6,v611_2);
        const Space v611_10 = (has_head(v611_9) ? constant_7 : Space{});
        Space v611_12;
        if (!v611_10.empty()) {
          const Path v613_6 = concat_path(v610_6,v610_11_head);
          const Space v613_11 = routine_104(c, v613_6, v610_11_tail);
          v611_12 = compose(v611_10,v613_11);
        }
        const Space v611_13 = unite(v611_8,v611_12);
        v610_11_result = unite(v610_11_result,v611_13);
      }
      const Space v610_11 = std::move(v610_11_result);
      v605_12 = compose(v605_10,v610_11);
    }
    const Space v605_13 = unite(v605_8,v605_12);
    v604_11_result = unite(v604_11_result,v605_13);
  }
  const Space v604_11 = std::move(v604_11_result);
  return v604_11;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v614_9_result;
  for (int v614_9_label = 1; v614_9_label <= 2; ++v614_9_label) {
    const Space v614_9_tail = child(s0,v614_9_label);
    if (v614_9_tail.empty()) continue;
    const Path v614_9_head{v614_9_label};
    const Space v615_2 = singleton(v614_9_head);
    const Space v615_3 = intersect(constant_6,v615_2);
    const Space v615_4 = (has_head(v615_3) ? constant_7 : Space{});
    const Space v615_5 = subtract(constant_0,v615_4);
    Space v615_8;
    if (!v615_5.empty()) {
      const Path v616_6 = concat_path(p0,v614_9_head);
      Space v616_7_result;
      for (int v616_7_label = 1; v616_7_label <= 2; ++v616_7_label) {
        const Space v616_7_tail = child(v614_9_tail,v616_7_label);
        if (v616_7_tail.empty()) continue;
        const Path v616_7_head{v616_7_label};
        const Space v617_2 = singleton(v616_7_head);
        const Space v617_3 = intersect(constant_6,v617_2);
        const Space v617_4 = (has_head(v617_3) ? constant_7 : Space{});
        const Space v617_5 = subtract(constant_0,v617_4);
        Space v617_8;
        if (!v617_5.empty()) {
          const Path v618_6 = concat_path(v616_6,v616_7_head);
          const Space v618_7 = routine_112(c, v618_6, v616_7_tail);
          v617_8 = compose(v617_5,v618_7);
        }
        const Space v617_9 = intersect(constant_6,v617_2);
        const Space v617_10 = (has_head(v617_9) ? constant_7 : Space{});
        Space v617_12;
        if (!v617_10.empty()) {
          const Path v619_6 = concat_path(v616_6,v616_7_head);
          const Space v619_11 = routine_113(c, v619_6, v616_7_tail);
          v617_12 = compose(v617_10,v619_11);
        }
        const Space v617_13 = unite(v617_8,v617_12);
        v616_7_result = unite(v616_7_result,v617_13);
      }
      const Space v616_7 = std::move(v616_7_result);
      v615_8 = compose(v615_5,v616_7);
    }
    const Space v615_9 = intersect(constant_6,v615_2);
    const Space v615_10 = (has_head(v615_9) ? constant_7 : Space{});
    const Space v615_11 = compose(v615_10,constant_9);
    const Space v615_12 = unite(v615_8,v615_11);
    v614_9_result = unite(v614_9_result,v615_12);
  }
  const Space v614_9 = std::move(v614_9_result);
  return v614_9;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v620_11_result;
  for (int v620_11_label = 1; v620_11_label <= 2; ++v620_11_label) {
    const Space v620_11_tail = child(s0,v620_11_label);
    if (v620_11_tail.empty()) continue;
    const Path v620_11_head{v620_11_label};
    const Space v621_2 = singleton(v620_11_head);
    const Space v621_3 = intersect(constant_6,v621_2);
    const Space v621_4 = (has_head(v621_3) ? constant_7 : Space{});
    const Space v621_5 = subtract(constant_0,v621_4);
    Space v621_8;
    if (!v621_5.empty()) {
      const Path v622_6 = concat_path(p0,v620_11_head);
      Space v622_7_result;
      for (int v622_7_label = 1; v622_7_label <= 2; ++v622_7_label) {
        const Space v622_7_tail = child(v620_11_tail,v622_7_label);
        if (v622_7_tail.empty()) continue;
        const Path v622_7_head{v622_7_label};
        const Space v623_2 = singleton(v622_7_head);
        const Space v623_3 = intersect(constant_6,v623_2);
        const Space v623_4 = (has_head(v623_3) ? constant_7 : Space{});
        const Space v623_5 = subtract(constant_0,v623_4);
        Space v623_8;
        if (!v623_5.empty()) {
          const Path v624_6 = concat_path(v622_6,v622_7_head);
          const Space v624_7 = routine_114(c, v624_6, v622_7_tail);
          v623_8 = compose(v623_5,v624_7);
        }
        const Space v623_9 = intersect(constant_6,v623_2);
        const Space v623_10 = (has_head(v623_9) ? constant_7 : Space{});
        Space v623_12;
        if (!v623_10.empty()) {
          const Path v625_6 = concat_path(v622_6,v622_7_head);
          const Space v625_11 = routine_115(c, v625_6, v622_7_tail);
          v623_12 = compose(v623_10,v625_11);
        }
        const Space v623_13 = unite(v623_8,v623_12);
        v622_7_result = unite(v622_7_result,v623_13);
      }
      const Space v622_7 = std::move(v622_7_result);
      v621_8 = compose(v621_5,v622_7);
    }
    const Space v621_9 = intersect(constant_6,v621_2);
    const Space v621_10 = (has_head(v621_9) ? constant_7 : Space{});
    Space v621_12;
    if (!v621_10.empty()) {
      const Path v626_6 = concat_path(p0,v620_11_head);
      Space v626_11_result;
      for (int v626_11_label = 1; v626_11_label <= 2; ++v626_11_label) {
        const Space v626_11_tail = child(v620_11_tail,v626_11_label);
        if (v626_11_tail.empty()) continue;
        const Path v626_11_head{v626_11_label};
        const Space v627_2 = singleton(v626_11_head);
        const Space v627_3 = intersect(constant_6,v627_2);
        const Space v627_4 = (has_head(v627_3) ? constant_7 : Space{});
        const Space v627_5 = subtract(constant_0,v627_4);
        Space v627_8;
        if (!v627_5.empty()) {
          const Path v628_6 = concat_path(v626_6,v626_11_head);
          const Space v628_7 = routine_114(c, v628_6, v626_11_tail);
          v627_8 = compose(v627_5,v628_7);
        }
        const Space v627_9 = intersect(constant_6,v627_2);
        const Space v627_10 = (has_head(v627_9) ? constant_7 : Space{});
        Space v627_12;
        if (!v627_10.empty()) {
          const Path v629_6 = concat_path(v626_6,v626_11_head);
          const Space v629_11 = routine_107(c, v629_6, v626_11_tail);
          v627_12 = compose(v627_10,v629_11);
        }
        const Space v627_13 = unite(v627_8,v627_12);
        v626_11_result = unite(v626_11_result,v627_13);
      }
      const Space v626_11 = std::move(v626_11_result);
      v621_12 = compose(v621_10,v626_11);
    }
    const Space v621_13 = unite(v621_8,v621_12);
    v620_11_result = unite(v620_11_result,v621_13);
  }
  const Space v620_11 = std::move(v620_11_result);
  return v620_11;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0) {
  Space v630_8_result;
  for (int v630_8_label = 1; v630_8_label <= 2; ++v630_8_label) {
    const Space v630_8_tail = child(s0,v630_8_label);
    if (v630_8_tail.empty()) continue;
    const Path v630_8_head{v630_8_label};
    const Space v631_2 = singleton(v630_8_head);
    const Space v631_3 = intersect(constant_6,v631_2);
    const Space v631_4 = (has_head(v631_3) ? constant_7 : Space{});
    const Space v631_5 = subtract(constant_0,v631_4);
    Space v631_8;
    if (!v631_5.empty()) {
      const Path v632_6 = concat_path(p0,v630_8_head);
      Space v632_7_result;
      for (int v632_7_label = 1; v632_7_label <= 2; ++v632_7_label) {
        const Space v632_7_tail = child(v630_8_tail,v632_7_label);
        if (v632_7_tail.empty()) continue;
        const Path v632_7_head{v632_7_label};
        const Space v633_2 = singleton(v632_7_head);
        const Space v633_3 = intersect(constant_6,v633_2);
        const Space v633_4 = (has_head(v633_3) ? constant_7 : Space{});
        const Space v633_5 = subtract(constant_0,v633_4);
        Space v633_8;
        if (!v633_5.empty()) {
          const Path v634_6 = concat_path(v632_6,v632_7_head);
          const Space v634_7 = routine_114(c, v634_6, v632_7_tail);
          v633_8 = compose(v633_5,v634_7);
        }
        const Space v633_9 = intersect(constant_6,v633_2);
        const Space v633_10 = (has_head(v633_9) ? constant_7 : Space{});
        Space v633_12;
        if (!v633_10.empty()) {
          const Path v635_6 = concat_path(v632_6,v632_7_head);
          const Space v635_11 = routine_115(c, v635_6, v632_7_tail);
          v633_12 = compose(v633_10,v635_11);
        }
        const Space v633_13 = unite(v633_8,v633_12);
        v632_7_result = unite(v632_7_result,v633_13);
      }
      const Space v632_7 = std::move(v632_7_result);
      v631_8 = compose(v631_5,v632_7);
    }
    const Space v631_9 = intersect(constant_6,v631_2);
    const Space v631_10 = (has_head(v631_9) ? constant_7 : Space{});
    const Space v631_11 = compose(v631_10,v630_8_tail);
    const Space v631_12 = unite(v631_8,v631_11);
    v630_8_result = unite(v630_8_result,v631_12);
  }
  const Space v630_8 = std::move(v630_8_result);
  return v630_8;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v636_12_result;
  for (int v636_12_label = 1; v636_12_label <= 2; ++v636_12_label) {
    const Space v636_12_tail = child(s0,v636_12_label);
    if (v636_12_tail.empty()) continue;
    const Path v636_12_head{v636_12_label};
    const Space v637_2 = singleton(v636_12_head);
    const Space v637_3 = intersect(constant_6,v637_2);
    const Space v637_4 = (has_head(v637_3) ? constant_7 : Space{});
    const Space v637_5 = subtract(constant_0,v637_4);
    Space v637_8;
    if (!v637_5.empty()) {
      const Path v638_6 = concat_path(p0,v636_12_head);
      Space v638_7_result;
      for (int v638_7_label = 1; v638_7_label <= 2; ++v638_7_label) {
        const Space v638_7_tail = child(v636_12_tail,v638_7_label);
        if (v638_7_tail.empty()) continue;
        const Path v638_7_head{v638_7_label};
        const Space v639_2 = singleton(v638_7_head);
        const Space v639_3 = intersect(constant_6,v639_2);
        const Space v639_4 = (has_head(v639_3) ? constant_7 : Space{});
        const Space v639_5 = subtract(constant_0,v639_4);
        Space v639_8;
        if (!v639_5.empty()) {
          const Path v640_6 = concat_path(v638_6,v638_7_head);
          const Space v640_7 = routine_116(c, v640_6, v638_7_tail, s1);
          v639_8 = compose(v639_5,v640_7);
        }
        const Space v639_9 = intersect(constant_6,v639_2);
        const Space v639_10 = (has_head(v639_9) ? constant_7 : Space{});
        Space v639_12;
        if (!v639_10.empty()) {
          const Path v641_6 = concat_path(v638_6,v638_7_head);
          const Space v641_11 = routine_117(c, v641_6, v638_7_tail, s1);
          v639_12 = compose(v639_10,v641_11);
        }
        const Space v639_13 = unite(v639_8,v639_12);
        v638_7_result = unite(v638_7_result,v639_13);
      }
      const Space v638_7 = std::move(v638_7_result);
      v637_8 = compose(v637_5,v638_7);
    }
    const Space v637_9 = intersect(constant_6,v637_2);
    const Space v637_10 = (has_head(v637_9) ? constant_7 : Space{});
    Space v637_12;
    if (!v637_10.empty()) {
      const Path v642_6 = concat_path(p0,v636_12_head);
      Space v642_11_result;
      for (int v642_11_label = 1; v642_11_label <= 2; ++v642_11_label) {
        const Space v642_11_tail = child(v636_12_tail,v642_11_label);
        if (v642_11_tail.empty()) continue;
        const Path v642_11_head{v642_11_label};
        const Space v643_2 = singleton(v642_11_head);
        const Space v643_3 = intersect(constant_6,v643_2);
        const Space v643_4 = (has_head(v643_3) ? constant_7 : Space{});
        const Space v643_5 = subtract(constant_0,v643_4);
        Space v643_8;
        if (!v643_5.empty()) {
          const Path v644_6 = concat_path(v642_6,v642_11_head);
          const Space v644_7 = routine_116(c, v644_6, v642_11_tail, s1);
          v643_8 = compose(v643_5,v644_7);
        }
        const Space v643_9 = intersect(constant_6,v643_2);
        const Space v643_10 = (has_head(v643_9) ? constant_7 : Space{});
        Space v643_12;
        if (!v643_10.empty()) {
          const Path v645_6 = concat_path(v642_6,v642_11_head);
          const Space v645_11 = routine_9(c, v645_6, v642_11_tail, s1);
          v643_12 = compose(v643_10,v645_11);
        }
        const Space v643_13 = unite(v643_8,v643_12);
        v642_11_result = unite(v642_11_result,v643_13);
      }
      const Space v642_11 = std::move(v642_11_result);
      v637_12 = compose(v637_10,v642_11);
    }
    const Space v637_13 = unite(v637_8,v637_12);
    v636_12_result = unite(v636_12_result,v637_13);
  }
  const Space v636_12 = std::move(v636_12_result);
  return v636_12;
}

static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v646_12_result;
  for (int v646_12_label = 1; v646_12_label <= 2; ++v646_12_label) {
    const Space v646_12_tail = child(s0,v646_12_label);
    if (v646_12_tail.empty()) continue;
    const Path v646_12_head{v646_12_label};
    const Space v647_2 = singleton(v646_12_head);
    const Space v647_3 = intersect(constant_6,v647_2);
    const Space v647_4 = (has_head(v647_3) ? constant_7 : Space{});
    const Space v647_5 = subtract(constant_0,v647_4);
    Space v647_8;
    if (!v647_5.empty()) {
      const Path v648_6 = concat_path(p0,v646_12_head);
      Space v648_7_result;
      for (int v648_7_label = 1; v648_7_label <= 2; ++v648_7_label) {
        const Space v648_7_tail = child(v646_12_tail,v648_7_label);
        if (v648_7_tail.empty()) continue;
        const Path v648_7_head{v648_7_label};
        const Space v649_2 = singleton(v648_7_head);
        const Space v649_3 = intersect(constant_6,v649_2);
        const Space v649_4 = (has_head(v649_3) ? constant_7 : Space{});
        const Space v649_5 = subtract(constant_0,v649_4);
        Space v649_8;
        if (!v649_5.empty()) {
          const Path v650_6 = concat_path(v648_6,v648_7_head);
          const Space v650_7 = routine_116(c, v650_6, v648_7_tail, s1);
          v649_8 = compose(v649_5,v650_7);
        }
        const Space v649_9 = intersect(constant_6,v649_2);
        const Space v649_10 = (has_head(v649_9) ? constant_7 : Space{});
        Space v649_12;
        if (!v649_10.empty()) {
          const Path v651_6 = concat_path(v648_6,v648_7_head);
          const Space v651_11 = routine_117(c, v651_6, v648_7_tail, s1);
          v649_12 = compose(v649_10,v651_11);
        }
        const Space v649_13 = unite(v649_8,v649_12);
        v648_7_result = unite(v648_7_result,v649_13);
      }
      const Space v648_7 = std::move(v648_7_result);
      v647_8 = compose(v647_5,v648_7);
    }
    const Space v647_9 = intersect(constant_6,v647_2);
    const Space v647_10 = (has_head(v647_9) ? constant_7 : Space{});
    Space v647_12;
    if (!v647_10.empty()) {
      const Path v652_6 = concat_path(p0,v646_12_head);
      Space v652_11_result;
      for (int v652_11_label = 1; v652_11_label <= 2; ++v652_11_label) {
        const Space v652_11_tail = child(v646_12_tail,v652_11_label);
        if (v652_11_tail.empty()) continue;
        const Path v652_11_head{v652_11_label};
        const Space v653_2 = singleton(v652_11_head);
        const Space v653_3 = intersect(constant_6,v653_2);
        const Space v653_4 = (has_head(v653_3) ? constant_7 : Space{});
        const Space v653_5 = subtract(constant_0,v653_4);
        Space v653_7;
        if (!v653_5.empty()) {
          const Space v654_6 = routine_10(c, v652_11_head, v652_6, v652_11_tail, s1);
          v653_7 = compose(v653_5,v654_6);
        }
        const Space v653_8 = intersect(constant_6,v653_2);
        const Space v653_9 = (has_head(v653_8) ? constant_7 : Space{});
        Space v653_11;
        if (!v653_9.empty()) {
          const Space v655_10 = routine_11(c, v652_11_head, v652_6, v652_11_tail, s1);
          v653_11 = compose(v653_9,v655_10);
        }
        const Space v653_12 = unite(v653_7,v653_11);
        v652_11_result = unite(v652_11_result,v653_12);
      }
      const Space v652_11 = std::move(v652_11_result);
      v647_12 = compose(v647_10,v652_11);
    }
    const Space v647_13 = unite(v647_8,v647_12);
    v646_12_result = unite(v646_12_result,v647_13);
  }
  const Space v646_12 = std::move(v646_12_result);
  return v646_12;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v656_13_result;
  for (int v656_13_label = 1; v656_13_label <= 2; ++v656_13_label) {
    const Space v656_13_tail = child(s0,v656_13_label);
    if (v656_13_tail.empty()) continue;
    const Path v656_13_head{v656_13_label};
    const Space v657_2 = singleton(v656_13_head);
    const Space v657_3 = intersect(constant_6,v657_2);
    const Space v657_4 = (has_head(v657_3) ? constant_7 : Space{});
    const Space v657_5 = subtract(constant_0,v657_4);
    Space v657_8;
    if (!v657_5.empty()) {
      const Path v658_6 = concat_path(p0,v656_13_head);
      Space v658_7_result;
      for (int v658_7_label = 1; v658_7_label <= 2; ++v658_7_label) {
        const Space v658_7_tail = child(v656_13_tail,v658_7_label);
        if (v658_7_tail.empty()) continue;
        const Path v658_7_head{v658_7_label};
        const Space v659_2 = singleton(v658_7_head);
        const Space v659_3 = intersect(constant_6,v659_2);
        const Space v659_4 = (has_head(v659_3) ? constant_7 : Space{});
        const Space v659_5 = subtract(constant_0,v659_4);
        Space v659_8;
        if (!v659_5.empty()) {
          const Path v660_6 = concat_path(v658_6,v658_7_head);
          const Space v660_7 = routine_118(c, v660_6, p1, v658_7_tail, s1);
          v659_8 = compose(v659_5,v660_7);
        }
        const Space v659_9 = intersect(constant_6,v659_2);
        const Space v659_10 = (has_head(v659_9) ? constant_7 : Space{});
        Space v659_12;
        if (!v659_10.empty()) {
          const Path v661_6 = concat_path(v658_6,v658_7_head);
          const Space v661_11 = routine_119(c, v661_6, p1, v658_7_tail, s1);
          v659_12 = compose(v659_10,v661_11);
        }
        const Space v659_13 = unite(v659_8,v659_12);
        v658_7_result = unite(v658_7_result,v659_13);
      }
      const Space v658_7 = std::move(v658_7_result);
      v657_8 = compose(v657_5,v658_7);
    }
    const Space v657_9 = intersect(constant_6,v657_2);
    const Space v657_10 = (has_head(v657_9) ? constant_7 : Space{});
    Space v657_12;
    if (!v657_10.empty()) {
      const Path v662_6 = concat_path(p0,v656_13_head);
      Space v662_11_result;
      for (int v662_11_label = 1; v662_11_label <= 2; ++v662_11_label) {
        const Space v662_11_tail = child(v656_13_tail,v662_11_label);
        if (v662_11_tail.empty()) continue;
        const Path v662_11_head{v662_11_label};
        const Space v663_2 = singleton(v662_11_head);
        const Space v663_3 = intersect(constant_6,v663_2);
        const Space v663_4 = (has_head(v663_3) ? constant_7 : Space{});
        const Space v663_5 = subtract(constant_0,v663_4);
        Space v663_8;
        if (!v663_5.empty()) {
          const Path v664_6 = concat_path(v662_6,v662_11_head);
          const Space v664_7 = routine_118(c, v664_6, p1, v662_11_tail, s1);
          v663_8 = compose(v663_5,v664_7);
        }
        const Space v663_9 = intersect(constant_6,v663_2);
        const Space v663_10 = (has_head(v663_9) ? constant_7 : Space{});
        Space v663_12;
        if (!v663_10.empty()) {
          const Path v665_6 = concat_path(v662_6,v662_11_head);
          const Space v665_11 = routine_26(c, v665_6, p1, v662_11_tail, s1);
          v663_12 = compose(v663_10,v665_11);
        }
        const Space v663_13 = unite(v663_8,v663_12);
        v662_11_result = unite(v662_11_result,v663_13);
      }
      const Space v662_11 = std::move(v662_11_result);
      v657_12 = compose(v657_10,v662_11);
    }
    const Space v657_13 = unite(v657_8,v657_12);
    v656_13_result = unite(v656_13_result,v657_13);
  }
  const Space v656_13 = std::move(v656_13_result);
  return v656_13;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v666_8 = unwrap(s1,constant_8);
  Space v666_21_result;
  for (int v666_21_label = 1; v666_21_label <= 2; ++v666_21_label) {
    const Space v666_21_tail = child(s0,v666_21_label);
    if (v666_21_tail.empty()) continue;
    const Path v666_21_head{v666_21_label};
    const Space v667_2 = singleton(v666_21_head);
    const Space v667_3 = intersect(constant_6,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_7 : Space{});
    const Space v667_5 = subtract(constant_0,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_21_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_21_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_6,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_7 : Space{});
        const Space v669_5 = subtract(constant_0,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_118(c, v670_6, p1, v668_7_tail, s1);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_6,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_7 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_119(c, v671_6, p1, v668_7_tail, s1);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_6,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_7 : Space{});
    Space v667_22;
    if (!v667_10.empty()) {
      const Path v672_6 = concat_path(p0,v666_21_head);
      const Path v672_11 = concat_path(p1,v672_6);
      const Space v672_12 = routine_29(c, v672_11);
      const Space v672_13 = intersect(v666_8,v672_12);
      const Space v672_14 = routine_30(c, v672_13);
      Space v672_15_result;
      for (int v672_15_label = 1; v672_15_label <= 2; ++v672_15_label) {
        const Space v672_15_tail = child(v672_14,v672_15_label);
        if (v672_15_tail.empty()) continue;
        const Path v672_15_head{v672_15_label};
        const Space v673_2 = singleton(v672_15_head);
        const Space v673_3 = intersect(constant_6,v673_2);
        const Space v673_4 = (has_head(v673_3) ? constant_7 : Space{});
        const Space v673_5 = subtract(constant_0,v673_4);
        Space v673_7;
        if (!v673_5.empty()) {
          const Space v674_6 = routine_31(c, v672_15_head, v672_15_tail);
          v673_7 = compose(v673_5,v674_6);
        }
        const Space v673_8 = intersect(constant_6,v673_2);
        const Space v673_9 = (has_head(v673_8) ? constant_7 : Space{});
        Space v673_11;
        if (!v673_9.empty()) {
          const Space v675_10 = routine_32(c, v672_15_head, v672_15_tail);
          v673_11 = compose(v673_9,v675_10);
        }
        const Space v673_12 = unite(v673_7,v673_11);
        v672_15_result = unite(v672_15_result,v673_12);
      }
      const Space v672_15 = std::move(v672_15_result);
      const Space v672_16 = routine_33(c, v672_13);
      Space v672_17_result;
      for (int v672_17_label = 1; v672_17_label <= 2; ++v672_17_label) {
        const Space v672_17_tail = child(v672_16,v672_17_label);
        if (v672_17_tail.empty()) continue;
        const Path v672_17_head{v672_17_label};
        const Space v676_2 = singleton(v672_17_head);
        const Space v676_3 = intersect(constant_6,v676_2);
        const Space v676_4 = (has_head(v676_3) ? constant_7 : Space{});
        const Space v676_5 = subtract(constant_0,v676_4);
        Space v676_7;
        if (!v676_5.empty()) {
          const Space v677_6 = routine_34(c, v672_17_head, v672_17_tail);
          v676_7 = compose(v676_5,v677_6);
        }
        const Space v676_8 = intersect(constant_6,v676_2);
        const Space v676_9 = (has_head(v676_8) ? constant_7 : Space{});
        Space v676_11;
        if (!v676_9.empty()) {
          const Space v678_10 = routine_35(c, v672_17_head, v672_17_tail);
          v676_11 = compose(v676_9,v678_10);
        }
        const Space v676_12 = unite(v676_7,v676_11);
        v672_17_result = unite(v672_17_result,v676_12);
      }
      const Space v672_17 = std::move(v672_17_result);
      const Space v672_18 = subtract(v672_15,v672_17);
      const Space v672_19 = singleton(v672_11);
      const Space v672_20 = compose(v672_18,v672_19);
      Space v672_21_result;
      for (int v672_21_label = 1; v672_21_label <= 2; ++v672_21_label) {
        const Space v672_21_tail = child(v672_20,v672_21_label);
        if (v672_21_tail.empty()) continue;
        const Path v672_21_head{v672_21_label};
        const Space v679_2 = singleton(v672_21_head);
        const Space v679_3 = intersect(constant_6,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_7 : Space{});
        const Space v679_5 = subtract(constant_0,v679_4);
        Space v679_7;
        if (!v679_5.empty()) {
          const Space v680_6 = routine_36(c, v672_21_head, v672_21_tail);
          v679_7 = compose(v679_5,v680_6);
        }
        const Space v679_8 = intersect(constant_6,v679_2);
        const Space v679_9 = (has_head(v679_8) ? constant_7 : Space{});
        Space v679_11;
        if (!v679_9.empty()) {
          const Space v681_10 = routine_37(c, v672_21_head, v672_21_tail);
          v679_11 = compose(v679_9,v681_10);
        }
        const Space v679_12 = unite(v679_7,v679_11);
        v672_21_result = unite(v672_21_result,v679_12);
      }
      const Space v672_21 = std::move(v672_21_result);
      v667_22 = compose(v667_10,v672_21);
    }
    const Space v667_23 = unite(v667_8,v667_22);
    v666_21_result = unite(v666_21_result,v667_23);
  }
  const Space v666_21 = std::move(v666_21_result);
  return v666_21;
}

static Space routine_63(Context& c, const Path& p0, const Space& s0) {
  Space v682_11_result;
  for (int v682_11_label = 1; v682_11_label <= 2; ++v682_11_label) {
    const Space v682_11_tail = child(s0,v682_11_label);
    if (v682_11_tail.empty()) continue;
    const Path v682_11_head{v682_11_label};
    const Space v683_2 = singleton(v682_11_head);
    const Space v683_3 = intersect(constant_6,v683_2);
    const Space v683_4 = (has_head(v683_3) ? constant_7 : Space{});
    const Space v683_5 = subtract(constant_0,v683_4);
    Space v683_8;
    if (!v683_5.empty()) {
      const Path v684_6 = concat_path(p0,v682_11_head);
      Space v684_7_result;
      for (int v684_7_label = 1; v684_7_label <= 2; ++v684_7_label) {
        const Space v684_7_tail = child(v682_11_tail,v684_7_label);
        if (v684_7_tail.empty()) continue;
        const Path v684_7_head{v684_7_label};
        const Space v685_2 = singleton(v684_7_head);
        const Space v685_3 = intersect(constant_6,v685_2);
        const Space v685_4 = (has_head(v685_3) ? constant_7 : Space{});
        const Space v685_5 = subtract(constant_0,v685_4);
        Space v685_8;
        if (!v685_5.empty()) {
          const Path v686_6 = concat_path(v684_6,v684_7_head);
          const Space v686_7 = routine_120(c, v686_6, v684_7_tail);
          v685_8 = compose(v685_5,v686_7);
        }
        const Space v685_9 = intersect(constant_6,v685_2);
        const Space v685_10 = (has_head(v685_9) ? constant_7 : Space{});
        Space v685_12;
        if (!v685_10.empty()) {
          const Path v687_6 = concat_path(v684_6,v684_7_head);
          const Space v687_11 = routine_121(c, v687_6, v684_7_tail);
          v685_12 = compose(v685_10,v687_11);
        }
        const Space v685_13 = unite(v685_8,v685_12);
        v684_7_result = unite(v684_7_result,v685_13);
      }
      const Space v684_7 = std::move(v684_7_result);
      v683_8 = compose(v683_5,v684_7);
    }
    const Space v683_9 = intersect(constant_6,v683_2);
    const Space v683_10 = (has_head(v683_9) ? constant_7 : Space{});
    Space v683_12;
    if (!v683_10.empty()) {
      const Path v688_6 = concat_path(p0,v682_11_head);
      Space v688_11_result;
      for (int v688_11_label = 1; v688_11_label <= 2; ++v688_11_label) {
        const Space v688_11_tail = child(v682_11_tail,v688_11_label);
        if (v688_11_tail.empty()) continue;
        const Path v688_11_head{v688_11_label};
        const Space v689_2 = singleton(v688_11_head);
        const Space v689_3 = intersect(constant_6,v689_2);
        const Space v689_4 = (has_head(v689_3) ? constant_7 : Space{});
        const Space v689_5 = subtract(constant_0,v689_4);
        Space v689_8;
        if (!v689_5.empty()) {
          const Path v690_6 = concat_path(v688_6,v688_11_head);
          const Space v690_7 = routine_120(c, v690_6, v688_11_tail);
          v689_8 = compose(v689_5,v690_7);
        }
        const Space v689_9 = intersect(constant_6,v689_2);
        const Space v689_10 = (has_head(v689_9) ? constant_7 : Space{});
        Space v689_12;
        if (!v689_10.empty()) {
          const Path v691_6 = concat_path(v688_6,v688_11_head);
          const Space v691_11 = routine_80(c, v691_6, v688_11_tail);
          v689_12 = compose(v689_10,v691_11);
        }
        const Space v689_13 = unite(v689_8,v689_12);
        v688_11_result = unite(v688_11_result,v689_13);
      }
      const Space v688_11 = std::move(v688_11_result);
      v683_12 = compose(v683_10,v688_11);
    }
    const Space v683_13 = unite(v683_8,v683_12);
    v682_11_result = unite(v682_11_result,v683_13);
  }
  const Space v682_11 = std::move(v682_11_result);
  return v682_11;
}

static Space routine_64(Context& c, const Path& p0, const Space& s0) {
  Space v692_11_result;
  for (int v692_11_label = 1; v692_11_label <= 2; ++v692_11_label) {
    const Space v692_11_tail = child(s0,v692_11_label);
    if (v692_11_tail.empty()) continue;
    const Path v692_11_head{v692_11_label};
    const Space v693_2 = singleton(v692_11_head);
    const Space v693_3 = intersect(constant_6,v693_2);
    const Space v693_4 = (has_head(v693_3) ? constant_7 : Space{});
    const Space v693_5 = subtract(constant_0,v693_4);
    Space v693_8;
    if (!v693_5.empty()) {
      const Path v694_6 = concat_path(p0,v692_11_head);
      Space v694_7_result;
      for (int v694_7_label = 1; v694_7_label <= 2; ++v694_7_label) {
        const Space v694_7_tail = child(v692_11_tail,v694_7_label);
        if (v694_7_tail.empty()) continue;
        const Path v694_7_head{v694_7_label};
        const Space v695_2 = singleton(v694_7_head);
        const Space v695_3 = intersect(constant_6,v695_2);
        const Space v695_4 = (has_head(v695_3) ? constant_7 : Space{});
        const Space v695_5 = subtract(constant_0,v695_4);
        Space v695_8;
        if (!v695_5.empty()) {
          const Path v696_6 = concat_path(v694_6,v694_7_head);
          const Space v696_7 = routine_120(c, v696_6, v694_7_tail);
          v695_8 = compose(v695_5,v696_7);
        }
        const Space v695_9 = intersect(constant_6,v695_2);
        const Space v695_10 = (has_head(v695_9) ? constant_7 : Space{});
        Space v695_12;
        if (!v695_10.empty()) {
          const Path v697_6 = concat_path(v694_6,v694_7_head);
          const Space v697_11 = routine_121(c, v697_6, v694_7_tail);
          v695_12 = compose(v695_10,v697_11);
        }
        const Space v695_13 = unite(v695_8,v695_12);
        v694_7_result = unite(v694_7_result,v695_13);
      }
      const Space v694_7 = std::move(v694_7_result);
      v693_8 = compose(v693_5,v694_7);
    }
    const Space v693_9 = intersect(constant_6,v693_2);
    const Space v693_10 = (has_head(v693_9) ? constant_7 : Space{});
    Space v693_12;
    if (!v693_10.empty()) {
      const Path v698_6 = concat_path(p0,v692_11_head);
      Space v698_11_result;
      for (int v698_11_label = 1; v698_11_label <= 2; ++v698_11_label) {
        const Space v698_11_tail = child(v692_11_tail,v698_11_label);
        if (v698_11_tail.empty()) continue;
        const Path v698_11_head{v698_11_label};
        const Space v699_2 = singleton(v698_11_head);
        const Space v699_3 = intersect(constant_6,v699_2);
        const Space v699_4 = (has_head(v699_3) ? constant_7 : Space{});
        const Space v699_5 = subtract(constant_0,v699_4);
        Space v699_7;
        if (!v699_5.empty()) {
          const Space v700_6 = routine_122(c, v698_11_head, v698_6, v698_11_tail);
          v699_7 = compose(v699_5,v700_6);
        }
        const Space v699_8 = intersect(constant_6,v699_2);
        const Space v699_9 = (has_head(v699_8) ? constant_7 : Space{});
        Space v699_11;
        if (!v699_9.empty()) {
          const Space v701_10 = routine_123(c, v698_11_head, v698_6, v698_11_tail);
          v699_11 = compose(v699_9,v701_10);
        }
        const Space v699_12 = unite(v699_7,v699_11);
        v698_11_result = unite(v698_11_result,v699_12);
      }
      const Space v698_11 = std::move(v698_11_result);
      v693_12 = compose(v693_10,v698_11);
    }
    const Space v693_13 = unite(v693_8,v693_12);
    v692_11_result = unite(v692_11_result,v693_13);
  }
  const Space v692_11 = std::move(v692_11_result);
  return v692_11;
}

static Space routine_65(Context& c, const Space& s0) {
  const Space v702_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v702_2 = first_matching(s0,constant_0,false);
  const Space v702_3 = unite(v702_1,v702_2);
  Space v702_13;
  if (!v702_3.empty()) {
    Space v703_6;
    if (!v702_3.empty()) {
      const Space v704_4 = routine_81(c, s0);
      const Space v704_5 = subtract(s0,v704_4);
      v703_6 = compose(v702_3,v704_5);
    }
    const Space v703_7 = (has_head(v703_6) ? constant_7 : Space{});
    const Space v703_8 = first_matching(v703_6,constant_0,false);
    const Space v703_9 = unite(v703_7,v703_8);
    Space v703_12;
    if (!v703_9.empty()) {
      const Space v705_10 = routine_81(c, v703_6);
      const Space v705_11 = subtract(v703_6,v705_10);
      v703_12 = compose(v703_9,v705_11);
    }
    v702_13 = compose(v702_3,v703_12);
  }
  return v702_13;
}

static Space routine_66(Context& c, const Space& s0) {
  const Space v706_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v706_2 = first_matching(s0,constant_0,false);
  const Space v706_3 = unite(v706_1,v706_2);
  Space v706_19;
  if (!v706_3.empty()) {
    const Space v707_5 = intersect(constant_0,v706_2);
    const Space v707_6 = (has_head(v706_2) ? constant_7 : Space{});
    const Space v707_7 = unite(v707_5,v707_6);
    const Space v707_9 = compose(v707_7,constant_0);
    const Space v707_10 = subtract(s0,v707_9);
    const Space v707_12 = subtract(constant_0,v706_2);
    const Space v707_13 = subtract(v707_12,v707_6);
    Space v707_17;
    if (!v707_13.empty()) {
      const Space v708_15 = first_listed(s0,constant_11,true);
      const Space v708_16 = routine_124(c, constant_10, v708_15, s0);
      v707_17 = compose(v707_13,v708_16);
    }
    const Space v707_18 = subtract(v707_10,v707_17);
    v706_19 = compose(v706_3,v707_18);
  }
  return v706_19;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v709_11_result;
  for (int v709_11_label = 1; v709_11_label <= 2; ++v709_11_label) {
    const Space v709_11_tail = child(s0,v709_11_label);
    if (v709_11_tail.empty()) continue;
    const Path v709_11_head{v709_11_label};
    const Space v710_2 = singleton(v709_11_head);
    const Space v710_3 = intersect(constant_6,v710_2);
    const Space v710_4 = (has_head(v710_3) ? constant_7 : Space{});
    const Space v710_5 = subtract(constant_0,v710_4);
    Space v710_8;
    if (!v710_5.empty()) {
      const Path v711_6 = concat_path(p0,v709_11_head);
      Space v711_7_result;
      for (int v711_7_label = 1; v711_7_label <= 2; ++v711_7_label) {
        const Space v711_7_tail = child(v709_11_tail,v711_7_label);
        if (v711_7_tail.empty()) continue;
        const Path v711_7_head{v711_7_label};
        const Space v712_2 = singleton(v711_7_head);
        const Space v712_3 = intersect(constant_6,v712_2);
        const Space v712_4 = (has_head(v712_3) ? constant_7 : Space{});
        const Space v712_5 = subtract(constant_0,v712_4);
        Space v712_8;
        if (!v712_5.empty()) {
          const Path v713_6 = concat_path(v711_6,v711_7_head);
          const Space v713_7 = routine_125(c, v713_6, v711_7_tail);
          v712_8 = compose(v712_5,v713_7);
        }
        const Space v712_9 = intersect(constant_6,v712_2);
        const Space v712_10 = (has_head(v712_9) ? constant_7 : Space{});
        Space v712_12;
        if (!v712_10.empty()) {
          const Path v714_6 = concat_path(v711_6,v711_7_head);
          const Space v714_11 = routine_126(c, v714_6, v711_7_tail);
          v712_12 = compose(v712_10,v714_11);
        }
        const Space v712_13 = unite(v712_8,v712_12);
        v711_7_result = unite(v711_7_result,v712_13);
      }
      const Space v711_7 = std::move(v711_7_result);
      v710_8 = compose(v710_5,v711_7);
    }
    const Space v710_9 = intersect(constant_6,v710_2);
    const Space v710_10 = (has_head(v710_9) ? constant_7 : Space{});
    Space v710_12;
    if (!v710_10.empty()) {
      const Path v715_6 = concat_path(p0,v709_11_head);
      Space v715_11_result;
      for (int v715_11_label = 1; v715_11_label <= 2; ++v715_11_label) {
        const Space v715_11_tail = child(v709_11_tail,v715_11_label);
        if (v715_11_tail.empty()) continue;
        const Path v715_11_head{v715_11_label};
        const Space v716_2 = singleton(v715_11_head);
        const Space v716_3 = intersect(constant_6,v716_2);
        const Space v716_4 = (has_head(v716_3) ? constant_7 : Space{});
        const Space v716_5 = subtract(constant_0,v716_4);
        Space v716_8;
        if (!v716_5.empty()) {
          const Path v717_6 = concat_path(v715_6,v715_11_head);
          const Space v717_7 = routine_125(c, v717_6, v715_11_tail);
          v716_8 = compose(v716_5,v717_7);
        }
        const Space v716_9 = intersect(constant_6,v716_2);
        const Space v716_10 = (has_head(v716_9) ? constant_7 : Space{});
        Space v716_12;
        if (!v716_10.empty()) {
          const Path v718_6 = concat_path(v715_6,v715_11_head);
          const Space v718_11 = routine_69(c, v718_6, v715_11_tail);
          v716_12 = compose(v716_10,v718_11);
        }
        const Space v716_13 = unite(v716_8,v716_12);
        v715_11_result = unite(v715_11_result,v716_13);
      }
      const Space v715_11 = std::move(v715_11_result);
      v710_12 = compose(v710_10,v715_11);
    }
    const Space v710_13 = unite(v710_8,v710_12);
    v709_11_result = unite(v709_11_result,v710_13);
  }
  const Space v709_11 = std::move(v709_11_result);
  return v709_11;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  Space v719_9_result;
  for (int v719_9_label = 1; v719_9_label <= 2; ++v719_9_label) {
    const Space v719_9_tail = child(s0,v719_9_label);
    if (v719_9_tail.empty()) continue;
    const Path v719_9_head{v719_9_label};
    const Space v720_2 = singleton(v719_9_head);
    const Space v720_3 = intersect(constant_6,v720_2);
    const Space v720_4 = (has_head(v720_3) ? constant_7 : Space{});
    const Space v720_5 = subtract(constant_0,v720_4);
    Space v720_8;
    if (!v720_5.empty()) {
      const Path v721_6 = concat_path(p0,v719_9_head);
      Space v721_7_result;
      for (int v721_7_label = 1; v721_7_label <= 2; ++v721_7_label) {
        const Space v721_7_tail = child(v719_9_tail,v721_7_label);
        if (v721_7_tail.empty()) continue;
        const Path v721_7_head{v721_7_label};
        const Space v722_2 = singleton(v721_7_head);
        const Space v722_3 = intersect(constant_6,v722_2);
        const Space v722_4 = (has_head(v722_3) ? constant_7 : Space{});
        const Space v722_5 = subtract(constant_0,v722_4);
        Space v722_8;
        if (!v722_5.empty()) {
          const Path v723_6 = concat_path(v721_6,v721_7_head);
          const Space v723_7 = routine_125(c, v723_6, v721_7_tail);
          v722_8 = compose(v722_5,v723_7);
        }
        const Space v722_9 = intersect(constant_6,v722_2);
        const Space v722_10 = (has_head(v722_9) ? constant_7 : Space{});
        Space v722_12;
        if (!v722_10.empty()) {
          const Path v724_6 = concat_path(v721_6,v721_7_head);
          const Space v724_11 = routine_126(c, v724_6, v721_7_tail);
          v722_12 = compose(v722_10,v724_11);
        }
        const Space v722_13 = unite(v722_8,v722_12);
        v721_7_result = unite(v721_7_result,v722_13);
      }
      const Space v721_7 = std::move(v721_7_result);
      v720_8 = compose(v720_5,v721_7);
    }
    const Space v720_9 = intersect(constant_6,v720_2);
    const Space v720_10 = (has_head(v720_9) ? constant_7 : Space{});
    const Space v720_11 = compose(v720_10,constant_9);
    const Space v720_12 = unite(v720_8,v720_11);
    v719_9_result = unite(v719_9_result,v720_12);
  }
  const Space v719_9 = std::move(v719_9_result);
  return v719_9;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v726_11_result;
  for (int v726_11_label = 1; v726_11_label <= 2; ++v726_11_label) {
    const Space v726_11_tail = child(s0,v726_11_label);
    if (v726_11_tail.empty()) continue;
    const Path v726_11_head{v726_11_label};
    const Space v727_2 = singleton(v726_11_head);
    const Space v727_3 = intersect(constant_6,v727_2);
    const Space v727_4 = (has_head(v727_3) ? constant_7 : Space{});
    const Space v727_5 = subtract(constant_0,v727_4);
    Space v727_8;
    if (!v727_5.empty()) {
      const Path v728_6 = concat_path(p0,v726_11_head);
      Space v728_7_result;
      for (int v728_7_label = 1; v728_7_label <= 2; ++v728_7_label) {
        const Space v728_7_tail = child(v726_11_tail,v728_7_label);
        if (v728_7_tail.empty()) continue;
        const Path v728_7_head{v728_7_label};
        const Space v729_2 = singleton(v728_7_head);
        const Space v729_3 = intersect(constant_6,v729_2);
        const Space v729_4 = (has_head(v729_3) ? constant_7 : Space{});
        const Space v729_5 = subtract(constant_0,v729_4);
        Space v729_8;
        if (!v729_5.empty()) {
          const Path v730_6 = concat_path(v728_6,v728_7_head);
          const Space v730_7 = routine_127(c, v730_6, v728_7_tail);
          v729_8 = compose(v729_5,v730_7);
        }
        const Space v729_9 = intersect(constant_6,v729_2);
        const Space v729_10 = (has_head(v729_9) ? constant_7 : Space{});
        Space v729_12;
        if (!v729_10.empty()) {
          const Path v731_6 = concat_path(v728_6,v728_7_head);
          const Space v731_11 = routine_128(c, v731_6, v728_7_tail);
          v729_12 = compose(v729_10,v731_11);
        }
        const Space v729_13 = unite(v729_8,v729_12);
        v728_7_result = unite(v728_7_result,v729_13);
      }
      const Space v728_7 = std::move(v728_7_result);
      v727_8 = compose(v727_5,v728_7);
    }
    const Space v727_9 = intersect(constant_6,v727_2);
    const Space v727_10 = (has_head(v727_9) ? constant_7 : Space{});
    Space v727_12;
    if (!v727_10.empty()) {
      const Path v732_6 = concat_path(p0,v726_11_head);
      Space v732_11_result;
      for (int v732_11_label = 1; v732_11_label <= 2; ++v732_11_label) {
        const Space v732_11_tail = child(v726_11_tail,v732_11_label);
        if (v732_11_tail.empty()) continue;
        const Path v732_11_head{v732_11_label};
        const Space v733_2 = singleton(v732_11_head);
        const Space v733_3 = intersect(constant_6,v733_2);
        const Space v733_4 = (has_head(v733_3) ? constant_7 : Space{});
        const Space v733_5 = subtract(constant_0,v733_4);
        Space v733_8;
        if (!v733_5.empty()) {
          const Path v734_6 = concat_path(v732_6,v732_11_head);
          const Space v734_7 = routine_127(c, v734_6, v732_11_tail);
          v733_8 = compose(v733_5,v734_7);
        }
        const Space v733_9 = intersect(constant_6,v733_2);
        const Space v733_10 = (has_head(v733_9) ? constant_7 : Space{});
        Space v733_12;
        if (!v733_10.empty()) {
          const Path v735_6 = concat_path(v732_6,v732_11_head);
          const Space v735_11 = routine_72(c, v735_6, v732_11_tail);
          v733_12 = compose(v733_10,v735_11);
        }
        const Space v733_13 = unite(v733_8,v733_12);
        v732_11_result = unite(v732_11_result,v733_13);
      }
      const Space v732_11 = std::move(v732_11_result);
      v727_12 = compose(v727_10,v732_11);
    }
    const Space v727_13 = unite(v727_8,v727_12);
    v726_11_result = unite(v726_11_result,v727_13);
  }
  const Space v726_11 = std::move(v726_11_result);
  return v726_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v736_9_result;
  for (int v736_9_label = 1; v736_9_label <= 2; ++v736_9_label) {
    const Space v736_9_tail = child(s0,v736_9_label);
    if (v736_9_tail.empty()) continue;
    const Path v736_9_head{v736_9_label};
    const Space v737_2 = singleton(v736_9_head);
    const Space v737_3 = intersect(constant_6,v737_2);
    const Space v737_4 = (has_head(v737_3) ? constant_7 : Space{});
    const Space v737_5 = subtract(constant_0,v737_4);
    Space v737_8;
    if (!v737_5.empty()) {
      const Path v738_6 = concat_path(p0,v736_9_head);
      Space v738_7_result;
      for (int v738_7_label = 1; v738_7_label <= 2; ++v738_7_label) {
        const Space v738_7_tail = child(v736_9_tail,v738_7_label);
        if (v738_7_tail.empty()) continue;
        const Path v738_7_head{v738_7_label};
        const Space v739_2 = singleton(v738_7_head);
        const Space v739_3 = intersect(constant_6,v739_2);
        const Space v739_4 = (has_head(v739_3) ? constant_7 : Space{});
        const Space v739_5 = subtract(constant_0,v739_4);
        Space v739_8;
        if (!v739_5.empty()) {
          const Path v740_6 = concat_path(v738_6,v738_7_head);
          const Space v740_7 = routine_127(c, v740_6, v738_7_tail);
          v739_8 = compose(v739_5,v740_7);
        }
        const Space v739_9 = intersect(constant_6,v739_2);
        const Space v739_10 = (has_head(v739_9) ? constant_7 : Space{});
        Space v739_12;
        if (!v739_10.empty()) {
          const Path v741_6 = concat_path(v738_6,v738_7_head);
          const Space v741_11 = routine_128(c, v741_6, v738_7_tail);
          v739_12 = compose(v739_10,v741_11);
        }
        const Space v739_13 = unite(v739_8,v739_12);
        v738_7_result = unite(v738_7_result,v739_13);
      }
      const Space v738_7 = std::move(v738_7_result);
      v737_8 = compose(v737_5,v738_7);
    }
    const Space v737_9 = intersect(constant_6,v737_2);
    const Space v737_10 = (has_head(v737_9) ? constant_7 : Space{});
    const Space v737_11 = compose(v737_10,constant_9);
    const Space v737_12 = unite(v737_8,v737_11);
    v736_9_result = unite(v736_9_result,v737_12);
  }
  const Space v736_9 = std::move(v736_9_result);
  return v736_9;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0) {
  Space v743_11_result;
  for (int v743_11_label = 1; v743_11_label <= 2; ++v743_11_label) {
    const Space v743_11_tail = child(s0,v743_11_label);
    if (v743_11_tail.empty()) continue;
    const Path v743_11_head{v743_11_label};
    const Space v744_2 = singleton(v743_11_head);
    const Space v744_3 = intersect(constant_6,v744_2);
    const Space v744_4 = (has_head(v744_3) ? constant_7 : Space{});
    const Space v744_5 = subtract(constant_0,v744_4);
    Space v744_8;
    if (!v744_5.empty()) {
      const Path v745_6 = concat_path(p0,v743_11_head);
      Space v745_7_result;
      for (int v745_7_label = 1; v745_7_label <= 2; ++v745_7_label) {
        const Space v745_7_tail = child(v743_11_tail,v745_7_label);
        if (v745_7_tail.empty()) continue;
        const Path v745_7_head{v745_7_label};
        const Space v746_2 = singleton(v745_7_head);
        const Space v746_3 = intersect(constant_6,v746_2);
        const Space v746_4 = (has_head(v746_3) ? constant_7 : Space{});
        const Space v746_5 = subtract(constant_0,v746_4);
        Space v746_8;
        if (!v746_5.empty()) {
          const Path v747_6 = concat_path(v745_6,v745_7_head);
          const Space v747_7 = routine_129(c, v747_6, v745_7_tail);
          v746_8 = compose(v746_5,v747_7);
        }
        const Space v746_9 = intersect(constant_6,v746_2);
        const Space v746_10 = (has_head(v746_9) ? constant_7 : Space{});
        Space v746_12;
        if (!v746_10.empty()) {
          const Path v748_6 = concat_path(v745_6,v745_7_head);
          const Space v748_11 = routine_130(c, v748_6, v745_7_tail);
          v746_12 = compose(v746_10,v748_11);
        }
        const Space v746_13 = unite(v746_8,v746_12);
        v745_7_result = unite(v745_7_result,v746_13);
      }
      const Space v745_7 = std::move(v745_7_result);
      v744_8 = compose(v744_5,v745_7);
    }
    const Space v744_9 = intersect(constant_6,v744_2);
    const Space v744_10 = (has_head(v744_9) ? constant_7 : Space{});
    Space v744_12;
    if (!v744_10.empty()) {
      const Path v749_6 = concat_path(p0,v743_11_head);
      Space v749_11_result;
      for (int v749_11_label = 1; v749_11_label <= 2; ++v749_11_label) {
        const Space v749_11_tail = child(v743_11_tail,v749_11_label);
        if (v749_11_tail.empty()) continue;
        const Path v749_11_head{v749_11_label};
        const Space v750_2 = singleton(v749_11_head);
        const Space v750_3 = intersect(constant_6,v750_2);
        const Space v750_4 = (has_head(v750_3) ? constant_7 : Space{});
        const Space v750_5 = subtract(constant_0,v750_4);
        Space v750_8;
        if (!v750_5.empty()) {
          const Path v751_6 = concat_path(v749_6,v749_11_head);
          const Space v751_7 = routine_129(c, v751_6, v749_11_tail);
          v750_8 = compose(v750_5,v751_7);
        }
        const Space v750_9 = intersect(constant_6,v750_2);
        const Space v750_10 = (has_head(v750_9) ? constant_7 : Space{});
        Space v750_12;
        if (!v750_10.empty()) {
          const Path v752_6 = concat_path(v749_6,v749_11_head);
          const Space v752_11 = routine_75(c, v752_6, v749_11_tail);
          v750_12 = compose(v750_10,v752_11);
        }
        const Space v750_13 = unite(v750_8,v750_12);
        v749_11_result = unite(v749_11_result,v750_13);
      }
      const Space v749_11 = std::move(v749_11_result);
      v744_12 = compose(v744_10,v749_11);
    }
    const Space v744_13 = unite(v744_8,v744_12);
    v743_11_result = unite(v743_11_result,v744_13);
  }
  const Space v743_11 = std::move(v743_11_result);
  return v743_11;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  Space v753_8_result;
  for (int v753_8_label = 1; v753_8_label <= 2; ++v753_8_label) {
    const Space v753_8_tail = child(s0,v753_8_label);
    if (v753_8_tail.empty()) continue;
    const Path v753_8_head{v753_8_label};
    const Space v754_2 = singleton(v753_8_head);
    const Space v754_3 = intersect(constant_6,v754_2);
    const Space v754_4 = (has_head(v754_3) ? constant_7 : Space{});
    const Space v754_5 = subtract(constant_0,v754_4);
    Space v754_8;
    if (!v754_5.empty()) {
      const Path v755_6 = concat_path(p0,v753_8_head);
      Space v755_7_result;
      for (int v755_7_label = 1; v755_7_label <= 2; ++v755_7_label) {
        const Space v755_7_tail = child(v753_8_tail,v755_7_label);
        if (v755_7_tail.empty()) continue;
        const Path v755_7_head{v755_7_label};
        const Space v756_2 = singleton(v755_7_head);
        const Space v756_3 = intersect(constant_6,v756_2);
        const Space v756_4 = (has_head(v756_3) ? constant_7 : Space{});
        const Space v756_5 = subtract(constant_0,v756_4);
        Space v756_8;
        if (!v756_5.empty()) {
          const Path v757_6 = concat_path(v755_6,v755_7_head);
          const Space v757_7 = routine_129(c, v757_6, v755_7_tail);
          v756_8 = compose(v756_5,v757_7);
        }
        const Space v756_9 = intersect(constant_6,v756_2);
        const Space v756_10 = (has_head(v756_9) ? constant_7 : Space{});
        Space v756_12;
        if (!v756_10.empty()) {
          const Path v758_6 = concat_path(v755_6,v755_7_head);
          const Space v758_11 = routine_130(c, v758_6, v755_7_tail);
          v756_12 = compose(v756_10,v758_11);
        }
        const Space v756_13 = unite(v756_8,v756_12);
        v755_7_result = unite(v755_7_result,v756_13);
      }
      const Space v755_7 = std::move(v755_7_result);
      v754_8 = compose(v754_5,v755_7);
    }
    const Space v754_9 = intersect(constant_6,v754_2);
    const Space v754_10 = (has_head(v754_9) ? constant_7 : Space{});
    const Space v754_11 = compose(v754_10,v753_8_tail);
    const Space v754_12 = unite(v754_8,v754_11);
    v753_8_result = unite(v753_8_result,v754_12);
  }
  const Space v753_8 = std::move(v753_8_result);
  return v753_8;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v760_13_result;
  for (int v760_13_label = 1; v760_13_label <= 2; ++v760_13_label) {
    const Space v760_13_tail = child(s0,v760_13_label);
    if (v760_13_tail.empty()) continue;
    const Path v760_13_head{v760_13_label};
    const Space v761_2 = singleton(v760_13_head);
    const Space v761_3 = intersect(constant_6,v761_2);
    const Space v761_4 = (has_head(v761_3) ? constant_7 : Space{});
    const Space v761_5 = subtract(constant_0,v761_4);
    Space v761_8;
    if (!v761_5.empty()) {
      const Path v762_6 = concat_path(p0,v760_13_head);
      Space v762_7_result;
      for (int v762_7_label = 1; v762_7_label <= 2; ++v762_7_label) {
        const Space v762_7_tail = child(v760_13_tail,v762_7_label);
        if (v762_7_tail.empty()) continue;
        const Path v762_7_head{v762_7_label};
        const Space v763_2 = singleton(v762_7_head);
        const Space v763_3 = intersect(constant_6,v763_2);
        const Space v763_4 = (has_head(v763_3) ? constant_7 : Space{});
        const Space v763_5 = subtract(constant_0,v763_4);
        Space v763_8;
        if (!v763_5.empty()) {
          const Path v764_6 = concat_path(v762_6,v762_7_head);
          const Space v764_7 = routine_131(c, v764_6, p1, v762_7_tail, s1);
          v763_8 = compose(v763_5,v764_7);
        }
        const Space v763_9 = intersect(constant_6,v763_2);
        const Space v763_10 = (has_head(v763_9) ? constant_7 : Space{});
        Space v763_12;
        if (!v763_10.empty()) {
          const Path v765_6 = concat_path(v762_6,v762_7_head);
          const Space v765_11 = routine_132(c, v765_6, p1, v762_7_tail, s1);
          v763_12 = compose(v763_10,v765_11);
        }
        const Space v763_13 = unite(v763_8,v763_12);
        v762_7_result = unite(v762_7_result,v763_13);
      }
      const Space v762_7 = std::move(v762_7_result);
      v761_8 = compose(v761_5,v762_7);
    }
    const Space v761_9 = intersect(constant_6,v761_2);
    const Space v761_10 = (has_head(v761_9) ? constant_7 : Space{});
    Space v761_12;
    if (!v761_10.empty()) {
      const Path v766_6 = concat_path(p0,v760_13_head);
      Space v766_11_result;
      for (int v766_11_label = 1; v766_11_label <= 2; ++v766_11_label) {
        const Space v766_11_tail = child(v760_13_tail,v766_11_label);
        if (v766_11_tail.empty()) continue;
        const Path v766_11_head{v766_11_label};
        const Space v767_2 = singleton(v766_11_head);
        const Space v767_3 = intersect(constant_6,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_7 : Space{});
        const Space v767_5 = subtract(constant_0,v767_4);
        Space v767_8;
        if (!v767_5.empty()) {
          const Path v768_6 = concat_path(v766_6,v766_11_head);
          const Space v768_7 = routine_131(c, v768_6, p1, v766_11_tail, s1);
          v767_8 = compose(v767_5,v768_7);
        }
        const Space v767_9 = intersect(constant_6,v767_2);
        const Space v767_10 = (has_head(v767_9) ? constant_7 : Space{});
        Space v767_12;
        if (!v767_10.empty()) {
          const Path v769_6 = concat_path(v766_6,v766_11_head);
          const Space v769_11 = routine_26(c, v769_6, p1, v766_11_tail, s1);
          v767_12 = compose(v767_10,v769_11);
        }
        const Space v767_13 = unite(v767_8,v767_12);
        v766_11_result = unite(v766_11_result,v767_13);
      }
      const Space v766_11 = std::move(v766_11_result);
      v761_12 = compose(v761_10,v766_11);
    }
    const Space v761_13 = unite(v761_8,v761_12);
    v760_13_result = unite(v760_13_result,v761_13);
  }
  const Space v760_13 = std::move(v760_13_result);
  return v760_13;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v770_8 = unwrap(s1,constant_8);
  Space v770_21_result;
  for (int v770_21_label = 1; v770_21_label <= 2; ++v770_21_label) {
    const Space v770_21_tail = child(s0,v770_21_label);
    if (v770_21_tail.empty()) continue;
    const Path v770_21_head{v770_21_label};
    const Space v771_2 = singleton(v770_21_head);
    const Space v771_3 = intersect(constant_6,v771_2);
    const Space v771_4 = (has_head(v771_3) ? constant_7 : Space{});
    const Space v771_5 = subtract(constant_0,v771_4);
    Space v771_8;
    if (!v771_5.empty()) {
      const Path v772_6 = concat_path(p0,v770_21_head);
      Space v772_7_result;
      for (int v772_7_label = 1; v772_7_label <= 2; ++v772_7_label) {
        const Space v772_7_tail = child(v770_21_tail,v772_7_label);
        if (v772_7_tail.empty()) continue;
        const Path v772_7_head{v772_7_label};
        const Space v773_2 = singleton(v772_7_head);
        const Space v773_3 = intersect(constant_6,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_7 : Space{});
        const Space v773_5 = subtract(constant_0,v773_4);
        Space v773_8;
        if (!v773_5.empty()) {
          const Path v774_6 = concat_path(v772_6,v772_7_head);
          const Space v774_7 = routine_131(c, v774_6, p1, v772_7_tail, s1);
          v773_8 = compose(v773_5,v774_7);
        }
        const Space v773_9 = intersect(constant_6,v773_2);
        const Space v773_10 = (has_head(v773_9) ? constant_7 : Space{});
        Space v773_12;
        if (!v773_10.empty()) {
          const Path v775_6 = concat_path(v772_6,v772_7_head);
          const Space v775_11 = routine_132(c, v775_6, p1, v772_7_tail, s1);
          v773_12 = compose(v773_10,v775_11);
        }
        const Space v773_13 = unite(v773_8,v773_12);
        v772_7_result = unite(v772_7_result,v773_13);
      }
      const Space v772_7 = std::move(v772_7_result);
      v771_8 = compose(v771_5,v772_7);
    }
    const Space v771_9 = intersect(constant_6,v771_2);
    const Space v771_10 = (has_head(v771_9) ? constant_7 : Space{});
    Space v771_22;
    if (!v771_10.empty()) {
      const Path v776_6 = concat_path(p0,v770_21_head);
      const Path v776_11 = concat_path(p1,v776_6);
      const Space v776_12 = routine_29(c, v776_11);
      const Space v776_13 = intersect(v770_8,v776_12);
      const Space v776_14 = routine_30(c, v776_13);
      Space v776_15_result;
      for (int v776_15_label = 1; v776_15_label <= 2; ++v776_15_label) {
        const Space v776_15_tail = child(v776_14,v776_15_label);
        if (v776_15_tail.empty()) continue;
        const Path v776_15_head{v776_15_label};
        const Space v777_2 = singleton(v776_15_head);
        const Space v777_3 = intersect(constant_6,v777_2);
        const Space v777_4 = (has_head(v777_3) ? constant_7 : Space{});
        const Space v777_5 = subtract(constant_0,v777_4);
        Space v777_7;
        if (!v777_5.empty()) {
          const Space v778_6 = routine_31(c, v776_15_head, v776_15_tail);
          v777_7 = compose(v777_5,v778_6);
        }
        const Space v777_8 = intersect(constant_6,v777_2);
        const Space v777_9 = (has_head(v777_8) ? constant_7 : Space{});
        Space v777_11;
        if (!v777_9.empty()) {
          const Space v779_10 = routine_32(c, v776_15_head, v776_15_tail);
          v777_11 = compose(v777_9,v779_10);
        }
        const Space v777_12 = unite(v777_7,v777_11);
        v776_15_result = unite(v776_15_result,v777_12);
      }
      const Space v776_15 = std::move(v776_15_result);
      const Space v776_16 = routine_33(c, v776_13);
      Space v776_17_result;
      for (int v776_17_label = 1; v776_17_label <= 2; ++v776_17_label) {
        const Space v776_17_tail = child(v776_16,v776_17_label);
        if (v776_17_tail.empty()) continue;
        const Path v776_17_head{v776_17_label};
        const Space v780_2 = singleton(v776_17_head);
        const Space v780_3 = intersect(constant_6,v780_2);
        const Space v780_4 = (has_head(v780_3) ? constant_7 : Space{});
        const Space v780_5 = subtract(constant_0,v780_4);
        Space v780_7;
        if (!v780_5.empty()) {
          const Space v781_6 = routine_34(c, v776_17_head, v776_17_tail);
          v780_7 = compose(v780_5,v781_6);
        }
        const Space v780_8 = intersect(constant_6,v780_2);
        const Space v780_9 = (has_head(v780_8) ? constant_7 : Space{});
        Space v780_11;
        if (!v780_9.empty()) {
          const Space v782_10 = routine_35(c, v776_17_head, v776_17_tail);
          v780_11 = compose(v780_9,v782_10);
        }
        const Space v780_12 = unite(v780_7,v780_11);
        v776_17_result = unite(v776_17_result,v780_12);
      }
      const Space v776_17 = std::move(v776_17_result);
      const Space v776_18 = subtract(v776_15,v776_17);
      const Space v776_19 = singleton(v776_11);
      const Space v776_20 = compose(v776_18,v776_19);
      Space v776_21_result;
      for (int v776_21_label = 1; v776_21_label <= 2; ++v776_21_label) {
        const Space v776_21_tail = child(v776_20,v776_21_label);
        if (v776_21_tail.empty()) continue;
        const Path v776_21_head{v776_21_label};
        const Space v783_2 = singleton(v776_21_head);
        const Space v783_3 = intersect(constant_6,v783_2);
        const Space v783_4 = (has_head(v783_3) ? constant_7 : Space{});
        const Space v783_5 = subtract(constant_0,v783_4);
        Space v783_7;
        if (!v783_5.empty()) {
          const Space v784_6 = routine_36(c, v776_21_head, v776_21_tail);
          v783_7 = compose(v783_5,v784_6);
        }
        const Space v783_8 = intersect(constant_6,v783_2);
        const Space v783_9 = (has_head(v783_8) ? constant_7 : Space{});
        Space v783_11;
        if (!v783_9.empty()) {
          const Space v785_10 = routine_37(c, v776_21_head, v776_21_tail);
          v783_11 = compose(v783_9,v785_10);
        }
        const Space v783_12 = unite(v783_7,v783_11);
        v776_21_result = unite(v776_21_result,v783_12);
      }
      const Space v776_21 = std::move(v776_21_result);
      v771_22 = compose(v771_10,v776_21);
    }
    const Space v771_23 = unite(v771_8,v771_22);
    v770_21_result = unite(v770_21_result,v771_23);
  }
  const Space v770_21 = std::move(v770_21_result);
  return v770_21;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v786_11_result;
  for (int v786_11_label = 1; v786_11_label <= 2; ++v786_11_label) {
    const Space v786_11_tail = child(s0,v786_11_label);
    if (v786_11_tail.empty()) continue;
    const Path v786_11_head{v786_11_label};
    const Space v787_2 = singleton(v786_11_head);
    const Space v787_3 = intersect(constant_6,v787_2);
    const Space v787_4 = (has_head(v787_3) ? constant_7 : Space{});
    const Space v787_5 = subtract(constant_0,v787_4);
    Space v787_8;
    if (!v787_5.empty()) {
      const Path v788_6 = concat_path(p0,v786_11_head);
      Space v788_7_result;
      for (int v788_7_label = 1; v788_7_label <= 2; ++v788_7_label) {
        const Space v788_7_tail = child(v786_11_tail,v788_7_label);
        if (v788_7_tail.empty()) continue;
        const Path v788_7_head{v788_7_label};
        const Space v789_2 = singleton(v788_7_head);
        const Space v789_3 = intersect(constant_6,v789_2);
        const Space v789_4 = (has_head(v789_3) ? constant_7 : Space{});
        const Space v789_5 = subtract(constant_0,v789_4);
        Space v789_8;
        if (!v789_5.empty()) {
          const Path v790_6 = concat_path(v788_6,v788_7_head);
          const Space v790_7 = routine_133(c, v790_6, v788_7_tail);
          v789_8 = compose(v789_5,v790_7);
        }
        const Space v789_9 = intersect(constant_6,v789_2);
        const Space v789_10 = (has_head(v789_9) ? constant_7 : Space{});
        Space v789_12;
        if (!v789_10.empty()) {
          const Path v791_6 = concat_path(v788_6,v788_7_head);
          const Space v791_11 = routine_134(c, v791_6, v788_7_tail);
          v789_12 = compose(v789_10,v791_11);
        }
        const Space v789_13 = unite(v789_8,v789_12);
        v788_7_result = unite(v788_7_result,v789_13);
      }
      const Space v788_7 = std::move(v788_7_result);
      v787_8 = compose(v787_5,v788_7);
    }
    const Space v787_9 = intersect(constant_6,v787_2);
    const Space v787_10 = (has_head(v787_9) ? constant_7 : Space{});
    Space v787_12;
    if (!v787_10.empty()) {
      const Path v792_6 = concat_path(p0,v786_11_head);
      Space v792_11_result;
      for (int v792_11_label = 1; v792_11_label <= 2; ++v792_11_label) {
        const Space v792_11_tail = child(v786_11_tail,v792_11_label);
        if (v792_11_tail.empty()) continue;
        const Path v792_11_head{v792_11_label};
        const Space v793_2 = singleton(v792_11_head);
        const Space v793_3 = intersect(constant_6,v793_2);
        const Space v793_4 = (has_head(v793_3) ? constant_7 : Space{});
        const Space v793_5 = subtract(constant_0,v793_4);
        Space v793_8;
        if (!v793_5.empty()) {
          const Path v794_6 = concat_path(v792_6,v792_11_head);
          const Space v794_7 = routine_133(c, v794_6, v792_11_tail);
          v793_8 = compose(v793_5,v794_7);
        }
        const Space v793_9 = intersect(constant_6,v793_2);
        const Space v793_10 = (has_head(v793_9) ? constant_7 : Space{});
        Space v793_12;
        if (!v793_10.empty()) {
          const Path v795_6 = concat_path(v792_6,v792_11_head);
          const Space v795_11 = routine_80(c, v795_6, v792_11_tail);
          v793_12 = compose(v793_10,v795_11);
        }
        const Space v793_13 = unite(v793_8,v793_12);
        v792_11_result = unite(v792_11_result,v793_13);
      }
      const Space v792_11 = std::move(v792_11_result);
      v787_12 = compose(v787_10,v792_11);
    }
    const Space v787_13 = unite(v787_8,v787_12);
    v786_11_result = unite(v786_11_result,v787_13);
  }
  const Space v786_11 = std::move(v786_11_result);
  return v786_11;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  Space v796_11_result;
  for (int v796_11_label = 1; v796_11_label <= 2; ++v796_11_label) {
    const Space v796_11_tail = child(s0,v796_11_label);
    if (v796_11_tail.empty()) continue;
    const Path v796_11_head{v796_11_label};
    const Space v797_2 = singleton(v796_11_head);
    const Space v797_3 = intersect(constant_6,v797_2);
    const Space v797_4 = (has_head(v797_3) ? constant_7 : Space{});
    const Space v797_5 = subtract(constant_0,v797_4);
    Space v797_8;
    if (!v797_5.empty()) {
      const Path v798_6 = concat_path(p0,v796_11_head);
      Space v798_7_result;
      for (int v798_7_label = 1; v798_7_label <= 2; ++v798_7_label) {
        const Space v798_7_tail = child(v796_11_tail,v798_7_label);
        if (v798_7_tail.empty()) continue;
        const Path v798_7_head{v798_7_label};
        const Space v799_2 = singleton(v798_7_head);
        const Space v799_3 = intersect(constant_6,v799_2);
        const Space v799_4 = (has_head(v799_3) ? constant_7 : Space{});
        const Space v799_5 = subtract(constant_0,v799_4);
        Space v799_8;
        if (!v799_5.empty()) {
          const Path v800_6 = concat_path(v798_6,v798_7_head);
          const Space v800_7 = routine_133(c, v800_6, v798_7_tail);
          v799_8 = compose(v799_5,v800_7);
        }
        const Space v799_9 = intersect(constant_6,v799_2);
        const Space v799_10 = (has_head(v799_9) ? constant_7 : Space{});
        Space v799_12;
        if (!v799_10.empty()) {
          const Path v801_6 = concat_path(v798_6,v798_7_head);
          const Space v801_11 = routine_134(c, v801_6, v798_7_tail);
          v799_12 = compose(v799_10,v801_11);
        }
        const Space v799_13 = unite(v799_8,v799_12);
        v798_7_result = unite(v798_7_result,v799_13);
      }
      const Space v798_7 = std::move(v798_7_result);
      v797_8 = compose(v797_5,v798_7);
    }
    const Space v797_9 = intersect(constant_6,v797_2);
    const Space v797_10 = (has_head(v797_9) ? constant_7 : Space{});
    Space v797_12;
    if (!v797_10.empty()) {
      const Path v802_6 = concat_path(p0,v796_11_head);
      Space v802_11_result;
      for (int v802_11_label = 1; v802_11_label <= 2; ++v802_11_label) {
        const Space v802_11_tail = child(v796_11_tail,v802_11_label);
        if (v802_11_tail.empty()) continue;
        const Path v802_11_head{v802_11_label};
        const Space v803_2 = singleton(v802_11_head);
        const Space v803_3 = intersect(constant_6,v803_2);
        const Space v803_4 = (has_head(v803_3) ? constant_7 : Space{});
        const Space v803_5 = subtract(constant_0,v803_4);
        Space v803_7;
        if (!v803_5.empty()) {
          const Space v804_6 = routine_122(c, v802_11_head, v802_6, v802_11_tail);
          v803_7 = compose(v803_5,v804_6);
        }
        const Space v803_8 = intersect(constant_6,v803_2);
        const Space v803_9 = (has_head(v803_8) ? constant_7 : Space{});
        Space v803_11;
        if (!v803_9.empty()) {
          const Space v805_10 = routine_123(c, v802_11_head, v802_6, v802_11_tail);
          v803_11 = compose(v803_9,v805_10);
        }
        const Space v803_12 = unite(v803_7,v803_11);
        v802_11_result = unite(v802_11_result,v803_12);
      }
      const Space v802_11 = std::move(v802_11_result);
      v797_12 = compose(v797_10,v802_11);
    }
    const Space v797_13 = unite(v797_8,v797_12);
    v796_11_result = unite(v796_11_result,v797_13);
  }
  const Space v796_11 = std::move(v796_11_result);
  return v796_11;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0) {
  Space v806_11_result;
  for (int v806_11_label = 1; v806_11_label <= 2; ++v806_11_label) {
    const Space v806_11_tail = child(s0,v806_11_label);
    if (v806_11_tail.empty()) continue;
    const Path v806_11_head{v806_11_label};
    const Space v807_2 = singleton(v806_11_head);
    const Space v807_3 = intersect(constant_6,v807_2);
    const Space v807_4 = (has_head(v807_3) ? constant_7 : Space{});
    const Space v807_5 = subtract(constant_0,v807_4);
    Space v807_7;
    if (!v807_5.empty()) {
      Space v808_6_result;
      for (int v808_6_label = 1; v808_6_label <= 2; ++v808_6_label) {
        const Space v808_6_tail = child(v806_11_tail,v808_6_label);
        if (v808_6_tail.empty()) continue;
        const Path v808_6_head{v808_6_label};
        const Space v809_2 = singleton(v808_6_head);
        const Space v809_3 = intersect(constant_6,v809_2);
        const Space v809_4 = (has_head(v809_3) ? constant_7 : Space{});
        const Space v809_5 = subtract(constant_0,v809_4);
        Space v809_8;
        if (!v809_5.empty()) {
          const Path v810_6 = concat_path(v806_11_head,v808_6_head);
          const Space v810_7 = routine_135(c, v810_6, p0, v808_6_tail);
          v809_8 = compose(v809_5,v810_7);
        }
        const Space v809_9 = intersect(constant_6,v809_2);
        const Space v809_10 = (has_head(v809_9) ? constant_7 : Space{});
        Space v809_12;
        if (!v809_10.empty()) {
          const Path v811_6 = concat_path(v806_11_head,v808_6_head);
          const Space v811_11 = routine_136(c, v811_6, p0, v808_6_tail);
          v809_12 = compose(v809_10,v811_11);
        }
        const Space v809_13 = unite(v809_8,v809_12);
        v808_6_result = unite(v808_6_result,v809_13);
      }
      const Space v808_6 = std::move(v808_6_result);
      v807_7 = compose(v807_5,v808_6);
    }
    const Space v807_8 = intersect(constant_6,v807_2);
    const Space v807_9 = (has_head(v807_8) ? constant_7 : Space{});
    Space v807_11;
    if (!v807_9.empty()) {
      Space v812_10_result;
      for (int v812_10_label = 1; v812_10_label <= 2; ++v812_10_label) {
        const Space v812_10_tail = child(v806_11_tail,v812_10_label);
        if (v812_10_tail.empty()) continue;
        const Path v812_10_head{v812_10_label};
        const Space v813_2 = singleton(v812_10_head);
        const Space v813_3 = intersect(constant_6,v813_2);
        const Space v813_4 = (has_head(v813_3) ? constant_7 : Space{});
        const Space v813_5 = subtract(constant_0,v813_4);
        Space v813_8;
        if (!v813_5.empty()) {
          const Path v814_6 = concat_path(v806_11_head,v812_10_head);
          const Space v814_7 = routine_135(c, v814_6, p0, v812_10_tail);
          v813_8 = compose(v813_5,v814_7);
        }
        const Space v813_9 = intersect(constant_6,v813_2);
        const Space v813_10 = (has_head(v813_9) ? constant_7 : Space{});
        Space v813_12;
        if (!v813_10.empty()) {
          const Path v815_6 = concat_path(v806_11_head,v812_10_head);
          const Space v815_11 = routine_137(c, v815_6, p0, v812_10_tail);
          v813_12 = compose(v813_10,v815_11);
        }
        const Space v813_13 = unite(v813_8,v813_12);
        v812_10_result = unite(v812_10_result,v813_13);
      }
      const Space v812_10 = std::move(v812_10_result);
      v807_11 = compose(v807_9,v812_10);
    }
    const Space v807_12 = unite(v807_7,v807_11);
    v806_11_result = unite(v806_11_result,v807_12);
  }
  const Space v806_11 = std::move(v806_11_result);
  return v806_11;
}

static Space routine_81(Context& c, const Space& s0) {
  const Space v816_2 = first_matching(s0,constant_0,false);
  const Space v816_3 = intersect(constant_0,v816_2);
  const Space v816_4 = (has_head(v816_2) ? constant_7 : Space{});
  const Space v816_5 = unite(v816_3,v816_4);
  const Space v816_7 = compose(v816_5,constant_0);
  const Space v816_9 = subtract(constant_0,v816_2);
  const Space v816_10 = subtract(v816_9,v816_4);
  Space v816_18;
  if (!v816_10.empty()) {
    const Space v817_11 = first_listed(s0,constant_11,true);
    const Space v817_12 = first_matching(v817_11,constant_0,false);
    Space v817_15;
    if (!v817_12.empty()) {
      const Space v818_14 = routine_138(c, constant_10, s0);
      v817_15 = compose(v817_12,v818_14);
    }
    Space v817_16_result;
    for (int v817_16_label = 1; v817_16_label <= 2; ++v817_16_label) {
      const Space v817_16_tail = child(v817_11,v817_16_label);
      if (v817_16_tail.empty()) continue;
      const Path v817_16_head{v817_16_label};
      const Space v819_2 = routine_124(c, v817_16_head, v817_16_tail, s0);
      v817_16_result = unite(v817_16_result,v819_2);
    }
    const Space v817_16 = std::move(v817_16_result);
    const Space v817_17 = unite(v817_15,v817_16);
    v816_18 = compose(v816_10,v817_17);
  }
  const Space v816_19 = unite(v816_7,v816_18);
  return v816_19;
}

static Space routine_82(Context& c, const Path& p0, const Space& s0) {
  Space v820_11_result;
  for (int v820_11_label = 1; v820_11_label <= 2; ++v820_11_label) {
    const Space v820_11_tail = child(s0,v820_11_label);
    if (v820_11_tail.empty()) continue;
    const Path v820_11_head{v820_11_label};
    const Space v821_2 = singleton(v820_11_head);
    const Space v821_3 = intersect(constant_6,v821_2);
    const Space v821_4 = (has_head(v821_3) ? constant_7 : Space{});
    const Space v821_5 = subtract(constant_0,v821_4);
    Space v821_8;
    if (!v821_5.empty()) {
      const Path v822_6 = concat_path(p0,v820_11_head);
      Space v822_7_result;
      for (int v822_7_label = 1; v822_7_label <= 2; ++v822_7_label) {
        const Space v822_7_tail = child(v820_11_tail,v822_7_label);
        if (v822_7_tail.empty()) continue;
        const Path v822_7_head{v822_7_label};
        const Space v823_2 = singleton(v822_7_head);
        const Space v823_3 = intersect(constant_6,v823_2);
        const Space v823_4 = (has_head(v823_3) ? constant_7 : Space{});
        const Space v823_5 = subtract(constant_0,v823_4);
        Space v823_8;
        if (!v823_5.empty()) {
          const Path v824_6 = concat_path(v822_6,v822_7_head);
          const Space v824_7 = routine_139(c, v824_6, v822_7_tail);
          v823_8 = compose(v823_5,v824_7);
        }
        const Space v823_9 = intersect(constant_6,v823_2);
        const Space v823_10 = (has_head(v823_9) ? constant_7 : Space{});
        Space v823_12;
        if (!v823_10.empty()) {
          const Path v825_6 = concat_path(v822_6,v822_7_head);
          const Space v825_11 = routine_140(c, v825_6, v822_7_tail);
          v823_12 = compose(v823_10,v825_11);
        }
        const Space v823_13 = unite(v823_8,v823_12);
        v822_7_result = unite(v822_7_result,v823_13);
      }
      const Space v822_7 = std::move(v822_7_result);
      v821_8 = compose(v821_5,v822_7);
    }
    const Space v821_9 = intersect(constant_6,v821_2);
    const Space v821_10 = (has_head(v821_9) ? constant_7 : Space{});
    Space v821_12;
    if (!v821_10.empty()) {
      const Path v826_6 = concat_path(p0,v820_11_head);
      Space v826_11_result;
      for (int v826_11_label = 1; v826_11_label <= 2; ++v826_11_label) {
        const Space v826_11_tail = child(v820_11_tail,v826_11_label);
        if (v826_11_tail.empty()) continue;
        const Path v826_11_head{v826_11_label};
        const Space v827_2 = singleton(v826_11_head);
        const Space v827_3 = intersect(constant_6,v827_2);
        const Space v827_4 = (has_head(v827_3) ? constant_7 : Space{});
        const Space v827_5 = subtract(constant_0,v827_4);
        Space v827_8;
        if (!v827_5.empty()) {
          const Path v828_6 = concat_path(v826_6,v826_11_head);
          const Space v828_7 = routine_139(c, v828_6, v826_11_tail);
          v827_8 = compose(v827_5,v828_7);
        }
        const Space v827_9 = intersect(constant_6,v827_2);
        const Space v827_10 = (has_head(v827_9) ? constant_7 : Space{});
        Space v827_12;
        if (!v827_10.empty()) {
          const Path v829_6 = concat_path(v826_6,v826_11_head);
          const Space v829_11 = routine_69(c, v829_6, v826_11_tail);
          v827_12 = compose(v827_10,v829_11);
        }
        const Space v827_13 = unite(v827_8,v827_12);
        v826_11_result = unite(v826_11_result,v827_13);
      }
      const Space v826_11 = std::move(v826_11_result);
      v821_12 = compose(v821_10,v826_11);
    }
    const Space v821_13 = unite(v821_8,v821_12);
    v820_11_result = unite(v820_11_result,v821_13);
  }
  const Space v820_11 = std::move(v820_11_result);
  return v820_11;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v830_9_result;
  for (int v830_9_label = 1; v830_9_label <= 2; ++v830_9_label) {
    const Space v830_9_tail = child(s0,v830_9_label);
    if (v830_9_tail.empty()) continue;
    const Path v830_9_head{v830_9_label};
    const Space v831_2 = singleton(v830_9_head);
    const Space v831_3 = intersect(constant_6,v831_2);
    const Space v831_4 = (has_head(v831_3) ? constant_7 : Space{});
    const Space v831_5 = subtract(constant_0,v831_4);
    Space v831_8;
    if (!v831_5.empty()) {
      const Path v832_6 = concat_path(p0,v830_9_head);
      Space v832_7_result;
      for (int v832_7_label = 1; v832_7_label <= 2; ++v832_7_label) {
        const Space v832_7_tail = child(v830_9_tail,v832_7_label);
        if (v832_7_tail.empty()) continue;
        const Path v832_7_head{v832_7_label};
        const Space v833_2 = singleton(v832_7_head);
        const Space v833_3 = intersect(constant_6,v833_2);
        const Space v833_4 = (has_head(v833_3) ? constant_7 : Space{});
        const Space v833_5 = subtract(constant_0,v833_4);
        Space v833_8;
        if (!v833_5.empty()) {
          const Path v834_6 = concat_path(v832_6,v832_7_head);
          const Space v834_7 = routine_139(c, v834_6, v832_7_tail);
          v833_8 = compose(v833_5,v834_7);
        }
        const Space v833_9 = intersect(constant_6,v833_2);
        const Space v833_10 = (has_head(v833_9) ? constant_7 : Space{});
        Space v833_12;
        if (!v833_10.empty()) {
          const Path v835_6 = concat_path(v832_6,v832_7_head);
          const Space v835_11 = routine_140(c, v835_6, v832_7_tail);
          v833_12 = compose(v833_10,v835_11);
        }
        const Space v833_13 = unite(v833_8,v833_12);
        v832_7_result = unite(v832_7_result,v833_13);
      }
      const Space v832_7 = std::move(v832_7_result);
      v831_8 = compose(v831_5,v832_7);
    }
    const Space v831_9 = intersect(constant_6,v831_2);
    const Space v831_10 = (has_head(v831_9) ? constant_7 : Space{});
    const Space v831_11 = compose(v831_10,constant_9);
    const Space v831_12 = unite(v831_8,v831_11);
    v830_9_result = unite(v830_9_result,v831_12);
  }
  const Space v830_9 = std::move(v830_9_result);
  return v830_9;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0) {
  Space v836_11_result;
  for (int v836_11_label = 1; v836_11_label <= 2; ++v836_11_label) {
    const Space v836_11_tail = child(s0,v836_11_label);
    if (v836_11_tail.empty()) continue;
    const Path v836_11_head{v836_11_label};
    const Space v837_2 = singleton(v836_11_head);
    const Space v837_3 = intersect(constant_6,v837_2);
    const Space v837_4 = (has_head(v837_3) ? constant_7 : Space{});
    const Space v837_5 = subtract(constant_0,v837_4);
    Space v837_8;
    if (!v837_5.empty()) {
      const Path v838_6 = concat_path(p0,v836_11_head);
      Space v838_7_result;
      for (int v838_7_label = 1; v838_7_label <= 2; ++v838_7_label) {
        const Space v838_7_tail = child(v836_11_tail,v838_7_label);
        if (v838_7_tail.empty()) continue;
        const Path v838_7_head{v838_7_label};
        const Space v839_2 = singleton(v838_7_head);
        const Space v839_3 = intersect(constant_6,v839_2);
        const Space v839_4 = (has_head(v839_3) ? constant_7 : Space{});
        const Space v839_5 = subtract(constant_0,v839_4);
        Space v839_8;
        if (!v839_5.empty()) {
          const Path v840_6 = concat_path(v838_6,v838_7_head);
          const Space v840_7 = routine_141(c, v840_6, v838_7_tail);
          v839_8 = compose(v839_5,v840_7);
        }
        const Space v839_9 = intersect(constant_6,v839_2);
        const Space v839_10 = (has_head(v839_9) ? constant_7 : Space{});
        Space v839_12;
        if (!v839_10.empty()) {
          const Path v841_6 = concat_path(v838_6,v838_7_head);
          const Space v841_11 = routine_142(c, v841_6, v838_7_tail);
          v839_12 = compose(v839_10,v841_11);
        }
        const Space v839_13 = unite(v839_8,v839_12);
        v838_7_result = unite(v838_7_result,v839_13);
      }
      const Space v838_7 = std::move(v838_7_result);
      v837_8 = compose(v837_5,v838_7);
    }
    const Space v837_9 = intersect(constant_6,v837_2);
    const Space v837_10 = (has_head(v837_9) ? constant_7 : Space{});
    Space v837_12;
    if (!v837_10.empty()) {
      const Path v842_6 = concat_path(p0,v836_11_head);
      Space v842_11_result;
      for (int v842_11_label = 1; v842_11_label <= 2; ++v842_11_label) {
        const Space v842_11_tail = child(v836_11_tail,v842_11_label);
        if (v842_11_tail.empty()) continue;
        const Path v842_11_head{v842_11_label};
        const Space v843_2 = singleton(v842_11_head);
        const Space v843_3 = intersect(constant_6,v843_2);
        const Space v843_4 = (has_head(v843_3) ? constant_7 : Space{});
        const Space v843_5 = subtract(constant_0,v843_4);
        Space v843_8;
        if (!v843_5.empty()) {
          const Path v844_6 = concat_path(v842_6,v842_11_head);
          const Space v844_7 = routine_141(c, v844_6, v842_11_tail);
          v843_8 = compose(v843_5,v844_7);
        }
        const Space v843_9 = intersect(constant_6,v843_2);
        const Space v843_10 = (has_head(v843_9) ? constant_7 : Space{});
        Space v843_12;
        if (!v843_10.empty()) {
          const Path v845_6 = concat_path(v842_6,v842_11_head);
          const Space v845_11 = routine_72(c, v845_6, v842_11_tail);
          v843_12 = compose(v843_10,v845_11);
        }
        const Space v843_13 = unite(v843_8,v843_12);
        v842_11_result = unite(v842_11_result,v843_13);
      }
      const Space v842_11 = std::move(v842_11_result);
      v837_12 = compose(v837_10,v842_11);
    }
    const Space v837_13 = unite(v837_8,v837_12);
    v836_11_result = unite(v836_11_result,v837_13);
  }
  const Space v836_11 = std::move(v836_11_result);
  return v836_11;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0) {
  Space v846_9_result;
  for (int v846_9_label = 1; v846_9_label <= 2; ++v846_9_label) {
    const Space v846_9_tail = child(s0,v846_9_label);
    if (v846_9_tail.empty()) continue;
    const Path v846_9_head{v846_9_label};
    const Space v847_2 = singleton(v846_9_head);
    const Space v847_3 = intersect(constant_6,v847_2);
    const Space v847_4 = (has_head(v847_3) ? constant_7 : Space{});
    const Space v847_5 = subtract(constant_0,v847_4);
    Space v847_8;
    if (!v847_5.empty()) {
      const Path v848_6 = concat_path(p0,v846_9_head);
      Space v848_7_result;
      for (int v848_7_label = 1; v848_7_label <= 2; ++v848_7_label) {
        const Space v848_7_tail = child(v846_9_tail,v848_7_label);
        if (v848_7_tail.empty()) continue;
        const Path v848_7_head{v848_7_label};
        const Space v849_2 = singleton(v848_7_head);
        const Space v849_3 = intersect(constant_6,v849_2);
        const Space v849_4 = (has_head(v849_3) ? constant_7 : Space{});
        const Space v849_5 = subtract(constant_0,v849_4);
        Space v849_8;
        if (!v849_5.empty()) {
          const Path v850_6 = concat_path(v848_6,v848_7_head);
          const Space v850_7 = routine_141(c, v850_6, v848_7_tail);
          v849_8 = compose(v849_5,v850_7);
        }
        const Space v849_9 = intersect(constant_6,v849_2);
        const Space v849_10 = (has_head(v849_9) ? constant_7 : Space{});
        Space v849_12;
        if (!v849_10.empty()) {
          const Path v851_6 = concat_path(v848_6,v848_7_head);
          const Space v851_11 = routine_142(c, v851_6, v848_7_tail);
          v849_12 = compose(v849_10,v851_11);
        }
        const Space v849_13 = unite(v849_8,v849_12);
        v848_7_result = unite(v848_7_result,v849_13);
      }
      const Space v848_7 = std::move(v848_7_result);
      v847_8 = compose(v847_5,v848_7);
    }
    const Space v847_9 = intersect(constant_6,v847_2);
    const Space v847_10 = (has_head(v847_9) ? constant_7 : Space{});
    const Space v847_11 = compose(v847_10,constant_9);
    const Space v847_12 = unite(v847_8,v847_11);
    v846_9_result = unite(v846_9_result,v847_12);
  }
  const Space v846_9 = std::move(v846_9_result);
  return v846_9;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0) {
  Space v852_11_result;
  for (int v852_11_label = 1; v852_11_label <= 2; ++v852_11_label) {
    const Space v852_11_tail = child(s0,v852_11_label);
    if (v852_11_tail.empty()) continue;
    const Path v852_11_head{v852_11_label};
    const Space v853_2 = singleton(v852_11_head);
    const Space v853_3 = intersect(constant_6,v853_2);
    const Space v853_4 = (has_head(v853_3) ? constant_7 : Space{});
    const Space v853_5 = subtract(constant_0,v853_4);
    Space v853_8;
    if (!v853_5.empty()) {
      const Path v854_6 = concat_path(p0,v852_11_head);
      Space v854_7_result;
      for (int v854_7_label = 1; v854_7_label <= 2; ++v854_7_label) {
        const Space v854_7_tail = child(v852_11_tail,v854_7_label);
        if (v854_7_tail.empty()) continue;
        const Path v854_7_head{v854_7_label};
        const Space v855_2 = singleton(v854_7_head);
        const Space v855_3 = intersect(constant_6,v855_2);
        const Space v855_4 = (has_head(v855_3) ? constant_7 : Space{});
        const Space v855_5 = subtract(constant_0,v855_4);
        Space v855_8;
        if (!v855_5.empty()) {
          const Path v856_6 = concat_path(v854_6,v854_7_head);
          const Space v856_7 = routine_143(c, v856_6, v854_7_tail);
          v855_8 = compose(v855_5,v856_7);
        }
        const Space v855_9 = intersect(constant_6,v855_2);
        const Space v855_10 = (has_head(v855_9) ? constant_7 : Space{});
        Space v855_12;
        if (!v855_10.empty()) {
          const Path v857_6 = concat_path(v854_6,v854_7_head);
          const Space v857_11 = routine_144(c, v857_6, v854_7_tail);
          v855_12 = compose(v855_10,v857_11);
        }
        const Space v855_13 = unite(v855_8,v855_12);
        v854_7_result = unite(v854_7_result,v855_13);
      }
      const Space v854_7 = std::move(v854_7_result);
      v853_8 = compose(v853_5,v854_7);
    }
    const Space v853_9 = intersect(constant_6,v853_2);
    const Space v853_10 = (has_head(v853_9) ? constant_7 : Space{});
    Space v853_12;
    if (!v853_10.empty()) {
      const Path v858_6 = concat_path(p0,v852_11_head);
      Space v858_11_result;
      for (int v858_11_label = 1; v858_11_label <= 2; ++v858_11_label) {
        const Space v858_11_tail = child(v852_11_tail,v858_11_label);
        if (v858_11_tail.empty()) continue;
        const Path v858_11_head{v858_11_label};
        const Space v859_2 = singleton(v858_11_head);
        const Space v859_3 = intersect(constant_6,v859_2);
        const Space v859_4 = (has_head(v859_3) ? constant_7 : Space{});
        const Space v859_5 = subtract(constant_0,v859_4);
        Space v859_8;
        if (!v859_5.empty()) {
          const Path v860_6 = concat_path(v858_6,v858_11_head);
          const Space v860_7 = routine_143(c, v860_6, v858_11_tail);
          v859_8 = compose(v859_5,v860_7);
        }
        const Space v859_9 = intersect(constant_6,v859_2);
        const Space v859_10 = (has_head(v859_9) ? constant_7 : Space{});
        Space v859_12;
        if (!v859_10.empty()) {
          const Path v861_6 = concat_path(v858_6,v858_11_head);
          const Space v861_11 = routine_75(c, v861_6, v858_11_tail);
          v859_12 = compose(v859_10,v861_11);
        }
        const Space v859_13 = unite(v859_8,v859_12);
        v858_11_result = unite(v858_11_result,v859_13);
      }
      const Space v858_11 = std::move(v858_11_result);
      v853_12 = compose(v853_10,v858_11);
    }
    const Space v853_13 = unite(v853_8,v853_12);
    v852_11_result = unite(v852_11_result,v853_13);
  }
  const Space v852_11 = std::move(v852_11_result);
  return v852_11;
}

static Space routine_87(Context& c, const Path& p0, const Space& s0) {
  Space v862_8_result;
  for (int v862_8_label = 1; v862_8_label <= 2; ++v862_8_label) {
    const Space v862_8_tail = child(s0,v862_8_label);
    if (v862_8_tail.empty()) continue;
    const Path v862_8_head{v862_8_label};
    const Space v863_2 = singleton(v862_8_head);
    const Space v863_3 = intersect(constant_6,v863_2);
    const Space v863_4 = (has_head(v863_3) ? constant_7 : Space{});
    const Space v863_5 = subtract(constant_0,v863_4);
    Space v863_8;
    if (!v863_5.empty()) {
      const Path v864_6 = concat_path(p0,v862_8_head);
      Space v864_7_result;
      for (int v864_7_label = 1; v864_7_label <= 2; ++v864_7_label) {
        const Space v864_7_tail = child(v862_8_tail,v864_7_label);
        if (v864_7_tail.empty()) continue;
        const Path v864_7_head{v864_7_label};
        const Space v865_2 = singleton(v864_7_head);
        const Space v865_3 = intersect(constant_6,v865_2);
        const Space v865_4 = (has_head(v865_3) ? constant_7 : Space{});
        const Space v865_5 = subtract(constant_0,v865_4);
        Space v865_8;
        if (!v865_5.empty()) {
          const Path v866_6 = concat_path(v864_6,v864_7_head);
          const Space v866_7 = routine_143(c, v866_6, v864_7_tail);
          v865_8 = compose(v865_5,v866_7);
        }
        const Space v865_9 = intersect(constant_6,v865_2);
        const Space v865_10 = (has_head(v865_9) ? constant_7 : Space{});
        Space v865_12;
        if (!v865_10.empty()) {
          const Path v867_6 = concat_path(v864_6,v864_7_head);
          const Space v867_11 = routine_144(c, v867_6, v864_7_tail);
          v865_12 = compose(v865_10,v867_11);
        }
        const Space v865_13 = unite(v865_8,v865_12);
        v864_7_result = unite(v864_7_result,v865_13);
      }
      const Space v864_7 = std::move(v864_7_result);
      v863_8 = compose(v863_5,v864_7);
    }
    const Space v863_9 = intersect(constant_6,v863_2);
    const Space v863_10 = (has_head(v863_9) ? constant_7 : Space{});
    const Space v863_11 = compose(v863_10,v862_8_tail);
    const Space v863_12 = unite(v863_8,v863_11);
    v862_8_result = unite(v862_8_result,v863_12);
  }
  const Space v862_8 = std::move(v862_8_result);
  return v862_8;
}

static Space routine_88(Context& c, const Path& p0, const Space& s0) {
  Space v868_11_result;
  for (int v868_11_label = 1; v868_11_label <= 2; ++v868_11_label) {
    const Space v868_11_tail = child(s0,v868_11_label);
    if (v868_11_tail.empty()) continue;
    const Path v868_11_head{v868_11_label};
    const Space v869_2 = singleton(v868_11_head);
    const Space v869_3 = intersect(constant_6,v869_2);
    const Space v869_4 = (has_head(v869_3) ? constant_7 : Space{});
    const Space v869_5 = subtract(constant_0,v869_4);
    Space v869_8;
    if (!v869_5.empty()) {
      const Path v870_6 = concat_path(p0,v868_11_head);
      Space v870_7_result;
      for (int v870_7_label = 1; v870_7_label <= 2; ++v870_7_label) {
        const Space v870_7_tail = child(v868_11_tail,v870_7_label);
        if (v870_7_tail.empty()) continue;
        const Path v870_7_head{v870_7_label};
        const Space v871_2 = singleton(v870_7_head);
        const Space v871_3 = intersect(constant_6,v871_2);
        const Space v871_4 = (has_head(v871_3) ? constant_7 : Space{});
        const Space v871_5 = subtract(constant_0,v871_4);
        Space v871_8;
        if (!v871_5.empty()) {
          const Path v872_6 = concat_path(v870_6,v870_7_head);
          const Space v872_7 = routine_145(c, v872_6, v870_7_tail);
          v871_8 = compose(v871_5,v872_7);
        }
        const Space v871_9 = intersect(constant_6,v871_2);
        const Space v871_10 = (has_head(v871_9) ? constant_7 : Space{});
        Space v871_12;
        if (!v871_10.empty()) {
          const Path v873_6 = concat_path(v870_6,v870_7_head);
          const Space v873_11 = routine_146(c, v873_6, v870_7_tail);
          v871_12 = compose(v871_10,v873_11);
        }
        const Space v871_13 = unite(v871_8,v871_12);
        v870_7_result = unite(v870_7_result,v871_13);
      }
      const Space v870_7 = std::move(v870_7_result);
      v869_8 = compose(v869_5,v870_7);
    }
    const Space v869_9 = intersect(constant_6,v869_2);
    const Space v869_10 = (has_head(v869_9) ? constant_7 : Space{});
    Space v869_12;
    if (!v869_10.empty()) {
      const Path v874_6 = concat_path(p0,v868_11_head);
      Space v874_11_result;
      for (int v874_11_label = 1; v874_11_label <= 2; ++v874_11_label) {
        const Space v874_11_tail = child(v868_11_tail,v874_11_label);
        if (v874_11_tail.empty()) continue;
        const Path v874_11_head{v874_11_label};
        const Space v875_2 = singleton(v874_11_head);
        const Space v875_3 = intersect(constant_6,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_7 : Space{});
        const Space v875_5 = subtract(constant_0,v875_4);
        Space v875_8;
        if (!v875_5.empty()) {
          const Path v876_6 = concat_path(v874_6,v874_11_head);
          const Space v876_7 = routine_145(c, v876_6, v874_11_tail);
          v875_8 = compose(v875_5,v876_7);
        }
        const Space v875_9 = intersect(constant_6,v875_2);
        const Space v875_10 = (has_head(v875_9) ? constant_7 : Space{});
        Space v875_12;
        if (!v875_10.empty()) {
          const Path v877_6 = concat_path(v874_6,v874_11_head);
          const Space v877_11 = routine_14(c, v877_6, v874_11_tail);
          v875_12 = compose(v875_10,v877_11);
        }
        const Space v875_13 = unite(v875_8,v875_12);
        v874_11_result = unite(v874_11_result,v875_13);
      }
      const Space v874_11 = std::move(v874_11_result);
      v869_12 = compose(v869_10,v874_11);
    }
    const Space v869_13 = unite(v869_8,v869_12);
    v868_11_result = unite(v868_11_result,v869_13);
  }
  const Space v868_11 = std::move(v868_11_result);
  return v868_11;
}

static Space routine_89(Context& c, const Path& p0, const Space& s0) {
  Space v878_11_result;
  for (int v878_11_label = 1; v878_11_label <= 2; ++v878_11_label) {
    const Space v878_11_tail = child(s0,v878_11_label);
    if (v878_11_tail.empty()) continue;
    const Path v878_11_head{v878_11_label};
    const Space v879_2 = singleton(v878_11_head);
    const Space v879_3 = intersect(constant_6,v879_2);
    const Space v879_4 = (has_head(v879_3) ? constant_7 : Space{});
    const Space v879_5 = subtract(constant_0,v879_4);
    Space v879_8;
    if (!v879_5.empty()) {
      const Path v880_6 = concat_path(p0,v878_11_head);
      Space v880_7_result;
      for (int v880_7_label = 1; v880_7_label <= 2; ++v880_7_label) {
        const Space v880_7_tail = child(v878_11_tail,v880_7_label);
        if (v880_7_tail.empty()) continue;
        const Path v880_7_head{v880_7_label};
        const Space v881_2 = singleton(v880_7_head);
        const Space v881_3 = intersect(constant_6,v881_2);
        const Space v881_4 = (has_head(v881_3) ? constant_7 : Space{});
        const Space v881_5 = subtract(constant_0,v881_4);
        Space v881_8;
        if (!v881_5.empty()) {
          const Path v882_6 = concat_path(v880_6,v880_7_head);
          const Space v882_7 = routine_145(c, v882_6, v880_7_tail);
          v881_8 = compose(v881_5,v882_7);
        }
        const Space v881_9 = intersect(constant_6,v881_2);
        const Space v881_10 = (has_head(v881_9) ? constant_7 : Space{});
        Space v881_12;
        if (!v881_10.empty()) {
          const Path v883_6 = concat_path(v880_6,v880_7_head);
          const Space v883_11 = routine_146(c, v883_6, v880_7_tail);
          v881_12 = compose(v881_10,v883_11);
        }
        const Space v881_13 = unite(v881_8,v881_12);
        v880_7_result = unite(v880_7_result,v881_13);
      }
      const Space v880_7 = std::move(v880_7_result);
      v879_8 = compose(v879_5,v880_7);
    }
    const Space v879_9 = intersect(constant_6,v879_2);
    const Space v879_10 = (has_head(v879_9) ? constant_7 : Space{});
    Space v879_12;
    if (!v879_10.empty()) {
      const Path v884_6 = concat_path(p0,v878_11_head);
      Space v884_11_result;
      for (int v884_11_label = 1; v884_11_label <= 2; ++v884_11_label) {
        const Space v884_11_tail = child(v878_11_tail,v884_11_label);
        if (v884_11_tail.empty()) continue;
        const Path v884_11_head{v884_11_label};
        const Space v885_2 = singleton(v884_11_head);
        const Space v885_3 = intersect(constant_6,v885_2);
        const Space v885_4 = (has_head(v885_3) ? constant_7 : Space{});
        const Space v885_5 = subtract(constant_0,v885_4);
        Space v885_7;
        if (!v885_5.empty()) {
          const Space v886_6 = routine_15(c, v884_11_head, v884_6, v884_11_tail);
          v885_7 = compose(v885_5,v886_6);
        }
        const Space v885_8 = intersect(constant_6,v885_2);
        const Space v885_9 = (has_head(v885_8) ? constant_7 : Space{});
        Space v885_11;
        if (!v885_9.empty()) {
          const Space v887_10 = routine_16(c, v884_11_head, v884_6, v884_11_tail);
          v885_11 = compose(v885_9,v887_10);
        }
        const Space v885_12 = unite(v885_7,v885_11);
        v884_11_result = unite(v884_11_result,v885_12);
      }
      const Space v884_11 = std::move(v884_11_result);
      v879_12 = compose(v879_10,v884_11);
    }
    const Space v879_13 = unite(v879_8,v879_12);
    v878_11_result = unite(v878_11_result,v879_13);
  }
  const Space v878_11 = std::move(v878_11_result);
  return v878_11;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v888_12_result;
  for (int v888_12_label = 1; v888_12_label <= 2; ++v888_12_label) {
    const Space v888_12_tail = child(s0,v888_12_label);
    if (v888_12_tail.empty()) continue;
    const Path v888_12_head{v888_12_label};
    const Space v889_2 = singleton(v888_12_head);
    const Space v889_3 = intersect(constant_6,v889_2);
    const Space v889_4 = (has_head(v889_3) ? constant_7 : Space{});
    const Space v889_5 = subtract(constant_0,v889_4);
    Space v889_8;
    if (!v889_5.empty()) {
      const Path v890_6 = concat_path(p0,v888_12_head);
      Space v890_7_result;
      for (int v890_7_label = 1; v890_7_label <= 2; ++v890_7_label) {
        const Space v890_7_tail = child(v888_12_tail,v890_7_label);
        if (v890_7_tail.empty()) continue;
        const Path v890_7_head{v890_7_label};
        const Space v891_2 = singleton(v890_7_head);
        const Space v891_3 = intersect(constant_6,v891_2);
        const Space v891_4 = (has_head(v891_3) ? constant_7 : Space{});
        const Space v891_5 = subtract(constant_0,v891_4);
        Space v891_8;
        if (!v891_5.empty()) {
          const Path v892_6 = concat_path(v890_6,v890_7_head);
          const Space v892_7 = routine_147(c, v892_6, p1, v890_7_tail);
          v891_8 = compose(v891_5,v892_7);
        }
        const Space v891_9 = intersect(constant_6,v891_2);
        const Space v891_10 = (has_head(v891_9) ? constant_7 : Space{});
        Space v891_12;
        if (!v891_10.empty()) {
          const Path v893_6 = concat_path(v890_6,v890_7_head);
          const Space v893_11 = routine_148(c, v893_6, p1, v890_7_tail);
          v891_12 = compose(v891_10,v893_11);
        }
        const Space v891_13 = unite(v891_8,v891_12);
        v890_7_result = unite(v890_7_result,v891_13);
      }
      const Space v890_7 = std::move(v890_7_result);
      v889_8 = compose(v889_5,v890_7);
    }
    const Space v889_9 = intersect(constant_6,v889_2);
    const Space v889_10 = (has_head(v889_9) ? constant_7 : Space{});
    Space v889_12;
    if (!v889_10.empty()) {
      const Path v894_6 = concat_path(p0,v888_12_head);
      Space v894_11_result;
      for (int v894_11_label = 1; v894_11_label <= 2; ++v894_11_label) {
        const Space v894_11_tail = child(v888_12_tail,v894_11_label);
        if (v894_11_tail.empty()) continue;
        const Path v894_11_head{v894_11_label};
        const Space v895_2 = singleton(v894_11_head);
        const Space v895_3 = intersect(constant_6,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_7 : Space{});
        const Space v895_5 = subtract(constant_0,v895_4);
        Space v895_8;
        if (!v895_5.empty()) {
          const Path v896_6 = concat_path(v894_6,v894_11_head);
          const Space v896_7 = routine_147(c, v896_6, p1, v894_11_tail);
          v895_8 = compose(v895_5,v896_7);
        }
        const Space v895_9 = intersect(constant_6,v895_2);
        const Space v895_10 = (has_head(v895_9) ? constant_7 : Space{});
        Space v895_12;
        if (!v895_10.empty()) {
          const Path v897_6 = concat_path(v894_6,v894_11_head);
          const Space v897_11 = routine_42(c, v897_6, p1, v894_11_tail);
          v895_12 = compose(v895_10,v897_11);
        }
        const Space v895_13 = unite(v895_8,v895_12);
        v894_11_result = unite(v894_11_result,v895_13);
      }
      const Space v894_11 = std::move(v894_11_result);
      v889_12 = compose(v889_10,v894_11);
    }
    const Space v889_13 = unite(v889_8,v889_12);
    v888_12_result = unite(v888_12_result,v889_13);
  }
  const Space v888_12 = std::move(v888_12_result);
  return v888_12;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v898_9_result;
  for (int v898_9_label = 1; v898_9_label <= 2; ++v898_9_label) {
    const Space v898_9_tail = child(s0,v898_9_label);
    if (v898_9_tail.empty()) continue;
    const Path v898_9_head{v898_9_label};
    const Space v899_2 = singleton(v898_9_head);
    const Space v899_3 = intersect(constant_6,v899_2);
    const Space v899_4 = (has_head(v899_3) ? constant_7 : Space{});
    const Space v899_5 = subtract(constant_0,v899_4);
    Space v899_8;
    if (!v899_5.empty()) {
      const Path v900_6 = concat_path(p0,v898_9_head);
      Space v900_7_result;
      for (int v900_7_label = 1; v900_7_label <= 2; ++v900_7_label) {
        const Space v900_7_tail = child(v898_9_tail,v900_7_label);
        if (v900_7_tail.empty()) continue;
        const Path v900_7_head{v900_7_label};
        const Space v901_2 = singleton(v900_7_head);
        const Space v901_3 = intersect(constant_6,v901_2);
        const Space v901_4 = (has_head(v901_3) ? constant_7 : Space{});
        const Space v901_5 = subtract(constant_0,v901_4);
        Space v901_8;
        if (!v901_5.empty()) {
          const Path v902_6 = concat_path(v900_6,v900_7_head);
          const Space v902_7 = routine_147(c, v902_6, p1, v900_7_tail);
          v901_8 = compose(v901_5,v902_7);
        }
        const Space v901_9 = intersect(constant_6,v901_2);
        const Space v901_10 = (has_head(v901_9) ? constant_7 : Space{});
        Space v901_12;
        if (!v901_10.empty()) {
          const Path v903_6 = concat_path(v900_6,v900_7_head);
          const Space v903_11 = routine_148(c, v903_6, p1, v900_7_tail);
          v901_12 = compose(v901_10,v903_11);
        }
        const Space v901_13 = unite(v901_8,v901_12);
        v900_7_result = unite(v900_7_result,v901_13);
      }
      const Space v900_7 = std::move(v900_7_result);
      v899_8 = compose(v899_5,v900_7);
    }
    const Space v899_9 = intersect(constant_6,v899_2);
    const Space v899_10 = (has_head(v899_9) ? constant_7 : Space{});
    Space v899_13;
    if (!v899_10.empty()) {
      const Path v904_6 = concat_path(p0,v898_9_head);
      const Path v904_11 = concat_path(p1,v904_6);
      const Space v904_12 = routine_29(c, v904_11);
      v899_13 = compose(v899_10,v904_12);
    }
    const Space v899_14 = unite(v899_8,v899_13);
    v898_9_result = unite(v898_9_result,v899_14);
  }
  const Space v898_9 = std::move(v898_9_result);
  return v898_9;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v905_12_result;
  for (int v905_12_label = 1; v905_12_label <= 2; ++v905_12_label) {
    const Space v905_12_tail = child(s0,v905_12_label);
    if (v905_12_tail.empty()) continue;
    const Path v905_12_head{v905_12_label};
    const Space v906_2 = singleton(v905_12_head);
    const Space v906_3 = intersect(constant_6,v906_2);
    const Space v906_4 = (has_head(v906_3) ? constant_7 : Space{});
    const Space v906_5 = subtract(constant_0,v906_4);
    Space v906_8;
    if (!v906_5.empty()) {
      const Path v907_6 = concat_path(p0,v905_12_head);
      Space v907_7_result;
      for (int v907_7_label = 1; v907_7_label <= 2; ++v907_7_label) {
        const Space v907_7_tail = child(v905_12_tail,v907_7_label);
        if (v907_7_tail.empty()) continue;
        const Path v907_7_head{v907_7_label};
        const Space v908_2 = singleton(v907_7_head);
        const Space v908_3 = intersect(constant_6,v908_2);
        const Space v908_4 = (has_head(v908_3) ? constant_7 : Space{});
        const Space v908_5 = subtract(constant_0,v908_4);
        Space v908_8;
        if (!v908_5.empty()) {
          const Path v909_6 = concat_path(v907_6,v907_7_head);
          const Space v909_7 = routine_149(c, v909_6, p1, v907_7_tail);
          v908_8 = compose(v908_5,v909_7);
        }
        const Space v908_9 = intersect(constant_6,v908_2);
        const Space v908_10 = (has_head(v908_9) ? constant_7 : Space{});
        Space v908_12;
        if (!v908_10.empty()) {
          const Path v910_6 = concat_path(v907_6,v907_7_head);
          const Space v910_11 = routine_150(c, v910_6, p1, v907_7_tail);
          v908_12 = compose(v908_10,v910_11);
        }
        const Space v908_13 = unite(v908_8,v908_12);
        v907_7_result = unite(v907_7_result,v908_13);
      }
      const Space v907_7 = std::move(v907_7_result);
      v906_8 = compose(v906_5,v907_7);
    }
    const Space v906_9 = intersect(constant_6,v906_2);
    const Space v906_10 = (has_head(v906_9) ? constant_7 : Space{});
    Space v906_12;
    if (!v906_10.empty()) {
      const Path v911_6 = concat_path(p0,v905_12_head);
      Space v911_11_result;
      for (int v911_11_label = 1; v911_11_label <= 2; ++v911_11_label) {
        const Space v911_11_tail = child(v905_12_tail,v911_11_label);
        if (v911_11_tail.empty()) continue;
        const Path v911_11_head{v911_11_label};
        const Space v912_2 = singleton(v911_11_head);
        const Space v912_3 = intersect(constant_6,v912_2);
        const Space v912_4 = (has_head(v912_3) ? constant_7 : Space{});
        const Space v912_5 = subtract(constant_0,v912_4);
        Space v912_8;
        if (!v912_5.empty()) {
          const Path v913_6 = concat_path(v911_6,v911_11_head);
          const Space v913_7 = routine_149(c, v913_6, p1, v911_11_tail);
          v912_8 = compose(v912_5,v913_7);
        }
        const Space v912_9 = intersect(constant_6,v912_2);
        const Space v912_10 = (has_head(v912_9) ? constant_7 : Space{});
        Space v912_12;
        if (!v912_10.empty()) {
          const Path v914_6 = concat_path(v911_6,v911_11_head);
          const Space v914_11 = routine_42(c, v914_6, p1, v911_11_tail);
          v912_12 = compose(v912_10,v914_11);
        }
        const Space v912_13 = unite(v912_8,v912_12);
        v911_11_result = unite(v911_11_result,v912_13);
      }
      const Space v911_11 = std::move(v911_11_result);
      v906_12 = compose(v906_10,v911_11);
    }
    const Space v906_13 = unite(v906_8,v906_12);
    v905_12_result = unite(v905_12_result,v906_13);
  }
  const Space v905_12 = std::move(v905_12_result);
  return v905_12;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v915_9_result;
  for (int v915_9_label = 1; v915_9_label <= 2; ++v915_9_label) {
    const Space v915_9_tail = child(s0,v915_9_label);
    if (v915_9_tail.empty()) continue;
    const Path v915_9_head{v915_9_label};
    const Space v916_2 = singleton(v915_9_head);
    const Space v916_3 = intersect(constant_6,v916_2);
    const Space v916_4 = (has_head(v916_3) ? constant_7 : Space{});
    const Space v916_5 = subtract(constant_0,v916_4);
    Space v916_8;
    if (!v916_5.empty()) {
      const Path v917_6 = concat_path(p0,v915_9_head);
      Space v917_7_result;
      for (int v917_7_label = 1; v917_7_label <= 2; ++v917_7_label) {
        const Space v917_7_tail = child(v915_9_tail,v917_7_label);
        if (v917_7_tail.empty()) continue;
        const Path v917_7_head{v917_7_label};
        const Space v918_2 = singleton(v917_7_head);
        const Space v918_3 = intersect(constant_6,v918_2);
        const Space v918_4 = (has_head(v918_3) ? constant_7 : Space{});
        const Space v918_5 = subtract(constant_0,v918_4);
        Space v918_8;
        if (!v918_5.empty()) {
          const Path v919_6 = concat_path(v917_6,v917_7_head);
          const Space v919_7 = routine_149(c, v919_6, p1, v917_7_tail);
          v918_8 = compose(v918_5,v919_7);
        }
        const Space v918_9 = intersect(constant_6,v918_2);
        const Space v918_10 = (has_head(v918_9) ? constant_7 : Space{});
        Space v918_12;
        if (!v918_10.empty()) {
          const Path v920_6 = concat_path(v917_6,v917_7_head);
          const Space v920_11 = routine_150(c, v920_6, p1, v917_7_tail);
          v918_12 = compose(v918_10,v920_11);
        }
        const Space v918_13 = unite(v918_8,v918_12);
        v917_7_result = unite(v917_7_result,v918_13);
      }
      const Space v917_7 = std::move(v917_7_result);
      v916_8 = compose(v916_5,v917_7);
    }
    const Space v916_9 = intersect(constant_6,v916_2);
    const Space v916_10 = (has_head(v916_9) ? constant_7 : Space{});
    Space v916_13;
    if (!v916_10.empty()) {
      const Path v921_6 = concat_path(p0,v915_9_head);
      const Path v921_11 = concat_path(p1,v921_6);
      const Space v921_12 = routine_29(c, v921_11);
      v916_13 = compose(v916_10,v921_12);
    }
    const Space v916_14 = unite(v916_8,v916_13);
    v915_9_result = unite(v915_9_result,v916_14);
  }
  const Space v915_9 = std::move(v915_9_result);
  return v915_9;
}

static Space routine_94(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v922_12_result;
  for (int v922_12_label = 1; v922_12_label <= 2; ++v922_12_label) {
    const Space v922_12_tail = child(s0,v922_12_label);
    if (v922_12_tail.empty()) continue;
    const Path v922_12_head{v922_12_label};
    const Space v923_2 = singleton(v922_12_head);
    const Space v923_3 = intersect(constant_6,v923_2);
    const Space v923_4 = (has_head(v923_3) ? constant_7 : Space{});
    const Space v923_5 = subtract(constant_0,v923_4);
    Space v923_8;
    if (!v923_5.empty()) {
      const Path v924_6 = concat_path(p0,v922_12_head);
      Space v924_7_result;
      for (int v924_7_label = 1; v924_7_label <= 2; ++v924_7_label) {
        const Space v924_7_tail = child(v922_12_tail,v924_7_label);
        if (v924_7_tail.empty()) continue;
        const Path v924_7_head{v924_7_label};
        const Space v925_2 = singleton(v924_7_head);
        const Space v925_3 = intersect(constant_6,v925_2);
        const Space v925_4 = (has_head(v925_3) ? constant_7 : Space{});
        const Space v925_5 = subtract(constant_0,v925_4);
        Space v925_8;
        if (!v925_5.empty()) {
          const Path v926_6 = concat_path(v924_6,v924_7_head);
          const Space v926_7 = routine_151(c, v926_6, v924_7_tail, s1);
          v925_8 = compose(v925_5,v926_7);
        }
        const Space v925_9 = intersect(constant_6,v925_2);
        const Space v925_10 = (has_head(v925_9) ? constant_7 : Space{});
        Space v925_12;
        if (!v925_10.empty()) {
          const Path v927_6 = concat_path(v924_6,v924_7_head);
          const Space v927_11 = routine_152(c, v927_6, v924_7_tail, s1);
          v925_12 = compose(v925_10,v927_11);
        }
        const Space v925_13 = unite(v925_8,v925_12);
        v924_7_result = unite(v924_7_result,v925_13);
      }
      const Space v924_7 = std::move(v924_7_result);
      v923_8 = compose(v923_5,v924_7);
    }
    const Space v923_9 = intersect(constant_6,v923_2);
    const Space v923_10 = (has_head(v923_9) ? constant_7 : Space{});
    Space v923_12;
    if (!v923_10.empty()) {
      const Path v928_6 = concat_path(p0,v922_12_head);
      Space v928_11_result;
      for (int v928_11_label = 1; v928_11_label <= 2; ++v928_11_label) {
        const Space v928_11_tail = child(v922_12_tail,v928_11_label);
        if (v928_11_tail.empty()) continue;
        const Path v928_11_head{v928_11_label};
        const Space v929_2 = singleton(v928_11_head);
        const Space v929_3 = intersect(constant_6,v929_2);
        const Space v929_4 = (has_head(v929_3) ? constant_7 : Space{});
        const Space v929_5 = subtract(constant_0,v929_4);
        Space v929_8;
        if (!v929_5.empty()) {
          const Path v930_6 = concat_path(v928_6,v928_11_head);
          const Space v930_7 = routine_151(c, v930_6, v928_11_tail, s1);
          v929_8 = compose(v929_5,v930_7);
        }
        const Space v929_9 = intersect(constant_6,v929_2);
        const Space v929_10 = (has_head(v929_9) ? constant_7 : Space{});
        Space v929_12;
        if (!v929_10.empty()) {
          const Path v931_6 = concat_path(v928_6,v928_11_head);
          const Space v931_11 = routine_19(c, v931_6, v928_11_tail, s1);
          v929_12 = compose(v929_10,v931_11);
        }
        const Space v929_13 = unite(v929_8,v929_12);
        v928_11_result = unite(v928_11_result,v929_13);
      }
      const Space v928_11 = std::move(v928_11_result);
      v923_12 = compose(v923_10,v928_11);
    }
    const Space v923_13 = unite(v923_8,v923_12);
    v922_12_result = unite(v922_12_result,v923_13);
  }
  const Space v922_12 = std::move(v922_12_result);
  return v922_12;
}

static Space routine_95(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v932_12_result;
  for (int v932_12_label = 1; v932_12_label <= 2; ++v932_12_label) {
    const Space v932_12_tail = child(s0,v932_12_label);
    if (v932_12_tail.empty()) continue;
    const Path v932_12_head{v932_12_label};
    const Space v933_2 = singleton(v932_12_head);
    const Space v933_3 = intersect(constant_6,v933_2);
    const Space v933_4 = (has_head(v933_3) ? constant_7 : Space{});
    const Space v933_5 = subtract(constant_0,v933_4);
    Space v933_8;
    if (!v933_5.empty()) {
      const Path v934_6 = concat_path(p0,v932_12_head);
      Space v934_7_result;
      for (int v934_7_label = 1; v934_7_label <= 2; ++v934_7_label) {
        const Space v934_7_tail = child(v932_12_tail,v934_7_label);
        if (v934_7_tail.empty()) continue;
        const Path v934_7_head{v934_7_label};
        const Space v935_2 = singleton(v934_7_head);
        const Space v935_3 = intersect(constant_6,v935_2);
        const Space v935_4 = (has_head(v935_3) ? constant_7 : Space{});
        const Space v935_5 = subtract(constant_0,v935_4);
        Space v935_8;
        if (!v935_5.empty()) {
          const Path v936_6 = concat_path(v934_6,v934_7_head);
          const Space v936_7 = routine_151(c, v936_6, v934_7_tail, s1);
          v935_8 = compose(v935_5,v936_7);
        }
        const Space v935_9 = intersect(constant_6,v935_2);
        const Space v935_10 = (has_head(v935_9) ? constant_7 : Space{});
        Space v935_12;
        if (!v935_10.empty()) {
          const Path v937_6 = concat_path(v934_6,v934_7_head);
          const Space v937_11 = routine_152(c, v937_6, v934_7_tail, s1);
          v935_12 = compose(v935_10,v937_11);
        }
        const Space v935_13 = unite(v935_8,v935_12);
        v934_7_result = unite(v934_7_result,v935_13);
      }
      const Space v934_7 = std::move(v934_7_result);
      v933_8 = compose(v933_5,v934_7);
    }
    const Space v933_9 = intersect(constant_6,v933_2);
    const Space v933_10 = (has_head(v933_9) ? constant_7 : Space{});
    Space v933_12;
    if (!v933_10.empty()) {
      const Path v938_6 = concat_path(p0,v932_12_head);
      Space v938_11_result;
      for (int v938_11_label = 1; v938_11_label <= 2; ++v938_11_label) {
        const Space v938_11_tail = child(v932_12_tail,v938_11_label);
        if (v938_11_tail.empty()) continue;
        const Path v938_11_head{v938_11_label};
        const Space v939_2 = singleton(v938_11_head);
        const Space v939_3 = intersect(constant_6,v939_2);
        const Space v939_4 = (has_head(v939_3) ? constant_7 : Space{});
        const Space v939_5 = subtract(constant_0,v939_4);
        Space v939_7;
        if (!v939_5.empty()) {
          const Space v940_6 = routine_20(c, v938_11_head, v938_6, v938_11_tail, s1);
          v939_7 = compose(v939_5,v940_6);
        }
        const Space v939_8 = intersect(constant_6,v939_2);
        const Space v939_9 = (has_head(v939_8) ? constant_7 : Space{});
        Space v939_11;
        if (!v939_9.empty()) {
          const Space v941_10 = routine_21(c, v938_11_head, v938_6, v938_11_tail, s1);
          v939_11 = compose(v939_9,v941_10);
        }
        const Space v939_12 = unite(v939_7,v939_11);
        v938_11_result = unite(v938_11_result,v939_12);
      }
      const Space v938_11 = std::move(v938_11_result);
      v933_12 = compose(v933_10,v938_11);
    }
    const Space v933_13 = unite(v933_8,v933_12);
    v932_12_result = unite(v932_12_result,v933_13);
  }
  const Space v932_12 = std::move(v932_12_result);
  return v932_12;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v942_13_result;
  for (int v942_13_label = 1; v942_13_label <= 2; ++v942_13_label) {
    const Space v942_13_tail = child(s0,v942_13_label);
    if (v942_13_tail.empty()) continue;
    const Path v942_13_head{v942_13_label};
    const Space v943_2 = singleton(v942_13_head);
    const Space v943_3 = intersect(constant_6,v943_2);
    const Space v943_4 = (has_head(v943_3) ? constant_7 : Space{});
    const Space v943_5 = subtract(constant_0,v943_4);
    Space v943_8;
    if (!v943_5.empty()) {
      const Path v944_6 = concat_path(p0,v942_13_head);
      Space v944_7_result;
      for (int v944_7_label = 1; v944_7_label <= 2; ++v944_7_label) {
        const Space v944_7_tail = child(v942_13_tail,v944_7_label);
        if (v944_7_tail.empty()) continue;
        const Path v944_7_head{v944_7_label};
        const Space v945_2 = singleton(v944_7_head);
        const Space v945_3 = intersect(constant_6,v945_2);
        const Space v945_4 = (has_head(v945_3) ? constant_7 : Space{});
        const Space v945_5 = subtract(constant_0,v945_4);
        Space v945_8;
        if (!v945_5.empty()) {
          const Path v946_6 = concat_path(v944_6,v944_7_head);
          const Space v946_7 = routine_153(c, v946_6, p1, v944_7_tail, s1);
          v945_8 = compose(v945_5,v946_7);
        }
        const Space v945_9 = intersect(constant_6,v945_2);
        const Space v945_10 = (has_head(v945_9) ? constant_7 : Space{});
        Space v945_12;
        if (!v945_10.empty()) {
          const Path v947_6 = concat_path(v944_6,v944_7_head);
          const Space v947_11 = routine_154(c, v947_6, p1, v944_7_tail, s1);
          v945_12 = compose(v945_10,v947_11);
        }
        const Space v945_13 = unite(v945_8,v945_12);
        v944_7_result = unite(v944_7_result,v945_13);
      }
      const Space v944_7 = std::move(v944_7_result);
      v943_8 = compose(v943_5,v944_7);
    }
    const Space v943_9 = intersect(constant_6,v943_2);
    const Space v943_10 = (has_head(v943_9) ? constant_7 : Space{});
    Space v943_12;
    if (!v943_10.empty()) {
      const Path v948_6 = concat_path(p0,v942_13_head);
      Space v948_11_result;
      for (int v948_11_label = 1; v948_11_label <= 2; ++v948_11_label) {
        const Space v948_11_tail = child(v942_13_tail,v948_11_label);
        if (v948_11_tail.empty()) continue;
        const Path v948_11_head{v948_11_label};
        const Space v949_2 = singleton(v948_11_head);
        const Space v949_3 = intersect(constant_6,v949_2);
        const Space v949_4 = (has_head(v949_3) ? constant_7 : Space{});
        const Space v949_5 = subtract(constant_0,v949_4);
        Space v949_8;
        if (!v949_5.empty()) {
          const Path v950_6 = concat_path(v948_6,v948_11_head);
          const Space v950_7 = routine_153(c, v950_6, p1, v948_11_tail, s1);
          v949_8 = compose(v949_5,v950_7);
        }
        const Space v949_9 = intersect(constant_6,v949_2);
        const Space v949_10 = (has_head(v949_9) ? constant_7 : Space{});
        Space v949_12;
        if (!v949_10.empty()) {
          const Path v951_6 = concat_path(v948_6,v948_11_head);
          const Space v951_11 = routine_49(c, v951_6, p1, v948_11_tail, s1);
          v949_12 = compose(v949_10,v951_11);
        }
        const Space v949_13 = unite(v949_8,v949_12);
        v948_11_result = unite(v948_11_result,v949_13);
      }
      const Space v948_11 = std::move(v948_11_result);
      v943_12 = compose(v943_10,v948_11);
    }
    const Space v943_13 = unite(v943_8,v943_12);
    v942_13_result = unite(v942_13_result,v943_13);
  }
  const Space v942_13 = std::move(v942_13_result);
  return v942_13;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v952_8 = unwrap(s1,constant_8);
  Space v952_21_result;
  for (int v952_21_label = 1; v952_21_label <= 2; ++v952_21_label) {
    const Space v952_21_tail = child(s0,v952_21_label);
    if (v952_21_tail.empty()) continue;
    const Path v952_21_head{v952_21_label};
    const Space v953_2 = singleton(v952_21_head);
    const Space v953_3 = intersect(constant_6,v953_2);
    const Space v953_4 = (has_head(v953_3) ? constant_7 : Space{});
    const Space v953_5 = subtract(constant_0,v953_4);
    Space v953_8;
    if (!v953_5.empty()) {
      const Path v954_6 = concat_path(p0,v952_21_head);
      Space v954_7_result;
      for (int v954_7_label = 1; v954_7_label <= 2; ++v954_7_label) {
        const Space v954_7_tail = child(v952_21_tail,v954_7_label);
        if (v954_7_tail.empty()) continue;
        const Path v954_7_head{v954_7_label};
        const Space v955_2 = singleton(v954_7_head);
        const Space v955_3 = intersect(constant_6,v955_2);
        const Space v955_4 = (has_head(v955_3) ? constant_7 : Space{});
        const Space v955_5 = subtract(constant_0,v955_4);
        Space v955_8;
        if (!v955_5.empty()) {
          const Path v956_6 = concat_path(v954_6,v954_7_head);
          const Space v956_7 = routine_153(c, v956_6, p1, v954_7_tail, s1);
          v955_8 = compose(v955_5,v956_7);
        }
        const Space v955_9 = intersect(constant_6,v955_2);
        const Space v955_10 = (has_head(v955_9) ? constant_7 : Space{});
        Space v955_12;
        if (!v955_10.empty()) {
          const Path v957_6 = concat_path(v954_6,v954_7_head);
          const Space v957_11 = routine_154(c, v957_6, p1, v954_7_tail, s1);
          v955_12 = compose(v955_10,v957_11);
        }
        const Space v955_13 = unite(v955_8,v955_12);
        v954_7_result = unite(v954_7_result,v955_13);
      }
      const Space v954_7 = std::move(v954_7_result);
      v953_8 = compose(v953_5,v954_7);
    }
    const Space v953_9 = intersect(constant_6,v953_2);
    const Space v953_10 = (has_head(v953_9) ? constant_7 : Space{});
    Space v953_22;
    if (!v953_10.empty()) {
      const Path v958_6 = concat_path(p0,v952_21_head);
      const Path v958_11 = concat_path(p1,v958_6);
      const Space v958_12 = routine_29(c, v958_11);
      const Space v958_13 = intersect(v952_8,v958_12);
      const Space v958_14 = routine_33(c, v958_13);
      Space v958_15_result;
      for (int v958_15_label = 1; v958_15_label <= 2; ++v958_15_label) {
        const Space v958_15_tail = child(v958_14,v958_15_label);
        if (v958_15_tail.empty()) continue;
        const Path v958_15_head{v958_15_label};
        const Space v959_2 = singleton(v958_15_head);
        const Space v959_3 = intersect(constant_6,v959_2);
        const Space v959_4 = (has_head(v959_3) ? constant_7 : Space{});
        const Space v959_5 = subtract(constant_0,v959_4);
        Space v959_7;
        if (!v959_5.empty()) {
          const Space v960_6 = routine_52(c, v958_15_head, v958_15_tail);
          v959_7 = compose(v959_5,v960_6);
        }
        const Space v959_8 = intersect(constant_6,v959_2);
        const Space v959_9 = (has_head(v959_8) ? constant_7 : Space{});
        Space v959_11;
        if (!v959_9.empty()) {
          const Space v961_10 = routine_53(c, v958_15_head, v958_15_tail);
          v959_11 = compose(v959_9,v961_10);
        }
        const Space v959_12 = unite(v959_7,v959_11);
        v958_15_result = unite(v958_15_result,v959_12);
      }
      const Space v958_15 = std::move(v958_15_result);
      const Space v958_16 = routine_54(c, v958_13);
      Space v958_17_result;
      for (int v958_17_label = 1; v958_17_label <= 2; ++v958_17_label) {
        const Space v958_17_tail = child(v958_16,v958_17_label);
        if (v958_17_tail.empty()) continue;
        const Path v958_17_head{v958_17_label};
        const Space v962_2 = singleton(v958_17_head);
        const Space v962_3 = intersect(constant_6,v962_2);
        const Space v962_4 = (has_head(v962_3) ? constant_7 : Space{});
        const Space v962_5 = subtract(constant_0,v962_4);
        Space v962_7;
        if (!v962_5.empty()) {
          const Space v963_6 = routine_55(c, v958_17_head, v958_17_tail);
          v962_7 = compose(v962_5,v963_6);
        }
        const Space v962_8 = intersect(constant_6,v962_2);
        const Space v962_9 = (has_head(v962_8) ? constant_7 : Space{});
        Space v962_11;
        if (!v962_9.empty()) {
          const Space v964_10 = routine_56(c, v958_17_head, v958_17_tail);
          v962_11 = compose(v962_9,v964_10);
        }
        const Space v962_12 = unite(v962_7,v962_11);
        v958_17_result = unite(v958_17_result,v962_12);
      }
      const Space v958_17 = std::move(v958_17_result);
      const Space v958_18 = subtract(v958_15,v958_17);
      const Space v958_19 = singleton(v958_11);
      const Space v958_20 = compose(v958_18,v958_19);
      Space v958_21_result;
      for (int v958_21_label = 1; v958_21_label <= 2; ++v958_21_label) {
        const Space v958_21_tail = child(v958_20,v958_21_label);
        if (v958_21_tail.empty()) continue;
        const Path v958_21_head{v958_21_label};
        const Space v965_2 = singleton(v958_21_head);
        const Space v965_3 = intersect(constant_6,v965_2);
        const Space v965_4 = (has_head(v965_3) ? constant_7 : Space{});
        const Space v965_5 = subtract(constant_0,v965_4);
        Space v965_7;
        if (!v965_5.empty()) {
          const Space v966_6 = routine_57(c, v958_21_head, v958_21_tail);
          v965_7 = compose(v965_5,v966_6);
        }
        const Space v965_8 = intersect(constant_6,v965_2);
        const Space v965_9 = (has_head(v965_8) ? constant_7 : Space{});
        Space v965_11;
        if (!v965_9.empty()) {
          const Space v967_10 = routine_58(c, v958_21_head, v958_21_tail);
          v965_11 = compose(v965_9,v967_10);
        }
        const Space v965_12 = unite(v965_7,v965_11);
        v958_21_result = unite(v958_21_result,v965_12);
      }
      const Space v958_21 = std::move(v958_21_result);
      v953_22 = compose(v953_10,v958_21);
    }
    const Space v953_23 = unite(v953_8,v953_22);
    v952_21_result = unite(v952_21_result,v953_23);
  }
  const Space v952_21 = std::move(v952_21_result);
  return v952_21;
}

static Space routine_98(Context& c, const Path& p0, const Space& s0) {
  Space v968_11_result;
  for (int v968_11_label = 1; v968_11_label <= 2; ++v968_11_label) {
    const Space v968_11_tail = child(s0,v968_11_label);
    if (v968_11_tail.empty()) continue;
    const Path v968_11_head{v968_11_label};
    const Space v969_2 = singleton(v968_11_head);
    const Space v969_3 = intersect(constant_6,v969_2);
    const Space v969_4 = (has_head(v969_3) ? constant_7 : Space{});
    const Space v969_5 = subtract(constant_0,v969_4);
    Space v969_8;
    if (!v969_5.empty()) {
      const Path v970_6 = concat_path(p0,v968_11_head);
      Space v970_7_result;
      for (int v970_7_label = 1; v970_7_label <= 2; ++v970_7_label) {
        const Space v970_7_tail = child(v968_11_tail,v970_7_label);
        if (v970_7_tail.empty()) continue;
        const Path v970_7_head{v970_7_label};
        const Space v971_2 = singleton(v970_7_head);
        const Space v971_3 = intersect(constant_6,v971_2);
        const Space v971_4 = (has_head(v971_3) ? constant_7 : Space{});
        const Space v971_5 = subtract(constant_0,v971_4);
        Space v971_8;
        if (!v971_5.empty()) {
          const Path v972_6 = concat_path(v970_6,v970_7_head);
          const Space v972_7 = routine_155(c, v972_6, v970_7_tail);
          v971_8 = compose(v971_5,v972_7);
        }
        const Space v971_9 = intersect(constant_6,v971_2);
        const Space v971_10 = (has_head(v971_9) ? constant_7 : Space{});
        Space v971_12;
        if (!v971_10.empty()) {
          const Path v973_6 = concat_path(v970_6,v970_7_head);
          const Space v973_11 = routine_156(c, v973_6, v970_7_tail);
          v971_12 = compose(v971_10,v973_11);
        }
        const Space v971_13 = unite(v971_8,v971_12);
        v970_7_result = unite(v970_7_result,v971_13);
      }
      const Space v970_7 = std::move(v970_7_result);
      v969_8 = compose(v969_5,v970_7);
    }
    const Space v969_9 = intersect(constant_6,v969_2);
    const Space v969_10 = (has_head(v969_9) ? constant_7 : Space{});
    Space v969_12;
    if (!v969_10.empty()) {
      const Path v974_6 = concat_path(p0,v968_11_head);
      Space v974_11_result;
      for (int v974_11_label = 1; v974_11_label <= 2; ++v974_11_label) {
        const Space v974_11_tail = child(v968_11_tail,v974_11_label);
        if (v974_11_tail.empty()) continue;
        const Path v974_11_head{v974_11_label};
        const Space v975_2 = singleton(v974_11_head);
        const Space v975_3 = intersect(constant_6,v975_2);
        const Space v975_4 = (has_head(v975_3) ? constant_7 : Space{});
        const Space v975_5 = subtract(constant_0,v975_4);
        Space v975_8;
        if (!v975_5.empty()) {
          const Path v976_6 = concat_path(v974_6,v974_11_head);
          const Space v976_7 = routine_155(c, v976_6, v974_11_tail);
          v975_8 = compose(v975_5,v976_7);
        }
        const Space v975_9 = intersect(constant_6,v975_2);
        const Space v975_10 = (has_head(v975_9) ? constant_7 : Space{});
        Space v975_12;
        if (!v975_10.empty()) {
          const Path v977_6 = concat_path(v974_6,v974_11_head);
          const Space v977_11 = routine_100(c, v977_6, v974_11_tail);
          v975_12 = compose(v975_10,v977_11);
        }
        const Space v975_13 = unite(v975_8,v975_12);
        v974_11_result = unite(v974_11_result,v975_13);
      }
      const Space v974_11 = std::move(v974_11_result);
      v969_12 = compose(v969_10,v974_11);
    }
    const Space v969_13 = unite(v969_8,v969_12);
    v968_11_result = unite(v968_11_result,v969_13);
  }
  const Space v968_11 = std::move(v968_11_result);
  return v968_11;
}

static Space routine_99(Context& c, const Path& p0, const Space& s0) {
  Space v978_9_result;
  for (int v978_9_label = 1; v978_9_label <= 2; ++v978_9_label) {
    const Space v978_9_tail = child(s0,v978_9_label);
    if (v978_9_tail.empty()) continue;
    const Path v978_9_head{v978_9_label};
    const Space v979_2 = singleton(v978_9_head);
    const Space v979_3 = intersect(constant_6,v979_2);
    const Space v979_4 = (has_head(v979_3) ? constant_7 : Space{});
    const Space v979_5 = subtract(constant_0,v979_4);
    Space v979_8;
    if (!v979_5.empty()) {
      const Path v980_6 = concat_path(p0,v978_9_head);
      Space v980_7_result;
      for (int v980_7_label = 1; v980_7_label <= 2; ++v980_7_label) {
        const Space v980_7_tail = child(v978_9_tail,v980_7_label);
        if (v980_7_tail.empty()) continue;
        const Path v980_7_head{v980_7_label};
        const Space v981_2 = singleton(v980_7_head);
        const Space v981_3 = intersect(constant_6,v981_2);
        const Space v981_4 = (has_head(v981_3) ? constant_7 : Space{});
        const Space v981_5 = subtract(constant_0,v981_4);
        Space v981_8;
        if (!v981_5.empty()) {
          const Path v982_6 = concat_path(v980_6,v980_7_head);
          const Space v982_7 = routine_155(c, v982_6, v980_7_tail);
          v981_8 = compose(v981_5,v982_7);
        }
        const Space v981_9 = intersect(constant_6,v981_2);
        const Space v981_10 = (has_head(v981_9) ? constant_7 : Space{});
        Space v981_12;
        if (!v981_10.empty()) {
          const Path v983_6 = concat_path(v980_6,v980_7_head);
          const Space v983_11 = routine_156(c, v983_6, v980_7_tail);
          v981_12 = compose(v981_10,v983_11);
        }
        const Space v981_13 = unite(v981_8,v981_12);
        v980_7_result = unite(v980_7_result,v981_13);
      }
      const Space v980_7 = std::move(v980_7_result);
      v979_8 = compose(v979_5,v980_7);
    }
    const Space v979_9 = intersect(constant_6,v979_2);
    const Space v979_10 = (has_head(v979_9) ? constant_7 : Space{});
    const Space v979_11 = compose(v979_10,constant_9);
    const Space v979_12 = unite(v979_8,v979_11);
    v978_9_result = unite(v978_9_result,v979_12);
  }
  const Space v978_9 = std::move(v978_9_result);
  return v978_9;
}

static Space routine_100(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_101(Context& c, const Space& s0) {
  const Space v985_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v985_2 = first_matching(s0,constant_0,false);
  const Space v985_3 = unite(v985_1,v985_2);
  Space v985_13;
  if (!v985_3.empty()) {
    Space v986_6;
    if (!v985_3.empty()) {
      const Space v987_4 = routine_66(c, s0);
      const Space v987_5 = routine_66(c, v987_4);
      v986_6 = compose(v985_3,v987_5);
    }
    const Space v986_7 = (has_head(v986_6) ? constant_7 : Space{});
    const Space v986_8 = first_matching(v986_6,constant_0,false);
    const Space v986_9 = unite(v986_7,v986_8);
    Space v986_12;
    if (!v986_9.empty()) {
      const Space v988_10 = routine_66(c, v986_6);
      const Space v988_11 = routine_66(c, v988_10);
      v986_12 = compose(v986_9,v988_11);
    }
    v985_13 = compose(v985_3,v986_12);
  }
  return v985_13;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0) {
  Space v989_11_result;
  for (int v989_11_label = 1; v989_11_label <= 2; ++v989_11_label) {
    const Space v989_11_tail = child(s0,v989_11_label);
    if (v989_11_tail.empty()) continue;
    const Path v989_11_head{v989_11_label};
    const Space v990_2 = singleton(v989_11_head);
    const Space v990_3 = intersect(constant_6,v990_2);
    const Space v990_4 = (has_head(v990_3) ? constant_7 : Space{});
    const Space v990_5 = subtract(constant_0,v990_4);
    Space v990_8;
    if (!v990_5.empty()) {
      const Path v991_6 = concat_path(p0,v989_11_head);
      Space v991_7_result;
      for (int v991_7_label = 1; v991_7_label <= 2; ++v991_7_label) {
        const Space v991_7_tail = child(v989_11_tail,v991_7_label);
        if (v991_7_tail.empty()) continue;
        const Path v991_7_head{v991_7_label};
        const Space v992_2 = singleton(v991_7_head);
        const Space v992_3 = intersect(constant_6,v992_2);
        const Space v992_4 = (has_head(v992_3) ? constant_7 : Space{});
        const Space v992_5 = subtract(constant_0,v992_4);
        Space v992_8;
        if (!v992_5.empty()) {
          const Path v993_6 = concat_path(v991_6,v991_7_head);
          const Space v993_7 = routine_157(c, v993_6, v991_7_tail);
          v992_8 = compose(v992_5,v993_7);
        }
        const Space v992_9 = intersect(constant_6,v992_2);
        const Space v992_10 = (has_head(v992_9) ? constant_7 : Space{});
        Space v992_12;
        if (!v992_10.empty()) {
          const Path v994_6 = concat_path(v991_6,v991_7_head);
          const Space v994_11 = routine_158(c, v994_6, v991_7_tail);
          v992_12 = compose(v992_10,v994_11);
        }
        const Space v992_13 = unite(v992_8,v992_12);
        v991_7_result = unite(v991_7_result,v992_13);
      }
      const Space v991_7 = std::move(v991_7_result);
      v990_8 = compose(v990_5,v991_7);
    }
    const Space v990_9 = intersect(constant_6,v990_2);
    const Space v990_10 = (has_head(v990_9) ? constant_7 : Space{});
    Space v990_12;
    if (!v990_10.empty()) {
      const Path v995_6 = concat_path(p0,v989_11_head);
      Space v995_11_result;
      for (int v995_11_label = 1; v995_11_label <= 2; ++v995_11_label) {
        const Space v995_11_tail = child(v989_11_tail,v995_11_label);
        if (v995_11_tail.empty()) continue;
        const Path v995_11_head{v995_11_label};
        const Space v996_2 = singleton(v995_11_head);
        const Space v996_3 = intersect(constant_6,v996_2);
        const Space v996_4 = (has_head(v996_3) ? constant_7 : Space{});
        const Space v996_5 = subtract(constant_0,v996_4);
        Space v996_8;
        if (!v996_5.empty()) {
          const Path v997_6 = concat_path(v995_6,v995_11_head);
          const Space v997_7 = routine_157(c, v997_6, v995_11_tail);
          v996_8 = compose(v996_5,v997_7);
        }
        const Space v996_9 = intersect(constant_6,v996_2);
        const Space v996_10 = (has_head(v996_9) ? constant_7 : Space{});
        Space v996_12;
        if (!v996_10.empty()) {
          const Path v998_6 = concat_path(v995_6,v995_11_head);
          const Space v998_11 = routine_104(c, v998_6, v995_11_tail);
          v996_12 = compose(v996_10,v998_11);
        }
        const Space v996_13 = unite(v996_8,v996_12);
        v995_11_result = unite(v995_11_result,v996_13);
      }
      const Space v995_11 = std::move(v995_11_result);
      v990_12 = compose(v990_10,v995_11);
    }
    const Space v990_13 = unite(v990_8,v990_12);
    v989_11_result = unite(v989_11_result,v990_13);
  }
  const Space v989_11 = std::move(v989_11_result);
  return v989_11;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0) {
  Space v999_9_result;
  for (int v999_9_label = 1; v999_9_label <= 2; ++v999_9_label) {
    const Space v999_9_tail = child(s0,v999_9_label);
    if (v999_9_tail.empty()) continue;
    const Path v999_9_head{v999_9_label};
    const Space v1000_2 = singleton(v999_9_head);
    const Space v1000_3 = intersect(constant_6,v1000_2);
    const Space v1000_4 = (has_head(v1000_3) ? constant_7 : Space{});
    const Space v1000_5 = subtract(constant_0,v1000_4);
    Space v1000_8;
    if (!v1000_5.empty()) {
      const Path v1001_6 = concat_path(p0,v999_9_head);
      Space v1001_7_result;
      for (int v1001_7_label = 1; v1001_7_label <= 2; ++v1001_7_label) {
        const Space v1001_7_tail = child(v999_9_tail,v1001_7_label);
        if (v1001_7_tail.empty()) continue;
        const Path v1001_7_head{v1001_7_label};
        const Space v1002_2 = singleton(v1001_7_head);
        const Space v1002_3 = intersect(constant_6,v1002_2);
        const Space v1002_4 = (has_head(v1002_3) ? constant_7 : Space{});
        const Space v1002_5 = subtract(constant_0,v1002_4);
        Space v1002_8;
        if (!v1002_5.empty()) {
          const Path v1003_6 = concat_path(v1001_6,v1001_7_head);
          const Space v1003_7 = routine_157(c, v1003_6, v1001_7_tail);
          v1002_8 = compose(v1002_5,v1003_7);
        }
        const Space v1002_9 = intersect(constant_6,v1002_2);
        const Space v1002_10 = (has_head(v1002_9) ? constant_7 : Space{});
        Space v1002_12;
        if (!v1002_10.empty()) {
          const Path v1004_6 = concat_path(v1001_6,v1001_7_head);
          const Space v1004_11 = routine_158(c, v1004_6, v1001_7_tail);
          v1002_12 = compose(v1002_10,v1004_11);
        }
        const Space v1002_13 = unite(v1002_8,v1002_12);
        v1001_7_result = unite(v1001_7_result,v1002_13);
      }
      const Space v1001_7 = std::move(v1001_7_result);
      v1000_8 = compose(v1000_5,v1001_7);
    }
    const Space v1000_9 = intersect(constant_6,v1000_2);
    const Space v1000_10 = (has_head(v1000_9) ? constant_7 : Space{});
    const Space v1000_11 = compose(v1000_10,constant_9);
    const Space v1000_12 = unite(v1000_8,v1000_11);
    v999_9_result = unite(v999_9_result,v1000_12);
  }
  const Space v999_9 = std::move(v999_9_result);
  return v999_9;
}

static Space routine_104(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_105(Context& c, const Path& p0, const Space& s0) {
  Space v1006_11_result;
  for (int v1006_11_label = 1; v1006_11_label <= 2; ++v1006_11_label) {
    const Space v1006_11_tail = child(s0,v1006_11_label);
    if (v1006_11_tail.empty()) continue;
    const Path v1006_11_head{v1006_11_label};
    const Space v1007_2 = singleton(v1006_11_head);
    const Space v1007_3 = intersect(constant_6,v1007_2);
    const Space v1007_4 = (has_head(v1007_3) ? constant_7 : Space{});
    const Space v1007_5 = subtract(constant_0,v1007_4);
    Space v1007_8;
    if (!v1007_5.empty()) {
      const Path v1008_6 = concat_path(p0,v1006_11_head);
      Space v1008_7_result;
      for (int v1008_7_label = 1; v1008_7_label <= 2; ++v1008_7_label) {
        const Space v1008_7_tail = child(v1006_11_tail,v1008_7_label);
        if (v1008_7_tail.empty()) continue;
        const Path v1008_7_head{v1008_7_label};
        const Space v1009_2 = singleton(v1008_7_head);
        const Space v1009_3 = intersect(constant_6,v1009_2);
        const Space v1009_4 = (has_head(v1009_3) ? constant_7 : Space{});
        const Space v1009_5 = subtract(constant_0,v1009_4);
        Space v1009_8;
        if (!v1009_5.empty()) {
          const Path v1010_6 = concat_path(v1008_6,v1008_7_head);
          const Space v1010_7 = routine_159(c, v1010_6, v1008_7_tail);
          v1009_8 = compose(v1009_5,v1010_7);
        }
        const Space v1009_9 = intersect(constant_6,v1009_2);
        const Space v1009_10 = (has_head(v1009_9) ? constant_7 : Space{});
        Space v1009_12;
        if (!v1009_10.empty()) {
          const Path v1011_6 = concat_path(v1008_6,v1008_7_head);
          const Space v1011_11 = routine_160(c, v1011_6, v1008_7_tail);
          v1009_12 = compose(v1009_10,v1011_11);
        }
        const Space v1009_13 = unite(v1009_8,v1009_12);
        v1008_7_result = unite(v1008_7_result,v1009_13);
      }
      const Space v1008_7 = std::move(v1008_7_result);
      v1007_8 = compose(v1007_5,v1008_7);
    }
    const Space v1007_9 = intersect(constant_6,v1007_2);
    const Space v1007_10 = (has_head(v1007_9) ? constant_7 : Space{});
    Space v1007_12;
    if (!v1007_10.empty()) {
      const Path v1012_6 = concat_path(p0,v1006_11_head);
      Space v1012_11_result;
      for (int v1012_11_label = 1; v1012_11_label <= 2; ++v1012_11_label) {
        const Space v1012_11_tail = child(v1006_11_tail,v1012_11_label);
        if (v1012_11_tail.empty()) continue;
        const Path v1012_11_head{v1012_11_label};
        const Space v1013_2 = singleton(v1012_11_head);
        const Space v1013_3 = intersect(constant_6,v1013_2);
        const Space v1013_4 = (has_head(v1013_3) ? constant_7 : Space{});
        const Space v1013_5 = subtract(constant_0,v1013_4);
        Space v1013_8;
        if (!v1013_5.empty()) {
          const Path v1014_6 = concat_path(v1012_6,v1012_11_head);
          const Space v1014_7 = routine_159(c, v1014_6, v1012_11_tail);
          v1013_8 = compose(v1013_5,v1014_7);
        }
        const Space v1013_9 = intersect(constant_6,v1013_2);
        const Space v1013_10 = (has_head(v1013_9) ? constant_7 : Space{});
        Space v1013_12;
        if (!v1013_10.empty()) {
          const Path v1015_6 = concat_path(v1012_6,v1012_11_head);
          const Space v1015_11 = routine_107(c, v1015_6, v1012_11_tail);
          v1013_12 = compose(v1013_10,v1015_11);
        }
        const Space v1013_13 = unite(v1013_8,v1013_12);
        v1012_11_result = unite(v1012_11_result,v1013_13);
      }
      const Space v1012_11 = std::move(v1012_11_result);
      v1007_12 = compose(v1007_10,v1012_11);
    }
    const Space v1007_13 = unite(v1007_8,v1007_12);
    v1006_11_result = unite(v1006_11_result,v1007_13);
  }
  const Space v1006_11 = std::move(v1006_11_result);
  return v1006_11;
}

static Space routine_106(Context& c, const Path& p0, const Space& s0) {
  Space v1016_8_result;
  for (int v1016_8_label = 1; v1016_8_label <= 2; ++v1016_8_label) {
    const Space v1016_8_tail = child(s0,v1016_8_label);
    if (v1016_8_tail.empty()) continue;
    const Path v1016_8_head{v1016_8_label};
    const Space v1017_2 = singleton(v1016_8_head);
    const Space v1017_3 = intersect(constant_6,v1017_2);
    const Space v1017_4 = (has_head(v1017_3) ? constant_7 : Space{});
    const Space v1017_5 = subtract(constant_0,v1017_4);
    Space v1017_8;
    if (!v1017_5.empty()) {
      const Path v1018_6 = concat_path(p0,v1016_8_head);
      Space v1018_7_result;
      for (int v1018_7_label = 1; v1018_7_label <= 2; ++v1018_7_label) {
        const Space v1018_7_tail = child(v1016_8_tail,v1018_7_label);
        if (v1018_7_tail.empty()) continue;
        const Path v1018_7_head{v1018_7_label};
        const Space v1019_2 = singleton(v1018_7_head);
        const Space v1019_3 = intersect(constant_6,v1019_2);
        const Space v1019_4 = (has_head(v1019_3) ? constant_7 : Space{});
        const Space v1019_5 = subtract(constant_0,v1019_4);
        Space v1019_8;
        if (!v1019_5.empty()) {
          const Path v1020_6 = concat_path(v1018_6,v1018_7_head);
          const Space v1020_7 = routine_159(c, v1020_6, v1018_7_tail);
          v1019_8 = compose(v1019_5,v1020_7);
        }
        const Space v1019_9 = intersect(constant_6,v1019_2);
        const Space v1019_10 = (has_head(v1019_9) ? constant_7 : Space{});
        Space v1019_12;
        if (!v1019_10.empty()) {
          const Path v1021_6 = concat_path(v1018_6,v1018_7_head);
          const Space v1021_11 = routine_160(c, v1021_6, v1018_7_tail);
          v1019_12 = compose(v1019_10,v1021_11);
        }
        const Space v1019_13 = unite(v1019_8,v1019_12);
        v1018_7_result = unite(v1018_7_result,v1019_13);
      }
      const Space v1018_7 = std::move(v1018_7_result);
      v1017_8 = compose(v1017_5,v1018_7);
    }
    const Space v1017_9 = intersect(constant_6,v1017_2);
    const Space v1017_10 = (has_head(v1017_9) ? constant_7 : Space{});
    const Space v1017_11 = compose(v1017_10,v1016_8_tail);
    const Space v1017_12 = unite(v1017_8,v1017_11);
    v1016_8_result = unite(v1016_8_result,v1017_12);
  }
  const Space v1016_8 = std::move(v1016_8_result);
  return v1016_8;
}

static Space routine_107(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1023_13_result;
  for (int v1023_13_label = 1; v1023_13_label <= 2; ++v1023_13_label) {
    const Space v1023_13_tail = child(s0,v1023_13_label);
    if (v1023_13_tail.empty()) continue;
    const Path v1023_13_head{v1023_13_label};
    const Space v1024_2 = singleton(v1023_13_head);
    const Space v1024_3 = intersect(constant_6,v1024_2);
    const Space v1024_4 = (has_head(v1024_3) ? constant_7 : Space{});
    const Space v1024_5 = subtract(constant_0,v1024_4);
    Space v1024_8;
    if (!v1024_5.empty()) {
      const Path v1025_6 = concat_path(p0,v1023_13_head);
      Space v1025_7_result;
      for (int v1025_7_label = 1; v1025_7_label <= 2; ++v1025_7_label) {
        const Space v1025_7_tail = child(v1023_13_tail,v1025_7_label);
        if (v1025_7_tail.empty()) continue;
        const Path v1025_7_head{v1025_7_label};
        const Space v1026_2 = singleton(v1025_7_head);
        const Space v1026_3 = intersect(constant_6,v1026_2);
        const Space v1026_4 = (has_head(v1026_3) ? constant_7 : Space{});
        const Space v1026_5 = subtract(constant_0,v1026_4);
        Space v1026_8;
        if (!v1026_5.empty()) {
          const Path v1027_6 = concat_path(v1025_6,v1025_7_head);
          const Space v1027_7 = routine_161(c, v1027_6, p1, v1025_7_tail, s1);
          v1026_8 = compose(v1026_5,v1027_7);
        }
        const Space v1026_9 = intersect(constant_6,v1026_2);
        const Space v1026_10 = (has_head(v1026_9) ? constant_7 : Space{});
        Space v1026_12;
        if (!v1026_10.empty()) {
          const Path v1028_6 = concat_path(v1025_6,v1025_7_head);
          const Space v1028_11 = routine_162(c, v1028_6, p1, v1025_7_tail, s1);
          v1026_12 = compose(v1026_10,v1028_11);
        }
        const Space v1026_13 = unite(v1026_8,v1026_12);
        v1025_7_result = unite(v1025_7_result,v1026_13);
      }
      const Space v1025_7 = std::move(v1025_7_result);
      v1024_8 = compose(v1024_5,v1025_7);
    }
    const Space v1024_9 = intersect(constant_6,v1024_2);
    const Space v1024_10 = (has_head(v1024_9) ? constant_7 : Space{});
    Space v1024_12;
    if (!v1024_10.empty()) {
      const Path v1029_6 = concat_path(p0,v1023_13_head);
      Space v1029_11_result;
      for (int v1029_11_label = 1; v1029_11_label <= 2; ++v1029_11_label) {
        const Space v1029_11_tail = child(v1023_13_tail,v1029_11_label);
        if (v1029_11_tail.empty()) continue;
        const Path v1029_11_head{v1029_11_label};
        const Space v1030_2 = singleton(v1029_11_head);
        const Space v1030_3 = intersect(constant_6,v1030_2);
        const Space v1030_4 = (has_head(v1030_3) ? constant_7 : Space{});
        const Space v1030_5 = subtract(constant_0,v1030_4);
        Space v1030_8;
        if (!v1030_5.empty()) {
          const Path v1031_6 = concat_path(v1029_6,v1029_11_head);
          const Space v1031_7 = routine_161(c, v1031_6, p1, v1029_11_tail, s1);
          v1030_8 = compose(v1030_5,v1031_7);
        }
        const Space v1030_9 = intersect(constant_6,v1030_2);
        const Space v1030_10 = (has_head(v1030_9) ? constant_7 : Space{});
        Space v1030_12;
        if (!v1030_10.empty()) {
          const Path v1032_6 = concat_path(v1029_6,v1029_11_head);
          const Space v1032_11 = routine_49(c, v1032_6, p1, v1029_11_tail, s1);
          v1030_12 = compose(v1030_10,v1032_11);
        }
        const Space v1030_13 = unite(v1030_8,v1030_12);
        v1029_11_result = unite(v1029_11_result,v1030_13);
      }
      const Space v1029_11 = std::move(v1029_11_result);
      v1024_12 = compose(v1024_10,v1029_11);
    }
    const Space v1024_13 = unite(v1024_8,v1024_12);
    v1023_13_result = unite(v1023_13_result,v1024_13);
  }
  const Space v1023_13 = std::move(v1023_13_result);
  return v1023_13;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1033_8 = unwrap(s1,constant_8);
  Space v1033_21_result;
  for (int v1033_21_label = 1; v1033_21_label <= 2; ++v1033_21_label) {
    const Space v1033_21_tail = child(s0,v1033_21_label);
    if (v1033_21_tail.empty()) continue;
    const Path v1033_21_head{v1033_21_label};
    const Space v1034_2 = singleton(v1033_21_head);
    const Space v1034_3 = intersect(constant_6,v1034_2);
    const Space v1034_4 = (has_head(v1034_3) ? constant_7 : Space{});
    const Space v1034_5 = subtract(constant_0,v1034_4);
    Space v1034_8;
    if (!v1034_5.empty()) {
      const Path v1035_6 = concat_path(p0,v1033_21_head);
      Space v1035_7_result;
      for (int v1035_7_label = 1; v1035_7_label <= 2; ++v1035_7_label) {
        const Space v1035_7_tail = child(v1033_21_tail,v1035_7_label);
        if (v1035_7_tail.empty()) continue;
        const Path v1035_7_head{v1035_7_label};
        const Space v1036_2 = singleton(v1035_7_head);
        const Space v1036_3 = intersect(constant_6,v1036_2);
        const Space v1036_4 = (has_head(v1036_3) ? constant_7 : Space{});
        const Space v1036_5 = subtract(constant_0,v1036_4);
        Space v1036_8;
        if (!v1036_5.empty()) {
          const Path v1037_6 = concat_path(v1035_6,v1035_7_head);
          const Space v1037_7 = routine_161(c, v1037_6, p1, v1035_7_tail, s1);
          v1036_8 = compose(v1036_5,v1037_7);
        }
        const Space v1036_9 = intersect(constant_6,v1036_2);
        const Space v1036_10 = (has_head(v1036_9) ? constant_7 : Space{});
        Space v1036_12;
        if (!v1036_10.empty()) {
          const Path v1038_6 = concat_path(v1035_6,v1035_7_head);
          const Space v1038_11 = routine_162(c, v1038_6, p1, v1035_7_tail, s1);
          v1036_12 = compose(v1036_10,v1038_11);
        }
        const Space v1036_13 = unite(v1036_8,v1036_12);
        v1035_7_result = unite(v1035_7_result,v1036_13);
      }
      const Space v1035_7 = std::move(v1035_7_result);
      v1034_8 = compose(v1034_5,v1035_7);
    }
    const Space v1034_9 = intersect(constant_6,v1034_2);
    const Space v1034_10 = (has_head(v1034_9) ? constant_7 : Space{});
    Space v1034_22;
    if (!v1034_10.empty()) {
      const Path v1039_6 = concat_path(p0,v1033_21_head);
      const Path v1039_11 = concat_path(p1,v1039_6);
      const Space v1039_12 = routine_29(c, v1039_11);
      const Space v1039_13 = intersect(v1033_8,v1039_12);
      const Space v1039_14 = routine_33(c, v1039_13);
      Space v1039_15_result;
      for (int v1039_15_label = 1; v1039_15_label <= 2; ++v1039_15_label) {
        const Space v1039_15_tail = child(v1039_14,v1039_15_label);
        if (v1039_15_tail.empty()) continue;
        const Path v1039_15_head{v1039_15_label};
        const Space v1040_2 = singleton(v1039_15_head);
        const Space v1040_3 = intersect(constant_6,v1040_2);
        const Space v1040_4 = (has_head(v1040_3) ? constant_7 : Space{});
        const Space v1040_5 = subtract(constant_0,v1040_4);
        Space v1040_7;
        if (!v1040_5.empty()) {
          const Space v1041_6 = routine_52(c, v1039_15_head, v1039_15_tail);
          v1040_7 = compose(v1040_5,v1041_6);
        }
        const Space v1040_8 = intersect(constant_6,v1040_2);
        const Space v1040_9 = (has_head(v1040_8) ? constant_7 : Space{});
        Space v1040_11;
        if (!v1040_9.empty()) {
          const Space v1042_10 = routine_53(c, v1039_15_head, v1039_15_tail);
          v1040_11 = compose(v1040_9,v1042_10);
        }
        const Space v1040_12 = unite(v1040_7,v1040_11);
        v1039_15_result = unite(v1039_15_result,v1040_12);
      }
      const Space v1039_15 = std::move(v1039_15_result);
      const Space v1039_16 = routine_54(c, v1039_13);
      Space v1039_17_result;
      for (int v1039_17_label = 1; v1039_17_label <= 2; ++v1039_17_label) {
        const Space v1039_17_tail = child(v1039_16,v1039_17_label);
        if (v1039_17_tail.empty()) continue;
        const Path v1039_17_head{v1039_17_label};
        const Space v1043_2 = singleton(v1039_17_head);
        const Space v1043_3 = intersect(constant_6,v1043_2);
        const Space v1043_4 = (has_head(v1043_3) ? constant_7 : Space{});
        const Space v1043_5 = subtract(constant_0,v1043_4);
        Space v1043_7;
        if (!v1043_5.empty()) {
          const Space v1044_6 = routine_55(c, v1039_17_head, v1039_17_tail);
          v1043_7 = compose(v1043_5,v1044_6);
        }
        const Space v1043_8 = intersect(constant_6,v1043_2);
        const Space v1043_9 = (has_head(v1043_8) ? constant_7 : Space{});
        Space v1043_11;
        if (!v1043_9.empty()) {
          const Space v1045_10 = routine_56(c, v1039_17_head, v1039_17_tail);
          v1043_11 = compose(v1043_9,v1045_10);
        }
        const Space v1043_12 = unite(v1043_7,v1043_11);
        v1039_17_result = unite(v1039_17_result,v1043_12);
      }
      const Space v1039_17 = std::move(v1039_17_result);
      const Space v1039_18 = subtract(v1039_15,v1039_17);
      const Space v1039_19 = singleton(v1039_11);
      const Space v1039_20 = compose(v1039_18,v1039_19);
      Space v1039_21_result;
      for (int v1039_21_label = 1; v1039_21_label <= 2; ++v1039_21_label) {
        const Space v1039_21_tail = child(v1039_20,v1039_21_label);
        if (v1039_21_tail.empty()) continue;
        const Path v1039_21_head{v1039_21_label};
        const Space v1046_2 = singleton(v1039_21_head);
        const Space v1046_3 = intersect(constant_6,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_7 : Space{});
        const Space v1046_5 = subtract(constant_0,v1046_4);
        Space v1046_7;
        if (!v1046_5.empty()) {
          const Space v1047_6 = routine_57(c, v1039_21_head, v1039_21_tail);
          v1046_7 = compose(v1046_5,v1047_6);
        }
        const Space v1046_8 = intersect(constant_6,v1046_2);
        const Space v1046_9 = (has_head(v1046_8) ? constant_7 : Space{});
        Space v1046_11;
        if (!v1046_9.empty()) {
          const Space v1048_10 = routine_58(c, v1039_21_head, v1039_21_tail);
          v1046_11 = compose(v1046_9,v1048_10);
        }
        const Space v1046_12 = unite(v1046_7,v1046_11);
        v1039_21_result = unite(v1039_21_result,v1046_12);
      }
      const Space v1039_21 = std::move(v1039_21_result);
      v1034_22 = compose(v1034_10,v1039_21);
    }
    const Space v1034_23 = unite(v1034_8,v1034_22);
    v1033_21_result = unite(v1033_21_result,v1034_23);
  }
  const Space v1033_21 = std::move(v1033_21_result);
  return v1033_21;
}

static Space routine_110(Context& c, const Path& p0, const Space& s0) {
  Space v1049_11_result;
  for (int v1049_11_label = 1; v1049_11_label <= 2; ++v1049_11_label) {
    const Space v1049_11_tail = child(s0,v1049_11_label);
    if (v1049_11_tail.empty()) continue;
    const Path v1049_11_head{v1049_11_label};
    const Space v1050_2 = singleton(v1049_11_head);
    const Space v1050_3 = intersect(constant_6,v1050_2);
    const Space v1050_4 = (has_head(v1050_3) ? constant_7 : Space{});
    const Space v1050_5 = subtract(constant_0,v1050_4);
    Space v1050_8;
    if (!v1050_5.empty()) {
      const Path v1051_6 = concat_path(p0,v1049_11_head);
      Space v1051_7_result;
      for (int v1051_7_label = 1; v1051_7_label <= 2; ++v1051_7_label) {
        const Space v1051_7_tail = child(v1049_11_tail,v1051_7_label);
        if (v1051_7_tail.empty()) continue;
        const Path v1051_7_head{v1051_7_label};
        const Space v1052_2 = singleton(v1051_7_head);
        const Space v1052_3 = intersect(constant_6,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_7 : Space{});
        const Space v1052_5 = subtract(constant_0,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1053_7 = routine_163(c, v1053_6, v1051_7_tail);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_6,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_7 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1054_11 = routine_164(c, v1054_6, v1051_7_tail);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_7_result = unite(v1051_7_result,v1052_13);
      }
      const Space v1051_7 = std::move(v1051_7_result);
      v1050_8 = compose(v1050_5,v1051_7);
    }
    const Space v1050_9 = intersect(constant_6,v1050_2);
    const Space v1050_10 = (has_head(v1050_9) ? constant_7 : Space{});
    Space v1050_12;
    if (!v1050_10.empty()) {
      const Path v1055_6 = concat_path(p0,v1049_11_head);
      Space v1055_11_result;
      for (int v1055_11_label = 1; v1055_11_label <= 2; ++v1055_11_label) {
        const Space v1055_11_tail = child(v1049_11_tail,v1055_11_label);
        if (v1055_11_tail.empty()) continue;
        const Path v1055_11_head{v1055_11_label};
        const Space v1056_2 = singleton(v1055_11_head);
        const Space v1056_3 = intersect(constant_6,v1056_2);
        const Space v1056_4 = (has_head(v1056_3) ? constant_7 : Space{});
        const Space v1056_5 = subtract(constant_0,v1056_4);
        Space v1056_8;
        if (!v1056_5.empty()) {
          const Path v1057_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1057_7 = routine_163(c, v1057_6, v1055_11_tail);
          v1056_8 = compose(v1056_5,v1057_7);
        }
        const Space v1056_9 = intersect(constant_6,v1056_2);
        const Space v1056_10 = (has_head(v1056_9) ? constant_7 : Space{});
        Space v1056_12;
        if (!v1056_10.empty()) {
          const Path v1058_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1058_11 = routine_100(c, v1058_6, v1055_11_tail);
          v1056_12 = compose(v1056_10,v1058_11);
        }
        const Space v1056_13 = unite(v1056_8,v1056_12);
        v1055_11_result = unite(v1055_11_result,v1056_13);
      }
      const Space v1055_11 = std::move(v1055_11_result);
      v1050_12 = compose(v1050_10,v1055_11);
    }
    const Space v1050_13 = unite(v1050_8,v1050_12);
    v1049_11_result = unite(v1049_11_result,v1050_13);
  }
  const Space v1049_11 = std::move(v1049_11_result);
  return v1049_11;
}

static Space routine_111(Context& c, const Path& p0, const Space& s0) {
  Space v1059_9_result;
  for (int v1059_9_label = 1; v1059_9_label <= 2; ++v1059_9_label) {
    const Space v1059_9_tail = child(s0,v1059_9_label);
    if (v1059_9_tail.empty()) continue;
    const Path v1059_9_head{v1059_9_label};
    const Space v1060_2 = singleton(v1059_9_head);
    const Space v1060_3 = intersect(constant_6,v1060_2);
    const Space v1060_4 = (has_head(v1060_3) ? constant_7 : Space{});
    const Space v1060_5 = subtract(constant_0,v1060_4);
    Space v1060_8;
    if (!v1060_5.empty()) {
      const Path v1061_6 = concat_path(p0,v1059_9_head);
      Space v1061_7_result;
      for (int v1061_7_label = 1; v1061_7_label <= 2; ++v1061_7_label) {
        const Space v1061_7_tail = child(v1059_9_tail,v1061_7_label);
        if (v1061_7_tail.empty()) continue;
        const Path v1061_7_head{v1061_7_label};
        const Space v1062_2 = singleton(v1061_7_head);
        const Space v1062_3 = intersect(constant_6,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_7 : Space{});
        const Space v1062_5 = subtract(constant_0,v1062_4);
        Space v1062_8;
        if (!v1062_5.empty()) {
          const Path v1063_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1063_7 = routine_163(c, v1063_6, v1061_7_tail);
          v1062_8 = compose(v1062_5,v1063_7);
        }
        const Space v1062_9 = intersect(constant_6,v1062_2);
        const Space v1062_10 = (has_head(v1062_9) ? constant_7 : Space{});
        Space v1062_12;
        if (!v1062_10.empty()) {
          const Path v1064_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1064_11 = routine_164(c, v1064_6, v1061_7_tail);
          v1062_12 = compose(v1062_10,v1064_11);
        }
        const Space v1062_13 = unite(v1062_8,v1062_12);
        v1061_7_result = unite(v1061_7_result,v1062_13);
      }
      const Space v1061_7 = std::move(v1061_7_result);
      v1060_8 = compose(v1060_5,v1061_7);
    }
    const Space v1060_9 = intersect(constant_6,v1060_2);
    const Space v1060_10 = (has_head(v1060_9) ? constant_7 : Space{});
    const Space v1060_11 = compose(v1060_10,constant_9);
    const Space v1060_12 = unite(v1060_8,v1060_11);
    v1059_9_result = unite(v1059_9_result,v1060_12);
  }
  const Space v1059_9 = std::move(v1059_9_result);
  return v1059_9;
}

static Space routine_112(Context& c, const Path& p0, const Space& s0) {
  Space v1065_11_result;
  for (int v1065_11_label = 1; v1065_11_label <= 2; ++v1065_11_label) {
    const Space v1065_11_tail = child(s0,v1065_11_label);
    if (v1065_11_tail.empty()) continue;
    const Path v1065_11_head{v1065_11_label};
    const Space v1066_2 = singleton(v1065_11_head);
    const Space v1066_3 = intersect(constant_6,v1066_2);
    const Space v1066_4 = (has_head(v1066_3) ? constant_7 : Space{});
    const Space v1066_5 = subtract(constant_0,v1066_4);
    Space v1066_8;
    if (!v1066_5.empty()) {
      const Path v1067_6 = concat_path(p0,v1065_11_head);
      Space v1067_7_result;
      for (int v1067_7_label = 1; v1067_7_label <= 2; ++v1067_7_label) {
        const Space v1067_7_tail = child(v1065_11_tail,v1067_7_label);
        if (v1067_7_tail.empty()) continue;
        const Path v1067_7_head{v1067_7_label};
        const Space v1068_2 = singleton(v1067_7_head);
        const Space v1068_3 = intersect(constant_6,v1068_2);
        const Space v1068_4 = (has_head(v1068_3) ? constant_7 : Space{});
        const Space v1068_5 = subtract(constant_0,v1068_4);
        Space v1068_8;
        if (!v1068_5.empty()) {
          const Path v1069_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1069_7 = routine_165(c, v1069_6, v1067_7_tail);
          v1068_8 = compose(v1068_5,v1069_7);
        }
        const Space v1068_9 = intersect(constant_6,v1068_2);
        const Space v1068_10 = (has_head(v1068_9) ? constant_7 : Space{});
        Space v1068_12;
        if (!v1068_10.empty()) {
          const Path v1070_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1070_11 = routine_166(c, v1070_6, v1067_7_tail);
          v1068_12 = compose(v1068_10,v1070_11);
        }
        const Space v1068_13 = unite(v1068_8,v1068_12);
        v1067_7_result = unite(v1067_7_result,v1068_13);
      }
      const Space v1067_7 = std::move(v1067_7_result);
      v1066_8 = compose(v1066_5,v1067_7);
    }
    const Space v1066_9 = intersect(constant_6,v1066_2);
    const Space v1066_10 = (has_head(v1066_9) ? constant_7 : Space{});
    Space v1066_12;
    if (!v1066_10.empty()) {
      const Path v1071_6 = concat_path(p0,v1065_11_head);
      Space v1071_11_result;
      for (int v1071_11_label = 1; v1071_11_label <= 2; ++v1071_11_label) {
        const Space v1071_11_tail = child(v1065_11_tail,v1071_11_label);
        if (v1071_11_tail.empty()) continue;
        const Path v1071_11_head{v1071_11_label};
        const Space v1072_2 = singleton(v1071_11_head);
        const Space v1072_3 = intersect(constant_6,v1072_2);
        const Space v1072_4 = (has_head(v1072_3) ? constant_7 : Space{});
        const Space v1072_5 = subtract(constant_0,v1072_4);
        Space v1072_8;
        if (!v1072_5.empty()) {
          const Path v1073_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1073_7 = routine_165(c, v1073_6, v1071_11_tail);
          v1072_8 = compose(v1072_5,v1073_7);
        }
        const Space v1072_9 = intersect(constant_6,v1072_2);
        const Space v1072_10 = (has_head(v1072_9) ? constant_7 : Space{});
        Space v1072_12;
        if (!v1072_10.empty()) {
          const Path v1074_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1074_11 = routine_104(c, v1074_6, v1071_11_tail);
          v1072_12 = compose(v1072_10,v1074_11);
        }
        const Space v1072_13 = unite(v1072_8,v1072_12);
        v1071_11_result = unite(v1071_11_result,v1072_13);
      }
      const Space v1071_11 = std::move(v1071_11_result);
      v1066_12 = compose(v1066_10,v1071_11);
    }
    const Space v1066_13 = unite(v1066_8,v1066_12);
    v1065_11_result = unite(v1065_11_result,v1066_13);
  }
  const Space v1065_11 = std::move(v1065_11_result);
  return v1065_11;
}

static Space routine_113(Context& c, const Path& p0, const Space& s0) {
  Space v1075_9_result;
  for (int v1075_9_label = 1; v1075_9_label <= 2; ++v1075_9_label) {
    const Space v1075_9_tail = child(s0,v1075_9_label);
    if (v1075_9_tail.empty()) continue;
    const Path v1075_9_head{v1075_9_label};
    const Space v1076_2 = singleton(v1075_9_head);
    const Space v1076_3 = intersect(constant_6,v1076_2);
    const Space v1076_4 = (has_head(v1076_3) ? constant_7 : Space{});
    const Space v1076_5 = subtract(constant_0,v1076_4);
    Space v1076_8;
    if (!v1076_5.empty()) {
      const Path v1077_6 = concat_path(p0,v1075_9_head);
      Space v1077_7_result;
      for (int v1077_7_label = 1; v1077_7_label <= 2; ++v1077_7_label) {
        const Space v1077_7_tail = child(v1075_9_tail,v1077_7_label);
        if (v1077_7_tail.empty()) continue;
        const Path v1077_7_head{v1077_7_label};
        const Space v1078_2 = singleton(v1077_7_head);
        const Space v1078_3 = intersect(constant_6,v1078_2);
        const Space v1078_4 = (has_head(v1078_3) ? constant_7 : Space{});
        const Space v1078_5 = subtract(constant_0,v1078_4);
        Space v1078_8;
        if (!v1078_5.empty()) {
          const Path v1079_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1079_7 = routine_165(c, v1079_6, v1077_7_tail);
          v1078_8 = compose(v1078_5,v1079_7);
        }
        const Space v1078_9 = intersect(constant_6,v1078_2);
        const Space v1078_10 = (has_head(v1078_9) ? constant_7 : Space{});
        Space v1078_12;
        if (!v1078_10.empty()) {
          const Path v1080_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1080_11 = routine_166(c, v1080_6, v1077_7_tail);
          v1078_12 = compose(v1078_10,v1080_11);
        }
        const Space v1078_13 = unite(v1078_8,v1078_12);
        v1077_7_result = unite(v1077_7_result,v1078_13);
      }
      const Space v1077_7 = std::move(v1077_7_result);
      v1076_8 = compose(v1076_5,v1077_7);
    }
    const Space v1076_9 = intersect(constant_6,v1076_2);
    const Space v1076_10 = (has_head(v1076_9) ? constant_7 : Space{});
    const Space v1076_11 = compose(v1076_10,constant_9);
    const Space v1076_12 = unite(v1076_8,v1076_11);
    v1075_9_result = unite(v1075_9_result,v1076_12);
  }
  const Space v1075_9 = std::move(v1075_9_result);
  return v1075_9;
}

static Space routine_114(Context& c, const Path& p0, const Space& s0) {
  Space v1081_11_result;
  for (int v1081_11_label = 1; v1081_11_label <= 2; ++v1081_11_label) {
    const Space v1081_11_tail = child(s0,v1081_11_label);
    if (v1081_11_tail.empty()) continue;
    const Path v1081_11_head{v1081_11_label};
    const Space v1082_2 = singleton(v1081_11_head);
    const Space v1082_3 = intersect(constant_6,v1082_2);
    const Space v1082_4 = (has_head(v1082_3) ? constant_7 : Space{});
    const Space v1082_5 = subtract(constant_0,v1082_4);
    Space v1082_8;
    if (!v1082_5.empty()) {
      const Path v1083_6 = concat_path(p0,v1081_11_head);
      Space v1083_7_result;
      for (int v1083_7_label = 1; v1083_7_label <= 2; ++v1083_7_label) {
        const Space v1083_7_tail = child(v1081_11_tail,v1083_7_label);
        if (v1083_7_tail.empty()) continue;
        const Path v1083_7_head{v1083_7_label};
        const Space v1084_2 = singleton(v1083_7_head);
        const Space v1084_3 = intersect(constant_6,v1084_2);
        const Space v1084_4 = (has_head(v1084_3) ? constant_7 : Space{});
        const Space v1084_5 = subtract(constant_0,v1084_4);
        Space v1084_8;
        if (!v1084_5.empty()) {
          const Path v1085_6 = concat_path(v1083_6,v1083_7_head);
          const Space v1085_7 = routine_167(c, v1085_6, v1083_7_tail);
          v1084_8 = compose(v1084_5,v1085_7);
        }
        const Space v1084_9 = intersect(constant_6,v1084_2);
        const Space v1084_10 = (has_head(v1084_9) ? constant_7 : Space{});
        Space v1084_12;
        if (!v1084_10.empty()) {
          const Path v1086_6 = concat_path(v1083_6,v1083_7_head);
          const Space v1086_11 = routine_168(c, v1086_6, v1083_7_tail);
          v1084_12 = compose(v1084_10,v1086_11);
        }
        const Space v1084_13 = unite(v1084_8,v1084_12);
        v1083_7_result = unite(v1083_7_result,v1084_13);
      }
      const Space v1083_7 = std::move(v1083_7_result);
      v1082_8 = compose(v1082_5,v1083_7);
    }
    const Space v1082_9 = intersect(constant_6,v1082_2);
    const Space v1082_10 = (has_head(v1082_9) ? constant_7 : Space{});
    Space v1082_12;
    if (!v1082_10.empty()) {
      const Path v1087_6 = concat_path(p0,v1081_11_head);
      Space v1087_11_result;
      for (int v1087_11_label = 1; v1087_11_label <= 2; ++v1087_11_label) {
        const Space v1087_11_tail = child(v1081_11_tail,v1087_11_label);
        if (v1087_11_tail.empty()) continue;
        const Path v1087_11_head{v1087_11_label};
        const Space v1088_2 = singleton(v1087_11_head);
        const Space v1088_3 = intersect(constant_6,v1088_2);
        const Space v1088_4 = (has_head(v1088_3) ? constant_7 : Space{});
        const Space v1088_5 = subtract(constant_0,v1088_4);
        Space v1088_8;
        if (!v1088_5.empty()) {
          const Path v1089_6 = concat_path(v1087_6,v1087_11_head);
          const Space v1089_7 = routine_167(c, v1089_6, v1087_11_tail);
          v1088_8 = compose(v1088_5,v1089_7);
        }
        const Space v1088_9 = intersect(constant_6,v1088_2);
        const Space v1088_10 = (has_head(v1088_9) ? constant_7 : Space{});
        Space v1088_12;
        if (!v1088_10.empty()) {
          const Path v1090_6 = concat_path(v1087_6,v1087_11_head);
          const Space v1090_11 = routine_107(c, v1090_6, v1087_11_tail);
          v1088_12 = compose(v1088_10,v1090_11);
        }
        const Space v1088_13 = unite(v1088_8,v1088_12);
        v1087_11_result = unite(v1087_11_result,v1088_13);
      }
      const Space v1087_11 = std::move(v1087_11_result);
      v1082_12 = compose(v1082_10,v1087_11);
    }
    const Space v1082_13 = unite(v1082_8,v1082_12);
    v1081_11_result = unite(v1081_11_result,v1082_13);
  }
  const Space v1081_11 = std::move(v1081_11_result);
  return v1081_11;
}

static Space routine_115(Context& c, const Path& p0, const Space& s0) {
  Space v1091_8_result;
  for (int v1091_8_label = 1; v1091_8_label <= 2; ++v1091_8_label) {
    const Space v1091_8_tail = child(s0,v1091_8_label);
    if (v1091_8_tail.empty()) continue;
    const Path v1091_8_head{v1091_8_label};
    const Space v1092_2 = singleton(v1091_8_head);
    const Space v1092_3 = intersect(constant_6,v1092_2);
    const Space v1092_4 = (has_head(v1092_3) ? constant_7 : Space{});
    const Space v1092_5 = subtract(constant_0,v1092_4);
    Space v1092_8;
    if (!v1092_5.empty()) {
      const Path v1093_6 = concat_path(p0,v1091_8_head);
      Space v1093_7_result;
      for (int v1093_7_label = 1; v1093_7_label <= 2; ++v1093_7_label) {
        const Space v1093_7_tail = child(v1091_8_tail,v1093_7_label);
        if (v1093_7_tail.empty()) continue;
        const Path v1093_7_head{v1093_7_label};
        const Space v1094_2 = singleton(v1093_7_head);
        const Space v1094_3 = intersect(constant_6,v1094_2);
        const Space v1094_4 = (has_head(v1094_3) ? constant_7 : Space{});
        const Space v1094_5 = subtract(constant_0,v1094_4);
        Space v1094_8;
        if (!v1094_5.empty()) {
          const Path v1095_6 = concat_path(v1093_6,v1093_7_head);
          const Space v1095_7 = routine_167(c, v1095_6, v1093_7_tail);
          v1094_8 = compose(v1094_5,v1095_7);
        }
        const Space v1094_9 = intersect(constant_6,v1094_2);
        const Space v1094_10 = (has_head(v1094_9) ? constant_7 : Space{});
        Space v1094_12;
        if (!v1094_10.empty()) {
          const Path v1096_6 = concat_path(v1093_6,v1093_7_head);
          const Space v1096_11 = routine_168(c, v1096_6, v1093_7_tail);
          v1094_12 = compose(v1094_10,v1096_11);
        }
        const Space v1094_13 = unite(v1094_8,v1094_12);
        v1093_7_result = unite(v1093_7_result,v1094_13);
      }
      const Space v1093_7 = std::move(v1093_7_result);
      v1092_8 = compose(v1092_5,v1093_7);
    }
    const Space v1092_9 = intersect(constant_6,v1092_2);
    const Space v1092_10 = (has_head(v1092_9) ? constant_7 : Space{});
    const Space v1092_11 = compose(v1092_10,v1091_8_tail);
    const Space v1092_12 = unite(v1092_8,v1092_11);
    v1091_8_result = unite(v1091_8_result,v1092_12);
  }
  const Space v1091_8 = std::move(v1091_8_result);
  return v1091_8;
}

static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1097_5_result;
  for (int v1097_5_label = 1; v1097_5_label <= 2; ++v1097_5_label) {
    const Space v1097_5_tail = child(s0,v1097_5_label);
    if (v1097_5_tail.empty()) continue;
    const Path v1097_5_head{v1097_5_label};
    const Space v1098_2 = singleton(v1097_5_head);
    const Space v1098_3 = intersect(constant_6,v1098_2);
    const Space v1098_4 = (has_head(v1098_3) ? constant_7 : Space{});
    Space v1098_7;
    if (!v1098_4.empty()) {
      const Path v1099_5 = concat_path(p0,v1097_5_head);
      Space v1099_6_result;
      for (int v1099_6_label = 1; v1099_6_label <= 2; ++v1099_6_label) {
        const Space v1099_6_tail = child(v1097_5_tail,v1099_6_label);
        if (v1099_6_tail.empty()) continue;
        const Path v1099_6_head{v1099_6_label};
        const Space v1100_2 = singleton(v1099_6_head);
        const Space v1100_3 = intersect(constant_6,v1100_2);
        const Space v1100_4 = (has_head(v1100_3) ? constant_7 : Space{});
        Space v1100_7;
        if (!v1100_4.empty()) {
          const Path v1101_5 = concat_path(v1099_5,v1099_6_head);
          const Space v1101_6 = routine_9(c, v1101_5, v1099_6_tail, s1);
          v1100_7 = compose(v1100_4,v1101_6);
        }
        v1099_6_result = unite(v1099_6_result,v1100_7);
      }
      const Space v1099_6 = std::move(v1099_6_result);
      v1098_7 = compose(v1098_4,v1099_6);
    }
    v1097_5_result = unite(v1097_5_result,v1098_7);
  }
  const Space v1097_5 = std::move(v1097_5_result);
  return v1097_5;
}

static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1102_7_result;
  for (int v1102_7_label = 1; v1102_7_label <= 2; ++v1102_7_label) {
    const Space v1102_7_tail = child(s0,v1102_7_label);
    if (v1102_7_tail.empty()) continue;
    const Path v1102_7_head{v1102_7_label};
    const Space v1103_2 = singleton(v1102_7_head);
    const Space v1103_3 = intersect(constant_6,v1103_2);
    const Space v1103_4 = (has_head(v1103_3) ? constant_7 : Space{});
    Space v1103_7;
    if (!v1103_4.empty()) {
      const Path v1104_5 = concat_path(p0,v1102_7_head);
      Space v1104_6_result;
      for (int v1104_6_label = 1; v1104_6_label <= 2; ++v1104_6_label) {
        const Space v1104_6_tail = child(v1102_7_tail,v1104_6_label);
        if (v1104_6_tail.empty()) continue;
        const Path v1104_6_head{v1104_6_label};
        const Space v1105_2 = singleton(v1104_6_head);
        const Space v1105_3 = intersect(constant_6,v1105_2);
        const Space v1105_4 = (has_head(v1105_3) ? constant_7 : Space{});
        const Space v1105_5 = subtract(constant_0,v1105_4);
        Space v1105_7;
        if (!v1105_5.empty()) {
          const Space v1106_6 = routine_10(c, v1104_6_head, v1104_5, v1104_6_tail, s1);
          v1105_7 = compose(v1105_5,v1106_6);
        }
        const Space v1105_8 = intersect(constant_6,v1105_2);
        const Space v1105_9 = (has_head(v1105_8) ? constant_7 : Space{});
        Space v1105_11;
        if (!v1105_9.empty()) {
          const Space v1107_10 = routine_11(c, v1104_6_head, v1104_5, v1104_6_tail, s1);
          v1105_11 = compose(v1105_9,v1107_10);
        }
        const Space v1105_12 = unite(v1105_7,v1105_11);
        v1104_6_result = unite(v1104_6_result,v1105_12);
      }
      const Space v1104_6 = std::move(v1104_6_result);
      v1103_7 = compose(v1103_4,v1104_6);
    }
    v1102_7_result = unite(v1102_7_result,v1103_7);
  }
  const Space v1102_7 = std::move(v1102_7_result);
  return v1102_7;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1108_13_result;
  for (int v1108_13_label = 1; v1108_13_label <= 2; ++v1108_13_label) {
    const Space v1108_13_tail = child(s0,v1108_13_label);
    if (v1108_13_tail.empty()) continue;
    const Path v1108_13_head{v1108_13_label};
    const Space v1109_2 = singleton(v1108_13_head);
    const Space v1109_3 = intersect(constant_6,v1109_2);
    const Space v1109_4 = (has_head(v1109_3) ? constant_7 : Space{});
    const Space v1109_5 = subtract(constant_0,v1109_4);
    Space v1109_8;
    if (!v1109_5.empty()) {
      const Path v1110_6 = concat_path(p0,v1108_13_head);
      Space v1110_7_result;
      for (int v1110_7_label = 1; v1110_7_label <= 2; ++v1110_7_label) {
        const Space v1110_7_tail = child(v1108_13_tail,v1110_7_label);
        if (v1110_7_tail.empty()) continue;
        const Path v1110_7_head{v1110_7_label};
        const Space v1111_2 = singleton(v1110_7_head);
        const Space v1111_3 = intersect(constant_6,v1111_2);
        const Space v1111_4 = (has_head(v1111_3) ? constant_7 : Space{});
        const Space v1111_5 = subtract(constant_0,v1111_4);
        Space v1111_8;
        if (!v1111_5.empty()) {
          const Path v1112_6 = concat_path(v1110_6,v1110_7_head);
          const Space v1112_7 = routine_169(c, v1112_6, p1, v1110_7_tail, s1);
          v1111_8 = compose(v1111_5,v1112_7);
        }
        const Space v1111_9 = intersect(constant_6,v1111_2);
        const Space v1111_10 = (has_head(v1111_9) ? constant_7 : Space{});
        Space v1111_12;
        if (!v1111_10.empty()) {
          const Path v1113_6 = concat_path(v1110_6,v1110_7_head);
          const Space v1113_11 = routine_170(c, v1113_6, p1, v1110_7_tail, s1);
          v1111_12 = compose(v1111_10,v1113_11);
        }
        const Space v1111_13 = unite(v1111_8,v1111_12);
        v1110_7_result = unite(v1110_7_result,v1111_13);
      }
      const Space v1110_7 = std::move(v1110_7_result);
      v1109_8 = compose(v1109_5,v1110_7);
    }
    const Space v1109_9 = intersect(constant_6,v1109_2);
    const Space v1109_10 = (has_head(v1109_9) ? constant_7 : Space{});
    Space v1109_12;
    if (!v1109_10.empty()) {
      const Path v1114_6 = concat_path(p0,v1108_13_head);
      Space v1114_11_result;
      for (int v1114_11_label = 1; v1114_11_label <= 2; ++v1114_11_label) {
        const Space v1114_11_tail = child(v1108_13_tail,v1114_11_label);
        if (v1114_11_tail.empty()) continue;
        const Path v1114_11_head{v1114_11_label};
        const Space v1115_2 = singleton(v1114_11_head);
        const Space v1115_3 = intersect(constant_6,v1115_2);
        const Space v1115_4 = (has_head(v1115_3) ? constant_7 : Space{});
        const Space v1115_5 = subtract(constant_0,v1115_4);
        Space v1115_8;
        if (!v1115_5.empty()) {
          const Path v1116_6 = concat_path(v1114_6,v1114_11_head);
          const Space v1116_7 = routine_169(c, v1116_6, p1, v1114_11_tail, s1);
          v1115_8 = compose(v1115_5,v1116_7);
        }
        const Space v1115_9 = intersect(constant_6,v1115_2);
        const Space v1115_10 = (has_head(v1115_9) ? constant_7 : Space{});
        Space v1115_12;
        if (!v1115_10.empty()) {
          const Path v1117_6 = concat_path(v1114_6,v1114_11_head);
          const Space v1117_11 = routine_26(c, v1117_6, p1, v1114_11_tail, s1);
          v1115_12 = compose(v1115_10,v1117_11);
        }
        const Space v1115_13 = unite(v1115_8,v1115_12);
        v1114_11_result = unite(v1114_11_result,v1115_13);
      }
      const Space v1114_11 = std::move(v1114_11_result);
      v1109_12 = compose(v1109_10,v1114_11);
    }
    const Space v1109_13 = unite(v1109_8,v1109_12);
    v1108_13_result = unite(v1108_13_result,v1109_13);
  }
  const Space v1108_13 = std::move(v1108_13_result);
  return v1108_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1118_8 = unwrap(s1,constant_8);
  Space v1118_21_result;
  for (int v1118_21_label = 1; v1118_21_label <= 2; ++v1118_21_label) {
    const Space v1118_21_tail = child(s0,v1118_21_label);
    if (v1118_21_tail.empty()) continue;
    const Path v1118_21_head{v1118_21_label};
    const Space v1119_2 = singleton(v1118_21_head);
    const Space v1119_3 = intersect(constant_6,v1119_2);
    const Space v1119_4 = (has_head(v1119_3) ? constant_7 : Space{});
    const Space v1119_5 = subtract(constant_0,v1119_4);
    Space v1119_8;
    if (!v1119_5.empty()) {
      const Path v1120_6 = concat_path(p0,v1118_21_head);
      Space v1120_7_result;
      for (int v1120_7_label = 1; v1120_7_label <= 2; ++v1120_7_label) {
        const Space v1120_7_tail = child(v1118_21_tail,v1120_7_label);
        if (v1120_7_tail.empty()) continue;
        const Path v1120_7_head{v1120_7_label};
        const Space v1121_2 = singleton(v1120_7_head);
        const Space v1121_3 = intersect(constant_6,v1121_2);
        const Space v1121_4 = (has_head(v1121_3) ? constant_7 : Space{});
        const Space v1121_5 = subtract(constant_0,v1121_4);
        Space v1121_8;
        if (!v1121_5.empty()) {
          const Path v1122_6 = concat_path(v1120_6,v1120_7_head);
          const Space v1122_7 = routine_169(c, v1122_6, p1, v1120_7_tail, s1);
          v1121_8 = compose(v1121_5,v1122_7);
        }
        const Space v1121_9 = intersect(constant_6,v1121_2);
        const Space v1121_10 = (has_head(v1121_9) ? constant_7 : Space{});
        Space v1121_12;
        if (!v1121_10.empty()) {
          const Path v1123_6 = concat_path(v1120_6,v1120_7_head);
          const Space v1123_11 = routine_170(c, v1123_6, p1, v1120_7_tail, s1);
          v1121_12 = compose(v1121_10,v1123_11);
        }
        const Space v1121_13 = unite(v1121_8,v1121_12);
        v1120_7_result = unite(v1120_7_result,v1121_13);
      }
      const Space v1120_7 = std::move(v1120_7_result);
      v1119_8 = compose(v1119_5,v1120_7);
    }
    const Space v1119_9 = intersect(constant_6,v1119_2);
    const Space v1119_10 = (has_head(v1119_9) ? constant_7 : Space{});
    Space v1119_22;
    if (!v1119_10.empty()) {
      const Path v1124_6 = concat_path(p0,v1118_21_head);
      const Path v1124_11 = concat_path(p1,v1124_6);
      const Space v1124_12 = routine_29(c, v1124_11);
      const Space v1124_13 = intersect(v1118_8,v1124_12);
      const Space v1124_14 = routine_30(c, v1124_13);
      Space v1124_15_result;
      for (int v1124_15_label = 1; v1124_15_label <= 2; ++v1124_15_label) {
        const Space v1124_15_tail = child(v1124_14,v1124_15_label);
        if (v1124_15_tail.empty()) continue;
        const Path v1124_15_head{v1124_15_label};
        const Space v1125_2 = singleton(v1124_15_head);
        const Space v1125_3 = intersect(constant_6,v1125_2);
        const Space v1125_4 = (has_head(v1125_3) ? constant_7 : Space{});
        const Space v1125_5 = subtract(constant_0,v1125_4);
        Space v1125_7;
        if (!v1125_5.empty()) {
          const Space v1126_6 = routine_31(c, v1124_15_head, v1124_15_tail);
          v1125_7 = compose(v1125_5,v1126_6);
        }
        const Space v1125_8 = intersect(constant_6,v1125_2);
        const Space v1125_9 = (has_head(v1125_8) ? constant_7 : Space{});
        Space v1125_11;
        if (!v1125_9.empty()) {
          const Space v1127_10 = routine_32(c, v1124_15_head, v1124_15_tail);
          v1125_11 = compose(v1125_9,v1127_10);
        }
        const Space v1125_12 = unite(v1125_7,v1125_11);
        v1124_15_result = unite(v1124_15_result,v1125_12);
      }
      const Space v1124_15 = std::move(v1124_15_result);
      const Space v1124_16 = routine_33(c, v1124_13);
      Space v1124_17_result;
      for (int v1124_17_label = 1; v1124_17_label <= 2; ++v1124_17_label) {
        const Space v1124_17_tail = child(v1124_16,v1124_17_label);
        if (v1124_17_tail.empty()) continue;
        const Path v1124_17_head{v1124_17_label};
        const Space v1128_2 = singleton(v1124_17_head);
        const Space v1128_3 = intersect(constant_6,v1128_2);
        const Space v1128_4 = (has_head(v1128_3) ? constant_7 : Space{});
        const Space v1128_5 = subtract(constant_0,v1128_4);
        Space v1128_7;
        if (!v1128_5.empty()) {
          const Space v1129_6 = routine_34(c, v1124_17_head, v1124_17_tail);
          v1128_7 = compose(v1128_5,v1129_6);
        }
        const Space v1128_8 = intersect(constant_6,v1128_2);
        const Space v1128_9 = (has_head(v1128_8) ? constant_7 : Space{});
        Space v1128_11;
        if (!v1128_9.empty()) {
          const Space v1130_10 = routine_35(c, v1124_17_head, v1124_17_tail);
          v1128_11 = compose(v1128_9,v1130_10);
        }
        const Space v1128_12 = unite(v1128_7,v1128_11);
        v1124_17_result = unite(v1124_17_result,v1128_12);
      }
      const Space v1124_17 = std::move(v1124_17_result);
      const Space v1124_18 = subtract(v1124_15,v1124_17);
      const Space v1124_19 = singleton(v1124_11);
      const Space v1124_20 = compose(v1124_18,v1124_19);
      Space v1124_21_result;
      for (int v1124_21_label = 1; v1124_21_label <= 2; ++v1124_21_label) {
        const Space v1124_21_tail = child(v1124_20,v1124_21_label);
        if (v1124_21_tail.empty()) continue;
        const Path v1124_21_head{v1124_21_label};
        const Space v1131_2 = singleton(v1124_21_head);
        const Space v1131_3 = intersect(constant_6,v1131_2);
        const Space v1131_4 = (has_head(v1131_3) ? constant_7 : Space{});
        const Space v1131_5 = subtract(constant_0,v1131_4);
        Space v1131_7;
        if (!v1131_5.empty()) {
          const Space v1132_6 = routine_36(c, v1124_21_head, v1124_21_tail);
          v1131_7 = compose(v1131_5,v1132_6);
        }
        const Space v1131_8 = intersect(constant_6,v1131_2);
        const Space v1131_9 = (has_head(v1131_8) ? constant_7 : Space{});
        Space v1131_11;
        if (!v1131_9.empty()) {
          const Space v1133_10 = routine_37(c, v1124_21_head, v1124_21_tail);
          v1131_11 = compose(v1131_9,v1133_10);
        }
        const Space v1131_12 = unite(v1131_7,v1131_11);
        v1124_21_result = unite(v1124_21_result,v1131_12);
      }
      const Space v1124_21 = std::move(v1124_21_result);
      v1119_22 = compose(v1119_10,v1124_21);
    }
    const Space v1119_23 = unite(v1119_8,v1119_22);
    v1118_21_result = unite(v1118_21_result,v1119_23);
  }
  const Space v1118_21 = std::move(v1118_21_result);
  return v1118_21;
}

static Space routine_120(Context& c, const Path& p0, const Space& s0) {
  Space v1134_11_result;
  for (int v1134_11_label = 1; v1134_11_label <= 2; ++v1134_11_label) {
    const Space v1134_11_tail = child(s0,v1134_11_label);
    if (v1134_11_tail.empty()) continue;
    const Path v1134_11_head{v1134_11_label};
    const Space v1135_2 = singleton(v1134_11_head);
    const Space v1135_3 = intersect(constant_6,v1135_2);
    const Space v1135_4 = (has_head(v1135_3) ? constant_7 : Space{});
    const Space v1135_5 = subtract(constant_0,v1135_4);
    Space v1135_8;
    if (!v1135_5.empty()) {
      const Path v1136_6 = concat_path(p0,v1134_11_head);
      Space v1136_7_result;
      for (int v1136_7_label = 1; v1136_7_label <= 2; ++v1136_7_label) {
        const Space v1136_7_tail = child(v1134_11_tail,v1136_7_label);
        if (v1136_7_tail.empty()) continue;
        const Path v1136_7_head{v1136_7_label};
        const Space v1137_2 = singleton(v1136_7_head);
        const Space v1137_3 = intersect(constant_6,v1137_2);
        const Space v1137_4 = (has_head(v1137_3) ? constant_7 : Space{});
        const Space v1137_5 = subtract(constant_0,v1137_4);
        Space v1137_8;
        if (!v1137_5.empty()) {
          const Path v1138_6 = concat_path(v1136_6,v1136_7_head);
          const Space v1138_7 = routine_171(c, v1138_6, v1136_7_tail);
          v1137_8 = compose(v1137_5,v1138_7);
        }
        const Space v1137_9 = intersect(constant_6,v1137_2);
        const Space v1137_10 = (has_head(v1137_9) ? constant_7 : Space{});
        Space v1137_12;
        if (!v1137_10.empty()) {
          const Path v1139_6 = concat_path(v1136_6,v1136_7_head);
          const Space v1139_11 = routine_172(c, v1139_6, v1136_7_tail);
          v1137_12 = compose(v1137_10,v1139_11);
        }
        const Space v1137_13 = unite(v1137_8,v1137_12);
        v1136_7_result = unite(v1136_7_result,v1137_13);
      }
      const Space v1136_7 = std::move(v1136_7_result);
      v1135_8 = compose(v1135_5,v1136_7);
    }
    const Space v1135_9 = intersect(constant_6,v1135_2);
    const Space v1135_10 = (has_head(v1135_9) ? constant_7 : Space{});
    Space v1135_12;
    if (!v1135_10.empty()) {
      const Path v1140_6 = concat_path(p0,v1134_11_head);
      Space v1140_11_result;
      for (int v1140_11_label = 1; v1140_11_label <= 2; ++v1140_11_label) {
        const Space v1140_11_tail = child(v1134_11_tail,v1140_11_label);
        if (v1140_11_tail.empty()) continue;
        const Path v1140_11_head{v1140_11_label};
        const Space v1141_2 = singleton(v1140_11_head);
        const Space v1141_3 = intersect(constant_6,v1141_2);
        const Space v1141_4 = (has_head(v1141_3) ? constant_7 : Space{});
        const Space v1141_5 = subtract(constant_0,v1141_4);
        Space v1141_8;
        if (!v1141_5.empty()) {
          const Path v1142_6 = concat_path(v1140_6,v1140_11_head);
          const Space v1142_7 = routine_171(c, v1142_6, v1140_11_tail);
          v1141_8 = compose(v1141_5,v1142_7);
        }
        const Space v1141_9 = intersect(constant_6,v1141_2);
        const Space v1141_10 = (has_head(v1141_9) ? constant_7 : Space{});
        Space v1141_12;
        if (!v1141_10.empty()) {
          const Path v1143_6 = concat_path(v1140_6,v1140_11_head);
          const Space v1143_11 = routine_80(c, v1143_6, v1140_11_tail);
          v1141_12 = compose(v1141_10,v1143_11);
        }
        const Space v1141_13 = unite(v1141_8,v1141_12);
        v1140_11_result = unite(v1140_11_result,v1141_13);
      }
      const Space v1140_11 = std::move(v1140_11_result);
      v1135_12 = compose(v1135_10,v1140_11);
    }
    const Space v1135_13 = unite(v1135_8,v1135_12);
    v1134_11_result = unite(v1134_11_result,v1135_13);
  }
  const Space v1134_11 = std::move(v1134_11_result);
  return v1134_11;
}

static Space routine_121(Context& c, const Path& p0, const Space& s0) {
  Space v1144_11_result;
  for (int v1144_11_label = 1; v1144_11_label <= 2; ++v1144_11_label) {
    const Space v1144_11_tail = child(s0,v1144_11_label);
    if (v1144_11_tail.empty()) continue;
    const Path v1144_11_head{v1144_11_label};
    const Space v1145_2 = singleton(v1144_11_head);
    const Space v1145_3 = intersect(constant_6,v1145_2);
    const Space v1145_4 = (has_head(v1145_3) ? constant_7 : Space{});
    const Space v1145_5 = subtract(constant_0,v1145_4);
    Space v1145_8;
    if (!v1145_5.empty()) {
      const Path v1146_6 = concat_path(p0,v1144_11_head);
      Space v1146_7_result;
      for (int v1146_7_label = 1; v1146_7_label <= 2; ++v1146_7_label) {
        const Space v1146_7_tail = child(v1144_11_tail,v1146_7_label);
        if (v1146_7_tail.empty()) continue;
        const Path v1146_7_head{v1146_7_label};
        const Space v1147_2 = singleton(v1146_7_head);
        const Space v1147_3 = intersect(constant_6,v1147_2);
        const Space v1147_4 = (has_head(v1147_3) ? constant_7 : Space{});
        const Space v1147_5 = subtract(constant_0,v1147_4);
        Space v1147_8;
        if (!v1147_5.empty()) {
          const Path v1148_6 = concat_path(v1146_6,v1146_7_head);
          const Space v1148_7 = routine_171(c, v1148_6, v1146_7_tail);
          v1147_8 = compose(v1147_5,v1148_7);
        }
        const Space v1147_9 = intersect(constant_6,v1147_2);
        const Space v1147_10 = (has_head(v1147_9) ? constant_7 : Space{});
        Space v1147_12;
        if (!v1147_10.empty()) {
          const Path v1149_6 = concat_path(v1146_6,v1146_7_head);
          const Space v1149_11 = routine_172(c, v1149_6, v1146_7_tail);
          v1147_12 = compose(v1147_10,v1149_11);
        }
        const Space v1147_13 = unite(v1147_8,v1147_12);
        v1146_7_result = unite(v1146_7_result,v1147_13);
      }
      const Space v1146_7 = std::move(v1146_7_result);
      v1145_8 = compose(v1145_5,v1146_7);
    }
    const Space v1145_9 = intersect(constant_6,v1145_2);
    const Space v1145_10 = (has_head(v1145_9) ? constant_7 : Space{});
    Space v1145_12;
    if (!v1145_10.empty()) {
      const Path v1150_6 = concat_path(p0,v1144_11_head);
      Space v1150_11_result;
      for (int v1150_11_label = 1; v1150_11_label <= 2; ++v1150_11_label) {
        const Space v1150_11_tail = child(v1144_11_tail,v1150_11_label);
        if (v1150_11_tail.empty()) continue;
        const Path v1150_11_head{v1150_11_label};
        const Space v1151_2 = singleton(v1150_11_head);
        const Space v1151_3 = intersect(constant_6,v1151_2);
        const Space v1151_4 = (has_head(v1151_3) ? constant_7 : Space{});
        const Space v1151_5 = subtract(constant_0,v1151_4);
        Space v1151_7;
        if (!v1151_5.empty()) {
          const Space v1152_6 = routine_122(c, v1150_11_head, v1150_6, v1150_11_tail);
          v1151_7 = compose(v1151_5,v1152_6);
        }
        const Space v1151_8 = intersect(constant_6,v1151_2);
        const Space v1151_9 = (has_head(v1151_8) ? constant_7 : Space{});
        Space v1151_11;
        if (!v1151_9.empty()) {
          const Space v1153_10 = routine_123(c, v1150_11_head, v1150_6, v1150_11_tail);
          v1151_11 = compose(v1151_9,v1153_10);
        }
        const Space v1151_12 = unite(v1151_7,v1151_11);
        v1150_11_result = unite(v1150_11_result,v1151_12);
      }
      const Space v1150_11 = std::move(v1150_11_result);
      v1145_12 = compose(v1145_10,v1150_11);
    }
    const Space v1145_13 = unite(v1145_8,v1145_12);
    v1144_11_result = unite(v1144_11_result,v1145_13);
  }
  const Space v1144_11 = std::move(v1144_11_result);
  return v1144_11;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1154_12_result;
  for (int v1154_12_label = 1; v1154_12_label <= 2; ++v1154_12_label) {
    const Space v1154_12_tail = child(s0,v1154_12_label);
    if (v1154_12_tail.empty()) continue;
    const Path v1154_12_head{v1154_12_label};
    const Space v1155_2 = singleton(v1154_12_head);
    const Space v1155_3 = intersect(constant_6,v1155_2);
    const Space v1155_4 = (has_head(v1155_3) ? constant_7 : Space{});
    const Space v1155_5 = subtract(constant_0,v1155_4);
    Space v1155_8;
    if (!v1155_5.empty()) {
      const Path v1156_6 = concat_path(p0,v1154_12_head);
      Space v1156_7_result;
      for (int v1156_7_label = 1; v1156_7_label <= 2; ++v1156_7_label) {
        const Space v1156_7_tail = child(v1154_12_tail,v1156_7_label);
        if (v1156_7_tail.empty()) continue;
        const Path v1156_7_head{v1156_7_label};
        const Space v1157_2 = singleton(v1156_7_head);
        const Space v1157_3 = intersect(constant_6,v1157_2);
        const Space v1157_4 = (has_head(v1157_3) ? constant_7 : Space{});
        const Space v1157_5 = subtract(constant_0,v1157_4);
        Space v1157_8;
        if (!v1157_5.empty()) {
          const Path v1158_6 = concat_path(v1156_6,v1156_7_head);
          const Space v1158_7 = routine_173(c, v1158_6, p1, v1156_7_tail);
          v1157_8 = compose(v1157_5,v1158_7);
        }
        const Space v1157_9 = intersect(constant_6,v1157_2);
        const Space v1157_10 = (has_head(v1157_9) ? constant_7 : Space{});
        Space v1157_12;
        if (!v1157_10.empty()) {
          const Path v1159_6 = concat_path(v1156_6,v1156_7_head);
          const Space v1159_11 = routine_174(c, v1159_6, p1, v1156_7_tail);
          v1157_12 = compose(v1157_10,v1159_11);
        }
        const Space v1157_13 = unite(v1157_8,v1157_12);
        v1156_7_result = unite(v1156_7_result,v1157_13);
      }
      const Space v1156_7 = std::move(v1156_7_result);
      v1155_8 = compose(v1155_5,v1156_7);
    }
    const Space v1155_9 = intersect(constant_6,v1155_2);
    const Space v1155_10 = (has_head(v1155_9) ? constant_7 : Space{});
    Space v1155_12;
    if (!v1155_10.empty()) {
      const Path v1160_6 = concat_path(p0,v1154_12_head);
      Space v1160_11_result;
      for (int v1160_11_label = 1; v1160_11_label <= 2; ++v1160_11_label) {
        const Space v1160_11_tail = child(v1154_12_tail,v1160_11_label);
        if (v1160_11_tail.empty()) continue;
        const Path v1160_11_head{v1160_11_label};
        const Space v1161_2 = singleton(v1160_11_head);
        const Space v1161_3 = intersect(constant_6,v1161_2);
        const Space v1161_4 = (has_head(v1161_3) ? constant_7 : Space{});
        const Space v1161_5 = subtract(constant_0,v1161_4);
        Space v1161_8;
        if (!v1161_5.empty()) {
          const Path v1162_6 = concat_path(v1160_6,v1160_11_head);
          const Space v1162_7 = routine_173(c, v1162_6, p1, v1160_11_tail);
          v1161_8 = compose(v1161_5,v1162_7);
        }
        const Space v1161_9 = intersect(constant_6,v1161_2);
        const Space v1161_10 = (has_head(v1161_9) ? constant_7 : Space{});
        Space v1161_12;
        if (!v1161_10.empty()) {
          const Path v1163_6 = concat_path(v1160_6,v1160_11_head);
          const Space v1163_11 = routine_137(c, v1163_6, p1, v1160_11_tail);
          v1161_12 = compose(v1161_10,v1163_11);
        }
        const Space v1161_13 = unite(v1161_8,v1161_12);
        v1160_11_result = unite(v1160_11_result,v1161_13);
      }
      const Space v1160_11 = std::move(v1160_11_result);
      v1155_12 = compose(v1155_10,v1160_11);
    }
    const Space v1155_13 = unite(v1155_8,v1155_12);
    v1154_12_result = unite(v1154_12_result,v1155_13);
  }
  const Space v1154_12 = std::move(v1154_12_result);
  return v1154_12;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1164_7 = unwrap(constant_12,p1);
  const Space v1164_9 = unwrap(constant_12,p0);
  Space v1164_13_result;
  for (int v1164_13_label = 1; v1164_13_label <= 2; ++v1164_13_label) {
    const Space v1164_13_tail = child(s0,v1164_13_label);
    if (v1164_13_tail.empty()) continue;
    const Path v1164_13_head{v1164_13_label};
    const Space v1165_2 = singleton(v1164_13_head);
    const Space v1165_3 = intersect(constant_6,v1165_2);
    const Space v1165_4 = (has_head(v1165_3) ? constant_7 : Space{});
    const Space v1165_5 = subtract(constant_0,v1165_4);
    Space v1165_8;
    if (!v1165_5.empty()) {
      const Path v1166_6 = concat_path(p0,v1164_13_head);
      Space v1166_7_result;
      for (int v1166_7_label = 1; v1166_7_label <= 2; ++v1166_7_label) {
        const Space v1166_7_tail = child(v1164_13_tail,v1166_7_label);
        if (v1166_7_tail.empty()) continue;
        const Path v1166_7_head{v1166_7_label};
        const Space v1167_2 = singleton(v1166_7_head);
        const Space v1167_3 = intersect(constant_6,v1167_2);
        const Space v1167_4 = (has_head(v1167_3) ? constant_7 : Space{});
        const Space v1167_5 = subtract(constant_0,v1167_4);
        Space v1167_8;
        if (!v1167_5.empty()) {
          const Path v1168_6 = concat_path(v1166_6,v1166_7_head);
          const Space v1168_7 = routine_173(c, v1168_6, p1, v1166_7_tail);
          v1167_8 = compose(v1167_5,v1168_7);
        }
        const Space v1167_9 = intersect(constant_6,v1167_2);
        const Space v1167_10 = (has_head(v1167_9) ? constant_7 : Space{});
        Space v1167_12;
        if (!v1167_10.empty()) {
          const Path v1169_6 = concat_path(v1166_6,v1166_7_head);
          const Space v1169_11 = routine_174(c, v1169_6, p1, v1166_7_tail);
          v1167_12 = compose(v1167_10,v1169_11);
        }
        const Space v1167_13 = unite(v1167_8,v1167_12);
        v1166_7_result = unite(v1166_7_result,v1167_13);
      }
      const Space v1166_7 = std::move(v1166_7_result);
      v1165_8 = compose(v1165_5,v1166_7);
    }
    const Space v1165_9 = intersect(constant_6,v1165_2);
    const Space v1165_10 = (has_head(v1165_9) ? constant_7 : Space{});
    const Space v1165_11 = unwrap(v1164_9,v1164_13_head);
    const Space v1165_12 = compose(v1164_7,v1165_11);
    const Path v1170_6 = concat_path(p0,v1164_13_head);
    const Path v1165_13 = concat_path(p1,v1170_6);
    const Space v1165_14 = singleton(v1165_13);
    const Space v1165_15 = subtract(v1165_12,v1165_14);
    const Space v1165_16 = compose(v1165_10,v1165_15);
    const Space v1165_17 = unite(v1165_8,v1165_16);
    v1164_13_result = unite(v1164_13_result,v1165_17);
  }
  const Space v1164_13 = std::move(v1164_13_result);
  return v1164_13;
}

static Space routine_124(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1171_3 = first_matching(s0,constant_0,false);
  Space v1171_7;
  if (!v1171_3.empty()) {
    const Space v1172_4 = unwrap(s1,p0);
    const Space v1172_5 = routine_81(c, v1172_4);
    const Space v1172_6 = wrap(v1172_5,p0);
    v1171_7 = compose(v1171_3,v1172_6);
  }
  Space v1171_8_result;
  for (int v1171_8_label = 1; v1171_8_label <= 2; ++v1171_8_label) {
    const Space v1171_8_tail = child(s0,v1171_8_label);
    if (v1171_8_tail.empty()) continue;
    const Path v1171_8_head{v1171_8_label};
    const Path v1173_2 = concat_path(p0,v1171_8_head);
    const Space v1173_3 = routine_124(c, v1173_2, v1171_8_tail, s1);
    v1171_8_result = unite(v1171_8_result,v1173_3);
  }
  const Space v1171_8 = std::move(v1171_8_result);
  const Space v1171_9 = unite(v1171_7,v1171_8);
  return v1171_9;
}

static Space routine_125(Context& c, const Path& p0, const Space& s0) {
  Space v1174_11_result;
  for (int v1174_11_label = 1; v1174_11_label <= 2; ++v1174_11_label) {
    const Space v1174_11_tail = child(s0,v1174_11_label);
    if (v1174_11_tail.empty()) continue;
    const Path v1174_11_head{v1174_11_label};
    const Space v1175_2 = singleton(v1174_11_head);
    const Space v1175_3 = intersect(constant_6,v1175_2);
    const Space v1175_4 = (has_head(v1175_3) ? constant_7 : Space{});
    const Space v1175_5 = subtract(constant_0,v1175_4);
    Space v1175_8;
    if (!v1175_5.empty()) {
      const Path v1176_6 = concat_path(p0,v1174_11_head);
      Space v1176_7_result;
      for (int v1176_7_label = 1; v1176_7_label <= 2; ++v1176_7_label) {
        const Space v1176_7_tail = child(v1174_11_tail,v1176_7_label);
        if (v1176_7_tail.empty()) continue;
        const Path v1176_7_head{v1176_7_label};
        const Space v1177_2 = singleton(v1176_7_head);
        const Space v1177_3 = intersect(constant_6,v1177_2);
        const Space v1177_4 = (has_head(v1177_3) ? constant_7 : Space{});
        const Space v1177_5 = subtract(constant_0,v1177_4);
        Space v1177_8;
        if (!v1177_5.empty()) {
          const Path v1178_6 = concat_path(v1176_6,v1176_7_head);
          const Space v1178_7 = routine_175(c, v1178_6, v1176_7_tail);
          v1177_8 = compose(v1177_5,v1178_7);
        }
        const Space v1177_9 = intersect(constant_6,v1177_2);
        const Space v1177_10 = (has_head(v1177_9) ? constant_7 : Space{});
        Space v1177_12;
        if (!v1177_10.empty()) {
          const Path v1179_6 = concat_path(v1176_6,v1176_7_head);
          const Space v1179_11 = routine_176(c, v1179_6, v1176_7_tail);
          v1177_12 = compose(v1177_10,v1179_11);
        }
        const Space v1177_13 = unite(v1177_8,v1177_12);
        v1176_7_result = unite(v1176_7_result,v1177_13);
      }
      const Space v1176_7 = std::move(v1176_7_result);
      v1175_8 = compose(v1175_5,v1176_7);
    }
    const Space v1175_9 = intersect(constant_6,v1175_2);
    const Space v1175_10 = (has_head(v1175_9) ? constant_7 : Space{});
    Space v1175_12;
    if (!v1175_10.empty()) {
      const Path v1180_6 = concat_path(p0,v1174_11_head);
      Space v1180_11_result;
      for (int v1180_11_label = 1; v1180_11_label <= 2; ++v1180_11_label) {
        const Space v1180_11_tail = child(v1174_11_tail,v1180_11_label);
        if (v1180_11_tail.empty()) continue;
        const Path v1180_11_head{v1180_11_label};
        const Space v1181_2 = singleton(v1180_11_head);
        const Space v1181_3 = intersect(constant_6,v1181_2);
        const Space v1181_4 = (has_head(v1181_3) ? constant_7 : Space{});
        const Space v1181_5 = subtract(constant_0,v1181_4);
        Space v1181_8;
        if (!v1181_5.empty()) {
          const Path v1182_6 = concat_path(v1180_6,v1180_11_head);
          const Space v1182_7 = routine_175(c, v1182_6, v1180_11_tail);
          v1181_8 = compose(v1181_5,v1182_7);
        }
        const Space v1181_9 = intersect(constant_6,v1181_2);
        const Space v1181_10 = (has_head(v1181_9) ? constant_7 : Space{});
        Space v1181_12;
        if (!v1181_10.empty()) {
          const Path v1183_6 = concat_path(v1180_6,v1180_11_head);
          const Space v1183_11 = routine_69(c, v1183_6, v1180_11_tail);
          v1181_12 = compose(v1181_10,v1183_11);
        }
        const Space v1181_13 = unite(v1181_8,v1181_12);
        v1180_11_result = unite(v1180_11_result,v1181_13);
      }
      const Space v1180_11 = std::move(v1180_11_result);
      v1175_12 = compose(v1175_10,v1180_11);
    }
    const Space v1175_13 = unite(v1175_8,v1175_12);
    v1174_11_result = unite(v1174_11_result,v1175_13);
  }
  const Space v1174_11 = std::move(v1174_11_result);
  return v1174_11;
}

static Space routine_126(Context& c, const Path& p0, const Space& s0) {
  Space v1184_9_result;
  for (int v1184_9_label = 1; v1184_9_label <= 2; ++v1184_9_label) {
    const Space v1184_9_tail = child(s0,v1184_9_label);
    if (v1184_9_tail.empty()) continue;
    const Path v1184_9_head{v1184_9_label};
    const Space v1185_2 = singleton(v1184_9_head);
    const Space v1185_3 = intersect(constant_6,v1185_2);
    const Space v1185_4 = (has_head(v1185_3) ? constant_7 : Space{});
    const Space v1185_5 = subtract(constant_0,v1185_4);
    Space v1185_8;
    if (!v1185_5.empty()) {
      const Path v1186_6 = concat_path(p0,v1184_9_head);
      Space v1186_7_result;
      for (int v1186_7_label = 1; v1186_7_label <= 2; ++v1186_7_label) {
        const Space v1186_7_tail = child(v1184_9_tail,v1186_7_label);
        if (v1186_7_tail.empty()) continue;
        const Path v1186_7_head{v1186_7_label};
        const Space v1187_2 = singleton(v1186_7_head);
        const Space v1187_3 = intersect(constant_6,v1187_2);
        const Space v1187_4 = (has_head(v1187_3) ? constant_7 : Space{});
        const Space v1187_5 = subtract(constant_0,v1187_4);
        Space v1187_8;
        if (!v1187_5.empty()) {
          const Path v1188_6 = concat_path(v1186_6,v1186_7_head);
          const Space v1188_7 = routine_175(c, v1188_6, v1186_7_tail);
          v1187_8 = compose(v1187_5,v1188_7);
        }
        const Space v1187_9 = intersect(constant_6,v1187_2);
        const Space v1187_10 = (has_head(v1187_9) ? constant_7 : Space{});
        Space v1187_12;
        if (!v1187_10.empty()) {
          const Path v1189_6 = concat_path(v1186_6,v1186_7_head);
          const Space v1189_11 = routine_176(c, v1189_6, v1186_7_tail);
          v1187_12 = compose(v1187_10,v1189_11);
        }
        const Space v1187_13 = unite(v1187_8,v1187_12);
        v1186_7_result = unite(v1186_7_result,v1187_13);
      }
      const Space v1186_7 = std::move(v1186_7_result);
      v1185_8 = compose(v1185_5,v1186_7);
    }
    const Space v1185_9 = intersect(constant_6,v1185_2);
    const Space v1185_10 = (has_head(v1185_9) ? constant_7 : Space{});
    const Space v1185_11 = compose(v1185_10,constant_9);
    const Space v1185_12 = unite(v1185_8,v1185_11);
    v1184_9_result = unite(v1184_9_result,v1185_12);
  }
  const Space v1184_9 = std::move(v1184_9_result);
  return v1184_9;
}

static Space routine_127(Context& c, const Path& p0, const Space& s0) {
  Space v1190_11_result;
  for (int v1190_11_label = 1; v1190_11_label <= 2; ++v1190_11_label) {
    const Space v1190_11_tail = child(s0,v1190_11_label);
    if (v1190_11_tail.empty()) continue;
    const Path v1190_11_head{v1190_11_label};
    const Space v1191_2 = singleton(v1190_11_head);
    const Space v1191_3 = intersect(constant_6,v1191_2);
    const Space v1191_4 = (has_head(v1191_3) ? constant_7 : Space{});
    const Space v1191_5 = subtract(constant_0,v1191_4);
    Space v1191_8;
    if (!v1191_5.empty()) {
      const Path v1192_6 = concat_path(p0,v1190_11_head);
      Space v1192_7_result;
      for (int v1192_7_label = 1; v1192_7_label <= 2; ++v1192_7_label) {
        const Space v1192_7_tail = child(v1190_11_tail,v1192_7_label);
        if (v1192_7_tail.empty()) continue;
        const Path v1192_7_head{v1192_7_label};
        const Space v1193_2 = singleton(v1192_7_head);
        const Space v1193_3 = intersect(constant_6,v1193_2);
        const Space v1193_4 = (has_head(v1193_3) ? constant_7 : Space{});
        const Space v1193_5 = subtract(constant_0,v1193_4);
        Space v1193_8;
        if (!v1193_5.empty()) {
          const Path v1194_6 = concat_path(v1192_6,v1192_7_head);
          const Space v1194_7 = routine_177(c, v1194_6, v1192_7_tail);
          v1193_8 = compose(v1193_5,v1194_7);
        }
        const Space v1193_9 = intersect(constant_6,v1193_2);
        const Space v1193_10 = (has_head(v1193_9) ? constant_7 : Space{});
        Space v1193_12;
        if (!v1193_10.empty()) {
          const Path v1195_6 = concat_path(v1192_6,v1192_7_head);
          const Space v1195_11 = routine_178(c, v1195_6, v1192_7_tail);
          v1193_12 = compose(v1193_10,v1195_11);
        }
        const Space v1193_13 = unite(v1193_8,v1193_12);
        v1192_7_result = unite(v1192_7_result,v1193_13);
      }
      const Space v1192_7 = std::move(v1192_7_result);
      v1191_8 = compose(v1191_5,v1192_7);
    }
    const Space v1191_9 = intersect(constant_6,v1191_2);
    const Space v1191_10 = (has_head(v1191_9) ? constant_7 : Space{});
    Space v1191_12;
    if (!v1191_10.empty()) {
      const Path v1196_6 = concat_path(p0,v1190_11_head);
      Space v1196_11_result;
      for (int v1196_11_label = 1; v1196_11_label <= 2; ++v1196_11_label) {
        const Space v1196_11_tail = child(v1190_11_tail,v1196_11_label);
        if (v1196_11_tail.empty()) continue;
        const Path v1196_11_head{v1196_11_label};
        const Space v1197_2 = singleton(v1196_11_head);
        const Space v1197_3 = intersect(constant_6,v1197_2);
        const Space v1197_4 = (has_head(v1197_3) ? constant_7 : Space{});
        const Space v1197_5 = subtract(constant_0,v1197_4);
        Space v1197_8;
        if (!v1197_5.empty()) {
          const Path v1198_6 = concat_path(v1196_6,v1196_11_head);
          const Space v1198_7 = routine_177(c, v1198_6, v1196_11_tail);
          v1197_8 = compose(v1197_5,v1198_7);
        }
        const Space v1197_9 = intersect(constant_6,v1197_2);
        const Space v1197_10 = (has_head(v1197_9) ? constant_7 : Space{});
        Space v1197_12;
        if (!v1197_10.empty()) {
          const Path v1199_6 = concat_path(v1196_6,v1196_11_head);
          const Space v1199_11 = routine_72(c, v1199_6, v1196_11_tail);
          v1197_12 = compose(v1197_10,v1199_11);
        }
        const Space v1197_13 = unite(v1197_8,v1197_12);
        v1196_11_result = unite(v1196_11_result,v1197_13);
      }
      const Space v1196_11 = std::move(v1196_11_result);
      v1191_12 = compose(v1191_10,v1196_11);
    }
    const Space v1191_13 = unite(v1191_8,v1191_12);
    v1190_11_result = unite(v1190_11_result,v1191_13);
  }
  const Space v1190_11 = std::move(v1190_11_result);
  return v1190_11;
}

static Space routine_128(Context& c, const Path& p0, const Space& s0) {
  Space v1200_9_result;
  for (int v1200_9_label = 1; v1200_9_label <= 2; ++v1200_9_label) {
    const Space v1200_9_tail = child(s0,v1200_9_label);
    if (v1200_9_tail.empty()) continue;
    const Path v1200_9_head{v1200_9_label};
    const Space v1201_2 = singleton(v1200_9_head);
    const Space v1201_3 = intersect(constant_6,v1201_2);
    const Space v1201_4 = (has_head(v1201_3) ? constant_7 : Space{});
    const Space v1201_5 = subtract(constant_0,v1201_4);
    Space v1201_8;
    if (!v1201_5.empty()) {
      const Path v1202_6 = concat_path(p0,v1200_9_head);
      Space v1202_7_result;
      for (int v1202_7_label = 1; v1202_7_label <= 2; ++v1202_7_label) {
        const Space v1202_7_tail = child(v1200_9_tail,v1202_7_label);
        if (v1202_7_tail.empty()) continue;
        const Path v1202_7_head{v1202_7_label};
        const Space v1203_2 = singleton(v1202_7_head);
        const Space v1203_3 = intersect(constant_6,v1203_2);
        const Space v1203_4 = (has_head(v1203_3) ? constant_7 : Space{});
        const Space v1203_5 = subtract(constant_0,v1203_4);
        Space v1203_8;
        if (!v1203_5.empty()) {
          const Path v1204_6 = concat_path(v1202_6,v1202_7_head);
          const Space v1204_7 = routine_177(c, v1204_6, v1202_7_tail);
          v1203_8 = compose(v1203_5,v1204_7);
        }
        const Space v1203_9 = intersect(constant_6,v1203_2);
        const Space v1203_10 = (has_head(v1203_9) ? constant_7 : Space{});
        Space v1203_12;
        if (!v1203_10.empty()) {
          const Path v1205_6 = concat_path(v1202_6,v1202_7_head);
          const Space v1205_11 = routine_178(c, v1205_6, v1202_7_tail);
          v1203_12 = compose(v1203_10,v1205_11);
        }
        const Space v1203_13 = unite(v1203_8,v1203_12);
        v1202_7_result = unite(v1202_7_result,v1203_13);
      }
      const Space v1202_7 = std::move(v1202_7_result);
      v1201_8 = compose(v1201_5,v1202_7);
    }
    const Space v1201_9 = intersect(constant_6,v1201_2);
    const Space v1201_10 = (has_head(v1201_9) ? constant_7 : Space{});
    const Space v1201_11 = compose(v1201_10,constant_9);
    const Space v1201_12 = unite(v1201_8,v1201_11);
    v1200_9_result = unite(v1200_9_result,v1201_12);
  }
  const Space v1200_9 = std::move(v1200_9_result);
  return v1200_9;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0) {
  Space v1206_11_result;
  for (int v1206_11_label = 1; v1206_11_label <= 2; ++v1206_11_label) {
    const Space v1206_11_tail = child(s0,v1206_11_label);
    if (v1206_11_tail.empty()) continue;
    const Path v1206_11_head{v1206_11_label};
    const Space v1207_2 = singleton(v1206_11_head);
    const Space v1207_3 = intersect(constant_6,v1207_2);
    const Space v1207_4 = (has_head(v1207_3) ? constant_7 : Space{});
    const Space v1207_5 = subtract(constant_0,v1207_4);
    Space v1207_8;
    if (!v1207_5.empty()) {
      const Path v1208_6 = concat_path(p0,v1206_11_head);
      Space v1208_7_result;
      for (int v1208_7_label = 1; v1208_7_label <= 2; ++v1208_7_label) {
        const Space v1208_7_tail = child(v1206_11_tail,v1208_7_label);
        if (v1208_7_tail.empty()) continue;
        const Path v1208_7_head{v1208_7_label};
        const Space v1209_2 = singleton(v1208_7_head);
        const Space v1209_3 = intersect(constant_6,v1209_2);
        const Space v1209_4 = (has_head(v1209_3) ? constant_7 : Space{});
        const Space v1209_5 = subtract(constant_0,v1209_4);
        Space v1209_8;
        if (!v1209_5.empty()) {
          const Path v1210_6 = concat_path(v1208_6,v1208_7_head);
          const Space v1210_7 = routine_179(c, v1210_6, v1208_7_tail);
          v1209_8 = compose(v1209_5,v1210_7);
        }
        const Space v1209_9 = intersect(constant_6,v1209_2);
        const Space v1209_10 = (has_head(v1209_9) ? constant_7 : Space{});
        Space v1209_12;
        if (!v1209_10.empty()) {
          const Path v1211_6 = concat_path(v1208_6,v1208_7_head);
          const Space v1211_11 = routine_180(c, v1211_6, v1208_7_tail);
          v1209_12 = compose(v1209_10,v1211_11);
        }
        const Space v1209_13 = unite(v1209_8,v1209_12);
        v1208_7_result = unite(v1208_7_result,v1209_13);
      }
      const Space v1208_7 = std::move(v1208_7_result);
      v1207_8 = compose(v1207_5,v1208_7);
    }
    const Space v1207_9 = intersect(constant_6,v1207_2);
    const Space v1207_10 = (has_head(v1207_9) ? constant_7 : Space{});
    Space v1207_12;
    if (!v1207_10.empty()) {
      const Path v1212_6 = concat_path(p0,v1206_11_head);
      Space v1212_11_result;
      for (int v1212_11_label = 1; v1212_11_label <= 2; ++v1212_11_label) {
        const Space v1212_11_tail = child(v1206_11_tail,v1212_11_label);
        if (v1212_11_tail.empty()) continue;
        const Path v1212_11_head{v1212_11_label};
        const Space v1213_2 = singleton(v1212_11_head);
        const Space v1213_3 = intersect(constant_6,v1213_2);
        const Space v1213_4 = (has_head(v1213_3) ? constant_7 : Space{});
        const Space v1213_5 = subtract(constant_0,v1213_4);
        Space v1213_8;
        if (!v1213_5.empty()) {
          const Path v1214_6 = concat_path(v1212_6,v1212_11_head);
          const Space v1214_7 = routine_179(c, v1214_6, v1212_11_tail);
          v1213_8 = compose(v1213_5,v1214_7);
        }
        const Space v1213_9 = intersect(constant_6,v1213_2);
        const Space v1213_10 = (has_head(v1213_9) ? constant_7 : Space{});
        Space v1213_12;
        if (!v1213_10.empty()) {
          const Path v1215_6 = concat_path(v1212_6,v1212_11_head);
          const Space v1215_11 = routine_75(c, v1215_6, v1212_11_tail);
          v1213_12 = compose(v1213_10,v1215_11);
        }
        const Space v1213_13 = unite(v1213_8,v1213_12);
        v1212_11_result = unite(v1212_11_result,v1213_13);
      }
      const Space v1212_11 = std::move(v1212_11_result);
      v1207_12 = compose(v1207_10,v1212_11);
    }
    const Space v1207_13 = unite(v1207_8,v1207_12);
    v1206_11_result = unite(v1206_11_result,v1207_13);
  }
  const Space v1206_11 = std::move(v1206_11_result);
  return v1206_11;
}

static Space routine_130(Context& c, const Path& p0, const Space& s0) {
  Space v1216_8_result;
  for (int v1216_8_label = 1; v1216_8_label <= 2; ++v1216_8_label) {
    const Space v1216_8_tail = child(s0,v1216_8_label);
    if (v1216_8_tail.empty()) continue;
    const Path v1216_8_head{v1216_8_label};
    const Space v1217_2 = singleton(v1216_8_head);
    const Space v1217_3 = intersect(constant_6,v1217_2);
    const Space v1217_4 = (has_head(v1217_3) ? constant_7 : Space{});
    const Space v1217_5 = subtract(constant_0,v1217_4);
    Space v1217_8;
    if (!v1217_5.empty()) {
      const Path v1218_6 = concat_path(p0,v1216_8_head);
      Space v1218_7_result;
      for (int v1218_7_label = 1; v1218_7_label <= 2; ++v1218_7_label) {
        const Space v1218_7_tail = child(v1216_8_tail,v1218_7_label);
        if (v1218_7_tail.empty()) continue;
        const Path v1218_7_head{v1218_7_label};
        const Space v1219_2 = singleton(v1218_7_head);
        const Space v1219_3 = intersect(constant_6,v1219_2);
        const Space v1219_4 = (has_head(v1219_3) ? constant_7 : Space{});
        const Space v1219_5 = subtract(constant_0,v1219_4);
        Space v1219_8;
        if (!v1219_5.empty()) {
          const Path v1220_6 = concat_path(v1218_6,v1218_7_head);
          const Space v1220_7 = routine_179(c, v1220_6, v1218_7_tail);
          v1219_8 = compose(v1219_5,v1220_7);
        }
        const Space v1219_9 = intersect(constant_6,v1219_2);
        const Space v1219_10 = (has_head(v1219_9) ? constant_7 : Space{});
        Space v1219_12;
        if (!v1219_10.empty()) {
          const Path v1221_6 = concat_path(v1218_6,v1218_7_head);
          const Space v1221_11 = routine_180(c, v1221_6, v1218_7_tail);
          v1219_12 = compose(v1219_10,v1221_11);
        }
        const Space v1219_13 = unite(v1219_8,v1219_12);
        v1218_7_result = unite(v1218_7_result,v1219_13);
      }
      const Space v1218_7 = std::move(v1218_7_result);
      v1217_8 = compose(v1217_5,v1218_7);
    }
    const Space v1217_9 = intersect(constant_6,v1217_2);
    const Space v1217_10 = (has_head(v1217_9) ? constant_7 : Space{});
    const Space v1217_11 = compose(v1217_10,v1216_8_tail);
    const Space v1217_12 = unite(v1217_8,v1217_11);
    v1216_8_result = unite(v1216_8_result,v1217_12);
  }
  const Space v1216_8 = std::move(v1216_8_result);
  return v1216_8;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1222_13_result;
  for (int v1222_13_label = 1; v1222_13_label <= 2; ++v1222_13_label) {
    const Space v1222_13_tail = child(s0,v1222_13_label);
    if (v1222_13_tail.empty()) continue;
    const Path v1222_13_head{v1222_13_label};
    const Space v1223_2 = singleton(v1222_13_head);
    const Space v1223_3 = intersect(constant_6,v1223_2);
    const Space v1223_4 = (has_head(v1223_3) ? constant_7 : Space{});
    const Space v1223_5 = subtract(constant_0,v1223_4);
    Space v1223_8;
    if (!v1223_5.empty()) {
      const Path v1224_6 = concat_path(p0,v1222_13_head);
      Space v1224_7_result;
      for (int v1224_7_label = 1; v1224_7_label <= 2; ++v1224_7_label) {
        const Space v1224_7_tail = child(v1222_13_tail,v1224_7_label);
        if (v1224_7_tail.empty()) continue;
        const Path v1224_7_head{v1224_7_label};
        const Space v1225_2 = singleton(v1224_7_head);
        const Space v1225_3 = intersect(constant_6,v1225_2);
        const Space v1225_4 = (has_head(v1225_3) ? constant_7 : Space{});
        const Space v1225_5 = subtract(constant_0,v1225_4);
        Space v1225_8;
        if (!v1225_5.empty()) {
          const Path v1226_6 = concat_path(v1224_6,v1224_7_head);
          const Space v1226_7 = routine_181(c, v1226_6, p1, v1224_7_tail, s1);
          v1225_8 = compose(v1225_5,v1226_7);
        }
        const Space v1225_9 = intersect(constant_6,v1225_2);
        const Space v1225_10 = (has_head(v1225_9) ? constant_7 : Space{});
        Space v1225_12;
        if (!v1225_10.empty()) {
          const Path v1227_6 = concat_path(v1224_6,v1224_7_head);
          const Space v1227_11 = routine_182(c, v1227_6, p1, v1224_7_tail, s1);
          v1225_12 = compose(v1225_10,v1227_11);
        }
        const Space v1225_13 = unite(v1225_8,v1225_12);
        v1224_7_result = unite(v1224_7_result,v1225_13);
      }
      const Space v1224_7 = std::move(v1224_7_result);
      v1223_8 = compose(v1223_5,v1224_7);
    }
    const Space v1223_9 = intersect(constant_6,v1223_2);
    const Space v1223_10 = (has_head(v1223_9) ? constant_7 : Space{});
    Space v1223_12;
    if (!v1223_10.empty()) {
      const Path v1228_6 = concat_path(p0,v1222_13_head);
      Space v1228_11_result;
      for (int v1228_11_label = 1; v1228_11_label <= 2; ++v1228_11_label) {
        const Space v1228_11_tail = child(v1222_13_tail,v1228_11_label);
        if (v1228_11_tail.empty()) continue;
        const Path v1228_11_head{v1228_11_label};
        const Space v1229_2 = singleton(v1228_11_head);
        const Space v1229_3 = intersect(constant_6,v1229_2);
        const Space v1229_4 = (has_head(v1229_3) ? constant_7 : Space{});
        const Space v1229_5 = subtract(constant_0,v1229_4);
        Space v1229_8;
        if (!v1229_5.empty()) {
          const Path v1230_6 = concat_path(v1228_6,v1228_11_head);
          const Space v1230_7 = routine_181(c, v1230_6, p1, v1228_11_tail, s1);
          v1229_8 = compose(v1229_5,v1230_7);
        }
        const Space v1229_9 = intersect(constant_6,v1229_2);
        const Space v1229_10 = (has_head(v1229_9) ? constant_7 : Space{});
        Space v1229_12;
        if (!v1229_10.empty()) {
          const Path v1231_6 = concat_path(v1228_6,v1228_11_head);
          const Space v1231_11 = routine_26(c, v1231_6, p1, v1228_11_tail, s1);
          v1229_12 = compose(v1229_10,v1231_11);
        }
        const Space v1229_13 = unite(v1229_8,v1229_12);
        v1228_11_result = unite(v1228_11_result,v1229_13);
      }
      const Space v1228_11 = std::move(v1228_11_result);
      v1223_12 = compose(v1223_10,v1228_11);
    }
    const Space v1223_13 = unite(v1223_8,v1223_12);
    v1222_13_result = unite(v1222_13_result,v1223_13);
  }
  const Space v1222_13 = std::move(v1222_13_result);
  return v1222_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1232_8 = unwrap(s1,constant_8);
  Space v1232_21_result;
  for (int v1232_21_label = 1; v1232_21_label <= 2; ++v1232_21_label) {
    const Space v1232_21_tail = child(s0,v1232_21_label);
    if (v1232_21_tail.empty()) continue;
    const Path v1232_21_head{v1232_21_label};
    const Space v1233_2 = singleton(v1232_21_head);
    const Space v1233_3 = intersect(constant_6,v1233_2);
    const Space v1233_4 = (has_head(v1233_3) ? constant_7 : Space{});
    const Space v1233_5 = subtract(constant_0,v1233_4);
    Space v1233_8;
    if (!v1233_5.empty()) {
      const Path v1234_6 = concat_path(p0,v1232_21_head);
      Space v1234_7_result;
      for (int v1234_7_label = 1; v1234_7_label <= 2; ++v1234_7_label) {
        const Space v1234_7_tail = child(v1232_21_tail,v1234_7_label);
        if (v1234_7_tail.empty()) continue;
        const Path v1234_7_head{v1234_7_label};
        const Space v1235_2 = singleton(v1234_7_head);
        const Space v1235_3 = intersect(constant_6,v1235_2);
        const Space v1235_4 = (has_head(v1235_3) ? constant_7 : Space{});
        const Space v1235_5 = subtract(constant_0,v1235_4);
        Space v1235_8;
        if (!v1235_5.empty()) {
          const Path v1236_6 = concat_path(v1234_6,v1234_7_head);
          const Space v1236_7 = routine_181(c, v1236_6, p1, v1234_7_tail, s1);
          v1235_8 = compose(v1235_5,v1236_7);
        }
        const Space v1235_9 = intersect(constant_6,v1235_2);
        const Space v1235_10 = (has_head(v1235_9) ? constant_7 : Space{});
        Space v1235_12;
        if (!v1235_10.empty()) {
          const Path v1237_6 = concat_path(v1234_6,v1234_7_head);
          const Space v1237_11 = routine_182(c, v1237_6, p1, v1234_7_tail, s1);
          v1235_12 = compose(v1235_10,v1237_11);
        }
        const Space v1235_13 = unite(v1235_8,v1235_12);
        v1234_7_result = unite(v1234_7_result,v1235_13);
      }
      const Space v1234_7 = std::move(v1234_7_result);
      v1233_8 = compose(v1233_5,v1234_7);
    }
    const Space v1233_9 = intersect(constant_6,v1233_2);
    const Space v1233_10 = (has_head(v1233_9) ? constant_7 : Space{});
    Space v1233_22;
    if (!v1233_10.empty()) {
      const Path v1238_6 = concat_path(p0,v1232_21_head);
      const Path v1238_11 = concat_path(p1,v1238_6);
      const Space v1238_12 = routine_29(c, v1238_11);
      const Space v1238_13 = intersect(v1232_8,v1238_12);
      const Space v1238_14 = routine_30(c, v1238_13);
      Space v1238_15_result;
      for (int v1238_15_label = 1; v1238_15_label <= 2; ++v1238_15_label) {
        const Space v1238_15_tail = child(v1238_14,v1238_15_label);
        if (v1238_15_tail.empty()) continue;
        const Path v1238_15_head{v1238_15_label};
        const Space v1239_2 = singleton(v1238_15_head);
        const Space v1239_3 = intersect(constant_6,v1239_2);
        const Space v1239_4 = (has_head(v1239_3) ? constant_7 : Space{});
        const Space v1239_5 = subtract(constant_0,v1239_4);
        Space v1239_7;
        if (!v1239_5.empty()) {
          const Space v1240_6 = routine_31(c, v1238_15_head, v1238_15_tail);
          v1239_7 = compose(v1239_5,v1240_6);
        }
        const Space v1239_8 = intersect(constant_6,v1239_2);
        const Space v1239_9 = (has_head(v1239_8) ? constant_7 : Space{});
        Space v1239_11;
        if (!v1239_9.empty()) {
          const Space v1241_10 = routine_32(c, v1238_15_head, v1238_15_tail);
          v1239_11 = compose(v1239_9,v1241_10);
        }
        const Space v1239_12 = unite(v1239_7,v1239_11);
        v1238_15_result = unite(v1238_15_result,v1239_12);
      }
      const Space v1238_15 = std::move(v1238_15_result);
      const Space v1238_16 = routine_33(c, v1238_13);
      Space v1238_17_result;
      for (int v1238_17_label = 1; v1238_17_label <= 2; ++v1238_17_label) {
        const Space v1238_17_tail = child(v1238_16,v1238_17_label);
        if (v1238_17_tail.empty()) continue;
        const Path v1238_17_head{v1238_17_label};
        const Space v1242_2 = singleton(v1238_17_head);
        const Space v1242_3 = intersect(constant_6,v1242_2);
        const Space v1242_4 = (has_head(v1242_3) ? constant_7 : Space{});
        const Space v1242_5 = subtract(constant_0,v1242_4);
        Space v1242_7;
        if (!v1242_5.empty()) {
          const Space v1243_6 = routine_34(c, v1238_17_head, v1238_17_tail);
          v1242_7 = compose(v1242_5,v1243_6);
        }
        const Space v1242_8 = intersect(constant_6,v1242_2);
        const Space v1242_9 = (has_head(v1242_8) ? constant_7 : Space{});
        Space v1242_11;
        if (!v1242_9.empty()) {
          const Space v1244_10 = routine_35(c, v1238_17_head, v1238_17_tail);
          v1242_11 = compose(v1242_9,v1244_10);
        }
        const Space v1242_12 = unite(v1242_7,v1242_11);
        v1238_17_result = unite(v1238_17_result,v1242_12);
      }
      const Space v1238_17 = std::move(v1238_17_result);
      const Space v1238_18 = subtract(v1238_15,v1238_17);
      const Space v1238_19 = singleton(v1238_11);
      const Space v1238_20 = compose(v1238_18,v1238_19);
      Space v1238_21_result;
      for (int v1238_21_label = 1; v1238_21_label <= 2; ++v1238_21_label) {
        const Space v1238_21_tail = child(v1238_20,v1238_21_label);
        if (v1238_21_tail.empty()) continue;
        const Path v1238_21_head{v1238_21_label};
        const Space v1245_2 = singleton(v1238_21_head);
        const Space v1245_3 = intersect(constant_6,v1245_2);
        const Space v1245_4 = (has_head(v1245_3) ? constant_7 : Space{});
        const Space v1245_5 = subtract(constant_0,v1245_4);
        Space v1245_7;
        if (!v1245_5.empty()) {
          const Space v1246_6 = routine_36(c, v1238_21_head, v1238_21_tail);
          v1245_7 = compose(v1245_5,v1246_6);
        }
        const Space v1245_8 = intersect(constant_6,v1245_2);
        const Space v1245_9 = (has_head(v1245_8) ? constant_7 : Space{});
        Space v1245_11;
        if (!v1245_9.empty()) {
          const Space v1247_10 = routine_37(c, v1238_21_head, v1238_21_tail);
          v1245_11 = compose(v1245_9,v1247_10);
        }
        const Space v1245_12 = unite(v1245_7,v1245_11);
        v1238_21_result = unite(v1238_21_result,v1245_12);
      }
      const Space v1238_21 = std::move(v1238_21_result);
      v1233_22 = compose(v1233_10,v1238_21);
    }
    const Space v1233_23 = unite(v1233_8,v1233_22);
    v1232_21_result = unite(v1232_21_result,v1233_23);
  }
  const Space v1232_21 = std::move(v1232_21_result);
  return v1232_21;
}

static Space routine_133(Context& c, const Path& p0, const Space& s0) {
  Space v1248_11_result;
  for (int v1248_11_label = 1; v1248_11_label <= 2; ++v1248_11_label) {
    const Space v1248_11_tail = child(s0,v1248_11_label);
    if (v1248_11_tail.empty()) continue;
    const Path v1248_11_head{v1248_11_label};
    const Space v1249_2 = singleton(v1248_11_head);
    const Space v1249_3 = intersect(constant_6,v1249_2);
    const Space v1249_4 = (has_head(v1249_3) ? constant_7 : Space{});
    const Space v1249_5 = subtract(constant_0,v1249_4);
    Space v1249_8;
    if (!v1249_5.empty()) {
      const Path v1250_6 = concat_path(p0,v1248_11_head);
      Space v1250_7_result;
      for (int v1250_7_label = 1; v1250_7_label <= 2; ++v1250_7_label) {
        const Space v1250_7_tail = child(v1248_11_tail,v1250_7_label);
        if (v1250_7_tail.empty()) continue;
        const Path v1250_7_head{v1250_7_label};
        const Space v1251_2 = singleton(v1250_7_head);
        const Space v1251_3 = intersect(constant_6,v1251_2);
        const Space v1251_4 = (has_head(v1251_3) ? constant_7 : Space{});
        const Space v1251_5 = subtract(constant_0,v1251_4);
        Space v1251_8;
        if (!v1251_5.empty()) {
          const Path v1252_6 = concat_path(v1250_6,v1250_7_head);
          const Space v1252_7 = routine_183(c, v1252_6, v1250_7_tail);
          v1251_8 = compose(v1251_5,v1252_7);
        }
        const Space v1251_9 = intersect(constant_6,v1251_2);
        const Space v1251_10 = (has_head(v1251_9) ? constant_7 : Space{});
        Space v1251_12;
        if (!v1251_10.empty()) {
          const Path v1253_6 = concat_path(v1250_6,v1250_7_head);
          const Space v1253_11 = routine_184(c, v1253_6, v1250_7_tail);
          v1251_12 = compose(v1251_10,v1253_11);
        }
        const Space v1251_13 = unite(v1251_8,v1251_12);
        v1250_7_result = unite(v1250_7_result,v1251_13);
      }
      const Space v1250_7 = std::move(v1250_7_result);
      v1249_8 = compose(v1249_5,v1250_7);
    }
    const Space v1249_9 = intersect(constant_6,v1249_2);
    const Space v1249_10 = (has_head(v1249_9) ? constant_7 : Space{});
    Space v1249_12;
    if (!v1249_10.empty()) {
      const Path v1254_6 = concat_path(p0,v1248_11_head);
      Space v1254_11_result;
      for (int v1254_11_label = 1; v1254_11_label <= 2; ++v1254_11_label) {
        const Space v1254_11_tail = child(v1248_11_tail,v1254_11_label);
        if (v1254_11_tail.empty()) continue;
        const Path v1254_11_head{v1254_11_label};
        const Space v1255_2 = singleton(v1254_11_head);
        const Space v1255_3 = intersect(constant_6,v1255_2);
        const Space v1255_4 = (has_head(v1255_3) ? constant_7 : Space{});
        const Space v1255_5 = subtract(constant_0,v1255_4);
        Space v1255_8;
        if (!v1255_5.empty()) {
          const Path v1256_6 = concat_path(v1254_6,v1254_11_head);
          const Space v1256_7 = routine_183(c, v1256_6, v1254_11_tail);
          v1255_8 = compose(v1255_5,v1256_7);
        }
        const Space v1255_9 = intersect(constant_6,v1255_2);
        const Space v1255_10 = (has_head(v1255_9) ? constant_7 : Space{});
        Space v1255_12;
        if (!v1255_10.empty()) {
          const Path v1257_6 = concat_path(v1254_6,v1254_11_head);
          const Space v1257_11 = routine_80(c, v1257_6, v1254_11_tail);
          v1255_12 = compose(v1255_10,v1257_11);
        }
        const Space v1255_13 = unite(v1255_8,v1255_12);
        v1254_11_result = unite(v1254_11_result,v1255_13);
      }
      const Space v1254_11 = std::move(v1254_11_result);
      v1249_12 = compose(v1249_10,v1254_11);
    }
    const Space v1249_13 = unite(v1249_8,v1249_12);
    v1248_11_result = unite(v1248_11_result,v1249_13);
  }
  const Space v1248_11 = std::move(v1248_11_result);
  return v1248_11;
}

static Space routine_134(Context& c, const Path& p0, const Space& s0) {
  Space v1258_11_result;
  for (int v1258_11_label = 1; v1258_11_label <= 2; ++v1258_11_label) {
    const Space v1258_11_tail = child(s0,v1258_11_label);
    if (v1258_11_tail.empty()) continue;
    const Path v1258_11_head{v1258_11_label};
    const Space v1259_2 = singleton(v1258_11_head);
    const Space v1259_3 = intersect(constant_6,v1259_2);
    const Space v1259_4 = (has_head(v1259_3) ? constant_7 : Space{});
    const Space v1259_5 = subtract(constant_0,v1259_4);
    Space v1259_8;
    if (!v1259_5.empty()) {
      const Path v1260_6 = concat_path(p0,v1258_11_head);
      Space v1260_7_result;
      for (int v1260_7_label = 1; v1260_7_label <= 2; ++v1260_7_label) {
        const Space v1260_7_tail = child(v1258_11_tail,v1260_7_label);
        if (v1260_7_tail.empty()) continue;
        const Path v1260_7_head{v1260_7_label};
        const Space v1261_2 = singleton(v1260_7_head);
        const Space v1261_3 = intersect(constant_6,v1261_2);
        const Space v1261_4 = (has_head(v1261_3) ? constant_7 : Space{});
        const Space v1261_5 = subtract(constant_0,v1261_4);
        Space v1261_8;
        if (!v1261_5.empty()) {
          const Path v1262_6 = concat_path(v1260_6,v1260_7_head);
          const Space v1262_7 = routine_183(c, v1262_6, v1260_7_tail);
          v1261_8 = compose(v1261_5,v1262_7);
        }
        const Space v1261_9 = intersect(constant_6,v1261_2);
        const Space v1261_10 = (has_head(v1261_9) ? constant_7 : Space{});
        Space v1261_12;
        if (!v1261_10.empty()) {
          const Path v1263_6 = concat_path(v1260_6,v1260_7_head);
          const Space v1263_11 = routine_184(c, v1263_6, v1260_7_tail);
          v1261_12 = compose(v1261_10,v1263_11);
        }
        const Space v1261_13 = unite(v1261_8,v1261_12);
        v1260_7_result = unite(v1260_7_result,v1261_13);
      }
      const Space v1260_7 = std::move(v1260_7_result);
      v1259_8 = compose(v1259_5,v1260_7);
    }
    const Space v1259_9 = intersect(constant_6,v1259_2);
    const Space v1259_10 = (has_head(v1259_9) ? constant_7 : Space{});
    Space v1259_12;
    if (!v1259_10.empty()) {
      const Path v1264_6 = concat_path(p0,v1258_11_head);
      Space v1264_11_result;
      for (int v1264_11_label = 1; v1264_11_label <= 2; ++v1264_11_label) {
        const Space v1264_11_tail = child(v1258_11_tail,v1264_11_label);
        if (v1264_11_tail.empty()) continue;
        const Path v1264_11_head{v1264_11_label};
        const Space v1265_2 = singleton(v1264_11_head);
        const Space v1265_3 = intersect(constant_6,v1265_2);
        const Space v1265_4 = (has_head(v1265_3) ? constant_7 : Space{});
        const Space v1265_5 = subtract(constant_0,v1265_4);
        Space v1265_7;
        if (!v1265_5.empty()) {
          const Space v1266_6 = routine_122(c, v1264_11_head, v1264_6, v1264_11_tail);
          v1265_7 = compose(v1265_5,v1266_6);
        }
        const Space v1265_8 = intersect(constant_6,v1265_2);
        const Space v1265_9 = (has_head(v1265_8) ? constant_7 : Space{});
        Space v1265_11;
        if (!v1265_9.empty()) {
          const Space v1267_10 = routine_123(c, v1264_11_head, v1264_6, v1264_11_tail);
          v1265_11 = compose(v1265_9,v1267_10);
        }
        const Space v1265_12 = unite(v1265_7,v1265_11);
        v1264_11_result = unite(v1264_11_result,v1265_12);
      }
      const Space v1264_11 = std::move(v1264_11_result);
      v1259_12 = compose(v1259_10,v1264_11);
    }
    const Space v1259_13 = unite(v1259_8,v1259_12);
    v1258_11_result = unite(v1258_11_result,v1259_13);
  }
  const Space v1258_11 = std::move(v1258_11_result);
  return v1258_11;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1268_12_result;
  for (int v1268_12_label = 1; v1268_12_label <= 2; ++v1268_12_label) {
    const Space v1268_12_tail = child(s0,v1268_12_label);
    if (v1268_12_tail.empty()) continue;
    const Path v1268_12_head{v1268_12_label};
    const Space v1269_2 = singleton(v1268_12_head);
    const Space v1269_3 = intersect(constant_6,v1269_2);
    const Space v1269_4 = (has_head(v1269_3) ? constant_7 : Space{});
    const Space v1269_5 = subtract(constant_0,v1269_4);
    Space v1269_8;
    if (!v1269_5.empty()) {
      const Path v1270_6 = concat_path(p0,v1268_12_head);
      Space v1270_7_result;
      for (int v1270_7_label = 1; v1270_7_label <= 2; ++v1270_7_label) {
        const Space v1270_7_tail = child(v1268_12_tail,v1270_7_label);
        if (v1270_7_tail.empty()) continue;
        const Path v1270_7_head{v1270_7_label};
        const Space v1271_2 = singleton(v1270_7_head);
        const Space v1271_3 = intersect(constant_6,v1271_2);
        const Space v1271_4 = (has_head(v1271_3) ? constant_7 : Space{});
        const Space v1271_5 = subtract(constant_0,v1271_4);
        Space v1271_8;
        if (!v1271_5.empty()) {
          const Path v1272_6 = concat_path(v1270_6,v1270_7_head);
          const Space v1272_7 = routine_185(c, v1272_6, p1, v1270_7_tail);
          v1271_8 = compose(v1271_5,v1272_7);
        }
        const Space v1271_9 = intersect(constant_6,v1271_2);
        const Space v1271_10 = (has_head(v1271_9) ? constant_7 : Space{});
        Space v1271_12;
        if (!v1271_10.empty()) {
          const Path v1273_6 = concat_path(v1270_6,v1270_7_head);
          const Space v1273_11 = routine_186(c, v1273_6, p1, v1270_7_tail);
          v1271_12 = compose(v1271_10,v1273_11);
        }
        const Space v1271_13 = unite(v1271_8,v1271_12);
        v1270_7_result = unite(v1270_7_result,v1271_13);
      }
      const Space v1270_7 = std::move(v1270_7_result);
      v1269_8 = compose(v1269_5,v1270_7);
    }
    const Space v1269_9 = intersect(constant_6,v1269_2);
    const Space v1269_10 = (has_head(v1269_9) ? constant_7 : Space{});
    Space v1269_12;
    if (!v1269_10.empty()) {
      const Path v1274_6 = concat_path(p0,v1268_12_head);
      Space v1274_11_result;
      for (int v1274_11_label = 1; v1274_11_label <= 2; ++v1274_11_label) {
        const Space v1274_11_tail = child(v1268_12_tail,v1274_11_label);
        if (v1274_11_tail.empty()) continue;
        const Path v1274_11_head{v1274_11_label};
        const Space v1275_2 = singleton(v1274_11_head);
        const Space v1275_3 = intersect(constant_6,v1275_2);
        const Space v1275_4 = (has_head(v1275_3) ? constant_7 : Space{});
        const Space v1275_5 = subtract(constant_0,v1275_4);
        Space v1275_8;
        if (!v1275_5.empty()) {
          const Path v1276_6 = concat_path(v1274_6,v1274_11_head);
          const Space v1276_7 = routine_185(c, v1276_6, p1, v1274_11_tail);
          v1275_8 = compose(v1275_5,v1276_7);
        }
        const Space v1275_9 = intersect(constant_6,v1275_2);
        const Space v1275_10 = (has_head(v1275_9) ? constant_7 : Space{});
        Space v1275_12;
        if (!v1275_10.empty()) {
          const Path v1277_6 = concat_path(v1274_6,v1274_11_head);
          const Space v1277_11 = routine_137(c, v1277_6, p1, v1274_11_tail);
          v1275_12 = compose(v1275_10,v1277_11);
        }
        const Space v1275_13 = unite(v1275_8,v1275_12);
        v1274_11_result = unite(v1274_11_result,v1275_13);
      }
      const Space v1274_11 = std::move(v1274_11_result);
      v1269_12 = compose(v1269_10,v1274_11);
    }
    const Space v1269_13 = unite(v1269_8,v1269_12);
    v1268_12_result = unite(v1268_12_result,v1269_13);
  }
  const Space v1268_12 = std::move(v1268_12_result);
  return v1268_12;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1278_7 = unwrap(constant_12,p1);
  const Space v1278_9 = unwrap(constant_12,p0);
  Space v1278_13_result;
  for (int v1278_13_label = 1; v1278_13_label <= 2; ++v1278_13_label) {
    const Space v1278_13_tail = child(s0,v1278_13_label);
    if (v1278_13_tail.empty()) continue;
    const Path v1278_13_head{v1278_13_label};
    const Space v1279_2 = singleton(v1278_13_head);
    const Space v1279_3 = intersect(constant_6,v1279_2);
    const Space v1279_4 = (has_head(v1279_3) ? constant_7 : Space{});
    const Space v1279_5 = subtract(constant_0,v1279_4);
    Space v1279_8;
    if (!v1279_5.empty()) {
      const Path v1280_6 = concat_path(p0,v1278_13_head);
      Space v1280_7_result;
      for (int v1280_7_label = 1; v1280_7_label <= 2; ++v1280_7_label) {
        const Space v1280_7_tail = child(v1278_13_tail,v1280_7_label);
        if (v1280_7_tail.empty()) continue;
        const Path v1280_7_head{v1280_7_label};
        const Space v1281_2 = singleton(v1280_7_head);
        const Space v1281_3 = intersect(constant_6,v1281_2);
        const Space v1281_4 = (has_head(v1281_3) ? constant_7 : Space{});
        const Space v1281_5 = subtract(constant_0,v1281_4);
        Space v1281_8;
        if (!v1281_5.empty()) {
          const Path v1282_6 = concat_path(v1280_6,v1280_7_head);
          const Space v1282_7 = routine_185(c, v1282_6, p1, v1280_7_tail);
          v1281_8 = compose(v1281_5,v1282_7);
        }
        const Space v1281_9 = intersect(constant_6,v1281_2);
        const Space v1281_10 = (has_head(v1281_9) ? constant_7 : Space{});
        Space v1281_12;
        if (!v1281_10.empty()) {
          const Path v1283_6 = concat_path(v1280_6,v1280_7_head);
          const Space v1283_11 = routine_186(c, v1283_6, p1, v1280_7_tail);
          v1281_12 = compose(v1281_10,v1283_11);
        }
        const Space v1281_13 = unite(v1281_8,v1281_12);
        v1280_7_result = unite(v1280_7_result,v1281_13);
      }
      const Space v1280_7 = std::move(v1280_7_result);
      v1279_8 = compose(v1279_5,v1280_7);
    }
    const Space v1279_9 = intersect(constant_6,v1279_2);
    const Space v1279_10 = (has_head(v1279_9) ? constant_7 : Space{});
    const Space v1279_11 = unwrap(v1278_9,v1278_13_head);
    const Space v1279_12 = compose(v1278_7,v1279_11);
    const Path v1284_6 = concat_path(p0,v1278_13_head);
    const Path v1279_13 = concat_path(p1,v1284_6);
    const Space v1279_14 = singleton(v1279_13);
    const Space v1279_15 = subtract(v1279_12,v1279_14);
    const Space v1279_16 = compose(v1279_10,v1279_15);
    const Space v1279_17 = unite(v1279_8,v1279_16);
    v1278_13_result = unite(v1278_13_result,v1279_17);
  }
  const Space v1278_13 = std::move(v1278_13_result);
  return v1278_13;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1285_4 = unwrap(constant_12,p1);
  const Space v1285_6 = unwrap(constant_12,p0);
  const Space v1285_7 = compose(v1285_4,v1285_6);
  const Path v1285_8 = concat_path(p1,p0);
  const Space v1285_9 = singleton(v1285_8);
  const Space v1285_10 = subtract(v1285_7,v1285_9);
  return v1285_10;
}

static Space routine_138(Context& c, const Path& p0, const Space& s0) {
  const Space v1286_3 = unwrap(s0,p0);
  const Space v1286_4 = first_matching(v1286_3,constant_0,false);
  const Space v1286_5 = intersect(constant_0,v1286_4);
  const Space v1286_6 = (has_head(v1286_4) ? constant_7 : Space{});
  const Space v1286_7 = unite(v1286_5,v1286_6);
  const Space v1286_9 = compose(v1286_7,constant_0);
  const Space v1286_11 = subtract(constant_0,v1286_4);
  const Space v1286_12 = subtract(v1286_11,v1286_6);
  Space v1286_16;
  if (!v1286_12.empty()) {
    const Space v1287_14 = first_listed(v1286_3,constant_11,true);
    const Space v1287_15 = routine_124(c, constant_10, v1287_14, v1286_3);
    v1286_16 = compose(v1286_12,v1287_15);
  }
  const Space v1286_17 = unite(v1286_9,v1286_16);
  const Space v1286_18 = wrap(v1286_17,p0);
  return v1286_18;
}

static Space routine_139(Context& c, const Path& p0, const Space& s0) {
  Space v1288_11_result;
  for (int v1288_11_label = 1; v1288_11_label <= 2; ++v1288_11_label) {
    const Space v1288_11_tail = child(s0,v1288_11_label);
    if (v1288_11_tail.empty()) continue;
    const Path v1288_11_head{v1288_11_label};
    const Space v1289_2 = singleton(v1288_11_head);
    const Space v1289_3 = intersect(constant_6,v1289_2);
    const Space v1289_4 = (has_head(v1289_3) ? constant_7 : Space{});
    const Space v1289_5 = subtract(constant_0,v1289_4);
    Space v1289_8;
    if (!v1289_5.empty()) {
      const Path v1290_6 = concat_path(p0,v1288_11_head);
      Space v1290_7_result;
      for (int v1290_7_label = 1; v1290_7_label <= 2; ++v1290_7_label) {
        const Space v1290_7_tail = child(v1288_11_tail,v1290_7_label);
        if (v1290_7_tail.empty()) continue;
        const Path v1290_7_head{v1290_7_label};
        const Space v1291_2 = singleton(v1290_7_head);
        const Space v1291_3 = intersect(constant_6,v1291_2);
        const Space v1291_4 = (has_head(v1291_3) ? constant_7 : Space{});
        const Space v1291_5 = subtract(constant_0,v1291_4);
        Space v1291_8;
        if (!v1291_5.empty()) {
          const Path v1292_6 = concat_path(v1290_6,v1290_7_head);
          const Space v1292_7 = routine_187(c, v1292_6, v1290_7_tail);
          v1291_8 = compose(v1291_5,v1292_7);
        }
        const Space v1291_9 = intersect(constant_6,v1291_2);
        const Space v1291_10 = (has_head(v1291_9) ? constant_7 : Space{});
        Space v1291_12;
        if (!v1291_10.empty()) {
          const Path v1293_6 = concat_path(v1290_6,v1290_7_head);
          const Space v1293_11 = routine_188(c, v1293_6, v1290_7_tail);
          v1291_12 = compose(v1291_10,v1293_11);
        }
        const Space v1291_13 = unite(v1291_8,v1291_12);
        v1290_7_result = unite(v1290_7_result,v1291_13);
      }
      const Space v1290_7 = std::move(v1290_7_result);
      v1289_8 = compose(v1289_5,v1290_7);
    }
    const Space v1289_9 = intersect(constant_6,v1289_2);
    const Space v1289_10 = (has_head(v1289_9) ? constant_7 : Space{});
    Space v1289_12;
    if (!v1289_10.empty()) {
      const Path v1294_6 = concat_path(p0,v1288_11_head);
      Space v1294_11_result;
      for (int v1294_11_label = 1; v1294_11_label <= 2; ++v1294_11_label) {
        const Space v1294_11_tail = child(v1288_11_tail,v1294_11_label);
        if (v1294_11_tail.empty()) continue;
        const Path v1294_11_head{v1294_11_label};
        const Space v1295_2 = singleton(v1294_11_head);
        const Space v1295_3 = intersect(constant_6,v1295_2);
        const Space v1295_4 = (has_head(v1295_3) ? constant_7 : Space{});
        const Space v1295_5 = subtract(constant_0,v1295_4);
        Space v1295_8;
        if (!v1295_5.empty()) {
          const Path v1296_6 = concat_path(v1294_6,v1294_11_head);
          const Space v1296_7 = routine_187(c, v1296_6, v1294_11_tail);
          v1295_8 = compose(v1295_5,v1296_7);
        }
        const Space v1295_9 = intersect(constant_6,v1295_2);
        const Space v1295_10 = (has_head(v1295_9) ? constant_7 : Space{});
        Space v1295_12;
        if (!v1295_10.empty()) {
          const Path v1297_6 = concat_path(v1294_6,v1294_11_head);
          const Space v1297_11 = routine_69(c, v1297_6, v1294_11_tail);
          v1295_12 = compose(v1295_10,v1297_11);
        }
        const Space v1295_13 = unite(v1295_8,v1295_12);
        v1294_11_result = unite(v1294_11_result,v1295_13);
      }
      const Space v1294_11 = std::move(v1294_11_result);
      v1289_12 = compose(v1289_10,v1294_11);
    }
    const Space v1289_13 = unite(v1289_8,v1289_12);
    v1288_11_result = unite(v1288_11_result,v1289_13);
  }
  const Space v1288_11 = std::move(v1288_11_result);
  return v1288_11;
}

static Space routine_140(Context& c, const Path& p0, const Space& s0) {
  Space v1298_9_result;
  for (int v1298_9_label = 1; v1298_9_label <= 2; ++v1298_9_label) {
    const Space v1298_9_tail = child(s0,v1298_9_label);
    if (v1298_9_tail.empty()) continue;
    const Path v1298_9_head{v1298_9_label};
    const Space v1299_2 = singleton(v1298_9_head);
    const Space v1299_3 = intersect(constant_6,v1299_2);
    const Space v1299_4 = (has_head(v1299_3) ? constant_7 : Space{});
    const Space v1299_5 = subtract(constant_0,v1299_4);
    Space v1299_8;
    if (!v1299_5.empty()) {
      const Path v1300_6 = concat_path(p0,v1298_9_head);
      Space v1300_7_result;
      for (int v1300_7_label = 1; v1300_7_label <= 2; ++v1300_7_label) {
        const Space v1300_7_tail = child(v1298_9_tail,v1300_7_label);
        if (v1300_7_tail.empty()) continue;
        const Path v1300_7_head{v1300_7_label};
        const Space v1301_2 = singleton(v1300_7_head);
        const Space v1301_3 = intersect(constant_6,v1301_2);
        const Space v1301_4 = (has_head(v1301_3) ? constant_7 : Space{});
        const Space v1301_5 = subtract(constant_0,v1301_4);
        Space v1301_8;
        if (!v1301_5.empty()) {
          const Path v1302_6 = concat_path(v1300_6,v1300_7_head);
          const Space v1302_7 = routine_187(c, v1302_6, v1300_7_tail);
          v1301_8 = compose(v1301_5,v1302_7);
        }
        const Space v1301_9 = intersect(constant_6,v1301_2);
        const Space v1301_10 = (has_head(v1301_9) ? constant_7 : Space{});
        Space v1301_12;
        if (!v1301_10.empty()) {
          const Path v1303_6 = concat_path(v1300_6,v1300_7_head);
          const Space v1303_11 = routine_188(c, v1303_6, v1300_7_tail);
          v1301_12 = compose(v1301_10,v1303_11);
        }
        const Space v1301_13 = unite(v1301_8,v1301_12);
        v1300_7_result = unite(v1300_7_result,v1301_13);
      }
      const Space v1300_7 = std::move(v1300_7_result);
      v1299_8 = compose(v1299_5,v1300_7);
    }
    const Space v1299_9 = intersect(constant_6,v1299_2);
    const Space v1299_10 = (has_head(v1299_9) ? constant_7 : Space{});
    const Space v1299_11 = compose(v1299_10,constant_9);
    const Space v1299_12 = unite(v1299_8,v1299_11);
    v1298_9_result = unite(v1298_9_result,v1299_12);
  }
  const Space v1298_9 = std::move(v1298_9_result);
  return v1298_9;
}

static Space routine_141(Context& c, const Path& p0, const Space& s0) {
  Space v1304_11_result;
  for (int v1304_11_label = 1; v1304_11_label <= 2; ++v1304_11_label) {
    const Space v1304_11_tail = child(s0,v1304_11_label);
    if (v1304_11_tail.empty()) continue;
    const Path v1304_11_head{v1304_11_label};
    const Space v1305_2 = singleton(v1304_11_head);
    const Space v1305_3 = intersect(constant_6,v1305_2);
    const Space v1305_4 = (has_head(v1305_3) ? constant_7 : Space{});
    const Space v1305_5 = subtract(constant_0,v1305_4);
    Space v1305_8;
    if (!v1305_5.empty()) {
      const Path v1306_6 = concat_path(p0,v1304_11_head);
      Space v1306_7_result;
      for (int v1306_7_label = 1; v1306_7_label <= 2; ++v1306_7_label) {
        const Space v1306_7_tail = child(v1304_11_tail,v1306_7_label);
        if (v1306_7_tail.empty()) continue;
        const Path v1306_7_head{v1306_7_label};
        const Space v1307_2 = singleton(v1306_7_head);
        const Space v1307_3 = intersect(constant_6,v1307_2);
        const Space v1307_4 = (has_head(v1307_3) ? constant_7 : Space{});
        const Space v1307_5 = subtract(constant_0,v1307_4);
        Space v1307_8;
        if (!v1307_5.empty()) {
          const Path v1308_6 = concat_path(v1306_6,v1306_7_head);
          const Space v1308_7 = routine_189(c, v1308_6, v1306_7_tail);
          v1307_8 = compose(v1307_5,v1308_7);
        }
        const Space v1307_9 = intersect(constant_6,v1307_2);
        const Space v1307_10 = (has_head(v1307_9) ? constant_7 : Space{});
        Space v1307_12;
        if (!v1307_10.empty()) {
          const Path v1309_6 = concat_path(v1306_6,v1306_7_head);
          const Space v1309_11 = routine_190(c, v1309_6, v1306_7_tail);
          v1307_12 = compose(v1307_10,v1309_11);
        }
        const Space v1307_13 = unite(v1307_8,v1307_12);
        v1306_7_result = unite(v1306_7_result,v1307_13);
      }
      const Space v1306_7 = std::move(v1306_7_result);
      v1305_8 = compose(v1305_5,v1306_7);
    }
    const Space v1305_9 = intersect(constant_6,v1305_2);
    const Space v1305_10 = (has_head(v1305_9) ? constant_7 : Space{});
    Space v1305_12;
    if (!v1305_10.empty()) {
      const Path v1310_6 = concat_path(p0,v1304_11_head);
      Space v1310_11_result;
      for (int v1310_11_label = 1; v1310_11_label <= 2; ++v1310_11_label) {
        const Space v1310_11_tail = child(v1304_11_tail,v1310_11_label);
        if (v1310_11_tail.empty()) continue;
        const Path v1310_11_head{v1310_11_label};
        const Space v1311_2 = singleton(v1310_11_head);
        const Space v1311_3 = intersect(constant_6,v1311_2);
        const Space v1311_4 = (has_head(v1311_3) ? constant_7 : Space{});
        const Space v1311_5 = subtract(constant_0,v1311_4);
        Space v1311_8;
        if (!v1311_5.empty()) {
          const Path v1312_6 = concat_path(v1310_6,v1310_11_head);
          const Space v1312_7 = routine_189(c, v1312_6, v1310_11_tail);
          v1311_8 = compose(v1311_5,v1312_7);
        }
        const Space v1311_9 = intersect(constant_6,v1311_2);
        const Space v1311_10 = (has_head(v1311_9) ? constant_7 : Space{});
        Space v1311_12;
        if (!v1311_10.empty()) {
          const Path v1313_6 = concat_path(v1310_6,v1310_11_head);
          const Space v1313_11 = routine_72(c, v1313_6, v1310_11_tail);
          v1311_12 = compose(v1311_10,v1313_11);
        }
        const Space v1311_13 = unite(v1311_8,v1311_12);
        v1310_11_result = unite(v1310_11_result,v1311_13);
      }
      const Space v1310_11 = std::move(v1310_11_result);
      v1305_12 = compose(v1305_10,v1310_11);
    }
    const Space v1305_13 = unite(v1305_8,v1305_12);
    v1304_11_result = unite(v1304_11_result,v1305_13);
  }
  const Space v1304_11 = std::move(v1304_11_result);
  return v1304_11;
}

static Space routine_142(Context& c, const Path& p0, const Space& s0) {
  Space v1314_9_result;
  for (int v1314_9_label = 1; v1314_9_label <= 2; ++v1314_9_label) {
    const Space v1314_9_tail = child(s0,v1314_9_label);
    if (v1314_9_tail.empty()) continue;
    const Path v1314_9_head{v1314_9_label};
    const Space v1315_2 = singleton(v1314_9_head);
    const Space v1315_3 = intersect(constant_6,v1315_2);
    const Space v1315_4 = (has_head(v1315_3) ? constant_7 : Space{});
    const Space v1315_5 = subtract(constant_0,v1315_4);
    Space v1315_8;
    if (!v1315_5.empty()) {
      const Path v1316_6 = concat_path(p0,v1314_9_head);
      Space v1316_7_result;
      for (int v1316_7_label = 1; v1316_7_label <= 2; ++v1316_7_label) {
        const Space v1316_7_tail = child(v1314_9_tail,v1316_7_label);
        if (v1316_7_tail.empty()) continue;
        const Path v1316_7_head{v1316_7_label};
        const Space v1317_2 = singleton(v1316_7_head);
        const Space v1317_3 = intersect(constant_6,v1317_2);
        const Space v1317_4 = (has_head(v1317_3) ? constant_7 : Space{});
        const Space v1317_5 = subtract(constant_0,v1317_4);
        Space v1317_8;
        if (!v1317_5.empty()) {
          const Path v1318_6 = concat_path(v1316_6,v1316_7_head);
          const Space v1318_7 = routine_189(c, v1318_6, v1316_7_tail);
          v1317_8 = compose(v1317_5,v1318_7);
        }
        const Space v1317_9 = intersect(constant_6,v1317_2);
        const Space v1317_10 = (has_head(v1317_9) ? constant_7 : Space{});
        Space v1317_12;
        if (!v1317_10.empty()) {
          const Path v1319_6 = concat_path(v1316_6,v1316_7_head);
          const Space v1319_11 = routine_190(c, v1319_6, v1316_7_tail);
          v1317_12 = compose(v1317_10,v1319_11);
        }
        const Space v1317_13 = unite(v1317_8,v1317_12);
        v1316_7_result = unite(v1316_7_result,v1317_13);
      }
      const Space v1316_7 = std::move(v1316_7_result);
      v1315_8 = compose(v1315_5,v1316_7);
    }
    const Space v1315_9 = intersect(constant_6,v1315_2);
    const Space v1315_10 = (has_head(v1315_9) ? constant_7 : Space{});
    const Space v1315_11 = compose(v1315_10,constant_9);
    const Space v1315_12 = unite(v1315_8,v1315_11);
    v1314_9_result = unite(v1314_9_result,v1315_12);
  }
  const Space v1314_9 = std::move(v1314_9_result);
  return v1314_9;
}

static Space routine_143(Context& c, const Path& p0, const Space& s0) {
  Space v1320_11_result;
  for (int v1320_11_label = 1; v1320_11_label <= 2; ++v1320_11_label) {
    const Space v1320_11_tail = child(s0,v1320_11_label);
    if (v1320_11_tail.empty()) continue;
    const Path v1320_11_head{v1320_11_label};
    const Space v1321_2 = singleton(v1320_11_head);
    const Space v1321_3 = intersect(constant_6,v1321_2);
    const Space v1321_4 = (has_head(v1321_3) ? constant_7 : Space{});
    const Space v1321_5 = subtract(constant_0,v1321_4);
    Space v1321_8;
    if (!v1321_5.empty()) {
      const Path v1322_6 = concat_path(p0,v1320_11_head);
      Space v1322_7_result;
      for (int v1322_7_label = 1; v1322_7_label <= 2; ++v1322_7_label) {
        const Space v1322_7_tail = child(v1320_11_tail,v1322_7_label);
        if (v1322_7_tail.empty()) continue;
        const Path v1322_7_head{v1322_7_label};
        const Space v1323_2 = singleton(v1322_7_head);
        const Space v1323_3 = intersect(constant_6,v1323_2);
        const Space v1323_4 = (has_head(v1323_3) ? constant_7 : Space{});
        const Space v1323_5 = subtract(constant_0,v1323_4);
        Space v1323_8;
        if (!v1323_5.empty()) {
          const Path v1324_6 = concat_path(v1322_6,v1322_7_head);
          const Space v1324_7 = routine_191(c, v1324_6, v1322_7_tail);
          v1323_8 = compose(v1323_5,v1324_7);
        }
        const Space v1323_9 = intersect(constant_6,v1323_2);
        const Space v1323_10 = (has_head(v1323_9) ? constant_7 : Space{});
        Space v1323_12;
        if (!v1323_10.empty()) {
          const Path v1325_6 = concat_path(v1322_6,v1322_7_head);
          const Space v1325_11 = routine_192(c, v1325_6, v1322_7_tail);
          v1323_12 = compose(v1323_10,v1325_11);
        }
        const Space v1323_13 = unite(v1323_8,v1323_12);
        v1322_7_result = unite(v1322_7_result,v1323_13);
      }
      const Space v1322_7 = std::move(v1322_7_result);
      v1321_8 = compose(v1321_5,v1322_7);
    }
    const Space v1321_9 = intersect(constant_6,v1321_2);
    const Space v1321_10 = (has_head(v1321_9) ? constant_7 : Space{});
    Space v1321_12;
    if (!v1321_10.empty()) {
      const Path v1326_6 = concat_path(p0,v1320_11_head);
      Space v1326_11_result;
      for (int v1326_11_label = 1; v1326_11_label <= 2; ++v1326_11_label) {
        const Space v1326_11_tail = child(v1320_11_tail,v1326_11_label);
        if (v1326_11_tail.empty()) continue;
        const Path v1326_11_head{v1326_11_label};
        const Space v1327_2 = singleton(v1326_11_head);
        const Space v1327_3 = intersect(constant_6,v1327_2);
        const Space v1327_4 = (has_head(v1327_3) ? constant_7 : Space{});
        const Space v1327_5 = subtract(constant_0,v1327_4);
        Space v1327_8;
        if (!v1327_5.empty()) {
          const Path v1328_6 = concat_path(v1326_6,v1326_11_head);
          const Space v1328_7 = routine_191(c, v1328_6, v1326_11_tail);
          v1327_8 = compose(v1327_5,v1328_7);
        }
        const Space v1327_9 = intersect(constant_6,v1327_2);
        const Space v1327_10 = (has_head(v1327_9) ? constant_7 : Space{});
        Space v1327_12;
        if (!v1327_10.empty()) {
          const Path v1329_6 = concat_path(v1326_6,v1326_11_head);
          const Space v1329_11 = routine_75(c, v1329_6, v1326_11_tail);
          v1327_12 = compose(v1327_10,v1329_11);
        }
        const Space v1327_13 = unite(v1327_8,v1327_12);
        v1326_11_result = unite(v1326_11_result,v1327_13);
      }
      const Space v1326_11 = std::move(v1326_11_result);
      v1321_12 = compose(v1321_10,v1326_11);
    }
    const Space v1321_13 = unite(v1321_8,v1321_12);
    v1320_11_result = unite(v1320_11_result,v1321_13);
  }
  const Space v1320_11 = std::move(v1320_11_result);
  return v1320_11;
}

static Space routine_144(Context& c, const Path& p0, const Space& s0) {
  Space v1330_8_result;
  for (int v1330_8_label = 1; v1330_8_label <= 2; ++v1330_8_label) {
    const Space v1330_8_tail = child(s0,v1330_8_label);
    if (v1330_8_tail.empty()) continue;
    const Path v1330_8_head{v1330_8_label};
    const Space v1331_2 = singleton(v1330_8_head);
    const Space v1331_3 = intersect(constant_6,v1331_2);
    const Space v1331_4 = (has_head(v1331_3) ? constant_7 : Space{});
    const Space v1331_5 = subtract(constant_0,v1331_4);
    Space v1331_8;
    if (!v1331_5.empty()) {
      const Path v1332_6 = concat_path(p0,v1330_8_head);
      Space v1332_7_result;
      for (int v1332_7_label = 1; v1332_7_label <= 2; ++v1332_7_label) {
        const Space v1332_7_tail = child(v1330_8_tail,v1332_7_label);
        if (v1332_7_tail.empty()) continue;
        const Path v1332_7_head{v1332_7_label};
        const Space v1333_2 = singleton(v1332_7_head);
        const Space v1333_3 = intersect(constant_6,v1333_2);
        const Space v1333_4 = (has_head(v1333_3) ? constant_7 : Space{});
        const Space v1333_5 = subtract(constant_0,v1333_4);
        Space v1333_8;
        if (!v1333_5.empty()) {
          const Path v1334_6 = concat_path(v1332_6,v1332_7_head);
          const Space v1334_7 = routine_191(c, v1334_6, v1332_7_tail);
          v1333_8 = compose(v1333_5,v1334_7);
        }
        const Space v1333_9 = intersect(constant_6,v1333_2);
        const Space v1333_10 = (has_head(v1333_9) ? constant_7 : Space{});
        Space v1333_12;
        if (!v1333_10.empty()) {
          const Path v1335_6 = concat_path(v1332_6,v1332_7_head);
          const Space v1335_11 = routine_192(c, v1335_6, v1332_7_tail);
          v1333_12 = compose(v1333_10,v1335_11);
        }
        const Space v1333_13 = unite(v1333_8,v1333_12);
        v1332_7_result = unite(v1332_7_result,v1333_13);
      }
      const Space v1332_7 = std::move(v1332_7_result);
      v1331_8 = compose(v1331_5,v1332_7);
    }
    const Space v1331_9 = intersect(constant_6,v1331_2);
    const Space v1331_10 = (has_head(v1331_9) ? constant_7 : Space{});
    const Space v1331_11 = compose(v1331_10,v1330_8_tail);
    const Space v1331_12 = unite(v1331_8,v1331_11);
    v1330_8_result = unite(v1330_8_result,v1331_12);
  }
  const Space v1330_8 = std::move(v1330_8_result);
  return v1330_8;
}

static Space routine_145(Context& c, const Path& p0, const Space& s0) {
  Space v1336_4_result;
  for (int v1336_4_label = 1; v1336_4_label <= 2; ++v1336_4_label) {
    const Space v1336_4_tail = child(s0,v1336_4_label);
    if (v1336_4_tail.empty()) continue;
    const Path v1336_4_head{v1336_4_label};
    const Space v1337_2 = singleton(v1336_4_head);
    const Space v1337_3 = intersect(constant_6,v1337_2);
    const Space v1337_4 = (has_head(v1337_3) ? constant_7 : Space{});
    Space v1337_7;
    if (!v1337_4.empty()) {
      const Path v1338_5 = concat_path(p0,v1336_4_head);
      Space v1338_6_result;
      for (int v1338_6_label = 1; v1338_6_label <= 2; ++v1338_6_label) {
        const Space v1338_6_tail = child(v1336_4_tail,v1338_6_label);
        if (v1338_6_tail.empty()) continue;
        const Path v1338_6_head{v1338_6_label};
        const Space v1339_2 = singleton(v1338_6_head);
        const Space v1339_3 = intersect(constant_6,v1339_2);
        const Space v1339_4 = (has_head(v1339_3) ? constant_7 : Space{});
        Space v1339_7;
        if (!v1339_4.empty()) {
          const Path v1340_5 = concat_path(v1338_5,v1338_6_head);
          const Space v1340_6 = routine_14(c, v1340_5, v1338_6_tail);
          v1339_7 = compose(v1339_4,v1340_6);
        }
        v1338_6_result = unite(v1338_6_result,v1339_7);
      }
      const Space v1338_6 = std::move(v1338_6_result);
      v1337_7 = compose(v1337_4,v1338_6);
    }
    v1336_4_result = unite(v1336_4_result,v1337_7);
  }
  const Space v1336_4 = std::move(v1336_4_result);
  return v1336_4;
}

static Space routine_146(Context& c, const Path& p0, const Space& s0) {
  Space v1341_6_result;
  for (int v1341_6_label = 1; v1341_6_label <= 2; ++v1341_6_label) {
    const Space v1341_6_tail = child(s0,v1341_6_label);
    if (v1341_6_tail.empty()) continue;
    const Path v1341_6_head{v1341_6_label};
    const Space v1342_2 = singleton(v1341_6_head);
    const Space v1342_3 = intersect(constant_6,v1342_2);
    const Space v1342_4 = (has_head(v1342_3) ? constant_7 : Space{});
    Space v1342_7;
    if (!v1342_4.empty()) {
      const Path v1343_5 = concat_path(p0,v1341_6_head);
      Space v1343_6_result;
      for (int v1343_6_label = 1; v1343_6_label <= 2; ++v1343_6_label) {
        const Space v1343_6_tail = child(v1341_6_tail,v1343_6_label);
        if (v1343_6_tail.empty()) continue;
        const Path v1343_6_head{v1343_6_label};
        const Space v1344_2 = singleton(v1343_6_head);
        const Space v1344_3 = intersect(constant_6,v1344_2);
        const Space v1344_4 = (has_head(v1344_3) ? constant_7 : Space{});
        const Space v1344_5 = subtract(constant_0,v1344_4);
        Space v1344_7;
        if (!v1344_5.empty()) {
          const Space v1345_6 = routine_15(c, v1343_6_head, v1343_5, v1343_6_tail);
          v1344_7 = compose(v1344_5,v1345_6);
        }
        const Space v1344_8 = intersect(constant_6,v1344_2);
        const Space v1344_9 = (has_head(v1344_8) ? constant_7 : Space{});
        Space v1344_11;
        if (!v1344_9.empty()) {
          const Space v1346_10 = routine_16(c, v1343_6_head, v1343_5, v1343_6_tail);
          v1344_11 = compose(v1344_9,v1346_10);
        }
        const Space v1344_12 = unite(v1344_7,v1344_11);
        v1343_6_result = unite(v1343_6_result,v1344_12);
      }
      const Space v1343_6 = std::move(v1343_6_result);
      v1342_7 = compose(v1342_4,v1343_6);
    }
    v1341_6_result = unite(v1341_6_result,v1342_7);
  }
  const Space v1341_6 = std::move(v1341_6_result);
  return v1341_6;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1347_12_result;
  for (int v1347_12_label = 1; v1347_12_label <= 2; ++v1347_12_label) {
    const Space v1347_12_tail = child(s0,v1347_12_label);
    if (v1347_12_tail.empty()) continue;
    const Path v1347_12_head{v1347_12_label};
    const Space v1348_2 = singleton(v1347_12_head);
    const Space v1348_3 = intersect(constant_6,v1348_2);
    const Space v1348_4 = (has_head(v1348_3) ? constant_7 : Space{});
    const Space v1348_5 = subtract(constant_0,v1348_4);
    Space v1348_8;
    if (!v1348_5.empty()) {
      const Path v1349_6 = concat_path(p0,v1347_12_head);
      Space v1349_7_result;
      for (int v1349_7_label = 1; v1349_7_label <= 2; ++v1349_7_label) {
        const Space v1349_7_tail = child(v1347_12_tail,v1349_7_label);
        if (v1349_7_tail.empty()) continue;
        const Path v1349_7_head{v1349_7_label};
        const Space v1350_2 = singleton(v1349_7_head);
        const Space v1350_3 = intersect(constant_6,v1350_2);
        const Space v1350_4 = (has_head(v1350_3) ? constant_7 : Space{});
        const Space v1350_5 = subtract(constant_0,v1350_4);
        Space v1350_8;
        if (!v1350_5.empty()) {
          const Path v1351_6 = concat_path(v1349_6,v1349_7_head);
          const Space v1351_7 = routine_193(c, v1351_6, p1, v1349_7_tail);
          v1350_8 = compose(v1350_5,v1351_7);
        }
        const Space v1350_9 = intersect(constant_6,v1350_2);
        const Space v1350_10 = (has_head(v1350_9) ? constant_7 : Space{});
        Space v1350_12;
        if (!v1350_10.empty()) {
          const Path v1352_6 = concat_path(v1349_6,v1349_7_head);
          const Space v1352_11 = routine_194(c, v1352_6, p1, v1349_7_tail);
          v1350_12 = compose(v1350_10,v1352_11);
        }
        const Space v1350_13 = unite(v1350_8,v1350_12);
        v1349_7_result = unite(v1349_7_result,v1350_13);
      }
      const Space v1349_7 = std::move(v1349_7_result);
      v1348_8 = compose(v1348_5,v1349_7);
    }
    const Space v1348_9 = intersect(constant_6,v1348_2);
    const Space v1348_10 = (has_head(v1348_9) ? constant_7 : Space{});
    Space v1348_12;
    if (!v1348_10.empty()) {
      const Path v1353_6 = concat_path(p0,v1347_12_head);
      Space v1353_11_result;
      for (int v1353_11_label = 1; v1353_11_label <= 2; ++v1353_11_label) {
        const Space v1353_11_tail = child(v1347_12_tail,v1353_11_label);
        if (v1353_11_tail.empty()) continue;
        const Path v1353_11_head{v1353_11_label};
        const Space v1354_2 = singleton(v1353_11_head);
        const Space v1354_3 = intersect(constant_6,v1354_2);
        const Space v1354_4 = (has_head(v1354_3) ? constant_7 : Space{});
        const Space v1354_5 = subtract(constant_0,v1354_4);
        Space v1354_8;
        if (!v1354_5.empty()) {
          const Path v1355_6 = concat_path(v1353_6,v1353_11_head);
          const Space v1355_7 = routine_193(c, v1355_6, p1, v1353_11_tail);
          v1354_8 = compose(v1354_5,v1355_7);
        }
        const Space v1354_9 = intersect(constant_6,v1354_2);
        const Space v1354_10 = (has_head(v1354_9) ? constant_7 : Space{});
        Space v1354_12;
        if (!v1354_10.empty()) {
          const Path v1356_6 = concat_path(v1353_6,v1353_11_head);
          const Space v1356_11 = routine_42(c, v1356_6, p1, v1353_11_tail);
          v1354_12 = compose(v1354_10,v1356_11);
        }
        const Space v1354_13 = unite(v1354_8,v1354_12);
        v1353_11_result = unite(v1353_11_result,v1354_13);
      }
      const Space v1353_11 = std::move(v1353_11_result);
      v1348_12 = compose(v1348_10,v1353_11);
    }
    const Space v1348_13 = unite(v1348_8,v1348_12);
    v1347_12_result = unite(v1347_12_result,v1348_13);
  }
  const Space v1347_12 = std::move(v1347_12_result);
  return v1347_12;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1357_9_result;
  for (int v1357_9_label = 1; v1357_9_label <= 2; ++v1357_9_label) {
    const Space v1357_9_tail = child(s0,v1357_9_label);
    if (v1357_9_tail.empty()) continue;
    const Path v1357_9_head{v1357_9_label};
    const Space v1358_2 = singleton(v1357_9_head);
    const Space v1358_3 = intersect(constant_6,v1358_2);
    const Space v1358_4 = (has_head(v1358_3) ? constant_7 : Space{});
    const Space v1358_5 = subtract(constant_0,v1358_4);
    Space v1358_8;
    if (!v1358_5.empty()) {
      const Path v1359_6 = concat_path(p0,v1357_9_head);
      Space v1359_7_result;
      for (int v1359_7_label = 1; v1359_7_label <= 2; ++v1359_7_label) {
        const Space v1359_7_tail = child(v1357_9_tail,v1359_7_label);
        if (v1359_7_tail.empty()) continue;
        const Path v1359_7_head{v1359_7_label};
        const Space v1360_2 = singleton(v1359_7_head);
        const Space v1360_3 = intersect(constant_6,v1360_2);
        const Space v1360_4 = (has_head(v1360_3) ? constant_7 : Space{});
        const Space v1360_5 = subtract(constant_0,v1360_4);
        Space v1360_8;
        if (!v1360_5.empty()) {
          const Path v1361_6 = concat_path(v1359_6,v1359_7_head);
          const Space v1361_7 = routine_193(c, v1361_6, p1, v1359_7_tail);
          v1360_8 = compose(v1360_5,v1361_7);
        }
        const Space v1360_9 = intersect(constant_6,v1360_2);
        const Space v1360_10 = (has_head(v1360_9) ? constant_7 : Space{});
        Space v1360_12;
        if (!v1360_10.empty()) {
          const Path v1362_6 = concat_path(v1359_6,v1359_7_head);
          const Space v1362_11 = routine_194(c, v1362_6, p1, v1359_7_tail);
          v1360_12 = compose(v1360_10,v1362_11);
        }
        const Space v1360_13 = unite(v1360_8,v1360_12);
        v1359_7_result = unite(v1359_7_result,v1360_13);
      }
      const Space v1359_7 = std::move(v1359_7_result);
      v1358_8 = compose(v1358_5,v1359_7);
    }
    const Space v1358_9 = intersect(constant_6,v1358_2);
    const Space v1358_10 = (has_head(v1358_9) ? constant_7 : Space{});
    Space v1358_13;
    if (!v1358_10.empty()) {
      const Path v1363_6 = concat_path(p0,v1357_9_head);
      const Path v1363_11 = concat_path(p1,v1363_6);
      const Space v1363_12 = routine_29(c, v1363_11);
      v1358_13 = compose(v1358_10,v1363_12);
    }
    const Space v1358_14 = unite(v1358_8,v1358_13);
    v1357_9_result = unite(v1357_9_result,v1358_14);
  }
  const Space v1357_9 = std::move(v1357_9_result);
  return v1357_9;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1364_12_result;
  for (int v1364_12_label = 1; v1364_12_label <= 2; ++v1364_12_label) {
    const Space v1364_12_tail = child(s0,v1364_12_label);
    if (v1364_12_tail.empty()) continue;
    const Path v1364_12_head{v1364_12_label};
    const Space v1365_2 = singleton(v1364_12_head);
    const Space v1365_3 = intersect(constant_6,v1365_2);
    const Space v1365_4 = (has_head(v1365_3) ? constant_7 : Space{});
    const Space v1365_5 = subtract(constant_0,v1365_4);
    Space v1365_8;
    if (!v1365_5.empty()) {
      const Path v1366_6 = concat_path(p0,v1364_12_head);
      Space v1366_7_result;
      for (int v1366_7_label = 1; v1366_7_label <= 2; ++v1366_7_label) {
        const Space v1366_7_tail = child(v1364_12_tail,v1366_7_label);
        if (v1366_7_tail.empty()) continue;
        const Path v1366_7_head{v1366_7_label};
        const Space v1367_2 = singleton(v1366_7_head);
        const Space v1367_3 = intersect(constant_6,v1367_2);
        const Space v1367_4 = (has_head(v1367_3) ? constant_7 : Space{});
        const Space v1367_5 = subtract(constant_0,v1367_4);
        Space v1367_8;
        if (!v1367_5.empty()) {
          const Path v1368_6 = concat_path(v1366_6,v1366_7_head);
          const Space v1368_7 = routine_195(c, v1368_6, p1, v1366_7_tail);
          v1367_8 = compose(v1367_5,v1368_7);
        }
        const Space v1367_9 = intersect(constant_6,v1367_2);
        const Space v1367_10 = (has_head(v1367_9) ? constant_7 : Space{});
        Space v1367_12;
        if (!v1367_10.empty()) {
          const Path v1369_6 = concat_path(v1366_6,v1366_7_head);
          const Space v1369_11 = routine_196(c, v1369_6, p1, v1366_7_tail);
          v1367_12 = compose(v1367_10,v1369_11);
        }
        const Space v1367_13 = unite(v1367_8,v1367_12);
        v1366_7_result = unite(v1366_7_result,v1367_13);
      }
      const Space v1366_7 = std::move(v1366_7_result);
      v1365_8 = compose(v1365_5,v1366_7);
    }
    const Space v1365_9 = intersect(constant_6,v1365_2);
    const Space v1365_10 = (has_head(v1365_9) ? constant_7 : Space{});
    Space v1365_12;
    if (!v1365_10.empty()) {
      const Path v1370_6 = concat_path(p0,v1364_12_head);
      Space v1370_11_result;
      for (int v1370_11_label = 1; v1370_11_label <= 2; ++v1370_11_label) {
        const Space v1370_11_tail = child(v1364_12_tail,v1370_11_label);
        if (v1370_11_tail.empty()) continue;
        const Path v1370_11_head{v1370_11_label};
        const Space v1371_2 = singleton(v1370_11_head);
        const Space v1371_3 = intersect(constant_6,v1371_2);
        const Space v1371_4 = (has_head(v1371_3) ? constant_7 : Space{});
        const Space v1371_5 = subtract(constant_0,v1371_4);
        Space v1371_8;
        if (!v1371_5.empty()) {
          const Path v1372_6 = concat_path(v1370_6,v1370_11_head);
          const Space v1372_7 = routine_195(c, v1372_6, p1, v1370_11_tail);
          v1371_8 = compose(v1371_5,v1372_7);
        }
        const Space v1371_9 = intersect(constant_6,v1371_2);
        const Space v1371_10 = (has_head(v1371_9) ? constant_7 : Space{});
        Space v1371_12;
        if (!v1371_10.empty()) {
          const Path v1373_6 = concat_path(v1370_6,v1370_11_head);
          const Space v1373_11 = routine_42(c, v1373_6, p1, v1370_11_tail);
          v1371_12 = compose(v1371_10,v1373_11);
        }
        const Space v1371_13 = unite(v1371_8,v1371_12);
        v1370_11_result = unite(v1370_11_result,v1371_13);
      }
      const Space v1370_11 = std::move(v1370_11_result);
      v1365_12 = compose(v1365_10,v1370_11);
    }
    const Space v1365_13 = unite(v1365_8,v1365_12);
    v1364_12_result = unite(v1364_12_result,v1365_13);
  }
  const Space v1364_12 = std::move(v1364_12_result);
  return v1364_12;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1374_9_result;
  for (int v1374_9_label = 1; v1374_9_label <= 2; ++v1374_9_label) {
    const Space v1374_9_tail = child(s0,v1374_9_label);
    if (v1374_9_tail.empty()) continue;
    const Path v1374_9_head{v1374_9_label};
    const Space v1375_2 = singleton(v1374_9_head);
    const Space v1375_3 = intersect(constant_6,v1375_2);
    const Space v1375_4 = (has_head(v1375_3) ? constant_7 : Space{});
    const Space v1375_5 = subtract(constant_0,v1375_4);
    Space v1375_8;
    if (!v1375_5.empty()) {
      const Path v1376_6 = concat_path(p0,v1374_9_head);
      Space v1376_7_result;
      for (int v1376_7_label = 1; v1376_7_label <= 2; ++v1376_7_label) {
        const Space v1376_7_tail = child(v1374_9_tail,v1376_7_label);
        if (v1376_7_tail.empty()) continue;
        const Path v1376_7_head{v1376_7_label};
        const Space v1377_2 = singleton(v1376_7_head);
        const Space v1377_3 = intersect(constant_6,v1377_2);
        const Space v1377_4 = (has_head(v1377_3) ? constant_7 : Space{});
        const Space v1377_5 = subtract(constant_0,v1377_4);
        Space v1377_8;
        if (!v1377_5.empty()) {
          const Path v1378_6 = concat_path(v1376_6,v1376_7_head);
          const Space v1378_7 = routine_195(c, v1378_6, p1, v1376_7_tail);
          v1377_8 = compose(v1377_5,v1378_7);
        }
        const Space v1377_9 = intersect(constant_6,v1377_2);
        const Space v1377_10 = (has_head(v1377_9) ? constant_7 : Space{});
        Space v1377_12;
        if (!v1377_10.empty()) {
          const Path v1379_6 = concat_path(v1376_6,v1376_7_head);
          const Space v1379_11 = routine_196(c, v1379_6, p1, v1376_7_tail);
          v1377_12 = compose(v1377_10,v1379_11);
        }
        const Space v1377_13 = unite(v1377_8,v1377_12);
        v1376_7_result = unite(v1376_7_result,v1377_13);
      }
      const Space v1376_7 = std::move(v1376_7_result);
      v1375_8 = compose(v1375_5,v1376_7);
    }
    const Space v1375_9 = intersect(constant_6,v1375_2);
    const Space v1375_10 = (has_head(v1375_9) ? constant_7 : Space{});
    Space v1375_13;
    if (!v1375_10.empty()) {
      const Path v1380_6 = concat_path(p0,v1374_9_head);
      const Path v1380_11 = concat_path(p1,v1380_6);
      const Space v1380_12 = routine_29(c, v1380_11);
      v1375_13 = compose(v1375_10,v1380_12);
    }
    const Space v1375_14 = unite(v1375_8,v1375_13);
    v1374_9_result = unite(v1374_9_result,v1375_14);
  }
  const Space v1374_9 = std::move(v1374_9_result);
  return v1374_9;
}

static Space routine_151(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1381_5_result;
  for (int v1381_5_label = 1; v1381_5_label <= 2; ++v1381_5_label) {
    const Space v1381_5_tail = child(s0,v1381_5_label);
    if (v1381_5_tail.empty()) continue;
    const Path v1381_5_head{v1381_5_label};
    const Space v1382_2 = singleton(v1381_5_head);
    const Space v1382_3 = intersect(constant_6,v1382_2);
    const Space v1382_4 = (has_head(v1382_3) ? constant_7 : Space{});
    Space v1382_7;
    if (!v1382_4.empty()) {
      const Path v1383_5 = concat_path(p0,v1381_5_head);
      Space v1383_6_result;
      for (int v1383_6_label = 1; v1383_6_label <= 2; ++v1383_6_label) {
        const Space v1383_6_tail = child(v1381_5_tail,v1383_6_label);
        if (v1383_6_tail.empty()) continue;
        const Path v1383_6_head{v1383_6_label};
        const Space v1384_2 = singleton(v1383_6_head);
        const Space v1384_3 = intersect(constant_6,v1384_2);
        const Space v1384_4 = (has_head(v1384_3) ? constant_7 : Space{});
        Space v1384_7;
        if (!v1384_4.empty()) {
          const Path v1385_5 = concat_path(v1383_5,v1383_6_head);
          const Space v1385_6 = routine_19(c, v1385_5, v1383_6_tail, s1);
          v1384_7 = compose(v1384_4,v1385_6);
        }
        v1383_6_result = unite(v1383_6_result,v1384_7);
      }
      const Space v1383_6 = std::move(v1383_6_result);
      v1382_7 = compose(v1382_4,v1383_6);
    }
    v1381_5_result = unite(v1381_5_result,v1382_7);
  }
  const Space v1381_5 = std::move(v1381_5_result);
  return v1381_5;
}

static Space routine_152(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1386_7_result;
  for (int v1386_7_label = 1; v1386_7_label <= 2; ++v1386_7_label) {
    const Space v1386_7_tail = child(s0,v1386_7_label);
    if (v1386_7_tail.empty()) continue;
    const Path v1386_7_head{v1386_7_label};
    const Space v1387_2 = singleton(v1386_7_head);
    const Space v1387_3 = intersect(constant_6,v1387_2);
    const Space v1387_4 = (has_head(v1387_3) ? constant_7 : Space{});
    Space v1387_7;
    if (!v1387_4.empty()) {
      const Path v1388_5 = concat_path(p0,v1386_7_head);
      Space v1388_6_result;
      for (int v1388_6_label = 1; v1388_6_label <= 2; ++v1388_6_label) {
        const Space v1388_6_tail = child(v1386_7_tail,v1388_6_label);
        if (v1388_6_tail.empty()) continue;
        const Path v1388_6_head{v1388_6_label};
        const Space v1389_2 = singleton(v1388_6_head);
        const Space v1389_3 = intersect(constant_6,v1389_2);
        const Space v1389_4 = (has_head(v1389_3) ? constant_7 : Space{});
        const Space v1389_5 = subtract(constant_0,v1389_4);
        Space v1389_7;
        if (!v1389_5.empty()) {
          const Space v1390_6 = routine_20(c, v1388_6_head, v1388_5, v1388_6_tail, s1);
          v1389_7 = compose(v1389_5,v1390_6);
        }
        const Space v1389_8 = intersect(constant_6,v1389_2);
        const Space v1389_9 = (has_head(v1389_8) ? constant_7 : Space{});
        Space v1389_11;
        if (!v1389_9.empty()) {
          const Space v1391_10 = routine_21(c, v1388_6_head, v1388_5, v1388_6_tail, s1);
          v1389_11 = compose(v1389_9,v1391_10);
        }
        const Space v1389_12 = unite(v1389_7,v1389_11);
        v1388_6_result = unite(v1388_6_result,v1389_12);
      }
      const Space v1388_6 = std::move(v1388_6_result);
      v1387_7 = compose(v1387_4,v1388_6);
    }
    v1386_7_result = unite(v1386_7_result,v1387_7);
  }
  const Space v1386_7 = std::move(v1386_7_result);
  return v1386_7;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1392_13_result;
  for (int v1392_13_label = 1; v1392_13_label <= 2; ++v1392_13_label) {
    const Space v1392_13_tail = child(s0,v1392_13_label);
    if (v1392_13_tail.empty()) continue;
    const Path v1392_13_head{v1392_13_label};
    const Space v1393_2 = singleton(v1392_13_head);
    const Space v1393_3 = intersect(constant_6,v1393_2);
    const Space v1393_4 = (has_head(v1393_3) ? constant_7 : Space{});
    const Space v1393_5 = subtract(constant_0,v1393_4);
    Space v1393_8;
    if (!v1393_5.empty()) {
      const Path v1394_6 = concat_path(p0,v1392_13_head);
      Space v1394_7_result;
      for (int v1394_7_label = 1; v1394_7_label <= 2; ++v1394_7_label) {
        const Space v1394_7_tail = child(v1392_13_tail,v1394_7_label);
        if (v1394_7_tail.empty()) continue;
        const Path v1394_7_head{v1394_7_label};
        const Space v1395_2 = singleton(v1394_7_head);
        const Space v1395_3 = intersect(constant_6,v1395_2);
        const Space v1395_4 = (has_head(v1395_3) ? constant_7 : Space{});
        const Space v1395_5 = subtract(constant_0,v1395_4);
        Space v1395_8;
        if (!v1395_5.empty()) {
          const Path v1396_6 = concat_path(v1394_6,v1394_7_head);
          const Space v1396_7 = routine_197(c, v1396_6, p1, v1394_7_tail, s1);
          v1395_8 = compose(v1395_5,v1396_7);
        }
        const Space v1395_9 = intersect(constant_6,v1395_2);
        const Space v1395_10 = (has_head(v1395_9) ? constant_7 : Space{});
        Space v1395_12;
        if (!v1395_10.empty()) {
          const Path v1397_6 = concat_path(v1394_6,v1394_7_head);
          const Space v1397_11 = routine_198(c, v1397_6, p1, v1394_7_tail, s1);
          v1395_12 = compose(v1395_10,v1397_11);
        }
        const Space v1395_13 = unite(v1395_8,v1395_12);
        v1394_7_result = unite(v1394_7_result,v1395_13);
      }
      const Space v1394_7 = std::move(v1394_7_result);
      v1393_8 = compose(v1393_5,v1394_7);
    }
    const Space v1393_9 = intersect(constant_6,v1393_2);
    const Space v1393_10 = (has_head(v1393_9) ? constant_7 : Space{});
    Space v1393_12;
    if (!v1393_10.empty()) {
      const Path v1398_6 = concat_path(p0,v1392_13_head);
      Space v1398_11_result;
      for (int v1398_11_label = 1; v1398_11_label <= 2; ++v1398_11_label) {
        const Space v1398_11_tail = child(v1392_13_tail,v1398_11_label);
        if (v1398_11_tail.empty()) continue;
        const Path v1398_11_head{v1398_11_label};
        const Space v1399_2 = singleton(v1398_11_head);
        const Space v1399_3 = intersect(constant_6,v1399_2);
        const Space v1399_4 = (has_head(v1399_3) ? constant_7 : Space{});
        const Space v1399_5 = subtract(constant_0,v1399_4);
        Space v1399_8;
        if (!v1399_5.empty()) {
          const Path v1400_6 = concat_path(v1398_6,v1398_11_head);
          const Space v1400_7 = routine_197(c, v1400_6, p1, v1398_11_tail, s1);
          v1399_8 = compose(v1399_5,v1400_7);
        }
        const Space v1399_9 = intersect(constant_6,v1399_2);
        const Space v1399_10 = (has_head(v1399_9) ? constant_7 : Space{});
        Space v1399_12;
        if (!v1399_10.empty()) {
          const Path v1401_6 = concat_path(v1398_6,v1398_11_head);
          const Space v1401_11 = routine_49(c, v1401_6, p1, v1398_11_tail, s1);
          v1399_12 = compose(v1399_10,v1401_11);
        }
        const Space v1399_13 = unite(v1399_8,v1399_12);
        v1398_11_result = unite(v1398_11_result,v1399_13);
      }
      const Space v1398_11 = std::move(v1398_11_result);
      v1393_12 = compose(v1393_10,v1398_11);
    }
    const Space v1393_13 = unite(v1393_8,v1393_12);
    v1392_13_result = unite(v1392_13_result,v1393_13);
  }
  const Space v1392_13 = std::move(v1392_13_result);
  return v1392_13;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1402_8 = unwrap(s1,constant_8);
  Space v1402_21_result;
  for (int v1402_21_label = 1; v1402_21_label <= 2; ++v1402_21_label) {
    const Space v1402_21_tail = child(s0,v1402_21_label);
    if (v1402_21_tail.empty()) continue;
    const Path v1402_21_head{v1402_21_label};
    const Space v1403_2 = singleton(v1402_21_head);
    const Space v1403_3 = intersect(constant_6,v1403_2);
    const Space v1403_4 = (has_head(v1403_3) ? constant_7 : Space{});
    const Space v1403_5 = subtract(constant_0,v1403_4);
    Space v1403_8;
    if (!v1403_5.empty()) {
      const Path v1404_6 = concat_path(p0,v1402_21_head);
      Space v1404_7_result;
      for (int v1404_7_label = 1; v1404_7_label <= 2; ++v1404_7_label) {
        const Space v1404_7_tail = child(v1402_21_tail,v1404_7_label);
        if (v1404_7_tail.empty()) continue;
        const Path v1404_7_head{v1404_7_label};
        const Space v1405_2 = singleton(v1404_7_head);
        const Space v1405_3 = intersect(constant_6,v1405_2);
        const Space v1405_4 = (has_head(v1405_3) ? constant_7 : Space{});
        const Space v1405_5 = subtract(constant_0,v1405_4);
        Space v1405_8;
        if (!v1405_5.empty()) {
          const Path v1406_6 = concat_path(v1404_6,v1404_7_head);
          const Space v1406_7 = routine_197(c, v1406_6, p1, v1404_7_tail, s1);
          v1405_8 = compose(v1405_5,v1406_7);
        }
        const Space v1405_9 = intersect(constant_6,v1405_2);
        const Space v1405_10 = (has_head(v1405_9) ? constant_7 : Space{});
        Space v1405_12;
        if (!v1405_10.empty()) {
          const Path v1407_6 = concat_path(v1404_6,v1404_7_head);
          const Space v1407_11 = routine_198(c, v1407_6, p1, v1404_7_tail, s1);
          v1405_12 = compose(v1405_10,v1407_11);
        }
        const Space v1405_13 = unite(v1405_8,v1405_12);
        v1404_7_result = unite(v1404_7_result,v1405_13);
      }
      const Space v1404_7 = std::move(v1404_7_result);
      v1403_8 = compose(v1403_5,v1404_7);
    }
    const Space v1403_9 = intersect(constant_6,v1403_2);
    const Space v1403_10 = (has_head(v1403_9) ? constant_7 : Space{});
    Space v1403_22;
    if (!v1403_10.empty()) {
      const Path v1408_6 = concat_path(p0,v1402_21_head);
      const Path v1408_11 = concat_path(p1,v1408_6);
      const Space v1408_12 = routine_29(c, v1408_11);
      const Space v1408_13 = intersect(v1402_8,v1408_12);
      const Space v1408_14 = routine_33(c, v1408_13);
      Space v1408_15_result;
      for (int v1408_15_label = 1; v1408_15_label <= 2; ++v1408_15_label) {
        const Space v1408_15_tail = child(v1408_14,v1408_15_label);
        if (v1408_15_tail.empty()) continue;
        const Path v1408_15_head{v1408_15_label};
        const Space v1409_2 = singleton(v1408_15_head);
        const Space v1409_3 = intersect(constant_6,v1409_2);
        const Space v1409_4 = (has_head(v1409_3) ? constant_7 : Space{});
        const Space v1409_5 = subtract(constant_0,v1409_4);
        Space v1409_7;
        if (!v1409_5.empty()) {
          const Space v1410_6 = routine_52(c, v1408_15_head, v1408_15_tail);
          v1409_7 = compose(v1409_5,v1410_6);
        }
        const Space v1409_8 = intersect(constant_6,v1409_2);
        const Space v1409_9 = (has_head(v1409_8) ? constant_7 : Space{});
        Space v1409_11;
        if (!v1409_9.empty()) {
          const Space v1411_10 = routine_53(c, v1408_15_head, v1408_15_tail);
          v1409_11 = compose(v1409_9,v1411_10);
        }
        const Space v1409_12 = unite(v1409_7,v1409_11);
        v1408_15_result = unite(v1408_15_result,v1409_12);
      }
      const Space v1408_15 = std::move(v1408_15_result);
      const Space v1408_16 = routine_54(c, v1408_13);
      Space v1408_17_result;
      for (int v1408_17_label = 1; v1408_17_label <= 2; ++v1408_17_label) {
        const Space v1408_17_tail = child(v1408_16,v1408_17_label);
        if (v1408_17_tail.empty()) continue;
        const Path v1408_17_head{v1408_17_label};
        const Space v1412_2 = singleton(v1408_17_head);
        const Space v1412_3 = intersect(constant_6,v1412_2);
        const Space v1412_4 = (has_head(v1412_3) ? constant_7 : Space{});
        const Space v1412_5 = subtract(constant_0,v1412_4);
        Space v1412_7;
        if (!v1412_5.empty()) {
          const Space v1413_6 = routine_55(c, v1408_17_head, v1408_17_tail);
          v1412_7 = compose(v1412_5,v1413_6);
        }
        const Space v1412_8 = intersect(constant_6,v1412_2);
        const Space v1412_9 = (has_head(v1412_8) ? constant_7 : Space{});
        Space v1412_11;
        if (!v1412_9.empty()) {
          const Space v1414_10 = routine_56(c, v1408_17_head, v1408_17_tail);
          v1412_11 = compose(v1412_9,v1414_10);
        }
        const Space v1412_12 = unite(v1412_7,v1412_11);
        v1408_17_result = unite(v1408_17_result,v1412_12);
      }
      const Space v1408_17 = std::move(v1408_17_result);
      const Space v1408_18 = subtract(v1408_15,v1408_17);
      const Space v1408_19 = singleton(v1408_11);
      const Space v1408_20 = compose(v1408_18,v1408_19);
      Space v1408_21_result;
      for (int v1408_21_label = 1; v1408_21_label <= 2; ++v1408_21_label) {
        const Space v1408_21_tail = child(v1408_20,v1408_21_label);
        if (v1408_21_tail.empty()) continue;
        const Path v1408_21_head{v1408_21_label};
        const Space v1415_2 = singleton(v1408_21_head);
        const Space v1415_3 = intersect(constant_6,v1415_2);
        const Space v1415_4 = (has_head(v1415_3) ? constant_7 : Space{});
        const Space v1415_5 = subtract(constant_0,v1415_4);
        Space v1415_7;
        if (!v1415_5.empty()) {
          const Space v1416_6 = routine_57(c, v1408_21_head, v1408_21_tail);
          v1415_7 = compose(v1415_5,v1416_6);
        }
        const Space v1415_8 = intersect(constant_6,v1415_2);
        const Space v1415_9 = (has_head(v1415_8) ? constant_7 : Space{});
        Space v1415_11;
        if (!v1415_9.empty()) {
          const Space v1417_10 = routine_58(c, v1408_21_head, v1408_21_tail);
          v1415_11 = compose(v1415_9,v1417_10);
        }
        const Space v1415_12 = unite(v1415_7,v1415_11);
        v1408_21_result = unite(v1408_21_result,v1415_12);
      }
      const Space v1408_21 = std::move(v1408_21_result);
      v1403_22 = compose(v1403_10,v1408_21);
    }
    const Space v1403_23 = unite(v1403_8,v1403_22);
    v1402_21_result = unite(v1402_21_result,v1403_23);
  }
  const Space v1402_21 = std::move(v1402_21_result);
  return v1402_21;
}

static Space routine_155(Context& c, const Path& p0, const Space& s0) {
  Space v1418_11_result;
  for (int v1418_11_label = 1; v1418_11_label <= 2; ++v1418_11_label) {
    const Space v1418_11_tail = child(s0,v1418_11_label);
    if (v1418_11_tail.empty()) continue;
    const Path v1418_11_head{v1418_11_label};
    const Space v1419_2 = singleton(v1418_11_head);
    const Space v1419_3 = intersect(constant_6,v1419_2);
    const Space v1419_4 = (has_head(v1419_3) ? constant_7 : Space{});
    const Space v1419_5 = subtract(constant_0,v1419_4);
    Space v1419_8;
    if (!v1419_5.empty()) {
      const Path v1420_6 = concat_path(p0,v1418_11_head);
      Space v1420_7_result;
      for (int v1420_7_label = 1; v1420_7_label <= 2; ++v1420_7_label) {
        const Space v1420_7_tail = child(v1418_11_tail,v1420_7_label);
        if (v1420_7_tail.empty()) continue;
        const Path v1420_7_head{v1420_7_label};
        const Space v1421_2 = singleton(v1420_7_head);
        const Space v1421_3 = intersect(constant_6,v1421_2);
        const Space v1421_4 = (has_head(v1421_3) ? constant_7 : Space{});
        const Space v1421_5 = subtract(constant_0,v1421_4);
        Space v1421_8;
        if (!v1421_5.empty()) {
          const Path v1422_6 = concat_path(v1420_6,v1420_7_head);
          const Space v1422_7 = routine_199(c, v1422_6, v1420_7_tail);
          v1421_8 = compose(v1421_5,v1422_7);
        }
        const Space v1421_9 = intersect(constant_6,v1421_2);
        const Space v1421_10 = (has_head(v1421_9) ? constant_7 : Space{});
        Space v1421_12;
        if (!v1421_10.empty()) {
          const Path v1423_6 = concat_path(v1420_6,v1420_7_head);
          const Space v1423_11 = routine_200(c, v1423_6, v1420_7_tail);
          v1421_12 = compose(v1421_10,v1423_11);
        }
        const Space v1421_13 = unite(v1421_8,v1421_12);
        v1420_7_result = unite(v1420_7_result,v1421_13);
      }
      const Space v1420_7 = std::move(v1420_7_result);
      v1419_8 = compose(v1419_5,v1420_7);
    }
    const Space v1419_9 = intersect(constant_6,v1419_2);
    const Space v1419_10 = (has_head(v1419_9) ? constant_7 : Space{});
    Space v1419_12;
    if (!v1419_10.empty()) {
      const Path v1424_6 = concat_path(p0,v1418_11_head);
      Space v1424_11_result;
      for (int v1424_11_label = 1; v1424_11_label <= 2; ++v1424_11_label) {
        const Space v1424_11_tail = child(v1418_11_tail,v1424_11_label);
        if (v1424_11_tail.empty()) continue;
        const Path v1424_11_head{v1424_11_label};
        const Space v1425_2 = singleton(v1424_11_head);
        const Space v1425_3 = intersect(constant_6,v1425_2);
        const Space v1425_4 = (has_head(v1425_3) ? constant_7 : Space{});
        const Space v1425_5 = subtract(constant_0,v1425_4);
        Space v1425_8;
        if (!v1425_5.empty()) {
          const Path v1426_6 = concat_path(v1424_6,v1424_11_head);
          const Space v1426_7 = routine_199(c, v1426_6, v1424_11_tail);
          v1425_8 = compose(v1425_5,v1426_7);
        }
        const Space v1425_9 = intersect(constant_6,v1425_2);
        const Space v1425_10 = (has_head(v1425_9) ? constant_7 : Space{});
        Space v1425_12;
        if (!v1425_10.empty()) {
          const Path v1427_6 = concat_path(v1424_6,v1424_11_head);
          const Space v1427_11 = routine_100(c, v1427_6, v1424_11_tail);
          v1425_12 = compose(v1425_10,v1427_11);
        }
        const Space v1425_13 = unite(v1425_8,v1425_12);
        v1424_11_result = unite(v1424_11_result,v1425_13);
      }
      const Space v1424_11 = std::move(v1424_11_result);
      v1419_12 = compose(v1419_10,v1424_11);
    }
    const Space v1419_13 = unite(v1419_8,v1419_12);
    v1418_11_result = unite(v1418_11_result,v1419_13);
  }
  const Space v1418_11 = std::move(v1418_11_result);
  return v1418_11;
}

static Space routine_156(Context& c, const Path& p0, const Space& s0) {
  Space v1428_9_result;
  for (int v1428_9_label = 1; v1428_9_label <= 2; ++v1428_9_label) {
    const Space v1428_9_tail = child(s0,v1428_9_label);
    if (v1428_9_tail.empty()) continue;
    const Path v1428_9_head{v1428_9_label};
    const Space v1429_2 = singleton(v1428_9_head);
    const Space v1429_3 = intersect(constant_6,v1429_2);
    const Space v1429_4 = (has_head(v1429_3) ? constant_7 : Space{});
    const Space v1429_5 = subtract(constant_0,v1429_4);
    Space v1429_8;
    if (!v1429_5.empty()) {
      const Path v1430_6 = concat_path(p0,v1428_9_head);
      Space v1430_7_result;
      for (int v1430_7_label = 1; v1430_7_label <= 2; ++v1430_7_label) {
        const Space v1430_7_tail = child(v1428_9_tail,v1430_7_label);
        if (v1430_7_tail.empty()) continue;
        const Path v1430_7_head{v1430_7_label};
        const Space v1431_2 = singleton(v1430_7_head);
        const Space v1431_3 = intersect(constant_6,v1431_2);
        const Space v1431_4 = (has_head(v1431_3) ? constant_7 : Space{});
        const Space v1431_5 = subtract(constant_0,v1431_4);
        Space v1431_8;
        if (!v1431_5.empty()) {
          const Path v1432_6 = concat_path(v1430_6,v1430_7_head);
          const Space v1432_7 = routine_199(c, v1432_6, v1430_7_tail);
          v1431_8 = compose(v1431_5,v1432_7);
        }
        const Space v1431_9 = intersect(constant_6,v1431_2);
        const Space v1431_10 = (has_head(v1431_9) ? constant_7 : Space{});
        Space v1431_12;
        if (!v1431_10.empty()) {
          const Path v1433_6 = concat_path(v1430_6,v1430_7_head);
          const Space v1433_11 = routine_200(c, v1433_6, v1430_7_tail);
          v1431_12 = compose(v1431_10,v1433_11);
        }
        const Space v1431_13 = unite(v1431_8,v1431_12);
        v1430_7_result = unite(v1430_7_result,v1431_13);
      }
      const Space v1430_7 = std::move(v1430_7_result);
      v1429_8 = compose(v1429_5,v1430_7);
    }
    const Space v1429_9 = intersect(constant_6,v1429_2);
    const Space v1429_10 = (has_head(v1429_9) ? constant_7 : Space{});
    const Space v1429_11 = compose(v1429_10,constant_9);
    const Space v1429_12 = unite(v1429_8,v1429_11);
    v1428_9_result = unite(v1428_9_result,v1429_12);
  }
  const Space v1428_9 = std::move(v1428_9_result);
  return v1428_9;
}

static Space routine_157(Context& c, const Path& p0, const Space& s0) {
  Space v1434_11_result;
  for (int v1434_11_label = 1; v1434_11_label <= 2; ++v1434_11_label) {
    const Space v1434_11_tail = child(s0,v1434_11_label);
    if (v1434_11_tail.empty()) continue;
    const Path v1434_11_head{v1434_11_label};
    const Space v1435_2 = singleton(v1434_11_head);
    const Space v1435_3 = intersect(constant_6,v1435_2);
    const Space v1435_4 = (has_head(v1435_3) ? constant_7 : Space{});
    const Space v1435_5 = subtract(constant_0,v1435_4);
    Space v1435_8;
    if (!v1435_5.empty()) {
      const Path v1436_6 = concat_path(p0,v1434_11_head);
      Space v1436_7_result;
      for (int v1436_7_label = 1; v1436_7_label <= 2; ++v1436_7_label) {
        const Space v1436_7_tail = child(v1434_11_tail,v1436_7_label);
        if (v1436_7_tail.empty()) continue;
        const Path v1436_7_head{v1436_7_label};
        const Space v1437_2 = singleton(v1436_7_head);
        const Space v1437_3 = intersect(constant_6,v1437_2);
        const Space v1437_4 = (has_head(v1437_3) ? constant_7 : Space{});
        const Space v1437_5 = subtract(constant_0,v1437_4);
        Space v1437_8;
        if (!v1437_5.empty()) {
          const Path v1438_6 = concat_path(v1436_6,v1436_7_head);
          const Space v1438_7 = routine_201(c, v1438_6, v1436_7_tail);
          v1437_8 = compose(v1437_5,v1438_7);
        }
        const Space v1437_9 = intersect(constant_6,v1437_2);
        const Space v1437_10 = (has_head(v1437_9) ? constant_7 : Space{});
        Space v1437_12;
        if (!v1437_10.empty()) {
          const Path v1439_6 = concat_path(v1436_6,v1436_7_head);
          const Space v1439_11 = routine_202(c, v1439_6, v1436_7_tail);
          v1437_12 = compose(v1437_10,v1439_11);
        }
        const Space v1437_13 = unite(v1437_8,v1437_12);
        v1436_7_result = unite(v1436_7_result,v1437_13);
      }
      const Space v1436_7 = std::move(v1436_7_result);
      v1435_8 = compose(v1435_5,v1436_7);
    }
    const Space v1435_9 = intersect(constant_6,v1435_2);
    const Space v1435_10 = (has_head(v1435_9) ? constant_7 : Space{});
    Space v1435_12;
    if (!v1435_10.empty()) {
      const Path v1440_6 = concat_path(p0,v1434_11_head);
      Space v1440_11_result;
      for (int v1440_11_label = 1; v1440_11_label <= 2; ++v1440_11_label) {
        const Space v1440_11_tail = child(v1434_11_tail,v1440_11_label);
        if (v1440_11_tail.empty()) continue;
        const Path v1440_11_head{v1440_11_label};
        const Space v1441_2 = singleton(v1440_11_head);
        const Space v1441_3 = intersect(constant_6,v1441_2);
        const Space v1441_4 = (has_head(v1441_3) ? constant_7 : Space{});
        const Space v1441_5 = subtract(constant_0,v1441_4);
        Space v1441_8;
        if (!v1441_5.empty()) {
          const Path v1442_6 = concat_path(v1440_6,v1440_11_head);
          const Space v1442_7 = routine_201(c, v1442_6, v1440_11_tail);
          v1441_8 = compose(v1441_5,v1442_7);
        }
        const Space v1441_9 = intersect(constant_6,v1441_2);
        const Space v1441_10 = (has_head(v1441_9) ? constant_7 : Space{});
        Space v1441_12;
        if (!v1441_10.empty()) {
          const Path v1443_6 = concat_path(v1440_6,v1440_11_head);
          const Space v1443_11 = routine_104(c, v1443_6, v1440_11_tail);
          v1441_12 = compose(v1441_10,v1443_11);
        }
        const Space v1441_13 = unite(v1441_8,v1441_12);
        v1440_11_result = unite(v1440_11_result,v1441_13);
      }
      const Space v1440_11 = std::move(v1440_11_result);
      v1435_12 = compose(v1435_10,v1440_11);
    }
    const Space v1435_13 = unite(v1435_8,v1435_12);
    v1434_11_result = unite(v1434_11_result,v1435_13);
  }
  const Space v1434_11 = std::move(v1434_11_result);
  return v1434_11;
}

static Space routine_158(Context& c, const Path& p0, const Space& s0) {
  Space v1444_9_result;
  for (int v1444_9_label = 1; v1444_9_label <= 2; ++v1444_9_label) {
    const Space v1444_9_tail = child(s0,v1444_9_label);
    if (v1444_9_tail.empty()) continue;
    const Path v1444_9_head{v1444_9_label};
    const Space v1445_2 = singleton(v1444_9_head);
    const Space v1445_3 = intersect(constant_6,v1445_2);
    const Space v1445_4 = (has_head(v1445_3) ? constant_7 : Space{});
    const Space v1445_5 = subtract(constant_0,v1445_4);
    Space v1445_8;
    if (!v1445_5.empty()) {
      const Path v1446_6 = concat_path(p0,v1444_9_head);
      Space v1446_7_result;
      for (int v1446_7_label = 1; v1446_7_label <= 2; ++v1446_7_label) {
        const Space v1446_7_tail = child(v1444_9_tail,v1446_7_label);
        if (v1446_7_tail.empty()) continue;
        const Path v1446_7_head{v1446_7_label};
        const Space v1447_2 = singleton(v1446_7_head);
        const Space v1447_3 = intersect(constant_6,v1447_2);
        const Space v1447_4 = (has_head(v1447_3) ? constant_7 : Space{});
        const Space v1447_5 = subtract(constant_0,v1447_4);
        Space v1447_8;
        if (!v1447_5.empty()) {
          const Path v1448_6 = concat_path(v1446_6,v1446_7_head);
          const Space v1448_7 = routine_201(c, v1448_6, v1446_7_tail);
          v1447_8 = compose(v1447_5,v1448_7);
        }
        const Space v1447_9 = intersect(constant_6,v1447_2);
        const Space v1447_10 = (has_head(v1447_9) ? constant_7 : Space{});
        Space v1447_12;
        if (!v1447_10.empty()) {
          const Path v1449_6 = concat_path(v1446_6,v1446_7_head);
          const Space v1449_11 = routine_202(c, v1449_6, v1446_7_tail);
          v1447_12 = compose(v1447_10,v1449_11);
        }
        const Space v1447_13 = unite(v1447_8,v1447_12);
        v1446_7_result = unite(v1446_7_result,v1447_13);
      }
      const Space v1446_7 = std::move(v1446_7_result);
      v1445_8 = compose(v1445_5,v1446_7);
    }
    const Space v1445_9 = intersect(constant_6,v1445_2);
    const Space v1445_10 = (has_head(v1445_9) ? constant_7 : Space{});
    const Space v1445_11 = compose(v1445_10,constant_9);
    const Space v1445_12 = unite(v1445_8,v1445_11);
    v1444_9_result = unite(v1444_9_result,v1445_12);
  }
  const Space v1444_9 = std::move(v1444_9_result);
  return v1444_9;
}

static Space routine_159(Context& c, const Path& p0, const Space& s0) {
  Space v1450_11_result;
  for (int v1450_11_label = 1; v1450_11_label <= 2; ++v1450_11_label) {
    const Space v1450_11_tail = child(s0,v1450_11_label);
    if (v1450_11_tail.empty()) continue;
    const Path v1450_11_head{v1450_11_label};
    const Space v1451_2 = singleton(v1450_11_head);
    const Space v1451_3 = intersect(constant_6,v1451_2);
    const Space v1451_4 = (has_head(v1451_3) ? constant_7 : Space{});
    const Space v1451_5 = subtract(constant_0,v1451_4);
    Space v1451_8;
    if (!v1451_5.empty()) {
      const Path v1452_6 = concat_path(p0,v1450_11_head);
      Space v1452_7_result;
      for (int v1452_7_label = 1; v1452_7_label <= 2; ++v1452_7_label) {
        const Space v1452_7_tail = child(v1450_11_tail,v1452_7_label);
        if (v1452_7_tail.empty()) continue;
        const Path v1452_7_head{v1452_7_label};
        const Space v1453_2 = singleton(v1452_7_head);
        const Space v1453_3 = intersect(constant_6,v1453_2);
        const Space v1453_4 = (has_head(v1453_3) ? constant_7 : Space{});
        const Space v1453_5 = subtract(constant_0,v1453_4);
        Space v1453_8;
        if (!v1453_5.empty()) {
          const Path v1454_6 = concat_path(v1452_6,v1452_7_head);
          const Space v1454_7 = routine_203(c, v1454_6, v1452_7_tail);
          v1453_8 = compose(v1453_5,v1454_7);
        }
        const Space v1453_9 = intersect(constant_6,v1453_2);
        const Space v1453_10 = (has_head(v1453_9) ? constant_7 : Space{});
        Space v1453_12;
        if (!v1453_10.empty()) {
          const Path v1455_6 = concat_path(v1452_6,v1452_7_head);
          const Space v1455_11 = routine_204(c, v1455_6, v1452_7_tail);
          v1453_12 = compose(v1453_10,v1455_11);
        }
        const Space v1453_13 = unite(v1453_8,v1453_12);
        v1452_7_result = unite(v1452_7_result,v1453_13);
      }
      const Space v1452_7 = std::move(v1452_7_result);
      v1451_8 = compose(v1451_5,v1452_7);
    }
    const Space v1451_9 = intersect(constant_6,v1451_2);
    const Space v1451_10 = (has_head(v1451_9) ? constant_7 : Space{});
    Space v1451_12;
    if (!v1451_10.empty()) {
      const Path v1456_6 = concat_path(p0,v1450_11_head);
      Space v1456_11_result;
      for (int v1456_11_label = 1; v1456_11_label <= 2; ++v1456_11_label) {
        const Space v1456_11_tail = child(v1450_11_tail,v1456_11_label);
        if (v1456_11_tail.empty()) continue;
        const Path v1456_11_head{v1456_11_label};
        const Space v1457_2 = singleton(v1456_11_head);
        const Space v1457_3 = intersect(constant_6,v1457_2);
        const Space v1457_4 = (has_head(v1457_3) ? constant_7 : Space{});
        const Space v1457_5 = subtract(constant_0,v1457_4);
        Space v1457_8;
        if (!v1457_5.empty()) {
          const Path v1458_6 = concat_path(v1456_6,v1456_11_head);
          const Space v1458_7 = routine_203(c, v1458_6, v1456_11_tail);
          v1457_8 = compose(v1457_5,v1458_7);
        }
        const Space v1457_9 = intersect(constant_6,v1457_2);
        const Space v1457_10 = (has_head(v1457_9) ? constant_7 : Space{});
        Space v1457_12;
        if (!v1457_10.empty()) {
          const Path v1459_6 = concat_path(v1456_6,v1456_11_head);
          const Space v1459_11 = routine_107(c, v1459_6, v1456_11_tail);
          v1457_12 = compose(v1457_10,v1459_11);
        }
        const Space v1457_13 = unite(v1457_8,v1457_12);
        v1456_11_result = unite(v1456_11_result,v1457_13);
      }
      const Space v1456_11 = std::move(v1456_11_result);
      v1451_12 = compose(v1451_10,v1456_11);
    }
    const Space v1451_13 = unite(v1451_8,v1451_12);
    v1450_11_result = unite(v1450_11_result,v1451_13);
  }
  const Space v1450_11 = std::move(v1450_11_result);
  return v1450_11;
}

static Space routine_160(Context& c, const Path& p0, const Space& s0) {
  Space v1460_8_result;
  for (int v1460_8_label = 1; v1460_8_label <= 2; ++v1460_8_label) {
    const Space v1460_8_tail = child(s0,v1460_8_label);
    if (v1460_8_tail.empty()) continue;
    const Path v1460_8_head{v1460_8_label};
    const Space v1461_2 = singleton(v1460_8_head);
    const Space v1461_3 = intersect(constant_6,v1461_2);
    const Space v1461_4 = (has_head(v1461_3) ? constant_7 : Space{});
    const Space v1461_5 = subtract(constant_0,v1461_4);
    Space v1461_8;
    if (!v1461_5.empty()) {
      const Path v1462_6 = concat_path(p0,v1460_8_head);
      Space v1462_7_result;
      for (int v1462_7_label = 1; v1462_7_label <= 2; ++v1462_7_label) {
        const Space v1462_7_tail = child(v1460_8_tail,v1462_7_label);
        if (v1462_7_tail.empty()) continue;
        const Path v1462_7_head{v1462_7_label};
        const Space v1463_2 = singleton(v1462_7_head);
        const Space v1463_3 = intersect(constant_6,v1463_2);
        const Space v1463_4 = (has_head(v1463_3) ? constant_7 : Space{});
        const Space v1463_5 = subtract(constant_0,v1463_4);
        Space v1463_8;
        if (!v1463_5.empty()) {
          const Path v1464_6 = concat_path(v1462_6,v1462_7_head);
          const Space v1464_7 = routine_203(c, v1464_6, v1462_7_tail);
          v1463_8 = compose(v1463_5,v1464_7);
        }
        const Space v1463_9 = intersect(constant_6,v1463_2);
        const Space v1463_10 = (has_head(v1463_9) ? constant_7 : Space{});
        Space v1463_12;
        if (!v1463_10.empty()) {
          const Path v1465_6 = concat_path(v1462_6,v1462_7_head);
          const Space v1465_11 = routine_204(c, v1465_6, v1462_7_tail);
          v1463_12 = compose(v1463_10,v1465_11);
        }
        const Space v1463_13 = unite(v1463_8,v1463_12);
        v1462_7_result = unite(v1462_7_result,v1463_13);
      }
      const Space v1462_7 = std::move(v1462_7_result);
      v1461_8 = compose(v1461_5,v1462_7);
    }
    const Space v1461_9 = intersect(constant_6,v1461_2);
    const Space v1461_10 = (has_head(v1461_9) ? constant_7 : Space{});
    const Space v1461_11 = compose(v1461_10,v1460_8_tail);
    const Space v1461_12 = unite(v1461_8,v1461_11);
    v1460_8_result = unite(v1460_8_result,v1461_12);
  }
  const Space v1460_8 = std::move(v1460_8_result);
  return v1460_8;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1466_13_result;
  for (int v1466_13_label = 1; v1466_13_label <= 2; ++v1466_13_label) {
    const Space v1466_13_tail = child(s0,v1466_13_label);
    if (v1466_13_tail.empty()) continue;
    const Path v1466_13_head{v1466_13_label};
    const Space v1467_2 = singleton(v1466_13_head);
    const Space v1467_3 = intersect(constant_6,v1467_2);
    const Space v1467_4 = (has_head(v1467_3) ? constant_7 : Space{});
    const Space v1467_5 = subtract(constant_0,v1467_4);
    Space v1467_8;
    if (!v1467_5.empty()) {
      const Path v1468_6 = concat_path(p0,v1466_13_head);
      Space v1468_7_result;
      for (int v1468_7_label = 1; v1468_7_label <= 2; ++v1468_7_label) {
        const Space v1468_7_tail = child(v1466_13_tail,v1468_7_label);
        if (v1468_7_tail.empty()) continue;
        const Path v1468_7_head{v1468_7_label};
        const Space v1469_2 = singleton(v1468_7_head);
        const Space v1469_3 = intersect(constant_6,v1469_2);
        const Space v1469_4 = (has_head(v1469_3) ? constant_7 : Space{});
        const Space v1469_5 = subtract(constant_0,v1469_4);
        Space v1469_8;
        if (!v1469_5.empty()) {
          const Path v1470_6 = concat_path(v1468_6,v1468_7_head);
          const Space v1470_7 = routine_205(c, v1470_6, p1, v1468_7_tail, s1);
          v1469_8 = compose(v1469_5,v1470_7);
        }
        const Space v1469_9 = intersect(constant_6,v1469_2);
        const Space v1469_10 = (has_head(v1469_9) ? constant_7 : Space{});
        Space v1469_12;
        if (!v1469_10.empty()) {
          const Path v1471_6 = concat_path(v1468_6,v1468_7_head);
          const Space v1471_11 = routine_206(c, v1471_6, p1, v1468_7_tail, s1);
          v1469_12 = compose(v1469_10,v1471_11);
        }
        const Space v1469_13 = unite(v1469_8,v1469_12);
        v1468_7_result = unite(v1468_7_result,v1469_13);
      }
      const Space v1468_7 = std::move(v1468_7_result);
      v1467_8 = compose(v1467_5,v1468_7);
    }
    const Space v1467_9 = intersect(constant_6,v1467_2);
    const Space v1467_10 = (has_head(v1467_9) ? constant_7 : Space{});
    Space v1467_12;
    if (!v1467_10.empty()) {
      const Path v1472_6 = concat_path(p0,v1466_13_head);
      Space v1472_11_result;
      for (int v1472_11_label = 1; v1472_11_label <= 2; ++v1472_11_label) {
        const Space v1472_11_tail = child(v1466_13_tail,v1472_11_label);
        if (v1472_11_tail.empty()) continue;
        const Path v1472_11_head{v1472_11_label};
        const Space v1473_2 = singleton(v1472_11_head);
        const Space v1473_3 = intersect(constant_6,v1473_2);
        const Space v1473_4 = (has_head(v1473_3) ? constant_7 : Space{});
        const Space v1473_5 = subtract(constant_0,v1473_4);
        Space v1473_8;
        if (!v1473_5.empty()) {
          const Path v1474_6 = concat_path(v1472_6,v1472_11_head);
          const Space v1474_7 = routine_205(c, v1474_6, p1, v1472_11_tail, s1);
          v1473_8 = compose(v1473_5,v1474_7);
        }
        const Space v1473_9 = intersect(constant_6,v1473_2);
        const Space v1473_10 = (has_head(v1473_9) ? constant_7 : Space{});
        Space v1473_12;
        if (!v1473_10.empty()) {
          const Path v1475_6 = concat_path(v1472_6,v1472_11_head);
          const Space v1475_11 = routine_49(c, v1475_6, p1, v1472_11_tail, s1);
          v1473_12 = compose(v1473_10,v1475_11);
        }
        const Space v1473_13 = unite(v1473_8,v1473_12);
        v1472_11_result = unite(v1472_11_result,v1473_13);
      }
      const Space v1472_11 = std::move(v1472_11_result);
      v1467_12 = compose(v1467_10,v1472_11);
    }
    const Space v1467_13 = unite(v1467_8,v1467_12);
    v1466_13_result = unite(v1466_13_result,v1467_13);
  }
  const Space v1466_13 = std::move(v1466_13_result);
  return v1466_13;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1476_8 = unwrap(s1,constant_8);
  Space v1476_21_result;
  for (int v1476_21_label = 1; v1476_21_label <= 2; ++v1476_21_label) {
    const Space v1476_21_tail = child(s0,v1476_21_label);
    if (v1476_21_tail.empty()) continue;
    const Path v1476_21_head{v1476_21_label};
    const Space v1477_2 = singleton(v1476_21_head);
    const Space v1477_3 = intersect(constant_6,v1477_2);
    const Space v1477_4 = (has_head(v1477_3) ? constant_7 : Space{});
    const Space v1477_5 = subtract(constant_0,v1477_4);
    Space v1477_8;
    if (!v1477_5.empty()) {
      const Path v1478_6 = concat_path(p0,v1476_21_head);
      Space v1478_7_result;
      for (int v1478_7_label = 1; v1478_7_label <= 2; ++v1478_7_label) {
        const Space v1478_7_tail = child(v1476_21_tail,v1478_7_label);
        if (v1478_7_tail.empty()) continue;
        const Path v1478_7_head{v1478_7_label};
        const Space v1479_2 = singleton(v1478_7_head);
        const Space v1479_3 = intersect(constant_6,v1479_2);
        const Space v1479_4 = (has_head(v1479_3) ? constant_7 : Space{});
        const Space v1479_5 = subtract(constant_0,v1479_4);
        Space v1479_8;
        if (!v1479_5.empty()) {
          const Path v1480_6 = concat_path(v1478_6,v1478_7_head);
          const Space v1480_7 = routine_205(c, v1480_6, p1, v1478_7_tail, s1);
          v1479_8 = compose(v1479_5,v1480_7);
        }
        const Space v1479_9 = intersect(constant_6,v1479_2);
        const Space v1479_10 = (has_head(v1479_9) ? constant_7 : Space{});
        Space v1479_12;
        if (!v1479_10.empty()) {
          const Path v1481_6 = concat_path(v1478_6,v1478_7_head);
          const Space v1481_11 = routine_206(c, v1481_6, p1, v1478_7_tail, s1);
          v1479_12 = compose(v1479_10,v1481_11);
        }
        const Space v1479_13 = unite(v1479_8,v1479_12);
        v1478_7_result = unite(v1478_7_result,v1479_13);
      }
      const Space v1478_7 = std::move(v1478_7_result);
      v1477_8 = compose(v1477_5,v1478_7);
    }
    const Space v1477_9 = intersect(constant_6,v1477_2);
    const Space v1477_10 = (has_head(v1477_9) ? constant_7 : Space{});
    Space v1477_22;
    if (!v1477_10.empty()) {
      const Path v1482_6 = concat_path(p0,v1476_21_head);
      const Path v1482_11 = concat_path(p1,v1482_6);
      const Space v1482_12 = routine_29(c, v1482_11);
      const Space v1482_13 = intersect(v1476_8,v1482_12);
      const Space v1482_14 = routine_33(c, v1482_13);
      Space v1482_15_result;
      for (int v1482_15_label = 1; v1482_15_label <= 2; ++v1482_15_label) {
        const Space v1482_15_tail = child(v1482_14,v1482_15_label);
        if (v1482_15_tail.empty()) continue;
        const Path v1482_15_head{v1482_15_label};
        const Space v1483_2 = singleton(v1482_15_head);
        const Space v1483_3 = intersect(constant_6,v1483_2);
        const Space v1483_4 = (has_head(v1483_3) ? constant_7 : Space{});
        const Space v1483_5 = subtract(constant_0,v1483_4);
        Space v1483_7;
        if (!v1483_5.empty()) {
          const Space v1484_6 = routine_52(c, v1482_15_head, v1482_15_tail);
          v1483_7 = compose(v1483_5,v1484_6);
        }
        const Space v1483_8 = intersect(constant_6,v1483_2);
        const Space v1483_9 = (has_head(v1483_8) ? constant_7 : Space{});
        Space v1483_11;
        if (!v1483_9.empty()) {
          const Space v1485_10 = routine_53(c, v1482_15_head, v1482_15_tail);
          v1483_11 = compose(v1483_9,v1485_10);
        }
        const Space v1483_12 = unite(v1483_7,v1483_11);
        v1482_15_result = unite(v1482_15_result,v1483_12);
      }
      const Space v1482_15 = std::move(v1482_15_result);
      const Space v1482_16 = routine_54(c, v1482_13);
      Space v1482_17_result;
      for (int v1482_17_label = 1; v1482_17_label <= 2; ++v1482_17_label) {
        const Space v1482_17_tail = child(v1482_16,v1482_17_label);
        if (v1482_17_tail.empty()) continue;
        const Path v1482_17_head{v1482_17_label};
        const Space v1486_2 = singleton(v1482_17_head);
        const Space v1486_3 = intersect(constant_6,v1486_2);
        const Space v1486_4 = (has_head(v1486_3) ? constant_7 : Space{});
        const Space v1486_5 = subtract(constant_0,v1486_4);
        Space v1486_7;
        if (!v1486_5.empty()) {
          const Space v1487_6 = routine_55(c, v1482_17_head, v1482_17_tail);
          v1486_7 = compose(v1486_5,v1487_6);
        }
        const Space v1486_8 = intersect(constant_6,v1486_2);
        const Space v1486_9 = (has_head(v1486_8) ? constant_7 : Space{});
        Space v1486_11;
        if (!v1486_9.empty()) {
          const Space v1488_10 = routine_56(c, v1482_17_head, v1482_17_tail);
          v1486_11 = compose(v1486_9,v1488_10);
        }
        const Space v1486_12 = unite(v1486_7,v1486_11);
        v1482_17_result = unite(v1482_17_result,v1486_12);
      }
      const Space v1482_17 = std::move(v1482_17_result);
      const Space v1482_18 = subtract(v1482_15,v1482_17);
      const Space v1482_19 = singleton(v1482_11);
      const Space v1482_20 = compose(v1482_18,v1482_19);
      Space v1482_21_result;
      for (int v1482_21_label = 1; v1482_21_label <= 2; ++v1482_21_label) {
        const Space v1482_21_tail = child(v1482_20,v1482_21_label);
        if (v1482_21_tail.empty()) continue;
        const Path v1482_21_head{v1482_21_label};
        const Space v1489_2 = singleton(v1482_21_head);
        const Space v1489_3 = intersect(constant_6,v1489_2);
        const Space v1489_4 = (has_head(v1489_3) ? constant_7 : Space{});
        const Space v1489_5 = subtract(constant_0,v1489_4);
        Space v1489_7;
        if (!v1489_5.empty()) {
          const Space v1490_6 = routine_57(c, v1482_21_head, v1482_21_tail);
          v1489_7 = compose(v1489_5,v1490_6);
        }
        const Space v1489_8 = intersect(constant_6,v1489_2);
        const Space v1489_9 = (has_head(v1489_8) ? constant_7 : Space{});
        Space v1489_11;
        if (!v1489_9.empty()) {
          const Space v1491_10 = routine_58(c, v1482_21_head, v1482_21_tail);
          v1489_11 = compose(v1489_9,v1491_10);
        }
        const Space v1489_12 = unite(v1489_7,v1489_11);
        v1482_21_result = unite(v1482_21_result,v1489_12);
      }
      const Space v1482_21 = std::move(v1482_21_result);
      v1477_22 = compose(v1477_10,v1482_21);
    }
    const Space v1477_23 = unite(v1477_8,v1477_22);
    v1476_21_result = unite(v1476_21_result,v1477_23);
  }
  const Space v1476_21 = std::move(v1476_21_result);
  return v1476_21;
}

static Space routine_163(Context& c, const Path& p0, const Space& s0) {
  Space v1492_11_result;
  for (int v1492_11_label = 1; v1492_11_label <= 2; ++v1492_11_label) {
    const Space v1492_11_tail = child(s0,v1492_11_label);
    if (v1492_11_tail.empty()) continue;
    const Path v1492_11_head{v1492_11_label};
    const Space v1493_2 = singleton(v1492_11_head);
    const Space v1493_3 = intersect(constant_6,v1493_2);
    const Space v1493_4 = (has_head(v1493_3) ? constant_7 : Space{});
    const Space v1493_5 = subtract(constant_0,v1493_4);
    Space v1493_8;
    if (!v1493_5.empty()) {
      const Path v1494_6 = concat_path(p0,v1492_11_head);
      Space v1494_7_result;
      for (int v1494_7_label = 1; v1494_7_label <= 2; ++v1494_7_label) {
        const Space v1494_7_tail = child(v1492_11_tail,v1494_7_label);
        if (v1494_7_tail.empty()) continue;
        const Path v1494_7_head{v1494_7_label};
        const Space v1495_2 = singleton(v1494_7_head);
        const Space v1495_3 = intersect(constant_6,v1495_2);
        const Space v1495_4 = (has_head(v1495_3) ? constant_7 : Space{});
        const Space v1495_5 = subtract(constant_0,v1495_4);
        Space v1495_8;
        if (!v1495_5.empty()) {
          const Path v1496_6 = concat_path(v1494_6,v1494_7_head);
          const Space v1496_7 = routine_207(c, v1496_6, v1494_7_tail);
          v1495_8 = compose(v1495_5,v1496_7);
        }
        const Space v1495_9 = intersect(constant_6,v1495_2);
        const Space v1495_10 = (has_head(v1495_9) ? constant_7 : Space{});
        Space v1495_12;
        if (!v1495_10.empty()) {
          const Path v1497_6 = concat_path(v1494_6,v1494_7_head);
          const Space v1497_11 = routine_208(c, v1497_6, v1494_7_tail);
          v1495_12 = compose(v1495_10,v1497_11);
        }
        const Space v1495_13 = unite(v1495_8,v1495_12);
        v1494_7_result = unite(v1494_7_result,v1495_13);
      }
      const Space v1494_7 = std::move(v1494_7_result);
      v1493_8 = compose(v1493_5,v1494_7);
    }
    const Space v1493_9 = intersect(constant_6,v1493_2);
    const Space v1493_10 = (has_head(v1493_9) ? constant_7 : Space{});
    Space v1493_12;
    if (!v1493_10.empty()) {
      const Path v1498_6 = concat_path(p0,v1492_11_head);
      Space v1498_11_result;
      for (int v1498_11_label = 1; v1498_11_label <= 2; ++v1498_11_label) {
        const Space v1498_11_tail = child(v1492_11_tail,v1498_11_label);
        if (v1498_11_tail.empty()) continue;
        const Path v1498_11_head{v1498_11_label};
        const Space v1499_2 = singleton(v1498_11_head);
        const Space v1499_3 = intersect(constant_6,v1499_2);
        const Space v1499_4 = (has_head(v1499_3) ? constant_7 : Space{});
        const Space v1499_5 = subtract(constant_0,v1499_4);
        Space v1499_8;
        if (!v1499_5.empty()) {
          const Path v1500_6 = concat_path(v1498_6,v1498_11_head);
          const Space v1500_7 = routine_207(c, v1500_6, v1498_11_tail);
          v1499_8 = compose(v1499_5,v1500_7);
        }
        const Space v1499_9 = intersect(constant_6,v1499_2);
        const Space v1499_10 = (has_head(v1499_9) ? constant_7 : Space{});
        Space v1499_12;
        if (!v1499_10.empty()) {
          const Path v1501_6 = concat_path(v1498_6,v1498_11_head);
          const Space v1501_11 = routine_100(c, v1501_6, v1498_11_tail);
          v1499_12 = compose(v1499_10,v1501_11);
        }
        const Space v1499_13 = unite(v1499_8,v1499_12);
        v1498_11_result = unite(v1498_11_result,v1499_13);
      }
      const Space v1498_11 = std::move(v1498_11_result);
      v1493_12 = compose(v1493_10,v1498_11);
    }
    const Space v1493_13 = unite(v1493_8,v1493_12);
    v1492_11_result = unite(v1492_11_result,v1493_13);
  }
  const Space v1492_11 = std::move(v1492_11_result);
  return v1492_11;
}

static Space routine_164(Context& c, const Path& p0, const Space& s0) {
  Space v1502_9_result;
  for (int v1502_9_label = 1; v1502_9_label <= 2; ++v1502_9_label) {
    const Space v1502_9_tail = child(s0,v1502_9_label);
    if (v1502_9_tail.empty()) continue;
    const Path v1502_9_head{v1502_9_label};
    const Space v1503_2 = singleton(v1502_9_head);
    const Space v1503_3 = intersect(constant_6,v1503_2);
    const Space v1503_4 = (has_head(v1503_3) ? constant_7 : Space{});
    const Space v1503_5 = subtract(constant_0,v1503_4);
    Space v1503_8;
    if (!v1503_5.empty()) {
      const Path v1504_6 = concat_path(p0,v1502_9_head);
      Space v1504_7_result;
      for (int v1504_7_label = 1; v1504_7_label <= 2; ++v1504_7_label) {
        const Space v1504_7_tail = child(v1502_9_tail,v1504_7_label);
        if (v1504_7_tail.empty()) continue;
        const Path v1504_7_head{v1504_7_label};
        const Space v1505_2 = singleton(v1504_7_head);
        const Space v1505_3 = intersect(constant_6,v1505_2);
        const Space v1505_4 = (has_head(v1505_3) ? constant_7 : Space{});
        const Space v1505_5 = subtract(constant_0,v1505_4);
        Space v1505_8;
        if (!v1505_5.empty()) {
          const Path v1506_6 = concat_path(v1504_6,v1504_7_head);
          const Space v1506_7 = routine_207(c, v1506_6, v1504_7_tail);
          v1505_8 = compose(v1505_5,v1506_7);
        }
        const Space v1505_9 = intersect(constant_6,v1505_2);
        const Space v1505_10 = (has_head(v1505_9) ? constant_7 : Space{});
        Space v1505_12;
        if (!v1505_10.empty()) {
          const Path v1507_6 = concat_path(v1504_6,v1504_7_head);
          const Space v1507_11 = routine_208(c, v1507_6, v1504_7_tail);
          v1505_12 = compose(v1505_10,v1507_11);
        }
        const Space v1505_13 = unite(v1505_8,v1505_12);
        v1504_7_result = unite(v1504_7_result,v1505_13);
      }
      const Space v1504_7 = std::move(v1504_7_result);
      v1503_8 = compose(v1503_5,v1504_7);
    }
    const Space v1503_9 = intersect(constant_6,v1503_2);
    const Space v1503_10 = (has_head(v1503_9) ? constant_7 : Space{});
    const Space v1503_11 = compose(v1503_10,constant_9);
    const Space v1503_12 = unite(v1503_8,v1503_11);
    v1502_9_result = unite(v1502_9_result,v1503_12);
  }
  const Space v1502_9 = std::move(v1502_9_result);
  return v1502_9;
}

static Space routine_165(Context& c, const Path& p0, const Space& s0) {
  Space v1508_11_result;
  for (int v1508_11_label = 1; v1508_11_label <= 2; ++v1508_11_label) {
    const Space v1508_11_tail = child(s0,v1508_11_label);
    if (v1508_11_tail.empty()) continue;
    const Path v1508_11_head{v1508_11_label};
    const Space v1509_2 = singleton(v1508_11_head);
    const Space v1509_3 = intersect(constant_6,v1509_2);
    const Space v1509_4 = (has_head(v1509_3) ? constant_7 : Space{});
    const Space v1509_5 = subtract(constant_0,v1509_4);
    Space v1509_8;
    if (!v1509_5.empty()) {
      const Path v1510_6 = concat_path(p0,v1508_11_head);
      Space v1510_7_result;
      for (int v1510_7_label = 1; v1510_7_label <= 2; ++v1510_7_label) {
        const Space v1510_7_tail = child(v1508_11_tail,v1510_7_label);
        if (v1510_7_tail.empty()) continue;
        const Path v1510_7_head{v1510_7_label};
        const Space v1511_2 = singleton(v1510_7_head);
        const Space v1511_3 = intersect(constant_6,v1511_2);
        const Space v1511_4 = (has_head(v1511_3) ? constant_7 : Space{});
        const Space v1511_5 = subtract(constant_0,v1511_4);
        Space v1511_8;
        if (!v1511_5.empty()) {
          const Path v1512_6 = concat_path(v1510_6,v1510_7_head);
          const Space v1512_7 = routine_209(c, v1512_6, v1510_7_tail);
          v1511_8 = compose(v1511_5,v1512_7);
        }
        const Space v1511_9 = intersect(constant_6,v1511_2);
        const Space v1511_10 = (has_head(v1511_9) ? constant_7 : Space{});
        Space v1511_12;
        if (!v1511_10.empty()) {
          const Path v1513_6 = concat_path(v1510_6,v1510_7_head);
          const Space v1513_11 = routine_210(c, v1513_6, v1510_7_tail);
          v1511_12 = compose(v1511_10,v1513_11);
        }
        const Space v1511_13 = unite(v1511_8,v1511_12);
        v1510_7_result = unite(v1510_7_result,v1511_13);
      }
      const Space v1510_7 = std::move(v1510_7_result);
      v1509_8 = compose(v1509_5,v1510_7);
    }
    const Space v1509_9 = intersect(constant_6,v1509_2);
    const Space v1509_10 = (has_head(v1509_9) ? constant_7 : Space{});
    Space v1509_12;
    if (!v1509_10.empty()) {
      const Path v1514_6 = concat_path(p0,v1508_11_head);
      Space v1514_11_result;
      for (int v1514_11_label = 1; v1514_11_label <= 2; ++v1514_11_label) {
        const Space v1514_11_tail = child(v1508_11_tail,v1514_11_label);
        if (v1514_11_tail.empty()) continue;
        const Path v1514_11_head{v1514_11_label};
        const Space v1515_2 = singleton(v1514_11_head);
        const Space v1515_3 = intersect(constant_6,v1515_2);
        const Space v1515_4 = (has_head(v1515_3) ? constant_7 : Space{});
        const Space v1515_5 = subtract(constant_0,v1515_4);
        Space v1515_8;
        if (!v1515_5.empty()) {
          const Path v1516_6 = concat_path(v1514_6,v1514_11_head);
          const Space v1516_7 = routine_209(c, v1516_6, v1514_11_tail);
          v1515_8 = compose(v1515_5,v1516_7);
        }
        const Space v1515_9 = intersect(constant_6,v1515_2);
        const Space v1515_10 = (has_head(v1515_9) ? constant_7 : Space{});
        Space v1515_12;
        if (!v1515_10.empty()) {
          const Path v1517_6 = concat_path(v1514_6,v1514_11_head);
          const Space v1517_11 = routine_104(c, v1517_6, v1514_11_tail);
          v1515_12 = compose(v1515_10,v1517_11);
        }
        const Space v1515_13 = unite(v1515_8,v1515_12);
        v1514_11_result = unite(v1514_11_result,v1515_13);
      }
      const Space v1514_11 = std::move(v1514_11_result);
      v1509_12 = compose(v1509_10,v1514_11);
    }
    const Space v1509_13 = unite(v1509_8,v1509_12);
    v1508_11_result = unite(v1508_11_result,v1509_13);
  }
  const Space v1508_11 = std::move(v1508_11_result);
  return v1508_11;
}

static Space routine_166(Context& c, const Path& p0, const Space& s0) {
  Space v1518_9_result;
  for (int v1518_9_label = 1; v1518_9_label <= 2; ++v1518_9_label) {
    const Space v1518_9_tail = child(s0,v1518_9_label);
    if (v1518_9_tail.empty()) continue;
    const Path v1518_9_head{v1518_9_label};
    const Space v1519_2 = singleton(v1518_9_head);
    const Space v1519_3 = intersect(constant_6,v1519_2);
    const Space v1519_4 = (has_head(v1519_3) ? constant_7 : Space{});
    const Space v1519_5 = subtract(constant_0,v1519_4);
    Space v1519_8;
    if (!v1519_5.empty()) {
      const Path v1520_6 = concat_path(p0,v1518_9_head);
      Space v1520_7_result;
      for (int v1520_7_label = 1; v1520_7_label <= 2; ++v1520_7_label) {
        const Space v1520_7_tail = child(v1518_9_tail,v1520_7_label);
        if (v1520_7_tail.empty()) continue;
        const Path v1520_7_head{v1520_7_label};
        const Space v1521_2 = singleton(v1520_7_head);
        const Space v1521_3 = intersect(constant_6,v1521_2);
        const Space v1521_4 = (has_head(v1521_3) ? constant_7 : Space{});
        const Space v1521_5 = subtract(constant_0,v1521_4);
        Space v1521_8;
        if (!v1521_5.empty()) {
          const Path v1522_6 = concat_path(v1520_6,v1520_7_head);
          const Space v1522_7 = routine_209(c, v1522_6, v1520_7_tail);
          v1521_8 = compose(v1521_5,v1522_7);
        }
        const Space v1521_9 = intersect(constant_6,v1521_2);
        const Space v1521_10 = (has_head(v1521_9) ? constant_7 : Space{});
        Space v1521_12;
        if (!v1521_10.empty()) {
          const Path v1523_6 = concat_path(v1520_6,v1520_7_head);
          const Space v1523_11 = routine_210(c, v1523_6, v1520_7_tail);
          v1521_12 = compose(v1521_10,v1523_11);
        }
        const Space v1521_13 = unite(v1521_8,v1521_12);
        v1520_7_result = unite(v1520_7_result,v1521_13);
      }
      const Space v1520_7 = std::move(v1520_7_result);
      v1519_8 = compose(v1519_5,v1520_7);
    }
    const Space v1519_9 = intersect(constant_6,v1519_2);
    const Space v1519_10 = (has_head(v1519_9) ? constant_7 : Space{});
    const Space v1519_11 = compose(v1519_10,constant_9);
    const Space v1519_12 = unite(v1519_8,v1519_11);
    v1518_9_result = unite(v1518_9_result,v1519_12);
  }
  const Space v1518_9 = std::move(v1518_9_result);
  return v1518_9;
}

static Space routine_167(Context& c, const Path& p0, const Space& s0) {
  Space v1524_11_result;
  for (int v1524_11_label = 1; v1524_11_label <= 2; ++v1524_11_label) {
    const Space v1524_11_tail = child(s0,v1524_11_label);
    if (v1524_11_tail.empty()) continue;
    const Path v1524_11_head{v1524_11_label};
    const Space v1525_2 = singleton(v1524_11_head);
    const Space v1525_3 = intersect(constant_6,v1525_2);
    const Space v1525_4 = (has_head(v1525_3) ? constant_7 : Space{});
    const Space v1525_5 = subtract(constant_0,v1525_4);
    Space v1525_8;
    if (!v1525_5.empty()) {
      const Path v1526_6 = concat_path(p0,v1524_11_head);
      Space v1526_7_result;
      for (int v1526_7_label = 1; v1526_7_label <= 2; ++v1526_7_label) {
        const Space v1526_7_tail = child(v1524_11_tail,v1526_7_label);
        if (v1526_7_tail.empty()) continue;
        const Path v1526_7_head{v1526_7_label};
        const Space v1527_2 = singleton(v1526_7_head);
        const Space v1527_3 = intersect(constant_6,v1527_2);
        const Space v1527_4 = (has_head(v1527_3) ? constant_7 : Space{});
        const Space v1527_5 = subtract(constant_0,v1527_4);
        Space v1527_8;
        if (!v1527_5.empty()) {
          const Path v1528_6 = concat_path(v1526_6,v1526_7_head);
          const Space v1528_7 = routine_211(c, v1528_6, v1526_7_tail);
          v1527_8 = compose(v1527_5,v1528_7);
        }
        const Space v1527_9 = intersect(constant_6,v1527_2);
        const Space v1527_10 = (has_head(v1527_9) ? constant_7 : Space{});
        Space v1527_12;
        if (!v1527_10.empty()) {
          const Path v1529_6 = concat_path(v1526_6,v1526_7_head);
          const Space v1529_11 = routine_212(c, v1529_6, v1526_7_tail);
          v1527_12 = compose(v1527_10,v1529_11);
        }
        const Space v1527_13 = unite(v1527_8,v1527_12);
        v1526_7_result = unite(v1526_7_result,v1527_13);
      }
      const Space v1526_7 = std::move(v1526_7_result);
      v1525_8 = compose(v1525_5,v1526_7);
    }
    const Space v1525_9 = intersect(constant_6,v1525_2);
    const Space v1525_10 = (has_head(v1525_9) ? constant_7 : Space{});
    Space v1525_12;
    if (!v1525_10.empty()) {
      const Path v1530_6 = concat_path(p0,v1524_11_head);
      Space v1530_11_result;
      for (int v1530_11_label = 1; v1530_11_label <= 2; ++v1530_11_label) {
        const Space v1530_11_tail = child(v1524_11_tail,v1530_11_label);
        if (v1530_11_tail.empty()) continue;
        const Path v1530_11_head{v1530_11_label};
        const Space v1531_2 = singleton(v1530_11_head);
        const Space v1531_3 = intersect(constant_6,v1531_2);
        const Space v1531_4 = (has_head(v1531_3) ? constant_7 : Space{});
        const Space v1531_5 = subtract(constant_0,v1531_4);
        Space v1531_8;
        if (!v1531_5.empty()) {
          const Path v1532_6 = concat_path(v1530_6,v1530_11_head);
          const Space v1532_7 = routine_211(c, v1532_6, v1530_11_tail);
          v1531_8 = compose(v1531_5,v1532_7);
        }
        const Space v1531_9 = intersect(constant_6,v1531_2);
        const Space v1531_10 = (has_head(v1531_9) ? constant_7 : Space{});
        Space v1531_12;
        if (!v1531_10.empty()) {
          const Path v1533_6 = concat_path(v1530_6,v1530_11_head);
          const Space v1533_11 = routine_107(c, v1533_6, v1530_11_tail);
          v1531_12 = compose(v1531_10,v1533_11);
        }
        const Space v1531_13 = unite(v1531_8,v1531_12);
        v1530_11_result = unite(v1530_11_result,v1531_13);
      }
      const Space v1530_11 = std::move(v1530_11_result);
      v1525_12 = compose(v1525_10,v1530_11);
    }
    const Space v1525_13 = unite(v1525_8,v1525_12);
    v1524_11_result = unite(v1524_11_result,v1525_13);
  }
  const Space v1524_11 = std::move(v1524_11_result);
  return v1524_11;
}

static Space routine_168(Context& c, const Path& p0, const Space& s0) {
  Space v1534_8_result;
  for (int v1534_8_label = 1; v1534_8_label <= 2; ++v1534_8_label) {
    const Space v1534_8_tail = child(s0,v1534_8_label);
    if (v1534_8_tail.empty()) continue;
    const Path v1534_8_head{v1534_8_label};
    const Space v1535_2 = singleton(v1534_8_head);
    const Space v1535_3 = intersect(constant_6,v1535_2);
    const Space v1535_4 = (has_head(v1535_3) ? constant_7 : Space{});
    const Space v1535_5 = subtract(constant_0,v1535_4);
    Space v1535_8;
    if (!v1535_5.empty()) {
      const Path v1536_6 = concat_path(p0,v1534_8_head);
      Space v1536_7_result;
      for (int v1536_7_label = 1; v1536_7_label <= 2; ++v1536_7_label) {
        const Space v1536_7_tail = child(v1534_8_tail,v1536_7_label);
        if (v1536_7_tail.empty()) continue;
        const Path v1536_7_head{v1536_7_label};
        const Space v1537_2 = singleton(v1536_7_head);
        const Space v1537_3 = intersect(constant_6,v1537_2);
        const Space v1537_4 = (has_head(v1537_3) ? constant_7 : Space{});
        const Space v1537_5 = subtract(constant_0,v1537_4);
        Space v1537_8;
        if (!v1537_5.empty()) {
          const Path v1538_6 = concat_path(v1536_6,v1536_7_head);
          const Space v1538_7 = routine_211(c, v1538_6, v1536_7_tail);
          v1537_8 = compose(v1537_5,v1538_7);
        }
        const Space v1537_9 = intersect(constant_6,v1537_2);
        const Space v1537_10 = (has_head(v1537_9) ? constant_7 : Space{});
        Space v1537_12;
        if (!v1537_10.empty()) {
          const Path v1539_6 = concat_path(v1536_6,v1536_7_head);
          const Space v1539_11 = routine_212(c, v1539_6, v1536_7_tail);
          v1537_12 = compose(v1537_10,v1539_11);
        }
        const Space v1537_13 = unite(v1537_8,v1537_12);
        v1536_7_result = unite(v1536_7_result,v1537_13);
      }
      const Space v1536_7 = std::move(v1536_7_result);
      v1535_8 = compose(v1535_5,v1536_7);
    }
    const Space v1535_9 = intersect(constant_6,v1535_2);
    const Space v1535_10 = (has_head(v1535_9) ? constant_7 : Space{});
    const Space v1535_11 = compose(v1535_10,v1534_8_tail);
    const Space v1535_12 = unite(v1535_8,v1535_11);
    v1534_8_result = unite(v1534_8_result,v1535_12);
  }
  const Space v1534_8 = std::move(v1534_8_result);
  return v1534_8;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1540_13_result;
  for (int v1540_13_label = 1; v1540_13_label <= 2; ++v1540_13_label) {
    const Space v1540_13_tail = child(s0,v1540_13_label);
    if (v1540_13_tail.empty()) continue;
    const Path v1540_13_head{v1540_13_label};
    const Space v1541_2 = singleton(v1540_13_head);
    const Space v1541_3 = intersect(constant_6,v1541_2);
    const Space v1541_4 = (has_head(v1541_3) ? constant_7 : Space{});
    const Space v1541_5 = subtract(constant_0,v1541_4);
    Space v1541_8;
    if (!v1541_5.empty()) {
      const Path v1542_6 = concat_path(p0,v1540_13_head);
      Space v1542_7_result;
      for (int v1542_7_label = 1; v1542_7_label <= 2; ++v1542_7_label) {
        const Space v1542_7_tail = child(v1540_13_tail,v1542_7_label);
        if (v1542_7_tail.empty()) continue;
        const Path v1542_7_head{v1542_7_label};
        const Space v1543_2 = singleton(v1542_7_head);
        const Space v1543_3 = intersect(constant_6,v1543_2);
        const Space v1543_4 = (has_head(v1543_3) ? constant_7 : Space{});
        const Space v1543_5 = subtract(constant_0,v1543_4);
        Space v1543_8;
        if (!v1543_5.empty()) {
          const Path v1544_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1544_7 = routine_213(c, v1544_6, p1, v1542_7_tail, s1);
          v1543_8 = compose(v1543_5,v1544_7);
        }
        const Space v1543_9 = intersect(constant_6,v1543_2);
        const Space v1543_10 = (has_head(v1543_9) ? constant_7 : Space{});
        Space v1543_12;
        if (!v1543_10.empty()) {
          const Path v1545_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1545_11 = routine_214(c, v1545_6, p1, v1542_7_tail, s1);
          v1543_12 = compose(v1543_10,v1545_11);
        }
        const Space v1543_13 = unite(v1543_8,v1543_12);
        v1542_7_result = unite(v1542_7_result,v1543_13);
      }
      const Space v1542_7 = std::move(v1542_7_result);
      v1541_8 = compose(v1541_5,v1542_7);
    }
    const Space v1541_9 = intersect(constant_6,v1541_2);
    const Space v1541_10 = (has_head(v1541_9) ? constant_7 : Space{});
    Space v1541_12;
    if (!v1541_10.empty()) {
      const Path v1546_6 = concat_path(p0,v1540_13_head);
      Space v1546_11_result;
      for (int v1546_11_label = 1; v1546_11_label <= 2; ++v1546_11_label) {
        const Space v1546_11_tail = child(v1540_13_tail,v1546_11_label);
        if (v1546_11_tail.empty()) continue;
        const Path v1546_11_head{v1546_11_label};
        const Space v1547_2 = singleton(v1546_11_head);
        const Space v1547_3 = intersect(constant_6,v1547_2);
        const Space v1547_4 = (has_head(v1547_3) ? constant_7 : Space{});
        const Space v1547_5 = subtract(constant_0,v1547_4);
        Space v1547_8;
        if (!v1547_5.empty()) {
          const Path v1548_6 = concat_path(v1546_6,v1546_11_head);
          const Space v1548_7 = routine_213(c, v1548_6, p1, v1546_11_tail, s1);
          v1547_8 = compose(v1547_5,v1548_7);
        }
        const Space v1547_9 = intersect(constant_6,v1547_2);
        const Space v1547_10 = (has_head(v1547_9) ? constant_7 : Space{});
        Space v1547_12;
        if (!v1547_10.empty()) {
          const Path v1549_6 = concat_path(v1546_6,v1546_11_head);
          const Space v1549_11 = routine_26(c, v1549_6, p1, v1546_11_tail, s1);
          v1547_12 = compose(v1547_10,v1549_11);
        }
        const Space v1547_13 = unite(v1547_8,v1547_12);
        v1546_11_result = unite(v1546_11_result,v1547_13);
      }
      const Space v1546_11 = std::move(v1546_11_result);
      v1541_12 = compose(v1541_10,v1546_11);
    }
    const Space v1541_13 = unite(v1541_8,v1541_12);
    v1540_13_result = unite(v1540_13_result,v1541_13);
  }
  const Space v1540_13 = std::move(v1540_13_result);
  return v1540_13;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1550_8 = unwrap(s1,constant_8);
  Space v1550_21_result;
  for (int v1550_21_label = 1; v1550_21_label <= 2; ++v1550_21_label) {
    const Space v1550_21_tail = child(s0,v1550_21_label);
    if (v1550_21_tail.empty()) continue;
    const Path v1550_21_head{v1550_21_label};
    const Space v1551_2 = singleton(v1550_21_head);
    const Space v1551_3 = intersect(constant_6,v1551_2);
    const Space v1551_4 = (has_head(v1551_3) ? constant_7 : Space{});
    const Space v1551_5 = subtract(constant_0,v1551_4);
    Space v1551_8;
    if (!v1551_5.empty()) {
      const Path v1552_6 = concat_path(p0,v1550_21_head);
      Space v1552_7_result;
      for (int v1552_7_label = 1; v1552_7_label <= 2; ++v1552_7_label) {
        const Space v1552_7_tail = child(v1550_21_tail,v1552_7_label);
        if (v1552_7_tail.empty()) continue;
        const Path v1552_7_head{v1552_7_label};
        const Space v1553_2 = singleton(v1552_7_head);
        const Space v1553_3 = intersect(constant_6,v1553_2);
        const Space v1553_4 = (has_head(v1553_3) ? constant_7 : Space{});
        const Space v1553_5 = subtract(constant_0,v1553_4);
        Space v1553_8;
        if (!v1553_5.empty()) {
          const Path v1554_6 = concat_path(v1552_6,v1552_7_head);
          const Space v1554_7 = routine_213(c, v1554_6, p1, v1552_7_tail, s1);
          v1553_8 = compose(v1553_5,v1554_7);
        }
        const Space v1553_9 = intersect(constant_6,v1553_2);
        const Space v1553_10 = (has_head(v1553_9) ? constant_7 : Space{});
        Space v1553_12;
        if (!v1553_10.empty()) {
          const Path v1555_6 = concat_path(v1552_6,v1552_7_head);
          const Space v1555_11 = routine_214(c, v1555_6, p1, v1552_7_tail, s1);
          v1553_12 = compose(v1553_10,v1555_11);
        }
        const Space v1553_13 = unite(v1553_8,v1553_12);
        v1552_7_result = unite(v1552_7_result,v1553_13);
      }
      const Space v1552_7 = std::move(v1552_7_result);
      v1551_8 = compose(v1551_5,v1552_7);
    }
    const Space v1551_9 = intersect(constant_6,v1551_2);
    const Space v1551_10 = (has_head(v1551_9) ? constant_7 : Space{});
    Space v1551_22;
    if (!v1551_10.empty()) {
      const Path v1556_6 = concat_path(p0,v1550_21_head);
      const Path v1556_11 = concat_path(p1,v1556_6);
      const Space v1556_12 = routine_29(c, v1556_11);
      const Space v1556_13 = intersect(v1550_8,v1556_12);
      const Space v1556_14 = routine_30(c, v1556_13);
      Space v1556_15_result;
      for (int v1556_15_label = 1; v1556_15_label <= 2; ++v1556_15_label) {
        const Space v1556_15_tail = child(v1556_14,v1556_15_label);
        if (v1556_15_tail.empty()) continue;
        const Path v1556_15_head{v1556_15_label};
        const Space v1557_2 = singleton(v1556_15_head);
        const Space v1557_3 = intersect(constant_6,v1557_2);
        const Space v1557_4 = (has_head(v1557_3) ? constant_7 : Space{});
        const Space v1557_5 = subtract(constant_0,v1557_4);
        Space v1557_7;
        if (!v1557_5.empty()) {
          const Space v1558_6 = routine_31(c, v1556_15_head, v1556_15_tail);
          v1557_7 = compose(v1557_5,v1558_6);
        }
        const Space v1557_8 = intersect(constant_6,v1557_2);
        const Space v1557_9 = (has_head(v1557_8) ? constant_7 : Space{});
        Space v1557_11;
        if (!v1557_9.empty()) {
          const Space v1559_10 = routine_32(c, v1556_15_head, v1556_15_tail);
          v1557_11 = compose(v1557_9,v1559_10);
        }
        const Space v1557_12 = unite(v1557_7,v1557_11);
        v1556_15_result = unite(v1556_15_result,v1557_12);
      }
      const Space v1556_15 = std::move(v1556_15_result);
      const Space v1556_16 = routine_33(c, v1556_13);
      Space v1556_17_result;
      for (int v1556_17_label = 1; v1556_17_label <= 2; ++v1556_17_label) {
        const Space v1556_17_tail = child(v1556_16,v1556_17_label);
        if (v1556_17_tail.empty()) continue;
        const Path v1556_17_head{v1556_17_label};
        const Space v1560_2 = singleton(v1556_17_head);
        const Space v1560_3 = intersect(constant_6,v1560_2);
        const Space v1560_4 = (has_head(v1560_3) ? constant_7 : Space{});
        const Space v1560_5 = subtract(constant_0,v1560_4);
        Space v1560_7;
        if (!v1560_5.empty()) {
          const Space v1561_6 = routine_34(c, v1556_17_head, v1556_17_tail);
          v1560_7 = compose(v1560_5,v1561_6);
        }
        const Space v1560_8 = intersect(constant_6,v1560_2);
        const Space v1560_9 = (has_head(v1560_8) ? constant_7 : Space{});
        Space v1560_11;
        if (!v1560_9.empty()) {
          const Space v1562_10 = routine_35(c, v1556_17_head, v1556_17_tail);
          v1560_11 = compose(v1560_9,v1562_10);
        }
        const Space v1560_12 = unite(v1560_7,v1560_11);
        v1556_17_result = unite(v1556_17_result,v1560_12);
      }
      const Space v1556_17 = std::move(v1556_17_result);
      const Space v1556_18 = subtract(v1556_15,v1556_17);
      const Space v1556_19 = singleton(v1556_11);
      const Space v1556_20 = compose(v1556_18,v1556_19);
      Space v1556_21_result;
      for (int v1556_21_label = 1; v1556_21_label <= 2; ++v1556_21_label) {
        const Space v1556_21_tail = child(v1556_20,v1556_21_label);
        if (v1556_21_tail.empty()) continue;
        const Path v1556_21_head{v1556_21_label};
        const Space v1563_2 = singleton(v1556_21_head);
        const Space v1563_3 = intersect(constant_6,v1563_2);
        const Space v1563_4 = (has_head(v1563_3) ? constant_7 : Space{});
        const Space v1563_5 = subtract(constant_0,v1563_4);
        Space v1563_7;
        if (!v1563_5.empty()) {
          const Space v1564_6 = routine_36(c, v1556_21_head, v1556_21_tail);
          v1563_7 = compose(v1563_5,v1564_6);
        }
        const Space v1563_8 = intersect(constant_6,v1563_2);
        const Space v1563_9 = (has_head(v1563_8) ? constant_7 : Space{});
        Space v1563_11;
        if (!v1563_9.empty()) {
          const Space v1565_10 = routine_37(c, v1556_21_head, v1556_21_tail);
          v1563_11 = compose(v1563_9,v1565_10);
        }
        const Space v1563_12 = unite(v1563_7,v1563_11);
        v1556_21_result = unite(v1556_21_result,v1563_12);
      }
      const Space v1556_21 = std::move(v1556_21_result);
      v1551_22 = compose(v1551_10,v1556_21);
    }
    const Space v1551_23 = unite(v1551_8,v1551_22);
    v1550_21_result = unite(v1550_21_result,v1551_23);
  }
  const Space v1550_21 = std::move(v1550_21_result);
  return v1550_21;
}

static Space routine_171(Context& c, const Path& p0, const Space& s0) {
  Space v1566_11_result;
  for (int v1566_11_label = 1; v1566_11_label <= 2; ++v1566_11_label) {
    const Space v1566_11_tail = child(s0,v1566_11_label);
    if (v1566_11_tail.empty()) continue;
    const Path v1566_11_head{v1566_11_label};
    const Space v1567_2 = singleton(v1566_11_head);
    const Space v1567_3 = intersect(constant_6,v1567_2);
    const Space v1567_4 = (has_head(v1567_3) ? constant_7 : Space{});
    const Space v1567_5 = subtract(constant_0,v1567_4);
    Space v1567_8;
    if (!v1567_5.empty()) {
      const Path v1568_6 = concat_path(p0,v1566_11_head);
      Space v1568_7_result;
      for (int v1568_7_label = 1; v1568_7_label <= 2; ++v1568_7_label) {
        const Space v1568_7_tail = child(v1566_11_tail,v1568_7_label);
        if (v1568_7_tail.empty()) continue;
        const Path v1568_7_head{v1568_7_label};
        const Space v1569_2 = singleton(v1568_7_head);
        const Space v1569_3 = intersect(constant_6,v1569_2);
        const Space v1569_4 = (has_head(v1569_3) ? constant_7 : Space{});
        const Space v1569_5 = subtract(constant_0,v1569_4);
        Space v1569_8;
        if (!v1569_5.empty()) {
          const Path v1570_6 = concat_path(v1568_6,v1568_7_head);
          const Space v1570_7 = routine_215(c, v1570_6, v1568_7_tail);
          v1569_8 = compose(v1569_5,v1570_7);
        }
        const Space v1569_9 = intersect(constant_6,v1569_2);
        const Space v1569_10 = (has_head(v1569_9) ? constant_7 : Space{});
        Space v1569_12;
        if (!v1569_10.empty()) {
          const Path v1571_6 = concat_path(v1568_6,v1568_7_head);
          const Space v1571_11 = routine_216(c, v1571_6, v1568_7_tail);
          v1569_12 = compose(v1569_10,v1571_11);
        }
        const Space v1569_13 = unite(v1569_8,v1569_12);
        v1568_7_result = unite(v1568_7_result,v1569_13);
      }
      const Space v1568_7 = std::move(v1568_7_result);
      v1567_8 = compose(v1567_5,v1568_7);
    }
    const Space v1567_9 = intersect(constant_6,v1567_2);
    const Space v1567_10 = (has_head(v1567_9) ? constant_7 : Space{});
    Space v1567_12;
    if (!v1567_10.empty()) {
      const Path v1572_6 = concat_path(p0,v1566_11_head);
      Space v1572_11_result;
      for (int v1572_11_label = 1; v1572_11_label <= 2; ++v1572_11_label) {
        const Space v1572_11_tail = child(v1566_11_tail,v1572_11_label);
        if (v1572_11_tail.empty()) continue;
        const Path v1572_11_head{v1572_11_label};
        const Space v1573_2 = singleton(v1572_11_head);
        const Space v1573_3 = intersect(constant_6,v1573_2);
        const Space v1573_4 = (has_head(v1573_3) ? constant_7 : Space{});
        const Space v1573_5 = subtract(constant_0,v1573_4);
        Space v1573_8;
        if (!v1573_5.empty()) {
          const Path v1574_6 = concat_path(v1572_6,v1572_11_head);
          const Space v1574_7 = routine_215(c, v1574_6, v1572_11_tail);
          v1573_8 = compose(v1573_5,v1574_7);
        }
        const Space v1573_9 = intersect(constant_6,v1573_2);
        const Space v1573_10 = (has_head(v1573_9) ? constant_7 : Space{});
        Space v1573_12;
        if (!v1573_10.empty()) {
          const Path v1575_6 = concat_path(v1572_6,v1572_11_head);
          const Space v1575_11 = routine_80(c, v1575_6, v1572_11_tail);
          v1573_12 = compose(v1573_10,v1575_11);
        }
        const Space v1573_13 = unite(v1573_8,v1573_12);
        v1572_11_result = unite(v1572_11_result,v1573_13);
      }
      const Space v1572_11 = std::move(v1572_11_result);
      v1567_12 = compose(v1567_10,v1572_11);
    }
    const Space v1567_13 = unite(v1567_8,v1567_12);
    v1566_11_result = unite(v1566_11_result,v1567_13);
  }
  const Space v1566_11 = std::move(v1566_11_result);
  return v1566_11;
}

static Space routine_172(Context& c, const Path& p0, const Space& s0) {
  Space v1576_11_result;
  for (int v1576_11_label = 1; v1576_11_label <= 2; ++v1576_11_label) {
    const Space v1576_11_tail = child(s0,v1576_11_label);
    if (v1576_11_tail.empty()) continue;
    const Path v1576_11_head{v1576_11_label};
    const Space v1577_2 = singleton(v1576_11_head);
    const Space v1577_3 = intersect(constant_6,v1577_2);
    const Space v1577_4 = (has_head(v1577_3) ? constant_7 : Space{});
    const Space v1577_5 = subtract(constant_0,v1577_4);
    Space v1577_8;
    if (!v1577_5.empty()) {
      const Path v1578_6 = concat_path(p0,v1576_11_head);
      Space v1578_7_result;
      for (int v1578_7_label = 1; v1578_7_label <= 2; ++v1578_7_label) {
        const Space v1578_7_tail = child(v1576_11_tail,v1578_7_label);
        if (v1578_7_tail.empty()) continue;
        const Path v1578_7_head{v1578_7_label};
        const Space v1579_2 = singleton(v1578_7_head);
        const Space v1579_3 = intersect(constant_6,v1579_2);
        const Space v1579_4 = (has_head(v1579_3) ? constant_7 : Space{});
        const Space v1579_5 = subtract(constant_0,v1579_4);
        Space v1579_8;
        if (!v1579_5.empty()) {
          const Path v1580_6 = concat_path(v1578_6,v1578_7_head);
          const Space v1580_7 = routine_215(c, v1580_6, v1578_7_tail);
          v1579_8 = compose(v1579_5,v1580_7);
        }
        const Space v1579_9 = intersect(constant_6,v1579_2);
        const Space v1579_10 = (has_head(v1579_9) ? constant_7 : Space{});
        Space v1579_12;
        if (!v1579_10.empty()) {
          const Path v1581_6 = concat_path(v1578_6,v1578_7_head);
          const Space v1581_11 = routine_216(c, v1581_6, v1578_7_tail);
          v1579_12 = compose(v1579_10,v1581_11);
        }
        const Space v1579_13 = unite(v1579_8,v1579_12);
        v1578_7_result = unite(v1578_7_result,v1579_13);
      }
      const Space v1578_7 = std::move(v1578_7_result);
      v1577_8 = compose(v1577_5,v1578_7);
    }
    const Space v1577_9 = intersect(constant_6,v1577_2);
    const Space v1577_10 = (has_head(v1577_9) ? constant_7 : Space{});
    Space v1577_12;
    if (!v1577_10.empty()) {
      const Path v1582_6 = concat_path(p0,v1576_11_head);
      Space v1582_11_result;
      for (int v1582_11_label = 1; v1582_11_label <= 2; ++v1582_11_label) {
        const Space v1582_11_tail = child(v1576_11_tail,v1582_11_label);
        if (v1582_11_tail.empty()) continue;
        const Path v1582_11_head{v1582_11_label};
        const Space v1583_2 = singleton(v1582_11_head);
        const Space v1583_3 = intersect(constant_6,v1583_2);
        const Space v1583_4 = (has_head(v1583_3) ? constant_7 : Space{});
        const Space v1583_5 = subtract(constant_0,v1583_4);
        Space v1583_7;
        if (!v1583_5.empty()) {
          const Space v1584_6 = routine_122(c, v1582_11_head, v1582_6, v1582_11_tail);
          v1583_7 = compose(v1583_5,v1584_6);
        }
        const Space v1583_8 = intersect(constant_6,v1583_2);
        const Space v1583_9 = (has_head(v1583_8) ? constant_7 : Space{});
        Space v1583_11;
        if (!v1583_9.empty()) {
          const Space v1585_10 = routine_123(c, v1582_11_head, v1582_6, v1582_11_tail);
          v1583_11 = compose(v1583_9,v1585_10);
        }
        const Space v1583_12 = unite(v1583_7,v1583_11);
        v1582_11_result = unite(v1582_11_result,v1583_12);
      }
      const Space v1582_11 = std::move(v1582_11_result);
      v1577_12 = compose(v1577_10,v1582_11);
    }
    const Space v1577_13 = unite(v1577_8,v1577_12);
    v1576_11_result = unite(v1576_11_result,v1577_13);
  }
  const Space v1576_11 = std::move(v1576_11_result);
  return v1576_11;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1586_12_result;
  for (int v1586_12_label = 1; v1586_12_label <= 2; ++v1586_12_label) {
    const Space v1586_12_tail = child(s0,v1586_12_label);
    if (v1586_12_tail.empty()) continue;
    const Path v1586_12_head{v1586_12_label};
    const Space v1587_2 = singleton(v1586_12_head);
    const Space v1587_3 = intersect(constant_6,v1587_2);
    const Space v1587_4 = (has_head(v1587_3) ? constant_7 : Space{});
    const Space v1587_5 = subtract(constant_0,v1587_4);
    Space v1587_8;
    if (!v1587_5.empty()) {
      const Path v1588_6 = concat_path(p0,v1586_12_head);
      Space v1588_7_result;
      for (int v1588_7_label = 1; v1588_7_label <= 2; ++v1588_7_label) {
        const Space v1588_7_tail = child(v1586_12_tail,v1588_7_label);
        if (v1588_7_tail.empty()) continue;
        const Path v1588_7_head{v1588_7_label};
        const Space v1589_2 = singleton(v1588_7_head);
        const Space v1589_3 = intersect(constant_6,v1589_2);
        const Space v1589_4 = (has_head(v1589_3) ? constant_7 : Space{});
        const Space v1589_5 = subtract(constant_0,v1589_4);
        Space v1589_8;
        if (!v1589_5.empty()) {
          const Path v1590_6 = concat_path(v1588_6,v1588_7_head);
          const Space v1590_7 = routine_217(c, v1590_6, p1, v1588_7_tail);
          v1589_8 = compose(v1589_5,v1590_7);
        }
        const Space v1589_9 = intersect(constant_6,v1589_2);
        const Space v1589_10 = (has_head(v1589_9) ? constant_7 : Space{});
        Space v1589_12;
        if (!v1589_10.empty()) {
          const Path v1591_6 = concat_path(v1588_6,v1588_7_head);
          const Space v1591_11 = routine_218(c, v1591_6, p1, v1588_7_tail);
          v1589_12 = compose(v1589_10,v1591_11);
        }
        const Space v1589_13 = unite(v1589_8,v1589_12);
        v1588_7_result = unite(v1588_7_result,v1589_13);
      }
      const Space v1588_7 = std::move(v1588_7_result);
      v1587_8 = compose(v1587_5,v1588_7);
    }
    const Space v1587_9 = intersect(constant_6,v1587_2);
    const Space v1587_10 = (has_head(v1587_9) ? constant_7 : Space{});
    Space v1587_12;
    if (!v1587_10.empty()) {
      const Path v1592_6 = concat_path(p0,v1586_12_head);
      Space v1592_11_result;
      for (int v1592_11_label = 1; v1592_11_label <= 2; ++v1592_11_label) {
        const Space v1592_11_tail = child(v1586_12_tail,v1592_11_label);
        if (v1592_11_tail.empty()) continue;
        const Path v1592_11_head{v1592_11_label};
        const Space v1593_2 = singleton(v1592_11_head);
        const Space v1593_3 = intersect(constant_6,v1593_2);
        const Space v1593_4 = (has_head(v1593_3) ? constant_7 : Space{});
        const Space v1593_5 = subtract(constant_0,v1593_4);
        Space v1593_8;
        if (!v1593_5.empty()) {
          const Path v1594_6 = concat_path(v1592_6,v1592_11_head);
          const Space v1594_7 = routine_217(c, v1594_6, p1, v1592_11_tail);
          v1593_8 = compose(v1593_5,v1594_7);
        }
        const Space v1593_9 = intersect(constant_6,v1593_2);
        const Space v1593_10 = (has_head(v1593_9) ? constant_7 : Space{});
        Space v1593_12;
        if (!v1593_10.empty()) {
          const Path v1595_6 = concat_path(v1592_6,v1592_11_head);
          const Space v1595_11 = routine_137(c, v1595_6, p1, v1592_11_tail);
          v1593_12 = compose(v1593_10,v1595_11);
        }
        const Space v1593_13 = unite(v1593_8,v1593_12);
        v1592_11_result = unite(v1592_11_result,v1593_13);
      }
      const Space v1592_11 = std::move(v1592_11_result);
      v1587_12 = compose(v1587_10,v1592_11);
    }
    const Space v1587_13 = unite(v1587_8,v1587_12);
    v1586_12_result = unite(v1586_12_result,v1587_13);
  }
  const Space v1586_12 = std::move(v1586_12_result);
  return v1586_12;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1596_7 = unwrap(constant_12,p1);
  const Space v1596_9 = unwrap(constant_12,p0);
  Space v1596_13_result;
  for (int v1596_13_label = 1; v1596_13_label <= 2; ++v1596_13_label) {
    const Space v1596_13_tail = child(s0,v1596_13_label);
    if (v1596_13_tail.empty()) continue;
    const Path v1596_13_head{v1596_13_label};
    const Space v1597_2 = singleton(v1596_13_head);
    const Space v1597_3 = intersect(constant_6,v1597_2);
    const Space v1597_4 = (has_head(v1597_3) ? constant_7 : Space{});
    const Space v1597_5 = subtract(constant_0,v1597_4);
    Space v1597_8;
    if (!v1597_5.empty()) {
      const Path v1598_6 = concat_path(p0,v1596_13_head);
      Space v1598_7_result;
      for (int v1598_7_label = 1; v1598_7_label <= 2; ++v1598_7_label) {
        const Space v1598_7_tail = child(v1596_13_tail,v1598_7_label);
        if (v1598_7_tail.empty()) continue;
        const Path v1598_7_head{v1598_7_label};
        const Space v1599_2 = singleton(v1598_7_head);
        const Space v1599_3 = intersect(constant_6,v1599_2);
        const Space v1599_4 = (has_head(v1599_3) ? constant_7 : Space{});
        const Space v1599_5 = subtract(constant_0,v1599_4);
        Space v1599_8;
        if (!v1599_5.empty()) {
          const Path v1600_6 = concat_path(v1598_6,v1598_7_head);
          const Space v1600_7 = routine_217(c, v1600_6, p1, v1598_7_tail);
          v1599_8 = compose(v1599_5,v1600_7);
        }
        const Space v1599_9 = intersect(constant_6,v1599_2);
        const Space v1599_10 = (has_head(v1599_9) ? constant_7 : Space{});
        Space v1599_12;
        if (!v1599_10.empty()) {
          const Path v1601_6 = concat_path(v1598_6,v1598_7_head);
          const Space v1601_11 = routine_218(c, v1601_6, p1, v1598_7_tail);
          v1599_12 = compose(v1599_10,v1601_11);
        }
        const Space v1599_13 = unite(v1599_8,v1599_12);
        v1598_7_result = unite(v1598_7_result,v1599_13);
      }
      const Space v1598_7 = std::move(v1598_7_result);
      v1597_8 = compose(v1597_5,v1598_7);
    }
    const Space v1597_9 = intersect(constant_6,v1597_2);
    const Space v1597_10 = (has_head(v1597_9) ? constant_7 : Space{});
    const Space v1597_11 = unwrap(v1596_9,v1596_13_head);
    const Space v1597_12 = compose(v1596_7,v1597_11);
    const Path v1602_6 = concat_path(p0,v1596_13_head);
    const Path v1597_13 = concat_path(p1,v1602_6);
    const Space v1597_14 = singleton(v1597_13);
    const Space v1597_15 = subtract(v1597_12,v1597_14);
    const Space v1597_16 = compose(v1597_10,v1597_15);
    const Space v1597_17 = unite(v1597_8,v1597_16);
    v1596_13_result = unite(v1596_13_result,v1597_17);
  }
  const Space v1596_13 = std::move(v1596_13_result);
  return v1596_13;
}

static Space routine_175(Context& c, const Path& p0, const Space& s0) {
  Space v1603_11_result;
  for (int v1603_11_label = 1; v1603_11_label <= 2; ++v1603_11_label) {
    const Space v1603_11_tail = child(s0,v1603_11_label);
    if (v1603_11_tail.empty()) continue;
    const Path v1603_11_head{v1603_11_label};
    const Space v1604_2 = singleton(v1603_11_head);
    const Space v1604_3 = intersect(constant_6,v1604_2);
    const Space v1604_4 = (has_head(v1604_3) ? constant_7 : Space{});
    const Space v1604_5 = subtract(constant_0,v1604_4);
    Space v1604_8;
    if (!v1604_5.empty()) {
      const Path v1605_6 = concat_path(p0,v1603_11_head);
      Space v1605_7_result;
      for (int v1605_7_label = 1; v1605_7_label <= 2; ++v1605_7_label) {
        const Space v1605_7_tail = child(v1603_11_tail,v1605_7_label);
        if (v1605_7_tail.empty()) continue;
        const Path v1605_7_head{v1605_7_label};
        const Space v1606_2 = singleton(v1605_7_head);
        const Space v1606_3 = intersect(constant_6,v1606_2);
        const Space v1606_4 = (has_head(v1606_3) ? constant_7 : Space{});
        const Space v1606_5 = subtract(constant_0,v1606_4);
        Space v1606_8;
        if (!v1606_5.empty()) {
          const Path v1607_6 = concat_path(v1605_6,v1605_7_head);
          const Space v1607_7 = routine_219(c, v1607_6, v1605_7_tail);
          v1606_8 = compose(v1606_5,v1607_7);
        }
        const Space v1606_9 = intersect(constant_6,v1606_2);
        const Space v1606_10 = (has_head(v1606_9) ? constant_7 : Space{});
        Space v1606_12;
        if (!v1606_10.empty()) {
          const Path v1608_6 = concat_path(v1605_6,v1605_7_head);
          const Space v1608_11 = routine_220(c, v1608_6, v1605_7_tail);
          v1606_12 = compose(v1606_10,v1608_11);
        }
        const Space v1606_13 = unite(v1606_8,v1606_12);
        v1605_7_result = unite(v1605_7_result,v1606_13);
      }
      const Space v1605_7 = std::move(v1605_7_result);
      v1604_8 = compose(v1604_5,v1605_7);
    }
    const Space v1604_9 = intersect(constant_6,v1604_2);
    const Space v1604_10 = (has_head(v1604_9) ? constant_7 : Space{});
    Space v1604_12;
    if (!v1604_10.empty()) {
      const Path v1609_6 = concat_path(p0,v1603_11_head);
      Space v1609_11_result;
      for (int v1609_11_label = 1; v1609_11_label <= 2; ++v1609_11_label) {
        const Space v1609_11_tail = child(v1603_11_tail,v1609_11_label);
        if (v1609_11_tail.empty()) continue;
        const Path v1609_11_head{v1609_11_label};
        const Space v1610_2 = singleton(v1609_11_head);
        const Space v1610_3 = intersect(constant_6,v1610_2);
        const Space v1610_4 = (has_head(v1610_3) ? constant_7 : Space{});
        const Space v1610_5 = subtract(constant_0,v1610_4);
        Space v1610_8;
        if (!v1610_5.empty()) {
          const Path v1611_6 = concat_path(v1609_6,v1609_11_head);
          const Space v1611_7 = routine_219(c, v1611_6, v1609_11_tail);
          v1610_8 = compose(v1610_5,v1611_7);
        }
        const Space v1610_9 = intersect(constant_6,v1610_2);
        const Space v1610_10 = (has_head(v1610_9) ? constant_7 : Space{});
        Space v1610_12;
        if (!v1610_10.empty()) {
          const Path v1612_6 = concat_path(v1609_6,v1609_11_head);
          const Space v1612_11 = routine_69(c, v1612_6, v1609_11_tail);
          v1610_12 = compose(v1610_10,v1612_11);
        }
        const Space v1610_13 = unite(v1610_8,v1610_12);
        v1609_11_result = unite(v1609_11_result,v1610_13);
      }
      const Space v1609_11 = std::move(v1609_11_result);
      v1604_12 = compose(v1604_10,v1609_11);
    }
    const Space v1604_13 = unite(v1604_8,v1604_12);
    v1603_11_result = unite(v1603_11_result,v1604_13);
  }
  const Space v1603_11 = std::move(v1603_11_result);
  return v1603_11;
}

static Space routine_176(Context& c, const Path& p0, const Space& s0) {
  Space v1613_9_result;
  for (int v1613_9_label = 1; v1613_9_label <= 2; ++v1613_9_label) {
    const Space v1613_9_tail = child(s0,v1613_9_label);
    if (v1613_9_tail.empty()) continue;
    const Path v1613_9_head{v1613_9_label};
    const Space v1614_2 = singleton(v1613_9_head);
    const Space v1614_3 = intersect(constant_6,v1614_2);
    const Space v1614_4 = (has_head(v1614_3) ? constant_7 : Space{});
    const Space v1614_5 = subtract(constant_0,v1614_4);
    Space v1614_8;
    if (!v1614_5.empty()) {
      const Path v1615_6 = concat_path(p0,v1613_9_head);
      Space v1615_7_result;
      for (int v1615_7_label = 1; v1615_7_label <= 2; ++v1615_7_label) {
        const Space v1615_7_tail = child(v1613_9_tail,v1615_7_label);
        if (v1615_7_tail.empty()) continue;
        const Path v1615_7_head{v1615_7_label};
        const Space v1616_2 = singleton(v1615_7_head);
        const Space v1616_3 = intersect(constant_6,v1616_2);
        const Space v1616_4 = (has_head(v1616_3) ? constant_7 : Space{});
        const Space v1616_5 = subtract(constant_0,v1616_4);
        Space v1616_8;
        if (!v1616_5.empty()) {
          const Path v1617_6 = concat_path(v1615_6,v1615_7_head);
          const Space v1617_7 = routine_219(c, v1617_6, v1615_7_tail);
          v1616_8 = compose(v1616_5,v1617_7);
        }
        const Space v1616_9 = intersect(constant_6,v1616_2);
        const Space v1616_10 = (has_head(v1616_9) ? constant_7 : Space{});
        Space v1616_12;
        if (!v1616_10.empty()) {
          const Path v1618_6 = concat_path(v1615_6,v1615_7_head);
          const Space v1618_11 = routine_220(c, v1618_6, v1615_7_tail);
          v1616_12 = compose(v1616_10,v1618_11);
        }
        const Space v1616_13 = unite(v1616_8,v1616_12);
        v1615_7_result = unite(v1615_7_result,v1616_13);
      }
      const Space v1615_7 = std::move(v1615_7_result);
      v1614_8 = compose(v1614_5,v1615_7);
    }
    const Space v1614_9 = intersect(constant_6,v1614_2);
    const Space v1614_10 = (has_head(v1614_9) ? constant_7 : Space{});
    const Space v1614_11 = compose(v1614_10,constant_9);
    const Space v1614_12 = unite(v1614_8,v1614_11);
    v1613_9_result = unite(v1613_9_result,v1614_12);
  }
  const Space v1613_9 = std::move(v1613_9_result);
  return v1613_9;
}

static Space routine_177(Context& c, const Path& p0, const Space& s0) {
  Space v1619_11_result;
  for (int v1619_11_label = 1; v1619_11_label <= 2; ++v1619_11_label) {
    const Space v1619_11_tail = child(s0,v1619_11_label);
    if (v1619_11_tail.empty()) continue;
    const Path v1619_11_head{v1619_11_label};
    const Space v1620_2 = singleton(v1619_11_head);
    const Space v1620_3 = intersect(constant_6,v1620_2);
    const Space v1620_4 = (has_head(v1620_3) ? constant_7 : Space{});
    const Space v1620_5 = subtract(constant_0,v1620_4);
    Space v1620_8;
    if (!v1620_5.empty()) {
      const Path v1621_6 = concat_path(p0,v1619_11_head);
      Space v1621_7_result;
      for (int v1621_7_label = 1; v1621_7_label <= 2; ++v1621_7_label) {
        const Space v1621_7_tail = child(v1619_11_tail,v1621_7_label);
        if (v1621_7_tail.empty()) continue;
        const Path v1621_7_head{v1621_7_label};
        const Space v1622_2 = singleton(v1621_7_head);
        const Space v1622_3 = intersect(constant_6,v1622_2);
        const Space v1622_4 = (has_head(v1622_3) ? constant_7 : Space{});
        const Space v1622_5 = subtract(constant_0,v1622_4);
        Space v1622_8;
        if (!v1622_5.empty()) {
          const Path v1623_6 = concat_path(v1621_6,v1621_7_head);
          const Space v1623_7 = routine_221(c, v1623_6, v1621_7_tail);
          v1622_8 = compose(v1622_5,v1623_7);
        }
        const Space v1622_9 = intersect(constant_6,v1622_2);
        const Space v1622_10 = (has_head(v1622_9) ? constant_7 : Space{});
        Space v1622_12;
        if (!v1622_10.empty()) {
          const Path v1624_6 = concat_path(v1621_6,v1621_7_head);
          const Space v1624_11 = routine_222(c, v1624_6, v1621_7_tail);
          v1622_12 = compose(v1622_10,v1624_11);
        }
        const Space v1622_13 = unite(v1622_8,v1622_12);
        v1621_7_result = unite(v1621_7_result,v1622_13);
      }
      const Space v1621_7 = std::move(v1621_7_result);
      v1620_8 = compose(v1620_5,v1621_7);
    }
    const Space v1620_9 = intersect(constant_6,v1620_2);
    const Space v1620_10 = (has_head(v1620_9) ? constant_7 : Space{});
    Space v1620_12;
    if (!v1620_10.empty()) {
      const Path v1625_6 = concat_path(p0,v1619_11_head);
      Space v1625_11_result;
      for (int v1625_11_label = 1; v1625_11_label <= 2; ++v1625_11_label) {
        const Space v1625_11_tail = child(v1619_11_tail,v1625_11_label);
        if (v1625_11_tail.empty()) continue;
        const Path v1625_11_head{v1625_11_label};
        const Space v1626_2 = singleton(v1625_11_head);
        const Space v1626_3 = intersect(constant_6,v1626_2);
        const Space v1626_4 = (has_head(v1626_3) ? constant_7 : Space{});
        const Space v1626_5 = subtract(constant_0,v1626_4);
        Space v1626_8;
        if (!v1626_5.empty()) {
          const Path v1627_6 = concat_path(v1625_6,v1625_11_head);
          const Space v1627_7 = routine_221(c, v1627_6, v1625_11_tail);
          v1626_8 = compose(v1626_5,v1627_7);
        }
        const Space v1626_9 = intersect(constant_6,v1626_2);
        const Space v1626_10 = (has_head(v1626_9) ? constant_7 : Space{});
        Space v1626_12;
        if (!v1626_10.empty()) {
          const Path v1628_6 = concat_path(v1625_6,v1625_11_head);
          const Space v1628_11 = routine_72(c, v1628_6, v1625_11_tail);
          v1626_12 = compose(v1626_10,v1628_11);
        }
        const Space v1626_13 = unite(v1626_8,v1626_12);
        v1625_11_result = unite(v1625_11_result,v1626_13);
      }
      const Space v1625_11 = std::move(v1625_11_result);
      v1620_12 = compose(v1620_10,v1625_11);
    }
    const Space v1620_13 = unite(v1620_8,v1620_12);
    v1619_11_result = unite(v1619_11_result,v1620_13);
  }
  const Space v1619_11 = std::move(v1619_11_result);
  return v1619_11;
}

static Space routine_178(Context& c, const Path& p0, const Space& s0) {
  Space v1629_9_result;
  for (int v1629_9_label = 1; v1629_9_label <= 2; ++v1629_9_label) {
    const Space v1629_9_tail = child(s0,v1629_9_label);
    if (v1629_9_tail.empty()) continue;
    const Path v1629_9_head{v1629_9_label};
    const Space v1630_2 = singleton(v1629_9_head);
    const Space v1630_3 = intersect(constant_6,v1630_2);
    const Space v1630_4 = (has_head(v1630_3) ? constant_7 : Space{});
    const Space v1630_5 = subtract(constant_0,v1630_4);
    Space v1630_8;
    if (!v1630_5.empty()) {
      const Path v1631_6 = concat_path(p0,v1629_9_head);
      Space v1631_7_result;
      for (int v1631_7_label = 1; v1631_7_label <= 2; ++v1631_7_label) {
        const Space v1631_7_tail = child(v1629_9_tail,v1631_7_label);
        if (v1631_7_tail.empty()) continue;
        const Path v1631_7_head{v1631_7_label};
        const Space v1632_2 = singleton(v1631_7_head);
        const Space v1632_3 = intersect(constant_6,v1632_2);
        const Space v1632_4 = (has_head(v1632_3) ? constant_7 : Space{});
        const Space v1632_5 = subtract(constant_0,v1632_4);
        Space v1632_8;
        if (!v1632_5.empty()) {
          const Path v1633_6 = concat_path(v1631_6,v1631_7_head);
          const Space v1633_7 = routine_221(c, v1633_6, v1631_7_tail);
          v1632_8 = compose(v1632_5,v1633_7);
        }
        const Space v1632_9 = intersect(constant_6,v1632_2);
        const Space v1632_10 = (has_head(v1632_9) ? constant_7 : Space{});
        Space v1632_12;
        if (!v1632_10.empty()) {
          const Path v1634_6 = concat_path(v1631_6,v1631_7_head);
          const Space v1634_11 = routine_222(c, v1634_6, v1631_7_tail);
          v1632_12 = compose(v1632_10,v1634_11);
        }
        const Space v1632_13 = unite(v1632_8,v1632_12);
        v1631_7_result = unite(v1631_7_result,v1632_13);
      }
      const Space v1631_7 = std::move(v1631_7_result);
      v1630_8 = compose(v1630_5,v1631_7);
    }
    const Space v1630_9 = intersect(constant_6,v1630_2);
    const Space v1630_10 = (has_head(v1630_9) ? constant_7 : Space{});
    const Space v1630_11 = compose(v1630_10,constant_9);
    const Space v1630_12 = unite(v1630_8,v1630_11);
    v1629_9_result = unite(v1629_9_result,v1630_12);
  }
  const Space v1629_9 = std::move(v1629_9_result);
  return v1629_9;
}

static Space routine_179(Context& c, const Path& p0, const Space& s0) {
  Space v1635_11_result;
  for (int v1635_11_label = 1; v1635_11_label <= 2; ++v1635_11_label) {
    const Space v1635_11_tail = child(s0,v1635_11_label);
    if (v1635_11_tail.empty()) continue;
    const Path v1635_11_head{v1635_11_label};
    const Space v1636_2 = singleton(v1635_11_head);
    const Space v1636_3 = intersect(constant_6,v1636_2);
    const Space v1636_4 = (has_head(v1636_3) ? constant_7 : Space{});
    const Space v1636_5 = subtract(constant_0,v1636_4);
    Space v1636_8;
    if (!v1636_5.empty()) {
      const Path v1637_6 = concat_path(p0,v1635_11_head);
      Space v1637_7_result;
      for (int v1637_7_label = 1; v1637_7_label <= 2; ++v1637_7_label) {
        const Space v1637_7_tail = child(v1635_11_tail,v1637_7_label);
        if (v1637_7_tail.empty()) continue;
        const Path v1637_7_head{v1637_7_label};
        const Space v1638_2 = singleton(v1637_7_head);
        const Space v1638_3 = intersect(constant_6,v1638_2);
        const Space v1638_4 = (has_head(v1638_3) ? constant_7 : Space{});
        const Space v1638_5 = subtract(constant_0,v1638_4);
        Space v1638_8;
        if (!v1638_5.empty()) {
          const Path v1639_6 = concat_path(v1637_6,v1637_7_head);
          const Space v1639_7 = routine_223(c, v1639_6, v1637_7_tail);
          v1638_8 = compose(v1638_5,v1639_7);
        }
        const Space v1638_9 = intersect(constant_6,v1638_2);
        const Space v1638_10 = (has_head(v1638_9) ? constant_7 : Space{});
        Space v1638_12;
        if (!v1638_10.empty()) {
          const Path v1640_6 = concat_path(v1637_6,v1637_7_head);
          const Space v1640_11 = routine_224(c, v1640_6, v1637_7_tail);
          v1638_12 = compose(v1638_10,v1640_11);
        }
        const Space v1638_13 = unite(v1638_8,v1638_12);
        v1637_7_result = unite(v1637_7_result,v1638_13);
      }
      const Space v1637_7 = std::move(v1637_7_result);
      v1636_8 = compose(v1636_5,v1637_7);
    }
    const Space v1636_9 = intersect(constant_6,v1636_2);
    const Space v1636_10 = (has_head(v1636_9) ? constant_7 : Space{});
    Space v1636_12;
    if (!v1636_10.empty()) {
      const Path v1641_6 = concat_path(p0,v1635_11_head);
      Space v1641_11_result;
      for (int v1641_11_label = 1; v1641_11_label <= 2; ++v1641_11_label) {
        const Space v1641_11_tail = child(v1635_11_tail,v1641_11_label);
        if (v1641_11_tail.empty()) continue;
        const Path v1641_11_head{v1641_11_label};
        const Space v1642_2 = singleton(v1641_11_head);
        const Space v1642_3 = intersect(constant_6,v1642_2);
        const Space v1642_4 = (has_head(v1642_3) ? constant_7 : Space{});
        const Space v1642_5 = subtract(constant_0,v1642_4);
        Space v1642_8;
        if (!v1642_5.empty()) {
          const Path v1643_6 = concat_path(v1641_6,v1641_11_head);
          const Space v1643_7 = routine_223(c, v1643_6, v1641_11_tail);
          v1642_8 = compose(v1642_5,v1643_7);
        }
        const Space v1642_9 = intersect(constant_6,v1642_2);
        const Space v1642_10 = (has_head(v1642_9) ? constant_7 : Space{});
        Space v1642_12;
        if (!v1642_10.empty()) {
          const Path v1644_6 = concat_path(v1641_6,v1641_11_head);
          const Space v1644_11 = routine_75(c, v1644_6, v1641_11_tail);
          v1642_12 = compose(v1642_10,v1644_11);
        }
        const Space v1642_13 = unite(v1642_8,v1642_12);
        v1641_11_result = unite(v1641_11_result,v1642_13);
      }
      const Space v1641_11 = std::move(v1641_11_result);
      v1636_12 = compose(v1636_10,v1641_11);
    }
    const Space v1636_13 = unite(v1636_8,v1636_12);
    v1635_11_result = unite(v1635_11_result,v1636_13);
  }
  const Space v1635_11 = std::move(v1635_11_result);
  return v1635_11;
}

static Space routine_180(Context& c, const Path& p0, const Space& s0) {
  Space v1645_8_result;
  for (int v1645_8_label = 1; v1645_8_label <= 2; ++v1645_8_label) {
    const Space v1645_8_tail = child(s0,v1645_8_label);
    if (v1645_8_tail.empty()) continue;
    const Path v1645_8_head{v1645_8_label};
    const Space v1646_2 = singleton(v1645_8_head);
    const Space v1646_3 = intersect(constant_6,v1646_2);
    const Space v1646_4 = (has_head(v1646_3) ? constant_7 : Space{});
    const Space v1646_5 = subtract(constant_0,v1646_4);
    Space v1646_8;
    if (!v1646_5.empty()) {
      const Path v1647_6 = concat_path(p0,v1645_8_head);
      Space v1647_7_result;
      for (int v1647_7_label = 1; v1647_7_label <= 2; ++v1647_7_label) {
        const Space v1647_7_tail = child(v1645_8_tail,v1647_7_label);
        if (v1647_7_tail.empty()) continue;
        const Path v1647_7_head{v1647_7_label};
        const Space v1648_2 = singleton(v1647_7_head);
        const Space v1648_3 = intersect(constant_6,v1648_2);
        const Space v1648_4 = (has_head(v1648_3) ? constant_7 : Space{});
        const Space v1648_5 = subtract(constant_0,v1648_4);
        Space v1648_8;
        if (!v1648_5.empty()) {
          const Path v1649_6 = concat_path(v1647_6,v1647_7_head);
          const Space v1649_7 = routine_223(c, v1649_6, v1647_7_tail);
          v1648_8 = compose(v1648_5,v1649_7);
        }
        const Space v1648_9 = intersect(constant_6,v1648_2);
        const Space v1648_10 = (has_head(v1648_9) ? constant_7 : Space{});
        Space v1648_12;
        if (!v1648_10.empty()) {
          const Path v1650_6 = concat_path(v1647_6,v1647_7_head);
          const Space v1650_11 = routine_224(c, v1650_6, v1647_7_tail);
          v1648_12 = compose(v1648_10,v1650_11);
        }
        const Space v1648_13 = unite(v1648_8,v1648_12);
        v1647_7_result = unite(v1647_7_result,v1648_13);
      }
      const Space v1647_7 = std::move(v1647_7_result);
      v1646_8 = compose(v1646_5,v1647_7);
    }
    const Space v1646_9 = intersect(constant_6,v1646_2);
    const Space v1646_10 = (has_head(v1646_9) ? constant_7 : Space{});
    const Space v1646_11 = compose(v1646_10,v1645_8_tail);
    const Space v1646_12 = unite(v1646_8,v1646_11);
    v1645_8_result = unite(v1645_8_result,v1646_12);
  }
  const Space v1645_8 = std::move(v1645_8_result);
  return v1645_8;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1651_6_result;
  for (int v1651_6_label = 1; v1651_6_label <= 2; ++v1651_6_label) {
    const Space v1651_6_tail = child(s0,v1651_6_label);
    if (v1651_6_tail.empty()) continue;
    const Path v1651_6_head{v1651_6_label};
    const Space v1652_2 = singleton(v1651_6_head);
    const Space v1652_3 = intersect(constant_6,v1652_2);
    const Space v1652_4 = (has_head(v1652_3) ? constant_7 : Space{});
    Space v1652_7;
    if (!v1652_4.empty()) {
      const Path v1653_5 = concat_path(p0,v1651_6_head);
      Space v1653_6_result;
      for (int v1653_6_label = 1; v1653_6_label <= 2; ++v1653_6_label) {
        const Space v1653_6_tail = child(v1651_6_tail,v1653_6_label);
        if (v1653_6_tail.empty()) continue;
        const Path v1653_6_head{v1653_6_label};
        const Space v1654_2 = singleton(v1653_6_head);
        const Space v1654_3 = intersect(constant_6,v1654_2);
        const Space v1654_4 = (has_head(v1654_3) ? constant_7 : Space{});
        Space v1654_7;
        if (!v1654_4.empty()) {
          const Path v1655_5 = concat_path(v1653_5,v1653_6_head);
          const Space v1655_6 = routine_26(c, v1655_5, p1, v1653_6_tail, s1);
          v1654_7 = compose(v1654_4,v1655_6);
        }
        v1653_6_result = unite(v1653_6_result,v1654_7);
      }
      const Space v1653_6 = std::move(v1653_6_result);
      v1652_7 = compose(v1652_4,v1653_6);
    }
    v1651_6_result = unite(v1651_6_result,v1652_7);
  }
  const Space v1651_6 = std::move(v1651_6_result);
  return v1651_6;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1656_6 = unwrap(s1,constant_8);
  Space v1656_16_result;
  for (int v1656_16_label = 1; v1656_16_label <= 2; ++v1656_16_label) {
    const Space v1656_16_tail = child(s0,v1656_16_label);
    if (v1656_16_tail.empty()) continue;
    const Path v1656_16_head{v1656_16_label};
    const Space v1657_2 = singleton(v1656_16_head);
    const Space v1657_3 = intersect(constant_6,v1657_2);
    const Space v1657_4 = (has_head(v1657_3) ? constant_7 : Space{});
    Space v1657_17;
    if (!v1657_4.empty()) {
      const Path v1658_5 = concat_path(p0,v1656_16_head);
      const Path v1658_6 = concat_path(p1,v1658_5);
      const Space v1658_7 = routine_29(c, v1658_6);
      const Space v1658_8 = intersect(v1656_6,v1658_7);
      const Space v1658_9 = routine_30(c, v1658_8);
      Space v1658_10_result;
      for (int v1658_10_label = 1; v1658_10_label <= 2; ++v1658_10_label) {
        const Space v1658_10_tail = child(v1658_9,v1658_10_label);
        if (v1658_10_tail.empty()) continue;
        const Path v1658_10_head{v1658_10_label};
        const Space v1659_2 = singleton(v1658_10_head);
        const Space v1659_3 = intersect(constant_6,v1659_2);
        const Space v1659_4 = (has_head(v1659_3) ? constant_7 : Space{});
        const Space v1659_5 = subtract(constant_0,v1659_4);
        Space v1659_7;
        if (!v1659_5.empty()) {
          const Space v1660_6 = routine_31(c, v1658_10_head, v1658_10_tail);
          v1659_7 = compose(v1659_5,v1660_6);
        }
        const Space v1659_8 = intersect(constant_6,v1659_2);
        const Space v1659_9 = (has_head(v1659_8) ? constant_7 : Space{});
        Space v1659_11;
        if (!v1659_9.empty()) {
          const Space v1661_10 = routine_32(c, v1658_10_head, v1658_10_tail);
          v1659_11 = compose(v1659_9,v1661_10);
        }
        const Space v1659_12 = unite(v1659_7,v1659_11);
        v1658_10_result = unite(v1658_10_result,v1659_12);
      }
      const Space v1658_10 = std::move(v1658_10_result);
      const Space v1658_11 = routine_33(c, v1658_8);
      Space v1658_12_result;
      for (int v1658_12_label = 1; v1658_12_label <= 2; ++v1658_12_label) {
        const Space v1658_12_tail = child(v1658_11,v1658_12_label);
        if (v1658_12_tail.empty()) continue;
        const Path v1658_12_head{v1658_12_label};
        const Space v1662_2 = singleton(v1658_12_head);
        const Space v1662_3 = intersect(constant_6,v1662_2);
        const Space v1662_4 = (has_head(v1662_3) ? constant_7 : Space{});
        const Space v1662_5 = subtract(constant_0,v1662_4);
        Space v1662_7;
        if (!v1662_5.empty()) {
          const Space v1663_6 = routine_34(c, v1658_12_head, v1658_12_tail);
          v1662_7 = compose(v1662_5,v1663_6);
        }
        const Space v1662_8 = intersect(constant_6,v1662_2);
        const Space v1662_9 = (has_head(v1662_8) ? constant_7 : Space{});
        Space v1662_11;
        if (!v1662_9.empty()) {
          const Space v1664_10 = routine_35(c, v1658_12_head, v1658_12_tail);
          v1662_11 = compose(v1662_9,v1664_10);
        }
        const Space v1662_12 = unite(v1662_7,v1662_11);
        v1658_12_result = unite(v1658_12_result,v1662_12);
      }
      const Space v1658_12 = std::move(v1658_12_result);
      const Space v1658_13 = subtract(v1658_10,v1658_12);
      const Space v1658_14 = singleton(v1658_6);
      const Space v1658_15 = compose(v1658_13,v1658_14);
      Space v1658_16_result;
      for (int v1658_16_label = 1; v1658_16_label <= 2; ++v1658_16_label) {
        const Space v1658_16_tail = child(v1658_15,v1658_16_label);
        if (v1658_16_tail.empty()) continue;
        const Path v1658_16_head{v1658_16_label};
        const Space v1665_2 = singleton(v1658_16_head);
        const Space v1665_3 = intersect(constant_6,v1665_2);
        const Space v1665_4 = (has_head(v1665_3) ? constant_7 : Space{});
        const Space v1665_5 = subtract(constant_0,v1665_4);
        Space v1665_7;
        if (!v1665_5.empty()) {
          const Space v1666_6 = routine_36(c, v1658_16_head, v1658_16_tail);
          v1665_7 = compose(v1665_5,v1666_6);
        }
        const Space v1665_8 = intersect(constant_6,v1665_2);
        const Space v1665_9 = (has_head(v1665_8) ? constant_7 : Space{});
        Space v1665_11;
        if (!v1665_9.empty()) {
          const Space v1667_10 = routine_37(c, v1658_16_head, v1658_16_tail);
          v1665_11 = compose(v1665_9,v1667_10);
        }
        const Space v1665_12 = unite(v1665_7,v1665_11);
        v1658_16_result = unite(v1658_16_result,v1665_12);
      }
      const Space v1658_16 = std::move(v1658_16_result);
      v1657_17 = compose(v1657_4,v1658_16);
    }
    v1656_16_result = unite(v1656_16_result,v1657_17);
  }
  const Space v1656_16 = std::move(v1656_16_result);
  return v1656_16;
}

static Space routine_183(Context& c, const Path& p0, const Space& s0) {
  Space v1668_11_result;
  for (int v1668_11_label = 1; v1668_11_label <= 2; ++v1668_11_label) {
    const Space v1668_11_tail = child(s0,v1668_11_label);
    if (v1668_11_tail.empty()) continue;
    const Path v1668_11_head{v1668_11_label};
    const Space v1669_2 = singleton(v1668_11_head);
    const Space v1669_3 = intersect(constant_6,v1669_2);
    const Space v1669_4 = (has_head(v1669_3) ? constant_7 : Space{});
    const Space v1669_5 = subtract(constant_0,v1669_4);
    Space v1669_8;
    if (!v1669_5.empty()) {
      const Path v1670_6 = concat_path(p0,v1668_11_head);
      Space v1670_7_result;
      for (int v1670_7_label = 1; v1670_7_label <= 2; ++v1670_7_label) {
        const Space v1670_7_tail = child(v1668_11_tail,v1670_7_label);
        if (v1670_7_tail.empty()) continue;
        const Path v1670_7_head{v1670_7_label};
        const Space v1671_2 = singleton(v1670_7_head);
        const Space v1671_3 = intersect(constant_6,v1671_2);
        const Space v1671_4 = (has_head(v1671_3) ? constant_7 : Space{});
        const Space v1671_5 = subtract(constant_0,v1671_4);
        Space v1671_8;
        if (!v1671_5.empty()) {
          const Path v1672_6 = concat_path(v1670_6,v1670_7_head);
          const Space v1672_7 = routine_225(c, v1672_6, v1670_7_tail);
          v1671_8 = compose(v1671_5,v1672_7);
        }
        const Space v1671_9 = intersect(constant_6,v1671_2);
        const Space v1671_10 = (has_head(v1671_9) ? constant_7 : Space{});
        Space v1671_12;
        if (!v1671_10.empty()) {
          const Path v1673_6 = concat_path(v1670_6,v1670_7_head);
          const Space v1673_11 = routine_226(c, v1673_6, v1670_7_tail);
          v1671_12 = compose(v1671_10,v1673_11);
        }
        const Space v1671_13 = unite(v1671_8,v1671_12);
        v1670_7_result = unite(v1670_7_result,v1671_13);
      }
      const Space v1670_7 = std::move(v1670_7_result);
      v1669_8 = compose(v1669_5,v1670_7);
    }
    const Space v1669_9 = intersect(constant_6,v1669_2);
    const Space v1669_10 = (has_head(v1669_9) ? constant_7 : Space{});
    Space v1669_12;
    if (!v1669_10.empty()) {
      const Path v1674_6 = concat_path(p0,v1668_11_head);
      Space v1674_11_result;
      for (int v1674_11_label = 1; v1674_11_label <= 2; ++v1674_11_label) {
        const Space v1674_11_tail = child(v1668_11_tail,v1674_11_label);
        if (v1674_11_tail.empty()) continue;
        const Path v1674_11_head{v1674_11_label};
        const Space v1675_2 = singleton(v1674_11_head);
        const Space v1675_3 = intersect(constant_6,v1675_2);
        const Space v1675_4 = (has_head(v1675_3) ? constant_7 : Space{});
        const Space v1675_5 = subtract(constant_0,v1675_4);
        Space v1675_8;
        if (!v1675_5.empty()) {
          const Path v1676_6 = concat_path(v1674_6,v1674_11_head);
          const Space v1676_7 = routine_225(c, v1676_6, v1674_11_tail);
          v1675_8 = compose(v1675_5,v1676_7);
        }
        const Space v1675_9 = intersect(constant_6,v1675_2);
        const Space v1675_10 = (has_head(v1675_9) ? constant_7 : Space{});
        Space v1675_12;
        if (!v1675_10.empty()) {
          const Path v1677_6 = concat_path(v1674_6,v1674_11_head);
          const Space v1677_11 = routine_80(c, v1677_6, v1674_11_tail);
          v1675_12 = compose(v1675_10,v1677_11);
        }
        const Space v1675_13 = unite(v1675_8,v1675_12);
        v1674_11_result = unite(v1674_11_result,v1675_13);
      }
      const Space v1674_11 = std::move(v1674_11_result);
      v1669_12 = compose(v1669_10,v1674_11);
    }
    const Space v1669_13 = unite(v1669_8,v1669_12);
    v1668_11_result = unite(v1668_11_result,v1669_13);
  }
  const Space v1668_11 = std::move(v1668_11_result);
  return v1668_11;
}

static Space routine_184(Context& c, const Path& p0, const Space& s0) {
  Space v1678_11_result;
  for (int v1678_11_label = 1; v1678_11_label <= 2; ++v1678_11_label) {
    const Space v1678_11_tail = child(s0,v1678_11_label);
    if (v1678_11_tail.empty()) continue;
    const Path v1678_11_head{v1678_11_label};
    const Space v1679_2 = singleton(v1678_11_head);
    const Space v1679_3 = intersect(constant_6,v1679_2);
    const Space v1679_4 = (has_head(v1679_3) ? constant_7 : Space{});
    const Space v1679_5 = subtract(constant_0,v1679_4);
    Space v1679_8;
    if (!v1679_5.empty()) {
      const Path v1680_6 = concat_path(p0,v1678_11_head);
      Space v1680_7_result;
      for (int v1680_7_label = 1; v1680_7_label <= 2; ++v1680_7_label) {
        const Space v1680_7_tail = child(v1678_11_tail,v1680_7_label);
        if (v1680_7_tail.empty()) continue;
        const Path v1680_7_head{v1680_7_label};
        const Space v1681_2 = singleton(v1680_7_head);
        const Space v1681_3 = intersect(constant_6,v1681_2);
        const Space v1681_4 = (has_head(v1681_3) ? constant_7 : Space{});
        const Space v1681_5 = subtract(constant_0,v1681_4);
        Space v1681_8;
        if (!v1681_5.empty()) {
          const Path v1682_6 = concat_path(v1680_6,v1680_7_head);
          const Space v1682_7 = routine_225(c, v1682_6, v1680_7_tail);
          v1681_8 = compose(v1681_5,v1682_7);
        }
        const Space v1681_9 = intersect(constant_6,v1681_2);
        const Space v1681_10 = (has_head(v1681_9) ? constant_7 : Space{});
        Space v1681_12;
        if (!v1681_10.empty()) {
          const Path v1683_6 = concat_path(v1680_6,v1680_7_head);
          const Space v1683_11 = routine_226(c, v1683_6, v1680_7_tail);
          v1681_12 = compose(v1681_10,v1683_11);
        }
        const Space v1681_13 = unite(v1681_8,v1681_12);
        v1680_7_result = unite(v1680_7_result,v1681_13);
      }
      const Space v1680_7 = std::move(v1680_7_result);
      v1679_8 = compose(v1679_5,v1680_7);
    }
    const Space v1679_9 = intersect(constant_6,v1679_2);
    const Space v1679_10 = (has_head(v1679_9) ? constant_7 : Space{});
    Space v1679_12;
    if (!v1679_10.empty()) {
      const Path v1684_6 = concat_path(p0,v1678_11_head);
      Space v1684_11_result;
      for (int v1684_11_label = 1; v1684_11_label <= 2; ++v1684_11_label) {
        const Space v1684_11_tail = child(v1678_11_tail,v1684_11_label);
        if (v1684_11_tail.empty()) continue;
        const Path v1684_11_head{v1684_11_label};
        const Space v1685_2 = singleton(v1684_11_head);
        const Space v1685_3 = intersect(constant_6,v1685_2);
        const Space v1685_4 = (has_head(v1685_3) ? constant_7 : Space{});
        const Space v1685_5 = subtract(constant_0,v1685_4);
        Space v1685_7;
        if (!v1685_5.empty()) {
          const Space v1686_6 = routine_122(c, v1684_11_head, v1684_6, v1684_11_tail);
          v1685_7 = compose(v1685_5,v1686_6);
        }
        const Space v1685_8 = intersect(constant_6,v1685_2);
        const Space v1685_9 = (has_head(v1685_8) ? constant_7 : Space{});
        Space v1685_11;
        if (!v1685_9.empty()) {
          const Space v1687_10 = routine_123(c, v1684_11_head, v1684_6, v1684_11_tail);
          v1685_11 = compose(v1685_9,v1687_10);
        }
        const Space v1685_12 = unite(v1685_7,v1685_11);
        v1684_11_result = unite(v1684_11_result,v1685_12);
      }
      const Space v1684_11 = std::move(v1684_11_result);
      v1679_12 = compose(v1679_10,v1684_11);
    }
    const Space v1679_13 = unite(v1679_8,v1679_12);
    v1678_11_result = unite(v1678_11_result,v1679_13);
  }
  const Space v1678_11 = std::move(v1678_11_result);
  return v1678_11;
}

static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1688_12_result;
  for (int v1688_12_label = 1; v1688_12_label <= 2; ++v1688_12_label) {
    const Space v1688_12_tail = child(s0,v1688_12_label);
    if (v1688_12_tail.empty()) continue;
    const Path v1688_12_head{v1688_12_label};
    const Space v1689_2 = singleton(v1688_12_head);
    const Space v1689_3 = intersect(constant_6,v1689_2);
    const Space v1689_4 = (has_head(v1689_3) ? constant_7 : Space{});
    const Space v1689_5 = subtract(constant_0,v1689_4);
    Space v1689_8;
    if (!v1689_5.empty()) {
      const Path v1690_6 = concat_path(p0,v1688_12_head);
      Space v1690_7_result;
      for (int v1690_7_label = 1; v1690_7_label <= 2; ++v1690_7_label) {
        const Space v1690_7_tail = child(v1688_12_tail,v1690_7_label);
        if (v1690_7_tail.empty()) continue;
        const Path v1690_7_head{v1690_7_label};
        const Space v1691_2 = singleton(v1690_7_head);
        const Space v1691_3 = intersect(constant_6,v1691_2);
        const Space v1691_4 = (has_head(v1691_3) ? constant_7 : Space{});
        const Space v1691_5 = subtract(constant_0,v1691_4);
        Space v1691_8;
        if (!v1691_5.empty()) {
          const Path v1692_6 = concat_path(v1690_6,v1690_7_head);
          const Space v1692_7 = routine_227(c, v1692_6, p1, v1690_7_tail);
          v1691_8 = compose(v1691_5,v1692_7);
        }
        const Space v1691_9 = intersect(constant_6,v1691_2);
        const Space v1691_10 = (has_head(v1691_9) ? constant_7 : Space{});
        Space v1691_12;
        if (!v1691_10.empty()) {
          const Path v1693_6 = concat_path(v1690_6,v1690_7_head);
          const Space v1693_11 = routine_228(c, v1693_6, p1, v1690_7_tail);
          v1691_12 = compose(v1691_10,v1693_11);
        }
        const Space v1691_13 = unite(v1691_8,v1691_12);
        v1690_7_result = unite(v1690_7_result,v1691_13);
      }
      const Space v1690_7 = std::move(v1690_7_result);
      v1689_8 = compose(v1689_5,v1690_7);
    }
    const Space v1689_9 = intersect(constant_6,v1689_2);
    const Space v1689_10 = (has_head(v1689_9) ? constant_7 : Space{});
    Space v1689_12;
    if (!v1689_10.empty()) {
      const Path v1694_6 = concat_path(p0,v1688_12_head);
      Space v1694_11_result;
      for (int v1694_11_label = 1; v1694_11_label <= 2; ++v1694_11_label) {
        const Space v1694_11_tail = child(v1688_12_tail,v1694_11_label);
        if (v1694_11_tail.empty()) continue;
        const Path v1694_11_head{v1694_11_label};
        const Space v1695_2 = singleton(v1694_11_head);
        const Space v1695_3 = intersect(constant_6,v1695_2);
        const Space v1695_4 = (has_head(v1695_3) ? constant_7 : Space{});
        const Space v1695_5 = subtract(constant_0,v1695_4);
        Space v1695_8;
        if (!v1695_5.empty()) {
          const Path v1696_6 = concat_path(v1694_6,v1694_11_head);
          const Space v1696_7 = routine_227(c, v1696_6, p1, v1694_11_tail);
          v1695_8 = compose(v1695_5,v1696_7);
        }
        const Space v1695_9 = intersect(constant_6,v1695_2);
        const Space v1695_10 = (has_head(v1695_9) ? constant_7 : Space{});
        Space v1695_12;
        if (!v1695_10.empty()) {
          const Path v1697_6 = concat_path(v1694_6,v1694_11_head);
          const Space v1697_11 = routine_137(c, v1697_6, p1, v1694_11_tail);
          v1695_12 = compose(v1695_10,v1697_11);
        }
        const Space v1695_13 = unite(v1695_8,v1695_12);
        v1694_11_result = unite(v1694_11_result,v1695_13);
      }
      const Space v1694_11 = std::move(v1694_11_result);
      v1689_12 = compose(v1689_10,v1694_11);
    }
    const Space v1689_13 = unite(v1689_8,v1689_12);
    v1688_12_result = unite(v1688_12_result,v1689_13);
  }
  const Space v1688_12 = std::move(v1688_12_result);
  return v1688_12;
}

static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1698_7 = unwrap(constant_12,p1);
  const Space v1698_9 = unwrap(constant_12,p0);
  Space v1698_13_result;
  for (int v1698_13_label = 1; v1698_13_label <= 2; ++v1698_13_label) {
    const Space v1698_13_tail = child(s0,v1698_13_label);
    if (v1698_13_tail.empty()) continue;
    const Path v1698_13_head{v1698_13_label};
    const Space v1699_2 = singleton(v1698_13_head);
    const Space v1699_3 = intersect(constant_6,v1699_2);
    const Space v1699_4 = (has_head(v1699_3) ? constant_7 : Space{});
    const Space v1699_5 = subtract(constant_0,v1699_4);
    Space v1699_8;
    if (!v1699_5.empty()) {
      const Path v1700_6 = concat_path(p0,v1698_13_head);
      Space v1700_7_result;
      for (int v1700_7_label = 1; v1700_7_label <= 2; ++v1700_7_label) {
        const Space v1700_7_tail = child(v1698_13_tail,v1700_7_label);
        if (v1700_7_tail.empty()) continue;
        const Path v1700_7_head{v1700_7_label};
        const Space v1701_2 = singleton(v1700_7_head);
        const Space v1701_3 = intersect(constant_6,v1701_2);
        const Space v1701_4 = (has_head(v1701_3) ? constant_7 : Space{});
        const Space v1701_5 = subtract(constant_0,v1701_4);
        Space v1701_8;
        if (!v1701_5.empty()) {
          const Path v1702_6 = concat_path(v1700_6,v1700_7_head);
          const Space v1702_7 = routine_227(c, v1702_6, p1, v1700_7_tail);
          v1701_8 = compose(v1701_5,v1702_7);
        }
        const Space v1701_9 = intersect(constant_6,v1701_2);
        const Space v1701_10 = (has_head(v1701_9) ? constant_7 : Space{});
        Space v1701_12;
        if (!v1701_10.empty()) {
          const Path v1703_6 = concat_path(v1700_6,v1700_7_head);
          const Space v1703_11 = routine_228(c, v1703_6, p1, v1700_7_tail);
          v1701_12 = compose(v1701_10,v1703_11);
        }
        const Space v1701_13 = unite(v1701_8,v1701_12);
        v1700_7_result = unite(v1700_7_result,v1701_13);
      }
      const Space v1700_7 = std::move(v1700_7_result);
      v1699_8 = compose(v1699_5,v1700_7);
    }
    const Space v1699_9 = intersect(constant_6,v1699_2);
    const Space v1699_10 = (has_head(v1699_9) ? constant_7 : Space{});
    const Space v1699_11 = unwrap(v1698_9,v1698_13_head);
    const Space v1699_12 = compose(v1698_7,v1699_11);
    const Path v1704_6 = concat_path(p0,v1698_13_head);
    const Path v1699_13 = concat_path(p1,v1704_6);
    const Space v1699_14 = singleton(v1699_13);
    const Space v1699_15 = subtract(v1699_12,v1699_14);
    const Space v1699_16 = compose(v1699_10,v1699_15);
    const Space v1699_17 = unite(v1699_8,v1699_16);
    v1698_13_result = unite(v1698_13_result,v1699_17);
  }
  const Space v1698_13 = std::move(v1698_13_result);
  return v1698_13;
}

static Space routine_187(Context& c, const Path& p0, const Space& s0) {
  Space v1705_11_result;
  for (int v1705_11_label = 1; v1705_11_label <= 2; ++v1705_11_label) {
    const Space v1705_11_tail = child(s0,v1705_11_label);
    if (v1705_11_tail.empty()) continue;
    const Path v1705_11_head{v1705_11_label};
    const Space v1706_2 = singleton(v1705_11_head);
    const Space v1706_3 = intersect(constant_6,v1706_2);
    const Space v1706_4 = (has_head(v1706_3) ? constant_7 : Space{});
    const Space v1706_5 = subtract(constant_0,v1706_4);
    Space v1706_8;
    if (!v1706_5.empty()) {
      const Path v1707_6 = concat_path(p0,v1705_11_head);
      Space v1707_7_result;
      for (int v1707_7_label = 1; v1707_7_label <= 2; ++v1707_7_label) {
        const Space v1707_7_tail = child(v1705_11_tail,v1707_7_label);
        if (v1707_7_tail.empty()) continue;
        const Path v1707_7_head{v1707_7_label};
        const Space v1708_2 = singleton(v1707_7_head);
        const Space v1708_3 = intersect(constant_6,v1708_2);
        const Space v1708_4 = (has_head(v1708_3) ? constant_7 : Space{});
        const Space v1708_5 = subtract(constant_0,v1708_4);
        Space v1708_8;
        if (!v1708_5.empty()) {
          const Path v1709_6 = concat_path(v1707_6,v1707_7_head);
          const Space v1709_7 = routine_229(c, v1709_6, v1707_7_tail);
          v1708_8 = compose(v1708_5,v1709_7);
        }
        const Space v1708_9 = intersect(constant_6,v1708_2);
        const Space v1708_10 = (has_head(v1708_9) ? constant_7 : Space{});
        Space v1708_12;
        if (!v1708_10.empty()) {
          const Path v1710_6 = concat_path(v1707_6,v1707_7_head);
          const Space v1710_11 = routine_230(c, v1710_6, v1707_7_tail);
          v1708_12 = compose(v1708_10,v1710_11);
        }
        const Space v1708_13 = unite(v1708_8,v1708_12);
        v1707_7_result = unite(v1707_7_result,v1708_13);
      }
      const Space v1707_7 = std::move(v1707_7_result);
      v1706_8 = compose(v1706_5,v1707_7);
    }
    const Space v1706_9 = intersect(constant_6,v1706_2);
    const Space v1706_10 = (has_head(v1706_9) ? constant_7 : Space{});
    Space v1706_12;
    if (!v1706_10.empty()) {
      const Path v1711_6 = concat_path(p0,v1705_11_head);
      Space v1711_11_result;
      for (int v1711_11_label = 1; v1711_11_label <= 2; ++v1711_11_label) {
        const Space v1711_11_tail = child(v1705_11_tail,v1711_11_label);
        if (v1711_11_tail.empty()) continue;
        const Path v1711_11_head{v1711_11_label};
        const Space v1712_2 = singleton(v1711_11_head);
        const Space v1712_3 = intersect(constant_6,v1712_2);
        const Space v1712_4 = (has_head(v1712_3) ? constant_7 : Space{});
        const Space v1712_5 = subtract(constant_0,v1712_4);
        Space v1712_8;
        if (!v1712_5.empty()) {
          const Path v1713_6 = concat_path(v1711_6,v1711_11_head);
          const Space v1713_7 = routine_229(c, v1713_6, v1711_11_tail);
          v1712_8 = compose(v1712_5,v1713_7);
        }
        const Space v1712_9 = intersect(constant_6,v1712_2);
        const Space v1712_10 = (has_head(v1712_9) ? constant_7 : Space{});
        Space v1712_12;
        if (!v1712_10.empty()) {
          const Path v1714_6 = concat_path(v1711_6,v1711_11_head);
          const Space v1714_11 = routine_69(c, v1714_6, v1711_11_tail);
          v1712_12 = compose(v1712_10,v1714_11);
        }
        const Space v1712_13 = unite(v1712_8,v1712_12);
        v1711_11_result = unite(v1711_11_result,v1712_13);
      }
      const Space v1711_11 = std::move(v1711_11_result);
      v1706_12 = compose(v1706_10,v1711_11);
    }
    const Space v1706_13 = unite(v1706_8,v1706_12);
    v1705_11_result = unite(v1705_11_result,v1706_13);
  }
  const Space v1705_11 = std::move(v1705_11_result);
  return v1705_11;
}

static Space routine_188(Context& c, const Path& p0, const Space& s0) {
  Space v1715_9_result;
  for (int v1715_9_label = 1; v1715_9_label <= 2; ++v1715_9_label) {
    const Space v1715_9_tail = child(s0,v1715_9_label);
    if (v1715_9_tail.empty()) continue;
    const Path v1715_9_head{v1715_9_label};
    const Space v1716_2 = singleton(v1715_9_head);
    const Space v1716_3 = intersect(constant_6,v1716_2);
    const Space v1716_4 = (has_head(v1716_3) ? constant_7 : Space{});
    const Space v1716_5 = subtract(constant_0,v1716_4);
    Space v1716_8;
    if (!v1716_5.empty()) {
      const Path v1717_6 = concat_path(p0,v1715_9_head);
      Space v1717_7_result;
      for (int v1717_7_label = 1; v1717_7_label <= 2; ++v1717_7_label) {
        const Space v1717_7_tail = child(v1715_9_tail,v1717_7_label);
        if (v1717_7_tail.empty()) continue;
        const Path v1717_7_head{v1717_7_label};
        const Space v1718_2 = singleton(v1717_7_head);
        const Space v1718_3 = intersect(constant_6,v1718_2);
        const Space v1718_4 = (has_head(v1718_3) ? constant_7 : Space{});
        const Space v1718_5 = subtract(constant_0,v1718_4);
        Space v1718_8;
        if (!v1718_5.empty()) {
          const Path v1719_6 = concat_path(v1717_6,v1717_7_head);
          const Space v1719_7 = routine_229(c, v1719_6, v1717_7_tail);
          v1718_8 = compose(v1718_5,v1719_7);
        }
        const Space v1718_9 = intersect(constant_6,v1718_2);
        const Space v1718_10 = (has_head(v1718_9) ? constant_7 : Space{});
        Space v1718_12;
        if (!v1718_10.empty()) {
          const Path v1720_6 = concat_path(v1717_6,v1717_7_head);
          const Space v1720_11 = routine_230(c, v1720_6, v1717_7_tail);
          v1718_12 = compose(v1718_10,v1720_11);
        }
        const Space v1718_13 = unite(v1718_8,v1718_12);
        v1717_7_result = unite(v1717_7_result,v1718_13);
      }
      const Space v1717_7 = std::move(v1717_7_result);
      v1716_8 = compose(v1716_5,v1717_7);
    }
    const Space v1716_9 = intersect(constant_6,v1716_2);
    const Space v1716_10 = (has_head(v1716_9) ? constant_7 : Space{});
    const Space v1716_11 = compose(v1716_10,constant_9);
    const Space v1716_12 = unite(v1716_8,v1716_11);
    v1715_9_result = unite(v1715_9_result,v1716_12);
  }
  const Space v1715_9 = std::move(v1715_9_result);
  return v1715_9;
}

static Space routine_189(Context& c, const Path& p0, const Space& s0) {
  Space v1721_11_result;
  for (int v1721_11_label = 1; v1721_11_label <= 2; ++v1721_11_label) {
    const Space v1721_11_tail = child(s0,v1721_11_label);
    if (v1721_11_tail.empty()) continue;
    const Path v1721_11_head{v1721_11_label};
    const Space v1722_2 = singleton(v1721_11_head);
    const Space v1722_3 = intersect(constant_6,v1722_2);
    const Space v1722_4 = (has_head(v1722_3) ? constant_7 : Space{});
    const Space v1722_5 = subtract(constant_0,v1722_4);
    Space v1722_8;
    if (!v1722_5.empty()) {
      const Path v1723_6 = concat_path(p0,v1721_11_head);
      Space v1723_7_result;
      for (int v1723_7_label = 1; v1723_7_label <= 2; ++v1723_7_label) {
        const Space v1723_7_tail = child(v1721_11_tail,v1723_7_label);
        if (v1723_7_tail.empty()) continue;
        const Path v1723_7_head{v1723_7_label};
        const Space v1724_2 = singleton(v1723_7_head);
        const Space v1724_3 = intersect(constant_6,v1724_2);
        const Space v1724_4 = (has_head(v1724_3) ? constant_7 : Space{});
        const Space v1724_5 = subtract(constant_0,v1724_4);
        Space v1724_8;
        if (!v1724_5.empty()) {
          const Path v1725_6 = concat_path(v1723_6,v1723_7_head);
          const Space v1725_7 = routine_231(c, v1725_6, v1723_7_tail);
          v1724_8 = compose(v1724_5,v1725_7);
        }
        const Space v1724_9 = intersect(constant_6,v1724_2);
        const Space v1724_10 = (has_head(v1724_9) ? constant_7 : Space{});
        Space v1724_12;
        if (!v1724_10.empty()) {
          const Path v1726_6 = concat_path(v1723_6,v1723_7_head);
          const Space v1726_11 = routine_232(c, v1726_6, v1723_7_tail);
          v1724_12 = compose(v1724_10,v1726_11);
        }
        const Space v1724_13 = unite(v1724_8,v1724_12);
        v1723_7_result = unite(v1723_7_result,v1724_13);
      }
      const Space v1723_7 = std::move(v1723_7_result);
      v1722_8 = compose(v1722_5,v1723_7);
    }
    const Space v1722_9 = intersect(constant_6,v1722_2);
    const Space v1722_10 = (has_head(v1722_9) ? constant_7 : Space{});
    Space v1722_12;
    if (!v1722_10.empty()) {
      const Path v1727_6 = concat_path(p0,v1721_11_head);
      Space v1727_11_result;
      for (int v1727_11_label = 1; v1727_11_label <= 2; ++v1727_11_label) {
        const Space v1727_11_tail = child(v1721_11_tail,v1727_11_label);
        if (v1727_11_tail.empty()) continue;
        const Path v1727_11_head{v1727_11_label};
        const Space v1728_2 = singleton(v1727_11_head);
        const Space v1728_3 = intersect(constant_6,v1728_2);
        const Space v1728_4 = (has_head(v1728_3) ? constant_7 : Space{});
        const Space v1728_5 = subtract(constant_0,v1728_4);
        Space v1728_8;
        if (!v1728_5.empty()) {
          const Path v1729_6 = concat_path(v1727_6,v1727_11_head);
          const Space v1729_7 = routine_231(c, v1729_6, v1727_11_tail);
          v1728_8 = compose(v1728_5,v1729_7);
        }
        const Space v1728_9 = intersect(constant_6,v1728_2);
        const Space v1728_10 = (has_head(v1728_9) ? constant_7 : Space{});
        Space v1728_12;
        if (!v1728_10.empty()) {
          const Path v1730_6 = concat_path(v1727_6,v1727_11_head);
          const Space v1730_11 = routine_72(c, v1730_6, v1727_11_tail);
          v1728_12 = compose(v1728_10,v1730_11);
        }
        const Space v1728_13 = unite(v1728_8,v1728_12);
        v1727_11_result = unite(v1727_11_result,v1728_13);
      }
      const Space v1727_11 = std::move(v1727_11_result);
      v1722_12 = compose(v1722_10,v1727_11);
    }
    const Space v1722_13 = unite(v1722_8,v1722_12);
    v1721_11_result = unite(v1721_11_result,v1722_13);
  }
  const Space v1721_11 = std::move(v1721_11_result);
  return v1721_11;
}

static Space routine_190(Context& c, const Path& p0, const Space& s0) {
  Space v1731_9_result;
  for (int v1731_9_label = 1; v1731_9_label <= 2; ++v1731_9_label) {
    const Space v1731_9_tail = child(s0,v1731_9_label);
    if (v1731_9_tail.empty()) continue;
    const Path v1731_9_head{v1731_9_label};
    const Space v1732_2 = singleton(v1731_9_head);
    const Space v1732_3 = intersect(constant_6,v1732_2);
    const Space v1732_4 = (has_head(v1732_3) ? constant_7 : Space{});
    const Space v1732_5 = subtract(constant_0,v1732_4);
    Space v1732_8;
    if (!v1732_5.empty()) {
      const Path v1733_6 = concat_path(p0,v1731_9_head);
      Space v1733_7_result;
      for (int v1733_7_label = 1; v1733_7_label <= 2; ++v1733_7_label) {
        const Space v1733_7_tail = child(v1731_9_tail,v1733_7_label);
        if (v1733_7_tail.empty()) continue;
        const Path v1733_7_head{v1733_7_label};
        const Space v1734_2 = singleton(v1733_7_head);
        const Space v1734_3 = intersect(constant_6,v1734_2);
        const Space v1734_4 = (has_head(v1734_3) ? constant_7 : Space{});
        const Space v1734_5 = subtract(constant_0,v1734_4);
        Space v1734_8;
        if (!v1734_5.empty()) {
          const Path v1735_6 = concat_path(v1733_6,v1733_7_head);
          const Space v1735_7 = routine_231(c, v1735_6, v1733_7_tail);
          v1734_8 = compose(v1734_5,v1735_7);
        }
        const Space v1734_9 = intersect(constant_6,v1734_2);
        const Space v1734_10 = (has_head(v1734_9) ? constant_7 : Space{});
        Space v1734_12;
        if (!v1734_10.empty()) {
          const Path v1736_6 = concat_path(v1733_6,v1733_7_head);
          const Space v1736_11 = routine_232(c, v1736_6, v1733_7_tail);
          v1734_12 = compose(v1734_10,v1736_11);
        }
        const Space v1734_13 = unite(v1734_8,v1734_12);
        v1733_7_result = unite(v1733_7_result,v1734_13);
      }
      const Space v1733_7 = std::move(v1733_7_result);
      v1732_8 = compose(v1732_5,v1733_7);
    }
    const Space v1732_9 = intersect(constant_6,v1732_2);
    const Space v1732_10 = (has_head(v1732_9) ? constant_7 : Space{});
    const Space v1732_11 = compose(v1732_10,constant_9);
    const Space v1732_12 = unite(v1732_8,v1732_11);
    v1731_9_result = unite(v1731_9_result,v1732_12);
  }
  const Space v1731_9 = std::move(v1731_9_result);
  return v1731_9;
}

static Space routine_191(Context& c, const Path& p0, const Space& s0) {
  Space v1737_11_result;
  for (int v1737_11_label = 1; v1737_11_label <= 2; ++v1737_11_label) {
    const Space v1737_11_tail = child(s0,v1737_11_label);
    if (v1737_11_tail.empty()) continue;
    const Path v1737_11_head{v1737_11_label};
    const Space v1738_2 = singleton(v1737_11_head);
    const Space v1738_3 = intersect(constant_6,v1738_2);
    const Space v1738_4 = (has_head(v1738_3) ? constant_7 : Space{});
    const Space v1738_5 = subtract(constant_0,v1738_4);
    Space v1738_8;
    if (!v1738_5.empty()) {
      const Path v1739_6 = concat_path(p0,v1737_11_head);
      Space v1739_7_result;
      for (int v1739_7_label = 1; v1739_7_label <= 2; ++v1739_7_label) {
        const Space v1739_7_tail = child(v1737_11_tail,v1739_7_label);
        if (v1739_7_tail.empty()) continue;
        const Path v1739_7_head{v1739_7_label};
        const Space v1740_2 = singleton(v1739_7_head);
        const Space v1740_3 = intersect(constant_6,v1740_2);
        const Space v1740_4 = (has_head(v1740_3) ? constant_7 : Space{});
        const Space v1740_5 = subtract(constant_0,v1740_4);
        Space v1740_8;
        if (!v1740_5.empty()) {
          const Path v1741_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1741_7 = routine_233(c, v1741_6, v1739_7_tail);
          v1740_8 = compose(v1740_5,v1741_7);
        }
        const Space v1740_9 = intersect(constant_6,v1740_2);
        const Space v1740_10 = (has_head(v1740_9) ? constant_7 : Space{});
        Space v1740_12;
        if (!v1740_10.empty()) {
          const Path v1742_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1742_11 = routine_234(c, v1742_6, v1739_7_tail);
          v1740_12 = compose(v1740_10,v1742_11);
        }
        const Space v1740_13 = unite(v1740_8,v1740_12);
        v1739_7_result = unite(v1739_7_result,v1740_13);
      }
      const Space v1739_7 = std::move(v1739_7_result);
      v1738_8 = compose(v1738_5,v1739_7);
    }
    const Space v1738_9 = intersect(constant_6,v1738_2);
    const Space v1738_10 = (has_head(v1738_9) ? constant_7 : Space{});
    Space v1738_12;
    if (!v1738_10.empty()) {
      const Path v1743_6 = concat_path(p0,v1737_11_head);
      Space v1743_11_result;
      for (int v1743_11_label = 1; v1743_11_label <= 2; ++v1743_11_label) {
        const Space v1743_11_tail = child(v1737_11_tail,v1743_11_label);
        if (v1743_11_tail.empty()) continue;
        const Path v1743_11_head{v1743_11_label};
        const Space v1744_2 = singleton(v1743_11_head);
        const Space v1744_3 = intersect(constant_6,v1744_2);
        const Space v1744_4 = (has_head(v1744_3) ? constant_7 : Space{});
        const Space v1744_5 = subtract(constant_0,v1744_4);
        Space v1744_8;
        if (!v1744_5.empty()) {
          const Path v1745_6 = concat_path(v1743_6,v1743_11_head);
          const Space v1745_7 = routine_233(c, v1745_6, v1743_11_tail);
          v1744_8 = compose(v1744_5,v1745_7);
        }
        const Space v1744_9 = intersect(constant_6,v1744_2);
        const Space v1744_10 = (has_head(v1744_9) ? constant_7 : Space{});
        Space v1744_12;
        if (!v1744_10.empty()) {
          const Path v1746_6 = concat_path(v1743_6,v1743_11_head);
          const Space v1746_11 = routine_75(c, v1746_6, v1743_11_tail);
          v1744_12 = compose(v1744_10,v1746_11);
        }
        const Space v1744_13 = unite(v1744_8,v1744_12);
        v1743_11_result = unite(v1743_11_result,v1744_13);
      }
      const Space v1743_11 = std::move(v1743_11_result);
      v1738_12 = compose(v1738_10,v1743_11);
    }
    const Space v1738_13 = unite(v1738_8,v1738_12);
    v1737_11_result = unite(v1737_11_result,v1738_13);
  }
  const Space v1737_11 = std::move(v1737_11_result);
  return v1737_11;
}

static Space routine_192(Context& c, const Path& p0, const Space& s0) {
  Space v1747_8_result;
  for (int v1747_8_label = 1; v1747_8_label <= 2; ++v1747_8_label) {
    const Space v1747_8_tail = child(s0,v1747_8_label);
    if (v1747_8_tail.empty()) continue;
    const Path v1747_8_head{v1747_8_label};
    const Space v1748_2 = singleton(v1747_8_head);
    const Space v1748_3 = intersect(constant_6,v1748_2);
    const Space v1748_4 = (has_head(v1748_3) ? constant_7 : Space{});
    const Space v1748_5 = subtract(constant_0,v1748_4);
    Space v1748_8;
    if (!v1748_5.empty()) {
      const Path v1749_6 = concat_path(p0,v1747_8_head);
      Space v1749_7_result;
      for (int v1749_7_label = 1; v1749_7_label <= 2; ++v1749_7_label) {
        const Space v1749_7_tail = child(v1747_8_tail,v1749_7_label);
        if (v1749_7_tail.empty()) continue;
        const Path v1749_7_head{v1749_7_label};
        const Space v1750_2 = singleton(v1749_7_head);
        const Space v1750_3 = intersect(constant_6,v1750_2);
        const Space v1750_4 = (has_head(v1750_3) ? constant_7 : Space{});
        const Space v1750_5 = subtract(constant_0,v1750_4);
        Space v1750_8;
        if (!v1750_5.empty()) {
          const Path v1751_6 = concat_path(v1749_6,v1749_7_head);
          const Space v1751_7 = routine_233(c, v1751_6, v1749_7_tail);
          v1750_8 = compose(v1750_5,v1751_7);
        }
        const Space v1750_9 = intersect(constant_6,v1750_2);
        const Space v1750_10 = (has_head(v1750_9) ? constant_7 : Space{});
        Space v1750_12;
        if (!v1750_10.empty()) {
          const Path v1752_6 = concat_path(v1749_6,v1749_7_head);
          const Space v1752_11 = routine_234(c, v1752_6, v1749_7_tail);
          v1750_12 = compose(v1750_10,v1752_11);
        }
        const Space v1750_13 = unite(v1750_8,v1750_12);
        v1749_7_result = unite(v1749_7_result,v1750_13);
      }
      const Space v1749_7 = std::move(v1749_7_result);
      v1748_8 = compose(v1748_5,v1749_7);
    }
    const Space v1748_9 = intersect(constant_6,v1748_2);
    const Space v1748_10 = (has_head(v1748_9) ? constant_7 : Space{});
    const Space v1748_11 = compose(v1748_10,v1747_8_tail);
    const Space v1748_12 = unite(v1748_8,v1748_11);
    v1747_8_result = unite(v1747_8_result,v1748_12);
  }
  const Space v1747_8 = std::move(v1747_8_result);
  return v1747_8;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1753_12_result;
  for (int v1753_12_label = 1; v1753_12_label <= 2; ++v1753_12_label) {
    const Space v1753_12_tail = child(s0,v1753_12_label);
    if (v1753_12_tail.empty()) continue;
    const Path v1753_12_head{v1753_12_label};
    const Space v1754_2 = singleton(v1753_12_head);
    const Space v1754_3 = intersect(constant_6,v1754_2);
    const Space v1754_4 = (has_head(v1754_3) ? constant_7 : Space{});
    const Space v1754_5 = subtract(constant_0,v1754_4);
    Space v1754_8;
    if (!v1754_5.empty()) {
      const Path v1755_6 = concat_path(p0,v1753_12_head);
      Space v1755_7_result;
      for (int v1755_7_label = 1; v1755_7_label <= 2; ++v1755_7_label) {
        const Space v1755_7_tail = child(v1753_12_tail,v1755_7_label);
        if (v1755_7_tail.empty()) continue;
        const Path v1755_7_head{v1755_7_label};
        const Space v1756_2 = singleton(v1755_7_head);
        const Space v1756_3 = intersect(constant_6,v1756_2);
        const Space v1756_4 = (has_head(v1756_3) ? constant_7 : Space{});
        const Space v1756_5 = subtract(constant_0,v1756_4);
        Space v1756_8;
        if (!v1756_5.empty()) {
          const Path v1757_6 = concat_path(v1755_6,v1755_7_head);
          const Space v1757_7 = routine_235(c, v1757_6, p1, v1755_7_tail);
          v1756_8 = compose(v1756_5,v1757_7);
        }
        const Space v1756_9 = intersect(constant_6,v1756_2);
        const Space v1756_10 = (has_head(v1756_9) ? constant_7 : Space{});
        Space v1756_12;
        if (!v1756_10.empty()) {
          const Path v1758_6 = concat_path(v1755_6,v1755_7_head);
          const Space v1758_11 = routine_236(c, v1758_6, p1, v1755_7_tail);
          v1756_12 = compose(v1756_10,v1758_11);
        }
        const Space v1756_13 = unite(v1756_8,v1756_12);
        v1755_7_result = unite(v1755_7_result,v1756_13);
      }
      const Space v1755_7 = std::move(v1755_7_result);
      v1754_8 = compose(v1754_5,v1755_7);
    }
    const Space v1754_9 = intersect(constant_6,v1754_2);
    const Space v1754_10 = (has_head(v1754_9) ? constant_7 : Space{});
    Space v1754_12;
    if (!v1754_10.empty()) {
      const Path v1759_6 = concat_path(p0,v1753_12_head);
      Space v1759_11_result;
      for (int v1759_11_label = 1; v1759_11_label <= 2; ++v1759_11_label) {
        const Space v1759_11_tail = child(v1753_12_tail,v1759_11_label);
        if (v1759_11_tail.empty()) continue;
        const Path v1759_11_head{v1759_11_label};
        const Space v1760_2 = singleton(v1759_11_head);
        const Space v1760_3 = intersect(constant_6,v1760_2);
        const Space v1760_4 = (has_head(v1760_3) ? constant_7 : Space{});
        const Space v1760_5 = subtract(constant_0,v1760_4);
        Space v1760_8;
        if (!v1760_5.empty()) {
          const Path v1761_6 = concat_path(v1759_6,v1759_11_head);
          const Space v1761_7 = routine_235(c, v1761_6, p1, v1759_11_tail);
          v1760_8 = compose(v1760_5,v1761_7);
        }
        const Space v1760_9 = intersect(constant_6,v1760_2);
        const Space v1760_10 = (has_head(v1760_9) ? constant_7 : Space{});
        Space v1760_12;
        if (!v1760_10.empty()) {
          const Path v1762_6 = concat_path(v1759_6,v1759_11_head);
          const Space v1762_11 = routine_42(c, v1762_6, p1, v1759_11_tail);
          v1760_12 = compose(v1760_10,v1762_11);
        }
        const Space v1760_13 = unite(v1760_8,v1760_12);
        v1759_11_result = unite(v1759_11_result,v1760_13);
      }
      const Space v1759_11 = std::move(v1759_11_result);
      v1754_12 = compose(v1754_10,v1759_11);
    }
    const Space v1754_13 = unite(v1754_8,v1754_12);
    v1753_12_result = unite(v1753_12_result,v1754_13);
  }
  const Space v1753_12 = std::move(v1753_12_result);
  return v1753_12;
}

static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1763_9_result;
  for (int v1763_9_label = 1; v1763_9_label <= 2; ++v1763_9_label) {
    const Space v1763_9_tail = child(s0,v1763_9_label);
    if (v1763_9_tail.empty()) continue;
    const Path v1763_9_head{v1763_9_label};
    const Space v1764_2 = singleton(v1763_9_head);
    const Space v1764_3 = intersect(constant_6,v1764_2);
    const Space v1764_4 = (has_head(v1764_3) ? constant_7 : Space{});
    const Space v1764_5 = subtract(constant_0,v1764_4);
    Space v1764_8;
    if (!v1764_5.empty()) {
      const Path v1765_6 = concat_path(p0,v1763_9_head);
      Space v1765_7_result;
      for (int v1765_7_label = 1; v1765_7_label <= 2; ++v1765_7_label) {
        const Space v1765_7_tail = child(v1763_9_tail,v1765_7_label);
        if (v1765_7_tail.empty()) continue;
        const Path v1765_7_head{v1765_7_label};
        const Space v1766_2 = singleton(v1765_7_head);
        const Space v1766_3 = intersect(constant_6,v1766_2);
        const Space v1766_4 = (has_head(v1766_3) ? constant_7 : Space{});
        const Space v1766_5 = subtract(constant_0,v1766_4);
        Space v1766_8;
        if (!v1766_5.empty()) {
          const Path v1767_6 = concat_path(v1765_6,v1765_7_head);
          const Space v1767_7 = routine_235(c, v1767_6, p1, v1765_7_tail);
          v1766_8 = compose(v1766_5,v1767_7);
        }
        const Space v1766_9 = intersect(constant_6,v1766_2);
        const Space v1766_10 = (has_head(v1766_9) ? constant_7 : Space{});
        Space v1766_12;
        if (!v1766_10.empty()) {
          const Path v1768_6 = concat_path(v1765_6,v1765_7_head);
          const Space v1768_11 = routine_236(c, v1768_6, p1, v1765_7_tail);
          v1766_12 = compose(v1766_10,v1768_11);
        }
        const Space v1766_13 = unite(v1766_8,v1766_12);
        v1765_7_result = unite(v1765_7_result,v1766_13);
      }
      const Space v1765_7 = std::move(v1765_7_result);
      v1764_8 = compose(v1764_5,v1765_7);
    }
    const Space v1764_9 = intersect(constant_6,v1764_2);
    const Space v1764_10 = (has_head(v1764_9) ? constant_7 : Space{});
    Space v1764_13;
    if (!v1764_10.empty()) {
      const Path v1769_6 = concat_path(p0,v1763_9_head);
      const Path v1769_11 = concat_path(p1,v1769_6);
      const Space v1769_12 = routine_29(c, v1769_11);
      v1764_13 = compose(v1764_10,v1769_12);
    }
    const Space v1764_14 = unite(v1764_8,v1764_13);
    v1763_9_result = unite(v1763_9_result,v1764_14);
  }
  const Space v1763_9 = std::move(v1763_9_result);
  return v1763_9;
}

static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1770_5_result;
  for (int v1770_5_label = 1; v1770_5_label <= 2; ++v1770_5_label) {
    const Space v1770_5_tail = child(s0,v1770_5_label);
    if (v1770_5_tail.empty()) continue;
    const Path v1770_5_head{v1770_5_label};
    const Space v1771_2 = singleton(v1770_5_head);
    const Space v1771_3 = intersect(constant_6,v1771_2);
    const Space v1771_4 = (has_head(v1771_3) ? constant_7 : Space{});
    Space v1771_7;
    if (!v1771_4.empty()) {
      const Path v1772_5 = concat_path(p0,v1770_5_head);
      Space v1772_6_result;
      for (int v1772_6_label = 1; v1772_6_label <= 2; ++v1772_6_label) {
        const Space v1772_6_tail = child(v1770_5_tail,v1772_6_label);
        if (v1772_6_tail.empty()) continue;
        const Path v1772_6_head{v1772_6_label};
        const Space v1773_2 = singleton(v1772_6_head);
        const Space v1773_3 = intersect(constant_6,v1773_2);
        const Space v1773_4 = (has_head(v1773_3) ? constant_7 : Space{});
        Space v1773_7;
        if (!v1773_4.empty()) {
          const Path v1774_5 = concat_path(v1772_5,v1772_6_head);
          const Space v1774_6 = routine_42(c, v1774_5, p1, v1772_6_tail);
          v1773_7 = compose(v1773_4,v1774_6);
        }
        v1772_6_result = unite(v1772_6_result,v1773_7);
      }
      const Space v1772_6 = std::move(v1772_6_result);
      v1771_7 = compose(v1771_4,v1772_6);
    }
    v1770_5_result = unite(v1770_5_result,v1771_7);
  }
  const Space v1770_5 = std::move(v1770_5_result);
  return v1770_5;
}

static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1775_4_result;
  for (int v1775_4_label = 1; v1775_4_label <= 2; ++v1775_4_label) {
    const Space v1775_4_tail = child(s0,v1775_4_label);
    if (v1775_4_tail.empty()) continue;
    const Path v1775_4_head{v1775_4_label};
    const Space v1776_2 = singleton(v1775_4_head);
    const Space v1776_3 = intersect(constant_6,v1776_2);
    const Space v1776_4 = (has_head(v1776_3) ? constant_7 : Space{});
    Space v1776_8;
    if (!v1776_4.empty()) {
      const Path v1777_5 = concat_path(p0,v1775_4_head);
      const Path v1777_6 = concat_path(p1,v1777_5);
      const Space v1777_7 = routine_29(c, v1777_6);
      v1776_8 = compose(v1776_4,v1777_7);
    }
    v1775_4_result = unite(v1775_4_result,v1776_8);
  }
  const Space v1775_4 = std::move(v1775_4_result);
  return v1775_4;
}

static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1778_13_result;
  for (int v1778_13_label = 1; v1778_13_label <= 2; ++v1778_13_label) {
    const Space v1778_13_tail = child(s0,v1778_13_label);
    if (v1778_13_tail.empty()) continue;
    const Path v1778_13_head{v1778_13_label};
    const Space v1779_2 = singleton(v1778_13_head);
    const Space v1779_3 = intersect(constant_6,v1779_2);
    const Space v1779_4 = (has_head(v1779_3) ? constant_7 : Space{});
    const Space v1779_5 = subtract(constant_0,v1779_4);
    Space v1779_8;
    if (!v1779_5.empty()) {
      const Path v1780_6 = concat_path(p0,v1778_13_head);
      Space v1780_7_result;
      for (int v1780_7_label = 1; v1780_7_label <= 2; ++v1780_7_label) {
        const Space v1780_7_tail = child(v1778_13_tail,v1780_7_label);
        if (v1780_7_tail.empty()) continue;
        const Path v1780_7_head{v1780_7_label};
        const Space v1781_2 = singleton(v1780_7_head);
        const Space v1781_3 = intersect(constant_6,v1781_2);
        const Space v1781_4 = (has_head(v1781_3) ? constant_7 : Space{});
        const Space v1781_5 = subtract(constant_0,v1781_4);
        Space v1781_8;
        if (!v1781_5.empty()) {
          const Path v1782_6 = concat_path(v1780_6,v1780_7_head);
          const Space v1782_7 = routine_237(c, v1782_6, p1, v1780_7_tail, s1);
          v1781_8 = compose(v1781_5,v1782_7);
        }
        const Space v1781_9 = intersect(constant_6,v1781_2);
        const Space v1781_10 = (has_head(v1781_9) ? constant_7 : Space{});
        Space v1781_12;
        if (!v1781_10.empty()) {
          const Path v1783_6 = concat_path(v1780_6,v1780_7_head);
          const Space v1783_11 = routine_238(c, v1783_6, p1, v1780_7_tail, s1);
          v1781_12 = compose(v1781_10,v1783_11);
        }
        const Space v1781_13 = unite(v1781_8,v1781_12);
        v1780_7_result = unite(v1780_7_result,v1781_13);
      }
      const Space v1780_7 = std::move(v1780_7_result);
      v1779_8 = compose(v1779_5,v1780_7);
    }
    const Space v1779_9 = intersect(constant_6,v1779_2);
    const Space v1779_10 = (has_head(v1779_9) ? constant_7 : Space{});
    Space v1779_12;
    if (!v1779_10.empty()) {
      const Path v1784_6 = concat_path(p0,v1778_13_head);
      Space v1784_11_result;
      for (int v1784_11_label = 1; v1784_11_label <= 2; ++v1784_11_label) {
        const Space v1784_11_tail = child(v1778_13_tail,v1784_11_label);
        if (v1784_11_tail.empty()) continue;
        const Path v1784_11_head{v1784_11_label};
        const Space v1785_2 = singleton(v1784_11_head);
        const Space v1785_3 = intersect(constant_6,v1785_2);
        const Space v1785_4 = (has_head(v1785_3) ? constant_7 : Space{});
        const Space v1785_5 = subtract(constant_0,v1785_4);
        Space v1785_8;
        if (!v1785_5.empty()) {
          const Path v1786_6 = concat_path(v1784_6,v1784_11_head);
          const Space v1786_7 = routine_237(c, v1786_6, p1, v1784_11_tail, s1);
          v1785_8 = compose(v1785_5,v1786_7);
        }
        const Space v1785_9 = intersect(constant_6,v1785_2);
        const Space v1785_10 = (has_head(v1785_9) ? constant_7 : Space{});
        Space v1785_12;
        if (!v1785_10.empty()) {
          const Path v1787_6 = concat_path(v1784_6,v1784_11_head);
          const Space v1787_11 = routine_49(c, v1787_6, p1, v1784_11_tail, s1);
          v1785_12 = compose(v1785_10,v1787_11);
        }
        const Space v1785_13 = unite(v1785_8,v1785_12);
        v1784_11_result = unite(v1784_11_result,v1785_13);
      }
      const Space v1784_11 = std::move(v1784_11_result);
      v1779_12 = compose(v1779_10,v1784_11);
    }
    const Space v1779_13 = unite(v1779_8,v1779_12);
    v1778_13_result = unite(v1778_13_result,v1779_13);
  }
  const Space v1778_13 = std::move(v1778_13_result);
  return v1778_13;
}

static Space routine_198(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1788_8 = unwrap(s1,constant_8);
  Space v1788_21_result;
  for (int v1788_21_label = 1; v1788_21_label <= 2; ++v1788_21_label) {
    const Space v1788_21_tail = child(s0,v1788_21_label);
    if (v1788_21_tail.empty()) continue;
    const Path v1788_21_head{v1788_21_label};
    const Space v1789_2 = singleton(v1788_21_head);
    const Space v1789_3 = intersect(constant_6,v1789_2);
    const Space v1789_4 = (has_head(v1789_3) ? constant_7 : Space{});
    const Space v1789_5 = subtract(constant_0,v1789_4);
    Space v1789_8;
    if (!v1789_5.empty()) {
      const Path v1790_6 = concat_path(p0,v1788_21_head);
      Space v1790_7_result;
      for (int v1790_7_label = 1; v1790_7_label <= 2; ++v1790_7_label) {
        const Space v1790_7_tail = child(v1788_21_tail,v1790_7_label);
        if (v1790_7_tail.empty()) continue;
        const Path v1790_7_head{v1790_7_label};
        const Space v1791_2 = singleton(v1790_7_head);
        const Space v1791_3 = intersect(constant_6,v1791_2);
        const Space v1791_4 = (has_head(v1791_3) ? constant_7 : Space{});
        const Space v1791_5 = subtract(constant_0,v1791_4);
        Space v1791_8;
        if (!v1791_5.empty()) {
          const Path v1792_6 = concat_path(v1790_6,v1790_7_head);
          const Space v1792_7 = routine_237(c, v1792_6, p1, v1790_7_tail, s1);
          v1791_8 = compose(v1791_5,v1792_7);
        }
        const Space v1791_9 = intersect(constant_6,v1791_2);
        const Space v1791_10 = (has_head(v1791_9) ? constant_7 : Space{});
        Space v1791_12;
        if (!v1791_10.empty()) {
          const Path v1793_6 = concat_path(v1790_6,v1790_7_head);
          const Space v1793_11 = routine_238(c, v1793_6, p1, v1790_7_tail, s1);
          v1791_12 = compose(v1791_10,v1793_11);
        }
        const Space v1791_13 = unite(v1791_8,v1791_12);
        v1790_7_result = unite(v1790_7_result,v1791_13);
      }
      const Space v1790_7 = std::move(v1790_7_result);
      v1789_8 = compose(v1789_5,v1790_7);
    }
    const Space v1789_9 = intersect(constant_6,v1789_2);
    const Space v1789_10 = (has_head(v1789_9) ? constant_7 : Space{});
    Space v1789_22;
    if (!v1789_10.empty()) {
      const Path v1794_6 = concat_path(p0,v1788_21_head);
      const Path v1794_11 = concat_path(p1,v1794_6);
      const Space v1794_12 = routine_29(c, v1794_11);
      const Space v1794_13 = intersect(v1788_8,v1794_12);
      const Space v1794_14 = routine_33(c, v1794_13);
      Space v1794_15_result;
      for (int v1794_15_label = 1; v1794_15_label <= 2; ++v1794_15_label) {
        const Space v1794_15_tail = child(v1794_14,v1794_15_label);
        if (v1794_15_tail.empty()) continue;
        const Path v1794_15_head{v1794_15_label};
        const Space v1795_2 = singleton(v1794_15_head);
        const Space v1795_3 = intersect(constant_6,v1795_2);
        const Space v1795_4 = (has_head(v1795_3) ? constant_7 : Space{});
        const Space v1795_5 = subtract(constant_0,v1795_4);
        Space v1795_7;
        if (!v1795_5.empty()) {
          const Space v1796_6 = routine_52(c, v1794_15_head, v1794_15_tail);
          v1795_7 = compose(v1795_5,v1796_6);
        }
        const Space v1795_8 = intersect(constant_6,v1795_2);
        const Space v1795_9 = (has_head(v1795_8) ? constant_7 : Space{});
        Space v1795_11;
        if (!v1795_9.empty()) {
          const Space v1797_10 = routine_53(c, v1794_15_head, v1794_15_tail);
          v1795_11 = compose(v1795_9,v1797_10);
        }
        const Space v1795_12 = unite(v1795_7,v1795_11);
        v1794_15_result = unite(v1794_15_result,v1795_12);
      }
      const Space v1794_15 = std::move(v1794_15_result);
      const Space v1794_16 = routine_54(c, v1794_13);
      Space v1794_17_result;
      for (int v1794_17_label = 1; v1794_17_label <= 2; ++v1794_17_label) {
        const Space v1794_17_tail = child(v1794_16,v1794_17_label);
        if (v1794_17_tail.empty()) continue;
        const Path v1794_17_head{v1794_17_label};
        const Space v1798_2 = singleton(v1794_17_head);
        const Space v1798_3 = intersect(constant_6,v1798_2);
        const Space v1798_4 = (has_head(v1798_3) ? constant_7 : Space{});
        const Space v1798_5 = subtract(constant_0,v1798_4);
        Space v1798_7;
        if (!v1798_5.empty()) {
          const Space v1799_6 = routine_55(c, v1794_17_head, v1794_17_tail);
          v1798_7 = compose(v1798_5,v1799_6);
        }
        const Space v1798_8 = intersect(constant_6,v1798_2);
        const Space v1798_9 = (has_head(v1798_8) ? constant_7 : Space{});
        Space v1798_11;
        if (!v1798_9.empty()) {
          const Space v1800_10 = routine_56(c, v1794_17_head, v1794_17_tail);
          v1798_11 = compose(v1798_9,v1800_10);
        }
        const Space v1798_12 = unite(v1798_7,v1798_11);
        v1794_17_result = unite(v1794_17_result,v1798_12);
      }
      const Space v1794_17 = std::move(v1794_17_result);
      const Space v1794_18 = subtract(v1794_15,v1794_17);
      const Space v1794_19 = singleton(v1794_11);
      const Space v1794_20 = compose(v1794_18,v1794_19);
      Space v1794_21_result;
      for (int v1794_21_label = 1; v1794_21_label <= 2; ++v1794_21_label) {
        const Space v1794_21_tail = child(v1794_20,v1794_21_label);
        if (v1794_21_tail.empty()) continue;
        const Path v1794_21_head{v1794_21_label};
        const Space v1801_2 = singleton(v1794_21_head);
        const Space v1801_3 = intersect(constant_6,v1801_2);
        const Space v1801_4 = (has_head(v1801_3) ? constant_7 : Space{});
        const Space v1801_5 = subtract(constant_0,v1801_4);
        Space v1801_7;
        if (!v1801_5.empty()) {
          const Space v1802_6 = routine_57(c, v1794_21_head, v1794_21_tail);
          v1801_7 = compose(v1801_5,v1802_6);
        }
        const Space v1801_8 = intersect(constant_6,v1801_2);
        const Space v1801_9 = (has_head(v1801_8) ? constant_7 : Space{});
        Space v1801_11;
        if (!v1801_9.empty()) {
          const Space v1803_10 = routine_58(c, v1794_21_head, v1794_21_tail);
          v1801_11 = compose(v1801_9,v1803_10);
        }
        const Space v1801_12 = unite(v1801_7,v1801_11);
        v1794_21_result = unite(v1794_21_result,v1801_12);
      }
      const Space v1794_21 = std::move(v1794_21_result);
      v1789_22 = compose(v1789_10,v1794_21);
    }
    const Space v1789_23 = unite(v1789_8,v1789_22);
    v1788_21_result = unite(v1788_21_result,v1789_23);
  }
  const Space v1788_21 = std::move(v1788_21_result);
  return v1788_21;
}

static Space routine_199(Context& c, const Path& p0, const Space& s0) {
  Space v1804_11_result;
  for (int v1804_11_label = 1; v1804_11_label <= 2; ++v1804_11_label) {
    const Space v1804_11_tail = child(s0,v1804_11_label);
    if (v1804_11_tail.empty()) continue;
    const Path v1804_11_head{v1804_11_label};
    const Space v1805_2 = singleton(v1804_11_head);
    const Space v1805_3 = intersect(constant_6,v1805_2);
    const Space v1805_4 = (has_head(v1805_3) ? constant_7 : Space{});
    const Space v1805_5 = subtract(constant_0,v1805_4);
    Space v1805_8;
    if (!v1805_5.empty()) {
      const Path v1806_6 = concat_path(p0,v1804_11_head);
      Space v1806_7_result;
      for (int v1806_7_label = 1; v1806_7_label <= 2; ++v1806_7_label) {
        const Space v1806_7_tail = child(v1804_11_tail,v1806_7_label);
        if (v1806_7_tail.empty()) continue;
        const Path v1806_7_head{v1806_7_label};
        const Space v1807_2 = singleton(v1806_7_head);
        const Space v1807_3 = intersect(constant_6,v1807_2);
        const Space v1807_4 = (has_head(v1807_3) ? constant_7 : Space{});
        const Space v1807_5 = subtract(constant_0,v1807_4);
        Space v1807_8;
        if (!v1807_5.empty()) {
          const Path v1808_6 = concat_path(v1806_6,v1806_7_head);
          const Space v1808_7 = routine_239(c, v1808_6, v1806_7_tail);
          v1807_8 = compose(v1807_5,v1808_7);
        }
        const Space v1807_9 = intersect(constant_6,v1807_2);
        const Space v1807_10 = (has_head(v1807_9) ? constant_7 : Space{});
        Space v1807_12;
        if (!v1807_10.empty()) {
          const Path v1809_6 = concat_path(v1806_6,v1806_7_head);
          const Space v1809_11 = routine_240(c, v1809_6, v1806_7_tail);
          v1807_12 = compose(v1807_10,v1809_11);
        }
        const Space v1807_13 = unite(v1807_8,v1807_12);
        v1806_7_result = unite(v1806_7_result,v1807_13);
      }
      const Space v1806_7 = std::move(v1806_7_result);
      v1805_8 = compose(v1805_5,v1806_7);
    }
    const Space v1805_9 = intersect(constant_6,v1805_2);
    const Space v1805_10 = (has_head(v1805_9) ? constant_7 : Space{});
    Space v1805_12;
    if (!v1805_10.empty()) {
      const Path v1810_6 = concat_path(p0,v1804_11_head);
      Space v1810_11_result;
      for (int v1810_11_label = 1; v1810_11_label <= 2; ++v1810_11_label) {
        const Space v1810_11_tail = child(v1804_11_tail,v1810_11_label);
        if (v1810_11_tail.empty()) continue;
        const Path v1810_11_head{v1810_11_label};
        const Space v1811_2 = singleton(v1810_11_head);
        const Space v1811_3 = intersect(constant_6,v1811_2);
        const Space v1811_4 = (has_head(v1811_3) ? constant_7 : Space{});
        const Space v1811_5 = subtract(constant_0,v1811_4);
        Space v1811_8;
        if (!v1811_5.empty()) {
          const Path v1812_6 = concat_path(v1810_6,v1810_11_head);
          const Space v1812_7 = routine_239(c, v1812_6, v1810_11_tail);
          v1811_8 = compose(v1811_5,v1812_7);
        }
        const Space v1811_9 = intersect(constant_6,v1811_2);
        const Space v1811_10 = (has_head(v1811_9) ? constant_7 : Space{});
        Space v1811_12;
        if (!v1811_10.empty()) {
          const Path v1813_6 = concat_path(v1810_6,v1810_11_head);
          const Space v1813_11 = routine_100(c, v1813_6, v1810_11_tail);
          v1811_12 = compose(v1811_10,v1813_11);
        }
        const Space v1811_13 = unite(v1811_8,v1811_12);
        v1810_11_result = unite(v1810_11_result,v1811_13);
      }
      const Space v1810_11 = std::move(v1810_11_result);
      v1805_12 = compose(v1805_10,v1810_11);
    }
    const Space v1805_13 = unite(v1805_8,v1805_12);
    v1804_11_result = unite(v1804_11_result,v1805_13);
  }
  const Space v1804_11 = std::move(v1804_11_result);
  return v1804_11;
}

static Space routine_200(Context& c, const Path& p0, const Space& s0) {
  Space v1814_9_result;
  for (int v1814_9_label = 1; v1814_9_label <= 2; ++v1814_9_label) {
    const Space v1814_9_tail = child(s0,v1814_9_label);
    if (v1814_9_tail.empty()) continue;
    const Path v1814_9_head{v1814_9_label};
    const Space v1815_2 = singleton(v1814_9_head);
    const Space v1815_3 = intersect(constant_6,v1815_2);
    const Space v1815_4 = (has_head(v1815_3) ? constant_7 : Space{});
    const Space v1815_5 = subtract(constant_0,v1815_4);
    Space v1815_8;
    if (!v1815_5.empty()) {
      const Path v1816_6 = concat_path(p0,v1814_9_head);
      Space v1816_7_result;
      for (int v1816_7_label = 1; v1816_7_label <= 2; ++v1816_7_label) {
        const Space v1816_7_tail = child(v1814_9_tail,v1816_7_label);
        if (v1816_7_tail.empty()) continue;
        const Path v1816_7_head{v1816_7_label};
        const Space v1817_2 = singleton(v1816_7_head);
        const Space v1817_3 = intersect(constant_6,v1817_2);
        const Space v1817_4 = (has_head(v1817_3) ? constant_7 : Space{});
        const Space v1817_5 = subtract(constant_0,v1817_4);
        Space v1817_8;
        if (!v1817_5.empty()) {
          const Path v1818_6 = concat_path(v1816_6,v1816_7_head);
          const Space v1818_7 = routine_239(c, v1818_6, v1816_7_tail);
          v1817_8 = compose(v1817_5,v1818_7);
        }
        const Space v1817_9 = intersect(constant_6,v1817_2);
        const Space v1817_10 = (has_head(v1817_9) ? constant_7 : Space{});
        Space v1817_12;
        if (!v1817_10.empty()) {
          const Path v1819_6 = concat_path(v1816_6,v1816_7_head);
          const Space v1819_11 = routine_240(c, v1819_6, v1816_7_tail);
          v1817_12 = compose(v1817_10,v1819_11);
        }
        const Space v1817_13 = unite(v1817_8,v1817_12);
        v1816_7_result = unite(v1816_7_result,v1817_13);
      }
      const Space v1816_7 = std::move(v1816_7_result);
      v1815_8 = compose(v1815_5,v1816_7);
    }
    const Space v1815_9 = intersect(constant_6,v1815_2);
    const Space v1815_10 = (has_head(v1815_9) ? constant_7 : Space{});
    const Space v1815_11 = compose(v1815_10,constant_9);
    const Space v1815_12 = unite(v1815_8,v1815_11);
    v1814_9_result = unite(v1814_9_result,v1815_12);
  }
  const Space v1814_9 = std::move(v1814_9_result);
  return v1814_9;
}

static Space routine_201(Context& c, const Path& p0, const Space& s0) {
  Space v1820_11_result;
  for (int v1820_11_label = 1; v1820_11_label <= 2; ++v1820_11_label) {
    const Space v1820_11_tail = child(s0,v1820_11_label);
    if (v1820_11_tail.empty()) continue;
    const Path v1820_11_head{v1820_11_label};
    const Space v1821_2 = singleton(v1820_11_head);
    const Space v1821_3 = intersect(constant_6,v1821_2);
    const Space v1821_4 = (has_head(v1821_3) ? constant_7 : Space{});
    const Space v1821_5 = subtract(constant_0,v1821_4);
    Space v1821_8;
    if (!v1821_5.empty()) {
      const Path v1822_6 = concat_path(p0,v1820_11_head);
      Space v1822_7_result;
      for (int v1822_7_label = 1; v1822_7_label <= 2; ++v1822_7_label) {
        const Space v1822_7_tail = child(v1820_11_tail,v1822_7_label);
        if (v1822_7_tail.empty()) continue;
        const Path v1822_7_head{v1822_7_label};
        const Space v1823_2 = singleton(v1822_7_head);
        const Space v1823_3 = intersect(constant_6,v1823_2);
        const Space v1823_4 = (has_head(v1823_3) ? constant_7 : Space{});
        const Space v1823_5 = subtract(constant_0,v1823_4);
        Space v1823_8;
        if (!v1823_5.empty()) {
          const Path v1824_6 = concat_path(v1822_6,v1822_7_head);
          const Space v1824_7 = routine_241(c, v1824_6, v1822_7_tail);
          v1823_8 = compose(v1823_5,v1824_7);
        }
        const Space v1823_9 = intersect(constant_6,v1823_2);
        const Space v1823_10 = (has_head(v1823_9) ? constant_7 : Space{});
        Space v1823_12;
        if (!v1823_10.empty()) {
          const Path v1825_6 = concat_path(v1822_6,v1822_7_head);
          const Space v1825_11 = routine_242(c, v1825_6, v1822_7_tail);
          v1823_12 = compose(v1823_10,v1825_11);
        }
        const Space v1823_13 = unite(v1823_8,v1823_12);
        v1822_7_result = unite(v1822_7_result,v1823_13);
      }
      const Space v1822_7 = std::move(v1822_7_result);
      v1821_8 = compose(v1821_5,v1822_7);
    }
    const Space v1821_9 = intersect(constant_6,v1821_2);
    const Space v1821_10 = (has_head(v1821_9) ? constant_7 : Space{});
    Space v1821_12;
    if (!v1821_10.empty()) {
      const Path v1826_6 = concat_path(p0,v1820_11_head);
      Space v1826_11_result;
      for (int v1826_11_label = 1; v1826_11_label <= 2; ++v1826_11_label) {
        const Space v1826_11_tail = child(v1820_11_tail,v1826_11_label);
        if (v1826_11_tail.empty()) continue;
        const Path v1826_11_head{v1826_11_label};
        const Space v1827_2 = singleton(v1826_11_head);
        const Space v1827_3 = intersect(constant_6,v1827_2);
        const Space v1827_4 = (has_head(v1827_3) ? constant_7 : Space{});
        const Space v1827_5 = subtract(constant_0,v1827_4);
        Space v1827_8;
        if (!v1827_5.empty()) {
          const Path v1828_6 = concat_path(v1826_6,v1826_11_head);
          const Space v1828_7 = routine_241(c, v1828_6, v1826_11_tail);
          v1827_8 = compose(v1827_5,v1828_7);
        }
        const Space v1827_9 = intersect(constant_6,v1827_2);
        const Space v1827_10 = (has_head(v1827_9) ? constant_7 : Space{});
        Space v1827_12;
        if (!v1827_10.empty()) {
          const Path v1829_6 = concat_path(v1826_6,v1826_11_head);
          const Space v1829_11 = routine_104(c, v1829_6, v1826_11_tail);
          v1827_12 = compose(v1827_10,v1829_11);
        }
        const Space v1827_13 = unite(v1827_8,v1827_12);
        v1826_11_result = unite(v1826_11_result,v1827_13);
      }
      const Space v1826_11 = std::move(v1826_11_result);
      v1821_12 = compose(v1821_10,v1826_11);
    }
    const Space v1821_13 = unite(v1821_8,v1821_12);
    v1820_11_result = unite(v1820_11_result,v1821_13);
  }
  const Space v1820_11 = std::move(v1820_11_result);
  return v1820_11;
}

static Space routine_202(Context& c, const Path& p0, const Space& s0) {
  Space v1830_9_result;
  for (int v1830_9_label = 1; v1830_9_label <= 2; ++v1830_9_label) {
    const Space v1830_9_tail = child(s0,v1830_9_label);
    if (v1830_9_tail.empty()) continue;
    const Path v1830_9_head{v1830_9_label};
    const Space v1831_2 = singleton(v1830_9_head);
    const Space v1831_3 = intersect(constant_6,v1831_2);
    const Space v1831_4 = (has_head(v1831_3) ? constant_7 : Space{});
    const Space v1831_5 = subtract(constant_0,v1831_4);
    Space v1831_8;
    if (!v1831_5.empty()) {
      const Path v1832_6 = concat_path(p0,v1830_9_head);
      Space v1832_7_result;
      for (int v1832_7_label = 1; v1832_7_label <= 2; ++v1832_7_label) {
        const Space v1832_7_tail = child(v1830_9_tail,v1832_7_label);
        if (v1832_7_tail.empty()) continue;
        const Path v1832_7_head{v1832_7_label};
        const Space v1833_2 = singleton(v1832_7_head);
        const Space v1833_3 = intersect(constant_6,v1833_2);
        const Space v1833_4 = (has_head(v1833_3) ? constant_7 : Space{});
        const Space v1833_5 = subtract(constant_0,v1833_4);
        Space v1833_8;
        if (!v1833_5.empty()) {
          const Path v1834_6 = concat_path(v1832_6,v1832_7_head);
          const Space v1834_7 = routine_241(c, v1834_6, v1832_7_tail);
          v1833_8 = compose(v1833_5,v1834_7);
        }
        const Space v1833_9 = intersect(constant_6,v1833_2);
        const Space v1833_10 = (has_head(v1833_9) ? constant_7 : Space{});
        Space v1833_12;
        if (!v1833_10.empty()) {
          const Path v1835_6 = concat_path(v1832_6,v1832_7_head);
          const Space v1835_11 = routine_242(c, v1835_6, v1832_7_tail);
          v1833_12 = compose(v1833_10,v1835_11);
        }
        const Space v1833_13 = unite(v1833_8,v1833_12);
        v1832_7_result = unite(v1832_7_result,v1833_13);
      }
      const Space v1832_7 = std::move(v1832_7_result);
      v1831_8 = compose(v1831_5,v1832_7);
    }
    const Space v1831_9 = intersect(constant_6,v1831_2);
    const Space v1831_10 = (has_head(v1831_9) ? constant_7 : Space{});
    const Space v1831_11 = compose(v1831_10,constant_9);
    const Space v1831_12 = unite(v1831_8,v1831_11);
    v1830_9_result = unite(v1830_9_result,v1831_12);
  }
  const Space v1830_9 = std::move(v1830_9_result);
  return v1830_9;
}

static Space routine_203(Context& c, const Path& p0, const Space& s0) {
  Space v1836_11_result;
  for (int v1836_11_label = 1; v1836_11_label <= 2; ++v1836_11_label) {
    const Space v1836_11_tail = child(s0,v1836_11_label);
    if (v1836_11_tail.empty()) continue;
    const Path v1836_11_head{v1836_11_label};
    const Space v1837_2 = singleton(v1836_11_head);
    const Space v1837_3 = intersect(constant_6,v1837_2);
    const Space v1837_4 = (has_head(v1837_3) ? constant_7 : Space{});
    const Space v1837_5 = subtract(constant_0,v1837_4);
    Space v1837_8;
    if (!v1837_5.empty()) {
      const Path v1838_6 = concat_path(p0,v1836_11_head);
      Space v1838_7_result;
      for (int v1838_7_label = 1; v1838_7_label <= 2; ++v1838_7_label) {
        const Space v1838_7_tail = child(v1836_11_tail,v1838_7_label);
        if (v1838_7_tail.empty()) continue;
        const Path v1838_7_head{v1838_7_label};
        const Space v1839_2 = singleton(v1838_7_head);
        const Space v1839_3 = intersect(constant_6,v1839_2);
        const Space v1839_4 = (has_head(v1839_3) ? constant_7 : Space{});
        const Space v1839_5 = subtract(constant_0,v1839_4);
        Space v1839_8;
        if (!v1839_5.empty()) {
          const Path v1840_6 = concat_path(v1838_6,v1838_7_head);
          const Space v1840_7 = routine_243(c, v1840_6, v1838_7_tail);
          v1839_8 = compose(v1839_5,v1840_7);
        }
        const Space v1839_9 = intersect(constant_6,v1839_2);
        const Space v1839_10 = (has_head(v1839_9) ? constant_7 : Space{});
        Space v1839_12;
        if (!v1839_10.empty()) {
          const Path v1841_6 = concat_path(v1838_6,v1838_7_head);
          const Space v1841_11 = routine_244(c, v1841_6, v1838_7_tail);
          v1839_12 = compose(v1839_10,v1841_11);
        }
        const Space v1839_13 = unite(v1839_8,v1839_12);
        v1838_7_result = unite(v1838_7_result,v1839_13);
      }
      const Space v1838_7 = std::move(v1838_7_result);
      v1837_8 = compose(v1837_5,v1838_7);
    }
    const Space v1837_9 = intersect(constant_6,v1837_2);
    const Space v1837_10 = (has_head(v1837_9) ? constant_7 : Space{});
    Space v1837_12;
    if (!v1837_10.empty()) {
      const Path v1842_6 = concat_path(p0,v1836_11_head);
      Space v1842_11_result;
      for (int v1842_11_label = 1; v1842_11_label <= 2; ++v1842_11_label) {
        const Space v1842_11_tail = child(v1836_11_tail,v1842_11_label);
        if (v1842_11_tail.empty()) continue;
        const Path v1842_11_head{v1842_11_label};
        const Space v1843_2 = singleton(v1842_11_head);
        const Space v1843_3 = intersect(constant_6,v1843_2);
        const Space v1843_4 = (has_head(v1843_3) ? constant_7 : Space{});
        const Space v1843_5 = subtract(constant_0,v1843_4);
        Space v1843_8;
        if (!v1843_5.empty()) {
          const Path v1844_6 = concat_path(v1842_6,v1842_11_head);
          const Space v1844_7 = routine_243(c, v1844_6, v1842_11_tail);
          v1843_8 = compose(v1843_5,v1844_7);
        }
        const Space v1843_9 = intersect(constant_6,v1843_2);
        const Space v1843_10 = (has_head(v1843_9) ? constant_7 : Space{});
        Space v1843_12;
        if (!v1843_10.empty()) {
          const Path v1845_6 = concat_path(v1842_6,v1842_11_head);
          const Space v1845_11 = routine_107(c, v1845_6, v1842_11_tail);
          v1843_12 = compose(v1843_10,v1845_11);
        }
        const Space v1843_13 = unite(v1843_8,v1843_12);
        v1842_11_result = unite(v1842_11_result,v1843_13);
      }
      const Space v1842_11 = std::move(v1842_11_result);
      v1837_12 = compose(v1837_10,v1842_11);
    }
    const Space v1837_13 = unite(v1837_8,v1837_12);
    v1836_11_result = unite(v1836_11_result,v1837_13);
  }
  const Space v1836_11 = std::move(v1836_11_result);
  return v1836_11;
}

static Space routine_204(Context& c, const Path& p0, const Space& s0) {
  Space v1846_8_result;
  for (int v1846_8_label = 1; v1846_8_label <= 2; ++v1846_8_label) {
    const Space v1846_8_tail = child(s0,v1846_8_label);
    if (v1846_8_tail.empty()) continue;
    const Path v1846_8_head{v1846_8_label};
    const Space v1847_2 = singleton(v1846_8_head);
    const Space v1847_3 = intersect(constant_6,v1847_2);
    const Space v1847_4 = (has_head(v1847_3) ? constant_7 : Space{});
    const Space v1847_5 = subtract(constant_0,v1847_4);
    Space v1847_8;
    if (!v1847_5.empty()) {
      const Path v1848_6 = concat_path(p0,v1846_8_head);
      Space v1848_7_result;
      for (int v1848_7_label = 1; v1848_7_label <= 2; ++v1848_7_label) {
        const Space v1848_7_tail = child(v1846_8_tail,v1848_7_label);
        if (v1848_7_tail.empty()) continue;
        const Path v1848_7_head{v1848_7_label};
        const Space v1849_2 = singleton(v1848_7_head);
        const Space v1849_3 = intersect(constant_6,v1849_2);
        const Space v1849_4 = (has_head(v1849_3) ? constant_7 : Space{});
        const Space v1849_5 = subtract(constant_0,v1849_4);
        Space v1849_8;
        if (!v1849_5.empty()) {
          const Path v1850_6 = concat_path(v1848_6,v1848_7_head);
          const Space v1850_7 = routine_243(c, v1850_6, v1848_7_tail);
          v1849_8 = compose(v1849_5,v1850_7);
        }
        const Space v1849_9 = intersect(constant_6,v1849_2);
        const Space v1849_10 = (has_head(v1849_9) ? constant_7 : Space{});
        Space v1849_12;
        if (!v1849_10.empty()) {
          const Path v1851_6 = concat_path(v1848_6,v1848_7_head);
          const Space v1851_11 = routine_244(c, v1851_6, v1848_7_tail);
          v1849_12 = compose(v1849_10,v1851_11);
        }
        const Space v1849_13 = unite(v1849_8,v1849_12);
        v1848_7_result = unite(v1848_7_result,v1849_13);
      }
      const Space v1848_7 = std::move(v1848_7_result);
      v1847_8 = compose(v1847_5,v1848_7);
    }
    const Space v1847_9 = intersect(constant_6,v1847_2);
    const Space v1847_10 = (has_head(v1847_9) ? constant_7 : Space{});
    const Space v1847_11 = compose(v1847_10,v1846_8_tail);
    const Space v1847_12 = unite(v1847_8,v1847_11);
    v1846_8_result = unite(v1846_8_result,v1847_12);
  }
  const Space v1846_8 = std::move(v1846_8_result);
  return v1846_8;
}

static Space routine_205(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1852_6_result;
  for (int v1852_6_label = 1; v1852_6_label <= 2; ++v1852_6_label) {
    const Space v1852_6_tail = child(s0,v1852_6_label);
    if (v1852_6_tail.empty()) continue;
    const Path v1852_6_head{v1852_6_label};
    const Space v1853_2 = singleton(v1852_6_head);
    const Space v1853_3 = intersect(constant_6,v1853_2);
    const Space v1853_4 = (has_head(v1853_3) ? constant_7 : Space{});
    Space v1853_7;
    if (!v1853_4.empty()) {
      const Path v1854_5 = concat_path(p0,v1852_6_head);
      Space v1854_6_result;
      for (int v1854_6_label = 1; v1854_6_label <= 2; ++v1854_6_label) {
        const Space v1854_6_tail = child(v1852_6_tail,v1854_6_label);
        if (v1854_6_tail.empty()) continue;
        const Path v1854_6_head{v1854_6_label};
        const Space v1855_2 = singleton(v1854_6_head);
        const Space v1855_3 = intersect(constant_6,v1855_2);
        const Space v1855_4 = (has_head(v1855_3) ? constant_7 : Space{});
        Space v1855_7;
        if (!v1855_4.empty()) {
          const Path v1856_5 = concat_path(v1854_5,v1854_6_head);
          const Space v1856_6 = routine_49(c, v1856_5, p1, v1854_6_tail, s1);
          v1855_7 = compose(v1855_4,v1856_6);
        }
        v1854_6_result = unite(v1854_6_result,v1855_7);
      }
      const Space v1854_6 = std::move(v1854_6_result);
      v1853_7 = compose(v1853_4,v1854_6);
    }
    v1852_6_result = unite(v1852_6_result,v1853_7);
  }
  const Space v1852_6 = std::move(v1852_6_result);
  return v1852_6;
}

static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1857_6 = unwrap(s1,constant_8);
  Space v1857_16_result;
  for (int v1857_16_label = 1; v1857_16_label <= 2; ++v1857_16_label) {
    const Space v1857_16_tail = child(s0,v1857_16_label);
    if (v1857_16_tail.empty()) continue;
    const Path v1857_16_head{v1857_16_label};
    const Space v1858_2 = singleton(v1857_16_head);
    const Space v1858_3 = intersect(constant_6,v1858_2);
    const Space v1858_4 = (has_head(v1858_3) ? constant_7 : Space{});
    Space v1858_17;
    if (!v1858_4.empty()) {
      const Path v1859_5 = concat_path(p0,v1857_16_head);
      const Path v1859_6 = concat_path(p1,v1859_5);
      const Space v1859_7 = routine_29(c, v1859_6);
      const Space v1859_8 = intersect(v1857_6,v1859_7);
      const Space v1859_9 = routine_33(c, v1859_8);
      Space v1859_10_result;
      for (int v1859_10_label = 1; v1859_10_label <= 2; ++v1859_10_label) {
        const Space v1859_10_tail = child(v1859_9,v1859_10_label);
        if (v1859_10_tail.empty()) continue;
        const Path v1859_10_head{v1859_10_label};
        const Space v1860_2 = singleton(v1859_10_head);
        const Space v1860_3 = intersect(constant_6,v1860_2);
        const Space v1860_4 = (has_head(v1860_3) ? constant_7 : Space{});
        const Space v1860_5 = subtract(constant_0,v1860_4);
        Space v1860_7;
        if (!v1860_5.empty()) {
          const Space v1861_6 = routine_52(c, v1859_10_head, v1859_10_tail);
          v1860_7 = compose(v1860_5,v1861_6);
        }
        const Space v1860_8 = intersect(constant_6,v1860_2);
        const Space v1860_9 = (has_head(v1860_8) ? constant_7 : Space{});
        Space v1860_11;
        if (!v1860_9.empty()) {
          const Space v1862_10 = routine_53(c, v1859_10_head, v1859_10_tail);
          v1860_11 = compose(v1860_9,v1862_10);
        }
        const Space v1860_12 = unite(v1860_7,v1860_11);
        v1859_10_result = unite(v1859_10_result,v1860_12);
      }
      const Space v1859_10 = std::move(v1859_10_result);
      const Space v1859_11 = routine_54(c, v1859_8);
      Space v1859_12_result;
      for (int v1859_12_label = 1; v1859_12_label <= 2; ++v1859_12_label) {
        const Space v1859_12_tail = child(v1859_11,v1859_12_label);
        if (v1859_12_tail.empty()) continue;
        const Path v1859_12_head{v1859_12_label};
        const Space v1863_2 = singleton(v1859_12_head);
        const Space v1863_3 = intersect(constant_6,v1863_2);
        const Space v1863_4 = (has_head(v1863_3) ? constant_7 : Space{});
        const Space v1863_5 = subtract(constant_0,v1863_4);
        Space v1863_7;
        if (!v1863_5.empty()) {
          const Space v1864_6 = routine_55(c, v1859_12_head, v1859_12_tail);
          v1863_7 = compose(v1863_5,v1864_6);
        }
        const Space v1863_8 = intersect(constant_6,v1863_2);
        const Space v1863_9 = (has_head(v1863_8) ? constant_7 : Space{});
        Space v1863_11;
        if (!v1863_9.empty()) {
          const Space v1865_10 = routine_56(c, v1859_12_head, v1859_12_tail);
          v1863_11 = compose(v1863_9,v1865_10);
        }
        const Space v1863_12 = unite(v1863_7,v1863_11);
        v1859_12_result = unite(v1859_12_result,v1863_12);
      }
      const Space v1859_12 = std::move(v1859_12_result);
      const Space v1859_13 = subtract(v1859_10,v1859_12);
      const Space v1859_14 = singleton(v1859_6);
      const Space v1859_15 = compose(v1859_13,v1859_14);
      Space v1859_16_result;
      for (int v1859_16_label = 1; v1859_16_label <= 2; ++v1859_16_label) {
        const Space v1859_16_tail = child(v1859_15,v1859_16_label);
        if (v1859_16_tail.empty()) continue;
        const Path v1859_16_head{v1859_16_label};
        const Space v1866_2 = singleton(v1859_16_head);
        const Space v1866_3 = intersect(constant_6,v1866_2);
        const Space v1866_4 = (has_head(v1866_3) ? constant_7 : Space{});
        const Space v1866_5 = subtract(constant_0,v1866_4);
        Space v1866_7;
        if (!v1866_5.empty()) {
          const Space v1867_6 = routine_57(c, v1859_16_head, v1859_16_tail);
          v1866_7 = compose(v1866_5,v1867_6);
        }
        const Space v1866_8 = intersect(constant_6,v1866_2);
        const Space v1866_9 = (has_head(v1866_8) ? constant_7 : Space{});
        Space v1866_11;
        if (!v1866_9.empty()) {
          const Space v1868_10 = routine_58(c, v1859_16_head, v1859_16_tail);
          v1866_11 = compose(v1866_9,v1868_10);
        }
        const Space v1866_12 = unite(v1866_7,v1866_11);
        v1859_16_result = unite(v1859_16_result,v1866_12);
      }
      const Space v1859_16 = std::move(v1859_16_result);
      v1858_17 = compose(v1858_4,v1859_16);
    }
    v1857_16_result = unite(v1857_16_result,v1858_17);
  }
  const Space v1857_16 = std::move(v1857_16_result);
  return v1857_16;
}

static Space routine_207(Context& c, const Path& p0, const Space& s0) {
  Space v1869_11_result;
  for (int v1869_11_label = 1; v1869_11_label <= 2; ++v1869_11_label) {
    const Space v1869_11_tail = child(s0,v1869_11_label);
    if (v1869_11_tail.empty()) continue;
    const Path v1869_11_head{v1869_11_label};
    const Space v1870_2 = singleton(v1869_11_head);
    const Space v1870_3 = intersect(constant_6,v1870_2);
    const Space v1870_4 = (has_head(v1870_3) ? constant_7 : Space{});
    const Space v1870_5 = subtract(constant_0,v1870_4);
    Space v1870_8;
    if (!v1870_5.empty()) {
      const Path v1871_6 = concat_path(p0,v1869_11_head);
      Space v1871_7_result;
      for (int v1871_7_label = 1; v1871_7_label <= 2; ++v1871_7_label) {
        const Space v1871_7_tail = child(v1869_11_tail,v1871_7_label);
        if (v1871_7_tail.empty()) continue;
        const Path v1871_7_head{v1871_7_label};
        const Space v1872_2 = singleton(v1871_7_head);
        const Space v1872_3 = intersect(constant_6,v1872_2);
        const Space v1872_4 = (has_head(v1872_3) ? constant_7 : Space{});
        const Space v1872_5 = subtract(constant_0,v1872_4);
        Space v1872_8;
        if (!v1872_5.empty()) {
          const Path v1873_6 = concat_path(v1871_6,v1871_7_head);
          const Space v1873_7 = routine_245(c, v1873_6, v1871_7_tail);
          v1872_8 = compose(v1872_5,v1873_7);
        }
        const Space v1872_9 = intersect(constant_6,v1872_2);
        const Space v1872_10 = (has_head(v1872_9) ? constant_7 : Space{});
        Space v1872_12;
        if (!v1872_10.empty()) {
          const Path v1874_6 = concat_path(v1871_6,v1871_7_head);
          const Space v1874_11 = routine_246(c, v1874_6, v1871_7_tail);
          v1872_12 = compose(v1872_10,v1874_11);
        }
        const Space v1872_13 = unite(v1872_8,v1872_12);
        v1871_7_result = unite(v1871_7_result,v1872_13);
      }
      const Space v1871_7 = std::move(v1871_7_result);
      v1870_8 = compose(v1870_5,v1871_7);
    }
    const Space v1870_9 = intersect(constant_6,v1870_2);
    const Space v1870_10 = (has_head(v1870_9) ? constant_7 : Space{});
    Space v1870_12;
    if (!v1870_10.empty()) {
      const Path v1875_6 = concat_path(p0,v1869_11_head);
      Space v1875_11_result;
      for (int v1875_11_label = 1; v1875_11_label <= 2; ++v1875_11_label) {
        const Space v1875_11_tail = child(v1869_11_tail,v1875_11_label);
        if (v1875_11_tail.empty()) continue;
        const Path v1875_11_head{v1875_11_label};
        const Space v1876_2 = singleton(v1875_11_head);
        const Space v1876_3 = intersect(constant_6,v1876_2);
        const Space v1876_4 = (has_head(v1876_3) ? constant_7 : Space{});
        const Space v1876_5 = subtract(constant_0,v1876_4);
        Space v1876_8;
        if (!v1876_5.empty()) {
          const Path v1877_6 = concat_path(v1875_6,v1875_11_head);
          const Space v1877_7 = routine_245(c, v1877_6, v1875_11_tail);
          v1876_8 = compose(v1876_5,v1877_7);
        }
        const Space v1876_9 = intersect(constant_6,v1876_2);
        const Space v1876_10 = (has_head(v1876_9) ? constant_7 : Space{});
        Space v1876_12;
        if (!v1876_10.empty()) {
          const Path v1878_6 = concat_path(v1875_6,v1875_11_head);
          const Space v1878_11 = routine_100(c, v1878_6, v1875_11_tail);
          v1876_12 = compose(v1876_10,v1878_11);
        }
        const Space v1876_13 = unite(v1876_8,v1876_12);
        v1875_11_result = unite(v1875_11_result,v1876_13);
      }
      const Space v1875_11 = std::move(v1875_11_result);
      v1870_12 = compose(v1870_10,v1875_11);
    }
    const Space v1870_13 = unite(v1870_8,v1870_12);
    v1869_11_result = unite(v1869_11_result,v1870_13);
  }
  const Space v1869_11 = std::move(v1869_11_result);
  return v1869_11;
}

static Space routine_208(Context& c, const Path& p0, const Space& s0) {
  Space v1879_9_result;
  for (int v1879_9_label = 1; v1879_9_label <= 2; ++v1879_9_label) {
    const Space v1879_9_tail = child(s0,v1879_9_label);
    if (v1879_9_tail.empty()) continue;
    const Path v1879_9_head{v1879_9_label};
    const Space v1880_2 = singleton(v1879_9_head);
    const Space v1880_3 = intersect(constant_6,v1880_2);
    const Space v1880_4 = (has_head(v1880_3) ? constant_7 : Space{});
    const Space v1880_5 = subtract(constant_0,v1880_4);
    Space v1880_8;
    if (!v1880_5.empty()) {
      const Path v1881_6 = concat_path(p0,v1879_9_head);
      Space v1881_7_result;
      for (int v1881_7_label = 1; v1881_7_label <= 2; ++v1881_7_label) {
        const Space v1881_7_tail = child(v1879_9_tail,v1881_7_label);
        if (v1881_7_tail.empty()) continue;
        const Path v1881_7_head{v1881_7_label};
        const Space v1882_2 = singleton(v1881_7_head);
        const Space v1882_3 = intersect(constant_6,v1882_2);
        const Space v1882_4 = (has_head(v1882_3) ? constant_7 : Space{});
        const Space v1882_5 = subtract(constant_0,v1882_4);
        Space v1882_8;
        if (!v1882_5.empty()) {
          const Path v1883_6 = concat_path(v1881_6,v1881_7_head);
          const Space v1883_7 = routine_245(c, v1883_6, v1881_7_tail);
          v1882_8 = compose(v1882_5,v1883_7);
        }
        const Space v1882_9 = intersect(constant_6,v1882_2);
        const Space v1882_10 = (has_head(v1882_9) ? constant_7 : Space{});
        Space v1882_12;
        if (!v1882_10.empty()) {
          const Path v1884_6 = concat_path(v1881_6,v1881_7_head);
          const Space v1884_11 = routine_246(c, v1884_6, v1881_7_tail);
          v1882_12 = compose(v1882_10,v1884_11);
        }
        const Space v1882_13 = unite(v1882_8,v1882_12);
        v1881_7_result = unite(v1881_7_result,v1882_13);
      }
      const Space v1881_7 = std::move(v1881_7_result);
      v1880_8 = compose(v1880_5,v1881_7);
    }
    const Space v1880_9 = intersect(constant_6,v1880_2);
    const Space v1880_10 = (has_head(v1880_9) ? constant_7 : Space{});
    const Space v1880_11 = compose(v1880_10,constant_9);
    const Space v1880_12 = unite(v1880_8,v1880_11);
    v1879_9_result = unite(v1879_9_result,v1880_12);
  }
  const Space v1879_9 = std::move(v1879_9_result);
  return v1879_9;
}

static Space routine_209(Context& c, const Path& p0, const Space& s0) {
  Space v1885_11_result;
  for (int v1885_11_label = 1; v1885_11_label <= 2; ++v1885_11_label) {
    const Space v1885_11_tail = child(s0,v1885_11_label);
    if (v1885_11_tail.empty()) continue;
    const Path v1885_11_head{v1885_11_label};
    const Space v1886_2 = singleton(v1885_11_head);
    const Space v1886_3 = intersect(constant_6,v1886_2);
    const Space v1886_4 = (has_head(v1886_3) ? constant_7 : Space{});
    const Space v1886_5 = subtract(constant_0,v1886_4);
    Space v1886_8;
    if (!v1886_5.empty()) {
      const Path v1887_6 = concat_path(p0,v1885_11_head);
      Space v1887_7_result;
      for (int v1887_7_label = 1; v1887_7_label <= 2; ++v1887_7_label) {
        const Space v1887_7_tail = child(v1885_11_tail,v1887_7_label);
        if (v1887_7_tail.empty()) continue;
        const Path v1887_7_head{v1887_7_label};
        const Space v1888_2 = singleton(v1887_7_head);
        const Space v1888_3 = intersect(constant_6,v1888_2);
        const Space v1888_4 = (has_head(v1888_3) ? constant_7 : Space{});
        const Space v1888_5 = subtract(constant_0,v1888_4);
        Space v1888_8;
        if (!v1888_5.empty()) {
          const Path v1889_6 = concat_path(v1887_6,v1887_7_head);
          const Space v1889_7 = routine_247(c, v1889_6, v1887_7_tail);
          v1888_8 = compose(v1888_5,v1889_7);
        }
        const Space v1888_9 = intersect(constant_6,v1888_2);
        const Space v1888_10 = (has_head(v1888_9) ? constant_7 : Space{});
        Space v1888_12;
        if (!v1888_10.empty()) {
          const Path v1890_6 = concat_path(v1887_6,v1887_7_head);
          const Space v1890_11 = routine_248(c, v1890_6, v1887_7_tail);
          v1888_12 = compose(v1888_10,v1890_11);
        }
        const Space v1888_13 = unite(v1888_8,v1888_12);
        v1887_7_result = unite(v1887_7_result,v1888_13);
      }
      const Space v1887_7 = std::move(v1887_7_result);
      v1886_8 = compose(v1886_5,v1887_7);
    }
    const Space v1886_9 = intersect(constant_6,v1886_2);
    const Space v1886_10 = (has_head(v1886_9) ? constant_7 : Space{});
    Space v1886_12;
    if (!v1886_10.empty()) {
      const Path v1891_6 = concat_path(p0,v1885_11_head);
      Space v1891_11_result;
      for (int v1891_11_label = 1; v1891_11_label <= 2; ++v1891_11_label) {
        const Space v1891_11_tail = child(v1885_11_tail,v1891_11_label);
        if (v1891_11_tail.empty()) continue;
        const Path v1891_11_head{v1891_11_label};
        const Space v1892_2 = singleton(v1891_11_head);
        const Space v1892_3 = intersect(constant_6,v1892_2);
        const Space v1892_4 = (has_head(v1892_3) ? constant_7 : Space{});
        const Space v1892_5 = subtract(constant_0,v1892_4);
        Space v1892_8;
        if (!v1892_5.empty()) {
          const Path v1893_6 = concat_path(v1891_6,v1891_11_head);
          const Space v1893_7 = routine_247(c, v1893_6, v1891_11_tail);
          v1892_8 = compose(v1892_5,v1893_7);
        }
        const Space v1892_9 = intersect(constant_6,v1892_2);
        const Space v1892_10 = (has_head(v1892_9) ? constant_7 : Space{});
        Space v1892_12;
        if (!v1892_10.empty()) {
          const Path v1894_6 = concat_path(v1891_6,v1891_11_head);
          const Space v1894_11 = routine_104(c, v1894_6, v1891_11_tail);
          v1892_12 = compose(v1892_10,v1894_11);
        }
        const Space v1892_13 = unite(v1892_8,v1892_12);
        v1891_11_result = unite(v1891_11_result,v1892_13);
      }
      const Space v1891_11 = std::move(v1891_11_result);
      v1886_12 = compose(v1886_10,v1891_11);
    }
    const Space v1886_13 = unite(v1886_8,v1886_12);
    v1885_11_result = unite(v1885_11_result,v1886_13);
  }
  const Space v1885_11 = std::move(v1885_11_result);
  return v1885_11;
}

static Space routine_210(Context& c, const Path& p0, const Space& s0) {
  Space v1895_9_result;
  for (int v1895_9_label = 1; v1895_9_label <= 2; ++v1895_9_label) {
    const Space v1895_9_tail = child(s0,v1895_9_label);
    if (v1895_9_tail.empty()) continue;
    const Path v1895_9_head{v1895_9_label};
    const Space v1896_2 = singleton(v1895_9_head);
    const Space v1896_3 = intersect(constant_6,v1896_2);
    const Space v1896_4 = (has_head(v1896_3) ? constant_7 : Space{});
    const Space v1896_5 = subtract(constant_0,v1896_4);
    Space v1896_8;
    if (!v1896_5.empty()) {
      const Path v1897_6 = concat_path(p0,v1895_9_head);
      Space v1897_7_result;
      for (int v1897_7_label = 1; v1897_7_label <= 2; ++v1897_7_label) {
        const Space v1897_7_tail = child(v1895_9_tail,v1897_7_label);
        if (v1897_7_tail.empty()) continue;
        const Path v1897_7_head{v1897_7_label};
        const Space v1898_2 = singleton(v1897_7_head);
        const Space v1898_3 = intersect(constant_6,v1898_2);
        const Space v1898_4 = (has_head(v1898_3) ? constant_7 : Space{});
        const Space v1898_5 = subtract(constant_0,v1898_4);
        Space v1898_8;
        if (!v1898_5.empty()) {
          const Path v1899_6 = concat_path(v1897_6,v1897_7_head);
          const Space v1899_7 = routine_247(c, v1899_6, v1897_7_tail);
          v1898_8 = compose(v1898_5,v1899_7);
        }
        const Space v1898_9 = intersect(constant_6,v1898_2);
        const Space v1898_10 = (has_head(v1898_9) ? constant_7 : Space{});
        Space v1898_12;
        if (!v1898_10.empty()) {
          const Path v1900_6 = concat_path(v1897_6,v1897_7_head);
          const Space v1900_11 = routine_248(c, v1900_6, v1897_7_tail);
          v1898_12 = compose(v1898_10,v1900_11);
        }
        const Space v1898_13 = unite(v1898_8,v1898_12);
        v1897_7_result = unite(v1897_7_result,v1898_13);
      }
      const Space v1897_7 = std::move(v1897_7_result);
      v1896_8 = compose(v1896_5,v1897_7);
    }
    const Space v1896_9 = intersect(constant_6,v1896_2);
    const Space v1896_10 = (has_head(v1896_9) ? constant_7 : Space{});
    const Space v1896_11 = compose(v1896_10,constant_9);
    const Space v1896_12 = unite(v1896_8,v1896_11);
    v1895_9_result = unite(v1895_9_result,v1896_12);
  }
  const Space v1895_9 = std::move(v1895_9_result);
  return v1895_9;
}

static Space routine_211(Context& c, const Path& p0, const Space& s0) {
  Space v1901_11_result;
  for (int v1901_11_label = 1; v1901_11_label <= 2; ++v1901_11_label) {
    const Space v1901_11_tail = child(s0,v1901_11_label);
    if (v1901_11_tail.empty()) continue;
    const Path v1901_11_head{v1901_11_label};
    const Space v1902_2 = singleton(v1901_11_head);
    const Space v1902_3 = intersect(constant_6,v1902_2);
    const Space v1902_4 = (has_head(v1902_3) ? constant_7 : Space{});
    const Space v1902_5 = subtract(constant_0,v1902_4);
    Space v1902_8;
    if (!v1902_5.empty()) {
      const Path v1903_6 = concat_path(p0,v1901_11_head);
      Space v1903_7_result;
      for (int v1903_7_label = 1; v1903_7_label <= 2; ++v1903_7_label) {
        const Space v1903_7_tail = child(v1901_11_tail,v1903_7_label);
        if (v1903_7_tail.empty()) continue;
        const Path v1903_7_head{v1903_7_label};
        const Space v1904_2 = singleton(v1903_7_head);
        const Space v1904_3 = intersect(constant_6,v1904_2);
        const Space v1904_4 = (has_head(v1904_3) ? constant_7 : Space{});
        const Space v1904_5 = subtract(constant_0,v1904_4);
        Space v1904_8;
        if (!v1904_5.empty()) {
          const Path v1905_6 = concat_path(v1903_6,v1903_7_head);
          const Space v1905_7 = routine_249(c, v1905_6, v1903_7_tail);
          v1904_8 = compose(v1904_5,v1905_7);
        }
        const Space v1904_9 = intersect(constant_6,v1904_2);
        const Space v1904_10 = (has_head(v1904_9) ? constant_7 : Space{});
        Space v1904_12;
        if (!v1904_10.empty()) {
          const Path v1906_6 = concat_path(v1903_6,v1903_7_head);
          const Space v1906_11 = routine_250(c, v1906_6, v1903_7_tail);
          v1904_12 = compose(v1904_10,v1906_11);
        }
        const Space v1904_13 = unite(v1904_8,v1904_12);
        v1903_7_result = unite(v1903_7_result,v1904_13);
      }
      const Space v1903_7 = std::move(v1903_7_result);
      v1902_8 = compose(v1902_5,v1903_7);
    }
    const Space v1902_9 = intersect(constant_6,v1902_2);
    const Space v1902_10 = (has_head(v1902_9) ? constant_7 : Space{});
    Space v1902_12;
    if (!v1902_10.empty()) {
      const Path v1907_6 = concat_path(p0,v1901_11_head);
      Space v1907_11_result;
      for (int v1907_11_label = 1; v1907_11_label <= 2; ++v1907_11_label) {
        const Space v1907_11_tail = child(v1901_11_tail,v1907_11_label);
        if (v1907_11_tail.empty()) continue;
        const Path v1907_11_head{v1907_11_label};
        const Space v1908_2 = singleton(v1907_11_head);
        const Space v1908_3 = intersect(constant_6,v1908_2);
        const Space v1908_4 = (has_head(v1908_3) ? constant_7 : Space{});
        const Space v1908_5 = subtract(constant_0,v1908_4);
        Space v1908_8;
        if (!v1908_5.empty()) {
          const Path v1909_6 = concat_path(v1907_6,v1907_11_head);
          const Space v1909_7 = routine_249(c, v1909_6, v1907_11_tail);
          v1908_8 = compose(v1908_5,v1909_7);
        }
        const Space v1908_9 = intersect(constant_6,v1908_2);
        const Space v1908_10 = (has_head(v1908_9) ? constant_7 : Space{});
        Space v1908_12;
        if (!v1908_10.empty()) {
          const Path v1910_6 = concat_path(v1907_6,v1907_11_head);
          const Space v1910_11 = routine_107(c, v1910_6, v1907_11_tail);
          v1908_12 = compose(v1908_10,v1910_11);
        }
        const Space v1908_13 = unite(v1908_8,v1908_12);
        v1907_11_result = unite(v1907_11_result,v1908_13);
      }
      const Space v1907_11 = std::move(v1907_11_result);
      v1902_12 = compose(v1902_10,v1907_11);
    }
    const Space v1902_13 = unite(v1902_8,v1902_12);
    v1901_11_result = unite(v1901_11_result,v1902_13);
  }
  const Space v1901_11 = std::move(v1901_11_result);
  return v1901_11;
}

static Space routine_212(Context& c, const Path& p0, const Space& s0) {
  Space v1911_8_result;
  for (int v1911_8_label = 1; v1911_8_label <= 2; ++v1911_8_label) {
    const Space v1911_8_tail = child(s0,v1911_8_label);
    if (v1911_8_tail.empty()) continue;
    const Path v1911_8_head{v1911_8_label};
    const Space v1912_2 = singleton(v1911_8_head);
    const Space v1912_3 = intersect(constant_6,v1912_2);
    const Space v1912_4 = (has_head(v1912_3) ? constant_7 : Space{});
    const Space v1912_5 = subtract(constant_0,v1912_4);
    Space v1912_8;
    if (!v1912_5.empty()) {
      const Path v1913_6 = concat_path(p0,v1911_8_head);
      Space v1913_7_result;
      for (int v1913_7_label = 1; v1913_7_label <= 2; ++v1913_7_label) {
        const Space v1913_7_tail = child(v1911_8_tail,v1913_7_label);
        if (v1913_7_tail.empty()) continue;
        const Path v1913_7_head{v1913_7_label};
        const Space v1914_2 = singleton(v1913_7_head);
        const Space v1914_3 = intersect(constant_6,v1914_2);
        const Space v1914_4 = (has_head(v1914_3) ? constant_7 : Space{});
        const Space v1914_5 = subtract(constant_0,v1914_4);
        Space v1914_8;
        if (!v1914_5.empty()) {
          const Path v1915_6 = concat_path(v1913_6,v1913_7_head);
          const Space v1915_7 = routine_249(c, v1915_6, v1913_7_tail);
          v1914_8 = compose(v1914_5,v1915_7);
        }
        const Space v1914_9 = intersect(constant_6,v1914_2);
        const Space v1914_10 = (has_head(v1914_9) ? constant_7 : Space{});
        Space v1914_12;
        if (!v1914_10.empty()) {
          const Path v1916_6 = concat_path(v1913_6,v1913_7_head);
          const Space v1916_11 = routine_250(c, v1916_6, v1913_7_tail);
          v1914_12 = compose(v1914_10,v1916_11);
        }
        const Space v1914_13 = unite(v1914_8,v1914_12);
        v1913_7_result = unite(v1913_7_result,v1914_13);
      }
      const Space v1913_7 = std::move(v1913_7_result);
      v1912_8 = compose(v1912_5,v1913_7);
    }
    const Space v1912_9 = intersect(constant_6,v1912_2);
    const Space v1912_10 = (has_head(v1912_9) ? constant_7 : Space{});
    const Space v1912_11 = compose(v1912_10,v1911_8_tail);
    const Space v1912_12 = unite(v1912_8,v1912_11);
    v1911_8_result = unite(v1911_8_result,v1912_12);
  }
  const Space v1911_8 = std::move(v1911_8_result);
  return v1911_8;
}

static Space routine_213(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1917_4 = Space{};
  return v1917_4;
}

static Space routine_214(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1918_6 = unwrap(s1,constant_8);
  Space v1918_16_result;
  for (int v1918_16_label = 1; v1918_16_label <= 2; ++v1918_16_label) {
    const Space v1918_16_tail = child(s0,v1918_16_label);
    if (v1918_16_tail.empty()) continue;
    const Path v1918_16_head{v1918_16_label};
    const Space v1919_2 = singleton(v1918_16_head);
    const Space v1919_3 = intersect(constant_6,v1919_2);
    const Space v1919_4 = (has_head(v1919_3) ? constant_7 : Space{});
    Space v1919_17;
    if (!v1919_4.empty()) {
      const Path v1920_5 = concat_path(p0,v1918_16_head);
      const Path v1920_6 = concat_path(p1,v1920_5);
      const Space v1920_7 = routine_29(c, v1920_6);
      const Space v1920_8 = intersect(v1918_6,v1920_7);
      const Space v1920_9 = routine_30(c, v1920_8);
      Space v1920_10_result;
      for (int v1920_10_label = 1; v1920_10_label <= 2; ++v1920_10_label) {
        const Space v1920_10_tail = child(v1920_9,v1920_10_label);
        if (v1920_10_tail.empty()) continue;
        const Path v1920_10_head{v1920_10_label};
        const Space v1921_2 = singleton(v1920_10_head);
        const Space v1921_3 = intersect(constant_6,v1921_2);
        const Space v1921_4 = (has_head(v1921_3) ? constant_7 : Space{});
        const Space v1921_5 = subtract(constant_0,v1921_4);
        Space v1921_7;
        if (!v1921_5.empty()) {
          const Space v1922_6 = routine_31(c, v1920_10_head, v1920_10_tail);
          v1921_7 = compose(v1921_5,v1922_6);
        }
        const Space v1921_8 = intersect(constant_6,v1921_2);
        const Space v1921_9 = (has_head(v1921_8) ? constant_7 : Space{});
        Space v1921_11;
        if (!v1921_9.empty()) {
          const Space v1923_10 = routine_32(c, v1920_10_head, v1920_10_tail);
          v1921_11 = compose(v1921_9,v1923_10);
        }
        const Space v1921_12 = unite(v1921_7,v1921_11);
        v1920_10_result = unite(v1920_10_result,v1921_12);
      }
      const Space v1920_10 = std::move(v1920_10_result);
      const Space v1920_11 = routine_33(c, v1920_8);
      Space v1920_12_result;
      for (int v1920_12_label = 1; v1920_12_label <= 2; ++v1920_12_label) {
        const Space v1920_12_tail = child(v1920_11,v1920_12_label);
        if (v1920_12_tail.empty()) continue;
        const Path v1920_12_head{v1920_12_label};
        const Space v1924_2 = singleton(v1920_12_head);
        const Space v1924_3 = intersect(constant_6,v1924_2);
        const Space v1924_4 = (has_head(v1924_3) ? constant_7 : Space{});
        const Space v1924_5 = subtract(constant_0,v1924_4);
        Space v1924_7;
        if (!v1924_5.empty()) {
          const Space v1925_6 = routine_34(c, v1920_12_head, v1920_12_tail);
          v1924_7 = compose(v1924_5,v1925_6);
        }
        const Space v1924_8 = intersect(constant_6,v1924_2);
        const Space v1924_9 = (has_head(v1924_8) ? constant_7 : Space{});
        Space v1924_11;
        if (!v1924_9.empty()) {
          const Space v1926_10 = routine_35(c, v1920_12_head, v1920_12_tail);
          v1924_11 = compose(v1924_9,v1926_10);
        }
        const Space v1924_12 = unite(v1924_7,v1924_11);
        v1920_12_result = unite(v1920_12_result,v1924_12);
      }
      const Space v1920_12 = std::move(v1920_12_result);
      const Space v1920_13 = subtract(v1920_10,v1920_12);
      const Space v1920_14 = singleton(v1920_6);
      const Space v1920_15 = compose(v1920_13,v1920_14);
      Space v1920_16_result;
      for (int v1920_16_label = 1; v1920_16_label <= 2; ++v1920_16_label) {
        const Space v1920_16_tail = child(v1920_15,v1920_16_label);
        if (v1920_16_tail.empty()) continue;
        const Path v1920_16_head{v1920_16_label};
        const Space v1927_2 = singleton(v1920_16_head);
        const Space v1927_3 = intersect(constant_6,v1927_2);
        const Space v1927_4 = (has_head(v1927_3) ? constant_7 : Space{});
        const Space v1927_5 = subtract(constant_0,v1927_4);
        Space v1927_7;
        if (!v1927_5.empty()) {
          const Space v1928_6 = routine_36(c, v1920_16_head, v1920_16_tail);
          v1927_7 = compose(v1927_5,v1928_6);
        }
        const Space v1927_8 = intersect(constant_6,v1927_2);
        const Space v1927_9 = (has_head(v1927_8) ? constant_7 : Space{});
        Space v1927_11;
        if (!v1927_9.empty()) {
          const Space v1929_10 = routine_37(c, v1920_16_head, v1920_16_tail);
          v1927_11 = compose(v1927_9,v1929_10);
        }
        const Space v1927_12 = unite(v1927_7,v1927_11);
        v1920_16_result = unite(v1920_16_result,v1927_12);
      }
      const Space v1920_16 = std::move(v1920_16_result);
      v1919_17 = compose(v1919_4,v1920_16);
    }
    v1918_16_result = unite(v1918_16_result,v1919_17);
  }
  const Space v1918_16 = std::move(v1918_16_result);
  return v1918_16;
}

static Space routine_215(Context& c, const Path& p0, const Space& s0) {
  Space v1930_11_result;
  for (int v1930_11_label = 1; v1930_11_label <= 2; ++v1930_11_label) {
    const Space v1930_11_tail = child(s0,v1930_11_label);
    if (v1930_11_tail.empty()) continue;
    const Path v1930_11_head{v1930_11_label};
    const Space v1931_2 = singleton(v1930_11_head);
    const Space v1931_3 = intersect(constant_6,v1931_2);
    const Space v1931_4 = (has_head(v1931_3) ? constant_7 : Space{});
    const Space v1931_5 = subtract(constant_0,v1931_4);
    Space v1931_8;
    if (!v1931_5.empty()) {
      const Path v1932_6 = concat_path(p0,v1930_11_head);
      Space v1932_7_result;
      for (int v1932_7_label = 1; v1932_7_label <= 2; ++v1932_7_label) {
        const Space v1932_7_tail = child(v1930_11_tail,v1932_7_label);
        if (v1932_7_tail.empty()) continue;
        const Path v1932_7_head{v1932_7_label};
        const Space v1933_2 = singleton(v1932_7_head);
        const Space v1933_3 = intersect(constant_6,v1933_2);
        const Space v1933_4 = (has_head(v1933_3) ? constant_7 : Space{});
        const Space v1933_5 = subtract(constant_0,v1933_4);
        Space v1933_8;
        if (!v1933_5.empty()) {
          const Path v1934_6 = concat_path(v1932_6,v1932_7_head);
          const Space v1934_7 = routine_251(c, v1934_6, v1932_7_tail);
          v1933_8 = compose(v1933_5,v1934_7);
        }
        const Space v1933_9 = intersect(constant_6,v1933_2);
        const Space v1933_10 = (has_head(v1933_9) ? constant_7 : Space{});
        Space v1933_12;
        if (!v1933_10.empty()) {
          const Path v1935_6 = concat_path(v1932_6,v1932_7_head);
          const Space v1935_11 = routine_252(c, v1935_6, v1932_7_tail);
          v1933_12 = compose(v1933_10,v1935_11);
        }
        const Space v1933_13 = unite(v1933_8,v1933_12);
        v1932_7_result = unite(v1932_7_result,v1933_13);
      }
      const Space v1932_7 = std::move(v1932_7_result);
      v1931_8 = compose(v1931_5,v1932_7);
    }
    const Space v1931_9 = intersect(constant_6,v1931_2);
    const Space v1931_10 = (has_head(v1931_9) ? constant_7 : Space{});
    Space v1931_12;
    if (!v1931_10.empty()) {
      const Path v1936_6 = concat_path(p0,v1930_11_head);
      Space v1936_11_result;
      for (int v1936_11_label = 1; v1936_11_label <= 2; ++v1936_11_label) {
        const Space v1936_11_tail = child(v1930_11_tail,v1936_11_label);
        if (v1936_11_tail.empty()) continue;
        const Path v1936_11_head{v1936_11_label};
        const Space v1937_2 = singleton(v1936_11_head);
        const Space v1937_3 = intersect(constant_6,v1937_2);
        const Space v1937_4 = (has_head(v1937_3) ? constant_7 : Space{});
        const Space v1937_5 = subtract(constant_0,v1937_4);
        Space v1937_8;
        if (!v1937_5.empty()) {
          const Path v1938_6 = concat_path(v1936_6,v1936_11_head);
          const Space v1938_7 = routine_251(c, v1938_6, v1936_11_tail);
          v1937_8 = compose(v1937_5,v1938_7);
        }
        const Space v1937_9 = intersect(constant_6,v1937_2);
        const Space v1937_10 = (has_head(v1937_9) ? constant_7 : Space{});
        Space v1937_12;
        if (!v1937_10.empty()) {
          const Path v1939_6 = concat_path(v1936_6,v1936_11_head);
          const Space v1939_11 = routine_80(c, v1939_6, v1936_11_tail);
          v1937_12 = compose(v1937_10,v1939_11);
        }
        const Space v1937_13 = unite(v1937_8,v1937_12);
        v1936_11_result = unite(v1936_11_result,v1937_13);
      }
      const Space v1936_11 = std::move(v1936_11_result);
      v1931_12 = compose(v1931_10,v1936_11);
    }
    const Space v1931_13 = unite(v1931_8,v1931_12);
    v1930_11_result = unite(v1930_11_result,v1931_13);
  }
  const Space v1930_11 = std::move(v1930_11_result);
  return v1930_11;
}

static Space routine_216(Context& c, const Path& p0, const Space& s0) {
  Space v1940_11_result;
  for (int v1940_11_label = 1; v1940_11_label <= 2; ++v1940_11_label) {
    const Space v1940_11_tail = child(s0,v1940_11_label);
    if (v1940_11_tail.empty()) continue;
    const Path v1940_11_head{v1940_11_label};
    const Space v1941_2 = singleton(v1940_11_head);
    const Space v1941_3 = intersect(constant_6,v1941_2);
    const Space v1941_4 = (has_head(v1941_3) ? constant_7 : Space{});
    const Space v1941_5 = subtract(constant_0,v1941_4);
    Space v1941_8;
    if (!v1941_5.empty()) {
      const Path v1942_6 = concat_path(p0,v1940_11_head);
      Space v1942_7_result;
      for (int v1942_7_label = 1; v1942_7_label <= 2; ++v1942_7_label) {
        const Space v1942_7_tail = child(v1940_11_tail,v1942_7_label);
        if (v1942_7_tail.empty()) continue;
        const Path v1942_7_head{v1942_7_label};
        const Space v1943_2 = singleton(v1942_7_head);
        const Space v1943_3 = intersect(constant_6,v1943_2);
        const Space v1943_4 = (has_head(v1943_3) ? constant_7 : Space{});
        const Space v1943_5 = subtract(constant_0,v1943_4);
        Space v1943_8;
        if (!v1943_5.empty()) {
          const Path v1944_6 = concat_path(v1942_6,v1942_7_head);
          const Space v1944_7 = routine_251(c, v1944_6, v1942_7_tail);
          v1943_8 = compose(v1943_5,v1944_7);
        }
        const Space v1943_9 = intersect(constant_6,v1943_2);
        const Space v1943_10 = (has_head(v1943_9) ? constant_7 : Space{});
        Space v1943_12;
        if (!v1943_10.empty()) {
          const Path v1945_6 = concat_path(v1942_6,v1942_7_head);
          const Space v1945_11 = routine_252(c, v1945_6, v1942_7_tail);
          v1943_12 = compose(v1943_10,v1945_11);
        }
        const Space v1943_13 = unite(v1943_8,v1943_12);
        v1942_7_result = unite(v1942_7_result,v1943_13);
      }
      const Space v1942_7 = std::move(v1942_7_result);
      v1941_8 = compose(v1941_5,v1942_7);
    }
    const Space v1941_9 = intersect(constant_6,v1941_2);
    const Space v1941_10 = (has_head(v1941_9) ? constant_7 : Space{});
    Space v1941_12;
    if (!v1941_10.empty()) {
      const Path v1946_6 = concat_path(p0,v1940_11_head);
      Space v1946_11_result;
      for (int v1946_11_label = 1; v1946_11_label <= 2; ++v1946_11_label) {
        const Space v1946_11_tail = child(v1940_11_tail,v1946_11_label);
        if (v1946_11_tail.empty()) continue;
        const Path v1946_11_head{v1946_11_label};
        const Space v1947_2 = singleton(v1946_11_head);
        const Space v1947_3 = intersect(constant_6,v1947_2);
        const Space v1947_4 = (has_head(v1947_3) ? constant_7 : Space{});
        const Space v1947_5 = subtract(constant_0,v1947_4);
        Space v1947_7;
        if (!v1947_5.empty()) {
          const Space v1948_6 = routine_122(c, v1946_11_head, v1946_6, v1946_11_tail);
          v1947_7 = compose(v1947_5,v1948_6);
        }
        const Space v1947_8 = intersect(constant_6,v1947_2);
        const Space v1947_9 = (has_head(v1947_8) ? constant_7 : Space{});
        Space v1947_11;
        if (!v1947_9.empty()) {
          const Space v1949_10 = routine_123(c, v1946_11_head, v1946_6, v1946_11_tail);
          v1947_11 = compose(v1947_9,v1949_10);
        }
        const Space v1947_12 = unite(v1947_7,v1947_11);
        v1946_11_result = unite(v1946_11_result,v1947_12);
      }
      const Space v1946_11 = std::move(v1946_11_result);
      v1941_12 = compose(v1941_10,v1946_11);
    }
    const Space v1941_13 = unite(v1941_8,v1941_12);
    v1940_11_result = unite(v1940_11_result,v1941_13);
  }
  const Space v1940_11 = std::move(v1940_11_result);
  return v1940_11;
}

static Space routine_217(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1950_12_result;
  for (int v1950_12_label = 1; v1950_12_label <= 2; ++v1950_12_label) {
    const Space v1950_12_tail = child(s0,v1950_12_label);
    if (v1950_12_tail.empty()) continue;
    const Path v1950_12_head{v1950_12_label};
    const Space v1951_2 = singleton(v1950_12_head);
    const Space v1951_3 = intersect(constant_6,v1951_2);
    const Space v1951_4 = (has_head(v1951_3) ? constant_7 : Space{});
    const Space v1951_5 = subtract(constant_0,v1951_4);
    Space v1951_8;
    if (!v1951_5.empty()) {
      const Path v1952_6 = concat_path(p0,v1950_12_head);
      Space v1952_7_result;
      for (int v1952_7_label = 1; v1952_7_label <= 2; ++v1952_7_label) {
        const Space v1952_7_tail = child(v1950_12_tail,v1952_7_label);
        if (v1952_7_tail.empty()) continue;
        const Path v1952_7_head{v1952_7_label};
        const Space v1953_2 = singleton(v1952_7_head);
        const Space v1953_3 = intersect(constant_6,v1953_2);
        const Space v1953_4 = (has_head(v1953_3) ? constant_7 : Space{});
        const Space v1953_5 = subtract(constant_0,v1953_4);
        Space v1953_8;
        if (!v1953_5.empty()) {
          const Path v1954_6 = concat_path(v1952_6,v1952_7_head);
          const Space v1954_7 = routine_253(c, v1954_6, p1, v1952_7_tail);
          v1953_8 = compose(v1953_5,v1954_7);
        }
        const Space v1953_9 = intersect(constant_6,v1953_2);
        const Space v1953_10 = (has_head(v1953_9) ? constant_7 : Space{});
        Space v1953_12;
        if (!v1953_10.empty()) {
          const Path v1955_6 = concat_path(v1952_6,v1952_7_head);
          const Space v1955_11 = routine_254(c, v1955_6, p1, v1952_7_tail);
          v1953_12 = compose(v1953_10,v1955_11);
        }
        const Space v1953_13 = unite(v1953_8,v1953_12);
        v1952_7_result = unite(v1952_7_result,v1953_13);
      }
      const Space v1952_7 = std::move(v1952_7_result);
      v1951_8 = compose(v1951_5,v1952_7);
    }
    const Space v1951_9 = intersect(constant_6,v1951_2);
    const Space v1951_10 = (has_head(v1951_9) ? constant_7 : Space{});
    Space v1951_12;
    if (!v1951_10.empty()) {
      const Path v1956_6 = concat_path(p0,v1950_12_head);
      Space v1956_11_result;
      for (int v1956_11_label = 1; v1956_11_label <= 2; ++v1956_11_label) {
        const Space v1956_11_tail = child(v1950_12_tail,v1956_11_label);
        if (v1956_11_tail.empty()) continue;
        const Path v1956_11_head{v1956_11_label};
        const Space v1957_2 = singleton(v1956_11_head);
        const Space v1957_3 = intersect(constant_6,v1957_2);
        const Space v1957_4 = (has_head(v1957_3) ? constant_7 : Space{});
        const Space v1957_5 = subtract(constant_0,v1957_4);
        Space v1957_8;
        if (!v1957_5.empty()) {
          const Path v1958_6 = concat_path(v1956_6,v1956_11_head);
          const Space v1958_7 = routine_253(c, v1958_6, p1, v1956_11_tail);
          v1957_8 = compose(v1957_5,v1958_7);
        }
        const Space v1957_9 = intersect(constant_6,v1957_2);
        const Space v1957_10 = (has_head(v1957_9) ? constant_7 : Space{});
        Space v1957_12;
        if (!v1957_10.empty()) {
          const Path v1959_6 = concat_path(v1956_6,v1956_11_head);
          const Space v1959_11 = routine_137(c, v1959_6, p1, v1956_11_tail);
          v1957_12 = compose(v1957_10,v1959_11);
        }
        const Space v1957_13 = unite(v1957_8,v1957_12);
        v1956_11_result = unite(v1956_11_result,v1957_13);
      }
      const Space v1956_11 = std::move(v1956_11_result);
      v1951_12 = compose(v1951_10,v1956_11);
    }
    const Space v1951_13 = unite(v1951_8,v1951_12);
    v1950_12_result = unite(v1950_12_result,v1951_13);
  }
  const Space v1950_12 = std::move(v1950_12_result);
  return v1950_12;
}

static Space routine_218(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1960_7 = unwrap(constant_12,p1);
  const Space v1960_9 = unwrap(constant_12,p0);
  Space v1960_13_result;
  for (int v1960_13_label = 1; v1960_13_label <= 2; ++v1960_13_label) {
    const Space v1960_13_tail = child(s0,v1960_13_label);
    if (v1960_13_tail.empty()) continue;
    const Path v1960_13_head{v1960_13_label};
    const Space v1961_2 = singleton(v1960_13_head);
    const Space v1961_3 = intersect(constant_6,v1961_2);
    const Space v1961_4 = (has_head(v1961_3) ? constant_7 : Space{});
    const Space v1961_5 = subtract(constant_0,v1961_4);
    Space v1961_8;
    if (!v1961_5.empty()) {
      const Path v1962_6 = concat_path(p0,v1960_13_head);
      Space v1962_7_result;
      for (int v1962_7_label = 1; v1962_7_label <= 2; ++v1962_7_label) {
        const Space v1962_7_tail = child(v1960_13_tail,v1962_7_label);
        if (v1962_7_tail.empty()) continue;
        const Path v1962_7_head{v1962_7_label};
        const Space v1963_2 = singleton(v1962_7_head);
        const Space v1963_3 = intersect(constant_6,v1963_2);
        const Space v1963_4 = (has_head(v1963_3) ? constant_7 : Space{});
        const Space v1963_5 = subtract(constant_0,v1963_4);
        Space v1963_8;
        if (!v1963_5.empty()) {
          const Path v1964_6 = concat_path(v1962_6,v1962_7_head);
          const Space v1964_7 = routine_253(c, v1964_6, p1, v1962_7_tail);
          v1963_8 = compose(v1963_5,v1964_7);
        }
        const Space v1963_9 = intersect(constant_6,v1963_2);
        const Space v1963_10 = (has_head(v1963_9) ? constant_7 : Space{});
        Space v1963_12;
        if (!v1963_10.empty()) {
          const Path v1965_6 = concat_path(v1962_6,v1962_7_head);
          const Space v1965_11 = routine_254(c, v1965_6, p1, v1962_7_tail);
          v1963_12 = compose(v1963_10,v1965_11);
        }
        const Space v1963_13 = unite(v1963_8,v1963_12);
        v1962_7_result = unite(v1962_7_result,v1963_13);
      }
      const Space v1962_7 = std::move(v1962_7_result);
      v1961_8 = compose(v1961_5,v1962_7);
    }
    const Space v1961_9 = intersect(constant_6,v1961_2);
    const Space v1961_10 = (has_head(v1961_9) ? constant_7 : Space{});
    const Space v1961_11 = unwrap(v1960_9,v1960_13_head);
    const Space v1961_12 = compose(v1960_7,v1961_11);
    const Path v1966_6 = concat_path(p0,v1960_13_head);
    const Path v1961_13 = concat_path(p1,v1966_6);
    const Space v1961_14 = singleton(v1961_13);
    const Space v1961_15 = subtract(v1961_12,v1961_14);
    const Space v1961_16 = compose(v1961_10,v1961_15);
    const Space v1961_17 = unite(v1961_8,v1961_16);
    v1960_13_result = unite(v1960_13_result,v1961_17);
  }
  const Space v1960_13 = std::move(v1960_13_result);
  return v1960_13;
}

static Space routine_219(Context& c, const Path& p0, const Space& s0) {
  Space v1967_11_result;
  for (int v1967_11_label = 1; v1967_11_label <= 2; ++v1967_11_label) {
    const Space v1967_11_tail = child(s0,v1967_11_label);
    if (v1967_11_tail.empty()) continue;
    const Path v1967_11_head{v1967_11_label};
    const Space v1968_2 = singleton(v1967_11_head);
    const Space v1968_3 = intersect(constant_6,v1968_2);
    const Space v1968_4 = (has_head(v1968_3) ? constant_7 : Space{});
    const Space v1968_5 = subtract(constant_0,v1968_4);
    Space v1968_8;
    if (!v1968_5.empty()) {
      const Path v1969_6 = concat_path(p0,v1967_11_head);
      Space v1969_7_result;
      for (int v1969_7_label = 1; v1969_7_label <= 2; ++v1969_7_label) {
        const Space v1969_7_tail = child(v1967_11_tail,v1969_7_label);
        if (v1969_7_tail.empty()) continue;
        const Path v1969_7_head{v1969_7_label};
        const Space v1970_2 = singleton(v1969_7_head);
        const Space v1970_3 = intersect(constant_6,v1970_2);
        const Space v1970_4 = (has_head(v1970_3) ? constant_7 : Space{});
        const Space v1970_5 = subtract(constant_0,v1970_4);
        Space v1970_8;
        if (!v1970_5.empty()) {
          const Path v1971_6 = concat_path(v1969_6,v1969_7_head);
          const Space v1971_7 = routine_255(c, v1971_6, v1969_7_tail);
          v1970_8 = compose(v1970_5,v1971_7);
        }
        const Space v1970_9 = intersect(constant_6,v1970_2);
        const Space v1970_10 = (has_head(v1970_9) ? constant_7 : Space{});
        Space v1970_12;
        if (!v1970_10.empty()) {
          const Path v1972_6 = concat_path(v1969_6,v1969_7_head);
          const Space v1972_11 = routine_256(c, v1972_6, v1969_7_tail);
          v1970_12 = compose(v1970_10,v1972_11);
        }
        const Space v1970_13 = unite(v1970_8,v1970_12);
        v1969_7_result = unite(v1969_7_result,v1970_13);
      }
      const Space v1969_7 = std::move(v1969_7_result);
      v1968_8 = compose(v1968_5,v1969_7);
    }
    const Space v1968_9 = intersect(constant_6,v1968_2);
    const Space v1968_10 = (has_head(v1968_9) ? constant_7 : Space{});
    Space v1968_12;
    if (!v1968_10.empty()) {
      const Path v1973_6 = concat_path(p0,v1967_11_head);
      Space v1973_11_result;
      for (int v1973_11_label = 1; v1973_11_label <= 2; ++v1973_11_label) {
        const Space v1973_11_tail = child(v1967_11_tail,v1973_11_label);
        if (v1973_11_tail.empty()) continue;
        const Path v1973_11_head{v1973_11_label};
        const Space v1974_2 = singleton(v1973_11_head);
        const Space v1974_3 = intersect(constant_6,v1974_2);
        const Space v1974_4 = (has_head(v1974_3) ? constant_7 : Space{});
        const Space v1974_5 = subtract(constant_0,v1974_4);
        Space v1974_8;
        if (!v1974_5.empty()) {
          const Path v1975_6 = concat_path(v1973_6,v1973_11_head);
          const Space v1975_7 = routine_255(c, v1975_6, v1973_11_tail);
          v1974_8 = compose(v1974_5,v1975_7);
        }
        const Space v1974_9 = intersect(constant_6,v1974_2);
        const Space v1974_10 = (has_head(v1974_9) ? constant_7 : Space{});
        Space v1974_12;
        if (!v1974_10.empty()) {
          const Path v1976_6 = concat_path(v1973_6,v1973_11_head);
          const Space v1976_11 = routine_69(c, v1976_6, v1973_11_tail);
          v1974_12 = compose(v1974_10,v1976_11);
        }
        const Space v1974_13 = unite(v1974_8,v1974_12);
        v1973_11_result = unite(v1973_11_result,v1974_13);
      }
      const Space v1973_11 = std::move(v1973_11_result);
      v1968_12 = compose(v1968_10,v1973_11);
    }
    const Space v1968_13 = unite(v1968_8,v1968_12);
    v1967_11_result = unite(v1967_11_result,v1968_13);
  }
  const Space v1967_11 = std::move(v1967_11_result);
  return v1967_11;
}

static Space routine_220(Context& c, const Path& p0, const Space& s0) {
  Space v1977_9_result;
  for (int v1977_9_label = 1; v1977_9_label <= 2; ++v1977_9_label) {
    const Space v1977_9_tail = child(s0,v1977_9_label);
    if (v1977_9_tail.empty()) continue;
    const Path v1977_9_head{v1977_9_label};
    const Space v1978_2 = singleton(v1977_9_head);
    const Space v1978_3 = intersect(constant_6,v1978_2);
    const Space v1978_4 = (has_head(v1978_3) ? constant_7 : Space{});
    const Space v1978_5 = subtract(constant_0,v1978_4);
    Space v1978_8;
    if (!v1978_5.empty()) {
      const Path v1979_6 = concat_path(p0,v1977_9_head);
      Space v1979_7_result;
      for (int v1979_7_label = 1; v1979_7_label <= 2; ++v1979_7_label) {
        const Space v1979_7_tail = child(v1977_9_tail,v1979_7_label);
        if (v1979_7_tail.empty()) continue;
        const Path v1979_7_head{v1979_7_label};
        const Space v1980_2 = singleton(v1979_7_head);
        const Space v1980_3 = intersect(constant_6,v1980_2);
        const Space v1980_4 = (has_head(v1980_3) ? constant_7 : Space{});
        const Space v1980_5 = subtract(constant_0,v1980_4);
        Space v1980_8;
        if (!v1980_5.empty()) {
          const Path v1981_6 = concat_path(v1979_6,v1979_7_head);
          const Space v1981_7 = routine_255(c, v1981_6, v1979_7_tail);
          v1980_8 = compose(v1980_5,v1981_7);
        }
        const Space v1980_9 = intersect(constant_6,v1980_2);
        const Space v1980_10 = (has_head(v1980_9) ? constant_7 : Space{});
        Space v1980_12;
        if (!v1980_10.empty()) {
          const Path v1982_6 = concat_path(v1979_6,v1979_7_head);
          const Space v1982_11 = routine_256(c, v1982_6, v1979_7_tail);
          v1980_12 = compose(v1980_10,v1982_11);
        }
        const Space v1980_13 = unite(v1980_8,v1980_12);
        v1979_7_result = unite(v1979_7_result,v1980_13);
      }
      const Space v1979_7 = std::move(v1979_7_result);
      v1978_8 = compose(v1978_5,v1979_7);
    }
    const Space v1978_9 = intersect(constant_6,v1978_2);
    const Space v1978_10 = (has_head(v1978_9) ? constant_7 : Space{});
    const Space v1978_11 = compose(v1978_10,constant_9);
    const Space v1978_12 = unite(v1978_8,v1978_11);
    v1977_9_result = unite(v1977_9_result,v1978_12);
  }
  const Space v1977_9 = std::move(v1977_9_result);
  return v1977_9;
}

static Space routine_221(Context& c, const Path& p0, const Space& s0) {
  Space v1983_11_result;
  for (int v1983_11_label = 1; v1983_11_label <= 2; ++v1983_11_label) {
    const Space v1983_11_tail = child(s0,v1983_11_label);
    if (v1983_11_tail.empty()) continue;
    const Path v1983_11_head{v1983_11_label};
    const Space v1984_2 = singleton(v1983_11_head);
    const Space v1984_3 = intersect(constant_6,v1984_2);
    const Space v1984_4 = (has_head(v1984_3) ? constant_7 : Space{});
    const Space v1984_5 = subtract(constant_0,v1984_4);
    Space v1984_8;
    if (!v1984_5.empty()) {
      const Path v1985_6 = concat_path(p0,v1983_11_head);
      Space v1985_7_result;
      for (int v1985_7_label = 1; v1985_7_label <= 2; ++v1985_7_label) {
        const Space v1985_7_tail = child(v1983_11_tail,v1985_7_label);
        if (v1985_7_tail.empty()) continue;
        const Path v1985_7_head{v1985_7_label};
        const Space v1986_2 = singleton(v1985_7_head);
        const Space v1986_3 = intersect(constant_6,v1986_2);
        const Space v1986_4 = (has_head(v1986_3) ? constant_7 : Space{});
        const Space v1986_5 = subtract(constant_0,v1986_4);
        Space v1986_8;
        if (!v1986_5.empty()) {
          const Path v1987_6 = concat_path(v1985_6,v1985_7_head);
          const Space v1987_7 = routine_257(c, v1987_6, v1985_7_tail);
          v1986_8 = compose(v1986_5,v1987_7);
        }
        const Space v1986_9 = intersect(constant_6,v1986_2);
        const Space v1986_10 = (has_head(v1986_9) ? constant_7 : Space{});
        Space v1986_12;
        if (!v1986_10.empty()) {
          const Path v1988_6 = concat_path(v1985_6,v1985_7_head);
          const Space v1988_11 = routine_258(c, v1988_6, v1985_7_tail);
          v1986_12 = compose(v1986_10,v1988_11);
        }
        const Space v1986_13 = unite(v1986_8,v1986_12);
        v1985_7_result = unite(v1985_7_result,v1986_13);
      }
      const Space v1985_7 = std::move(v1985_7_result);
      v1984_8 = compose(v1984_5,v1985_7);
    }
    const Space v1984_9 = intersect(constant_6,v1984_2);
    const Space v1984_10 = (has_head(v1984_9) ? constant_7 : Space{});
    Space v1984_12;
    if (!v1984_10.empty()) {
      const Path v1989_6 = concat_path(p0,v1983_11_head);
      Space v1989_11_result;
      for (int v1989_11_label = 1; v1989_11_label <= 2; ++v1989_11_label) {
        const Space v1989_11_tail = child(v1983_11_tail,v1989_11_label);
        if (v1989_11_tail.empty()) continue;
        const Path v1989_11_head{v1989_11_label};
        const Space v1990_2 = singleton(v1989_11_head);
        const Space v1990_3 = intersect(constant_6,v1990_2);
        const Space v1990_4 = (has_head(v1990_3) ? constant_7 : Space{});
        const Space v1990_5 = subtract(constant_0,v1990_4);
        Space v1990_8;
        if (!v1990_5.empty()) {
          const Path v1991_6 = concat_path(v1989_6,v1989_11_head);
          const Space v1991_7 = routine_257(c, v1991_6, v1989_11_tail);
          v1990_8 = compose(v1990_5,v1991_7);
        }
        const Space v1990_9 = intersect(constant_6,v1990_2);
        const Space v1990_10 = (has_head(v1990_9) ? constant_7 : Space{});
        Space v1990_12;
        if (!v1990_10.empty()) {
          const Path v1992_6 = concat_path(v1989_6,v1989_11_head);
          const Space v1992_11 = routine_72(c, v1992_6, v1989_11_tail);
          v1990_12 = compose(v1990_10,v1992_11);
        }
        const Space v1990_13 = unite(v1990_8,v1990_12);
        v1989_11_result = unite(v1989_11_result,v1990_13);
      }
      const Space v1989_11 = std::move(v1989_11_result);
      v1984_12 = compose(v1984_10,v1989_11);
    }
    const Space v1984_13 = unite(v1984_8,v1984_12);
    v1983_11_result = unite(v1983_11_result,v1984_13);
  }
  const Space v1983_11 = std::move(v1983_11_result);
  return v1983_11;
}

static Space routine_222(Context& c, const Path& p0, const Space& s0) {
  Space v1993_9_result;
  for (int v1993_9_label = 1; v1993_9_label <= 2; ++v1993_9_label) {
    const Space v1993_9_tail = child(s0,v1993_9_label);
    if (v1993_9_tail.empty()) continue;
    const Path v1993_9_head{v1993_9_label};
    const Space v1994_2 = singleton(v1993_9_head);
    const Space v1994_3 = intersect(constant_6,v1994_2);
    const Space v1994_4 = (has_head(v1994_3) ? constant_7 : Space{});
    const Space v1994_5 = subtract(constant_0,v1994_4);
    Space v1994_8;
    if (!v1994_5.empty()) {
      const Path v1995_6 = concat_path(p0,v1993_9_head);
      Space v1995_7_result;
      for (int v1995_7_label = 1; v1995_7_label <= 2; ++v1995_7_label) {
        const Space v1995_7_tail = child(v1993_9_tail,v1995_7_label);
        if (v1995_7_tail.empty()) continue;
        const Path v1995_7_head{v1995_7_label};
        const Space v1996_2 = singleton(v1995_7_head);
        const Space v1996_3 = intersect(constant_6,v1996_2);
        const Space v1996_4 = (has_head(v1996_3) ? constant_7 : Space{});
        const Space v1996_5 = subtract(constant_0,v1996_4);
        Space v1996_8;
        if (!v1996_5.empty()) {
          const Path v1997_6 = concat_path(v1995_6,v1995_7_head);
          const Space v1997_7 = routine_257(c, v1997_6, v1995_7_tail);
          v1996_8 = compose(v1996_5,v1997_7);
        }
        const Space v1996_9 = intersect(constant_6,v1996_2);
        const Space v1996_10 = (has_head(v1996_9) ? constant_7 : Space{});
        Space v1996_12;
        if (!v1996_10.empty()) {
          const Path v1998_6 = concat_path(v1995_6,v1995_7_head);
          const Space v1998_11 = routine_258(c, v1998_6, v1995_7_tail);
          v1996_12 = compose(v1996_10,v1998_11);
        }
        const Space v1996_13 = unite(v1996_8,v1996_12);
        v1995_7_result = unite(v1995_7_result,v1996_13);
      }
      const Space v1995_7 = std::move(v1995_7_result);
      v1994_8 = compose(v1994_5,v1995_7);
    }
    const Space v1994_9 = intersect(constant_6,v1994_2);
    const Space v1994_10 = (has_head(v1994_9) ? constant_7 : Space{});
    const Space v1994_11 = compose(v1994_10,constant_9);
    const Space v1994_12 = unite(v1994_8,v1994_11);
    v1993_9_result = unite(v1993_9_result,v1994_12);
  }
  const Space v1993_9 = std::move(v1993_9_result);
  return v1993_9;
}

static Space routine_223(Context& c, const Path& p0, const Space& s0) {
  Space v1999_11_result;
  for (int v1999_11_label = 1; v1999_11_label <= 2; ++v1999_11_label) {
    const Space v1999_11_tail = child(s0,v1999_11_label);
    if (v1999_11_tail.empty()) continue;
    const Path v1999_11_head{v1999_11_label};
    const Space v2000_2 = singleton(v1999_11_head);
    const Space v2000_3 = intersect(constant_6,v2000_2);
    const Space v2000_4 = (has_head(v2000_3) ? constant_7 : Space{});
    const Space v2000_5 = subtract(constant_0,v2000_4);
    Space v2000_8;
    if (!v2000_5.empty()) {
      const Path v2001_6 = concat_path(p0,v1999_11_head);
      Space v2001_7_result;
      for (int v2001_7_label = 1; v2001_7_label <= 2; ++v2001_7_label) {
        const Space v2001_7_tail = child(v1999_11_tail,v2001_7_label);
        if (v2001_7_tail.empty()) continue;
        const Path v2001_7_head{v2001_7_label};
        const Space v2002_2 = singleton(v2001_7_head);
        const Space v2002_3 = intersect(constant_6,v2002_2);
        const Space v2002_4 = (has_head(v2002_3) ? constant_7 : Space{});
        const Space v2002_5 = subtract(constant_0,v2002_4);
        Space v2002_8;
        if (!v2002_5.empty()) {
          const Path v2003_6 = concat_path(v2001_6,v2001_7_head);
          const Space v2003_7 = routine_259(c, v2003_6, v2001_7_tail);
          v2002_8 = compose(v2002_5,v2003_7);
        }
        const Space v2002_9 = intersect(constant_6,v2002_2);
        const Space v2002_10 = (has_head(v2002_9) ? constant_7 : Space{});
        Space v2002_12;
        if (!v2002_10.empty()) {
          const Path v2004_6 = concat_path(v2001_6,v2001_7_head);
          const Space v2004_11 = routine_260(c, v2004_6, v2001_7_tail);
          v2002_12 = compose(v2002_10,v2004_11);
        }
        const Space v2002_13 = unite(v2002_8,v2002_12);
        v2001_7_result = unite(v2001_7_result,v2002_13);
      }
      const Space v2001_7 = std::move(v2001_7_result);
      v2000_8 = compose(v2000_5,v2001_7);
    }
    const Space v2000_9 = intersect(constant_6,v2000_2);
    const Space v2000_10 = (has_head(v2000_9) ? constant_7 : Space{});
    Space v2000_12;
    if (!v2000_10.empty()) {
      const Path v2005_6 = concat_path(p0,v1999_11_head);
      Space v2005_11_result;
      for (int v2005_11_label = 1; v2005_11_label <= 2; ++v2005_11_label) {
        const Space v2005_11_tail = child(v1999_11_tail,v2005_11_label);
        if (v2005_11_tail.empty()) continue;
        const Path v2005_11_head{v2005_11_label};
        const Space v2006_2 = singleton(v2005_11_head);
        const Space v2006_3 = intersect(constant_6,v2006_2);
        const Space v2006_4 = (has_head(v2006_3) ? constant_7 : Space{});
        const Space v2006_5 = subtract(constant_0,v2006_4);
        Space v2006_8;
        if (!v2006_5.empty()) {
          const Path v2007_6 = concat_path(v2005_6,v2005_11_head);
          const Space v2007_7 = routine_259(c, v2007_6, v2005_11_tail);
          v2006_8 = compose(v2006_5,v2007_7);
        }
        const Space v2006_9 = intersect(constant_6,v2006_2);
        const Space v2006_10 = (has_head(v2006_9) ? constant_7 : Space{});
        Space v2006_12;
        if (!v2006_10.empty()) {
          const Path v2008_6 = concat_path(v2005_6,v2005_11_head);
          const Space v2008_11 = routine_75(c, v2008_6, v2005_11_tail);
          v2006_12 = compose(v2006_10,v2008_11);
        }
        const Space v2006_13 = unite(v2006_8,v2006_12);
        v2005_11_result = unite(v2005_11_result,v2006_13);
      }
      const Space v2005_11 = std::move(v2005_11_result);
      v2000_12 = compose(v2000_10,v2005_11);
    }
    const Space v2000_13 = unite(v2000_8,v2000_12);
    v1999_11_result = unite(v1999_11_result,v2000_13);
  }
  const Space v1999_11 = std::move(v1999_11_result);
  return v1999_11;
}

static Space routine_224(Context& c, const Path& p0, const Space& s0) {
  Space v2009_8_result;
  for (int v2009_8_label = 1; v2009_8_label <= 2; ++v2009_8_label) {
    const Space v2009_8_tail = child(s0,v2009_8_label);
    if (v2009_8_tail.empty()) continue;
    const Path v2009_8_head{v2009_8_label};
    const Space v2010_2 = singleton(v2009_8_head);
    const Space v2010_3 = intersect(constant_6,v2010_2);
    const Space v2010_4 = (has_head(v2010_3) ? constant_7 : Space{});
    const Space v2010_5 = subtract(constant_0,v2010_4);
    Space v2010_8;
    if (!v2010_5.empty()) {
      const Path v2011_6 = concat_path(p0,v2009_8_head);
      Space v2011_7_result;
      for (int v2011_7_label = 1; v2011_7_label <= 2; ++v2011_7_label) {
        const Space v2011_7_tail = child(v2009_8_tail,v2011_7_label);
        if (v2011_7_tail.empty()) continue;
        const Path v2011_7_head{v2011_7_label};
        const Space v2012_2 = singleton(v2011_7_head);
        const Space v2012_3 = intersect(constant_6,v2012_2);
        const Space v2012_4 = (has_head(v2012_3) ? constant_7 : Space{});
        const Space v2012_5 = subtract(constant_0,v2012_4);
        Space v2012_8;
        if (!v2012_5.empty()) {
          const Path v2013_6 = concat_path(v2011_6,v2011_7_head);
          const Space v2013_7 = routine_259(c, v2013_6, v2011_7_tail);
          v2012_8 = compose(v2012_5,v2013_7);
        }
        const Space v2012_9 = intersect(constant_6,v2012_2);
        const Space v2012_10 = (has_head(v2012_9) ? constant_7 : Space{});
        Space v2012_12;
        if (!v2012_10.empty()) {
          const Path v2014_6 = concat_path(v2011_6,v2011_7_head);
          const Space v2014_11 = routine_260(c, v2014_6, v2011_7_tail);
          v2012_12 = compose(v2012_10,v2014_11);
        }
        const Space v2012_13 = unite(v2012_8,v2012_12);
        v2011_7_result = unite(v2011_7_result,v2012_13);
      }
      const Space v2011_7 = std::move(v2011_7_result);
      v2010_8 = compose(v2010_5,v2011_7);
    }
    const Space v2010_9 = intersect(constant_6,v2010_2);
    const Space v2010_10 = (has_head(v2010_9) ? constant_7 : Space{});
    const Space v2010_11 = compose(v2010_10,v2009_8_tail);
    const Space v2010_12 = unite(v2010_8,v2010_11);
    v2009_8_result = unite(v2009_8_result,v2010_12);
  }
  const Space v2009_8 = std::move(v2009_8_result);
  return v2009_8;
}

static Space routine_225(Context& c, const Path& p0, const Space& s0) {
  Space v2015_11_result;
  for (int v2015_11_label = 1; v2015_11_label <= 2; ++v2015_11_label) {
    const Space v2015_11_tail = child(s0,v2015_11_label);
    if (v2015_11_tail.empty()) continue;
    const Path v2015_11_head{v2015_11_label};
    const Space v2016_2 = singleton(v2015_11_head);
    const Space v2016_3 = intersect(constant_6,v2016_2);
    const Space v2016_4 = (has_head(v2016_3) ? constant_7 : Space{});
    const Space v2016_5 = subtract(constant_0,v2016_4);
    Space v2016_8;
    if (!v2016_5.empty()) {
      const Path v2017_6 = concat_path(p0,v2015_11_head);
      Space v2017_7_result;
      for (int v2017_7_label = 1; v2017_7_label <= 2; ++v2017_7_label) {
        const Space v2017_7_tail = child(v2015_11_tail,v2017_7_label);
        if (v2017_7_tail.empty()) continue;
        const Path v2017_7_head{v2017_7_label};
        const Space v2018_2 = singleton(v2017_7_head);
        const Space v2018_3 = intersect(constant_6,v2018_2);
        const Space v2018_4 = (has_head(v2018_3) ? constant_7 : Space{});
        const Space v2018_5 = subtract(constant_0,v2018_4);
        Space v2018_8;
        if (!v2018_5.empty()) {
          const Path v2019_6 = concat_path(v2017_6,v2017_7_head);
          const Space v2019_7 = routine_261(c, v2019_6, v2017_7_tail);
          v2018_8 = compose(v2018_5,v2019_7);
        }
        const Space v2018_9 = intersect(constant_6,v2018_2);
        const Space v2018_10 = (has_head(v2018_9) ? constant_7 : Space{});
        Space v2018_12;
        if (!v2018_10.empty()) {
          const Path v2020_6 = concat_path(v2017_6,v2017_7_head);
          const Space v2020_11 = routine_262(c, v2020_6, v2017_7_tail);
          v2018_12 = compose(v2018_10,v2020_11);
        }
        const Space v2018_13 = unite(v2018_8,v2018_12);
        v2017_7_result = unite(v2017_7_result,v2018_13);
      }
      const Space v2017_7 = std::move(v2017_7_result);
      v2016_8 = compose(v2016_5,v2017_7);
    }
    const Space v2016_9 = intersect(constant_6,v2016_2);
    const Space v2016_10 = (has_head(v2016_9) ? constant_7 : Space{});
    Space v2016_12;
    if (!v2016_10.empty()) {
      const Path v2021_6 = concat_path(p0,v2015_11_head);
      Space v2021_11_result;
      for (int v2021_11_label = 1; v2021_11_label <= 2; ++v2021_11_label) {
        const Space v2021_11_tail = child(v2015_11_tail,v2021_11_label);
        if (v2021_11_tail.empty()) continue;
        const Path v2021_11_head{v2021_11_label};
        const Space v2022_2 = singleton(v2021_11_head);
        const Space v2022_3 = intersect(constant_6,v2022_2);
        const Space v2022_4 = (has_head(v2022_3) ? constant_7 : Space{});
        const Space v2022_5 = subtract(constant_0,v2022_4);
        Space v2022_8;
        if (!v2022_5.empty()) {
          const Path v2023_6 = concat_path(v2021_6,v2021_11_head);
          const Space v2023_7 = routine_261(c, v2023_6, v2021_11_tail);
          v2022_8 = compose(v2022_5,v2023_7);
        }
        const Space v2022_9 = intersect(constant_6,v2022_2);
        const Space v2022_10 = (has_head(v2022_9) ? constant_7 : Space{});
        Space v2022_12;
        if (!v2022_10.empty()) {
          const Path v2024_6 = concat_path(v2021_6,v2021_11_head);
          const Space v2024_11 = routine_80(c, v2024_6, v2021_11_tail);
          v2022_12 = compose(v2022_10,v2024_11);
        }
        const Space v2022_13 = unite(v2022_8,v2022_12);
        v2021_11_result = unite(v2021_11_result,v2022_13);
      }
      const Space v2021_11 = std::move(v2021_11_result);
      v2016_12 = compose(v2016_10,v2021_11);
    }
    const Space v2016_13 = unite(v2016_8,v2016_12);
    v2015_11_result = unite(v2015_11_result,v2016_13);
  }
  const Space v2015_11 = std::move(v2015_11_result);
  return v2015_11;
}

static Space routine_226(Context& c, const Path& p0, const Space& s0) {
  Space v2025_11_result;
  for (int v2025_11_label = 1; v2025_11_label <= 2; ++v2025_11_label) {
    const Space v2025_11_tail = child(s0,v2025_11_label);
    if (v2025_11_tail.empty()) continue;
    const Path v2025_11_head{v2025_11_label};
    const Space v2026_2 = singleton(v2025_11_head);
    const Space v2026_3 = intersect(constant_6,v2026_2);
    const Space v2026_4 = (has_head(v2026_3) ? constant_7 : Space{});
    const Space v2026_5 = subtract(constant_0,v2026_4);
    Space v2026_8;
    if (!v2026_5.empty()) {
      const Path v2027_6 = concat_path(p0,v2025_11_head);
      Space v2027_7_result;
      for (int v2027_7_label = 1; v2027_7_label <= 2; ++v2027_7_label) {
        const Space v2027_7_tail = child(v2025_11_tail,v2027_7_label);
        if (v2027_7_tail.empty()) continue;
        const Path v2027_7_head{v2027_7_label};
        const Space v2028_2 = singleton(v2027_7_head);
        const Space v2028_3 = intersect(constant_6,v2028_2);
        const Space v2028_4 = (has_head(v2028_3) ? constant_7 : Space{});
        const Space v2028_5 = subtract(constant_0,v2028_4);
        Space v2028_8;
        if (!v2028_5.empty()) {
          const Path v2029_6 = concat_path(v2027_6,v2027_7_head);
          const Space v2029_7 = routine_261(c, v2029_6, v2027_7_tail);
          v2028_8 = compose(v2028_5,v2029_7);
        }
        const Space v2028_9 = intersect(constant_6,v2028_2);
        const Space v2028_10 = (has_head(v2028_9) ? constant_7 : Space{});
        Space v2028_12;
        if (!v2028_10.empty()) {
          const Path v2030_6 = concat_path(v2027_6,v2027_7_head);
          const Space v2030_11 = routine_262(c, v2030_6, v2027_7_tail);
          v2028_12 = compose(v2028_10,v2030_11);
        }
        const Space v2028_13 = unite(v2028_8,v2028_12);
        v2027_7_result = unite(v2027_7_result,v2028_13);
      }
      const Space v2027_7 = std::move(v2027_7_result);
      v2026_8 = compose(v2026_5,v2027_7);
    }
    const Space v2026_9 = intersect(constant_6,v2026_2);
    const Space v2026_10 = (has_head(v2026_9) ? constant_7 : Space{});
    Space v2026_12;
    if (!v2026_10.empty()) {
      const Path v2031_6 = concat_path(p0,v2025_11_head);
      Space v2031_11_result;
      for (int v2031_11_label = 1; v2031_11_label <= 2; ++v2031_11_label) {
        const Space v2031_11_tail = child(v2025_11_tail,v2031_11_label);
        if (v2031_11_tail.empty()) continue;
        const Path v2031_11_head{v2031_11_label};
        const Space v2032_2 = singleton(v2031_11_head);
        const Space v2032_3 = intersect(constant_6,v2032_2);
        const Space v2032_4 = (has_head(v2032_3) ? constant_7 : Space{});
        const Space v2032_5 = subtract(constant_0,v2032_4);
        Space v2032_7;
        if (!v2032_5.empty()) {
          const Space v2033_6 = routine_122(c, v2031_11_head, v2031_6, v2031_11_tail);
          v2032_7 = compose(v2032_5,v2033_6);
        }
        const Space v2032_8 = intersect(constant_6,v2032_2);
        const Space v2032_9 = (has_head(v2032_8) ? constant_7 : Space{});
        Space v2032_11;
        if (!v2032_9.empty()) {
          const Space v2034_10 = routine_123(c, v2031_11_head, v2031_6, v2031_11_tail);
          v2032_11 = compose(v2032_9,v2034_10);
        }
        const Space v2032_12 = unite(v2032_7,v2032_11);
        v2031_11_result = unite(v2031_11_result,v2032_12);
      }
      const Space v2031_11 = std::move(v2031_11_result);
      v2026_12 = compose(v2026_10,v2031_11);
    }
    const Space v2026_13 = unite(v2026_8,v2026_12);
    v2025_11_result = unite(v2025_11_result,v2026_13);
  }
  const Space v2025_11 = std::move(v2025_11_result);
  return v2025_11;
}

static Space routine_227(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2035_12_result;
  for (int v2035_12_label = 1; v2035_12_label <= 2; ++v2035_12_label) {
    const Space v2035_12_tail = child(s0,v2035_12_label);
    if (v2035_12_tail.empty()) continue;
    const Path v2035_12_head{v2035_12_label};
    const Space v2036_2 = singleton(v2035_12_head);
    const Space v2036_3 = intersect(constant_6,v2036_2);
    const Space v2036_4 = (has_head(v2036_3) ? constant_7 : Space{});
    const Space v2036_5 = subtract(constant_0,v2036_4);
    Space v2036_8;
    if (!v2036_5.empty()) {
      const Path v2037_6 = concat_path(p0,v2035_12_head);
      Space v2037_7_result;
      for (int v2037_7_label = 1; v2037_7_label <= 2; ++v2037_7_label) {
        const Space v2037_7_tail = child(v2035_12_tail,v2037_7_label);
        if (v2037_7_tail.empty()) continue;
        const Path v2037_7_head{v2037_7_label};
        const Space v2038_2 = singleton(v2037_7_head);
        const Space v2038_3 = intersect(constant_6,v2038_2);
        const Space v2038_4 = (has_head(v2038_3) ? constant_7 : Space{});
        const Space v2038_5 = subtract(constant_0,v2038_4);
        Space v2038_8;
        if (!v2038_5.empty()) {
          const Path v2039_6 = concat_path(v2037_6,v2037_7_head);
          const Space v2039_7 = routine_263(c, v2039_6, p1, v2037_7_tail);
          v2038_8 = compose(v2038_5,v2039_7);
        }
        const Space v2038_9 = intersect(constant_6,v2038_2);
        const Space v2038_10 = (has_head(v2038_9) ? constant_7 : Space{});
        Space v2038_12;
        if (!v2038_10.empty()) {
          const Path v2040_6 = concat_path(v2037_6,v2037_7_head);
          const Space v2040_11 = routine_264(c, v2040_6, p1, v2037_7_tail);
          v2038_12 = compose(v2038_10,v2040_11);
        }
        const Space v2038_13 = unite(v2038_8,v2038_12);
        v2037_7_result = unite(v2037_7_result,v2038_13);
      }
      const Space v2037_7 = std::move(v2037_7_result);
      v2036_8 = compose(v2036_5,v2037_7);
    }
    const Space v2036_9 = intersect(constant_6,v2036_2);
    const Space v2036_10 = (has_head(v2036_9) ? constant_7 : Space{});
    Space v2036_12;
    if (!v2036_10.empty()) {
      const Path v2041_6 = concat_path(p0,v2035_12_head);
      Space v2041_11_result;
      for (int v2041_11_label = 1; v2041_11_label <= 2; ++v2041_11_label) {
        const Space v2041_11_tail = child(v2035_12_tail,v2041_11_label);
        if (v2041_11_tail.empty()) continue;
        const Path v2041_11_head{v2041_11_label};
        const Space v2042_2 = singleton(v2041_11_head);
        const Space v2042_3 = intersect(constant_6,v2042_2);
        const Space v2042_4 = (has_head(v2042_3) ? constant_7 : Space{});
        const Space v2042_5 = subtract(constant_0,v2042_4);
        Space v2042_8;
        if (!v2042_5.empty()) {
          const Path v2043_6 = concat_path(v2041_6,v2041_11_head);
          const Space v2043_7 = routine_263(c, v2043_6, p1, v2041_11_tail);
          v2042_8 = compose(v2042_5,v2043_7);
        }
        const Space v2042_9 = intersect(constant_6,v2042_2);
        const Space v2042_10 = (has_head(v2042_9) ? constant_7 : Space{});
        Space v2042_12;
        if (!v2042_10.empty()) {
          const Path v2044_6 = concat_path(v2041_6,v2041_11_head);
          const Space v2044_11 = routine_137(c, v2044_6, p1, v2041_11_tail);
          v2042_12 = compose(v2042_10,v2044_11);
        }
        const Space v2042_13 = unite(v2042_8,v2042_12);
        v2041_11_result = unite(v2041_11_result,v2042_13);
      }
      const Space v2041_11 = std::move(v2041_11_result);
      v2036_12 = compose(v2036_10,v2041_11);
    }
    const Space v2036_13 = unite(v2036_8,v2036_12);
    v2035_12_result = unite(v2035_12_result,v2036_13);
  }
  const Space v2035_12 = std::move(v2035_12_result);
  return v2035_12;
}

static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2045_7 = unwrap(constant_12,p1);
  const Space v2045_9 = unwrap(constant_12,p0);
  Space v2045_13_result;
  for (int v2045_13_label = 1; v2045_13_label <= 2; ++v2045_13_label) {
    const Space v2045_13_tail = child(s0,v2045_13_label);
    if (v2045_13_tail.empty()) continue;
    const Path v2045_13_head{v2045_13_label};
    const Space v2046_2 = singleton(v2045_13_head);
    const Space v2046_3 = intersect(constant_6,v2046_2);
    const Space v2046_4 = (has_head(v2046_3) ? constant_7 : Space{});
    const Space v2046_5 = subtract(constant_0,v2046_4);
    Space v2046_8;
    if (!v2046_5.empty()) {
      const Path v2047_6 = concat_path(p0,v2045_13_head);
      Space v2047_7_result;
      for (int v2047_7_label = 1; v2047_7_label <= 2; ++v2047_7_label) {
        const Space v2047_7_tail = child(v2045_13_tail,v2047_7_label);
        if (v2047_7_tail.empty()) continue;
        const Path v2047_7_head{v2047_7_label};
        const Space v2048_2 = singleton(v2047_7_head);
        const Space v2048_3 = intersect(constant_6,v2048_2);
        const Space v2048_4 = (has_head(v2048_3) ? constant_7 : Space{});
        const Space v2048_5 = subtract(constant_0,v2048_4);
        Space v2048_8;
        if (!v2048_5.empty()) {
          const Path v2049_6 = concat_path(v2047_6,v2047_7_head);
          const Space v2049_7 = routine_263(c, v2049_6, p1, v2047_7_tail);
          v2048_8 = compose(v2048_5,v2049_7);
        }
        const Space v2048_9 = intersect(constant_6,v2048_2);
        const Space v2048_10 = (has_head(v2048_9) ? constant_7 : Space{});
        Space v2048_12;
        if (!v2048_10.empty()) {
          const Path v2050_6 = concat_path(v2047_6,v2047_7_head);
          const Space v2050_11 = routine_264(c, v2050_6, p1, v2047_7_tail);
          v2048_12 = compose(v2048_10,v2050_11);
        }
        const Space v2048_13 = unite(v2048_8,v2048_12);
        v2047_7_result = unite(v2047_7_result,v2048_13);
      }
      const Space v2047_7 = std::move(v2047_7_result);
      v2046_8 = compose(v2046_5,v2047_7);
    }
    const Space v2046_9 = intersect(constant_6,v2046_2);
    const Space v2046_10 = (has_head(v2046_9) ? constant_7 : Space{});
    const Space v2046_11 = unwrap(v2045_9,v2045_13_head);
    const Space v2046_12 = compose(v2045_7,v2046_11);
    const Path v2051_6 = concat_path(p0,v2045_13_head);
    const Path v2046_13 = concat_path(p1,v2051_6);
    const Space v2046_14 = singleton(v2046_13);
    const Space v2046_15 = subtract(v2046_12,v2046_14);
    const Space v2046_16 = compose(v2046_10,v2046_15);
    const Space v2046_17 = unite(v2046_8,v2046_16);
    v2045_13_result = unite(v2045_13_result,v2046_17);
  }
  const Space v2045_13 = std::move(v2045_13_result);
  return v2045_13;
}

static Space routine_229(Context& c, const Path& p0, const Space& s0) {
  Space v2052_4_result;
  for (int v2052_4_label = 1; v2052_4_label <= 2; ++v2052_4_label) {
    const Space v2052_4_tail = child(s0,v2052_4_label);
    if (v2052_4_tail.empty()) continue;
    const Path v2052_4_head{v2052_4_label};
    const Space v2053_2 = singleton(v2052_4_head);
    const Space v2053_3 = intersect(constant_6,v2053_2);
    const Space v2053_4 = (has_head(v2053_3) ? constant_7 : Space{});
    Space v2053_7;
    if (!v2053_4.empty()) {
      const Path v2054_5 = concat_path(p0,v2052_4_head);
      Space v2054_6_result;
      for (int v2054_6_label = 1; v2054_6_label <= 2; ++v2054_6_label) {
        const Space v2054_6_tail = child(v2052_4_tail,v2054_6_label);
        if (v2054_6_tail.empty()) continue;
        const Path v2054_6_head{v2054_6_label};
        const Space v2055_2 = singleton(v2054_6_head);
        const Space v2055_3 = intersect(constant_6,v2055_2);
        const Space v2055_4 = (has_head(v2055_3) ? constant_7 : Space{});
        Space v2055_7;
        if (!v2055_4.empty()) {
          const Path v2056_5 = concat_path(v2054_5,v2054_6_head);
          const Space v2056_6 = routine_69(c, v2056_5, v2054_6_tail);
          v2055_7 = compose(v2055_4,v2056_6);
        }
        v2054_6_result = unite(v2054_6_result,v2055_7);
      }
      const Space v2054_6 = std::move(v2054_6_result);
      v2053_7 = compose(v2053_4,v2054_6);
    }
    v2052_4_result = unite(v2052_4_result,v2053_7);
  }
  const Space v2052_4 = std::move(v2052_4_result);
  return v2052_4;
}

static Space routine_230(Context& c, const Path& p0, const Space& s0) {
  Space v2057_4_result;
  for (int v2057_4_label = 1; v2057_4_label <= 2; ++v2057_4_label) {
    const Space v2057_4_tail = child(s0,v2057_4_label);
    if (v2057_4_tail.empty()) continue;
    const Path v2057_4_head{v2057_4_label};
    const Space v2058_2 = singleton(v2057_4_head);
    const Space v2058_3 = intersect(constant_6,v2058_2);
    const Space v2058_4 = (has_head(v2058_3) ? constant_7 : Space{});
    const Space v2058_5 = compose(v2058_4,constant_9);
    v2057_4_result = unite(v2057_4_result,v2058_5);
  }
  const Space v2057_4 = std::move(v2057_4_result);
  return v2057_4;
}

static Space routine_231(Context& c, const Path& p0, const Space& s0) {
  Space v2059_4_result;
  for (int v2059_4_label = 1; v2059_4_label <= 2; ++v2059_4_label) {
    const Space v2059_4_tail = child(s0,v2059_4_label);
    if (v2059_4_tail.empty()) continue;
    const Path v2059_4_head{v2059_4_label};
    const Space v2060_2 = singleton(v2059_4_head);
    const Space v2060_3 = intersect(constant_6,v2060_2);
    const Space v2060_4 = (has_head(v2060_3) ? constant_7 : Space{});
    Space v2060_7;
    if (!v2060_4.empty()) {
      const Path v2061_5 = concat_path(p0,v2059_4_head);
      Space v2061_6_result;
      for (int v2061_6_label = 1; v2061_6_label <= 2; ++v2061_6_label) {
        const Space v2061_6_tail = child(v2059_4_tail,v2061_6_label);
        if (v2061_6_tail.empty()) continue;
        const Path v2061_6_head{v2061_6_label};
        const Space v2062_2 = singleton(v2061_6_head);
        const Space v2062_3 = intersect(constant_6,v2062_2);
        const Space v2062_4 = (has_head(v2062_3) ? constant_7 : Space{});
        Space v2062_7;
        if (!v2062_4.empty()) {
          const Path v2063_5 = concat_path(v2061_5,v2061_6_head);
          const Space v2063_6 = routine_72(c, v2063_5, v2061_6_tail);
          v2062_7 = compose(v2062_4,v2063_6);
        }
        v2061_6_result = unite(v2061_6_result,v2062_7);
      }
      const Space v2061_6 = std::move(v2061_6_result);
      v2060_7 = compose(v2060_4,v2061_6);
    }
    v2059_4_result = unite(v2059_4_result,v2060_7);
  }
  const Space v2059_4 = std::move(v2059_4_result);
  return v2059_4;
}

static Space routine_232(Context& c, const Path& p0, const Space& s0) {
  Space v2064_4_result;
  for (int v2064_4_label = 1; v2064_4_label <= 2; ++v2064_4_label) {
    const Space v2064_4_tail = child(s0,v2064_4_label);
    if (v2064_4_tail.empty()) continue;
    const Path v2064_4_head{v2064_4_label};
    const Space v2065_2 = singleton(v2064_4_head);
    const Space v2065_3 = intersect(constant_6,v2065_2);
    const Space v2065_4 = (has_head(v2065_3) ? constant_7 : Space{});
    const Space v2065_5 = compose(v2065_4,constant_9);
    v2064_4_result = unite(v2064_4_result,v2065_5);
  }
  const Space v2064_4 = std::move(v2064_4_result);
  return v2064_4;
}

static Space routine_233(Context& c, const Path& p0, const Space& s0) {
  Space v2066_4_result;
  for (int v2066_4_label = 1; v2066_4_label <= 2; ++v2066_4_label) {
    const Space v2066_4_tail = child(s0,v2066_4_label);
    if (v2066_4_tail.empty()) continue;
    const Path v2066_4_head{v2066_4_label};
    const Space v2067_2 = singleton(v2066_4_head);
    const Space v2067_3 = intersect(constant_6,v2067_2);
    const Space v2067_4 = (has_head(v2067_3) ? constant_7 : Space{});
    Space v2067_7;
    if (!v2067_4.empty()) {
      const Path v2068_5 = concat_path(p0,v2066_4_head);
      Space v2068_6_result;
      for (int v2068_6_label = 1; v2068_6_label <= 2; ++v2068_6_label) {
        const Space v2068_6_tail = child(v2066_4_tail,v2068_6_label);
        if (v2068_6_tail.empty()) continue;
        const Path v2068_6_head{v2068_6_label};
        const Space v2069_2 = singleton(v2068_6_head);
        const Space v2069_3 = intersect(constant_6,v2069_2);
        const Space v2069_4 = (has_head(v2069_3) ? constant_7 : Space{});
        Space v2069_7;
        if (!v2069_4.empty()) {
          const Path v2070_5 = concat_path(v2068_5,v2068_6_head);
          const Space v2070_6 = routine_75(c, v2070_5, v2068_6_tail);
          v2069_7 = compose(v2069_4,v2070_6);
        }
        v2068_6_result = unite(v2068_6_result,v2069_7);
      }
      const Space v2068_6 = std::move(v2068_6_result);
      v2067_7 = compose(v2067_4,v2068_6);
    }
    v2066_4_result = unite(v2066_4_result,v2067_7);
  }
  const Space v2066_4 = std::move(v2066_4_result);
  return v2066_4;
}

static Space routine_234(Context& c, const Path& p0, const Space& s0) {
  Space v2071_3_result;
  for (int v2071_3_label = 1; v2071_3_label <= 2; ++v2071_3_label) {
    const Space v2071_3_tail = child(s0,v2071_3_label);
    if (v2071_3_tail.empty()) continue;
    const Path v2071_3_head{v2071_3_label};
    const Space v2072_2 = singleton(v2071_3_head);
    const Space v2072_3 = intersect(constant_6,v2072_2);
    const Space v2072_4 = (has_head(v2072_3) ? constant_7 : Space{});
    const Space v2072_5 = compose(v2072_4,v2071_3_tail);
    v2071_3_result = unite(v2071_3_result,v2072_5);
  }
  const Space v2071_3 = std::move(v2071_3_result);
  return v2071_3;
}

static Space routine_235(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2073_3 = Space{};
  return v2073_3;
}

static Space routine_236(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2074_4_result;
  for (int v2074_4_label = 1; v2074_4_label <= 2; ++v2074_4_label) {
    const Space v2074_4_tail = child(s0,v2074_4_label);
    if (v2074_4_tail.empty()) continue;
    const Path v2074_4_head{v2074_4_label};
    const Space v2075_2 = singleton(v2074_4_head);
    const Space v2075_3 = intersect(constant_6,v2075_2);
    const Space v2075_4 = (has_head(v2075_3) ? constant_7 : Space{});
    Space v2075_8;
    if (!v2075_4.empty()) {
      const Path v2076_5 = concat_path(p0,v2074_4_head);
      const Path v2076_6 = concat_path(p1,v2076_5);
      const Space v2076_7 = routine_29(c, v2076_6);
      v2075_8 = compose(v2075_4,v2076_7);
    }
    v2074_4_result = unite(v2074_4_result,v2075_8);
  }
  const Space v2074_4 = std::move(v2074_4_result);
  return v2074_4;
}

static Space routine_237(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v2077_4 = Space{};
  return v2077_4;
}

static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v2078_6 = unwrap(s1,constant_8);
  Space v2078_16_result;
  for (int v2078_16_label = 1; v2078_16_label <= 2; ++v2078_16_label) {
    const Space v2078_16_tail = child(s0,v2078_16_label);
    if (v2078_16_tail.empty()) continue;
    const Path v2078_16_head{v2078_16_label};
    const Space v2079_2 = singleton(v2078_16_head);
    const Space v2079_3 = intersect(constant_6,v2079_2);
    const Space v2079_4 = (has_head(v2079_3) ? constant_7 : Space{});
    Space v2079_17;
    if (!v2079_4.empty()) {
      const Path v2080_5 = concat_path(p0,v2078_16_head);
      const Path v2080_6 = concat_path(p1,v2080_5);
      const Space v2080_7 = routine_29(c, v2080_6);
      const Space v2080_8 = intersect(v2078_6,v2080_7);
      const Space v2080_9 = routine_33(c, v2080_8);
      Space v2080_10_result;
      for (int v2080_10_label = 1; v2080_10_label <= 2; ++v2080_10_label) {
        const Space v2080_10_tail = child(v2080_9,v2080_10_label);
        if (v2080_10_tail.empty()) continue;
        const Path v2080_10_head{v2080_10_label};
        const Space v2081_2 = singleton(v2080_10_head);
        const Space v2081_3 = intersect(constant_6,v2081_2);
        const Space v2081_4 = (has_head(v2081_3) ? constant_7 : Space{});
        const Space v2081_5 = subtract(constant_0,v2081_4);
        Space v2081_7;
        if (!v2081_5.empty()) {
          const Space v2082_6 = routine_52(c, v2080_10_head, v2080_10_tail);
          v2081_7 = compose(v2081_5,v2082_6);
        }
        const Space v2081_8 = intersect(constant_6,v2081_2);
        const Space v2081_9 = (has_head(v2081_8) ? constant_7 : Space{});
        Space v2081_11;
        if (!v2081_9.empty()) {
          const Space v2083_10 = routine_53(c, v2080_10_head, v2080_10_tail);
          v2081_11 = compose(v2081_9,v2083_10);
        }
        const Space v2081_12 = unite(v2081_7,v2081_11);
        v2080_10_result = unite(v2080_10_result,v2081_12);
      }
      const Space v2080_10 = std::move(v2080_10_result);
      const Space v2080_11 = routine_54(c, v2080_8);
      Space v2080_12_result;
      for (int v2080_12_label = 1; v2080_12_label <= 2; ++v2080_12_label) {
        const Space v2080_12_tail = child(v2080_11,v2080_12_label);
        if (v2080_12_tail.empty()) continue;
        const Path v2080_12_head{v2080_12_label};
        const Space v2084_2 = singleton(v2080_12_head);
        const Space v2084_3 = intersect(constant_6,v2084_2);
        const Space v2084_4 = (has_head(v2084_3) ? constant_7 : Space{});
        const Space v2084_5 = subtract(constant_0,v2084_4);
        Space v2084_7;
        if (!v2084_5.empty()) {
          const Space v2085_6 = routine_55(c, v2080_12_head, v2080_12_tail);
          v2084_7 = compose(v2084_5,v2085_6);
        }
        const Space v2084_8 = intersect(constant_6,v2084_2);
        const Space v2084_9 = (has_head(v2084_8) ? constant_7 : Space{});
        Space v2084_11;
        if (!v2084_9.empty()) {
          const Space v2086_10 = routine_56(c, v2080_12_head, v2080_12_tail);
          v2084_11 = compose(v2084_9,v2086_10);
        }
        const Space v2084_12 = unite(v2084_7,v2084_11);
        v2080_12_result = unite(v2080_12_result,v2084_12);
      }
      const Space v2080_12 = std::move(v2080_12_result);
      const Space v2080_13 = subtract(v2080_10,v2080_12);
      const Space v2080_14 = singleton(v2080_6);
      const Space v2080_15 = compose(v2080_13,v2080_14);
      Space v2080_16_result;
      for (int v2080_16_label = 1; v2080_16_label <= 2; ++v2080_16_label) {
        const Space v2080_16_tail = child(v2080_15,v2080_16_label);
        if (v2080_16_tail.empty()) continue;
        const Path v2080_16_head{v2080_16_label};
        const Space v2087_2 = singleton(v2080_16_head);
        const Space v2087_3 = intersect(constant_6,v2087_2);
        const Space v2087_4 = (has_head(v2087_3) ? constant_7 : Space{});
        const Space v2087_5 = subtract(constant_0,v2087_4);
        Space v2087_7;
        if (!v2087_5.empty()) {
          const Space v2088_6 = routine_57(c, v2080_16_head, v2080_16_tail);
          v2087_7 = compose(v2087_5,v2088_6);
        }
        const Space v2087_8 = intersect(constant_6,v2087_2);
        const Space v2087_9 = (has_head(v2087_8) ? constant_7 : Space{});
        Space v2087_11;
        if (!v2087_9.empty()) {
          const Space v2089_10 = routine_58(c, v2080_16_head, v2080_16_tail);
          v2087_11 = compose(v2087_9,v2089_10);
        }
        const Space v2087_12 = unite(v2087_7,v2087_11);
        v2080_16_result = unite(v2080_16_result,v2087_12);
      }
      const Space v2080_16 = std::move(v2080_16_result);
      v2079_17 = compose(v2079_4,v2080_16);
    }
    v2078_16_result = unite(v2078_16_result,v2079_17);
  }
  const Space v2078_16 = std::move(v2078_16_result);
  return v2078_16;
}

static Space routine_239(Context& c, const Path& p0, const Space& s0) {
  Space v2090_11_result;
  for (int v2090_11_label = 1; v2090_11_label <= 2; ++v2090_11_label) {
    const Space v2090_11_tail = child(s0,v2090_11_label);
    if (v2090_11_tail.empty()) continue;
    const Path v2090_11_head{v2090_11_label};
    const Space v2091_2 = singleton(v2090_11_head);
    const Space v2091_3 = intersect(constant_6,v2091_2);
    const Space v2091_4 = (has_head(v2091_3) ? constant_7 : Space{});
    const Space v2091_5 = subtract(constant_0,v2091_4);
    Space v2091_8;
    if (!v2091_5.empty()) {
      const Path v2092_6 = concat_path(p0,v2090_11_head);
      Space v2092_7_result;
      for (int v2092_7_label = 1; v2092_7_label <= 2; ++v2092_7_label) {
        const Space v2092_7_tail = child(v2090_11_tail,v2092_7_label);
        if (v2092_7_tail.empty()) continue;
        const Path v2092_7_head{v2092_7_label};
        const Space v2093_2 = singleton(v2092_7_head);
        const Space v2093_3 = intersect(constant_6,v2093_2);
        const Space v2093_4 = (has_head(v2093_3) ? constant_7 : Space{});
        const Space v2093_5 = subtract(constant_0,v2093_4);
        Space v2093_8;
        if (!v2093_5.empty()) {
          const Path v2094_6 = concat_path(v2092_6,v2092_7_head);
          const Space v2094_7 = routine_265(c, v2094_6, v2092_7_tail);
          v2093_8 = compose(v2093_5,v2094_7);
        }
        const Space v2093_9 = intersect(constant_6,v2093_2);
        const Space v2093_10 = (has_head(v2093_9) ? constant_7 : Space{});
        Space v2093_12;
        if (!v2093_10.empty()) {
          const Path v2095_6 = concat_path(v2092_6,v2092_7_head);
          const Space v2095_11 = routine_266(c, v2095_6, v2092_7_tail);
          v2093_12 = compose(v2093_10,v2095_11);
        }
        const Space v2093_13 = unite(v2093_8,v2093_12);
        v2092_7_result = unite(v2092_7_result,v2093_13);
      }
      const Space v2092_7 = std::move(v2092_7_result);
      v2091_8 = compose(v2091_5,v2092_7);
    }
    const Space v2091_9 = intersect(constant_6,v2091_2);
    const Space v2091_10 = (has_head(v2091_9) ? constant_7 : Space{});
    Space v2091_12;
    if (!v2091_10.empty()) {
      const Path v2096_6 = concat_path(p0,v2090_11_head);
      Space v2096_11_result;
      for (int v2096_11_label = 1; v2096_11_label <= 2; ++v2096_11_label) {
        const Space v2096_11_tail = child(v2090_11_tail,v2096_11_label);
        if (v2096_11_tail.empty()) continue;
        const Path v2096_11_head{v2096_11_label};
        const Space v2097_2 = singleton(v2096_11_head);
        const Space v2097_3 = intersect(constant_6,v2097_2);
        const Space v2097_4 = (has_head(v2097_3) ? constant_7 : Space{});
        const Space v2097_5 = subtract(constant_0,v2097_4);
        Space v2097_8;
        if (!v2097_5.empty()) {
          const Path v2098_6 = concat_path(v2096_6,v2096_11_head);
          const Space v2098_7 = routine_265(c, v2098_6, v2096_11_tail);
          v2097_8 = compose(v2097_5,v2098_7);
        }
        const Space v2097_9 = intersect(constant_6,v2097_2);
        const Space v2097_10 = (has_head(v2097_9) ? constant_7 : Space{});
        Space v2097_12;
        if (!v2097_10.empty()) {
          const Path v2099_6 = concat_path(v2096_6,v2096_11_head);
          const Space v2099_11 = routine_100(c, v2099_6, v2096_11_tail);
          v2097_12 = compose(v2097_10,v2099_11);
        }
        const Space v2097_13 = unite(v2097_8,v2097_12);
        v2096_11_result = unite(v2096_11_result,v2097_13);
      }
      const Space v2096_11 = std::move(v2096_11_result);
      v2091_12 = compose(v2091_10,v2096_11);
    }
    const Space v2091_13 = unite(v2091_8,v2091_12);
    v2090_11_result = unite(v2090_11_result,v2091_13);
  }
  const Space v2090_11 = std::move(v2090_11_result);
  return v2090_11;
}

static Space routine_240(Context& c, const Path& p0, const Space& s0) {
  Space v2100_9_result;
  for (int v2100_9_label = 1; v2100_9_label <= 2; ++v2100_9_label) {
    const Space v2100_9_tail = child(s0,v2100_9_label);
    if (v2100_9_tail.empty()) continue;
    const Path v2100_9_head{v2100_9_label};
    const Space v2101_2 = singleton(v2100_9_head);
    const Space v2101_3 = intersect(constant_6,v2101_2);
    const Space v2101_4 = (has_head(v2101_3) ? constant_7 : Space{});
    const Space v2101_5 = subtract(constant_0,v2101_4);
    Space v2101_8;
    if (!v2101_5.empty()) {
      const Path v2102_6 = concat_path(p0,v2100_9_head);
      Space v2102_7_result;
      for (int v2102_7_label = 1; v2102_7_label <= 2; ++v2102_7_label) {
        const Space v2102_7_tail = child(v2100_9_tail,v2102_7_label);
        if (v2102_7_tail.empty()) continue;
        const Path v2102_7_head{v2102_7_label};
        const Space v2103_2 = singleton(v2102_7_head);
        const Space v2103_3 = intersect(constant_6,v2103_2);
        const Space v2103_4 = (has_head(v2103_3) ? constant_7 : Space{});
        const Space v2103_5 = subtract(constant_0,v2103_4);
        Space v2103_8;
        if (!v2103_5.empty()) {
          const Path v2104_6 = concat_path(v2102_6,v2102_7_head);
          const Space v2104_7 = routine_265(c, v2104_6, v2102_7_tail);
          v2103_8 = compose(v2103_5,v2104_7);
        }
        const Space v2103_9 = intersect(constant_6,v2103_2);
        const Space v2103_10 = (has_head(v2103_9) ? constant_7 : Space{});
        Space v2103_12;
        if (!v2103_10.empty()) {
          const Path v2105_6 = concat_path(v2102_6,v2102_7_head);
          const Space v2105_11 = routine_266(c, v2105_6, v2102_7_tail);
          v2103_12 = compose(v2103_10,v2105_11);
        }
        const Space v2103_13 = unite(v2103_8,v2103_12);
        v2102_7_result = unite(v2102_7_result,v2103_13);
      }
      const Space v2102_7 = std::move(v2102_7_result);
      v2101_8 = compose(v2101_5,v2102_7);
    }
    const Space v2101_9 = intersect(constant_6,v2101_2);
    const Space v2101_10 = (has_head(v2101_9) ? constant_7 : Space{});
    const Space v2101_11 = compose(v2101_10,constant_9);
    const Space v2101_12 = unite(v2101_8,v2101_11);
    v2100_9_result = unite(v2100_9_result,v2101_12);
  }
  const Space v2100_9 = std::move(v2100_9_result);
  return v2100_9;
}

static Space routine_241(Context& c, const Path& p0, const Space& s0) {
  Space v2106_11_result;
  for (int v2106_11_label = 1; v2106_11_label <= 2; ++v2106_11_label) {
    const Space v2106_11_tail = child(s0,v2106_11_label);
    if (v2106_11_tail.empty()) continue;
    const Path v2106_11_head{v2106_11_label};
    const Space v2107_2 = singleton(v2106_11_head);
    const Space v2107_3 = intersect(constant_6,v2107_2);
    const Space v2107_4 = (has_head(v2107_3) ? constant_7 : Space{});
    const Space v2107_5 = subtract(constant_0,v2107_4);
    Space v2107_8;
    if (!v2107_5.empty()) {
      const Path v2108_6 = concat_path(p0,v2106_11_head);
      Space v2108_7_result;
      for (int v2108_7_label = 1; v2108_7_label <= 2; ++v2108_7_label) {
        const Space v2108_7_tail = child(v2106_11_tail,v2108_7_label);
        if (v2108_7_tail.empty()) continue;
        const Path v2108_7_head{v2108_7_label};
        const Space v2109_2 = singleton(v2108_7_head);
        const Space v2109_3 = intersect(constant_6,v2109_2);
        const Space v2109_4 = (has_head(v2109_3) ? constant_7 : Space{});
        const Space v2109_5 = subtract(constant_0,v2109_4);
        Space v2109_8;
        if (!v2109_5.empty()) {
          const Path v2110_6 = concat_path(v2108_6,v2108_7_head);
          const Space v2110_7 = routine_267(c, v2110_6, v2108_7_tail);
          v2109_8 = compose(v2109_5,v2110_7);
        }
        const Space v2109_9 = intersect(constant_6,v2109_2);
        const Space v2109_10 = (has_head(v2109_9) ? constant_7 : Space{});
        Space v2109_12;
        if (!v2109_10.empty()) {
          const Path v2111_6 = concat_path(v2108_6,v2108_7_head);
          const Space v2111_11 = routine_268(c, v2111_6, v2108_7_tail);
          v2109_12 = compose(v2109_10,v2111_11);
        }
        const Space v2109_13 = unite(v2109_8,v2109_12);
        v2108_7_result = unite(v2108_7_result,v2109_13);
      }
      const Space v2108_7 = std::move(v2108_7_result);
      v2107_8 = compose(v2107_5,v2108_7);
    }
    const Space v2107_9 = intersect(constant_6,v2107_2);
    const Space v2107_10 = (has_head(v2107_9) ? constant_7 : Space{});
    Space v2107_12;
    if (!v2107_10.empty()) {
      const Path v2112_6 = concat_path(p0,v2106_11_head);
      Space v2112_11_result;
      for (int v2112_11_label = 1; v2112_11_label <= 2; ++v2112_11_label) {
        const Space v2112_11_tail = child(v2106_11_tail,v2112_11_label);
        if (v2112_11_tail.empty()) continue;
        const Path v2112_11_head{v2112_11_label};
        const Space v2113_2 = singleton(v2112_11_head);
        const Space v2113_3 = intersect(constant_6,v2113_2);
        const Space v2113_4 = (has_head(v2113_3) ? constant_7 : Space{});
        const Space v2113_5 = subtract(constant_0,v2113_4);
        Space v2113_8;
        if (!v2113_5.empty()) {
          const Path v2114_6 = concat_path(v2112_6,v2112_11_head);
          const Space v2114_7 = routine_267(c, v2114_6, v2112_11_tail);
          v2113_8 = compose(v2113_5,v2114_7);
        }
        const Space v2113_9 = intersect(constant_6,v2113_2);
        const Space v2113_10 = (has_head(v2113_9) ? constant_7 : Space{});
        Space v2113_12;
        if (!v2113_10.empty()) {
          const Path v2115_6 = concat_path(v2112_6,v2112_11_head);
          const Space v2115_11 = routine_104(c, v2115_6, v2112_11_tail);
          v2113_12 = compose(v2113_10,v2115_11);
        }
        const Space v2113_13 = unite(v2113_8,v2113_12);
        v2112_11_result = unite(v2112_11_result,v2113_13);
      }
      const Space v2112_11 = std::move(v2112_11_result);
      v2107_12 = compose(v2107_10,v2112_11);
    }
    const Space v2107_13 = unite(v2107_8,v2107_12);
    v2106_11_result = unite(v2106_11_result,v2107_13);
  }
  const Space v2106_11 = std::move(v2106_11_result);
  return v2106_11;
}

static Space routine_242(Context& c, const Path& p0, const Space& s0) {
  Space v2116_9_result;
  for (int v2116_9_label = 1; v2116_9_label <= 2; ++v2116_9_label) {
    const Space v2116_9_tail = child(s0,v2116_9_label);
    if (v2116_9_tail.empty()) continue;
    const Path v2116_9_head{v2116_9_label};
    const Space v2117_2 = singleton(v2116_9_head);
    const Space v2117_3 = intersect(constant_6,v2117_2);
    const Space v2117_4 = (has_head(v2117_3) ? constant_7 : Space{});
    const Space v2117_5 = subtract(constant_0,v2117_4);
    Space v2117_8;
    if (!v2117_5.empty()) {
      const Path v2118_6 = concat_path(p0,v2116_9_head);
      Space v2118_7_result;
      for (int v2118_7_label = 1; v2118_7_label <= 2; ++v2118_7_label) {
        const Space v2118_7_tail = child(v2116_9_tail,v2118_7_label);
        if (v2118_7_tail.empty()) continue;
        const Path v2118_7_head{v2118_7_label};
        const Space v2119_2 = singleton(v2118_7_head);
        const Space v2119_3 = intersect(constant_6,v2119_2);
        const Space v2119_4 = (has_head(v2119_3) ? constant_7 : Space{});
        const Space v2119_5 = subtract(constant_0,v2119_4);
        Space v2119_8;
        if (!v2119_5.empty()) {
          const Path v2120_6 = concat_path(v2118_6,v2118_7_head);
          const Space v2120_7 = routine_267(c, v2120_6, v2118_7_tail);
          v2119_8 = compose(v2119_5,v2120_7);
        }
        const Space v2119_9 = intersect(constant_6,v2119_2);
        const Space v2119_10 = (has_head(v2119_9) ? constant_7 : Space{});
        Space v2119_12;
        if (!v2119_10.empty()) {
          const Path v2121_6 = concat_path(v2118_6,v2118_7_head);
          const Space v2121_11 = routine_268(c, v2121_6, v2118_7_tail);
          v2119_12 = compose(v2119_10,v2121_11);
        }
        const Space v2119_13 = unite(v2119_8,v2119_12);
        v2118_7_result = unite(v2118_7_result,v2119_13);
      }
      const Space v2118_7 = std::move(v2118_7_result);
      v2117_8 = compose(v2117_5,v2118_7);
    }
    const Space v2117_9 = intersect(constant_6,v2117_2);
    const Space v2117_10 = (has_head(v2117_9) ? constant_7 : Space{});
    const Space v2117_11 = compose(v2117_10,constant_9);
    const Space v2117_12 = unite(v2117_8,v2117_11);
    v2116_9_result = unite(v2116_9_result,v2117_12);
  }
  const Space v2116_9 = std::move(v2116_9_result);
  return v2116_9;
}

static Space routine_243(Context& c, const Path& p0, const Space& s0) {
  Space v2122_11_result;
  for (int v2122_11_label = 1; v2122_11_label <= 2; ++v2122_11_label) {
    const Space v2122_11_tail = child(s0,v2122_11_label);
    if (v2122_11_tail.empty()) continue;
    const Path v2122_11_head{v2122_11_label};
    const Space v2123_2 = singleton(v2122_11_head);
    const Space v2123_3 = intersect(constant_6,v2123_2);
    const Space v2123_4 = (has_head(v2123_3) ? constant_7 : Space{});
    const Space v2123_5 = subtract(constant_0,v2123_4);
    Space v2123_8;
    if (!v2123_5.empty()) {
      const Path v2124_6 = concat_path(p0,v2122_11_head);
      Space v2124_7_result;
      for (int v2124_7_label = 1; v2124_7_label <= 2; ++v2124_7_label) {
        const Space v2124_7_tail = child(v2122_11_tail,v2124_7_label);
        if (v2124_7_tail.empty()) continue;
        const Path v2124_7_head{v2124_7_label};
        const Space v2125_2 = singleton(v2124_7_head);
        const Space v2125_3 = intersect(constant_6,v2125_2);
        const Space v2125_4 = (has_head(v2125_3) ? constant_7 : Space{});
        const Space v2125_5 = subtract(constant_0,v2125_4);
        Space v2125_8;
        if (!v2125_5.empty()) {
          const Path v2126_6 = concat_path(v2124_6,v2124_7_head);
          const Space v2126_7 = routine_269(c, v2126_6, v2124_7_tail);
          v2125_8 = compose(v2125_5,v2126_7);
        }
        const Space v2125_9 = intersect(constant_6,v2125_2);
        const Space v2125_10 = (has_head(v2125_9) ? constant_7 : Space{});
        Space v2125_12;
        if (!v2125_10.empty()) {
          const Path v2127_6 = concat_path(v2124_6,v2124_7_head);
          const Space v2127_11 = routine_270(c, v2127_6, v2124_7_tail);
          v2125_12 = compose(v2125_10,v2127_11);
        }
        const Space v2125_13 = unite(v2125_8,v2125_12);
        v2124_7_result = unite(v2124_7_result,v2125_13);
      }
      const Space v2124_7 = std::move(v2124_7_result);
      v2123_8 = compose(v2123_5,v2124_7);
    }
    const Space v2123_9 = intersect(constant_6,v2123_2);
    const Space v2123_10 = (has_head(v2123_9) ? constant_7 : Space{});
    Space v2123_12;
    if (!v2123_10.empty()) {
      const Path v2128_6 = concat_path(p0,v2122_11_head);
      Space v2128_11_result;
      for (int v2128_11_label = 1; v2128_11_label <= 2; ++v2128_11_label) {
        const Space v2128_11_tail = child(v2122_11_tail,v2128_11_label);
        if (v2128_11_tail.empty()) continue;
        const Path v2128_11_head{v2128_11_label};
        const Space v2129_2 = singleton(v2128_11_head);
        const Space v2129_3 = intersect(constant_6,v2129_2);
        const Space v2129_4 = (has_head(v2129_3) ? constant_7 : Space{});
        const Space v2129_5 = subtract(constant_0,v2129_4);
        Space v2129_8;
        if (!v2129_5.empty()) {
          const Path v2130_6 = concat_path(v2128_6,v2128_11_head);
          const Space v2130_7 = routine_269(c, v2130_6, v2128_11_tail);
          v2129_8 = compose(v2129_5,v2130_7);
        }
        const Space v2129_9 = intersect(constant_6,v2129_2);
        const Space v2129_10 = (has_head(v2129_9) ? constant_7 : Space{});
        Space v2129_12;
        if (!v2129_10.empty()) {
          const Path v2131_6 = concat_path(v2128_6,v2128_11_head);
          const Space v2131_11 = routine_107(c, v2131_6, v2128_11_tail);
          v2129_12 = compose(v2129_10,v2131_11);
        }
        const Space v2129_13 = unite(v2129_8,v2129_12);
        v2128_11_result = unite(v2128_11_result,v2129_13);
      }
      const Space v2128_11 = std::move(v2128_11_result);
      v2123_12 = compose(v2123_10,v2128_11);
    }
    const Space v2123_13 = unite(v2123_8,v2123_12);
    v2122_11_result = unite(v2122_11_result,v2123_13);
  }
  const Space v2122_11 = std::move(v2122_11_result);
  return v2122_11;
}

static Space routine_244(Context& c, const Path& p0, const Space& s0) {
  Space v2132_8_result;
  for (int v2132_8_label = 1; v2132_8_label <= 2; ++v2132_8_label) {
    const Space v2132_8_tail = child(s0,v2132_8_label);
    if (v2132_8_tail.empty()) continue;
    const Path v2132_8_head{v2132_8_label};
    const Space v2133_2 = singleton(v2132_8_head);
    const Space v2133_3 = intersect(constant_6,v2133_2);
    const Space v2133_4 = (has_head(v2133_3) ? constant_7 : Space{});
    const Space v2133_5 = subtract(constant_0,v2133_4);
    Space v2133_8;
    if (!v2133_5.empty()) {
      const Path v2134_6 = concat_path(p0,v2132_8_head);
      Space v2134_7_result;
      for (int v2134_7_label = 1; v2134_7_label <= 2; ++v2134_7_label) {
        const Space v2134_7_tail = child(v2132_8_tail,v2134_7_label);
        if (v2134_7_tail.empty()) continue;
        const Path v2134_7_head{v2134_7_label};
        const Space v2135_2 = singleton(v2134_7_head);
        const Space v2135_3 = intersect(constant_6,v2135_2);
        const Space v2135_4 = (has_head(v2135_3) ? constant_7 : Space{});
        const Space v2135_5 = subtract(constant_0,v2135_4);
        Space v2135_8;
        if (!v2135_5.empty()) {
          const Path v2136_6 = concat_path(v2134_6,v2134_7_head);
          const Space v2136_7 = routine_269(c, v2136_6, v2134_7_tail);
          v2135_8 = compose(v2135_5,v2136_7);
        }
        const Space v2135_9 = intersect(constant_6,v2135_2);
        const Space v2135_10 = (has_head(v2135_9) ? constant_7 : Space{});
        Space v2135_12;
        if (!v2135_10.empty()) {
          const Path v2137_6 = concat_path(v2134_6,v2134_7_head);
          const Space v2137_11 = routine_270(c, v2137_6, v2134_7_tail);
          v2135_12 = compose(v2135_10,v2137_11);
        }
        const Space v2135_13 = unite(v2135_8,v2135_12);
        v2134_7_result = unite(v2134_7_result,v2135_13);
      }
      const Space v2134_7 = std::move(v2134_7_result);
      v2133_8 = compose(v2133_5,v2134_7);
    }
    const Space v2133_9 = intersect(constant_6,v2133_2);
    const Space v2133_10 = (has_head(v2133_9) ? constant_7 : Space{});
    const Space v2133_11 = compose(v2133_10,v2132_8_tail);
    const Space v2133_12 = unite(v2133_8,v2133_11);
    v2132_8_result = unite(v2132_8_result,v2133_12);
  }
  const Space v2132_8 = std::move(v2132_8_result);
  return v2132_8;
}

static Space routine_245(Context& c, const Path& p0, const Space& s0) {
  Space v2138_4_result;
  for (int v2138_4_label = 1; v2138_4_label <= 2; ++v2138_4_label) {
    const Space v2138_4_tail = child(s0,v2138_4_label);
    if (v2138_4_tail.empty()) continue;
    const Path v2138_4_head{v2138_4_label};
    const Space v2139_2 = singleton(v2138_4_head);
    const Space v2139_3 = intersect(constant_6,v2139_2);
    const Space v2139_4 = (has_head(v2139_3) ? constant_7 : Space{});
    Space v2139_7;
    if (!v2139_4.empty()) {
      const Path v2140_5 = concat_path(p0,v2138_4_head);
      Space v2140_6_result;
      for (int v2140_6_label = 1; v2140_6_label <= 2; ++v2140_6_label) {
        const Space v2140_6_tail = child(v2138_4_tail,v2140_6_label);
        if (v2140_6_tail.empty()) continue;
        const Path v2140_6_head{v2140_6_label};
        const Space v2141_2 = singleton(v2140_6_head);
        const Space v2141_3 = intersect(constant_6,v2141_2);
        const Space v2141_4 = (has_head(v2141_3) ? constant_7 : Space{});
        Space v2141_7;
        if (!v2141_4.empty()) {
          const Path v2142_5 = concat_path(v2140_5,v2140_6_head);
          const Space v2142_6 = routine_100(c, v2142_5, v2140_6_tail);
          v2141_7 = compose(v2141_4,v2142_6);
        }
        v2140_6_result = unite(v2140_6_result,v2141_7);
      }
      const Space v2140_6 = std::move(v2140_6_result);
      v2139_7 = compose(v2139_4,v2140_6);
    }
    v2138_4_result = unite(v2138_4_result,v2139_7);
  }
  const Space v2138_4 = std::move(v2138_4_result);
  return v2138_4;
}

static Space routine_246(Context& c, const Path& p0, const Space& s0) {
  Space v2143_4_result;
  for (int v2143_4_label = 1; v2143_4_label <= 2; ++v2143_4_label) {
    const Space v2143_4_tail = child(s0,v2143_4_label);
    if (v2143_4_tail.empty()) continue;
    const Path v2143_4_head{v2143_4_label};
    const Space v2144_2 = singleton(v2143_4_head);
    const Space v2144_3 = intersect(constant_6,v2144_2);
    const Space v2144_4 = (has_head(v2144_3) ? constant_7 : Space{});
    const Space v2144_5 = compose(v2144_4,constant_9);
    v2143_4_result = unite(v2143_4_result,v2144_5);
  }
  const Space v2143_4 = std::move(v2143_4_result);
  return v2143_4;
}

static Space routine_247(Context& c, const Path& p0, const Space& s0) {
  Space v2145_4_result;
  for (int v2145_4_label = 1; v2145_4_label <= 2; ++v2145_4_label) {
    const Space v2145_4_tail = child(s0,v2145_4_label);
    if (v2145_4_tail.empty()) continue;
    const Path v2145_4_head{v2145_4_label};
    const Space v2146_2 = singleton(v2145_4_head);
    const Space v2146_3 = intersect(constant_6,v2146_2);
    const Space v2146_4 = (has_head(v2146_3) ? constant_7 : Space{});
    Space v2146_7;
    if (!v2146_4.empty()) {
      const Path v2147_5 = concat_path(p0,v2145_4_head);
      Space v2147_6_result;
      for (int v2147_6_label = 1; v2147_6_label <= 2; ++v2147_6_label) {
        const Space v2147_6_tail = child(v2145_4_tail,v2147_6_label);
        if (v2147_6_tail.empty()) continue;
        const Path v2147_6_head{v2147_6_label};
        const Space v2148_2 = singleton(v2147_6_head);
        const Space v2148_3 = intersect(constant_6,v2148_2);
        const Space v2148_4 = (has_head(v2148_3) ? constant_7 : Space{});
        Space v2148_7;
        if (!v2148_4.empty()) {
          const Path v2149_5 = concat_path(v2147_5,v2147_6_head);
          const Space v2149_6 = routine_104(c, v2149_5, v2147_6_tail);
          v2148_7 = compose(v2148_4,v2149_6);
        }
        v2147_6_result = unite(v2147_6_result,v2148_7);
      }
      const Space v2147_6 = std::move(v2147_6_result);
      v2146_7 = compose(v2146_4,v2147_6);
    }
    v2145_4_result = unite(v2145_4_result,v2146_7);
  }
  const Space v2145_4 = std::move(v2145_4_result);
  return v2145_4;
}

static Space routine_248(Context& c, const Path& p0, const Space& s0) {
  Space v2150_4_result;
  for (int v2150_4_label = 1; v2150_4_label <= 2; ++v2150_4_label) {
    const Space v2150_4_tail = child(s0,v2150_4_label);
    if (v2150_4_tail.empty()) continue;
    const Path v2150_4_head{v2150_4_label};
    const Space v2151_2 = singleton(v2150_4_head);
    const Space v2151_3 = intersect(constant_6,v2151_2);
    const Space v2151_4 = (has_head(v2151_3) ? constant_7 : Space{});
    const Space v2151_5 = compose(v2151_4,constant_9);
    v2150_4_result = unite(v2150_4_result,v2151_5);
  }
  const Space v2150_4 = std::move(v2150_4_result);
  return v2150_4;
}

static Space routine_249(Context& c, const Path& p0, const Space& s0) {
  Space v2152_4_result;
  for (int v2152_4_label = 1; v2152_4_label <= 2; ++v2152_4_label) {
    const Space v2152_4_tail = child(s0,v2152_4_label);
    if (v2152_4_tail.empty()) continue;
    const Path v2152_4_head{v2152_4_label};
    const Space v2153_2 = singleton(v2152_4_head);
    const Space v2153_3 = intersect(constant_6,v2153_2);
    const Space v2153_4 = (has_head(v2153_3) ? constant_7 : Space{});
    Space v2153_7;
    if (!v2153_4.empty()) {
      const Path v2154_5 = concat_path(p0,v2152_4_head);
      Space v2154_6_result;
      for (int v2154_6_label = 1; v2154_6_label <= 2; ++v2154_6_label) {
        const Space v2154_6_tail = child(v2152_4_tail,v2154_6_label);
        if (v2154_6_tail.empty()) continue;
        const Path v2154_6_head{v2154_6_label};
        const Space v2155_2 = singleton(v2154_6_head);
        const Space v2155_3 = intersect(constant_6,v2155_2);
        const Space v2155_4 = (has_head(v2155_3) ? constant_7 : Space{});
        Space v2155_7;
        if (!v2155_4.empty()) {
          const Path v2156_5 = concat_path(v2154_5,v2154_6_head);
          const Space v2156_6 = routine_107(c, v2156_5, v2154_6_tail);
          v2155_7 = compose(v2155_4,v2156_6);
        }
        v2154_6_result = unite(v2154_6_result,v2155_7);
      }
      const Space v2154_6 = std::move(v2154_6_result);
      v2153_7 = compose(v2153_4,v2154_6);
    }
    v2152_4_result = unite(v2152_4_result,v2153_7);
  }
  const Space v2152_4 = std::move(v2152_4_result);
  return v2152_4;
}

static Space routine_250(Context& c, const Path& p0, const Space& s0) {
  Space v2157_3_result;
  for (int v2157_3_label = 1; v2157_3_label <= 2; ++v2157_3_label) {
    const Space v2157_3_tail = child(s0,v2157_3_label);
    if (v2157_3_tail.empty()) continue;
    const Path v2157_3_head{v2157_3_label};
    const Space v2158_2 = singleton(v2157_3_head);
    const Space v2158_3 = intersect(constant_6,v2158_2);
    const Space v2158_4 = (has_head(v2158_3) ? constant_7 : Space{});
    const Space v2158_5 = compose(v2158_4,v2157_3_tail);
    v2157_3_result = unite(v2157_3_result,v2158_5);
  }
  const Space v2157_3 = std::move(v2157_3_result);
  return v2157_3;
}

static Space routine_251(Context& c, const Path& p0, const Space& s0) {
  Space v2159_4_result;
  for (int v2159_4_label = 1; v2159_4_label <= 2; ++v2159_4_label) {
    const Space v2159_4_tail = child(s0,v2159_4_label);
    if (v2159_4_tail.empty()) continue;
    const Path v2159_4_head{v2159_4_label};
    const Space v2160_2 = singleton(v2159_4_head);
    const Space v2160_3 = intersect(constant_6,v2160_2);
    const Space v2160_4 = (has_head(v2160_3) ? constant_7 : Space{});
    Space v2160_7;
    if (!v2160_4.empty()) {
      const Path v2161_5 = concat_path(p0,v2159_4_head);
      Space v2161_6_result;
      for (int v2161_6_label = 1; v2161_6_label <= 2; ++v2161_6_label) {
        const Space v2161_6_tail = child(v2159_4_tail,v2161_6_label);
        if (v2161_6_tail.empty()) continue;
        const Path v2161_6_head{v2161_6_label};
        const Space v2162_2 = singleton(v2161_6_head);
        const Space v2162_3 = intersect(constant_6,v2162_2);
        const Space v2162_4 = (has_head(v2162_3) ? constant_7 : Space{});
        Space v2162_7;
        if (!v2162_4.empty()) {
          const Path v2163_5 = concat_path(v2161_5,v2161_6_head);
          const Space v2163_6 = routine_80(c, v2163_5, v2161_6_tail);
          v2162_7 = compose(v2162_4,v2163_6);
        }
        v2161_6_result = unite(v2161_6_result,v2162_7);
      }
      const Space v2161_6 = std::move(v2161_6_result);
      v2160_7 = compose(v2160_4,v2161_6);
    }
    v2159_4_result = unite(v2159_4_result,v2160_7);
  }
  const Space v2159_4 = std::move(v2159_4_result);
  return v2159_4;
}

static Space routine_252(Context& c, const Path& p0, const Space& s0) {
  Space v2164_6_result;
  for (int v2164_6_label = 1; v2164_6_label <= 2; ++v2164_6_label) {
    const Space v2164_6_tail = child(s0,v2164_6_label);
    if (v2164_6_tail.empty()) continue;
    const Path v2164_6_head{v2164_6_label};
    const Space v2165_2 = singleton(v2164_6_head);
    const Space v2165_3 = intersect(constant_6,v2165_2);
    const Space v2165_4 = (has_head(v2165_3) ? constant_7 : Space{});
    Space v2165_7;
    if (!v2165_4.empty()) {
      const Path v2166_5 = concat_path(p0,v2164_6_head);
      Space v2166_6_result;
      for (int v2166_6_label = 1; v2166_6_label <= 2; ++v2166_6_label) {
        const Space v2166_6_tail = child(v2164_6_tail,v2166_6_label);
        if (v2166_6_tail.empty()) continue;
        const Path v2166_6_head{v2166_6_label};
        const Space v2167_2 = singleton(v2166_6_head);
        const Space v2167_3 = intersect(constant_6,v2167_2);
        const Space v2167_4 = (has_head(v2167_3) ? constant_7 : Space{});
        const Space v2167_5 = subtract(constant_0,v2167_4);
        Space v2167_7;
        if (!v2167_5.empty()) {
          const Space v2168_6 = routine_122(c, v2166_6_head, v2166_5, v2166_6_tail);
          v2167_7 = compose(v2167_5,v2168_6);
        }
        const Space v2167_8 = intersect(constant_6,v2167_2);
        const Space v2167_9 = (has_head(v2167_8) ? constant_7 : Space{});
        Space v2167_11;
        if (!v2167_9.empty()) {
          const Space v2169_10 = routine_123(c, v2166_6_head, v2166_5, v2166_6_tail);
          v2167_11 = compose(v2167_9,v2169_10);
        }
        const Space v2167_12 = unite(v2167_7,v2167_11);
        v2166_6_result = unite(v2166_6_result,v2167_12);
      }
      const Space v2166_6 = std::move(v2166_6_result);
      v2165_7 = compose(v2165_4,v2166_6);
    }
    v2164_6_result = unite(v2164_6_result,v2165_7);
  }
  const Space v2164_6 = std::move(v2164_6_result);
  return v2164_6;
}

static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2170_12_result;
  for (int v2170_12_label = 1; v2170_12_label <= 2; ++v2170_12_label) {
    const Space v2170_12_tail = child(s0,v2170_12_label);
    if (v2170_12_tail.empty()) continue;
    const Path v2170_12_head{v2170_12_label};
    const Space v2171_2 = singleton(v2170_12_head);
    const Space v2171_3 = intersect(constant_6,v2171_2);
    const Space v2171_4 = (has_head(v2171_3) ? constant_7 : Space{});
    const Space v2171_5 = subtract(constant_0,v2171_4);
    Space v2171_8;
    if (!v2171_5.empty()) {
      const Path v2172_6 = concat_path(p0,v2170_12_head);
      Space v2172_7_result;
      for (int v2172_7_label = 1; v2172_7_label <= 2; ++v2172_7_label) {
        const Space v2172_7_tail = child(v2170_12_tail,v2172_7_label);
        if (v2172_7_tail.empty()) continue;
        const Path v2172_7_head{v2172_7_label};
        const Space v2173_2 = singleton(v2172_7_head);
        const Space v2173_3 = intersect(constant_6,v2173_2);
        const Space v2173_4 = (has_head(v2173_3) ? constant_7 : Space{});
        const Space v2173_5 = subtract(constant_0,v2173_4);
        Space v2173_8;
        if (!v2173_5.empty()) {
          const Path v2174_6 = concat_path(v2172_6,v2172_7_head);
          const Space v2174_7 = routine_271(c, v2174_6, p1, v2172_7_tail);
          v2173_8 = compose(v2173_5,v2174_7);
        }
        const Space v2173_9 = intersect(constant_6,v2173_2);
        const Space v2173_10 = (has_head(v2173_9) ? constant_7 : Space{});
        Space v2173_12;
        if (!v2173_10.empty()) {
          const Path v2175_6 = concat_path(v2172_6,v2172_7_head);
          const Space v2175_11 = routine_272(c, v2175_6, p1, v2172_7_tail);
          v2173_12 = compose(v2173_10,v2175_11);
        }
        const Space v2173_13 = unite(v2173_8,v2173_12);
        v2172_7_result = unite(v2172_7_result,v2173_13);
      }
      const Space v2172_7 = std::move(v2172_7_result);
      v2171_8 = compose(v2171_5,v2172_7);
    }
    const Space v2171_9 = intersect(constant_6,v2171_2);
    const Space v2171_10 = (has_head(v2171_9) ? constant_7 : Space{});
    Space v2171_12;
    if (!v2171_10.empty()) {
      const Path v2176_6 = concat_path(p0,v2170_12_head);
      Space v2176_11_result;
      for (int v2176_11_label = 1; v2176_11_label <= 2; ++v2176_11_label) {
        const Space v2176_11_tail = child(v2170_12_tail,v2176_11_label);
        if (v2176_11_tail.empty()) continue;
        const Path v2176_11_head{v2176_11_label};
        const Space v2177_2 = singleton(v2176_11_head);
        const Space v2177_3 = intersect(constant_6,v2177_2);
        const Space v2177_4 = (has_head(v2177_3) ? constant_7 : Space{});
        const Space v2177_5 = subtract(constant_0,v2177_4);
        Space v2177_8;
        if (!v2177_5.empty()) {
          const Path v2178_6 = concat_path(v2176_6,v2176_11_head);
          const Space v2178_7 = routine_271(c, v2178_6, p1, v2176_11_tail);
          v2177_8 = compose(v2177_5,v2178_7);
        }
        const Space v2177_9 = intersect(constant_6,v2177_2);
        const Space v2177_10 = (has_head(v2177_9) ? constant_7 : Space{});
        Space v2177_12;
        if (!v2177_10.empty()) {
          const Path v2179_6 = concat_path(v2176_6,v2176_11_head);
          const Space v2179_11 = routine_137(c, v2179_6, p1, v2176_11_tail);
          v2177_12 = compose(v2177_10,v2179_11);
        }
        const Space v2177_13 = unite(v2177_8,v2177_12);
        v2176_11_result = unite(v2176_11_result,v2177_13);
      }
      const Space v2176_11 = std::move(v2176_11_result);
      v2171_12 = compose(v2171_10,v2176_11);
    }
    const Space v2171_13 = unite(v2171_8,v2171_12);
    v2170_12_result = unite(v2170_12_result,v2171_13);
  }
  const Space v2170_12 = std::move(v2170_12_result);
  return v2170_12;
}

static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2180_7 = unwrap(constant_12,p1);
  const Space v2180_9 = unwrap(constant_12,p0);
  Space v2180_13_result;
  for (int v2180_13_label = 1; v2180_13_label <= 2; ++v2180_13_label) {
    const Space v2180_13_tail = child(s0,v2180_13_label);
    if (v2180_13_tail.empty()) continue;
    const Path v2180_13_head{v2180_13_label};
    const Space v2181_2 = singleton(v2180_13_head);
    const Space v2181_3 = intersect(constant_6,v2181_2);
    const Space v2181_4 = (has_head(v2181_3) ? constant_7 : Space{});
    const Space v2181_5 = subtract(constant_0,v2181_4);
    Space v2181_8;
    if (!v2181_5.empty()) {
      const Path v2182_6 = concat_path(p0,v2180_13_head);
      Space v2182_7_result;
      for (int v2182_7_label = 1; v2182_7_label <= 2; ++v2182_7_label) {
        const Space v2182_7_tail = child(v2180_13_tail,v2182_7_label);
        if (v2182_7_tail.empty()) continue;
        const Path v2182_7_head{v2182_7_label};
        const Space v2183_2 = singleton(v2182_7_head);
        const Space v2183_3 = intersect(constant_6,v2183_2);
        const Space v2183_4 = (has_head(v2183_3) ? constant_7 : Space{});
        const Space v2183_5 = subtract(constant_0,v2183_4);
        Space v2183_8;
        if (!v2183_5.empty()) {
          const Path v2184_6 = concat_path(v2182_6,v2182_7_head);
          const Space v2184_7 = routine_271(c, v2184_6, p1, v2182_7_tail);
          v2183_8 = compose(v2183_5,v2184_7);
        }
        const Space v2183_9 = intersect(constant_6,v2183_2);
        const Space v2183_10 = (has_head(v2183_9) ? constant_7 : Space{});
        Space v2183_12;
        if (!v2183_10.empty()) {
          const Path v2185_6 = concat_path(v2182_6,v2182_7_head);
          const Space v2185_11 = routine_272(c, v2185_6, p1, v2182_7_tail);
          v2183_12 = compose(v2183_10,v2185_11);
        }
        const Space v2183_13 = unite(v2183_8,v2183_12);
        v2182_7_result = unite(v2182_7_result,v2183_13);
      }
      const Space v2182_7 = std::move(v2182_7_result);
      v2181_8 = compose(v2181_5,v2182_7);
    }
    const Space v2181_9 = intersect(constant_6,v2181_2);
    const Space v2181_10 = (has_head(v2181_9) ? constant_7 : Space{});
    const Space v2181_11 = unwrap(v2180_9,v2180_13_head);
    const Space v2181_12 = compose(v2180_7,v2181_11);
    const Path v2186_6 = concat_path(p0,v2180_13_head);
    const Path v2181_13 = concat_path(p1,v2186_6);
    const Space v2181_14 = singleton(v2181_13);
    const Space v2181_15 = subtract(v2181_12,v2181_14);
    const Space v2181_16 = compose(v2181_10,v2181_15);
    const Space v2181_17 = unite(v2181_8,v2181_16);
    v2180_13_result = unite(v2180_13_result,v2181_17);
  }
  const Space v2180_13 = std::move(v2180_13_result);
  return v2180_13;
}

static Space routine_255(Context& c, const Path& p0, const Space& s0) {
  const Space v2187_2 = Space{};
  return v2187_2;
}

static Space routine_256(Context& c, const Path& p0, const Space& s0) {
  Space v2188_4_result;
  for (int v2188_4_label = 1; v2188_4_label <= 2; ++v2188_4_label) {
    const Space v2188_4_tail = child(s0,v2188_4_label);
    if (v2188_4_tail.empty()) continue;
    const Path v2188_4_head{v2188_4_label};
    const Space v2189_2 = singleton(v2188_4_head);
    const Space v2189_3 = intersect(constant_6,v2189_2);
    const Space v2189_4 = (has_head(v2189_3) ? constant_7 : Space{});
    const Space v2189_5 = compose(v2189_4,constant_9);
    v2188_4_result = unite(v2188_4_result,v2189_5);
  }
  const Space v2188_4 = std::move(v2188_4_result);
  return v2188_4;
}

static Space routine_257(Context& c, const Path& p0, const Space& s0) {
  const Space v2190_2 = Space{};
  return v2190_2;
}

static Space routine_258(Context& c, const Path& p0, const Space& s0) {
  Space v2191_4_result;
  for (int v2191_4_label = 1; v2191_4_label <= 2; ++v2191_4_label) {
    const Space v2191_4_tail = child(s0,v2191_4_label);
    if (v2191_4_tail.empty()) continue;
    const Path v2191_4_head{v2191_4_label};
    const Space v2192_2 = singleton(v2191_4_head);
    const Space v2192_3 = intersect(constant_6,v2192_2);
    const Space v2192_4 = (has_head(v2192_3) ? constant_7 : Space{});
    const Space v2192_5 = compose(v2192_4,constant_9);
    v2191_4_result = unite(v2191_4_result,v2192_5);
  }
  const Space v2191_4 = std::move(v2191_4_result);
  return v2191_4;
}

static Space routine_259(Context& c, const Path& p0, const Space& s0) {
  const Space v2193_2 = Space{};
  return v2193_2;
}

static Space routine_260(Context& c, const Path& p0, const Space& s0) {
  Space v2194_3_result;
  for (int v2194_3_label = 1; v2194_3_label <= 2; ++v2194_3_label) {
    const Space v2194_3_tail = child(s0,v2194_3_label);
    if (v2194_3_tail.empty()) continue;
    const Path v2194_3_head{v2194_3_label};
    const Space v2195_2 = singleton(v2194_3_head);
    const Space v2195_3 = intersect(constant_6,v2195_2);
    const Space v2195_4 = (has_head(v2195_3) ? constant_7 : Space{});
    const Space v2195_5 = compose(v2195_4,v2194_3_tail);
    v2194_3_result = unite(v2194_3_result,v2195_5);
  }
  const Space v2194_3 = std::move(v2194_3_result);
  return v2194_3;
}

static Space routine_261(Context& c, const Path& p0, const Space& s0) {
  const Space v2196_2 = Space{};
  return v2196_2;
}

static Space routine_262(Context& c, const Path& p0, const Space& s0) {
  Space v2197_6_result;
  for (int v2197_6_label = 1; v2197_6_label <= 2; ++v2197_6_label) {
    const Space v2197_6_tail = child(s0,v2197_6_label);
    if (v2197_6_tail.empty()) continue;
    const Path v2197_6_head{v2197_6_label};
    const Space v2198_2 = singleton(v2197_6_head);
    const Space v2198_3 = intersect(constant_6,v2198_2);
    const Space v2198_4 = (has_head(v2198_3) ? constant_7 : Space{});
    Space v2198_7;
    if (!v2198_4.empty()) {
      const Path v2199_5 = concat_path(p0,v2197_6_head);
      Space v2199_6_result;
      for (int v2199_6_label = 1; v2199_6_label <= 2; ++v2199_6_label) {
        const Space v2199_6_tail = child(v2197_6_tail,v2199_6_label);
        if (v2199_6_tail.empty()) continue;
        const Path v2199_6_head{v2199_6_label};
        const Space v2200_2 = singleton(v2199_6_head);
        const Space v2200_3 = intersect(constant_6,v2200_2);
        const Space v2200_4 = (has_head(v2200_3) ? constant_7 : Space{});
        const Space v2200_5 = subtract(constant_0,v2200_4);
        Space v2200_7;
        if (!v2200_5.empty()) {
          const Space v2201_6 = routine_122(c, v2199_6_head, v2199_5, v2199_6_tail);
          v2200_7 = compose(v2200_5,v2201_6);
        }
        const Space v2200_8 = intersect(constant_6,v2200_2);
        const Space v2200_9 = (has_head(v2200_8) ? constant_7 : Space{});
        Space v2200_11;
        if (!v2200_9.empty()) {
          const Space v2202_10 = routine_123(c, v2199_6_head, v2199_5, v2199_6_tail);
          v2200_11 = compose(v2200_9,v2202_10);
        }
        const Space v2200_12 = unite(v2200_7,v2200_11);
        v2199_6_result = unite(v2199_6_result,v2200_12);
      }
      const Space v2199_6 = std::move(v2199_6_result);
      v2198_7 = compose(v2198_4,v2199_6);
    }
    v2197_6_result = unite(v2197_6_result,v2198_7);
  }
  const Space v2197_6 = std::move(v2197_6_result);
  return v2197_6;
}

static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2203_12_result;
  for (int v2203_12_label = 1; v2203_12_label <= 2; ++v2203_12_label) {
    const Space v2203_12_tail = child(s0,v2203_12_label);
    if (v2203_12_tail.empty()) continue;
    const Path v2203_12_head{v2203_12_label};
    const Space v2204_2 = singleton(v2203_12_head);
    const Space v2204_3 = intersect(constant_6,v2204_2);
    const Space v2204_4 = (has_head(v2204_3) ? constant_7 : Space{});
    const Space v2204_5 = subtract(constant_0,v2204_4);
    Space v2204_8;
    if (!v2204_5.empty()) {
      const Path v2205_6 = concat_path(p0,v2203_12_head);
      Space v2205_7_result;
      for (int v2205_7_label = 1; v2205_7_label <= 2; ++v2205_7_label) {
        const Space v2205_7_tail = child(v2203_12_tail,v2205_7_label);
        if (v2205_7_tail.empty()) continue;
        const Path v2205_7_head{v2205_7_label};
        const Space v2206_2 = singleton(v2205_7_head);
        const Space v2206_3 = intersect(constant_6,v2206_2);
        const Space v2206_4 = (has_head(v2206_3) ? constant_7 : Space{});
        const Space v2206_5 = subtract(constant_0,v2206_4);
        Space v2206_8;
        if (!v2206_5.empty()) {
          const Path v2207_6 = concat_path(v2205_6,v2205_7_head);
          const Space v2207_7 = routine_273(c, v2207_6, p1, v2205_7_tail);
          v2206_8 = compose(v2206_5,v2207_7);
        }
        const Space v2206_9 = intersect(constant_6,v2206_2);
        const Space v2206_10 = (has_head(v2206_9) ? constant_7 : Space{});
        Space v2206_12;
        if (!v2206_10.empty()) {
          const Path v2208_6 = concat_path(v2205_6,v2205_7_head);
          const Space v2208_11 = routine_274(c, v2208_6, p1, v2205_7_tail);
          v2206_12 = compose(v2206_10,v2208_11);
        }
        const Space v2206_13 = unite(v2206_8,v2206_12);
        v2205_7_result = unite(v2205_7_result,v2206_13);
      }
      const Space v2205_7 = std::move(v2205_7_result);
      v2204_8 = compose(v2204_5,v2205_7);
    }
    const Space v2204_9 = intersect(constant_6,v2204_2);
    const Space v2204_10 = (has_head(v2204_9) ? constant_7 : Space{});
    Space v2204_12;
    if (!v2204_10.empty()) {
      const Path v2209_6 = concat_path(p0,v2203_12_head);
      Space v2209_11_result;
      for (int v2209_11_label = 1; v2209_11_label <= 2; ++v2209_11_label) {
        const Space v2209_11_tail = child(v2203_12_tail,v2209_11_label);
        if (v2209_11_tail.empty()) continue;
        const Path v2209_11_head{v2209_11_label};
        const Space v2210_2 = singleton(v2209_11_head);
        const Space v2210_3 = intersect(constant_6,v2210_2);
        const Space v2210_4 = (has_head(v2210_3) ? constant_7 : Space{});
        const Space v2210_5 = subtract(constant_0,v2210_4);
        Space v2210_8;
        if (!v2210_5.empty()) {
          const Path v2211_6 = concat_path(v2209_6,v2209_11_head);
          const Space v2211_7 = routine_273(c, v2211_6, p1, v2209_11_tail);
          v2210_8 = compose(v2210_5,v2211_7);
        }
        const Space v2210_9 = intersect(constant_6,v2210_2);
        const Space v2210_10 = (has_head(v2210_9) ? constant_7 : Space{});
        Space v2210_12;
        if (!v2210_10.empty()) {
          const Path v2212_6 = concat_path(v2209_6,v2209_11_head);
          const Space v2212_11 = routine_137(c, v2212_6, p1, v2209_11_tail);
          v2210_12 = compose(v2210_10,v2212_11);
        }
        const Space v2210_13 = unite(v2210_8,v2210_12);
        v2209_11_result = unite(v2209_11_result,v2210_13);
      }
      const Space v2209_11 = std::move(v2209_11_result);
      v2204_12 = compose(v2204_10,v2209_11);
    }
    const Space v2204_13 = unite(v2204_8,v2204_12);
    v2203_12_result = unite(v2203_12_result,v2204_13);
  }
  const Space v2203_12 = std::move(v2203_12_result);
  return v2203_12;
}

static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2213_7 = unwrap(constant_12,p1);
  const Space v2213_9 = unwrap(constant_12,p0);
  Space v2213_13_result;
  for (int v2213_13_label = 1; v2213_13_label <= 2; ++v2213_13_label) {
    const Space v2213_13_tail = child(s0,v2213_13_label);
    if (v2213_13_tail.empty()) continue;
    const Path v2213_13_head{v2213_13_label};
    const Space v2214_2 = singleton(v2213_13_head);
    const Space v2214_3 = intersect(constant_6,v2214_2);
    const Space v2214_4 = (has_head(v2214_3) ? constant_7 : Space{});
    const Space v2214_5 = subtract(constant_0,v2214_4);
    Space v2214_8;
    if (!v2214_5.empty()) {
      const Path v2215_6 = concat_path(p0,v2213_13_head);
      Space v2215_7_result;
      for (int v2215_7_label = 1; v2215_7_label <= 2; ++v2215_7_label) {
        const Space v2215_7_tail = child(v2213_13_tail,v2215_7_label);
        if (v2215_7_tail.empty()) continue;
        const Path v2215_7_head{v2215_7_label};
        const Space v2216_2 = singleton(v2215_7_head);
        const Space v2216_3 = intersect(constant_6,v2216_2);
        const Space v2216_4 = (has_head(v2216_3) ? constant_7 : Space{});
        const Space v2216_5 = subtract(constant_0,v2216_4);
        Space v2216_8;
        if (!v2216_5.empty()) {
          const Path v2217_6 = concat_path(v2215_6,v2215_7_head);
          const Space v2217_7 = routine_273(c, v2217_6, p1, v2215_7_tail);
          v2216_8 = compose(v2216_5,v2217_7);
        }
        const Space v2216_9 = intersect(constant_6,v2216_2);
        const Space v2216_10 = (has_head(v2216_9) ? constant_7 : Space{});
        Space v2216_12;
        if (!v2216_10.empty()) {
          const Path v2218_6 = concat_path(v2215_6,v2215_7_head);
          const Space v2218_11 = routine_274(c, v2218_6, p1, v2215_7_tail);
          v2216_12 = compose(v2216_10,v2218_11);
        }
        const Space v2216_13 = unite(v2216_8,v2216_12);
        v2215_7_result = unite(v2215_7_result,v2216_13);
      }
      const Space v2215_7 = std::move(v2215_7_result);
      v2214_8 = compose(v2214_5,v2215_7);
    }
    const Space v2214_9 = intersect(constant_6,v2214_2);
    const Space v2214_10 = (has_head(v2214_9) ? constant_7 : Space{});
    const Space v2214_11 = unwrap(v2213_9,v2213_13_head);
    const Space v2214_12 = compose(v2213_7,v2214_11);
    const Path v2219_6 = concat_path(p0,v2213_13_head);
    const Path v2214_13 = concat_path(p1,v2219_6);
    const Space v2214_14 = singleton(v2214_13);
    const Space v2214_15 = subtract(v2214_12,v2214_14);
    const Space v2214_16 = compose(v2214_10,v2214_15);
    const Space v2214_17 = unite(v2214_8,v2214_16);
    v2213_13_result = unite(v2213_13_result,v2214_17);
  }
  const Space v2213_13 = std::move(v2213_13_result);
  return v2213_13;
}

static Space routine_265(Context& c, const Path& p0, const Space& s0) {
  const Space v2220_2 = Space{};
  return v2220_2;
}

static Space routine_266(Context& c, const Path& p0, const Space& s0) {
  Space v2221_4_result;
  for (int v2221_4_label = 1; v2221_4_label <= 2; ++v2221_4_label) {
    const Space v2221_4_tail = child(s0,v2221_4_label);
    if (v2221_4_tail.empty()) continue;
    const Path v2221_4_head{v2221_4_label};
    const Space v2222_2 = singleton(v2221_4_head);
    const Space v2222_3 = intersect(constant_6,v2222_2);
    const Space v2222_4 = (has_head(v2222_3) ? constant_7 : Space{});
    const Space v2222_5 = compose(v2222_4,constant_9);
    v2221_4_result = unite(v2221_4_result,v2222_5);
  }
  const Space v2221_4 = std::move(v2221_4_result);
  return v2221_4;
}

static Space routine_267(Context& c, const Path& p0, const Space& s0) {
  const Space v2223_2 = Space{};
  return v2223_2;
}

static Space routine_268(Context& c, const Path& p0, const Space& s0) {
  Space v2224_4_result;
  for (int v2224_4_label = 1; v2224_4_label <= 2; ++v2224_4_label) {
    const Space v2224_4_tail = child(s0,v2224_4_label);
    if (v2224_4_tail.empty()) continue;
    const Path v2224_4_head{v2224_4_label};
    const Space v2225_2 = singleton(v2224_4_head);
    const Space v2225_3 = intersect(constant_6,v2225_2);
    const Space v2225_4 = (has_head(v2225_3) ? constant_7 : Space{});
    const Space v2225_5 = compose(v2225_4,constant_9);
    v2224_4_result = unite(v2224_4_result,v2225_5);
  }
  const Space v2224_4 = std::move(v2224_4_result);
  return v2224_4;
}

static Space routine_269(Context& c, const Path& p0, const Space& s0) {
  const Space v2226_2 = Space{};
  return v2226_2;
}

static Space routine_270(Context& c, const Path& p0, const Space& s0) {
  Space v2227_3_result;
  for (int v2227_3_label = 1; v2227_3_label <= 2; ++v2227_3_label) {
    const Space v2227_3_tail = child(s0,v2227_3_label);
    if (v2227_3_tail.empty()) continue;
    const Path v2227_3_head{v2227_3_label};
    const Space v2228_2 = singleton(v2227_3_head);
    const Space v2228_3 = intersect(constant_6,v2228_2);
    const Space v2228_4 = (has_head(v2228_3) ? constant_7 : Space{});
    const Space v2228_5 = compose(v2228_4,v2227_3_tail);
    v2227_3_result = unite(v2227_3_result,v2228_5);
  }
  const Space v2227_3 = std::move(v2227_3_result);
  return v2227_3;
}

static Space routine_271(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2229_5_result;
  for (int v2229_5_label = 1; v2229_5_label <= 2; ++v2229_5_label) {
    const Space v2229_5_tail = child(s0,v2229_5_label);
    if (v2229_5_tail.empty()) continue;
    const Path v2229_5_head{v2229_5_label};
    const Space v2230_2 = singleton(v2229_5_head);
    const Space v2230_3 = intersect(constant_6,v2230_2);
    const Space v2230_4 = (has_head(v2230_3) ? constant_7 : Space{});
    Space v2230_7;
    if (!v2230_4.empty()) {
      const Path v2231_5 = concat_path(p0,v2229_5_head);
      Space v2231_6_result;
      for (int v2231_6_label = 1; v2231_6_label <= 2; ++v2231_6_label) {
        const Space v2231_6_tail = child(v2229_5_tail,v2231_6_label);
        if (v2231_6_tail.empty()) continue;
        const Path v2231_6_head{v2231_6_label};
        const Space v2232_2 = singleton(v2231_6_head);
        const Space v2232_3 = intersect(constant_6,v2232_2);
        const Space v2232_4 = (has_head(v2232_3) ? constant_7 : Space{});
        Space v2232_7;
        if (!v2232_4.empty()) {
          const Path v2233_5 = concat_path(v2231_5,v2231_6_head);
          const Space v2233_6 = routine_137(c, v2233_5, p1, v2231_6_tail);
          v2232_7 = compose(v2232_4,v2233_6);
        }
        v2231_6_result = unite(v2231_6_result,v2232_7);
      }
      const Space v2231_6 = std::move(v2231_6_result);
      v2230_7 = compose(v2230_4,v2231_6);
    }
    v2229_5_result = unite(v2229_5_result,v2230_7);
  }
  const Space v2229_5 = std::move(v2229_5_result);
  return v2229_5;
}

static Space routine_272(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2234_5 = unwrap(constant_12,p1);
  const Space v2234_7 = unwrap(constant_12,p0);
  Space v2234_8_result;
  for (int v2234_8_label = 1; v2234_8_label <= 2; ++v2234_8_label) {
    const Space v2234_8_tail = child(s0,v2234_8_label);
    if (v2234_8_tail.empty()) continue;
    const Path v2234_8_head{v2234_8_label};
    const Space v2235_2 = singleton(v2234_8_head);
    const Space v2235_3 = intersect(constant_6,v2235_2);
    const Space v2235_4 = (has_head(v2235_3) ? constant_7 : Space{});
    const Space v2235_5 = unwrap(v2234_7,v2234_8_head);
    const Space v2235_6 = compose(v2234_5,v2235_5);
    const Path v2235_7 = concat_path(p0,v2234_8_head);
    const Path v2235_8 = concat_path(p1,v2235_7);
    const Space v2235_9 = singleton(v2235_8);
    const Space v2235_10 = subtract(v2235_6,v2235_9);
    const Space v2235_11 = compose(v2235_4,v2235_10);
    v2234_8_result = unite(v2234_8_result,v2235_11);
  }
  const Space v2234_8 = std::move(v2234_8_result);
  return v2234_8;
}

static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2236_3 = Space{};
  return v2236_3;
}

static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2237_5 = unwrap(constant_12,p1);
  const Space v2237_7 = unwrap(constant_12,p0);
  Space v2237_8_result;
  for (int v2237_8_label = 1; v2237_8_label <= 2; ++v2237_8_label) {
    const Space v2237_8_tail = child(s0,v2237_8_label);
    if (v2237_8_tail.empty()) continue;
    const Path v2237_8_head{v2237_8_label};
    const Space v2238_2 = singleton(v2237_8_head);
    const Space v2238_3 = intersect(constant_6,v2238_2);
    const Space v2238_4 = (has_head(v2238_3) ? constant_7 : Space{});
    const Space v2238_5 = unwrap(v2237_7,v2237_8_head);
    const Space v2238_6 = compose(v2237_5,v2238_5);
    const Path v2238_7 = concat_path(p0,v2237_8_head);
    const Path v2238_8 = concat_path(p1,v2238_7);
    const Space v2238_9 = singleton(v2238_8);
    const Space v2238_10 = subtract(v2238_6,v2238_9);
    const Space v2238_11 = compose(v2238_4,v2238_10);
    v2237_8_result = unite(v2237_8_result,v2238_11);
  }
  const Space v2237_8 = std::move(v2237_8_result);
  return v2237_8;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
