#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1};
static const Path constant_1 = Path{2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  const auto v0_3_branches = branches(c,v0_2);
  std::vector<Space> v0_3_outputs;
  v0_3_outputs.reserve(v0_3_branches.size());
  for (const auto& v0_3_branch : v0_3_branches) {
    const Path v0_3_head{v0_3_branch.first};
    const Space& v0_3_tail = v0_3_branch.second;
    const auto v1_2_branches = branches(c,v0_3_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Space v2_2 = unwrap(v0_2,v1_2_head);
      const Space v2_3 = unwrap(v2_2,v0_3_head);
      const Space v2_4 = wrap(v2_3,v1_2_head);
      v1_2_outputs.push_back(v2_4);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    const Space v1_3 = wrap(v1_2,v0_3_head);
    v0_3_outputs.push_back(v1_3);
  }
  const Space v0_3 = join_outputs(std::move(v0_3_outputs));
  const Space v0_5 = wrap(v0_3,constant_1);
  return v0_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"2 1 4 101 100 103 101 2 6 77 117 116 117 97 108"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
