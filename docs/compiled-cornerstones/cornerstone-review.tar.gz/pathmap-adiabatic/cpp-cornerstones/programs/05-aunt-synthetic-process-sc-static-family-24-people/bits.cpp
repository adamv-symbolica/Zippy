#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{2,1,2,1,1,1,2,2};
static const Space constant_4 = literal_text("36 15 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 2 1 2 2 13 1 1 1 1 2 2 1 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 1 1 2 2 15 1 1 1 2 1 2 2 1 1 2 1 1 1 2 2 15 1 1 1 2 1 2 2 1 2 1 1 1 1 2 2 11 1 1 1 2 2 1 1 2 1 2 2 11 1 1 1 2 2 1 2 1 1 2 2 15 1 1 2 1 1 2 2 1 1 1 1 1 1 2 2 15 1 1 2 1 1 2 2 2 1 1 1 1 1 2 2 13 1 1 2 1 2 2 1 1 2 1 1 2 2 13 1 1 2 1 2 2 2 1 2 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 10 1 1 2 2 2 1 1 1 2 2 15 1 2 1 1 1 2 2 1 1 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 2 1 2 2 13 1 2 1 1 2 2 1 1 2 1 1 2 2 13 1 2 1 1 2 2 1 2 1 1 1 2 2 12 1 2 1 2 2 1 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 9 1 2 2 1 1 1 1 2 2 8 1 2 2 1 2 1 2 2 14 2 1 1 1 1 2 2 1 2 1 2 1 2 2 14 2 1 1 1 1 2 2 2 1 1 2 1 2 2 13 2 1 1 1 2 2 1 2 1 1 1 2 2 13 2 1 1 1 2 2 2 1 1 1 1 2 2 11 2 1 1 2 2 1 1 2 1 2 2 11 2 1 1 2 2 2 1 2 1 2 2 15 2 1 2 1 1 2 2 1 2 1 1 1 1 2 2 15 2 1 2 1 1 2 2 2 1 1 1 1 1 2 2 13 2 1 2 1 2 2 1 1 1 2 1 2 2 13 2 1 2 1 2 2 2 1 2 1 1 2 2 10 2 1 2 2 1 2 1 1 2 2 10 2 1 2 2 2 1 1 1 2 2 7 2 2 1 2 1 2 2 8 2 2 2 1 2 1 2 2");
static const Space constant_5 = literal_text("36 15 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 15 1 1 1 1 1 1 2 2 1 2 1 1 1 2 2 13 1 1 1 1 1 2 2 1 1 1 1 2 2 12 1 1 1 1 1 2 2 1 2 1 2 2 10 1 1 1 1 2 2 1 1 2 2 9 1 1 1 1 2 2 1 2 2 12 1 1 1 2 1 2 2 1 2 1 2 2 13 1 1 1 2 1 2 2 2 1 2 1 2 2 15 1 1 2 1 1 1 2 2 1 1 1 1 1 2 2 15 1 1 2 1 1 1 2 2 1 1 1 2 1 2 2 13 1 1 2 1 1 2 2 1 1 2 1 2 2 13 1 1 2 1 1 2 2 1 2 1 1 2 2 11 1 1 2 1 2 2 1 1 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 15 1 2 1 1 1 1 2 2 1 1 1 2 1 2 2 15 1 2 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 2 1 1 1 2 2 1 2 1 1 2 2 13 1 2 1 1 1 2 2 2 1 1 1 2 2 11 1 2 1 1 2 2 1 1 1 2 2 10 1 2 1 1 2 2 2 1 2 2 14 1 2 1 2 1 2 2 1 2 1 1 1 2 2 14 1 2 1 2 1 2 2 2 1 1 1 1 2 2 8 1 2 1 2 2 1 2 2 7 1 2 1 2 2 2 2 15 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 15 2 1 1 1 1 1 2 2 2 1 2 1 1 2 2 13 2 1 1 1 1 2 2 1 1 1 1 2 2 13 2 1 1 1 1 2 2 2 1 1 1 2 2 10 2 1 1 1 2 2 1 1 2 2 10 2 1 1 1 2 2 2 1 2 2 14 2 1 1 2 1 2 2 1 1 1 1 1 2 2 14 2 1 1 2 1 2 2 2 1 1 1 1 2 2 13 2 1 2 1 1 2 2 1 1 2 1 2 2 13 2 1 2 1 1 2 2 2 1 2 1 2 2 11 2 1 2 1 2 2 2 1 1 2 2 8 2 1 2 1 2 2 2 2");
static const Space constant_6 = literal_text("12 8 1 1 1 1 1 1 2 2 7 1 1 1 1 1 2 2 5 1 1 1 2 2 6 1 1 2 1 2 2 4 1 1 2 2 8 1 2 1 1 1 1 2 2 7 1 2 1 1 1 2 2 5 1 2 1 2 2 6 2 1 1 1 2 2 7 2 1 1 2 1 2 2 7 2 1 2 1 1 2 2 2 2 2");
static Space routine_0(Context& c, const Space* s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  Space v0_4_result;
  for (int v0_4_label = 1; v0_4_label <= 2; ++v0_4_label) {
    const Space v0_4_tail = child(bound_space(s0),v0_4_label);
    if (v0_4_tail.empty()) continue;
    const Path v0_4_head{v0_4_label};
    const Space v1_2 = singleton(v0_4_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_4_head, v0_4_tail);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_4_head, v0_4_tail);
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_4_result = unite(v0_4_result,v1_12);
  }
  const Space v0_4 = std::move(v0_4_result);
  const Space v0_6 = wrap(v0_4,constant_3);
  return v0_6;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v4_11_result;
  for (int v4_11_label = 1; v4_11_label <= 2; ++v4_11_label) {
    const Space v4_11_tail = child(s0,v4_11_label);
    if (v4_11_tail.empty()) continue;
    const Path v4_11_head{v4_11_label};
    const Space v5_2 = singleton(v4_11_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_11_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_11_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_11_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_11_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_11_result = unite(v4_11_result,v5_13);
  }
  const Space v4_11 = std::move(v4_11_result);
  return v4_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  const Space v14_8 = unwrap(constant_5,p0);
  const Space v14_10 = unwrap(constant_5,p0);
  Space v14_21_result;
  for (int v14_21_label = 1; v14_21_label <= 2; ++v14_21_label) {
    const Space v14_21_tail = child(s0,v14_21_label);
    if (v14_21_tail.empty()) continue;
    const Path v14_21_head{v14_21_label};
    const Space v15_2 = singleton(v14_21_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_21_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_21_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_19;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_8,v14_21_head);
      const Space v20_12 = restrict_to(constant_5,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(constant_4,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = unwrap(v14_10,v14_21_head);
      const Space v20_17 = subtract(v20_15,v20_16);
      const Space v20_18 = intersect(v20_17,constant_6);
      v15_19 = compose(v15_10,v20_18);
    }
    const Path v27_6 = concat_path(p0,v14_21_head);
    const Space v15_20 = wrap(v15_19,v27_6);
    const Space v15_21 = unite(v15_8,v15_20);
    v14_21_result = unite(v14_21_result,v15_21);
  }
  const Space v14_21 = std::move(v14_21_result);
  return v14_21;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v28_11_result;
  for (int v28_11_label = 1; v28_11_label <= 2; ++v28_11_label) {
    const Space v28_11_tail = child(s0,v28_11_label);
    if (v28_11_tail.empty()) continue;
    const Path v28_11_head{v28_11_label};
    const Space v29_2 = singleton(v28_11_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_11_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_11_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_11_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_11_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_11_result = unite(v28_11_result,v29_13);
  }
  const Space v28_11 = std::move(v28_11_result);
  return v28_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  const Space v38_8 = unwrap(constant_5,p0);
  const Space v38_10 = unwrap(constant_5,p0);
  Space v38_21_result;
  for (int v38_21_label = 1; v38_21_label <= 2; ++v38_21_label) {
    const Space v38_21_tail = child(s0,v38_21_label);
    if (v38_21_tail.empty()) continue;
    const Path v38_21_head{v38_21_label};
    const Space v39_2 = singleton(v38_21_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_21_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_21_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_19;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_8,v38_21_head);
      const Space v44_12 = restrict_to(constant_5,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(constant_4,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = unwrap(v38_10,v38_21_head);
      const Space v44_17 = subtract(v44_15,v44_16);
      const Space v44_18 = intersect(v44_17,constant_6);
      v39_19 = compose(v39_10,v44_18);
    }
    const Path v51_6 = concat_path(p0,v38_21_head);
    const Space v39_20 = wrap(v39_19,v51_6);
    const Space v39_21 = unite(v39_8,v39_20);
    v38_21_result = unite(v38_21_result,v39_21);
  }
  const Space v38_21 = std::move(v38_21_result);
  return v38_21;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  const Space v52_5 = unwrap(constant_5,p0);
  const Space v52_6 = restrict_to(constant_5,v52_5);
  Space v52_16_result;
  for (int v52_16_label = 1; v52_16_label <= 2; ++v52_16_label) {
    const Space v52_16_tail = child(v52_6,v52_16_label);
    if (v52_16_tail.empty()) continue;
    const Path v52_16_head{v52_16_label};
    const Space v53_2 = singleton(v52_16_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_16_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_16_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_16_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_16_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_16_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_16_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_16_result = unite(v52_16_result,v53_12);
  }
  const Space v52_16 = std::move(v52_16_result);
  const Space v52_17 = restrict_to(constant_4,v52_16);
  Space v52_27_result;
  for (int v52_27_label = 1; v52_27_label <= 2; ++v52_27_label) {
    const Space v52_27_tail = child(v52_17,v52_27_label);
    if (v52_27_tail.empty()) continue;
    const Path v52_27_head{v52_27_label};
    const Space v62_2 = singleton(v52_27_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_27_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_27_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_27_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_27_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_27_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_27_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_27_result = unite(v52_27_result,v62_12);
  }
  const Space v52_27 = std::move(v52_27_result);
  const Space v52_29 = unwrap(constant_5,p0);
  const Space v52_30 = subtract(v52_27,v52_29);
  const Space v52_32 = intersect(v52_30,constant_6);
  const Space v52_33 = wrap(v52_32,p0);
  return v52_33;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  Space v103_11_result;
  for (int v103_11_label = 1; v103_11_label <= 2; ++v103_11_label) {
    const Space v103_11_tail = child(s0,v103_11_label);
    if (v103_11_tail.empty()) continue;
    const Path v103_11_head{v103_11_label};
    const Space v104_2 = singleton(v103_11_head);
    const Space v104_3 = intersect(constant_1,v104_2);
    const Space v104_4 = (has_head(v104_3) ? constant_2 : Space{});
    const Space v104_5 = subtract(constant_0,v104_4);
    Space v104_8;
    if (!v104_5.empty()) {
      const Path v105_6 = concat_path(p0,v103_11_head);
      Space v105_7_result;
      for (int v105_7_label = 1; v105_7_label <= 2; ++v105_7_label) {
        const Space v105_7_tail = child(v103_11_tail,v105_7_label);
        if (v105_7_tail.empty()) continue;
        const Path v105_7_head{v105_7_label};
        const Space v106_2 = singleton(v105_7_head);
        const Space v106_3 = intersect(constant_1,v106_2);
        const Space v106_4 = (has_head(v106_3) ? constant_2 : Space{});
        const Space v106_5 = subtract(constant_0,v106_4);
        Space v106_8;
        if (!v106_5.empty()) {
          const Path v107_6 = concat_path(v105_6,v105_7_head);
          const Space v107_7 = routine_22(c, v107_6, v105_7_tail);
          v106_8 = compose(v106_5,v107_7);
        }
        const Space v106_9 = intersect(constant_1,v106_2);
        const Space v106_10 = (has_head(v106_9) ? constant_2 : Space{});
        Space v106_12;
        if (!v106_10.empty()) {
          const Path v108_6 = concat_path(v105_6,v105_7_head);
          const Space v108_11 = routine_23(c, v108_6, v105_7_tail);
          v106_12 = compose(v106_10,v108_11);
        }
        const Space v106_13 = unite(v106_8,v106_12);
        v105_7_result = unite(v105_7_result,v106_13);
      }
      const Space v105_7 = std::move(v105_7_result);
      v104_8 = compose(v104_5,v105_7);
    }
    const Space v104_9 = intersect(constant_1,v104_2);
    const Space v104_10 = (has_head(v104_9) ? constant_2 : Space{});
    Space v104_12;
    if (!v104_10.empty()) {
      const Path v109_6 = concat_path(p0,v103_11_head);
      Space v109_11_result;
      for (int v109_11_label = 1; v109_11_label <= 2; ++v109_11_label) {
        const Space v109_11_tail = child(v103_11_tail,v109_11_label);
        if (v109_11_tail.empty()) continue;
        const Path v109_11_head{v109_11_label};
        const Space v110_2 = singleton(v109_11_head);
        const Space v110_3 = intersect(constant_1,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_2 : Space{});
        const Space v110_5 = subtract(constant_0,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_11_head);
          const Space v111_7 = routine_22(c, v111_6, v109_11_tail);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_1,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_2 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_11_head);
          const Space v112_11 = routine_5(c, v112_6, v109_11_tail);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_11_result = unite(v109_11_result,v110_13);
      }
      const Space v109_11 = std::move(v109_11_result);
      v104_12 = compose(v104_10,v109_11);
    }
    const Space v104_13 = unite(v104_8,v104_12);
    v103_11_result = unite(v103_11_result,v104_13);
  }
  const Space v103_11 = std::move(v103_11_result);
  return v103_11;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  const Space v113_8 = unwrap(constant_5,p0);
  const Space v113_10 = unwrap(constant_5,p0);
  Space v113_21_result;
  for (int v113_21_label = 1; v113_21_label <= 2; ++v113_21_label) {
    const Space v113_21_tail = child(s0,v113_21_label);
    if (v113_21_tail.empty()) continue;
    const Path v113_21_head{v113_21_label};
    const Space v114_2 = singleton(v113_21_head);
    const Space v114_3 = intersect(constant_1,v114_2);
    const Space v114_4 = (has_head(v114_3) ? constant_2 : Space{});
    const Space v114_5 = subtract(constant_0,v114_4);
    Space v114_8;
    if (!v114_5.empty()) {
      const Path v115_6 = concat_path(p0,v113_21_head);
      Space v115_7_result;
      for (int v115_7_label = 1; v115_7_label <= 2; ++v115_7_label) {
        const Space v115_7_tail = child(v113_21_tail,v115_7_label);
        if (v115_7_tail.empty()) continue;
        const Path v115_7_head{v115_7_label};
        const Space v116_2 = singleton(v115_7_head);
        const Space v116_3 = intersect(constant_1,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_2 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_8;
        if (!v116_5.empty()) {
          const Path v117_6 = concat_path(v115_6,v115_7_head);
          const Space v117_7 = routine_22(c, v117_6, v115_7_tail);
          v116_8 = compose(v116_5,v117_7);
        }
        const Space v116_9 = intersect(constant_1,v116_2);
        const Space v116_10 = (has_head(v116_9) ? constant_2 : Space{});
        Space v116_12;
        if (!v116_10.empty()) {
          const Path v118_6 = concat_path(v115_6,v115_7_head);
          const Space v118_11 = routine_23(c, v118_6, v115_7_tail);
          v116_12 = compose(v116_10,v118_11);
        }
        const Space v116_13 = unite(v116_8,v116_12);
        v115_7_result = unite(v115_7_result,v116_13);
      }
      const Space v115_7 = std::move(v115_7_result);
      v114_8 = compose(v114_5,v115_7);
    }
    const Space v114_9 = intersect(constant_1,v114_2);
    const Space v114_10 = (has_head(v114_9) ? constant_2 : Space{});
    Space v114_19;
    if (!v114_10.empty()) {
      const Space v119_11 = unwrap(v113_8,v113_21_head);
      const Space v119_12 = restrict_to(constant_5,v119_11);
      Space v119_13_result;
      for (int v119_13_label = 1; v119_13_label <= 2; ++v119_13_label) {
        const Space v119_13_tail = child(v119_12,v119_13_label);
        if (v119_13_tail.empty()) continue;
        const Path v119_13_head{v119_13_label};
        const Space v120_2 = singleton(v119_13_head);
        const Space v120_3 = intersect(constant_1,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_7;
        if (!v120_5.empty()) {
          const Space v121_6 = routine_6(c, v119_13_head, v119_13_tail);
          v120_7 = compose(v120_5,v121_6);
        }
        const Space v120_8 = intersect(constant_1,v120_2);
        const Space v120_9 = (has_head(v120_8) ? constant_2 : Space{});
        Space v120_11;
        if (!v120_9.empty()) {
          const Space v122_10 = routine_7(c, v119_13_head, v119_13_tail);
          v120_11 = compose(v120_9,v122_10);
        }
        const Space v120_12 = unite(v120_7,v120_11);
        v119_13_result = unite(v119_13_result,v120_12);
      }
      const Space v119_13 = std::move(v119_13_result);
      const Space v119_14 = restrict_to(constant_4,v119_13);
      Space v119_15_result;
      for (int v119_15_label = 1; v119_15_label <= 2; ++v119_15_label) {
        const Space v119_15_tail = child(v119_14,v119_15_label);
        if (v119_15_tail.empty()) continue;
        const Path v119_15_head{v119_15_label};
        const Space v123_2 = singleton(v119_15_head);
        const Space v123_3 = intersect(constant_1,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_2 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_7;
        if (!v123_5.empty()) {
          const Space v124_6 = routine_8(c, v119_15_head, v119_15_tail);
          v123_7 = compose(v123_5,v124_6);
        }
        const Space v123_8 = intersect(constant_1,v123_2);
        const Space v123_9 = (has_head(v123_8) ? constant_2 : Space{});
        Space v123_11;
        if (!v123_9.empty()) {
          const Space v125_10 = routine_9(c, v119_15_head, v119_15_tail);
          v123_11 = compose(v123_9,v125_10);
        }
        const Space v123_12 = unite(v123_7,v123_11);
        v119_15_result = unite(v119_15_result,v123_12);
      }
      const Space v119_15 = std::move(v119_15_result);
      const Space v119_16 = unwrap(v113_10,v113_21_head);
      const Space v119_17 = subtract(v119_15,v119_16);
      const Space v119_18 = intersect(v119_17,constant_6);
      v114_19 = compose(v114_10,v119_18);
    }
    const Path v126_6 = concat_path(p0,v113_21_head);
    const Space v114_20 = wrap(v114_19,v126_6);
    const Space v114_21 = unite(v114_8,v114_20);
    v113_21_result = unite(v113_21_result,v114_21);
  }
  const Space v113_21 = std::move(v113_21_result);
  return v113_21;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v127_11_result;
  for (int v127_11_label = 1; v127_11_label <= 2; ++v127_11_label) {
    const Space v127_11_tail = child(s0,v127_11_label);
    if (v127_11_tail.empty()) continue;
    const Path v127_11_head{v127_11_label};
    const Space v128_2 = singleton(v127_11_head);
    const Space v128_3 = intersect(constant_1,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_2 : Space{});
    const Space v128_5 = subtract(constant_0,v128_4);
    Space v128_8;
    if (!v128_5.empty()) {
      const Path v129_6 = concat_path(p0,v127_11_head);
      Space v129_7_result;
      for (int v129_7_label = 1; v129_7_label <= 2; ++v129_7_label) {
        const Space v129_7_tail = child(v127_11_tail,v129_7_label);
        if (v129_7_tail.empty()) continue;
        const Path v129_7_head{v129_7_label};
        const Space v130_2 = singleton(v129_7_head);
        const Space v130_3 = intersect(constant_1,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_2 : Space{});
        const Space v130_5 = subtract(constant_0,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v129_6,v129_7_head);
          const Space v131_7 = routine_24(c, v131_6, v129_7_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_1,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_2 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v129_6,v129_7_head);
          const Space v132_11 = routine_25(c, v132_6, v129_7_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_7_result = unite(v129_7_result,v130_13);
      }
      const Space v129_7 = std::move(v129_7_result);
      v128_8 = compose(v128_5,v129_7);
    }
    const Space v128_9 = intersect(constant_1,v128_2);
    const Space v128_10 = (has_head(v128_9) ? constant_2 : Space{});
    Space v128_12;
    if (!v128_10.empty()) {
      const Path v133_6 = concat_path(p0,v127_11_head);
      Space v133_11_result;
      for (int v133_11_label = 1; v133_11_label <= 2; ++v133_11_label) {
        const Space v133_11_tail = child(v127_11_tail,v133_11_label);
        if (v133_11_tail.empty()) continue;
        const Path v133_11_head{v133_11_label};
        const Space v134_2 = singleton(v133_11_head);
        const Space v134_3 = intersect(constant_1,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_2 : Space{});
        const Space v134_5 = subtract(constant_0,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v133_6,v133_11_head);
          const Space v135_7 = routine_24(c, v135_6, v133_11_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_1,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_2 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v133_6,v133_11_head);
          const Space v136_11 = routine_14(c, v136_6, v133_11_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_11_result = unite(v133_11_result,v134_13);
      }
      const Space v133_11 = std::move(v133_11_result);
      v128_12 = compose(v128_10,v133_11);
    }
    const Space v128_13 = unite(v128_8,v128_12);
    v127_11_result = unite(v127_11_result,v128_13);
  }
  const Space v127_11 = std::move(v127_11_result);
  return v127_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v137_8_result;
  for (int v137_8_label = 1; v137_8_label <= 2; ++v137_8_label) {
    const Space v137_8_tail = child(s0,v137_8_label);
    if (v137_8_tail.empty()) continue;
    const Path v137_8_head{v137_8_label};
    const Space v138_2 = singleton(v137_8_head);
    const Space v138_3 = intersect(constant_1,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_2 : Space{});
    const Space v138_5 = subtract(constant_0,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_8_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_8_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_1,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_2 : Space{});
        const Space v140_5 = subtract(constant_0,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_24(c, v141_6, v139_7_tail);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_1,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_2 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_25(c, v142_6, v139_7_tail);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_1,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_2 : Space{});
    const Space v138_11 = compose(v138_10,v137_8_tail);
    const Space v138_12 = unite(v138_8,v138_11);
    v137_8_result = unite(v137_8_result,v138_12);
  }
  const Space v137_8 = std::move(v137_8_result);
  return v137_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v144_11_result;
  for (int v144_11_label = 1; v144_11_label <= 2; ++v144_11_label) {
    const Space v144_11_tail = child(s0,v144_11_label);
    if (v144_11_tail.empty()) continue;
    const Path v144_11_head{v144_11_label};
    const Space v145_2 = singleton(v144_11_head);
    const Space v145_3 = intersect(constant_1,v145_2);
    const Space v145_4 = (has_head(v145_3) ? constant_2 : Space{});
    const Space v145_5 = subtract(constant_0,v145_4);
    Space v145_8;
    if (!v145_5.empty()) {
      const Path v146_6 = concat_path(p0,v144_11_head);
      Space v146_7_result;
      for (int v146_7_label = 1; v146_7_label <= 2; ++v146_7_label) {
        const Space v146_7_tail = child(v144_11_tail,v146_7_label);
        if (v146_7_tail.empty()) continue;
        const Path v146_7_head{v146_7_label};
        const Space v147_2 = singleton(v146_7_head);
        const Space v147_3 = intersect(constant_1,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_2 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v146_6,v146_7_head);
          const Space v148_7 = routine_26(c, v148_6, v146_7_tail);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_1,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_2 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v146_6,v146_7_head);
          const Space v149_11 = routine_27(c, v149_6, v146_7_tail);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_7_result = unite(v146_7_result,v147_13);
      }
      const Space v146_7 = std::move(v146_7_result);
      v145_8 = compose(v145_5,v146_7);
    }
    const Space v145_9 = intersect(constant_1,v145_2);
    const Space v145_10 = (has_head(v145_9) ? constant_2 : Space{});
    Space v145_12;
    if (!v145_10.empty()) {
      const Path v150_6 = concat_path(p0,v144_11_head);
      Space v150_11_result;
      for (int v150_11_label = 1; v150_11_label <= 2; ++v150_11_label) {
        const Space v150_11_tail = child(v144_11_tail,v150_11_label);
        if (v150_11_tail.empty()) continue;
        const Path v150_11_head{v150_11_label};
        const Space v151_2 = singleton(v150_11_head);
        const Space v151_3 = intersect(constant_1,v151_2);
        const Space v151_4 = (has_head(v151_3) ? constant_2 : Space{});
        const Space v151_5 = subtract(constant_0,v151_4);
        Space v151_8;
        if (!v151_5.empty()) {
          const Path v152_6 = concat_path(v150_6,v150_11_head);
          const Space v152_7 = routine_26(c, v152_6, v150_11_tail);
          v151_8 = compose(v151_5,v152_7);
        }
        const Space v151_9 = intersect(constant_1,v151_2);
        const Space v151_10 = (has_head(v151_9) ? constant_2 : Space{});
        Space v151_12;
        if (!v151_10.empty()) {
          const Path v153_6 = concat_path(v150_6,v150_11_head);
          const Space v153_11 = routine_17(c, v153_6, v150_11_tail);
          v151_12 = compose(v151_10,v153_11);
        }
        const Space v151_13 = unite(v151_8,v151_12);
        v150_11_result = unite(v150_11_result,v151_13);
      }
      const Space v150_11 = std::move(v150_11_result);
      v145_12 = compose(v145_10,v150_11);
    }
    const Space v145_13 = unite(v145_8,v145_12);
    v144_11_result = unite(v144_11_result,v145_13);
  }
  const Space v144_11 = std::move(v144_11_result);
  return v144_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v154_8_result;
  for (int v154_8_label = 1; v154_8_label <= 2; ++v154_8_label) {
    const Space v154_8_tail = child(s0,v154_8_label);
    if (v154_8_tail.empty()) continue;
    const Path v154_8_head{v154_8_label};
    const Space v155_2 = singleton(v154_8_head);
    const Space v155_3 = intersect(constant_1,v155_2);
    const Space v155_4 = (has_head(v155_3) ? constant_2 : Space{});
    const Space v155_5 = subtract(constant_0,v155_4);
    Space v155_8;
    if (!v155_5.empty()) {
      const Path v156_6 = concat_path(p0,v154_8_head);
      Space v156_7_result;
      for (int v156_7_label = 1; v156_7_label <= 2; ++v156_7_label) {
        const Space v156_7_tail = child(v154_8_tail,v156_7_label);
        if (v156_7_tail.empty()) continue;
        const Path v156_7_head{v156_7_label};
        const Space v157_2 = singleton(v156_7_head);
        const Space v157_3 = intersect(constant_1,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_2 : Space{});
        const Space v157_5 = subtract(constant_0,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_7_head);
          const Space v158_7 = routine_26(c, v158_6, v156_7_tail);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_1,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_2 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_7_head);
          const Space v159_11 = routine_27(c, v159_6, v156_7_tail);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_7_result = unite(v156_7_result,v157_13);
      }
      const Space v156_7 = std::move(v156_7_result);
      v155_8 = compose(v155_5,v156_7);
    }
    const Space v155_9 = intersect(constant_1,v155_2);
    const Space v155_10 = (has_head(v155_9) ? constant_2 : Space{});
    const Space v155_11 = compose(v155_10,v154_8_tail);
    const Space v155_12 = unite(v155_8,v155_11);
    v154_8_result = unite(v154_8_result,v155_12);
  }
  const Space v154_8 = std::move(v154_8_result);
  return v154_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v161_11_result;
  for (int v161_11_label = 1; v161_11_label <= 2; ++v161_11_label) {
    const Space v161_11_tail = child(s0,v161_11_label);
    if (v161_11_tail.empty()) continue;
    const Path v161_11_head{v161_11_label};
    const Space v162_2 = singleton(v161_11_head);
    const Space v162_3 = intersect(constant_1,v162_2);
    const Space v162_4 = (has_head(v162_3) ? constant_2 : Space{});
    const Space v162_5 = subtract(constant_0,v162_4);
    Space v162_8;
    if (!v162_5.empty()) {
      const Path v163_6 = concat_path(p0,v161_11_head);
      Space v163_7_result;
      for (int v163_7_label = 1; v163_7_label <= 2; ++v163_7_label) {
        const Space v163_7_tail = child(v161_11_tail,v163_7_label);
        if (v163_7_tail.empty()) continue;
        const Path v163_7_head{v163_7_label};
        const Space v164_2 = singleton(v163_7_head);
        const Space v164_3 = intersect(constant_1,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
        const Space v164_5 = subtract(constant_0,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v163_6,v163_7_head);
          const Space v165_7 = routine_28(c, v165_6, v163_7_tail);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_1,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v163_6,v163_7_head);
          const Space v166_11 = routine_29(c, v166_6, v163_7_tail);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_7_result = unite(v163_7_result,v164_13);
      }
      const Space v163_7 = std::move(v163_7_result);
      v162_8 = compose(v162_5,v163_7);
    }
    const Space v162_9 = intersect(constant_1,v162_2);
    const Space v162_10 = (has_head(v162_9) ? constant_2 : Space{});
    Space v162_12;
    if (!v162_10.empty()) {
      const Path v167_6 = concat_path(p0,v161_11_head);
      Space v167_11_result;
      for (int v167_11_label = 1; v167_11_label <= 2; ++v167_11_label) {
        const Space v167_11_tail = child(v161_11_tail,v167_11_label);
        if (v167_11_tail.empty()) continue;
        const Path v167_11_head{v167_11_label};
        const Space v168_2 = singleton(v167_11_head);
        const Space v168_3 = intersect(constant_1,v168_2);
        const Space v168_4 = (has_head(v168_3) ? constant_2 : Space{});
        const Space v168_5 = subtract(constant_0,v168_4);
        Space v168_8;
        if (!v168_5.empty()) {
          const Path v169_6 = concat_path(v167_6,v167_11_head);
          const Space v169_7 = routine_28(c, v169_6, v167_11_tail);
          v168_8 = compose(v168_5,v169_7);
        }
        const Space v168_9 = intersect(constant_1,v168_2);
        const Space v168_10 = (has_head(v168_9) ? constant_2 : Space{});
        Space v168_12;
        if (!v168_10.empty()) {
          const Path v170_6 = concat_path(v167_6,v167_11_head);
          const Space v170_11 = routine_14(c, v170_6, v167_11_tail);
          v168_12 = compose(v168_10,v170_11);
        }
        const Space v168_13 = unite(v168_8,v168_12);
        v167_11_result = unite(v167_11_result,v168_13);
      }
      const Space v167_11 = std::move(v167_11_result);
      v162_12 = compose(v162_10,v167_11);
    }
    const Space v162_13 = unite(v162_8,v162_12);
    v161_11_result = unite(v161_11_result,v162_13);
  }
  const Space v161_11 = std::move(v161_11_result);
  return v161_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v171_8_result;
  for (int v171_8_label = 1; v171_8_label <= 2; ++v171_8_label) {
    const Space v171_8_tail = child(s0,v171_8_label);
    if (v171_8_tail.empty()) continue;
    const Path v171_8_head{v171_8_label};
    const Space v172_2 = singleton(v171_8_head);
    const Space v172_3 = intersect(constant_1,v172_2);
    const Space v172_4 = (has_head(v172_3) ? constant_2 : Space{});
    const Space v172_5 = subtract(constant_0,v172_4);
    Space v172_8;
    if (!v172_5.empty()) {
      const Path v173_6 = concat_path(p0,v171_8_head);
      Space v173_7_result;
      for (int v173_7_label = 1; v173_7_label <= 2; ++v173_7_label) {
        const Space v173_7_tail = child(v171_8_tail,v173_7_label);
        if (v173_7_tail.empty()) continue;
        const Path v173_7_head{v173_7_label};
        const Space v174_2 = singleton(v173_7_head);
        const Space v174_3 = intersect(constant_1,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_2 : Space{});
        const Space v174_5 = subtract(constant_0,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_7_head);
          const Space v175_7 = routine_28(c, v175_6, v173_7_tail);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_1,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_2 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_7_head);
          const Space v176_11 = routine_29(c, v176_6, v173_7_tail);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_7_result = unite(v173_7_result,v174_13);
      }
      const Space v173_7 = std::move(v173_7_result);
      v172_8 = compose(v172_5,v173_7);
    }
    const Space v172_9 = intersect(constant_1,v172_2);
    const Space v172_10 = (has_head(v172_9) ? constant_2 : Space{});
    const Space v172_11 = compose(v172_10,v171_8_tail);
    const Space v172_12 = unite(v172_8,v172_11);
    v171_8_result = unite(v171_8_result,v172_12);
  }
  const Space v171_8 = std::move(v171_8_result);
  return v171_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v177_11_result;
  for (int v177_11_label = 1; v177_11_label <= 2; ++v177_11_label) {
    const Space v177_11_tail = child(s0,v177_11_label);
    if (v177_11_tail.empty()) continue;
    const Path v177_11_head{v177_11_label};
    const Space v178_2 = singleton(v177_11_head);
    const Space v178_3 = intersect(constant_1,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_2 : Space{});
    const Space v178_5 = subtract(constant_0,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_11_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_11_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_1,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
        const Space v180_5 = subtract(constant_0,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_30(c, v181_6, v179_7_tail);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_1,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_2 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_31(c, v182_6, v179_7_tail);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_1,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_2 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_11_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_11_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_1,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_2 : Space{});
        const Space v184_5 = subtract(constant_0,v184_4);
        Space v184_8;
        if (!v184_5.empty()) {
          const Path v185_6 = concat_path(v183_6,v183_11_head);
          const Space v185_7 = routine_30(c, v185_6, v183_11_tail);
          v184_8 = compose(v184_5,v185_7);
        }
        const Space v184_9 = intersect(constant_1,v184_2);
        const Space v184_10 = (has_head(v184_9) ? constant_2 : Space{});
        Space v184_12;
        if (!v184_10.empty()) {
          const Path v186_6 = concat_path(v183_6,v183_11_head);
          const Space v186_11 = routine_17(c, v186_6, v183_11_tail);
          v184_12 = compose(v184_10,v186_11);
        }
        const Space v184_13 = unite(v184_8,v184_12);
        v183_11_result = unite(v183_11_result,v184_13);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_11_result = unite(v177_11_result,v178_13);
  }
  const Space v177_11 = std::move(v177_11_result);
  return v177_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v187_8_result;
  for (int v187_8_label = 1; v187_8_label <= 2; ++v187_8_label) {
    const Space v187_8_tail = child(s0,v187_8_label);
    if (v187_8_tail.empty()) continue;
    const Path v187_8_head{v187_8_label};
    const Space v188_2 = singleton(v187_8_head);
    const Space v188_3 = intersect(constant_1,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_2 : Space{});
    const Space v188_5 = subtract(constant_0,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_8_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_8_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_1,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_2 : Space{});
        const Space v190_5 = subtract(constant_0,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_30(c, v191_6, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_1,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_2 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_31(c, v192_6, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_1,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_2 : Space{});
    const Space v188_11 = compose(v188_10,v187_8_tail);
    const Space v188_12 = unite(v188_8,v188_11);
    v187_8_result = unite(v187_8_result,v188_12);
  }
  const Space v187_8 = std::move(v187_8_result);
  return v187_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  const Space v193_2 = Space{};
  return v193_2;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  const Space v194_6 = unwrap(constant_5,p0);
  const Space v194_8 = unwrap(constant_5,p0);
  Space v194_16_result;
  for (int v194_16_label = 1; v194_16_label <= 2; ++v194_16_label) {
    const Space v194_16_tail = child(s0,v194_16_label);
    if (v194_16_tail.empty()) continue;
    const Path v194_16_head{v194_16_label};
    const Space v195_2 = singleton(v194_16_head);
    const Space v195_3 = intersect(constant_1,v195_2);
    const Space v195_4 = (has_head(v195_3) ? constant_2 : Space{});
    Space v195_13;
    if (!v195_4.empty()) {
      const Space v196_5 = unwrap(v194_6,v194_16_head);
      const Space v196_6 = restrict_to(constant_5,v196_5);
      Space v196_7_result;
      for (int v196_7_label = 1; v196_7_label <= 2; ++v196_7_label) {
        const Space v196_7_tail = child(v196_6,v196_7_label);
        if (v196_7_tail.empty()) continue;
        const Path v196_7_head{v196_7_label};
        const Space v197_2 = singleton(v196_7_head);
        const Space v197_3 = intersect(constant_1,v197_2);
        const Space v197_4 = (has_head(v197_3) ? constant_2 : Space{});
        const Space v197_5 = subtract(constant_0,v197_4);
        Space v197_7;
        if (!v197_5.empty()) {
          const Space v198_6 = routine_6(c, v196_7_head, v196_7_tail);
          v197_7 = compose(v197_5,v198_6);
        }
        const Space v197_8 = intersect(constant_1,v197_2);
        const Space v197_9 = (has_head(v197_8) ? constant_2 : Space{});
        Space v197_11;
        if (!v197_9.empty()) {
          const Space v199_10 = routine_7(c, v196_7_head, v196_7_tail);
          v197_11 = compose(v197_9,v199_10);
        }
        const Space v197_12 = unite(v197_7,v197_11);
        v196_7_result = unite(v196_7_result,v197_12);
      }
      const Space v196_7 = std::move(v196_7_result);
      const Space v196_8 = restrict_to(constant_4,v196_7);
      Space v196_9_result;
      for (int v196_9_label = 1; v196_9_label <= 2; ++v196_9_label) {
        const Space v196_9_tail = child(v196_8,v196_9_label);
        if (v196_9_tail.empty()) continue;
        const Path v196_9_head{v196_9_label};
        const Space v200_2 = singleton(v196_9_head);
        const Space v200_3 = intersect(constant_1,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_2 : Space{});
        const Space v200_5 = subtract(constant_0,v200_4);
        Space v200_7;
        if (!v200_5.empty()) {
          const Space v201_6 = routine_8(c, v196_9_head, v196_9_tail);
          v200_7 = compose(v200_5,v201_6);
        }
        const Space v200_8 = intersect(constant_1,v200_2);
        const Space v200_9 = (has_head(v200_8) ? constant_2 : Space{});
        Space v200_11;
        if (!v200_9.empty()) {
          const Space v202_10 = routine_9(c, v196_9_head, v196_9_tail);
          v200_11 = compose(v200_9,v202_10);
        }
        const Space v200_12 = unite(v200_7,v200_11);
        v196_9_result = unite(v196_9_result,v200_12);
      }
      const Space v196_9 = std::move(v196_9_result);
      const Space v196_10 = unwrap(v194_8,v194_16_head);
      const Space v196_11 = subtract(v196_9,v196_10);
      const Space v196_12 = intersect(v196_11,constant_6);
      v195_13 = compose(v195_4,v196_12);
    }
    const Path v195_14 = concat_path(p0,v194_16_head);
    const Space v195_15 = wrap(v195_13,v195_14);
    v194_16_result = unite(v194_16_result,v195_15);
  }
  const Space v194_16 = std::move(v194_16_result);
  return v194_16;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v203_11_result;
  for (int v203_11_label = 1; v203_11_label <= 2; ++v203_11_label) {
    const Space v203_11_tail = child(s0,v203_11_label);
    if (v203_11_tail.empty()) continue;
    const Path v203_11_head{v203_11_label};
    const Space v204_2 = singleton(v203_11_head);
    const Space v204_3 = intersect(constant_1,v204_2);
    const Space v204_4 = (has_head(v204_3) ? constant_2 : Space{});
    const Space v204_5 = subtract(constant_0,v204_4);
    Space v204_8;
    if (!v204_5.empty()) {
      const Path v205_6 = concat_path(p0,v203_11_head);
      Space v205_7_result;
      for (int v205_7_label = 1; v205_7_label <= 2; ++v205_7_label) {
        const Space v205_7_tail = child(v203_11_tail,v205_7_label);
        if (v205_7_tail.empty()) continue;
        const Path v205_7_head{v205_7_label};
        const Space v206_2 = singleton(v205_7_head);
        const Space v206_3 = intersect(constant_1,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_2 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_7_head);
          const Space v207_7 = routine_32(c, v207_6, v205_7_tail);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_1,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_2 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_7_head);
          const Space v208_11 = routine_33(c, v208_6, v205_7_tail);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_7_result = unite(v205_7_result,v206_13);
      }
      const Space v205_7 = std::move(v205_7_result);
      v204_8 = compose(v204_5,v205_7);
    }
    const Space v204_9 = intersect(constant_1,v204_2);
    const Space v204_10 = (has_head(v204_9) ? constant_2 : Space{});
    Space v204_12;
    if (!v204_10.empty()) {
      const Path v209_6 = concat_path(p0,v203_11_head);
      Space v209_11_result;
      for (int v209_11_label = 1; v209_11_label <= 2; ++v209_11_label) {
        const Space v209_11_tail = child(v203_11_tail,v209_11_label);
        if (v209_11_tail.empty()) continue;
        const Path v209_11_head{v209_11_label};
        const Space v210_2 = singleton(v209_11_head);
        const Space v210_3 = intersect(constant_1,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_2 : Space{});
        const Space v210_5 = subtract(constant_0,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_11_head);
          const Space v211_7 = routine_32(c, v211_6, v209_11_tail);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_1,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_2 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_11_head);
          const Space v212_11 = routine_14(c, v212_6, v209_11_tail);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_11_result = unite(v209_11_result,v210_13);
      }
      const Space v209_11 = std::move(v209_11_result);
      v204_12 = compose(v204_10,v209_11);
    }
    const Space v204_13 = unite(v204_8,v204_12);
    v203_11_result = unite(v203_11_result,v204_13);
  }
  const Space v203_11 = std::move(v203_11_result);
  return v203_11;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v213_8_result;
  for (int v213_8_label = 1; v213_8_label <= 2; ++v213_8_label) {
    const Space v213_8_tail = child(s0,v213_8_label);
    if (v213_8_tail.empty()) continue;
    const Path v213_8_head{v213_8_label};
    const Space v214_2 = singleton(v213_8_head);
    const Space v214_3 = intersect(constant_1,v214_2);
    const Space v214_4 = (has_head(v214_3) ? constant_2 : Space{});
    const Space v214_5 = subtract(constant_0,v214_4);
    Space v214_8;
    if (!v214_5.empty()) {
      const Path v215_6 = concat_path(p0,v213_8_head);
      Space v215_7_result;
      for (int v215_7_label = 1; v215_7_label <= 2; ++v215_7_label) {
        const Space v215_7_tail = child(v213_8_tail,v215_7_label);
        if (v215_7_tail.empty()) continue;
        const Path v215_7_head{v215_7_label};
        const Space v216_2 = singleton(v215_7_head);
        const Space v216_3 = intersect(constant_1,v216_2);
        const Space v216_4 = (has_head(v216_3) ? constant_2 : Space{});
        const Space v216_5 = subtract(constant_0,v216_4);
        Space v216_8;
        if (!v216_5.empty()) {
          const Path v217_6 = concat_path(v215_6,v215_7_head);
          const Space v217_7 = routine_32(c, v217_6, v215_7_tail);
          v216_8 = compose(v216_5,v217_7);
        }
        const Space v216_9 = intersect(constant_1,v216_2);
        const Space v216_10 = (has_head(v216_9) ? constant_2 : Space{});
        Space v216_12;
        if (!v216_10.empty()) {
          const Path v218_6 = concat_path(v215_6,v215_7_head);
          const Space v218_11 = routine_33(c, v218_6, v215_7_tail);
          v216_12 = compose(v216_10,v218_11);
        }
        const Space v216_13 = unite(v216_8,v216_12);
        v215_7_result = unite(v215_7_result,v216_13);
      }
      const Space v215_7 = std::move(v215_7_result);
      v214_8 = compose(v214_5,v215_7);
    }
    const Space v214_9 = intersect(constant_1,v214_2);
    const Space v214_10 = (has_head(v214_9) ? constant_2 : Space{});
    const Space v214_11 = compose(v214_10,v213_8_tail);
    const Space v214_12 = unite(v214_8,v214_11);
    v213_8_result = unite(v213_8_result,v214_12);
  }
  const Space v213_8 = std::move(v213_8_result);
  return v213_8;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v219_11_result;
  for (int v219_11_label = 1; v219_11_label <= 2; ++v219_11_label) {
    const Space v219_11_tail = child(s0,v219_11_label);
    if (v219_11_tail.empty()) continue;
    const Path v219_11_head{v219_11_label};
    const Space v220_2 = singleton(v219_11_head);
    const Space v220_3 = intersect(constant_1,v220_2);
    const Space v220_4 = (has_head(v220_3) ? constant_2 : Space{});
    const Space v220_5 = subtract(constant_0,v220_4);
    Space v220_8;
    if (!v220_5.empty()) {
      const Path v221_6 = concat_path(p0,v219_11_head);
      Space v221_7_result;
      for (int v221_7_label = 1; v221_7_label <= 2; ++v221_7_label) {
        const Space v221_7_tail = child(v219_11_tail,v221_7_label);
        if (v221_7_tail.empty()) continue;
        const Path v221_7_head{v221_7_label};
        const Space v222_2 = singleton(v221_7_head);
        const Space v222_3 = intersect(constant_1,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_2 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_8;
        if (!v222_5.empty()) {
          const Path v223_6 = concat_path(v221_6,v221_7_head);
          const Space v223_7 = routine_34(c, v223_6, v221_7_tail);
          v222_8 = compose(v222_5,v223_7);
        }
        const Space v222_9 = intersect(constant_1,v222_2);
        const Space v222_10 = (has_head(v222_9) ? constant_2 : Space{});
        Space v222_12;
        if (!v222_10.empty()) {
          const Path v224_6 = concat_path(v221_6,v221_7_head);
          const Space v224_11 = routine_35(c, v224_6, v221_7_tail);
          v222_12 = compose(v222_10,v224_11);
        }
        const Space v222_13 = unite(v222_8,v222_12);
        v221_7_result = unite(v221_7_result,v222_13);
      }
      const Space v221_7 = std::move(v221_7_result);
      v220_8 = compose(v220_5,v221_7);
    }
    const Space v220_9 = intersect(constant_1,v220_2);
    const Space v220_10 = (has_head(v220_9) ? constant_2 : Space{});
    Space v220_12;
    if (!v220_10.empty()) {
      const Path v225_6 = concat_path(p0,v219_11_head);
      Space v225_11_result;
      for (int v225_11_label = 1; v225_11_label <= 2; ++v225_11_label) {
        const Space v225_11_tail = child(v219_11_tail,v225_11_label);
        if (v225_11_tail.empty()) continue;
        const Path v225_11_head{v225_11_label};
        const Space v226_2 = singleton(v225_11_head);
        const Space v226_3 = intersect(constant_1,v226_2);
        const Space v226_4 = (has_head(v226_3) ? constant_2 : Space{});
        const Space v226_5 = subtract(constant_0,v226_4);
        Space v226_8;
        if (!v226_5.empty()) {
          const Path v227_6 = concat_path(v225_6,v225_11_head);
          const Space v227_7 = routine_34(c, v227_6, v225_11_tail);
          v226_8 = compose(v226_5,v227_7);
        }
        const Space v226_9 = intersect(constant_1,v226_2);
        const Space v226_10 = (has_head(v226_9) ? constant_2 : Space{});
        Space v226_12;
        if (!v226_10.empty()) {
          const Path v228_6 = concat_path(v225_6,v225_11_head);
          const Space v228_11 = routine_17(c, v228_6, v225_11_tail);
          v226_12 = compose(v226_10,v228_11);
        }
        const Space v226_13 = unite(v226_8,v226_12);
        v225_11_result = unite(v225_11_result,v226_13);
      }
      const Space v225_11 = std::move(v225_11_result);
      v220_12 = compose(v220_10,v225_11);
    }
    const Space v220_13 = unite(v220_8,v220_12);
    v219_11_result = unite(v219_11_result,v220_13);
  }
  const Space v219_11 = std::move(v219_11_result);
  return v219_11;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v229_8_result;
  for (int v229_8_label = 1; v229_8_label <= 2; ++v229_8_label) {
    const Space v229_8_tail = child(s0,v229_8_label);
    if (v229_8_tail.empty()) continue;
    const Path v229_8_head{v229_8_label};
    const Space v230_2 = singleton(v229_8_head);
    const Space v230_3 = intersect(constant_1,v230_2);
    const Space v230_4 = (has_head(v230_3) ? constant_2 : Space{});
    const Space v230_5 = subtract(constant_0,v230_4);
    Space v230_8;
    if (!v230_5.empty()) {
      const Path v231_6 = concat_path(p0,v229_8_head);
      Space v231_7_result;
      for (int v231_7_label = 1; v231_7_label <= 2; ++v231_7_label) {
        const Space v231_7_tail = child(v229_8_tail,v231_7_label);
        if (v231_7_tail.empty()) continue;
        const Path v231_7_head{v231_7_label};
        const Space v232_2 = singleton(v231_7_head);
        const Space v232_3 = intersect(constant_1,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_2 : Space{});
        const Space v232_5 = subtract(constant_0,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_7_head);
          const Space v233_7 = routine_34(c, v233_6, v231_7_tail);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_1,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_2 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_7_head);
          const Space v234_11 = routine_35(c, v234_6, v231_7_tail);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_7_result = unite(v231_7_result,v232_13);
      }
      const Space v231_7 = std::move(v231_7_result);
      v230_8 = compose(v230_5,v231_7);
    }
    const Space v230_9 = intersect(constant_1,v230_2);
    const Space v230_10 = (has_head(v230_9) ? constant_2 : Space{});
    const Space v230_11 = compose(v230_10,v229_8_tail);
    const Space v230_12 = unite(v230_8,v230_11);
    v229_8_result = unite(v229_8_result,v230_12);
  }
  const Space v229_8 = std::move(v229_8_result);
  return v229_8;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v235_11_result;
  for (int v235_11_label = 1; v235_11_label <= 2; ++v235_11_label) {
    const Space v235_11_tail = child(s0,v235_11_label);
    if (v235_11_tail.empty()) continue;
    const Path v235_11_head{v235_11_label};
    const Space v236_2 = singleton(v235_11_head);
    const Space v236_3 = intersect(constant_1,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_2 : Space{});
    const Space v236_5 = subtract(constant_0,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_11_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_11_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_1,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_2 : Space{});
        const Space v238_5 = subtract(constant_0,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_36(c, v239_6, v237_7_tail);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_1,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_2 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_37(c, v240_6, v237_7_tail);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_1,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_2 : Space{});
    Space v236_12;
    if (!v236_10.empty()) {
      const Path v241_6 = concat_path(p0,v235_11_head);
      Space v241_11_result;
      for (int v241_11_label = 1; v241_11_label <= 2; ++v241_11_label) {
        const Space v241_11_tail = child(v235_11_tail,v241_11_label);
        if (v241_11_tail.empty()) continue;
        const Path v241_11_head{v241_11_label};
        const Space v242_2 = singleton(v241_11_head);
        const Space v242_3 = intersect(constant_1,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_2 : Space{});
        const Space v242_5 = subtract(constant_0,v242_4);
        Space v242_8;
        if (!v242_5.empty()) {
          const Path v243_6 = concat_path(v241_6,v241_11_head);
          const Space v243_7 = routine_36(c, v243_6, v241_11_tail);
          v242_8 = compose(v242_5,v243_7);
        }
        const Space v242_9 = intersect(constant_1,v242_2);
        const Space v242_10 = (has_head(v242_9) ? constant_2 : Space{});
        Space v242_12;
        if (!v242_10.empty()) {
          const Path v244_6 = concat_path(v241_6,v241_11_head);
          const Space v244_11 = routine_14(c, v244_6, v241_11_tail);
          v242_12 = compose(v242_10,v244_11);
        }
        const Space v242_13 = unite(v242_8,v242_12);
        v241_11_result = unite(v241_11_result,v242_13);
      }
      const Space v241_11 = std::move(v241_11_result);
      v236_12 = compose(v236_10,v241_11);
    }
    const Space v236_13 = unite(v236_8,v236_12);
    v235_11_result = unite(v235_11_result,v236_13);
  }
  const Space v235_11 = std::move(v235_11_result);
  return v235_11;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v245_8_result;
  for (int v245_8_label = 1; v245_8_label <= 2; ++v245_8_label) {
    const Space v245_8_tail = child(s0,v245_8_label);
    if (v245_8_tail.empty()) continue;
    const Path v245_8_head{v245_8_label};
    const Space v246_2 = singleton(v245_8_head);
    const Space v246_3 = intersect(constant_1,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_2 : Space{});
    const Space v246_5 = subtract(constant_0,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_8_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_8_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_1,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_2 : Space{});
        const Space v248_5 = subtract(constant_0,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_36(c, v249_6, v247_7_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_1,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_2 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_37(c, v250_6, v247_7_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_1,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_2 : Space{});
    const Space v246_11 = compose(v246_10,v245_8_tail);
    const Space v246_12 = unite(v246_8,v246_11);
    v245_8_result = unite(v245_8_result,v246_12);
  }
  const Space v245_8 = std::move(v245_8_result);
  return v245_8;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v251_11_result;
  for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
    const Space v251_11_tail = child(s0,v251_11_label);
    if (v251_11_tail.empty()) continue;
    const Path v251_11_head{v251_11_label};
    const Space v252_2 = singleton(v251_11_head);
    const Space v252_3 = intersect(constant_1,v252_2);
    const Space v252_4 = (has_head(v252_3) ? constant_2 : Space{});
    const Space v252_5 = subtract(constant_0,v252_4);
    Space v252_8;
    if (!v252_5.empty()) {
      const Path v253_6 = concat_path(p0,v251_11_head);
      Space v253_7_result;
      for (int v253_7_label = 1; v253_7_label <= 2; ++v253_7_label) {
        const Space v253_7_tail = child(v251_11_tail,v253_7_label);
        if (v253_7_tail.empty()) continue;
        const Path v253_7_head{v253_7_label};
        const Space v254_2 = singleton(v253_7_head);
        const Space v254_3 = intersect(constant_1,v254_2);
        const Space v254_4 = (has_head(v254_3) ? constant_2 : Space{});
        const Space v254_5 = subtract(constant_0,v254_4);
        Space v254_8;
        if (!v254_5.empty()) {
          const Path v255_6 = concat_path(v253_6,v253_7_head);
          const Space v255_7 = routine_38(c, v255_6, v253_7_tail);
          v254_8 = compose(v254_5,v255_7);
        }
        const Space v254_9 = intersect(constant_1,v254_2);
        const Space v254_10 = (has_head(v254_9) ? constant_2 : Space{});
        Space v254_12;
        if (!v254_10.empty()) {
          const Path v256_6 = concat_path(v253_6,v253_7_head);
          const Space v256_11 = routine_39(c, v256_6, v253_7_tail);
          v254_12 = compose(v254_10,v256_11);
        }
        const Space v254_13 = unite(v254_8,v254_12);
        v253_7_result = unite(v253_7_result,v254_13);
      }
      const Space v253_7 = std::move(v253_7_result);
      v252_8 = compose(v252_5,v253_7);
    }
    const Space v252_9 = intersect(constant_1,v252_2);
    const Space v252_10 = (has_head(v252_9) ? constant_2 : Space{});
    Space v252_12;
    if (!v252_10.empty()) {
      const Path v257_6 = concat_path(p0,v251_11_head);
      Space v257_11_result;
      for (int v257_11_label = 1; v257_11_label <= 2; ++v257_11_label) {
        const Space v257_11_tail = child(v251_11_tail,v257_11_label);
        if (v257_11_tail.empty()) continue;
        const Path v257_11_head{v257_11_label};
        const Space v258_2 = singleton(v257_11_head);
        const Space v258_3 = intersect(constant_1,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_2 : Space{});
        const Space v258_5 = subtract(constant_0,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_11_head);
          const Space v259_7 = routine_38(c, v259_6, v257_11_tail);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_1,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_2 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_11_head);
          const Space v260_11 = routine_17(c, v260_6, v257_11_tail);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_11_result = unite(v257_11_result,v258_13);
      }
      const Space v257_11 = std::move(v257_11_result);
      v252_12 = compose(v252_10,v257_11);
    }
    const Space v252_13 = unite(v252_8,v252_12);
    v251_11_result = unite(v251_11_result,v252_13);
  }
  const Space v251_11 = std::move(v251_11_result);
  return v251_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v261_8_result;
  for (int v261_8_label = 1; v261_8_label <= 2; ++v261_8_label) {
    const Space v261_8_tail = child(s0,v261_8_label);
    if (v261_8_tail.empty()) continue;
    const Path v261_8_head{v261_8_label};
    const Space v262_2 = singleton(v261_8_head);
    const Space v262_3 = intersect(constant_1,v262_2);
    const Space v262_4 = (has_head(v262_3) ? constant_2 : Space{});
    const Space v262_5 = subtract(constant_0,v262_4);
    Space v262_8;
    if (!v262_5.empty()) {
      const Path v263_6 = concat_path(p0,v261_8_head);
      Space v263_7_result;
      for (int v263_7_label = 1; v263_7_label <= 2; ++v263_7_label) {
        const Space v263_7_tail = child(v261_8_tail,v263_7_label);
        if (v263_7_tail.empty()) continue;
        const Path v263_7_head{v263_7_label};
        const Space v264_2 = singleton(v263_7_head);
        const Space v264_3 = intersect(constant_1,v264_2);
        const Space v264_4 = (has_head(v264_3) ? constant_2 : Space{});
        const Space v264_5 = subtract(constant_0,v264_4);
        Space v264_8;
        if (!v264_5.empty()) {
          const Path v265_6 = concat_path(v263_6,v263_7_head);
          const Space v265_7 = routine_38(c, v265_6, v263_7_tail);
          v264_8 = compose(v264_5,v265_7);
        }
        const Space v264_9 = intersect(constant_1,v264_2);
        const Space v264_10 = (has_head(v264_9) ? constant_2 : Space{});
        Space v264_12;
        if (!v264_10.empty()) {
          const Path v266_6 = concat_path(v263_6,v263_7_head);
          const Space v266_11 = routine_39(c, v266_6, v263_7_tail);
          v264_12 = compose(v264_10,v266_11);
        }
        const Space v264_13 = unite(v264_8,v264_12);
        v263_7_result = unite(v263_7_result,v264_13);
      }
      const Space v263_7 = std::move(v263_7_result);
      v262_8 = compose(v262_5,v263_7);
    }
    const Space v262_9 = intersect(constant_1,v262_2);
    const Space v262_10 = (has_head(v262_9) ? constant_2 : Space{});
    const Space v262_11 = compose(v262_10,v261_8_tail);
    const Space v262_12 = unite(v262_8,v262_11);
    v261_8_result = unite(v261_8_result,v262_12);
  }
  const Space v261_8 = std::move(v261_8_result);
  return v261_8;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  Space v267_4_result;
  for (int v267_4_label = 1; v267_4_label <= 2; ++v267_4_label) {
    const Space v267_4_tail = child(s0,v267_4_label);
    if (v267_4_tail.empty()) continue;
    const Path v267_4_head{v267_4_label};
    const Space v268_2 = singleton(v267_4_head);
    const Space v268_3 = intersect(constant_1,v268_2);
    const Space v268_4 = (has_head(v268_3) ? constant_2 : Space{});
    Space v268_7;
    if (!v268_4.empty()) {
      const Path v269_5 = concat_path(p0,v267_4_head);
      Space v269_6_result;
      for (int v269_6_label = 1; v269_6_label <= 2; ++v269_6_label) {
        const Space v269_6_tail = child(v267_4_tail,v269_6_label);
        if (v269_6_tail.empty()) continue;
        const Path v269_6_head{v269_6_label};
        const Space v270_2 = singleton(v269_6_head);
        const Space v270_3 = intersect(constant_1,v270_2);
        const Space v270_4 = (has_head(v270_3) ? constant_2 : Space{});
        Space v270_7;
        if (!v270_4.empty()) {
          const Path v271_5 = concat_path(v269_5,v269_6_head);
          const Space v271_6 = routine_14(c, v271_5, v269_6_tail);
          v270_7 = compose(v270_4,v271_6);
        }
        v269_6_result = unite(v269_6_result,v270_7);
      }
      const Space v269_6 = std::move(v269_6_result);
      v268_7 = compose(v268_4,v269_6);
    }
    v267_4_result = unite(v267_4_result,v268_7);
  }
  const Space v267_4 = std::move(v267_4_result);
  return v267_4;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0) {
  Space v272_3_result;
  for (int v272_3_label = 1; v272_3_label <= 2; ++v272_3_label) {
    const Space v272_3_tail = child(s0,v272_3_label);
    if (v272_3_tail.empty()) continue;
    const Path v272_3_head{v272_3_label};
    const Space v273_2 = singleton(v272_3_head);
    const Space v273_3 = intersect(constant_1,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_2 : Space{});
    const Space v273_5 = compose(v273_4,v272_3_tail);
    v272_3_result = unite(v272_3_result,v273_5);
  }
  const Space v272_3 = std::move(v272_3_result);
  return v272_3;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  Space v274_4_result;
  for (int v274_4_label = 1; v274_4_label <= 2; ++v274_4_label) {
    const Space v274_4_tail = child(s0,v274_4_label);
    if (v274_4_tail.empty()) continue;
    const Path v274_4_head{v274_4_label};
    const Space v275_2 = singleton(v274_4_head);
    const Space v275_3 = intersect(constant_1,v275_2);
    const Space v275_4 = (has_head(v275_3) ? constant_2 : Space{});
    Space v275_7;
    if (!v275_4.empty()) {
      const Path v276_5 = concat_path(p0,v274_4_head);
      Space v276_6_result;
      for (int v276_6_label = 1; v276_6_label <= 2; ++v276_6_label) {
        const Space v276_6_tail = child(v274_4_tail,v276_6_label);
        if (v276_6_tail.empty()) continue;
        const Path v276_6_head{v276_6_label};
        const Space v277_2 = singleton(v276_6_head);
        const Space v277_3 = intersect(constant_1,v277_2);
        const Space v277_4 = (has_head(v277_3) ? constant_2 : Space{});
        Space v277_7;
        if (!v277_4.empty()) {
          const Path v278_5 = concat_path(v276_5,v276_6_head);
          const Space v278_6 = routine_17(c, v278_5, v276_6_tail);
          v277_7 = compose(v277_4,v278_6);
        }
        v276_6_result = unite(v276_6_result,v277_7);
      }
      const Space v276_6 = std::move(v276_6_result);
      v275_7 = compose(v275_4,v276_6);
    }
    v274_4_result = unite(v274_4_result,v275_7);
  }
  const Space v274_4 = std::move(v274_4_result);
  return v274_4;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  Space v279_3_result;
  for (int v279_3_label = 1; v279_3_label <= 2; ++v279_3_label) {
    const Space v279_3_tail = child(s0,v279_3_label);
    if (v279_3_tail.empty()) continue;
    const Path v279_3_head{v279_3_label};
    const Space v280_2 = singleton(v279_3_head);
    const Space v280_3 = intersect(constant_1,v280_2);
    const Space v280_4 = (has_head(v280_3) ? constant_2 : Space{});
    const Space v280_5 = compose(v280_4,v279_3_tail);
    v279_3_result = unite(v279_3_result,v280_5);
  }
  const Space v279_3 = std::move(v279_3_result);
  return v279_3;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  const Space v281_2 = Space{};
  return v281_2;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v282_3_result;
  for (int v282_3_label = 1; v282_3_label <= 2; ++v282_3_label) {
    const Space v282_3_tail = child(s0,v282_3_label);
    if (v282_3_tail.empty()) continue;
    const Path v282_3_head{v282_3_label};
    const Space v283_2 = singleton(v282_3_head);
    const Space v283_3 = intersect(constant_1,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_2 : Space{});
    const Space v283_5 = compose(v283_4,v282_3_tail);
    v282_3_result = unite(v282_3_result,v283_5);
  }
  const Space v282_3 = std::move(v282_3_result);
  return v282_3;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  const Space v284_2 = Space{};
  return v284_2;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  Space v285_3_result;
  for (int v285_3_label = 1; v285_3_label <= 2; ++v285_3_label) {
    const Space v285_3_tail = child(s0,v285_3_label);
    if (v285_3_tail.empty()) continue;
    const Path v285_3_head{v285_3_label};
    const Space v286_2 = singleton(v285_3_head);
    const Space v286_3 = intersect(constant_1,v286_2);
    const Space v286_4 = (has_head(v286_3) ? constant_2 : Space{});
    const Space v286_5 = compose(v286_4,v285_3_tail);
    v285_3_result = unite(v285_3_result,v286_5);
  }
  const Space v285_3 = std::move(v285_3_result);
  return v285_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
