#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("36 2 1 2 2 1 15 2 2 8 2 2 20 2 3 4 2 3 10 2 5 6 2 5 11 2 6 12 2 6 22 2 7 3 2 7 8 2 8 4 2 8 19 2 9 2 2 9 7 2 11 10 2 11 12 2 13 5 2 13 14 2 14 6 2 14 24 2 15 20 2 15 24 2 16 14 2 16 15 2 17 5 2 17 18 2 18 3 2 18 11 2 20 19 2 20 21 2 23 7 2 23 18 2 24 21 2 24 22");
static const Space constant_1 = literal_text("36 2 2 1 2 2 9 2 3 7 2 3 18 2 4 3 2 4 8 2 5 13 2 5 17 2 6 5 2 6 14 2 7 9 2 7 23 2 8 2 2 8 7 2 10 3 2 10 11 2 11 5 2 11 18 2 12 6 2 12 11 2 14 13 2 14 16 2 15 1 2 15 16 2 18 17 2 18 23 2 19 8 2 19 20 2 20 2 2 20 15 2 21 20 2 21 24 2 22 6 2 22 24 2 24 14 2 24 15");
static const Space constant_2 = literal_text("12 1 1 1 5 1 7 1 8 1 10 1 11 1 13 1 15 1 19 1 22 1 23 1 24");
static const Path constant_3 = Path{25};
static Space routine_0(Context& c, const Space* s0);
static Space routine_0(Context& c, const Space* s0) {
  const auto v0_6_branches = branches(c,bound_space(s0));
  std::vector<Space> v0_6_outputs;
  v0_6_outputs.reserve(v0_6_branches.size());
  for (const auto& v0_6_branch : v0_6_branches) {
    const Path v0_6_head{v0_6_branch.first};
    const Space& v0_6_tail = v0_6_branch.second;
    const Space v1_2 = unwrap(constant_1,v0_6_head);
    const Space v1_3 = restrict_to(constant_1,v1_2);
    const Space v1_4 = tails_union(v1_3);
    const Space v1_5 = restrict_to(constant_0,v1_4);
    const Space v1_6 = tails_union(v1_5);
    const Space v1_7 = unwrap(constant_1,v0_6_head);
    const Space v1_8 = subtract(v1_6,v1_7);
    const Space v1_9 = intersect(v1_8,constant_2);
    const Space v1_10 = wrap(v1_9,v0_6_head);
    v0_6_outputs.push_back(v1_10);
  }
  const Space v0_6 = join_outputs(std::move(v0_6_outputs));
  const Space v0_8 = wrap(v0_6,constant_3);
  return v0_8;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"25 1 4 112 48 95 48 2 4 112 49 95 53 3 4 112 50 95 51 4 4 112 51 95 51 5 4 112 49 95 50 6 4 112 50 95 49 7 4 112 49 95 52 8 4 112 50 95 52 9 4 112 48 95 53 10 4 112 51 95 50 11 4 112 50 95 50 12 4 112 51 95 49 13 4 112 48 95 50 14 4 112 49 95 49 15 4 112 49 95 48 16 4 112 48 95 49 17 4 112 48 95 51 18 4 112 49 95 51 19 4 112 51 95 52 20 4 112 50 95 53 21 4 112 51 95 53 22 4 112 51 95 48 23 4 112 48 95 52 24 4 112 50 95 48 25 4 65 117 110 116"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
