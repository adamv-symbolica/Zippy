#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,25};
static const Space constant_1 = literal_text("36 8 1 1 1 1 1 1 1 7 8 1 1 1 1 1 1 1 12 8 1 1 1 2 1 1 1 7 8 1 1 1 2 1 1 1 8 8 1 1 1 3 1 1 1 8 8 1 1 1 3 1 1 1 9 8 1 1 1 4 1 1 1 9 8 1 1 1 4 1 1 1 10 8 1 1 1 5 1 1 1 10 8 1 1 1 5 1 1 1 11 8 1 1 1 6 1 1 1 11 8 1 1 1 6 1 1 1 12 8 1 1 1 7 1 1 1 13 8 1 1 1 7 1 1 1 18 8 1 1 1 8 1 1 1 13 8 1 1 1 8 1 1 1 14 8 1 1 1 9 1 1 1 14 8 1 1 1 9 1 1 1 15 8 1 1 1 10 1 1 1 15 8 1 1 1 10 1 1 1 16 8 1 1 1 11 1 1 1 16 8 1 1 1 11 1 1 1 17 8 1 1 1 12 1 1 1 17 8 1 1 1 12 1 1 1 18 8 1 1 1 13 1 1 1 19 8 1 1 1 13 1 1 1 24 8 1 1 1 14 1 1 1 19 8 1 1 1 14 1 1 1 20 8 1 1 1 15 1 1 1 20 8 1 1 1 15 1 1 1 21 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 22 8 1 1 1 17 1 1 1 23 8 1 1 1 18 1 1 1 23 8 1 1 1 18 1 1 1 24");
static const Space constant_2 = literal_text("36 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 9 1 1 1 3 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 4 8 1 1 1 10 1 1 1 5 8 1 1 1 11 1 1 1 5 8 1 1 1 11 1 1 1 6 8 1 1 1 12 1 1 1 1 8 1 1 1 12 1 1 1 6 8 1 1 1 13 1 1 1 7 8 1 1 1 13 1 1 1 8 8 1 1 1 14 1 1 1 8 8 1 1 1 14 1 1 1 9 8 1 1 1 15 1 1 1 9 8 1 1 1 15 1 1 1 10 8 1 1 1 16 1 1 1 10 8 1 1 1 16 1 1 1 11 8 1 1 1 17 1 1 1 11 8 1 1 1 17 1 1 1 12 8 1 1 1 18 1 1 1 7 8 1 1 1 18 1 1 1 12 8 1 1 1 19 1 1 1 13 8 1 1 1 19 1 1 1 14 8 1 1 1 20 1 1 1 14 8 1 1 1 20 1 1 1 15 8 1 1 1 21 1 1 1 15 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 17 8 1 1 1 23 1 1 1 17 8 1 1 1 23 1 1 1 18 8 1 1 1 24 1 1 1 13 8 1 1 1 24 1 1 1 18");
static const Space constant_3 = literal_text("12 4 1 1 1 1 4 1 1 1 3 4 1 1 1 5 4 1 1 1 7 4 1 1 1 9 4 1 1 1 11 4 1 1 1 13 4 1 1 1 15 4 1 1 1 17 4 1 1 1 19 4 1 1 1 21 4 1 1 1 23");
static Space routine_0(Context& c, const Space* s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  const auto v0_1_branches = branches(c,bound_space(s0));
  std::vector<Space> v0_1_outputs;
  v0_1_outputs.reserve(v0_1_branches.size());
  for (const auto& v0_1_branch : v0_1_branches) {
    const Path v0_1_head{v0_1_branch.first};
    const Space& v0_1_tail = v0_1_branch.second;
    const auto v1_2_branches = branches(c,v0_1_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_1_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const Space v4_3 = routine_1(c, v4_2, v3_3_tail);
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_1_outputs.push_back(v1_2);
  }
  const Space v0_1 = join_outputs(std::move(v0_1_outputs));
  const Space v0_3 = wrap(v0_1,constant_0);
  return v0_3;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  const Space v5_5 = unwrap(constant_2,p0);
  const Space v5_6 = restrict_to(constant_2,v5_5);
  const auto v5_7_branches = branches(c,v5_6);
  std::vector<Space> v5_7_outputs;
  v5_7_outputs.reserve(v5_7_branches.size());
  for (const auto& v5_7_branch : v5_7_branches) {
    const Path v5_7_head{v5_7_branch.first};
    const Space& v5_7_tail = v5_7_branch.second;
    const auto v6_2_branches = branches(c,v5_7_tail);
    std::vector<Space> v6_2_outputs;
    v6_2_outputs.reserve(v6_2_branches.size());
    for (const auto& v6_2_branch : v6_2_branches) {
      const Path v6_2_head{v6_2_branch.first};
      const Space& v6_2_tail = v6_2_branch.second;
      const auto v7_2_branches = branches(c,v6_2_tail);
      std::vector<Space> v7_2_outputs;
      v7_2_outputs.reserve(v7_2_branches.size());
      for (const auto& v7_2_branch : v7_2_branches) {
        const Path v7_2_head{v7_2_branch.first};
        const Space& v7_2_tail = v7_2_branch.second;
        const Space v8_2 = tails_union(v7_2_tail);
        v7_2_outputs.push_back(v8_2);
      }
      const Space v7_2 = join_outputs(std::move(v7_2_outputs));
      v6_2_outputs.push_back(v7_2);
    }
    const Space v6_2 = join_outputs(std::move(v6_2_outputs));
    v5_7_outputs.push_back(v6_2);
  }
  const Space v5_7 = join_outputs(std::move(v5_7_outputs));
  const Space v5_8 = restrict_to(constant_1,v5_7);
  const auto v5_9_branches = branches(c,v5_8);
  std::vector<Space> v5_9_outputs;
  v5_9_outputs.reserve(v5_9_branches.size());
  for (const auto& v5_9_branch : v5_9_branches) {
    const Path v5_9_head{v5_9_branch.first};
    const Space& v5_9_tail = v5_9_branch.second;
    const auto v9_2_branches = branches(c,v5_9_tail);
    std::vector<Space> v9_2_outputs;
    v9_2_outputs.reserve(v9_2_branches.size());
    for (const auto& v9_2_branch : v9_2_branches) {
      const Path v9_2_head{v9_2_branch.first};
      const Space& v9_2_tail = v9_2_branch.second;
      const auto v10_2_branches = branches(c,v9_2_tail);
      std::vector<Space> v10_2_outputs;
      v10_2_outputs.reserve(v10_2_branches.size());
      for (const auto& v10_2_branch : v10_2_branches) {
        const Path v10_2_head{v10_2_branch.first};
        const Space& v10_2_tail = v10_2_branch.second;
        const Space v11_2 = tails_union(v10_2_tail);
        v10_2_outputs.push_back(v11_2);
      }
      const Space v10_2 = join_outputs(std::move(v10_2_outputs));
      v9_2_outputs.push_back(v10_2);
    }
    const Space v9_2 = join_outputs(std::move(v9_2_outputs));
    v5_9_outputs.push_back(v9_2);
  }
  const Space v5_9 = join_outputs(std::move(v5_9_outputs));
  const Space v5_11 = unwrap(constant_2,p0);
  const Space v5_12 = subtract(v5_9,v5_11);
  const Space v5_14 = intersect(v5_12,constant_3);
  const Space v5_15 = wrap(v5_14,p0);
  return v5_15;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
