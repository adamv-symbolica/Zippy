#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("92 8 1 2 3 4 5 6 7 8 8 1 3 2 5 4 8 7 6 8 1 3 4 7 8 2 5 6 8 1 6 7 4 5 2 3 8 8 1 6 7 8 4 2 3 5 8 1 7 5 3 2 6 4 8 8 1 7 6 2 4 8 3 5 8 1 8 3 2 5 4 7 6 8 2 1 6 5 4 7 8 3 8 2 1 8 4 7 6 5 3 8 2 5 4 3 1 6 7 8 8 2 8 4 5 3 1 7 6 8 3 1 7 4 5 6 2 8 8 3 1 7 4 8 2 6 5 8 3 2 1 8 4 7 6 5 8 3 4 6 1 2 5 7 8 8 3 5 4 2 6 1 8 7 8 3 5 4 2 8 1 7 6 8 3 5 4 7 6 2 1 8 8 3 5 6 2 4 8 1 7 8 3 5 6 7 4 8 1 2 8 3 5 7 1 2 6 4 8 8 3 5 7 1 8 2 4 6 8 3 5 7 8 4 2 1 6 8 3 8 1 2 6 7 4 5 8 3 8 4 6 2 1 7 5 8 3 8 7 4 2 1 6 5 8 3 8 7 4 5 6 1 2 8 4 3 2 5 7 8 1 6 8 4 6 2 3 5 7 1 8 8 4 7 6 2 1 8 3 5 8 4 7 8 3 2 1 6 5 8 5 2 8 7 4 3 1 6 8 5 3 1 6 2 4 7 8 8 5 3 1 7 4 8 2 6 8 5 3 1 7 6 4 2 8 8 5 3 2 1 8 4 7 6 8 5 3 2 4 6 7 1 8 8 5 3 2 4 8 7 6 1 8 5 3 8 1 2 6 7 4 8 5 3 8 4 2 6 7 1 8 5 4 7 6 2 1 8 3 8 5 6 1 2 3 8 7 4 8 5 6 1 2 4 7 8 3 8 5 6 2 8 4 7 1 3 8 5 6 7 4 8 1 2 3 8 5 7 1 2 3 8 4 6 8 5 7 1 2 6 4 8 3 8 6 1 2 4 8 7 5 3 8 6 1 3 4 7 8 2 5 8 6 1 8 3 2 5 4 7 8 6 1 8 7 5 2 3 4 8 6 2 8 4 5 3 1 7 8 6 2 8 4 7 1 3 5 8 6 4 2 3 5 7 1 8 8 6 4 2 8 1 7 5 3 8 6 4 8 3 2 1 7 5 8 6 5 2 8 7 4 3 1 8 6 5 4 3 2 1 8 7 8 6 5 4 7 1 2 3 8 8 6 7 1 3 5 4 2 8 8 6 7 1 3 5 4 8 2 8 6 7 1 8 2 4 5 3 8 6 7 4 5 2 3 8 1 8 6 7 4 8 1 2 3 5 8 6 7 8 4 5 2 3 1 8 7 1 3 5 4 8 2 6 8 7 1 8 4 2 6 5 3 8 7 4 5 2 3 8 1 6 8 7 5 2 1 6 4 3 8 8 7 5 4 3 2 6 1 8 8 7 6 5 4 3 2 1 8 8 7 8 1 2 3 4 5 6 8 7 8 1 6 2 4 5 3 8 8 1 2 3 4 5 6 7 8 8 1 2 6 7 4 5 3 8 8 1 6 2 3 4 5 7 8 8 1 7 5 3 2 4 6 8 8 1 7 5 3 2 6 4 8 8 1 7 6 4 2 3 5 8 8 2 4 5 3 1 7 6 8 8 2 4 6 7 1 3 5 8 8 2 6 5 4 7 1 3 8 8 3 2 1 7 4 5 6 8 8 3 2 5 4 7 6 1 8 8 3 4 6 1 2 5 7 8 8 4 6 2 1 7 5 3 8 8 4 6 2 3 5 7 1 8 8 7 4 2 6 1 3 5 8 8 7 5 2 1 6 4 3 8 8 7 6 1 3 4 5 2 8 8 7 6 5 4 3 2 1");
static Space routine_0(Context& c);
static Space routine_0(Context& c) {
  return constant_0;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"8 1 1 50 2 1 56 3 1 54 4 1 49 5 1 51 6 1 53 7 1 55 8 1 52"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
