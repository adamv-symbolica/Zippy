#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1};
static const Space constant_2 = literal_text("77 13 1 1 1 1 1 2 2 1 1 1 1 2 2 12 1 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 1 2 2 1 1 2 1 2 2 14 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 14 1 1 1 1 2 2 2 1 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 1 1 2 2 12 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 2 2 1 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 13 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 2 2 1 2 1 1 1 2 2 10 1 1 2 1 2 2 1 1 2 2 13 1 1 2 1 2 2 2 1 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 9 1 1 2 2 2 1 1 2 2 13 1 2 1 1 1 2 2 1 1 1 1 2 2 12 1 2 1 1 1 2 2 1 1 1 2 2 11 1 2 1 1 1 2 2 1 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 12 1 2 1 1 1 2 2 1 2 1 2 2 14 1 2 1 1 1 2 2 2 1 2 1 1 2 2 9 1 2 1 1 2 2 1 2 2 12 1 2 1 2 2 1 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 1 2 1 1 1 2 2 12 1 2 1 2 2 1 2 1 1 1 2 2 10 1 2 2 1 1 1 1 1 2 2 9 1 2 2 1 1 2 1 2 2 9 1 2 2 1 2 1 1 2 2 9 1 2 2 2 1 1 1 2 2 9 1 2 2 2 1 2 1 2 2 15 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 13 2 1 1 1 1 2 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 1 1 2 1 1 2 2 13 2 1 1 1 1 2 2 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 2 1 2 1 2 2 14 2 1 1 1 1 2 2 2 1 2 1 1 2 2 11 2 1 1 1 1 2 2 2 1 2 2 14 2 1 1 1 2 2 1 1 2 1 1 1 2 2 10 2 1 1 1 2 2 1 1 2 2 12 2 1 1 1 2 2 1 2 1 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 13 2 1 1 1 2 2 2 1 2 1 1 2 2 13 2 1 1 2 2 1 1 1 1 1 1 2 2 9 2 1 1 2 2 1 1 2 2 12 2 1 1 2 2 1 2 1 1 1 2 2 13 2 1 1 2 2 2 1 1 1 1 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 13 2 1 1 2 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 2 1 1 2 1 2 2 13 2 1 2 1 2 2 2 1 2 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 10 2 1 2 1 2 2 2 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 10 2 1 2 2 1 2 1 1 2 2 11 2 1 2 2 1 2 1 2 1 2 2 7 2 1 2 2 1 2 2 10 2 1 2 2 2 1 2 1 2 2 6 2 2 1 1 2 2 6 2 2 2 1 2 2");
static const Path constant_3 = Path{2};
static const Space constant_4 = literal_text("43 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 2 1 2 2 15 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 15 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 13 1 1 1 1 2 2 1 1 1 2 1 2 2 11 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 2 1 2 1 1 2 2 14 1 1 2 1 2 2 1 1 1 1 1 1 2 2 13 1 1 2 1 2 2 1 1 1 1 1 2 2 14 1 1 2 1 2 2 1 2 1 1 1 1 2 2 13 1 1 2 1 2 2 1 2 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 11 1 1 2 2 2 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 2 1 1 2 2 15 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 13 1 2 1 1 2 2 2 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 1 2 1 2 2 11 1 2 1 2 2 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 2 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 11 1 2 1 2 2 2 1 2 1 2 2 9 1 2 2 1 1 2 1 2 2 10 1 2 2 1 2 1 1 1 2 2 10 1 2 2 2 1 1 1 1 2 2 9 1 2 2 2 1 1 1 2 2 7 1 2 2 2 1 2 2");
static const Space constant_5 = literal_text("1 1 2");
static const Space constant_6 = literal_text("120 16 2 2 1 1 1 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 1 2 2 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 2 2 18 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 1 1 2 2 2 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 17 2 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 16 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 1 2 1 2 2 1 1 2 2 16 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 14 2 2 1 1 1 2 1 2 2 2 1 1 2 2 13 2 2 1 1 1 2 2 1 1 1 1 2 2 12 2 2 1 1 1 2 2 1 2 1 2 2 12 2 2 1 1 1 2 2 2 1 1 2 2 16 2 2 1 1 2 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 1 1 2 2 14 2 2 1 1 2 1 1 1 2 2 1 1 2 2 18 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 17 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 2 1 2 2 17 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 2 12 2 2 1 1 2 1 1 2 2 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 1 1 2 1 2 2 1 1 1 2 2 16 2 2 1 1 2 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 2 2 1 1 1 1 1 2 2 12 2 2 1 1 2 2 1 1 2 1 2 2 12 2 2 1 1 2 2 1 2 1 1 2 2 12 2 2 1 1 2 2 2 1 1 1 2 2 12 2 2 1 1 2 2 2 1 2 1 2 2 18 2 2 1 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 1 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 1 2 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 2 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 2 1 2 1 1 2 2 14 2 2 1 2 1 1 1 1 2 2 2 1 2 2 17 2 2 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 13 2 2 1 2 1 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 1 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 2 1 1 2 2 1 1 1 1 1 1 2 2 12 2 2 1 2 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 1 1 1 1 2 2 14 2 2 1 2 1 1 2 2 2 1 1 1 2 2 13 2 2 1 2 1 1 2 2 2 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 1 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 1 2 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 2 1 1 2 2 15 2 2 1 2 1 2 1 2 2 2 1 2 1 2 2 13 2 2 1 2 1 2 1 2 2 2 1 2 2 14 2 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 2 1 2 1 2 2 1 2 1 1 2 2 14 2 2 1 2 1 2 2 1 2 1 2 1 2 2 10 2 2 1 2 1 2 2 1 2 2 13 2 2 1 2 1 2 2 2 1 2 1 2 2 9 2 2 1 2 2 1 1 2 2 9 2 2 1 2 2 2 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 2 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 1 2 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 2 1 2 2 16 2 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 14 2 2 2 1 1 1 1 2 2 1 1 1 2 2 17 2 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 2 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 2 1 1 2 2 15 2 2 2 1 1 1 2 2 2 1 2 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 2 1 2 1 2 2 14 2 2 2 1 1 2 1 2 2 2 1 1 2 2 14 2 2 2 1 1 2 2 1 1 1 1 1 2 2 13 2 2 2 1 1 2 2 1 1 1 1 2 2 12 2 2 2 1 1 2 2 1 2 1 2 2 14 2 2 2 1 1 2 2 2 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 15 2 2 2 1 2 1 1 2 2 1 2 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 14 2 2 2 1 2 1 2 2 1 1 1 1 2 2 15 2 2 2 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 2 1 2 1 2 2 1 1 1 2 2 16 2 2 2 1 2 1 2 2 1 2 1 1 1 1 2 2 13 2 2 2 1 2 1 2 2 1 2 1 2 2 14 2 2 2 1 2 1 2 2 2 1 2 1 2 2 12 2 2 2 1 2 2 1 1 2 1 2 2 13 2 2 2 1 2 2 1 2 1 1 1 2 2 13 2 2 2 1 2 2 2 1 1 1 1 2 2 12 2 2 2 1 2 2 2 1 1 1 2 2 10 2 2 2 1 2 2 2 1 2 2");
static const Space constant_7 = singleton(Path{});
static const Path constant_8 = Path{2,2};
static const Space constant_9 = literal_text("387 20 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 19 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 2 1 2 2 20 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 2 1 1 2 2 18 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 17 1 1 1 1 1 1 1 2 2 2 1 2 1 2 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 1 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 13 1 1 1 1 1 1 2 2 1 2 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 11 1 1 1 1 1 2 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 2 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 2 1 1 2 1 1 1 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 2 1 1 1 2 1 1 2 1 2 2 18 1 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 1 1 1 2 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 1 2 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 1 2 2 21 1 1 1 1 2 1 2 1 2 2 2 1 1 1 1 1 1 1 1 2 2 16 1 1 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 2 1 2 1 1 2 2 12 1 1 1 1 2 2 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 1 2 1 1 1 2 2 1 1 1 2 1 1 1 2 2 18 1 1 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 2 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 2 1 2 2 16 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 2 1 2 1 1 1 1 2 2 18 1 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 1 1 2 1 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 14 1 1 1 2 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 1 2 2 1 1 1 2 2 14 1 1 1 2 1 2 2 2 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 10 1 1 1 2 2 1 1 1 2 2 8 1 1 1 2 2 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 15 1 1 2 1 1 1 2 2 1 2 1 2 1 2 2 14 1 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 2 1 2 1 1 2 1 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 2 1 1 2 1 2 2 18 1 1 2 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 15 1 1 2 1 1 2 2 1 1 1 1 1 1 2 2 14 1 1 2 1 1 2 2 1 1 2 1 1 2 2 15 1 1 2 1 1 2 2 2 1 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 12 1 1 2 1 2 2 1 1 2 1 2 2 17 1 1 2 1 2 2 1 2 1 1 1 1 1 1 1 2 2 14 1 1 2 1 2 2 2 1 2 1 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 8 1 1 2 2 1 1 2 2 8 1 1 2 2 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 17 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 15 1 2 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 1 1 2 1 2 2 1 1 2 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 13 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 2 1 1 2 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 14 1 2 1 1 2 2 2 1 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 2 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 19 1 2 1 2 1 1 1 1 2 2 2 1 2 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 1 2 1 2 1 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 2 1 1 1 2 2 1 1 1 2 1 1 1 2 2 18 1 2 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 20 1 2 1 2 1 1 2 1 2 2 1 2 1 2 1 1 2 1 2 2 20 1 2 1 2 1 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 20 1 2 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 16 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 2 16 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 2 16 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 19 1 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 1 2 2 18 1 2 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 1 2 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 14 1 2 1 2 1 2 2 1 1 1 1 1 2 2 15 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 14 1 2 1 2 1 2 2 1 2 1 2 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 10 1 2 1 2 2 2 1 1 2 2 11 1 2 2 1 1 1 2 1 1 2 2 8 1 2 2 1 1 1 2 2 6 1 2 2 1 2 2 21 2 1 1 1 1 1 1 1 1 2 2 1 1 1 1 2 1 2 1 2 2 22 2 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 19 2 1 1 1 1 1 1 1 1 2 2 2 1 1 1 2 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 15 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 2 1 1 1 1 1 2 2 1 2 1 1 2 2 16 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 1 1 2 1 2 2 15 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 2 1 2 1 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 2 1 1 1 2 1 2 2 1 2 1 2 1 1 2 2 19 2 1 1 1 2 1 2 2 2 1 1 1 1 1 1 1 1 2 2 16 2 1 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 11 2 1 1 1 2 2 2 1 1 2 2 10 2 1 1 1 2 2 2 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 20 2 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 1 2 1 1 1 2 2 17 2 1 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 2 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 16 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 17 2 1 1 2 1 1 2 2 2 1 1 2 1 1 1 2 2 16 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 2 1 2 1 1 2 1 1 2 2 18 2 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 13 2 1 1 2 1 2 2 1 1 1 1 2 2 14 2 1 1 2 1 2 2 2 1 1 2 1 2 2 15 2 1 1 2 1 2 2 2 1 2 1 1 1 2 2 10 2 1 1 2 2 1 2 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 2 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 14 2 1 2 1 1 1 2 2 1 1 2 1 2 2 15 2 1 2 1 1 1 2 2 2 1 1 2 1 2 2 16 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 2 1 1 2 1 1 2 2 19 2 1 2 1 1 2 1 2 2 1 2 1 2 1 1 1 1 2 2 18 2 1 2 1 1 2 1 2 2 2 1 1 2 1 1 1 2 2 18 2 1 2 1 1 2 1 2 2 2 1 2 1 1 2 1 2 2 13 2 1 2 1 1 2 2 1 1 1 1 2 2 13 2 1 2 1 1 2 2 1 2 1 1 2 2 14 2 1 2 1 1 2 2 2 1 2 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 21 2 1 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 1 1 2 2 20 2 1 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 2 1 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 1 2 2 17 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 2 2 16 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 14 2 1 2 1 2 2 1 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 8 2 1 2 2 1 1 2 2 10 2 1 2 2 2 1 1 1 2 2 8 2 1 2 2 2 1 2 2");
static const Space constant_10 = literal_text("1 11 1 2 1 1 2 1 1 2 1 2 2");
static const Path constant_11 = Path{};
static const std::vector<Path> constant_12 = paths_text("133 8 1 1 1 2 1 1 2 2 8 1 2 1 2 1 1 2 2 8 1 1 1 1 2 1 2 2 8 1 2 1 1 2 1 2 2 8 1 1 2 1 2 1 2 2 8 2 1 2 1 2 1 2 2 9 1 1 1 1 1 1 1 2 2 9 2 1 1 1 1 1 1 2 2 9 1 2 1 1 1 1 1 2 2 9 1 1 2 1 1 1 1 2 2 9 2 1 2 1 1 1 1 2 2 8 2 1 1 2 1 1 2 2 9 1 1 1 2 1 1 1 2 2 9 1 2 1 2 1 1 1 2 2 9 1 1 1 1 2 1 1 2 2 9 2 1 1 1 2 1 1 2 2 9 1 2 1 1 2 1 1 2 2 9 1 1 2 1 2 1 1 2 2 9 2 1 2 1 2 1 1 2 2 9 1 1 1 1 1 2 1 2 2 9 2 1 1 1 1 2 1 2 2 9 1 2 1 1 1 2 1 2 2 9 2 1 1 2 1 1 1 2 2 9 1 1 2 1 1 2 1 2 2 9 1 1 1 2 1 2 1 2 2 9 2 1 1 2 1 2 1 2 2 9 1 2 1 2 1 2 1 2 2 10 1 1 1 1 1 1 1 1 2 2 10 2 1 1 1 1 1 1 1 2 2 10 1 2 1 1 1 1 1 1 2 2 10 1 1 2 1 1 1 1 1 2 2 10 2 1 2 1 1 1 1 1 2 2 10 1 1 1 2 1 1 1 1 2 2 9 2 1 2 1 1 2 1 2 2 10 2 1 1 2 1 1 1 1 2 2 10 1 1 1 1 2 1 1 1 2 2 10 2 1 1 1 2 1 1 1 2 2 10 1 2 1 1 2 1 1 1 2 2 10 1 1 2 1 2 1 1 1 2 2 10 2 1 2 1 2 1 1 1 2 2 10 1 1 1 1 1 2 1 1 2 2 10 2 1 1 1 1 2 1 1 2 2 10 1 2 1 1 1 2 1 1 2 2 10 1 1 2 1 1 2 1 1 2 2 10 1 2 1 2 1 1 1 1 2 2 10 2 1 2 1 1 2 1 1 2 2 10 2 1 1 2 1 2 1 1 2 2 10 1 2 1 2 1 2 1 1 2 2 10 1 1 1 1 1 1 2 1 2 2 10 2 1 1 1 1 1 2 1 2 2 10 1 2 1 1 1 1 2 1 2 2 10 1 1 2 1 1 1 2 1 2 2 10 2 1 2 1 1 1 2 1 2 2 10 1 1 1 2 1 1 2 1 2 2 10 2 1 1 2 1 1 2 1 2 2 10 1 1 1 2 1 2 1 1 2 2 10 1 2 1 2 1 1 2 1 2 2 10 2 1 1 1 2 1 2 1 2 2 10 1 2 1 1 2 1 2 1 2 2 10 1 1 2 1 2 1 2 1 2 2 10 2 1 2 1 2 1 2 1 2 2 11 1 1 1 1 1 1 1 1 1 2 2 10 1 1 1 1 2 1 2 1 2 2 11 2 1 1 1 1 1 1 1 1 2 2 8 2 1 1 1 2 1 2 2 3 1 2 2 5 1 1 1 2 2 4 1 1 2 2 4 2 1 2 2 6 2 1 1 1 2 2 5 2 1 1 2 2 5 1 2 1 2 2 8 1 1 1 1 1 1 2 2 7 1 1 2 1 1 2 2 8 2 1 1 1 1 1 2 2 6 1 2 1 1 2 2 7 2 1 2 1 1 2 2 7 1 1 1 2 1 2 2 6 1 1 1 1 2 2 7 2 1 1 2 1 2 2 8 2 1 2 1 1 1 2 2 6 1 1 2 1 2 2 11 1 2 1 1 1 1 1 1 1 2 2 11 1 1 2 1 1 1 1 1 1 2 2 11 2 1 2 1 1 1 1 1 1 2 2 11 1 1 1 2 1 1 1 1 1 2 2 11 2 1 1 2 1 1 1 1 1 2 2 11 1 2 1 2 1 1 1 1 1 2 2 7 2 1 1 1 1 2 2 11 1 1 1 1 2 1 1 1 1 2 2 11 2 1 1 1 2 1 1 1 1 2 2 11 1 2 1 1 2 1 1 1 1 2 2 11 1 1 2 1 2 1 1 1 1 2 2 11 2 1 2 1 2 1 1 1 1 2 2 11 1 1 1 1 1 2 1 1 1 2 2 11 2 1 1 1 1 2 1 1 1 2 2 11 1 2 1 1 1 2 1 1 1 2 2 11 1 1 2 1 1 2 1 1 1 2 2 11 2 1 2 1 1 2 1 1 1 2 2 8 1 2 1 1 1 1 2 2 11 1 1 1 2 1 2 1 1 1 2 2 11 2 1 1 2 1 2 1 1 1 2 2 11 1 2 1 2 1 2 1 1 1 2 2 11 1 1 1 1 1 1 2 1 1 2 2 11 2 1 1 1 1 1 2 1 1 2 2 11 1 2 1 1 1 1 2 1 1 2 2 11 1 1 2 1 1 1 2 1 1 2 2 11 2 1 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 1 1 2 2 11 2 1 1 2 1 1 2 1 1 2 2 7 1 2 1 1 1 2 2 11 1 2 1 2 1 1 2 1 1 2 2 11 1 1 1 1 2 1 2 1 1 2 2 11 2 1 1 1 2 1 2 1 1 2 2 11 1 2 1 1 2 1 2 1 1 2 2 11 1 1 2 1 2 1 2 1 1 2 2 11 2 1 2 1 2 1 2 1 1 2 2 11 1 1 1 1 1 1 1 2 1 2 2 11 2 1 1 1 1 1 1 2 1 2 2 11 1 2 1 1 1 1 1 2 1 2 2 11 1 1 2 1 1 1 1 2 1 2 2 6 2 1 2 1 2 2 11 2 1 2 1 1 1 1 2 1 2 2 11 1 1 1 2 1 1 1 2 1 2 2 11 2 1 1 2 1 1 1 2 1 2 2 11 1 2 1 2 1 1 1 2 1 2 2 11 1 1 1 1 2 1 1 2 1 2 2 11 2 1 1 1 2 1 1 2 1 2 2 8 1 1 2 1 1 1 2 2 7 1 2 1 2 1 2 2 7 1 1 1 1 1 2 2 2 2 2 11 1 2 1 1 2 1 1 2 1 2 2");
static Space routine_0(Context& c);
static Space routine_120(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_68(Context& c, const Space& s0);
static Space routine_69(Context& c, const Space& s0);
static Space routine_73(Context& c, const Space& s0);
static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_226(Context& c, const Path& p0, const Space& s0);
static Space routine_228(Context& c, const Path& p0, const Space& s0);
static Space routine_230(Context& c, const Path& p0, const Space& s0);
static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_190(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_220(Context& c, const Path& p0, const Space& s0);
static Space routine_222(Context& c, const Path& p0, const Space& s0);
static Space routine_224(Context& c, const Path& p0, const Space& s0);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_227(Context& c, const Path& p0, const Space& s0);
static Space routine_229(Context& c, const Path& p0, const Space& s0);
static Space routine_231(Context& c, const Path& p0, const Space& s0);
static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_221(Context& c, const Path& p0, const Space& s0);
static Space routine_223(Context& c, const Path& p0, const Space& s0);
static Space routine_225(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_93(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_104(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_105(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_84(Context& c, const Path& p0, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Space& s0);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_121(Context& c, const Path& p0, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_122(Context& c, const Path& p0, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Space& s0);
static Space routine_126(Context& c, const Path& p0, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_130(Context& c, const Path& p0, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Space& s0);
static Space routine_178(Context& c, const Path& p0, const Space& s0);
static Space routine_180(Context& c, const Path& p0, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_177(Context& c, const Path& p0, const Space& s0);
static Space routine_179(Context& c, const Path& p0, const Space& s0);
static Space routine_181(Context& c, const Path& p0, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Space& s0);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_64(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_184(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_89(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Space& s0);
static Space routine_170(Context& c, const Path& p0, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_65(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_185(Context& c, const Path& p0, const Space& s0);
static Space routine_187(Context& c, const Path& p0, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_90(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_208(Context& c, const Path& p0, const Space& s0);
static Space routine_210(Context& c, const Path& p0, const Space& s0);
static Space routine_212(Context& c, const Path& p0, const Space& s0);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_194(Context& c, const Path& p0, const Space& s0);
static Space routine_196(Context& c, const Path& p0, const Space& s0);
static Space routine_198(Context& c, const Path& p0, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_209(Context& c, const Path& p0, const Space& s0);
static Space routine_211(Context& c, const Path& p0, const Space& s0);
static Space routine_213(Context& c, const Path& p0, const Space& s0);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_195(Context& c, const Path& p0, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Space& s0);
static Space routine_199(Context& c, const Path& p0, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_214(Context& c, const Path& p0, const Space& s0);
static Space routine_216(Context& c, const Path& p0, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Space& s0);
static Space routine_218(Context& c, const Path& p0, const Space& s0);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_136(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_200(Context& c, const Path& p0, const Space& s0);
static Space routine_202(Context& c, const Path& p0, const Space& s0);
static Space routine_204(Context& c, const Path& p0, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_215(Context& c, const Path& p0, const Space& s0);
static Space routine_217(Context& c, const Path& p0, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Space& s0);
static Space routine_219(Context& c, const Path& p0, const Space& s0);
static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_137(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_201(Context& c, const Path& p0, const Space& s0);
static Space routine_203(Context& c, const Path& p0, const Space& s0);
static Space routine_205(Context& c, const Path& p0, const Space& s0);
static Space routine_82(Context& c, const Space& s0);
static Space routine_51(Context& c, const Space& s0);
static Space routine_36(Context& c, const Space& s0);
static Space routine_39(Context& c, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_95(Context& c, const Path& p0, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c) {
  Space v0_8;
  if (!constant_0.empty()) {
    const Space v1_3 = routine_1(c, constant_1, constant_2);
    const Space v1_6 = routine_2(c, constant_3, constant_4);
    const Space v1_7 = unite(v1_3,v1_6);
    v0_8 = compose(constant_0,v1_7);
  }
  Space v0_14_result;
  for (int v0_14_label = 1; v0_14_label <= 2; ++v0_14_label) {
    const Space v0_14_tail = child(v0_8,v0_14_label);
    if (v0_14_tail.empty()) continue;
    const Path v0_14_head{v0_14_label};
    const Space v2_2 = singleton(v0_14_head);
    const Space v2_3 = intersect(constant_5,v2_2);
    const Space v2_4 = (has_head(v2_3) ? constant_7 : Space{});
    const Space v2_5 = subtract(constant_0,v2_4);
    Space v2_7;
    if (!v2_5.empty()) {
      const Space v3_6 = routine_3(c, v0_14_head, v0_14_tail, constant_6);
      v2_7 = compose(v2_5,v3_6);
    }
    const Space v2_8 = intersect(constant_5,v2_2);
    const Space v2_9 = (has_head(v2_8) ? constant_7 : Space{});
    Space v2_11;
    if (!v2_9.empty()) {
      const Space v4_10 = routine_4(c, v0_14_head, v0_14_tail, constant_6);
      v2_11 = compose(v2_9,v4_10);
    }
    const Space v2_12 = unite(v2_7,v2_11);
    v0_14_result = unite(v0_14_result,v2_12);
  }
  const Space v0_14 = std::move(v0_14_result);
  Space v0_23;
  if (!constant_0.empty()) {
    const Space v5_18 = routine_5(c, constant_1, constant_2, constant_6);
    const Space v5_21 = routine_6(c, constant_3, constant_4, constant_6);
    const Space v5_22 = unite(v5_18,v5_21);
    v0_23 = compose(constant_0,v5_22);
  }
  const Space v0_24 = unite(v0_14,v0_23);
  const Space v0_26 = wrap(v0_24,constant_8);
  return v0_26;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v6_11_result;
  for (int v6_11_label = 1; v6_11_label <= 2; ++v6_11_label) {
    const Space v6_11_tail = child(s0,v6_11_label);
    if (v6_11_tail.empty()) continue;
    const Path v6_11_head{v6_11_label};
    const Space v7_2 = singleton(v6_11_head);
    const Space v7_3 = intersect(constant_5,v7_2);
    const Space v7_4 = (has_head(v7_3) ? constant_7 : Space{});
    const Space v7_5 = subtract(constant_0,v7_4);
    Space v7_8;
    if (!v7_5.empty()) {
      const Path v8_6 = concat_path(p0,v6_11_head);
      Space v8_7_result;
      for (int v8_7_label = 1; v8_7_label <= 2; ++v8_7_label) {
        const Space v8_7_tail = child(v6_11_tail,v8_7_label);
        if (v8_7_tail.empty()) continue;
        const Path v8_7_head{v8_7_label};
        const Space v9_2 = singleton(v8_7_head);
        const Space v9_3 = intersect(constant_5,v9_2);
        const Space v9_4 = (has_head(v9_3) ? constant_7 : Space{});
        const Space v9_5 = subtract(constant_0,v9_4);
        Space v9_8;
        if (!v9_5.empty()) {
          const Path v10_6 = concat_path(v8_6,v8_7_head);
          const Space v10_7 = routine_7(c, v10_6, v8_7_tail);
          v9_8 = compose(v9_5,v10_7);
        }
        const Space v9_9 = intersect(constant_5,v9_2);
        const Space v9_10 = (has_head(v9_9) ? constant_7 : Space{});
        Space v9_12;
        if (!v9_10.empty()) {
          const Path v11_6 = concat_path(v8_6,v8_7_head);
          const Space v11_11 = routine_8(c, v11_6, v8_7_tail);
          v9_12 = compose(v9_10,v11_11);
        }
        const Space v9_13 = unite(v9_8,v9_12);
        v8_7_result = unite(v8_7_result,v9_13);
      }
      const Space v8_7 = std::move(v8_7_result);
      v7_8 = compose(v7_5,v8_7);
    }
    const Space v7_9 = intersect(constant_5,v7_2);
    const Space v7_10 = (has_head(v7_9) ? constant_7 : Space{});
    Space v7_12;
    if (!v7_10.empty()) {
      const Path v12_6 = concat_path(p0,v6_11_head);
      Space v12_11_result;
      for (int v12_11_label = 1; v12_11_label <= 2; ++v12_11_label) {
        const Space v12_11_tail = child(v6_11_tail,v12_11_label);
        if (v12_11_tail.empty()) continue;
        const Path v12_11_head{v12_11_label};
        const Space v13_2 = singleton(v12_11_head);
        const Space v13_3 = intersect(constant_5,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_7 : Space{});
        const Space v13_5 = subtract(constant_0,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_11_head);
          const Space v14_7 = routine_7(c, v14_6, v12_11_tail);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_5,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_7 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_11_head);
          const Space v15_11 = routine_9(c, v15_6, v12_11_tail);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_11_result = unite(v12_11_result,v13_13);
      }
      const Space v12_11 = std::move(v12_11_result);
      v7_12 = compose(v7_10,v12_11);
    }
    const Space v7_13 = unite(v7_8,v7_12);
    v6_11_result = unite(v6_11_result,v7_13);
  }
  const Space v6_11 = std::move(v6_11_result);
  return v6_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v16_11_result;
  for (int v16_11_label = 1; v16_11_label <= 2; ++v16_11_label) {
    const Space v16_11_tail = child(s0,v16_11_label);
    if (v16_11_tail.empty()) continue;
    const Path v16_11_head{v16_11_label};
    const Space v17_2 = singleton(v16_11_head);
    const Space v17_3 = intersect(constant_5,v17_2);
    const Space v17_4 = (has_head(v17_3) ? constant_7 : Space{});
    const Space v17_5 = subtract(constant_0,v17_4);
    Space v17_8;
    if (!v17_5.empty()) {
      const Path v18_6 = concat_path(p0,v16_11_head);
      Space v18_7_result;
      for (int v18_7_label = 1; v18_7_label <= 2; ++v18_7_label) {
        const Space v18_7_tail = child(v16_11_tail,v18_7_label);
        if (v18_7_tail.empty()) continue;
        const Path v18_7_head{v18_7_label};
        const Space v19_2 = singleton(v18_7_head);
        const Space v19_3 = intersect(constant_5,v19_2);
        const Space v19_4 = (has_head(v19_3) ? constant_7 : Space{});
        const Space v19_5 = subtract(constant_0,v19_4);
        Space v19_8;
        if (!v19_5.empty()) {
          const Path v20_6 = concat_path(v18_6,v18_7_head);
          const Space v20_7 = routine_7(c, v20_6, v18_7_tail);
          v19_8 = compose(v19_5,v20_7);
        }
        const Space v19_9 = intersect(constant_5,v19_2);
        const Space v19_10 = (has_head(v19_9) ? constant_7 : Space{});
        Space v19_12;
        if (!v19_10.empty()) {
          const Path v21_6 = concat_path(v18_6,v18_7_head);
          const Space v21_11 = routine_8(c, v21_6, v18_7_tail);
          v19_12 = compose(v19_10,v21_11);
        }
        const Space v19_13 = unite(v19_8,v19_12);
        v18_7_result = unite(v18_7_result,v19_13);
      }
      const Space v18_7 = std::move(v18_7_result);
      v17_8 = compose(v17_5,v18_7);
    }
    const Space v17_9 = intersect(constant_5,v17_2);
    const Space v17_10 = (has_head(v17_9) ? constant_7 : Space{});
    Space v17_12;
    if (!v17_10.empty()) {
      const Path v22_6 = concat_path(p0,v16_11_head);
      Space v22_11_result;
      for (int v22_11_label = 1; v22_11_label <= 2; ++v22_11_label) {
        const Space v22_11_tail = child(v16_11_tail,v22_11_label);
        if (v22_11_tail.empty()) continue;
        const Path v22_11_head{v22_11_label};
        const Space v23_2 = singleton(v22_11_head);
        const Space v23_3 = intersect(constant_5,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_7 : Space{});
        const Space v23_5 = subtract(constant_0,v23_4);
        Space v23_7;
        if (!v23_5.empty()) {
          const Space v24_6 = routine_10(c, v22_11_head, v22_6, v22_11_tail);
          v23_7 = compose(v23_5,v24_6);
        }
        const Space v23_8 = intersect(constant_5,v23_2);
        const Space v23_9 = (has_head(v23_8) ? constant_7 : Space{});
        Space v23_11;
        if (!v23_9.empty()) {
          const Space v25_10 = routine_11(c, v22_11_head, v22_6, v22_11_tail);
          v23_11 = compose(v23_9,v25_10);
        }
        const Space v23_12 = unite(v23_7,v23_11);
        v22_11_result = unite(v22_11_result,v23_12);
      }
      const Space v22_11 = std::move(v22_11_result);
      v17_12 = compose(v17_10,v22_11);
    }
    const Space v17_13 = unite(v17_8,v17_12);
    v16_11_result = unite(v16_11_result,v17_13);
  }
  const Space v16_11 = std::move(v16_11_result);
  return v16_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v26_12_result;
  for (int v26_12_label = 1; v26_12_label <= 2; ++v26_12_label) {
    const Space v26_12_tail = child(s0,v26_12_label);
    if (v26_12_tail.empty()) continue;
    const Path v26_12_head{v26_12_label};
    const Space v27_2 = singleton(v26_12_head);
    const Space v27_3 = intersect(constant_5,v27_2);
    const Space v27_4 = (has_head(v27_3) ? constant_7 : Space{});
    const Space v27_5 = subtract(constant_0,v27_4);
    Space v27_8;
    if (!v27_5.empty()) {
      const Path v28_6 = concat_path(p0,v26_12_head);
      Space v28_7_result;
      for (int v28_7_label = 1; v28_7_label <= 2; ++v28_7_label) {
        const Space v28_7_tail = child(v26_12_tail,v28_7_label);
        if (v28_7_tail.empty()) continue;
        const Path v28_7_head{v28_7_label};
        const Space v29_2 = singleton(v28_7_head);
        const Space v29_3 = intersect(constant_5,v29_2);
        const Space v29_4 = (has_head(v29_3) ? constant_7 : Space{});
        const Space v29_5 = subtract(constant_0,v29_4);
        Space v29_8;
        if (!v29_5.empty()) {
          const Path v30_6 = concat_path(v28_6,v28_7_head);
          const Space v30_7 = routine_12(c, v30_6, v28_7_tail, s1);
          v29_8 = compose(v29_5,v30_7);
        }
        const Space v29_9 = intersect(constant_5,v29_2);
        const Space v29_10 = (has_head(v29_9) ? constant_7 : Space{});
        Space v29_12;
        if (!v29_10.empty()) {
          const Path v31_6 = concat_path(v28_6,v28_7_head);
          const Space v31_11 = routine_13(c, v31_6, v28_7_tail, s1);
          v29_12 = compose(v29_10,v31_11);
        }
        const Space v29_13 = unite(v29_8,v29_12);
        v28_7_result = unite(v28_7_result,v29_13);
      }
      const Space v28_7 = std::move(v28_7_result);
      v27_8 = compose(v27_5,v28_7);
    }
    const Space v27_9 = intersect(constant_5,v27_2);
    const Space v27_10 = (has_head(v27_9) ? constant_7 : Space{});
    Space v27_12;
    if (!v27_10.empty()) {
      const Path v32_6 = concat_path(p0,v26_12_head);
      Space v32_11_result;
      for (int v32_11_label = 1; v32_11_label <= 2; ++v32_11_label) {
        const Space v32_11_tail = child(v26_12_tail,v32_11_label);
        if (v32_11_tail.empty()) continue;
        const Path v32_11_head{v32_11_label};
        const Space v33_2 = singleton(v32_11_head);
        const Space v33_3 = intersect(constant_5,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_7 : Space{});
        const Space v33_5 = subtract(constant_0,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v32_6,v32_11_head);
          const Space v34_7 = routine_12(c, v34_6, v32_11_tail, s1);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_5,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_7 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v32_6,v32_11_head);
          const Space v35_11 = routine_14(c, v35_6, v32_11_tail, s1);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_11_result = unite(v32_11_result,v33_13);
      }
      const Space v32_11 = std::move(v32_11_result);
      v27_12 = compose(v27_10,v32_11);
    }
    const Space v27_13 = unite(v27_8,v27_12);
    v26_12_result = unite(v26_12_result,v27_13);
  }
  const Space v26_12 = std::move(v26_12_result);
  return v26_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v36_12_result;
  for (int v36_12_label = 1; v36_12_label <= 2; ++v36_12_label) {
    const Space v36_12_tail = child(s0,v36_12_label);
    if (v36_12_tail.empty()) continue;
    const Path v36_12_head{v36_12_label};
    const Space v37_2 = singleton(v36_12_head);
    const Space v37_3 = intersect(constant_5,v37_2);
    const Space v37_4 = (has_head(v37_3) ? constant_7 : Space{});
    const Space v37_5 = subtract(constant_0,v37_4);
    Space v37_8;
    if (!v37_5.empty()) {
      const Path v38_6 = concat_path(p0,v36_12_head);
      Space v38_7_result;
      for (int v38_7_label = 1; v38_7_label <= 2; ++v38_7_label) {
        const Space v38_7_tail = child(v36_12_tail,v38_7_label);
        if (v38_7_tail.empty()) continue;
        const Path v38_7_head{v38_7_label};
        const Space v39_2 = singleton(v38_7_head);
        const Space v39_3 = intersect(constant_5,v39_2);
        const Space v39_4 = (has_head(v39_3) ? constant_7 : Space{});
        const Space v39_5 = subtract(constant_0,v39_4);
        Space v39_8;
        if (!v39_5.empty()) {
          const Path v40_6 = concat_path(v38_6,v38_7_head);
          const Space v40_7 = routine_12(c, v40_6, v38_7_tail, s1);
          v39_8 = compose(v39_5,v40_7);
        }
        const Space v39_9 = intersect(constant_5,v39_2);
        const Space v39_10 = (has_head(v39_9) ? constant_7 : Space{});
        Space v39_12;
        if (!v39_10.empty()) {
          const Path v41_6 = concat_path(v38_6,v38_7_head);
          const Space v41_11 = routine_13(c, v41_6, v38_7_tail, s1);
          v39_12 = compose(v39_10,v41_11);
        }
        const Space v39_13 = unite(v39_8,v39_12);
        v38_7_result = unite(v38_7_result,v39_13);
      }
      const Space v38_7 = std::move(v38_7_result);
      v37_8 = compose(v37_5,v38_7);
    }
    const Space v37_9 = intersect(constant_5,v37_2);
    const Space v37_10 = (has_head(v37_9) ? constant_7 : Space{});
    Space v37_12;
    if (!v37_10.empty()) {
      const Path v42_6 = concat_path(p0,v36_12_head);
      Space v42_11_result;
      for (int v42_11_label = 1; v42_11_label <= 2; ++v42_11_label) {
        const Space v42_11_tail = child(v36_12_tail,v42_11_label);
        if (v42_11_tail.empty()) continue;
        const Path v42_11_head{v42_11_label};
        const Space v43_2 = singleton(v42_11_head);
        const Space v43_3 = intersect(constant_5,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_7 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_7;
        if (!v43_5.empty()) {
          const Space v44_6 = routine_15(c, v42_11_head, v42_6, v42_11_tail, s1);
          v43_7 = compose(v43_5,v44_6);
        }
        const Space v43_8 = intersect(constant_5,v43_2);
        const Space v43_9 = (has_head(v43_8) ? constant_7 : Space{});
        Space v43_11;
        if (!v43_9.empty()) {
          const Space v45_10 = routine_16(c, v42_11_head, v42_6, v42_11_tail, s1);
          v43_11 = compose(v43_9,v45_10);
        }
        const Space v43_12 = unite(v43_7,v43_11);
        v42_11_result = unite(v42_11_result,v43_12);
      }
      const Space v42_11 = std::move(v42_11_result);
      v37_12 = compose(v37_10,v42_11);
    }
    const Space v37_13 = unite(v37_8,v37_12);
    v36_12_result = unite(v36_12_result,v37_13);
  }
  const Space v36_12 = std::move(v36_12_result);
  return v36_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v46_12_result;
  for (int v46_12_label = 1; v46_12_label <= 2; ++v46_12_label) {
    const Space v46_12_tail = child(s0,v46_12_label);
    if (v46_12_tail.empty()) continue;
    const Path v46_12_head{v46_12_label};
    const Space v47_2 = singleton(v46_12_head);
    const Space v47_3 = intersect(constant_5,v47_2);
    const Space v47_4 = (has_head(v47_3) ? constant_7 : Space{});
    const Space v47_5 = subtract(constant_0,v47_4);
    Space v47_8;
    if (!v47_5.empty()) {
      const Path v48_6 = concat_path(p0,v46_12_head);
      Space v48_7_result;
      for (int v48_7_label = 1; v48_7_label <= 2; ++v48_7_label) {
        const Space v48_7_tail = child(v46_12_tail,v48_7_label);
        if (v48_7_tail.empty()) continue;
        const Path v48_7_head{v48_7_label};
        const Space v49_2 = singleton(v48_7_head);
        const Space v49_3 = intersect(constant_5,v49_2);
        const Space v49_4 = (has_head(v49_3) ? constant_7 : Space{});
        const Space v49_5 = subtract(constant_0,v49_4);
        Space v49_8;
        if (!v49_5.empty()) {
          const Path v50_6 = concat_path(v48_6,v48_7_head);
          const Space v50_7 = routine_17(c, v50_6, v48_7_tail, s1);
          v49_8 = compose(v49_5,v50_7);
        }
        const Space v49_9 = intersect(constant_5,v49_2);
        const Space v49_10 = (has_head(v49_9) ? constant_7 : Space{});
        Space v49_12;
        if (!v49_10.empty()) {
          const Path v51_6 = concat_path(v48_6,v48_7_head);
          const Space v51_11 = routine_18(c, v51_6, v48_7_tail, s1);
          v49_12 = compose(v49_10,v51_11);
        }
        const Space v49_13 = unite(v49_8,v49_12);
        v48_7_result = unite(v48_7_result,v49_13);
      }
      const Space v48_7 = std::move(v48_7_result);
      v47_8 = compose(v47_5,v48_7);
    }
    const Space v47_9 = intersect(constant_5,v47_2);
    const Space v47_10 = (has_head(v47_9) ? constant_7 : Space{});
    Space v47_12;
    if (!v47_10.empty()) {
      const Path v52_6 = concat_path(p0,v46_12_head);
      Space v52_11_result;
      for (int v52_11_label = 1; v52_11_label <= 2; ++v52_11_label) {
        const Space v52_11_tail = child(v46_12_tail,v52_11_label);
        if (v52_11_tail.empty()) continue;
        const Path v52_11_head{v52_11_label};
        const Space v53_2 = singleton(v52_11_head);
        const Space v53_3 = intersect(constant_5,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_7 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_11_head);
          const Space v54_7 = routine_17(c, v54_6, v52_11_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_5,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_7 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_11_head);
          const Space v55_11 = routine_19(c, v55_6, v52_11_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_11_result = unite(v52_11_result,v53_13);
      }
      const Space v52_11 = std::move(v52_11_result);
      v47_12 = compose(v47_10,v52_11);
    }
    const Space v47_13 = unite(v47_8,v47_12);
    v46_12_result = unite(v46_12_result,v47_13);
  }
  const Space v46_12 = std::move(v46_12_result);
  return v46_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v56_12_result;
  for (int v56_12_label = 1; v56_12_label <= 2; ++v56_12_label) {
    const Space v56_12_tail = child(s0,v56_12_label);
    if (v56_12_tail.empty()) continue;
    const Path v56_12_head{v56_12_label};
    const Space v57_2 = singleton(v56_12_head);
    const Space v57_3 = intersect(constant_5,v57_2);
    const Space v57_4 = (has_head(v57_3) ? constant_7 : Space{});
    const Space v57_5 = subtract(constant_0,v57_4);
    Space v57_8;
    if (!v57_5.empty()) {
      const Path v58_6 = concat_path(p0,v56_12_head);
      Space v58_7_result;
      for (int v58_7_label = 1; v58_7_label <= 2; ++v58_7_label) {
        const Space v58_7_tail = child(v56_12_tail,v58_7_label);
        if (v58_7_tail.empty()) continue;
        const Path v58_7_head{v58_7_label};
        const Space v59_2 = singleton(v58_7_head);
        const Space v59_3 = intersect(constant_5,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_7 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v58_6,v58_7_head);
          const Space v60_7 = routine_17(c, v60_6, v58_7_tail, s1);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_5,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_7 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v58_6,v58_7_head);
          const Space v61_11 = routine_18(c, v61_6, v58_7_tail, s1);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_7_result = unite(v58_7_result,v59_13);
      }
      const Space v58_7 = std::move(v58_7_result);
      v57_8 = compose(v57_5,v58_7);
    }
    const Space v57_9 = intersect(constant_5,v57_2);
    const Space v57_10 = (has_head(v57_9) ? constant_7 : Space{});
    Space v57_12;
    if (!v57_10.empty()) {
      const Path v62_6 = concat_path(p0,v56_12_head);
      Space v62_11_result;
      for (int v62_11_label = 1; v62_11_label <= 2; ++v62_11_label) {
        const Space v62_11_tail = child(v56_12_tail,v62_11_label);
        if (v62_11_tail.empty()) continue;
        const Path v62_11_head{v62_11_label};
        const Space v63_2 = singleton(v62_11_head);
        const Space v63_3 = intersect(constant_5,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_7 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_7;
        if (!v63_5.empty()) {
          const Space v64_6 = routine_20(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_7 = compose(v63_5,v64_6);
        }
        const Space v63_8 = intersect(constant_5,v63_2);
        const Space v63_9 = (has_head(v63_8) ? constant_7 : Space{});
        Space v63_11;
        if (!v63_9.empty()) {
          const Space v65_10 = routine_21(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_11 = compose(v63_9,v65_10);
        }
        const Space v63_12 = unite(v63_7,v63_11);
        v62_11_result = unite(v62_11_result,v63_12);
      }
      const Space v62_11 = std::move(v62_11_result);
      v57_12 = compose(v57_10,v62_11);
    }
    const Space v57_13 = unite(v57_8,v57_12);
    v56_12_result = unite(v56_12_result,v57_13);
  }
  const Space v56_12 = std::move(v56_12_result);
  return v56_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v66_11_result;
  for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
    const Space v66_11_tail = child(s0,v66_11_label);
    if (v66_11_tail.empty()) continue;
    const Path v66_11_head{v66_11_label};
    const Space v67_2 = singleton(v66_11_head);
    const Space v67_3 = intersect(constant_5,v67_2);
    const Space v67_4 = (has_head(v67_3) ? constant_7 : Space{});
    const Space v67_5 = subtract(constant_0,v67_4);
    Space v67_8;
    if (!v67_5.empty()) {
      const Path v68_6 = concat_path(p0,v66_11_head);
      Space v68_7_result;
      for (int v68_7_label = 1; v68_7_label <= 2; ++v68_7_label) {
        const Space v68_7_tail = child(v66_11_tail,v68_7_label);
        if (v68_7_tail.empty()) continue;
        const Path v68_7_head{v68_7_label};
        const Space v69_2 = singleton(v68_7_head);
        const Space v69_3 = intersect(constant_5,v69_2);
        const Space v69_4 = (has_head(v69_3) ? constant_7 : Space{});
        const Space v69_5 = subtract(constant_0,v69_4);
        Space v69_8;
        if (!v69_5.empty()) {
          const Path v70_6 = concat_path(v68_6,v68_7_head);
          const Space v70_7 = routine_22(c, v70_6, v68_7_tail);
          v69_8 = compose(v69_5,v70_7);
        }
        const Space v69_9 = intersect(constant_5,v69_2);
        const Space v69_10 = (has_head(v69_9) ? constant_7 : Space{});
        Space v69_12;
        if (!v69_10.empty()) {
          const Path v71_6 = concat_path(v68_6,v68_7_head);
          const Space v71_11 = routine_23(c, v71_6, v68_7_tail);
          v69_12 = compose(v69_10,v71_11);
        }
        const Space v69_13 = unite(v69_8,v69_12);
        v68_7_result = unite(v68_7_result,v69_13);
      }
      const Space v68_7 = std::move(v68_7_result);
      v67_8 = compose(v67_5,v68_7);
    }
    const Space v67_9 = intersect(constant_5,v67_2);
    const Space v67_10 = (has_head(v67_9) ? constant_7 : Space{});
    Space v67_12;
    if (!v67_10.empty()) {
      const Path v72_6 = concat_path(p0,v66_11_head);
      Space v72_11_result;
      for (int v72_11_label = 1; v72_11_label <= 2; ++v72_11_label) {
        const Space v72_11_tail = child(v66_11_tail,v72_11_label);
        if (v72_11_tail.empty()) continue;
        const Path v72_11_head{v72_11_label};
        const Space v73_2 = singleton(v72_11_head);
        const Space v73_3 = intersect(constant_5,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_7 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_11_head);
          const Space v74_7 = routine_22(c, v74_6, v72_11_tail);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_5,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_7 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_11_head);
          const Space v75_11 = routine_9(c, v75_6, v72_11_tail);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_11_result = unite(v72_11_result,v73_13);
      }
      const Space v72_11 = std::move(v72_11_result);
      v67_12 = compose(v67_10,v72_11);
    }
    const Space v67_13 = unite(v67_8,v67_12);
    v66_11_result = unite(v66_11_result,v67_13);
  }
  const Space v66_11 = std::move(v66_11_result);
  return v66_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v76_11_result;
  for (int v76_11_label = 1; v76_11_label <= 2; ++v76_11_label) {
    const Space v76_11_tail = child(s0,v76_11_label);
    if (v76_11_tail.empty()) continue;
    const Path v76_11_head{v76_11_label};
    const Space v77_2 = singleton(v76_11_head);
    const Space v77_3 = intersect(constant_5,v77_2);
    const Space v77_4 = (has_head(v77_3) ? constant_7 : Space{});
    const Space v77_5 = subtract(constant_0,v77_4);
    Space v77_8;
    if (!v77_5.empty()) {
      const Path v78_6 = concat_path(p0,v76_11_head);
      Space v78_7_result;
      for (int v78_7_label = 1; v78_7_label <= 2; ++v78_7_label) {
        const Space v78_7_tail = child(v76_11_tail,v78_7_label);
        if (v78_7_tail.empty()) continue;
        const Path v78_7_head{v78_7_label};
        const Space v79_2 = singleton(v78_7_head);
        const Space v79_3 = intersect(constant_5,v79_2);
        const Space v79_4 = (has_head(v79_3) ? constant_7 : Space{});
        const Space v79_5 = subtract(constant_0,v79_4);
        Space v79_8;
        if (!v79_5.empty()) {
          const Path v80_6 = concat_path(v78_6,v78_7_head);
          const Space v80_7 = routine_22(c, v80_6, v78_7_tail);
          v79_8 = compose(v79_5,v80_7);
        }
        const Space v79_9 = intersect(constant_5,v79_2);
        const Space v79_10 = (has_head(v79_9) ? constant_7 : Space{});
        Space v79_12;
        if (!v79_10.empty()) {
          const Path v81_6 = concat_path(v78_6,v78_7_head);
          const Space v81_11 = routine_23(c, v81_6, v78_7_tail);
          v79_12 = compose(v79_10,v81_11);
        }
        const Space v79_13 = unite(v79_8,v79_12);
        v78_7_result = unite(v78_7_result,v79_13);
      }
      const Space v78_7 = std::move(v78_7_result);
      v77_8 = compose(v77_5,v78_7);
    }
    const Space v77_9 = intersect(constant_5,v77_2);
    const Space v77_10 = (has_head(v77_9) ? constant_7 : Space{});
    Space v77_12;
    if (!v77_10.empty()) {
      const Path v82_6 = concat_path(p0,v76_11_head);
      Space v82_11_result;
      for (int v82_11_label = 1; v82_11_label <= 2; ++v82_11_label) {
        const Space v82_11_tail = child(v76_11_tail,v82_11_label);
        if (v82_11_tail.empty()) continue;
        const Path v82_11_head{v82_11_label};
        const Space v83_2 = singleton(v82_11_head);
        const Space v83_3 = intersect(constant_5,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_7 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_7;
        if (!v83_5.empty()) {
          const Space v84_6 = routine_10(c, v82_11_head, v82_6, v82_11_tail);
          v83_7 = compose(v83_5,v84_6);
        }
        const Space v83_8 = intersect(constant_5,v83_2);
        const Space v83_9 = (has_head(v83_8) ? constant_7 : Space{});
        Space v83_11;
        if (!v83_9.empty()) {
          const Space v85_10 = routine_11(c, v82_11_head, v82_6, v82_11_tail);
          v83_11 = compose(v83_9,v85_10);
        }
        const Space v83_12 = unite(v83_7,v83_11);
        v82_11_result = unite(v82_11_result,v83_12);
      }
      const Space v82_11 = std::move(v82_11_result);
      v77_12 = compose(v77_10,v82_11);
    }
    const Space v77_13 = unite(v77_8,v77_12);
    v76_11_result = unite(v76_11_result,v77_13);
  }
  const Space v76_11 = std::move(v76_11_result);
  return v76_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v86_11_result;
  for (int v86_11_label = 1; v86_11_label <= 2; ++v86_11_label) {
    const Space v86_11_tail = child(s0,v86_11_label);
    if (v86_11_tail.empty()) continue;
    const Path v86_11_head{v86_11_label};
    const Space v87_2 = singleton(v86_11_head);
    const Space v87_3 = intersect(constant_5,v87_2);
    const Space v87_4 = (has_head(v87_3) ? constant_7 : Space{});
    const Space v87_5 = subtract(constant_0,v87_4);
    Space v87_7;
    if (!v87_5.empty()) {
      Space v88_6_result;
      for (int v88_6_label = 1; v88_6_label <= 2; ++v88_6_label) {
        const Space v88_6_tail = child(v86_11_tail,v88_6_label);
        if (v88_6_tail.empty()) continue;
        const Path v88_6_head{v88_6_label};
        const Space v89_2 = singleton(v88_6_head);
        const Space v89_3 = intersect(constant_5,v89_2);
        const Space v89_4 = (has_head(v89_3) ? constant_7 : Space{});
        const Space v89_5 = subtract(constant_0,v89_4);
        Space v89_8;
        if (!v89_5.empty()) {
          const Path v90_6 = concat_path(v86_11_head,v88_6_head);
          const Space v90_7 = routine_24(c, v90_6, p0, v88_6_tail);
          v89_8 = compose(v89_5,v90_7);
        }
        const Space v89_9 = intersect(constant_5,v89_2);
        const Space v89_10 = (has_head(v89_9) ? constant_7 : Space{});
        Space v89_12;
        if (!v89_10.empty()) {
          const Path v91_6 = concat_path(v86_11_head,v88_6_head);
          const Space v91_11 = routine_25(c, v91_6, p0, v88_6_tail);
          v89_12 = compose(v89_10,v91_11);
        }
        const Space v89_13 = unite(v89_8,v89_12);
        v88_6_result = unite(v88_6_result,v89_13);
      }
      const Space v88_6 = std::move(v88_6_result);
      v87_7 = compose(v87_5,v88_6);
    }
    const Space v87_8 = intersect(constant_5,v87_2);
    const Space v87_9 = (has_head(v87_8) ? constant_7 : Space{});
    Space v87_11;
    if (!v87_9.empty()) {
      Space v92_10_result;
      for (int v92_10_label = 1; v92_10_label <= 2; ++v92_10_label) {
        const Space v92_10_tail = child(v86_11_tail,v92_10_label);
        if (v92_10_tail.empty()) continue;
        const Path v92_10_head{v92_10_label};
        const Space v93_2 = singleton(v92_10_head);
        const Space v93_3 = intersect(constant_5,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_7 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v86_11_head,v92_10_head);
          const Space v94_7 = routine_24(c, v94_6, p0, v92_10_tail);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_5,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_7 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v86_11_head,v92_10_head);
          const Space v95_11 = routine_26(c, v95_6, p0, v92_10_tail);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_10_result = unite(v92_10_result,v93_13);
      }
      const Space v92_10 = std::move(v92_10_result);
      v87_11 = compose(v87_9,v92_10);
    }
    const Space v87_12 = unite(v87_7,v87_11);
    v86_11_result = unite(v86_11_result,v87_12);
  }
  const Space v86_11 = std::move(v86_11_result);
  return v86_11;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v96_12_result;
  for (int v96_12_label = 1; v96_12_label <= 2; ++v96_12_label) {
    const Space v96_12_tail = child(s0,v96_12_label);
    if (v96_12_tail.empty()) continue;
    const Path v96_12_head{v96_12_label};
    const Space v97_2 = singleton(v96_12_head);
    const Space v97_3 = intersect(constant_5,v97_2);
    const Space v97_4 = (has_head(v97_3) ? constant_7 : Space{});
    const Space v97_5 = subtract(constant_0,v97_4);
    Space v97_8;
    if (!v97_5.empty()) {
      const Path v98_6 = concat_path(p0,v96_12_head);
      Space v98_7_result;
      for (int v98_7_label = 1; v98_7_label <= 2; ++v98_7_label) {
        const Space v98_7_tail = child(v96_12_tail,v98_7_label);
        if (v98_7_tail.empty()) continue;
        const Path v98_7_head{v98_7_label};
        const Space v99_2 = singleton(v98_7_head);
        const Space v99_3 = intersect(constant_5,v99_2);
        const Space v99_4 = (has_head(v99_3) ? constant_7 : Space{});
        const Space v99_5 = subtract(constant_0,v99_4);
        Space v99_8;
        if (!v99_5.empty()) {
          const Path v100_6 = concat_path(v98_6,v98_7_head);
          const Space v100_7 = routine_27(c, v100_6, p1, v98_7_tail);
          v99_8 = compose(v99_5,v100_7);
        }
        const Space v99_9 = intersect(constant_5,v99_2);
        const Space v99_10 = (has_head(v99_9) ? constant_7 : Space{});
        Space v99_12;
        if (!v99_10.empty()) {
          const Path v101_6 = concat_path(v98_6,v98_7_head);
          const Space v101_11 = routine_28(c, v101_6, p1, v98_7_tail);
          v99_12 = compose(v99_10,v101_11);
        }
        const Space v99_13 = unite(v99_8,v99_12);
        v98_7_result = unite(v98_7_result,v99_13);
      }
      const Space v98_7 = std::move(v98_7_result);
      v97_8 = compose(v97_5,v98_7);
    }
    const Space v97_9 = intersect(constant_5,v97_2);
    const Space v97_10 = (has_head(v97_9) ? constant_7 : Space{});
    Space v97_12;
    if (!v97_10.empty()) {
      const Path v102_6 = concat_path(p0,v96_12_head);
      Space v102_11_result;
      for (int v102_11_label = 1; v102_11_label <= 2; ++v102_11_label) {
        const Space v102_11_tail = child(v96_12_tail,v102_11_label);
        if (v102_11_tail.empty()) continue;
        const Path v102_11_head{v102_11_label};
        const Space v103_2 = singleton(v102_11_head);
        const Space v103_3 = intersect(constant_5,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_7 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_11_head);
          const Space v104_7 = routine_27(c, v104_6, p1, v102_11_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_5,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_7 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_11_head);
          const Space v105_11 = routine_26(c, v105_6, p1, v102_11_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_11_result = unite(v102_11_result,v103_13);
      }
      const Space v102_11 = std::move(v102_11_result);
      v97_12 = compose(v97_10,v102_11);
    }
    const Space v97_13 = unite(v97_8,v97_12);
    v96_12_result = unite(v96_12_result,v97_13);
  }
  const Space v96_12 = std::move(v96_12_result);
  return v96_12;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v106_7 = unwrap(constant_9,p1);
  const Space v106_9 = unwrap(constant_9,p0);
  Space v106_13_result;
  for (int v106_13_label = 1; v106_13_label <= 2; ++v106_13_label) {
    const Space v106_13_tail = child(s0,v106_13_label);
    if (v106_13_tail.empty()) continue;
    const Path v106_13_head{v106_13_label};
    const Space v107_2 = singleton(v106_13_head);
    const Space v107_3 = intersect(constant_5,v107_2);
    const Space v107_4 = (has_head(v107_3) ? constant_7 : Space{});
    const Space v107_5 = subtract(constant_0,v107_4);
    Space v107_8;
    if (!v107_5.empty()) {
      const Path v108_6 = concat_path(p0,v106_13_head);
      Space v108_7_result;
      for (int v108_7_label = 1; v108_7_label <= 2; ++v108_7_label) {
        const Space v108_7_tail = child(v106_13_tail,v108_7_label);
        if (v108_7_tail.empty()) continue;
        const Path v108_7_head{v108_7_label};
        const Space v109_2 = singleton(v108_7_head);
        const Space v109_3 = intersect(constant_5,v109_2);
        const Space v109_4 = (has_head(v109_3) ? constant_7 : Space{});
        const Space v109_5 = subtract(constant_0,v109_4);
        Space v109_8;
        if (!v109_5.empty()) {
          const Path v110_6 = concat_path(v108_6,v108_7_head);
          const Space v110_7 = routine_27(c, v110_6, p1, v108_7_tail);
          v109_8 = compose(v109_5,v110_7);
        }
        const Space v109_9 = intersect(constant_5,v109_2);
        const Space v109_10 = (has_head(v109_9) ? constant_7 : Space{});
        Space v109_12;
        if (!v109_10.empty()) {
          const Path v111_6 = concat_path(v108_6,v108_7_head);
          const Space v111_11 = routine_28(c, v111_6, p1, v108_7_tail);
          v109_12 = compose(v109_10,v111_11);
        }
        const Space v109_13 = unite(v109_8,v109_12);
        v108_7_result = unite(v108_7_result,v109_13);
      }
      const Space v108_7 = std::move(v108_7_result);
      v107_8 = compose(v107_5,v108_7);
    }
    const Space v107_9 = intersect(constant_5,v107_2);
    const Space v107_10 = (has_head(v107_9) ? constant_7 : Space{});
    const Space v107_11 = unwrap(v106_9,v106_13_head);
    const Space v107_12 = compose(v106_7,v107_11);
    const Path v112_6 = concat_path(p0,v106_13_head);
    const Path v107_13 = concat_path(p1,v112_6);
    const Space v107_14 = singleton(v107_13);
    const Space v107_15 = subtract(v107_12,v107_14);
    const Space v107_16 = compose(v107_10,v107_15);
    const Space v107_17 = unite(v107_8,v107_16);
    v106_13_result = unite(v106_13_result,v107_17);
  }
  const Space v106_13 = std::move(v106_13_result);
  return v106_13;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v113_12_result;
  for (int v113_12_label = 1; v113_12_label <= 2; ++v113_12_label) {
    const Space v113_12_tail = child(s0,v113_12_label);
    if (v113_12_tail.empty()) continue;
    const Path v113_12_head{v113_12_label};
    const Space v114_2 = singleton(v113_12_head);
    const Space v114_3 = intersect(constant_5,v114_2);
    const Space v114_4 = (has_head(v114_3) ? constant_7 : Space{});
    const Space v114_5 = subtract(constant_0,v114_4);
    Space v114_8;
    if (!v114_5.empty()) {
      const Path v115_6 = concat_path(p0,v113_12_head);
      Space v115_7_result;
      for (int v115_7_label = 1; v115_7_label <= 2; ++v115_7_label) {
        const Space v115_7_tail = child(v113_12_tail,v115_7_label);
        if (v115_7_tail.empty()) continue;
        const Path v115_7_head{v115_7_label};
        const Space v116_2 = singleton(v115_7_head);
        const Space v116_3 = intersect(constant_5,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_7 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_8;
        if (!v116_5.empty()) {
          const Path v117_6 = concat_path(v115_6,v115_7_head);
          const Space v117_7 = routine_29(c, v117_6, v115_7_tail, s1);
          v116_8 = compose(v116_5,v117_7);
        }
        const Space v116_9 = intersect(constant_5,v116_2);
        const Space v116_10 = (has_head(v116_9) ? constant_7 : Space{});
        Space v116_12;
        if (!v116_10.empty()) {
          const Path v118_6 = concat_path(v115_6,v115_7_head);
          const Space v118_11 = routine_30(c, v118_6, v115_7_tail, s1);
          v116_12 = compose(v116_10,v118_11);
        }
        const Space v116_13 = unite(v116_8,v116_12);
        v115_7_result = unite(v115_7_result,v116_13);
      }
      const Space v115_7 = std::move(v115_7_result);
      v114_8 = compose(v114_5,v115_7);
    }
    const Space v114_9 = intersect(constant_5,v114_2);
    const Space v114_10 = (has_head(v114_9) ? constant_7 : Space{});
    Space v114_12;
    if (!v114_10.empty()) {
      const Path v119_6 = concat_path(p0,v113_12_head);
      Space v119_11_result;
      for (int v119_11_label = 1; v119_11_label <= 2; ++v119_11_label) {
        const Space v119_11_tail = child(v113_12_tail,v119_11_label);
        if (v119_11_tail.empty()) continue;
        const Path v119_11_head{v119_11_label};
        const Space v120_2 = singleton(v119_11_head);
        const Space v120_3 = intersect(constant_5,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_7 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_11_head);
          const Space v121_7 = routine_29(c, v121_6, v119_11_tail, s1);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_5,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_7 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_11_head);
          const Space v122_11 = routine_14(c, v122_6, v119_11_tail, s1);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_11_result = unite(v119_11_result,v120_13);
      }
      const Space v119_11 = std::move(v119_11_result);
      v114_12 = compose(v114_10,v119_11);
    }
    const Space v114_13 = unite(v114_8,v114_12);
    v113_12_result = unite(v113_12_result,v114_13);
  }
  const Space v113_12 = std::move(v113_12_result);
  return v113_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v123_12_result;
  for (int v123_12_label = 1; v123_12_label <= 2; ++v123_12_label) {
    const Space v123_12_tail = child(s0,v123_12_label);
    if (v123_12_tail.empty()) continue;
    const Path v123_12_head{v123_12_label};
    const Space v124_2 = singleton(v123_12_head);
    const Space v124_3 = intersect(constant_5,v124_2);
    const Space v124_4 = (has_head(v124_3) ? constant_7 : Space{});
    const Space v124_5 = subtract(constant_0,v124_4);
    Space v124_8;
    if (!v124_5.empty()) {
      const Path v125_6 = concat_path(p0,v123_12_head);
      Space v125_7_result;
      for (int v125_7_label = 1; v125_7_label <= 2; ++v125_7_label) {
        const Space v125_7_tail = child(v123_12_tail,v125_7_label);
        if (v125_7_tail.empty()) continue;
        const Path v125_7_head{v125_7_label};
        const Space v126_2 = singleton(v125_7_head);
        const Space v126_3 = intersect(constant_5,v126_2);
        const Space v126_4 = (has_head(v126_3) ? constant_7 : Space{});
        const Space v126_5 = subtract(constant_0,v126_4);
        Space v126_8;
        if (!v126_5.empty()) {
          const Path v127_6 = concat_path(v125_6,v125_7_head);
          const Space v127_7 = routine_29(c, v127_6, v125_7_tail, s1);
          v126_8 = compose(v126_5,v127_7);
        }
        const Space v126_9 = intersect(constant_5,v126_2);
        const Space v126_10 = (has_head(v126_9) ? constant_7 : Space{});
        Space v126_12;
        if (!v126_10.empty()) {
          const Path v128_6 = concat_path(v125_6,v125_7_head);
          const Space v128_11 = routine_30(c, v128_6, v125_7_tail, s1);
          v126_12 = compose(v126_10,v128_11);
        }
        const Space v126_13 = unite(v126_8,v126_12);
        v125_7_result = unite(v125_7_result,v126_13);
      }
      const Space v125_7 = std::move(v125_7_result);
      v124_8 = compose(v124_5,v125_7);
    }
    const Space v124_9 = intersect(constant_5,v124_2);
    const Space v124_10 = (has_head(v124_9) ? constant_7 : Space{});
    Space v124_12;
    if (!v124_10.empty()) {
      const Path v129_6 = concat_path(p0,v123_12_head);
      Space v129_11_result;
      for (int v129_11_label = 1; v129_11_label <= 2; ++v129_11_label) {
        const Space v129_11_tail = child(v123_12_tail,v129_11_label);
        if (v129_11_tail.empty()) continue;
        const Path v129_11_head{v129_11_label};
        const Space v130_2 = singleton(v129_11_head);
        const Space v130_3 = intersect(constant_5,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_7 : Space{});
        const Space v130_5 = subtract(constant_0,v130_4);
        Space v130_7;
        if (!v130_5.empty()) {
          const Space v131_6 = routine_15(c, v129_11_head, v129_6, v129_11_tail, s1);
          v130_7 = compose(v130_5,v131_6);
        }
        const Space v130_8 = intersect(constant_5,v130_2);
        const Space v130_9 = (has_head(v130_8) ? constant_7 : Space{});
        Space v130_11;
        if (!v130_9.empty()) {
          const Space v132_10 = routine_16(c, v129_11_head, v129_6, v129_11_tail, s1);
          v130_11 = compose(v130_9,v132_10);
        }
        const Space v130_12 = unite(v130_7,v130_11);
        v129_11_result = unite(v129_11_result,v130_12);
      }
      const Space v129_11 = std::move(v129_11_result);
      v124_12 = compose(v124_10,v129_11);
    }
    const Space v124_13 = unite(v124_8,v124_12);
    v123_12_result = unite(v123_12_result,v124_13);
  }
  const Space v123_12 = std::move(v123_12_result);
  return v123_12;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v133_12_result;
  for (int v133_12_label = 1; v133_12_label <= 2; ++v133_12_label) {
    const Space v133_12_tail = child(s0,v133_12_label);
    if (v133_12_tail.empty()) continue;
    const Path v133_12_head{v133_12_label};
    const Space v134_2 = singleton(v133_12_head);
    const Space v134_3 = intersect(constant_5,v134_2);
    const Space v134_4 = (has_head(v134_3) ? constant_7 : Space{});
    const Space v134_5 = subtract(constant_0,v134_4);
    Space v134_7;
    if (!v134_5.empty()) {
      Space v135_6_result;
      for (int v135_6_label = 1; v135_6_label <= 2; ++v135_6_label) {
        const Space v135_6_tail = child(v133_12_tail,v135_6_label);
        if (v135_6_tail.empty()) continue;
        const Path v135_6_head{v135_6_label};
        const Space v136_2 = singleton(v135_6_head);
        const Space v136_3 = intersect(constant_5,v136_2);
        const Space v136_4 = (has_head(v136_3) ? constant_7 : Space{});
        const Space v136_5 = subtract(constant_0,v136_4);
        Space v136_8;
        if (!v136_5.empty()) {
          const Path v137_6 = concat_path(v133_12_head,v135_6_head);
          const Space v137_7 = routine_31(c, v137_6, p0, v135_6_tail, s1);
          v136_8 = compose(v136_5,v137_7);
        }
        const Space v136_9 = intersect(constant_5,v136_2);
        const Space v136_10 = (has_head(v136_9) ? constant_7 : Space{});
        Space v136_12;
        if (!v136_10.empty()) {
          const Path v138_6 = concat_path(v133_12_head,v135_6_head);
          const Space v138_11 = routine_32(c, v138_6, p0, v135_6_tail, s1);
          v136_12 = compose(v136_10,v138_11);
        }
        const Space v136_13 = unite(v136_8,v136_12);
        v135_6_result = unite(v135_6_result,v136_13);
      }
      const Space v135_6 = std::move(v135_6_result);
      v134_7 = compose(v134_5,v135_6);
    }
    const Space v134_8 = intersect(constant_5,v134_2);
    const Space v134_9 = (has_head(v134_8) ? constant_7 : Space{});
    Space v134_11;
    if (!v134_9.empty()) {
      Space v139_10_result;
      for (int v139_10_label = 1; v139_10_label <= 2; ++v139_10_label) {
        const Space v139_10_tail = child(v133_12_tail,v139_10_label);
        if (v139_10_tail.empty()) continue;
        const Path v139_10_head{v139_10_label};
        const Space v140_2 = singleton(v139_10_head);
        const Space v140_3 = intersect(constant_5,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_7 : Space{});
        const Space v140_5 = subtract(constant_0,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v133_12_head,v139_10_head);
          const Space v141_7 = routine_31(c, v141_6, p0, v139_10_tail, s1);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_5,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_7 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v133_12_head,v139_10_head);
          const Space v142_11 = routine_33(c, v142_6, p0, v139_10_tail, s1);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_10_result = unite(v139_10_result,v140_13);
      }
      const Space v139_10 = std::move(v139_10_result);
      v134_11 = compose(v134_9,v139_10);
    }
    const Space v134_12 = unite(v134_7,v134_11);
    v133_12_result = unite(v133_12_result,v134_12);
  }
  const Space v133_12 = std::move(v133_12_result);
  return v133_12;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v143_13_result;
  for (int v143_13_label = 1; v143_13_label <= 2; ++v143_13_label) {
    const Space v143_13_tail = child(s0,v143_13_label);
    if (v143_13_tail.empty()) continue;
    const Path v143_13_head{v143_13_label};
    const Space v144_2 = singleton(v143_13_head);
    const Space v144_3 = intersect(constant_5,v144_2);
    const Space v144_4 = (has_head(v144_3) ? constant_7 : Space{});
    const Space v144_5 = subtract(constant_0,v144_4);
    Space v144_8;
    if (!v144_5.empty()) {
      const Path v145_6 = concat_path(p0,v143_13_head);
      Space v145_7_result;
      for (int v145_7_label = 1; v145_7_label <= 2; ++v145_7_label) {
        const Space v145_7_tail = child(v143_13_tail,v145_7_label);
        if (v145_7_tail.empty()) continue;
        const Path v145_7_head{v145_7_label};
        const Space v146_2 = singleton(v145_7_head);
        const Space v146_3 = intersect(constant_5,v146_2);
        const Space v146_4 = (has_head(v146_3) ? constant_7 : Space{});
        const Space v146_5 = subtract(constant_0,v146_4);
        Space v146_8;
        if (!v146_5.empty()) {
          const Path v147_6 = concat_path(v145_6,v145_7_head);
          const Space v147_7 = routine_34(c, v147_6, p1, v145_7_tail, s1);
          v146_8 = compose(v146_5,v147_7);
        }
        const Space v146_9 = intersect(constant_5,v146_2);
        const Space v146_10 = (has_head(v146_9) ? constant_7 : Space{});
        Space v146_12;
        if (!v146_10.empty()) {
          const Path v148_6 = concat_path(v145_6,v145_7_head);
          const Space v148_11 = routine_35(c, v148_6, p1, v145_7_tail, s1);
          v146_12 = compose(v146_10,v148_11);
        }
        const Space v146_13 = unite(v146_8,v146_12);
        v145_7_result = unite(v145_7_result,v146_13);
      }
      const Space v145_7 = std::move(v145_7_result);
      v144_8 = compose(v144_5,v145_7);
    }
    const Space v144_9 = intersect(constant_5,v144_2);
    const Space v144_10 = (has_head(v144_9) ? constant_7 : Space{});
    Space v144_12;
    if (!v144_10.empty()) {
      const Path v149_6 = concat_path(p0,v143_13_head);
      Space v149_11_result;
      for (int v149_11_label = 1; v149_11_label <= 2; ++v149_11_label) {
        const Space v149_11_tail = child(v143_13_tail,v149_11_label);
        if (v149_11_tail.empty()) continue;
        const Path v149_11_head{v149_11_label};
        const Space v150_2 = singleton(v149_11_head);
        const Space v150_3 = intersect(constant_5,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_7 : Space{});
        const Space v150_5 = subtract(constant_0,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_11_head);
          const Space v151_7 = routine_34(c, v151_6, p1, v149_11_tail, s1);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_5,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_7 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_11_head);
          const Space v152_11 = routine_33(c, v152_6, p1, v149_11_tail, s1);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_11_result = unite(v149_11_result,v150_13);
      }
      const Space v149_11 = std::move(v149_11_result);
      v144_12 = compose(v144_10,v149_11);
    }
    const Space v144_13 = unite(v144_8,v144_12);
    v143_13_result = unite(v143_13_result,v144_13);
  }
  const Space v143_13 = std::move(v143_13_result);
  return v143_13;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v153_8 = unwrap(constant_9,p1);
  const Space v153_10 = unwrap(constant_9,p0);
  const Space v153_12 = unwrap(s1,constant_8);
  const Space v153_14 = unwrap(constant_9,p1);
  const Space v153_16 = unwrap(constant_9,p0);
  Space v153_29_result;
  for (int v153_29_label = 1; v153_29_label <= 2; ++v153_29_label) {
    const Space v153_29_tail = child(s0,v153_29_label);
    if (v153_29_tail.empty()) continue;
    const Path v153_29_head{v153_29_label};
    const Space v154_2 = singleton(v153_29_head);
    const Space v154_3 = intersect(constant_5,v154_2);
    const Space v154_4 = (has_head(v154_3) ? constant_7 : Space{});
    const Space v154_5 = subtract(constant_0,v154_4);
    Space v154_8;
    if (!v154_5.empty()) {
      const Path v155_6 = concat_path(p0,v153_29_head);
      Space v155_7_result;
      for (int v155_7_label = 1; v155_7_label <= 2; ++v155_7_label) {
        const Space v155_7_tail = child(v153_29_tail,v155_7_label);
        if (v155_7_tail.empty()) continue;
        const Path v155_7_head{v155_7_label};
        const Space v156_2 = singleton(v155_7_head);
        const Space v156_3 = intersect(constant_5,v156_2);
        const Space v156_4 = (has_head(v156_3) ? constant_7 : Space{});
        const Space v156_5 = subtract(constant_0,v156_4);
        Space v156_8;
        if (!v156_5.empty()) {
          const Path v157_6 = concat_path(v155_6,v155_7_head);
          const Space v157_7 = routine_34(c, v157_6, p1, v155_7_tail, s1);
          v156_8 = compose(v156_5,v157_7);
        }
        const Space v156_9 = intersect(constant_5,v156_2);
        const Space v156_10 = (has_head(v156_9) ? constant_7 : Space{});
        Space v156_12;
        if (!v156_10.empty()) {
          const Path v158_6 = concat_path(v155_6,v155_7_head);
          const Space v158_11 = routine_35(c, v158_6, p1, v155_7_tail, s1);
          v156_12 = compose(v156_10,v158_11);
        }
        const Space v156_13 = unite(v156_8,v156_12);
        v155_7_result = unite(v155_7_result,v156_13);
      }
      const Space v155_7 = std::move(v155_7_result);
      v154_8 = compose(v154_5,v155_7);
    }
    const Space v154_9 = intersect(constant_5,v154_2);
    const Space v154_10 = (has_head(v154_9) ? constant_7 : Space{});
    Space v154_28;
    if (!v154_10.empty()) {
      const Path v159_6 = concat_path(p0,v153_29_head);
      const Space v159_11 = unwrap(v153_10,v153_29_head);
      const Space v159_12 = compose(v153_8,v159_11);
      const Path v159_13 = concat_path(p1,v159_6);
      const Space v159_14 = singleton(v159_13);
      const Space v159_15 = subtract(v159_12,v159_14);
      const Space v159_16 = intersect(v159_15,v153_12);
      const Space v159_17 = routine_36(c, v159_16);
      Space v159_18_result;
      for (int v159_18_label = 1; v159_18_label <= 2; ++v159_18_label) {
        const Space v159_18_tail = child(v159_17,v159_18_label);
        if (v159_18_tail.empty()) continue;
        const Path v159_18_head{v159_18_label};
        const Space v160_2 = singleton(v159_18_head);
        const Space v160_3 = intersect(constant_5,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_7 : Space{});
        const Space v160_5 = subtract(constant_0,v160_4);
        Space v160_7;
        if (!v160_5.empty()) {
          const Space v161_6 = routine_37(c, v159_18_head, v159_18_tail);
          v160_7 = compose(v160_5,v161_6);
        }
        const Space v160_8 = intersect(constant_5,v160_2);
        const Space v160_9 = (has_head(v160_8) ? constant_7 : Space{});
        Space v160_11;
        if (!v160_9.empty()) {
          const Space v162_10 = routine_38(c, v159_18_head, v159_18_tail);
          v160_11 = compose(v160_9,v162_10);
        }
        const Space v160_12 = unite(v160_7,v160_11);
        v159_18_result = unite(v159_18_result,v160_12);
      }
      const Space v159_18 = std::move(v159_18_result);
      const Space v159_19 = unwrap(v153_16,v153_29_head);
      const Space v159_20 = compose(v153_14,v159_19);
      const Space v159_21 = subtract(v159_20,v159_14);
      const Space v159_22 = intersect(v159_21,v153_12);
      const Space v159_23 = routine_39(c, v159_22);
      Space v159_24_result;
      for (int v159_24_label = 1; v159_24_label <= 2; ++v159_24_label) {
        const Space v159_24_tail = child(v159_23,v159_24_label);
        if (v159_24_tail.empty()) continue;
        const Path v159_24_head{v159_24_label};
        const Space v163_2 = singleton(v159_24_head);
        const Space v163_3 = intersect(constant_5,v163_2);
        const Space v163_4 = (has_head(v163_3) ? constant_7 : Space{});
        const Space v163_5 = subtract(constant_0,v163_4);
        Space v163_7;
        if (!v163_5.empty()) {
          const Space v164_6 = routine_40(c, v159_24_head, v159_24_tail);
          v163_7 = compose(v163_5,v164_6);
        }
        const Space v163_8 = intersect(constant_5,v163_2);
        const Space v163_9 = (has_head(v163_8) ? constant_7 : Space{});
        Space v163_11;
        if (!v163_9.empty()) {
          const Space v165_10 = routine_41(c, v159_24_head, v159_24_tail);
          v163_11 = compose(v163_9,v165_10);
        }
        const Space v163_12 = unite(v163_7,v163_11);
        v159_24_result = unite(v159_24_result,v163_12);
      }
      const Space v159_24 = std::move(v159_24_result);
      const Space v159_25 = subtract(v159_18,v159_24);
      const Space v159_26 = compose(v159_25,v159_14);
      Space v159_27_result;
      for (int v159_27_label = 1; v159_27_label <= 2; ++v159_27_label) {
        const Space v159_27_tail = child(v159_26,v159_27_label);
        if (v159_27_tail.empty()) continue;
        const Path v159_27_head{v159_27_label};
        const Space v166_2 = singleton(v159_27_head);
        const Space v166_3 = intersect(constant_5,v166_2);
        const Space v166_4 = (has_head(v166_3) ? constant_7 : Space{});
        const Space v166_5 = subtract(constant_0,v166_4);
        Space v166_7;
        if (!v166_5.empty()) {
          const Space v167_6 = routine_42(c, v159_27_head, v159_27_tail);
          v166_7 = compose(v166_5,v167_6);
        }
        const Space v166_8 = intersect(constant_5,v166_2);
        const Space v166_9 = (has_head(v166_8) ? constant_7 : Space{});
        Space v166_11;
        if (!v166_9.empty()) {
          const Space v168_10 = routine_43(c, v159_27_head, v159_27_tail);
          v166_11 = compose(v166_9,v168_10);
        }
        const Space v166_12 = unite(v166_7,v166_11);
        v159_27_result = unite(v159_27_result,v166_12);
      }
      const Space v159_27 = std::move(v159_27_result);
      v154_28 = compose(v154_10,v159_27);
    }
    const Space v154_29 = unite(v154_8,v154_28);
    v153_29_result = unite(v153_29_result,v154_29);
  }
  const Space v153_29 = std::move(v153_29_result);
  return v153_29;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v169_12_result;
  for (int v169_12_label = 1; v169_12_label <= 2; ++v169_12_label) {
    const Space v169_12_tail = child(s0,v169_12_label);
    if (v169_12_tail.empty()) continue;
    const Path v169_12_head{v169_12_label};
    const Space v170_2 = singleton(v169_12_head);
    const Space v170_3 = intersect(constant_5,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_7 : Space{});
    const Space v170_5 = subtract(constant_0,v170_4);
    Space v170_8;
    if (!v170_5.empty()) {
      const Path v171_6 = concat_path(p0,v169_12_head);
      Space v171_7_result;
      for (int v171_7_label = 1; v171_7_label <= 2; ++v171_7_label) {
        const Space v171_7_tail = child(v169_12_tail,v171_7_label);
        if (v171_7_tail.empty()) continue;
        const Path v171_7_head{v171_7_label};
        const Space v172_2 = singleton(v171_7_head);
        const Space v172_3 = intersect(constant_5,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_7 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v171_6,v171_7_head);
          const Space v173_7 = routine_44(c, v173_6, v171_7_tail, s1);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_5,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_7 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v171_6,v171_7_head);
          const Space v174_11 = routine_45(c, v174_6, v171_7_tail, s1);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_7_result = unite(v171_7_result,v172_13);
      }
      const Space v171_7 = std::move(v171_7_result);
      v170_8 = compose(v170_5,v171_7);
    }
    const Space v170_9 = intersect(constant_5,v170_2);
    const Space v170_10 = (has_head(v170_9) ? constant_7 : Space{});
    Space v170_12;
    if (!v170_10.empty()) {
      const Path v175_6 = concat_path(p0,v169_12_head);
      Space v175_11_result;
      for (int v175_11_label = 1; v175_11_label <= 2; ++v175_11_label) {
        const Space v175_11_tail = child(v169_12_tail,v175_11_label);
        if (v175_11_tail.empty()) continue;
        const Path v175_11_head{v175_11_label};
        const Space v176_2 = singleton(v175_11_head);
        const Space v176_3 = intersect(constant_5,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_7 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_11_head);
          const Space v177_7 = routine_44(c, v177_6, v175_11_tail, s1);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_5,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_7 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_11_head);
          const Space v178_11 = routine_19(c, v178_6, v175_11_tail, s1);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_11_result = unite(v175_11_result,v176_13);
      }
      const Space v175_11 = std::move(v175_11_result);
      v170_12 = compose(v170_10,v175_11);
    }
    const Space v170_13 = unite(v170_8,v170_12);
    v169_12_result = unite(v169_12_result,v170_13);
  }
  const Space v169_12 = std::move(v169_12_result);
  return v169_12;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v179_12_result;
  for (int v179_12_label = 1; v179_12_label <= 2; ++v179_12_label) {
    const Space v179_12_tail = child(s0,v179_12_label);
    if (v179_12_tail.empty()) continue;
    const Path v179_12_head{v179_12_label};
    const Space v180_2 = singleton(v179_12_head);
    const Space v180_3 = intersect(constant_5,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_7 : Space{});
    const Space v180_5 = subtract(constant_0,v180_4);
    Space v180_8;
    if (!v180_5.empty()) {
      const Path v181_6 = concat_path(p0,v179_12_head);
      Space v181_7_result;
      for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
        const Space v181_7_tail = child(v179_12_tail,v181_7_label);
        if (v181_7_tail.empty()) continue;
        const Path v181_7_head{v181_7_label};
        const Space v182_2 = singleton(v181_7_head);
        const Space v182_3 = intersect(constant_5,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_7 : Space{});
        const Space v182_5 = subtract(constant_0,v182_4);
        Space v182_8;
        if (!v182_5.empty()) {
          const Path v183_6 = concat_path(v181_6,v181_7_head);
          const Space v183_7 = routine_44(c, v183_6, v181_7_tail, s1);
          v182_8 = compose(v182_5,v183_7);
        }
        const Space v182_9 = intersect(constant_5,v182_2);
        const Space v182_10 = (has_head(v182_9) ? constant_7 : Space{});
        Space v182_12;
        if (!v182_10.empty()) {
          const Path v184_6 = concat_path(v181_6,v181_7_head);
          const Space v184_11 = routine_45(c, v184_6, v181_7_tail, s1);
          v182_12 = compose(v182_10,v184_11);
        }
        const Space v182_13 = unite(v182_8,v182_12);
        v181_7_result = unite(v181_7_result,v182_13);
      }
      const Space v181_7 = std::move(v181_7_result);
      v180_8 = compose(v180_5,v181_7);
    }
    const Space v180_9 = intersect(constant_5,v180_2);
    const Space v180_10 = (has_head(v180_9) ? constant_7 : Space{});
    Space v180_12;
    if (!v180_10.empty()) {
      const Path v185_6 = concat_path(p0,v179_12_head);
      Space v185_11_result;
      for (int v185_11_label = 1; v185_11_label <= 2; ++v185_11_label) {
        const Space v185_11_tail = child(v179_12_tail,v185_11_label);
        if (v185_11_tail.empty()) continue;
        const Path v185_11_head{v185_11_label};
        const Space v186_2 = singleton(v185_11_head);
        const Space v186_3 = intersect(constant_5,v186_2);
        const Space v186_4 = (has_head(v186_3) ? constant_7 : Space{});
        const Space v186_5 = subtract(constant_0,v186_4);
        Space v186_7;
        if (!v186_5.empty()) {
          const Space v187_6 = routine_20(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_7 = compose(v186_5,v187_6);
        }
        const Space v186_8 = intersect(constant_5,v186_2);
        const Space v186_9 = (has_head(v186_8) ? constant_7 : Space{});
        Space v186_11;
        if (!v186_9.empty()) {
          const Space v188_10 = routine_21(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_11 = compose(v186_9,v188_10);
        }
        const Space v186_12 = unite(v186_7,v186_11);
        v185_11_result = unite(v185_11_result,v186_12);
      }
      const Space v185_11 = std::move(v185_11_result);
      v180_12 = compose(v180_10,v185_11);
    }
    const Space v180_13 = unite(v180_8,v180_12);
    v179_12_result = unite(v179_12_result,v180_13);
  }
  const Space v179_12 = std::move(v179_12_result);
  return v179_12;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v189_12_result;
  for (int v189_12_label = 1; v189_12_label <= 2; ++v189_12_label) {
    const Space v189_12_tail = child(s0,v189_12_label);
    if (v189_12_tail.empty()) continue;
    const Path v189_12_head{v189_12_label};
    const Space v190_2 = singleton(v189_12_head);
    const Space v190_3 = intersect(constant_5,v190_2);
    const Space v190_4 = (has_head(v190_3) ? constant_7 : Space{});
    const Space v190_5 = subtract(constant_0,v190_4);
    Space v190_7;
    if (!v190_5.empty()) {
      Space v191_6_result;
      for (int v191_6_label = 1; v191_6_label <= 2; ++v191_6_label) {
        const Space v191_6_tail = child(v189_12_tail,v191_6_label);
        if (v191_6_tail.empty()) continue;
        const Path v191_6_head{v191_6_label};
        const Space v192_2 = singleton(v191_6_head);
        const Space v192_3 = intersect(constant_5,v192_2);
        const Space v192_4 = (has_head(v192_3) ? constant_7 : Space{});
        const Space v192_5 = subtract(constant_0,v192_4);
        Space v192_8;
        if (!v192_5.empty()) {
          const Path v193_6 = concat_path(v189_12_head,v191_6_head);
          const Space v193_7 = routine_46(c, v193_6, p0, v191_6_tail, s1);
          v192_8 = compose(v192_5,v193_7);
        }
        const Space v192_9 = intersect(constant_5,v192_2);
        const Space v192_10 = (has_head(v192_9) ? constant_7 : Space{});
        Space v192_12;
        if (!v192_10.empty()) {
          const Path v194_6 = concat_path(v189_12_head,v191_6_head);
          const Space v194_11 = routine_47(c, v194_6, p0, v191_6_tail, s1);
          v192_12 = compose(v192_10,v194_11);
        }
        const Space v192_13 = unite(v192_8,v192_12);
        v191_6_result = unite(v191_6_result,v192_13);
      }
      const Space v191_6 = std::move(v191_6_result);
      v190_7 = compose(v190_5,v191_6);
    }
    const Space v190_8 = intersect(constant_5,v190_2);
    const Space v190_9 = (has_head(v190_8) ? constant_7 : Space{});
    Space v190_11;
    if (!v190_9.empty()) {
      Space v195_10_result;
      for (int v195_10_label = 1; v195_10_label <= 2; ++v195_10_label) {
        const Space v195_10_tail = child(v189_12_tail,v195_10_label);
        if (v195_10_tail.empty()) continue;
        const Path v195_10_head{v195_10_label};
        const Space v196_2 = singleton(v195_10_head);
        const Space v196_3 = intersect(constant_5,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_7 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v189_12_head,v195_10_head);
          const Space v197_7 = routine_46(c, v197_6, p0, v195_10_tail, s1);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_5,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_7 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v189_12_head,v195_10_head);
          const Space v198_11 = routine_48(c, v198_6, p0, v195_10_tail, s1);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_10_result = unite(v195_10_result,v196_13);
      }
      const Space v195_10 = std::move(v195_10_result);
      v190_11 = compose(v190_9,v195_10);
    }
    const Space v190_12 = unite(v190_7,v190_11);
    v189_12_result = unite(v189_12_result,v190_12);
  }
  const Space v189_12 = std::move(v189_12_result);
  return v189_12;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v199_13_result;
  for (int v199_13_label = 1; v199_13_label <= 2; ++v199_13_label) {
    const Space v199_13_tail = child(s0,v199_13_label);
    if (v199_13_tail.empty()) continue;
    const Path v199_13_head{v199_13_label};
    const Space v200_2 = singleton(v199_13_head);
    const Space v200_3 = intersect(constant_5,v200_2);
    const Space v200_4 = (has_head(v200_3) ? constant_7 : Space{});
    const Space v200_5 = subtract(constant_0,v200_4);
    Space v200_8;
    if (!v200_5.empty()) {
      const Path v201_6 = concat_path(p0,v199_13_head);
      Space v201_7_result;
      for (int v201_7_label = 1; v201_7_label <= 2; ++v201_7_label) {
        const Space v201_7_tail = child(v199_13_tail,v201_7_label);
        if (v201_7_tail.empty()) continue;
        const Path v201_7_head{v201_7_label};
        const Space v202_2 = singleton(v201_7_head);
        const Space v202_3 = intersect(constant_5,v202_2);
        const Space v202_4 = (has_head(v202_3) ? constant_7 : Space{});
        const Space v202_5 = subtract(constant_0,v202_4);
        Space v202_8;
        if (!v202_5.empty()) {
          const Path v203_6 = concat_path(v201_6,v201_7_head);
          const Space v203_7 = routine_49(c, v203_6, p1, v201_7_tail, s1);
          v202_8 = compose(v202_5,v203_7);
        }
        const Space v202_9 = intersect(constant_5,v202_2);
        const Space v202_10 = (has_head(v202_9) ? constant_7 : Space{});
        Space v202_12;
        if (!v202_10.empty()) {
          const Path v204_6 = concat_path(v201_6,v201_7_head);
          const Space v204_11 = routine_50(c, v204_6, p1, v201_7_tail, s1);
          v202_12 = compose(v202_10,v204_11);
        }
        const Space v202_13 = unite(v202_8,v202_12);
        v201_7_result = unite(v201_7_result,v202_13);
      }
      const Space v201_7 = std::move(v201_7_result);
      v200_8 = compose(v200_5,v201_7);
    }
    const Space v200_9 = intersect(constant_5,v200_2);
    const Space v200_10 = (has_head(v200_9) ? constant_7 : Space{});
    Space v200_12;
    if (!v200_10.empty()) {
      const Path v205_6 = concat_path(p0,v199_13_head);
      Space v205_11_result;
      for (int v205_11_label = 1; v205_11_label <= 2; ++v205_11_label) {
        const Space v205_11_tail = child(v199_13_tail,v205_11_label);
        if (v205_11_tail.empty()) continue;
        const Path v205_11_head{v205_11_label};
        const Space v206_2 = singleton(v205_11_head);
        const Space v206_3 = intersect(constant_5,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_7 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_11_head);
          const Space v207_7 = routine_49(c, v207_6, p1, v205_11_tail, s1);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_5,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_7 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_11_head);
          const Space v208_11 = routine_48(c, v208_6, p1, v205_11_tail, s1);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_11_result = unite(v205_11_result,v206_13);
      }
      const Space v205_11 = std::move(v205_11_result);
      v200_12 = compose(v200_10,v205_11);
    }
    const Space v200_13 = unite(v200_8,v200_12);
    v199_13_result = unite(v199_13_result,v200_13);
  }
  const Space v199_13 = std::move(v199_13_result);
  return v199_13;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v209_8 = unwrap(constant_9,p1);
  const Space v209_10 = unwrap(constant_9,p0);
  const Space v209_12 = unwrap(s1,constant_8);
  const Space v209_14 = unwrap(constant_9,p1);
  const Space v209_16 = unwrap(constant_9,p0);
  Space v209_29_result;
  for (int v209_29_label = 1; v209_29_label <= 2; ++v209_29_label) {
    const Space v209_29_tail = child(s0,v209_29_label);
    if (v209_29_tail.empty()) continue;
    const Path v209_29_head{v209_29_label};
    const Space v210_2 = singleton(v209_29_head);
    const Space v210_3 = intersect(constant_5,v210_2);
    const Space v210_4 = (has_head(v210_3) ? constant_7 : Space{});
    const Space v210_5 = subtract(constant_0,v210_4);
    Space v210_8;
    if (!v210_5.empty()) {
      const Path v211_6 = concat_path(p0,v209_29_head);
      Space v211_7_result;
      for (int v211_7_label = 1; v211_7_label <= 2; ++v211_7_label) {
        const Space v211_7_tail = child(v209_29_tail,v211_7_label);
        if (v211_7_tail.empty()) continue;
        const Path v211_7_head{v211_7_label};
        const Space v212_2 = singleton(v211_7_head);
        const Space v212_3 = intersect(constant_5,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_7 : Space{});
        const Space v212_5 = subtract(constant_0,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_7_head);
          const Space v213_7 = routine_49(c, v213_6, p1, v211_7_tail, s1);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_5,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_7 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_7_head);
          const Space v214_11 = routine_50(c, v214_6, p1, v211_7_tail, s1);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_7_result = unite(v211_7_result,v212_13);
      }
      const Space v211_7 = std::move(v211_7_result);
      v210_8 = compose(v210_5,v211_7);
    }
    const Space v210_9 = intersect(constant_5,v210_2);
    const Space v210_10 = (has_head(v210_9) ? constant_7 : Space{});
    Space v210_28;
    if (!v210_10.empty()) {
      const Path v215_6 = concat_path(p0,v209_29_head);
      const Space v215_11 = unwrap(v209_10,v209_29_head);
      const Space v215_12 = compose(v209_8,v215_11);
      const Path v215_13 = concat_path(p1,v215_6);
      const Space v215_14 = singleton(v215_13);
      const Space v215_15 = subtract(v215_12,v215_14);
      const Space v215_16 = intersect(v215_15,v209_12);
      const Space v215_17 = routine_51(c, v215_16);
      Space v215_18_result;
      for (int v215_18_label = 1; v215_18_label <= 2; ++v215_18_label) {
        const Space v215_18_tail = child(v215_17,v215_18_label);
        if (v215_18_tail.empty()) continue;
        const Path v215_18_head{v215_18_label};
        const Space v216_2 = singleton(v215_18_head);
        const Space v216_3 = intersect(constant_5,v216_2);
        const Space v216_4 = (has_head(v216_3) ? constant_7 : Space{});
        const Space v216_5 = subtract(constant_0,v216_4);
        Space v216_7;
        if (!v216_5.empty()) {
          const Space v217_6 = routine_52(c, v215_18_head, v215_18_tail);
          v216_7 = compose(v216_5,v217_6);
        }
        const Space v216_8 = intersect(constant_5,v216_2);
        const Space v216_9 = (has_head(v216_8) ? constant_7 : Space{});
        Space v216_11;
        if (!v216_9.empty()) {
          const Space v218_10 = routine_53(c, v215_18_head, v215_18_tail);
          v216_11 = compose(v216_9,v218_10);
        }
        const Space v216_12 = unite(v216_7,v216_11);
        v215_18_result = unite(v215_18_result,v216_12);
      }
      const Space v215_18 = std::move(v215_18_result);
      const Space v215_19 = unwrap(v209_16,v209_29_head);
      const Space v215_20 = compose(v209_14,v215_19);
      const Space v215_21 = subtract(v215_20,v215_14);
      const Space v215_22 = intersect(v215_21,v209_12);
      const Space v215_23 = routine_36(c, v215_22);
      Space v215_24_result;
      for (int v215_24_label = 1; v215_24_label <= 2; ++v215_24_label) {
        const Space v215_24_tail = child(v215_23,v215_24_label);
        if (v215_24_tail.empty()) continue;
        const Path v215_24_head{v215_24_label};
        const Space v219_2 = singleton(v215_24_head);
        const Space v219_3 = intersect(constant_5,v219_2);
        const Space v219_4 = (has_head(v219_3) ? constant_7 : Space{});
        const Space v219_5 = subtract(constant_0,v219_4);
        Space v219_7;
        if (!v219_5.empty()) {
          const Space v220_6 = routine_54(c, v215_24_head, v215_24_tail);
          v219_7 = compose(v219_5,v220_6);
        }
        const Space v219_8 = intersect(constant_5,v219_2);
        const Space v219_9 = (has_head(v219_8) ? constant_7 : Space{});
        Space v219_11;
        if (!v219_9.empty()) {
          const Space v221_10 = routine_55(c, v215_24_head, v215_24_tail);
          v219_11 = compose(v219_9,v221_10);
        }
        const Space v219_12 = unite(v219_7,v219_11);
        v215_24_result = unite(v215_24_result,v219_12);
      }
      const Space v215_24 = std::move(v215_24_result);
      const Space v215_25 = subtract(v215_18,v215_24);
      const Space v215_26 = compose(v215_25,v215_14);
      Space v215_27_result;
      for (int v215_27_label = 1; v215_27_label <= 2; ++v215_27_label) {
        const Space v215_27_tail = child(v215_26,v215_27_label);
        if (v215_27_tail.empty()) continue;
        const Path v215_27_head{v215_27_label};
        const Space v222_2 = singleton(v215_27_head);
        const Space v222_3 = intersect(constant_5,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_7 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_56(c, v215_27_head, v215_27_tail);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_5,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_7 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_57(c, v215_27_head, v215_27_tail);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v215_27_result = unite(v215_27_result,v222_12);
      }
      const Space v215_27 = std::move(v215_27_result);
      v210_28 = compose(v210_10,v215_27);
    }
    const Space v210_29 = unite(v210_8,v210_28);
    v209_29_result = unite(v209_29_result,v210_29);
  }
  const Space v209_29 = std::move(v209_29_result);
  return v209_29;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  Space v225_11_result;
  for (int v225_11_label = 1; v225_11_label <= 2; ++v225_11_label) {
    const Space v225_11_tail = child(s0,v225_11_label);
    if (v225_11_tail.empty()) continue;
    const Path v225_11_head{v225_11_label};
    const Space v226_2 = singleton(v225_11_head);
    const Space v226_3 = intersect(constant_5,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_7 : Space{});
    const Space v226_5 = subtract(constant_0,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_11_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_11_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_5,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_7 : Space{});
        const Space v228_5 = subtract(constant_0,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_58(c, v229_6, v227_7_tail);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_5,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_7 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_59(c, v230_6, v227_7_tail);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_5,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_7 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_11_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_11_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_5,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_7 : Space{});
        const Space v232_5 = subtract(constant_0,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_58(c, v233_6, v231_11_tail);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_5,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_7 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_9(c, v234_6, v231_11_tail);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_11_result = unite(v225_11_result,v226_13);
  }
  const Space v225_11 = std::move(v225_11_result);
  return v225_11;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  Space v235_11_result;
  for (int v235_11_label = 1; v235_11_label <= 2; ++v235_11_label) {
    const Space v235_11_tail = child(s0,v235_11_label);
    if (v235_11_tail.empty()) continue;
    const Path v235_11_head{v235_11_label};
    const Space v236_2 = singleton(v235_11_head);
    const Space v236_3 = intersect(constant_5,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_7 : Space{});
    const Space v236_5 = subtract(constant_0,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_11_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_11_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_5,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_7 : Space{});
        const Space v238_5 = subtract(constant_0,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_58(c, v239_6, v237_7_tail);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_5,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_7 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_59(c, v240_6, v237_7_tail);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_5,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_7 : Space{});
    Space v236_12;
    if (!v236_10.empty()) {
      const Path v241_6 = concat_path(p0,v235_11_head);
      Space v241_11_result;
      for (int v241_11_label = 1; v241_11_label <= 2; ++v241_11_label) {
        const Space v241_11_tail = child(v235_11_tail,v241_11_label);
        if (v241_11_tail.empty()) continue;
        const Path v241_11_head{v241_11_label};
        const Space v242_2 = singleton(v241_11_head);
        const Space v242_3 = intersect(constant_5,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_7 : Space{});
        const Space v242_5 = subtract(constant_0,v242_4);
        Space v242_7;
        if (!v242_5.empty()) {
          const Space v243_6 = routine_10(c, v241_11_head, v241_6, v241_11_tail);
          v242_7 = compose(v242_5,v243_6);
        }
        const Space v242_8 = intersect(constant_5,v242_2);
        const Space v242_9 = (has_head(v242_8) ? constant_7 : Space{});
        Space v242_11;
        if (!v242_9.empty()) {
          const Space v244_10 = routine_11(c, v241_11_head, v241_6, v241_11_tail);
          v242_11 = compose(v242_9,v244_10);
        }
        const Space v242_12 = unite(v242_7,v242_11);
        v241_11_result = unite(v241_11_result,v242_12);
      }
      const Space v241_11 = std::move(v241_11_result);
      v236_12 = compose(v236_10,v241_11);
    }
    const Space v236_13 = unite(v236_8,v236_12);
    v235_11_result = unite(v235_11_result,v236_13);
  }
  const Space v235_11 = std::move(v235_11_result);
  return v235_11;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v245_12_result;
  for (int v245_12_label = 1; v245_12_label <= 2; ++v245_12_label) {
    const Space v245_12_tail = child(s0,v245_12_label);
    if (v245_12_tail.empty()) continue;
    const Path v245_12_head{v245_12_label};
    const Space v246_2 = singleton(v245_12_head);
    const Space v246_3 = intersect(constant_5,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_7 : Space{});
    const Space v246_5 = subtract(constant_0,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_12_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_12_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_5,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_7 : Space{});
        const Space v248_5 = subtract(constant_0,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_60(c, v249_6, p1, v247_7_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_5,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_7 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_61(c, v250_6, p1, v247_7_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_5,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_7 : Space{});
    Space v246_12;
    if (!v246_10.empty()) {
      const Path v251_6 = concat_path(p0,v245_12_head);
      Space v251_11_result;
      for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
        const Space v251_11_tail = child(v245_12_tail,v251_11_label);
        if (v251_11_tail.empty()) continue;
        const Path v251_11_head{v251_11_label};
        const Space v252_2 = singleton(v251_11_head);
        const Space v252_3 = intersect(constant_5,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_7 : Space{});
        const Space v252_5 = subtract(constant_0,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_11_head);
          const Space v253_7 = routine_60(c, v253_6, p1, v251_11_tail);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_5,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_7 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_11_head);
          const Space v254_11 = routine_26(c, v254_6, p1, v251_11_tail);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_11_result = unite(v251_11_result,v252_13);
      }
      const Space v251_11 = std::move(v251_11_result);
      v246_12 = compose(v246_10,v251_11);
    }
    const Space v246_13 = unite(v246_8,v246_12);
    v245_12_result = unite(v245_12_result,v246_13);
  }
  const Space v245_12 = std::move(v245_12_result);
  return v245_12;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v255_7 = unwrap(constant_9,p1);
  const Space v255_9 = unwrap(constant_9,p0);
  Space v255_13_result;
  for (int v255_13_label = 1; v255_13_label <= 2; ++v255_13_label) {
    const Space v255_13_tail = child(s0,v255_13_label);
    if (v255_13_tail.empty()) continue;
    const Path v255_13_head{v255_13_label};
    const Space v256_2 = singleton(v255_13_head);
    const Space v256_3 = intersect(constant_5,v256_2);
    const Space v256_4 = (has_head(v256_3) ? constant_7 : Space{});
    const Space v256_5 = subtract(constant_0,v256_4);
    Space v256_8;
    if (!v256_5.empty()) {
      const Path v257_6 = concat_path(p0,v255_13_head);
      Space v257_7_result;
      for (int v257_7_label = 1; v257_7_label <= 2; ++v257_7_label) {
        const Space v257_7_tail = child(v255_13_tail,v257_7_label);
        if (v257_7_tail.empty()) continue;
        const Path v257_7_head{v257_7_label};
        const Space v258_2 = singleton(v257_7_head);
        const Space v258_3 = intersect(constant_5,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_7 : Space{});
        const Space v258_5 = subtract(constant_0,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_7_head);
          const Space v259_7 = routine_60(c, v259_6, p1, v257_7_tail);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_5,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_7 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_7_head);
          const Space v260_11 = routine_61(c, v260_6, p1, v257_7_tail);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_7_result = unite(v257_7_result,v258_13);
      }
      const Space v257_7 = std::move(v257_7_result);
      v256_8 = compose(v256_5,v257_7);
    }
    const Space v256_9 = intersect(constant_5,v256_2);
    const Space v256_10 = (has_head(v256_9) ? constant_7 : Space{});
    const Space v256_11 = unwrap(v255_9,v255_13_head);
    const Space v256_12 = compose(v255_7,v256_11);
    const Path v261_6 = concat_path(p0,v255_13_head);
    const Path v256_13 = concat_path(p1,v261_6);
    const Space v256_14 = singleton(v256_13);
    const Space v256_15 = subtract(v256_12,v256_14);
    const Space v256_16 = compose(v256_10,v256_15);
    const Space v256_17 = unite(v256_8,v256_16);
    v255_13_result = unite(v255_13_result,v256_17);
  }
  const Space v255_13 = std::move(v255_13_result);
  return v255_13;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v262_4 = unwrap(constant_9,p1);
  const Space v262_6 = unwrap(constant_9,p0);
  const Space v262_7 = compose(v262_4,v262_6);
  const Path v262_8 = concat_path(p1,p0);
  const Space v262_9 = singleton(v262_8);
  const Space v262_10 = subtract(v262_7,v262_9);
  return v262_10;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v263_12_result;
  for (int v263_12_label = 1; v263_12_label <= 2; ++v263_12_label) {
    const Space v263_12_tail = child(s0,v263_12_label);
    if (v263_12_tail.empty()) continue;
    const Path v263_12_head{v263_12_label};
    const Space v264_2 = singleton(v263_12_head);
    const Space v264_3 = intersect(constant_5,v264_2);
    const Space v264_4 = (has_head(v264_3) ? constant_7 : Space{});
    const Space v264_5 = subtract(constant_0,v264_4);
    Space v264_8;
    if (!v264_5.empty()) {
      const Path v265_6 = concat_path(p0,v263_12_head);
      Space v265_7_result;
      for (int v265_7_label = 1; v265_7_label <= 2; ++v265_7_label) {
        const Space v265_7_tail = child(v263_12_tail,v265_7_label);
        if (v265_7_tail.empty()) continue;
        const Path v265_7_head{v265_7_label};
        const Space v266_2 = singleton(v265_7_head);
        const Space v266_3 = intersect(constant_5,v266_2);
        const Space v266_4 = (has_head(v266_3) ? constant_7 : Space{});
        const Space v266_5 = subtract(constant_0,v266_4);
        Space v266_8;
        if (!v266_5.empty()) {
          const Path v267_6 = concat_path(v265_6,v265_7_head);
          const Space v267_7 = routine_62(c, v267_6, p1, v265_7_tail);
          v266_8 = compose(v266_5,v267_7);
        }
        const Space v266_9 = intersect(constant_5,v266_2);
        const Space v266_10 = (has_head(v266_9) ? constant_7 : Space{});
        Space v266_12;
        if (!v266_10.empty()) {
          const Path v268_6 = concat_path(v265_6,v265_7_head);
          const Space v268_11 = routine_63(c, v268_6, p1, v265_7_tail);
          v266_12 = compose(v266_10,v268_11);
        }
        const Space v266_13 = unite(v266_8,v266_12);
        v265_7_result = unite(v265_7_result,v266_13);
      }
      const Space v265_7 = std::move(v265_7_result);
      v264_8 = compose(v264_5,v265_7);
    }
    const Space v264_9 = intersect(constant_5,v264_2);
    const Space v264_10 = (has_head(v264_9) ? constant_7 : Space{});
    Space v264_12;
    if (!v264_10.empty()) {
      const Path v269_6 = concat_path(p0,v263_12_head);
      Space v269_11_result;
      for (int v269_11_label = 1; v269_11_label <= 2; ++v269_11_label) {
        const Space v269_11_tail = child(v263_12_tail,v269_11_label);
        if (v269_11_tail.empty()) continue;
        const Path v269_11_head{v269_11_label};
        const Space v270_2 = singleton(v269_11_head);
        const Space v270_3 = intersect(constant_5,v270_2);
        const Space v270_4 = (has_head(v270_3) ? constant_7 : Space{});
        const Space v270_5 = subtract(constant_0,v270_4);
        Space v270_8;
        if (!v270_5.empty()) {
          const Path v271_6 = concat_path(v269_6,v269_11_head);
          const Space v271_7 = routine_62(c, v271_6, p1, v269_11_tail);
          v270_8 = compose(v270_5,v271_7);
        }
        const Space v270_9 = intersect(constant_5,v270_2);
        const Space v270_10 = (has_head(v270_9) ? constant_7 : Space{});
        Space v270_12;
        if (!v270_10.empty()) {
          const Path v272_6 = concat_path(v269_6,v269_11_head);
          const Space v272_11 = routine_26(c, v272_6, p1, v269_11_tail);
          v270_12 = compose(v270_10,v272_11);
        }
        const Space v270_13 = unite(v270_8,v270_12);
        v269_11_result = unite(v269_11_result,v270_13);
      }
      const Space v269_11 = std::move(v269_11_result);
      v264_12 = compose(v264_10,v269_11);
    }
    const Space v264_13 = unite(v264_8,v264_12);
    v263_12_result = unite(v263_12_result,v264_13);
  }
  const Space v263_12 = std::move(v263_12_result);
  return v263_12;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v273_7 = unwrap(constant_9,p1);
  const Space v273_9 = unwrap(constant_9,p0);
  Space v273_13_result;
  for (int v273_13_label = 1; v273_13_label <= 2; ++v273_13_label) {
    const Space v273_13_tail = child(s0,v273_13_label);
    if (v273_13_tail.empty()) continue;
    const Path v273_13_head{v273_13_label};
    const Space v274_2 = singleton(v273_13_head);
    const Space v274_3 = intersect(constant_5,v274_2);
    const Space v274_4 = (has_head(v274_3) ? constant_7 : Space{});
    const Space v274_5 = subtract(constant_0,v274_4);
    Space v274_8;
    if (!v274_5.empty()) {
      const Path v275_6 = concat_path(p0,v273_13_head);
      Space v275_7_result;
      for (int v275_7_label = 1; v275_7_label <= 2; ++v275_7_label) {
        const Space v275_7_tail = child(v273_13_tail,v275_7_label);
        if (v275_7_tail.empty()) continue;
        const Path v275_7_head{v275_7_label};
        const Space v276_2 = singleton(v275_7_head);
        const Space v276_3 = intersect(constant_5,v276_2);
        const Space v276_4 = (has_head(v276_3) ? constant_7 : Space{});
        const Space v276_5 = subtract(constant_0,v276_4);
        Space v276_8;
        if (!v276_5.empty()) {
          const Path v277_6 = concat_path(v275_6,v275_7_head);
          const Space v277_7 = routine_62(c, v277_6, p1, v275_7_tail);
          v276_8 = compose(v276_5,v277_7);
        }
        const Space v276_9 = intersect(constant_5,v276_2);
        const Space v276_10 = (has_head(v276_9) ? constant_7 : Space{});
        Space v276_12;
        if (!v276_10.empty()) {
          const Path v278_6 = concat_path(v275_6,v275_7_head);
          const Space v278_11 = routine_63(c, v278_6, p1, v275_7_tail);
          v276_12 = compose(v276_10,v278_11);
        }
        const Space v276_13 = unite(v276_8,v276_12);
        v275_7_result = unite(v275_7_result,v276_13);
      }
      const Space v275_7 = std::move(v275_7_result);
      v274_8 = compose(v274_5,v275_7);
    }
    const Space v274_9 = intersect(constant_5,v274_2);
    const Space v274_10 = (has_head(v274_9) ? constant_7 : Space{});
    const Space v274_11 = unwrap(v273_9,v273_13_head);
    const Space v274_12 = compose(v273_7,v274_11);
    const Path v279_6 = concat_path(p0,v273_13_head);
    const Path v274_13 = concat_path(p1,v279_6);
    const Space v274_14 = singleton(v274_13);
    const Space v274_15 = subtract(v274_12,v274_14);
    const Space v274_16 = compose(v274_10,v274_15);
    const Space v274_17 = unite(v274_8,v274_16);
    v273_13_result = unite(v273_13_result,v274_17);
  }
  const Space v273_13 = std::move(v273_13_result);
  return v273_13;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v280_12_result;
  for (int v280_12_label = 1; v280_12_label <= 2; ++v280_12_label) {
    const Space v280_12_tail = child(s0,v280_12_label);
    if (v280_12_tail.empty()) continue;
    const Path v280_12_head{v280_12_label};
    const Space v281_2 = singleton(v280_12_head);
    const Space v281_3 = intersect(constant_5,v281_2);
    const Space v281_4 = (has_head(v281_3) ? constant_7 : Space{});
    const Space v281_5 = subtract(constant_0,v281_4);
    Space v281_8;
    if (!v281_5.empty()) {
      const Path v282_6 = concat_path(p0,v280_12_head);
      Space v282_7_result;
      for (int v282_7_label = 1; v282_7_label <= 2; ++v282_7_label) {
        const Space v282_7_tail = child(v280_12_tail,v282_7_label);
        if (v282_7_tail.empty()) continue;
        const Path v282_7_head{v282_7_label};
        const Space v283_2 = singleton(v282_7_head);
        const Space v283_3 = intersect(constant_5,v283_2);
        const Space v283_4 = (has_head(v283_3) ? constant_7 : Space{});
        const Space v283_5 = subtract(constant_0,v283_4);
        Space v283_8;
        if (!v283_5.empty()) {
          const Path v284_6 = concat_path(v282_6,v282_7_head);
          const Space v284_7 = routine_64(c, v284_6, v282_7_tail, s1);
          v283_8 = compose(v283_5,v284_7);
        }
        const Space v283_9 = intersect(constant_5,v283_2);
        const Space v283_10 = (has_head(v283_9) ? constant_7 : Space{});
        Space v283_12;
        if (!v283_10.empty()) {
          const Path v285_6 = concat_path(v282_6,v282_7_head);
          const Space v285_11 = routine_65(c, v285_6, v282_7_tail, s1);
          v283_12 = compose(v283_10,v285_11);
        }
        const Space v283_13 = unite(v283_8,v283_12);
        v282_7_result = unite(v282_7_result,v283_13);
      }
      const Space v282_7 = std::move(v282_7_result);
      v281_8 = compose(v281_5,v282_7);
    }
    const Space v281_9 = intersect(constant_5,v281_2);
    const Space v281_10 = (has_head(v281_9) ? constant_7 : Space{});
    Space v281_12;
    if (!v281_10.empty()) {
      const Path v286_6 = concat_path(p0,v280_12_head);
      Space v286_11_result;
      for (int v286_11_label = 1; v286_11_label <= 2; ++v286_11_label) {
        const Space v286_11_tail = child(v280_12_tail,v286_11_label);
        if (v286_11_tail.empty()) continue;
        const Path v286_11_head{v286_11_label};
        const Space v287_2 = singleton(v286_11_head);
        const Space v287_3 = intersect(constant_5,v287_2);
        const Space v287_4 = (has_head(v287_3) ? constant_7 : Space{});
        const Space v287_5 = subtract(constant_0,v287_4);
        Space v287_8;
        if (!v287_5.empty()) {
          const Path v288_6 = concat_path(v286_6,v286_11_head);
          const Space v288_7 = routine_64(c, v288_6, v286_11_tail, s1);
          v287_8 = compose(v287_5,v288_7);
        }
        const Space v287_9 = intersect(constant_5,v287_2);
        const Space v287_10 = (has_head(v287_9) ? constant_7 : Space{});
        Space v287_12;
        if (!v287_10.empty()) {
          const Path v289_6 = concat_path(v286_6,v286_11_head);
          const Space v289_11 = routine_14(c, v289_6, v286_11_tail, s1);
          v287_12 = compose(v287_10,v289_11);
        }
        const Space v287_13 = unite(v287_8,v287_12);
        v286_11_result = unite(v286_11_result,v287_13);
      }
      const Space v286_11 = std::move(v286_11_result);
      v281_12 = compose(v281_10,v286_11);
    }
    const Space v281_13 = unite(v281_8,v281_12);
    v280_12_result = unite(v280_12_result,v281_13);
  }
  const Space v280_12 = std::move(v280_12_result);
  return v280_12;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v290_12_result;
  for (int v290_12_label = 1; v290_12_label <= 2; ++v290_12_label) {
    const Space v290_12_tail = child(s0,v290_12_label);
    if (v290_12_tail.empty()) continue;
    const Path v290_12_head{v290_12_label};
    const Space v291_2 = singleton(v290_12_head);
    const Space v291_3 = intersect(constant_5,v291_2);
    const Space v291_4 = (has_head(v291_3) ? constant_7 : Space{});
    const Space v291_5 = subtract(constant_0,v291_4);
    Space v291_8;
    if (!v291_5.empty()) {
      const Path v292_6 = concat_path(p0,v290_12_head);
      Space v292_7_result;
      for (int v292_7_label = 1; v292_7_label <= 2; ++v292_7_label) {
        const Space v292_7_tail = child(v290_12_tail,v292_7_label);
        if (v292_7_tail.empty()) continue;
        const Path v292_7_head{v292_7_label};
        const Space v293_2 = singleton(v292_7_head);
        const Space v293_3 = intersect(constant_5,v293_2);
        const Space v293_4 = (has_head(v293_3) ? constant_7 : Space{});
        const Space v293_5 = subtract(constant_0,v293_4);
        Space v293_8;
        if (!v293_5.empty()) {
          const Path v294_6 = concat_path(v292_6,v292_7_head);
          const Space v294_7 = routine_64(c, v294_6, v292_7_tail, s1);
          v293_8 = compose(v293_5,v294_7);
        }
        const Space v293_9 = intersect(constant_5,v293_2);
        const Space v293_10 = (has_head(v293_9) ? constant_7 : Space{});
        Space v293_12;
        if (!v293_10.empty()) {
          const Path v295_6 = concat_path(v292_6,v292_7_head);
          const Space v295_11 = routine_65(c, v295_6, v292_7_tail, s1);
          v293_12 = compose(v293_10,v295_11);
        }
        const Space v293_13 = unite(v293_8,v293_12);
        v292_7_result = unite(v292_7_result,v293_13);
      }
      const Space v292_7 = std::move(v292_7_result);
      v291_8 = compose(v291_5,v292_7);
    }
    const Space v291_9 = intersect(constant_5,v291_2);
    const Space v291_10 = (has_head(v291_9) ? constant_7 : Space{});
    Space v291_12;
    if (!v291_10.empty()) {
      const Path v296_6 = concat_path(p0,v290_12_head);
      Space v296_11_result;
      for (int v296_11_label = 1; v296_11_label <= 2; ++v296_11_label) {
        const Space v296_11_tail = child(v290_12_tail,v296_11_label);
        if (v296_11_tail.empty()) continue;
        const Path v296_11_head{v296_11_label};
        const Space v297_2 = singleton(v296_11_head);
        const Space v297_3 = intersect(constant_5,v297_2);
        const Space v297_4 = (has_head(v297_3) ? constant_7 : Space{});
        const Space v297_5 = subtract(constant_0,v297_4);
        Space v297_7;
        if (!v297_5.empty()) {
          const Space v298_6 = routine_15(c, v296_11_head, v296_6, v296_11_tail, s1);
          v297_7 = compose(v297_5,v298_6);
        }
        const Space v297_8 = intersect(constant_5,v297_2);
        const Space v297_9 = (has_head(v297_8) ? constant_7 : Space{});
        Space v297_11;
        if (!v297_9.empty()) {
          const Space v299_10 = routine_16(c, v296_11_head, v296_6, v296_11_tail, s1);
          v297_11 = compose(v297_9,v299_10);
        }
        const Space v297_12 = unite(v297_7,v297_11);
        v296_11_result = unite(v296_11_result,v297_12);
      }
      const Space v296_11 = std::move(v296_11_result);
      v291_12 = compose(v291_10,v296_11);
    }
    const Space v291_13 = unite(v291_8,v291_12);
    v290_12_result = unite(v290_12_result,v291_13);
  }
  const Space v290_12 = std::move(v290_12_result);
  return v290_12;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v300_13_result;
  for (int v300_13_label = 1; v300_13_label <= 2; ++v300_13_label) {
    const Space v300_13_tail = child(s0,v300_13_label);
    if (v300_13_tail.empty()) continue;
    const Path v300_13_head{v300_13_label};
    const Space v301_2 = singleton(v300_13_head);
    const Space v301_3 = intersect(constant_5,v301_2);
    const Space v301_4 = (has_head(v301_3) ? constant_7 : Space{});
    const Space v301_5 = subtract(constant_0,v301_4);
    Space v301_8;
    if (!v301_5.empty()) {
      const Path v302_6 = concat_path(p0,v300_13_head);
      Space v302_7_result;
      for (int v302_7_label = 1; v302_7_label <= 2; ++v302_7_label) {
        const Space v302_7_tail = child(v300_13_tail,v302_7_label);
        if (v302_7_tail.empty()) continue;
        const Path v302_7_head{v302_7_label};
        const Space v303_2 = singleton(v302_7_head);
        const Space v303_3 = intersect(constant_5,v303_2);
        const Space v303_4 = (has_head(v303_3) ? constant_7 : Space{});
        const Space v303_5 = subtract(constant_0,v303_4);
        Space v303_8;
        if (!v303_5.empty()) {
          const Path v304_6 = concat_path(v302_6,v302_7_head);
          const Space v304_7 = routine_66(c, v304_6, p1, v302_7_tail, s1);
          v303_8 = compose(v303_5,v304_7);
        }
        const Space v303_9 = intersect(constant_5,v303_2);
        const Space v303_10 = (has_head(v303_9) ? constant_7 : Space{});
        Space v303_12;
        if (!v303_10.empty()) {
          const Path v305_6 = concat_path(v302_6,v302_7_head);
          const Space v305_11 = routine_67(c, v305_6, p1, v302_7_tail, s1);
          v303_12 = compose(v303_10,v305_11);
        }
        const Space v303_13 = unite(v303_8,v303_12);
        v302_7_result = unite(v302_7_result,v303_13);
      }
      const Space v302_7 = std::move(v302_7_result);
      v301_8 = compose(v301_5,v302_7);
    }
    const Space v301_9 = intersect(constant_5,v301_2);
    const Space v301_10 = (has_head(v301_9) ? constant_7 : Space{});
    Space v301_12;
    if (!v301_10.empty()) {
      const Path v306_6 = concat_path(p0,v300_13_head);
      Space v306_11_result;
      for (int v306_11_label = 1; v306_11_label <= 2; ++v306_11_label) {
        const Space v306_11_tail = child(v300_13_tail,v306_11_label);
        if (v306_11_tail.empty()) continue;
        const Path v306_11_head{v306_11_label};
        const Space v307_2 = singleton(v306_11_head);
        const Space v307_3 = intersect(constant_5,v307_2);
        const Space v307_4 = (has_head(v307_3) ? constant_7 : Space{});
        const Space v307_5 = subtract(constant_0,v307_4);
        Space v307_8;
        if (!v307_5.empty()) {
          const Path v308_6 = concat_path(v306_6,v306_11_head);
          const Space v308_7 = routine_66(c, v308_6, p1, v306_11_tail, s1);
          v307_8 = compose(v307_5,v308_7);
        }
        const Space v307_9 = intersect(constant_5,v307_2);
        const Space v307_10 = (has_head(v307_9) ? constant_7 : Space{});
        Space v307_12;
        if (!v307_10.empty()) {
          const Path v309_6 = concat_path(v306_6,v306_11_head);
          const Space v309_11 = routine_33(c, v309_6, p1, v306_11_tail, s1);
          v307_12 = compose(v307_10,v309_11);
        }
        const Space v307_13 = unite(v307_8,v307_12);
        v306_11_result = unite(v306_11_result,v307_13);
      }
      const Space v306_11 = std::move(v306_11_result);
      v301_12 = compose(v301_10,v306_11);
    }
    const Space v301_13 = unite(v301_8,v301_12);
    v300_13_result = unite(v300_13_result,v301_13);
  }
  const Space v300_13 = std::move(v300_13_result);
  return v300_13;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v310_8 = unwrap(constant_9,p1);
  const Space v310_10 = unwrap(constant_9,p0);
  const Space v310_12 = unwrap(s1,constant_8);
  const Space v310_14 = unwrap(constant_9,p1);
  const Space v310_16 = unwrap(constant_9,p0);
  Space v310_29_result;
  for (int v310_29_label = 1; v310_29_label <= 2; ++v310_29_label) {
    const Space v310_29_tail = child(s0,v310_29_label);
    if (v310_29_tail.empty()) continue;
    const Path v310_29_head{v310_29_label};
    const Space v311_2 = singleton(v310_29_head);
    const Space v311_3 = intersect(constant_5,v311_2);
    const Space v311_4 = (has_head(v311_3) ? constant_7 : Space{});
    const Space v311_5 = subtract(constant_0,v311_4);
    Space v311_8;
    if (!v311_5.empty()) {
      const Path v312_6 = concat_path(p0,v310_29_head);
      Space v312_7_result;
      for (int v312_7_label = 1; v312_7_label <= 2; ++v312_7_label) {
        const Space v312_7_tail = child(v310_29_tail,v312_7_label);
        if (v312_7_tail.empty()) continue;
        const Path v312_7_head{v312_7_label};
        const Space v313_2 = singleton(v312_7_head);
        const Space v313_3 = intersect(constant_5,v313_2);
        const Space v313_4 = (has_head(v313_3) ? constant_7 : Space{});
        const Space v313_5 = subtract(constant_0,v313_4);
        Space v313_8;
        if (!v313_5.empty()) {
          const Path v314_6 = concat_path(v312_6,v312_7_head);
          const Space v314_7 = routine_66(c, v314_6, p1, v312_7_tail, s1);
          v313_8 = compose(v313_5,v314_7);
        }
        const Space v313_9 = intersect(constant_5,v313_2);
        const Space v313_10 = (has_head(v313_9) ? constant_7 : Space{});
        Space v313_12;
        if (!v313_10.empty()) {
          const Path v315_6 = concat_path(v312_6,v312_7_head);
          const Space v315_11 = routine_67(c, v315_6, p1, v312_7_tail, s1);
          v313_12 = compose(v313_10,v315_11);
        }
        const Space v313_13 = unite(v313_8,v313_12);
        v312_7_result = unite(v312_7_result,v313_13);
      }
      const Space v312_7 = std::move(v312_7_result);
      v311_8 = compose(v311_5,v312_7);
    }
    const Space v311_9 = intersect(constant_5,v311_2);
    const Space v311_10 = (has_head(v311_9) ? constant_7 : Space{});
    Space v311_28;
    if (!v311_10.empty()) {
      const Path v316_6 = concat_path(p0,v310_29_head);
      const Space v316_11 = unwrap(v310_10,v310_29_head);
      const Space v316_12 = compose(v310_8,v316_11);
      const Path v316_13 = concat_path(p1,v316_6);
      const Space v316_14 = singleton(v316_13);
      const Space v316_15 = subtract(v316_12,v316_14);
      const Space v316_16 = intersect(v316_15,v310_12);
      const Space v316_17 = routine_36(c, v316_16);
      Space v316_18_result;
      for (int v316_18_label = 1; v316_18_label <= 2; ++v316_18_label) {
        const Space v316_18_tail = child(v316_17,v316_18_label);
        if (v316_18_tail.empty()) continue;
        const Path v316_18_head{v316_18_label};
        const Space v317_2 = singleton(v316_18_head);
        const Space v317_3 = intersect(constant_5,v317_2);
        const Space v317_4 = (has_head(v317_3) ? constant_7 : Space{});
        const Space v317_5 = subtract(constant_0,v317_4);
        Space v317_7;
        if (!v317_5.empty()) {
          const Space v318_6 = routine_37(c, v316_18_head, v316_18_tail);
          v317_7 = compose(v317_5,v318_6);
        }
        const Space v317_8 = intersect(constant_5,v317_2);
        const Space v317_9 = (has_head(v317_8) ? constant_7 : Space{});
        Space v317_11;
        if (!v317_9.empty()) {
          const Space v319_10 = routine_38(c, v316_18_head, v316_18_tail);
          v317_11 = compose(v317_9,v319_10);
        }
        const Space v317_12 = unite(v317_7,v317_11);
        v316_18_result = unite(v316_18_result,v317_12);
      }
      const Space v316_18 = std::move(v316_18_result);
      const Space v316_19 = unwrap(v310_16,v310_29_head);
      const Space v316_20 = compose(v310_14,v316_19);
      const Space v316_21 = subtract(v316_20,v316_14);
      const Space v316_22 = intersect(v316_21,v310_12);
      const Space v316_23 = routine_39(c, v316_22);
      Space v316_24_result;
      for (int v316_24_label = 1; v316_24_label <= 2; ++v316_24_label) {
        const Space v316_24_tail = child(v316_23,v316_24_label);
        if (v316_24_tail.empty()) continue;
        const Path v316_24_head{v316_24_label};
        const Space v320_2 = singleton(v316_24_head);
        const Space v320_3 = intersect(constant_5,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_7 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_7;
        if (!v320_5.empty()) {
          const Space v321_6 = routine_40(c, v316_24_head, v316_24_tail);
          v320_7 = compose(v320_5,v321_6);
        }
        const Space v320_8 = intersect(constant_5,v320_2);
        const Space v320_9 = (has_head(v320_8) ? constant_7 : Space{});
        Space v320_11;
        if (!v320_9.empty()) {
          const Space v322_10 = routine_41(c, v316_24_head, v316_24_tail);
          v320_11 = compose(v320_9,v322_10);
        }
        const Space v320_12 = unite(v320_7,v320_11);
        v316_24_result = unite(v316_24_result,v320_12);
      }
      const Space v316_24 = std::move(v316_24_result);
      const Space v316_25 = subtract(v316_18,v316_24);
      const Space v316_26 = compose(v316_25,v316_14);
      Space v316_27_result;
      for (int v316_27_label = 1; v316_27_label <= 2; ++v316_27_label) {
        const Space v316_27_tail = child(v316_26,v316_27_label);
        if (v316_27_tail.empty()) continue;
        const Path v316_27_head{v316_27_label};
        const Space v323_2 = singleton(v316_27_head);
        const Space v323_3 = intersect(constant_5,v323_2);
        const Space v323_4 = (has_head(v323_3) ? constant_7 : Space{});
        const Space v323_5 = subtract(constant_0,v323_4);
        Space v323_7;
        if (!v323_5.empty()) {
          const Space v324_6 = routine_42(c, v316_27_head, v316_27_tail);
          v323_7 = compose(v323_5,v324_6);
        }
        const Space v323_8 = intersect(constant_5,v323_2);
        const Space v323_9 = (has_head(v323_8) ? constant_7 : Space{});
        Space v323_11;
        if (!v323_9.empty()) {
          const Space v325_10 = routine_43(c, v316_27_head, v316_27_tail);
          v323_11 = compose(v323_9,v325_10);
        }
        const Space v323_12 = unite(v323_7,v323_11);
        v316_27_result = unite(v316_27_result,v323_12);
      }
      const Space v316_27 = std::move(v316_27_result);
      v311_28 = compose(v311_10,v316_27);
    }
    const Space v311_29 = unite(v311_8,v311_28);
    v310_29_result = unite(v310_29_result,v311_29);
  }
  const Space v310_29 = std::move(v310_29_result);
  return v310_29;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v326_5 = unwrap(constant_9,p1);
  const Space v326_7 = unwrap(constant_9,p0);
  const Space v326_8 = compose(v326_5,v326_7);
  const Path v326_9 = concat_path(p1,p0);
  const Space v326_10 = singleton(v326_9);
  const Space v326_11 = subtract(v326_8,v326_10);
  const Space v326_13 = unwrap(s1,constant_8);
  const Space v326_14 = intersect(v326_11,v326_13);
  const Space v326_16 = unwrap(constant_9,p1);
  const Space v326_18 = unwrap(constant_9,p0);
  const Space v326_19 = compose(v326_16,v326_18);
  const Space v326_20 = subtract(v326_19,v326_10);
  const Space v326_21 = intersect(v326_20,v326_13);
  const Space v326_22 = routine_68(c, v326_21);
  const Space v326_23 = routine_69(c, v326_22);
  const Space v326_24 = subtract(v326_14,v326_23);
  const Space v326_26 = unwrap(constant_9,p1);
  const Space v326_28 = unwrap(constant_9,p0);
  const Space v326_29 = compose(v326_26,v326_28);
  const Space v326_30 = subtract(v326_29,v326_10);
  const Space v326_31 = intersect(v326_30,v326_13);
  const Space v326_32 = routine_69(c, v326_31);
  const Space v326_33 = intersect(v326_24,v326_32);
  Space v326_43_result;
  for (int v326_43_label = 1; v326_43_label <= 2; ++v326_43_label) {
    const Space v326_43_tail = child(v326_33,v326_43_label);
    if (v326_43_tail.empty()) continue;
    const Path v326_43_head{v326_43_label};
    const Space v327_2 = singleton(v326_43_head);
    const Space v327_3 = intersect(constant_5,v327_2);
    const Space v327_4 = (has_head(v327_3) ? constant_7 : Space{});
    const Space v327_5 = subtract(constant_0,v327_4);
    Space v327_7;
    if (!v327_5.empty()) {
      Space v328_6_result;
      for (int v328_6_label = 1; v328_6_label <= 2; ++v328_6_label) {
        const Space v328_6_tail = child(v326_43_tail,v328_6_label);
        if (v328_6_tail.empty()) continue;
        const Path v328_6_head{v328_6_label};
        const Space v329_2 = singleton(v328_6_head);
        const Space v329_3 = intersect(constant_5,v329_2);
        const Space v329_4 = (has_head(v329_3) ? constant_7 : Space{});
        const Space v329_5 = subtract(constant_0,v329_4);
        Space v329_8;
        if (!v329_5.empty()) {
          const Path v330_6 = concat_path(v326_43_head,v328_6_head);
          const Space v330_7 = routine_70(c, v330_6, v328_6_tail);
          v329_8 = compose(v329_5,v330_7);
        }
        const Space v329_9 = intersect(constant_5,v329_2);
        const Space v329_10 = (has_head(v329_9) ? constant_7 : Space{});
        Space v329_12;
        if (!v329_10.empty()) {
          const Path v331_6 = concat_path(v326_43_head,v328_6_head);
          const Space v331_11 = routine_71(c, v331_6, v328_6_tail);
          v329_12 = compose(v329_10,v331_11);
        }
        const Space v329_13 = unite(v329_8,v329_12);
        v328_6_result = unite(v328_6_result,v329_13);
      }
      const Space v328_6 = std::move(v328_6_result);
      v327_7 = compose(v327_5,v328_6);
    }
    const Space v327_8 = intersect(constant_5,v327_2);
    const Space v327_9 = (has_head(v327_8) ? constant_7 : Space{});
    Space v327_11;
    if (!v327_9.empty()) {
      Space v332_10_result;
      for (int v332_10_label = 1; v332_10_label <= 2; ++v332_10_label) {
        const Space v332_10_tail = child(v326_43_tail,v332_10_label);
        if (v332_10_tail.empty()) continue;
        const Path v332_10_head{v332_10_label};
        const Space v333_2 = singleton(v332_10_head);
        const Space v333_3 = intersect(constant_5,v333_2);
        const Space v333_4 = (has_head(v333_3) ? constant_7 : Space{});
        const Space v333_5 = subtract(constant_0,v333_4);
        Space v333_8;
        if (!v333_5.empty()) {
          const Path v334_6 = concat_path(v326_43_head,v332_10_head);
          const Space v334_7 = routine_70(c, v334_6, v332_10_tail);
          v333_8 = compose(v333_5,v334_7);
        }
        const Space v333_9 = intersect(constant_5,v333_2);
        const Space v333_10 = (has_head(v333_9) ? constant_7 : Space{});
        Space v333_12;
        if (!v333_10.empty()) {
          const Path v335_6 = concat_path(v326_43_head,v332_10_head);
          const Space v335_11 = routine_72(c, v335_6, v332_10_tail);
          v333_12 = compose(v333_10,v335_11);
        }
        const Space v333_13 = unite(v333_8,v333_12);
        v332_10_result = unite(v332_10_result,v333_13);
      }
      const Space v332_10 = std::move(v332_10_result);
      v327_11 = compose(v327_9,v332_10);
    }
    const Space v327_12 = unite(v327_7,v327_11);
    v326_43_result = unite(v326_43_result,v327_12);
  }
  const Space v326_43 = std::move(v326_43_result);
  const Space v326_45 = unwrap(constant_9,p1);
  const Space v326_47 = unwrap(constant_9,p0);
  const Space v326_48 = compose(v326_45,v326_47);
  const Space v326_49 = subtract(v326_48,v326_10);
  const Space v326_50 = intersect(v326_49,v326_13);
  const Space v326_52 = unwrap(constant_9,p1);
  const Space v326_54 = unwrap(constant_9,p0);
  const Space v326_55 = compose(v326_52,v326_54);
  const Space v326_56 = subtract(v326_55,v326_10);
  const Space v326_57 = intersect(v326_56,v326_13);
  const Space v326_58 = routine_73(c, v326_57);
  const Space v326_59 = subtract(v326_50,v326_58);
  const Space v326_61 = unwrap(constant_9,p1);
  const Space v326_63 = unwrap(constant_9,p0);
  const Space v326_64 = compose(v326_61,v326_63);
  const Space v326_65 = subtract(v326_64,v326_10);
  const Space v326_66 = intersect(v326_65,v326_13);
  const Space v326_67 = routine_68(c, v326_66);
  const Space v326_68 = routine_69(c, v326_67);
  const Space v326_69 = intersect(v326_59,v326_68);
  Space v326_79_result;
  for (int v326_79_label = 1; v326_79_label <= 2; ++v326_79_label) {
    const Space v326_79_tail = child(v326_69,v326_79_label);
    if (v326_79_tail.empty()) continue;
    const Path v326_79_head{v326_79_label};
    const Space v336_2 = singleton(v326_79_head);
    const Space v336_3 = intersect(constant_5,v336_2);
    const Space v336_4 = (has_head(v336_3) ? constant_7 : Space{});
    const Space v336_5 = subtract(constant_0,v336_4);
    Space v336_7;
    if (!v336_5.empty()) {
      Space v337_6_result;
      for (int v337_6_label = 1; v337_6_label <= 2; ++v337_6_label) {
        const Space v337_6_tail = child(v326_79_tail,v337_6_label);
        if (v337_6_tail.empty()) continue;
        const Path v337_6_head{v337_6_label};
        const Space v338_2 = singleton(v337_6_head);
        const Space v338_3 = intersect(constant_5,v338_2);
        const Space v338_4 = (has_head(v338_3) ? constant_7 : Space{});
        const Space v338_5 = subtract(constant_0,v338_4);
        Space v338_8;
        if (!v338_5.empty()) {
          const Path v339_6 = concat_path(v326_79_head,v337_6_head);
          const Space v339_7 = routine_74(c, v339_6, v337_6_tail);
          v338_8 = compose(v338_5,v339_7);
        }
        const Space v338_9 = intersect(constant_5,v338_2);
        const Space v338_10 = (has_head(v338_9) ? constant_7 : Space{});
        Space v338_12;
        if (!v338_10.empty()) {
          const Path v340_6 = concat_path(v326_79_head,v337_6_head);
          const Space v340_11 = routine_75(c, v340_6, v337_6_tail);
          v338_12 = compose(v338_10,v340_11);
        }
        const Space v338_13 = unite(v338_8,v338_12);
        v337_6_result = unite(v337_6_result,v338_13);
      }
      const Space v337_6 = std::move(v337_6_result);
      v336_7 = compose(v336_5,v337_6);
    }
    const Space v336_8 = intersect(constant_5,v336_2);
    const Space v336_9 = (has_head(v336_8) ? constant_7 : Space{});
    Space v336_11;
    if (!v336_9.empty()) {
      Space v341_10_result;
      for (int v341_10_label = 1; v341_10_label <= 2; ++v341_10_label) {
        const Space v341_10_tail = child(v326_79_tail,v341_10_label);
        if (v341_10_tail.empty()) continue;
        const Path v341_10_head{v341_10_label};
        const Space v342_2 = singleton(v341_10_head);
        const Space v342_3 = intersect(constant_5,v342_2);
        const Space v342_4 = (has_head(v342_3) ? constant_7 : Space{});
        const Space v342_5 = subtract(constant_0,v342_4);
        Space v342_8;
        if (!v342_5.empty()) {
          const Path v343_6 = concat_path(v326_79_head,v341_10_head);
          const Space v343_7 = routine_74(c, v343_6, v341_10_tail);
          v342_8 = compose(v342_5,v343_7);
        }
        const Space v342_9 = intersect(constant_5,v342_2);
        const Space v342_10 = (has_head(v342_9) ? constant_7 : Space{});
        Space v342_12;
        if (!v342_10.empty()) {
          const Path v344_6 = concat_path(v326_79_head,v341_10_head);
          const Space v344_11 = routine_76(c, v344_6, v341_10_tail);
          v342_12 = compose(v342_10,v344_11);
        }
        const Space v342_13 = unite(v342_8,v342_12);
        v341_10_result = unite(v341_10_result,v342_13);
      }
      const Space v341_10 = std::move(v341_10_result);
      v336_11 = compose(v336_9,v341_10);
    }
    const Space v336_12 = unite(v336_7,v336_11);
    v326_79_result = unite(v326_79_result,v336_12);
  }
  const Space v326_79 = std::move(v326_79_result);
  const Space v326_80 = subtract(v326_43,v326_79);
  const Space v326_81 = compose(v326_80,v326_10);
  Space v326_91_result;
  for (int v326_91_label = 1; v326_91_label <= 2; ++v326_91_label) {
    const Space v326_91_tail = child(v326_81,v326_91_label);
    if (v326_91_tail.empty()) continue;
    const Path v326_91_head{v326_91_label};
    const Space v345_2 = singleton(v326_91_head);
    const Space v345_3 = intersect(constant_5,v345_2);
    const Space v345_4 = (has_head(v345_3) ? constant_7 : Space{});
    const Space v345_5 = subtract(constant_0,v345_4);
    Space v345_7;
    if (!v345_5.empty()) {
      Space v346_6_result;
      for (int v346_6_label = 1; v346_6_label <= 2; ++v346_6_label) {
        const Space v346_6_tail = child(v326_91_tail,v346_6_label);
        if (v346_6_tail.empty()) continue;
        const Path v346_6_head{v346_6_label};
        const Space v347_2 = singleton(v346_6_head);
        const Space v347_3 = intersect(constant_5,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_7 : Space{});
        const Space v347_5 = subtract(constant_0,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v326_91_head,v346_6_head);
          const Space v348_7 = routine_77(c, v348_6, v346_6_tail);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_5,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_7 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v326_91_head,v346_6_head);
          const Space v349_11 = routine_78(c, v349_6, v346_6_tail);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_6_result = unite(v346_6_result,v347_13);
      }
      const Space v346_6 = std::move(v346_6_result);
      v345_7 = compose(v345_5,v346_6);
    }
    const Space v345_8 = intersect(constant_5,v345_2);
    const Space v345_9 = (has_head(v345_8) ? constant_7 : Space{});
    Space v345_11;
    if (!v345_9.empty()) {
      Space v350_10_result;
      for (int v350_10_label = 1; v350_10_label <= 2; ++v350_10_label) {
        const Space v350_10_tail = child(v326_91_tail,v350_10_label);
        if (v350_10_tail.empty()) continue;
        const Path v350_10_head{v350_10_label};
        const Space v351_2 = singleton(v350_10_head);
        const Space v351_3 = intersect(constant_5,v351_2);
        const Space v351_4 = (has_head(v351_3) ? constant_7 : Space{});
        const Space v351_5 = subtract(constant_0,v351_4);
        Space v351_8;
        if (!v351_5.empty()) {
          const Path v352_6 = concat_path(v326_91_head,v350_10_head);
          const Space v352_7 = routine_77(c, v352_6, v350_10_tail);
          v351_8 = compose(v351_5,v352_7);
        }
        const Space v351_9 = intersect(constant_5,v351_2);
        const Space v351_10 = (has_head(v351_9) ? constant_7 : Space{});
        Space v351_12;
        if (!v351_10.empty()) {
          const Path v353_6 = concat_path(v326_91_head,v350_10_head);
          const Space v353_11 = routine_79(c, v353_6, v350_10_tail);
          v351_12 = compose(v351_10,v353_11);
        }
        const Space v351_13 = unite(v351_8,v351_12);
        v350_10_result = unite(v350_10_result,v351_13);
      }
      const Space v350_10 = std::move(v350_10_result);
      v345_11 = compose(v345_9,v350_10);
    }
    const Space v345_12 = unite(v345_7,v345_11);
    v326_91_result = unite(v326_91_result,v345_12);
  }
  const Space v326_91 = std::move(v326_91_result);
  return v326_91;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v354_13_result;
  for (int v354_13_label = 1; v354_13_label <= 2; ++v354_13_label) {
    const Space v354_13_tail = child(s0,v354_13_label);
    if (v354_13_tail.empty()) continue;
    const Path v354_13_head{v354_13_label};
    const Space v355_2 = singleton(v354_13_head);
    const Space v355_3 = intersect(constant_5,v355_2);
    const Space v355_4 = (has_head(v355_3) ? constant_7 : Space{});
    const Space v355_5 = subtract(constant_0,v355_4);
    Space v355_8;
    if (!v355_5.empty()) {
      const Path v356_6 = concat_path(p0,v354_13_head);
      Space v356_7_result;
      for (int v356_7_label = 1; v356_7_label <= 2; ++v356_7_label) {
        const Space v356_7_tail = child(v354_13_tail,v356_7_label);
        if (v356_7_tail.empty()) continue;
        const Path v356_7_head{v356_7_label};
        const Space v357_2 = singleton(v356_7_head);
        const Space v357_3 = intersect(constant_5,v357_2);
        const Space v357_4 = (has_head(v357_3) ? constant_7 : Space{});
        const Space v357_5 = subtract(constant_0,v357_4);
        Space v357_8;
        if (!v357_5.empty()) {
          const Path v358_6 = concat_path(v356_6,v356_7_head);
          const Space v358_7 = routine_80(c, v358_6, p1, v356_7_tail, s1);
          v357_8 = compose(v357_5,v358_7);
        }
        const Space v357_9 = intersect(constant_5,v357_2);
        const Space v357_10 = (has_head(v357_9) ? constant_7 : Space{});
        Space v357_12;
        if (!v357_10.empty()) {
          const Path v359_6 = concat_path(v356_6,v356_7_head);
          const Space v359_11 = routine_81(c, v359_6, p1, v356_7_tail, s1);
          v357_12 = compose(v357_10,v359_11);
        }
        const Space v357_13 = unite(v357_8,v357_12);
        v356_7_result = unite(v356_7_result,v357_13);
      }
      const Space v356_7 = std::move(v356_7_result);
      v355_8 = compose(v355_5,v356_7);
    }
    const Space v355_9 = intersect(constant_5,v355_2);
    const Space v355_10 = (has_head(v355_9) ? constant_7 : Space{});
    Space v355_12;
    if (!v355_10.empty()) {
      const Path v360_6 = concat_path(p0,v354_13_head);
      Space v360_11_result;
      for (int v360_11_label = 1; v360_11_label <= 2; ++v360_11_label) {
        const Space v360_11_tail = child(v354_13_tail,v360_11_label);
        if (v360_11_tail.empty()) continue;
        const Path v360_11_head{v360_11_label};
        const Space v361_2 = singleton(v360_11_head);
        const Space v361_3 = intersect(constant_5,v361_2);
        const Space v361_4 = (has_head(v361_3) ? constant_7 : Space{});
        const Space v361_5 = subtract(constant_0,v361_4);
        Space v361_8;
        if (!v361_5.empty()) {
          const Path v362_6 = concat_path(v360_6,v360_11_head);
          const Space v362_7 = routine_80(c, v362_6, p1, v360_11_tail, s1);
          v361_8 = compose(v361_5,v362_7);
        }
        const Space v361_9 = intersect(constant_5,v361_2);
        const Space v361_10 = (has_head(v361_9) ? constant_7 : Space{});
        Space v361_12;
        if (!v361_10.empty()) {
          const Path v363_6 = concat_path(v360_6,v360_11_head);
          const Space v363_11 = routine_33(c, v363_6, p1, v360_11_tail, s1);
          v361_12 = compose(v361_10,v363_11);
        }
        const Space v361_13 = unite(v361_8,v361_12);
        v360_11_result = unite(v360_11_result,v361_13);
      }
      const Space v360_11 = std::move(v360_11_result);
      v355_12 = compose(v355_10,v360_11);
    }
    const Space v355_13 = unite(v355_8,v355_12);
    v354_13_result = unite(v354_13_result,v355_13);
  }
  const Space v354_13 = std::move(v354_13_result);
  return v354_13;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v364_8 = unwrap(constant_9,p1);
  const Space v364_10 = unwrap(constant_9,p0);
  const Space v364_12 = unwrap(s1,constant_8);
  const Space v364_14 = unwrap(constant_9,p1);
  const Space v364_16 = unwrap(constant_9,p0);
  Space v364_29_result;
  for (int v364_29_label = 1; v364_29_label <= 2; ++v364_29_label) {
    const Space v364_29_tail = child(s0,v364_29_label);
    if (v364_29_tail.empty()) continue;
    const Path v364_29_head{v364_29_label};
    const Space v365_2 = singleton(v364_29_head);
    const Space v365_3 = intersect(constant_5,v365_2);
    const Space v365_4 = (has_head(v365_3) ? constant_7 : Space{});
    const Space v365_5 = subtract(constant_0,v365_4);
    Space v365_8;
    if (!v365_5.empty()) {
      const Path v366_6 = concat_path(p0,v364_29_head);
      Space v366_7_result;
      for (int v366_7_label = 1; v366_7_label <= 2; ++v366_7_label) {
        const Space v366_7_tail = child(v364_29_tail,v366_7_label);
        if (v366_7_tail.empty()) continue;
        const Path v366_7_head{v366_7_label};
        const Space v367_2 = singleton(v366_7_head);
        const Space v367_3 = intersect(constant_5,v367_2);
        const Space v367_4 = (has_head(v367_3) ? constant_7 : Space{});
        const Space v367_5 = subtract(constant_0,v367_4);
        Space v367_8;
        if (!v367_5.empty()) {
          const Path v368_6 = concat_path(v366_6,v366_7_head);
          const Space v368_7 = routine_80(c, v368_6, p1, v366_7_tail, s1);
          v367_8 = compose(v367_5,v368_7);
        }
        const Space v367_9 = intersect(constant_5,v367_2);
        const Space v367_10 = (has_head(v367_9) ? constant_7 : Space{});
        Space v367_12;
        if (!v367_10.empty()) {
          const Path v369_6 = concat_path(v366_6,v366_7_head);
          const Space v369_11 = routine_81(c, v369_6, p1, v366_7_tail, s1);
          v367_12 = compose(v367_10,v369_11);
        }
        const Space v367_13 = unite(v367_8,v367_12);
        v366_7_result = unite(v366_7_result,v367_13);
      }
      const Space v366_7 = std::move(v366_7_result);
      v365_8 = compose(v365_5,v366_7);
    }
    const Space v365_9 = intersect(constant_5,v365_2);
    const Space v365_10 = (has_head(v365_9) ? constant_7 : Space{});
    Space v365_28;
    if (!v365_10.empty()) {
      const Path v370_6 = concat_path(p0,v364_29_head);
      const Space v370_11 = unwrap(v364_10,v364_29_head);
      const Space v370_12 = compose(v364_8,v370_11);
      const Path v370_13 = concat_path(p1,v370_6);
      const Space v370_14 = singleton(v370_13);
      const Space v370_15 = subtract(v370_12,v370_14);
      const Space v370_16 = intersect(v370_15,v364_12);
      const Space v370_17 = routine_36(c, v370_16);
      Space v370_18_result;
      for (int v370_18_label = 1; v370_18_label <= 2; ++v370_18_label) {
        const Space v370_18_tail = child(v370_17,v370_18_label);
        if (v370_18_tail.empty()) continue;
        const Path v370_18_head{v370_18_label};
        const Space v371_2 = singleton(v370_18_head);
        const Space v371_3 = intersect(constant_5,v371_2);
        const Space v371_4 = (has_head(v371_3) ? constant_7 : Space{});
        const Space v371_5 = subtract(constant_0,v371_4);
        Space v371_7;
        if (!v371_5.empty()) {
          const Space v372_6 = routine_37(c, v370_18_head, v370_18_tail);
          v371_7 = compose(v371_5,v372_6);
        }
        const Space v371_8 = intersect(constant_5,v371_2);
        const Space v371_9 = (has_head(v371_8) ? constant_7 : Space{});
        Space v371_11;
        if (!v371_9.empty()) {
          const Space v373_10 = routine_38(c, v370_18_head, v370_18_tail);
          v371_11 = compose(v371_9,v373_10);
        }
        const Space v371_12 = unite(v371_7,v371_11);
        v370_18_result = unite(v370_18_result,v371_12);
      }
      const Space v370_18 = std::move(v370_18_result);
      const Space v370_19 = unwrap(v364_16,v364_29_head);
      const Space v370_20 = compose(v364_14,v370_19);
      const Space v370_21 = subtract(v370_20,v370_14);
      const Space v370_22 = intersect(v370_21,v364_12);
      const Space v370_23 = routine_39(c, v370_22);
      Space v370_24_result;
      for (int v370_24_label = 1; v370_24_label <= 2; ++v370_24_label) {
        const Space v370_24_tail = child(v370_23,v370_24_label);
        if (v370_24_tail.empty()) continue;
        const Path v370_24_head{v370_24_label};
        const Space v374_2 = singleton(v370_24_head);
        const Space v374_3 = intersect(constant_5,v374_2);
        const Space v374_4 = (has_head(v374_3) ? constant_7 : Space{});
        const Space v374_5 = subtract(constant_0,v374_4);
        Space v374_7;
        if (!v374_5.empty()) {
          const Space v375_6 = routine_40(c, v370_24_head, v370_24_tail);
          v374_7 = compose(v374_5,v375_6);
        }
        const Space v374_8 = intersect(constant_5,v374_2);
        const Space v374_9 = (has_head(v374_8) ? constant_7 : Space{});
        Space v374_11;
        if (!v374_9.empty()) {
          const Space v376_10 = routine_41(c, v370_24_head, v370_24_tail);
          v374_11 = compose(v374_9,v376_10);
        }
        const Space v374_12 = unite(v374_7,v374_11);
        v370_24_result = unite(v370_24_result,v374_12);
      }
      const Space v370_24 = std::move(v370_24_result);
      const Space v370_25 = subtract(v370_18,v370_24);
      const Space v370_26 = compose(v370_25,v370_14);
      Space v370_27_result;
      for (int v370_27_label = 1; v370_27_label <= 2; ++v370_27_label) {
        const Space v370_27_tail = child(v370_26,v370_27_label);
        if (v370_27_tail.empty()) continue;
        const Path v370_27_head{v370_27_label};
        const Space v377_2 = singleton(v370_27_head);
        const Space v377_3 = intersect(constant_5,v377_2);
        const Space v377_4 = (has_head(v377_3) ? constant_7 : Space{});
        const Space v377_5 = subtract(constant_0,v377_4);
        Space v377_7;
        if (!v377_5.empty()) {
          const Space v378_6 = routine_42(c, v370_27_head, v370_27_tail);
          v377_7 = compose(v377_5,v378_6);
        }
        const Space v377_8 = intersect(constant_5,v377_2);
        const Space v377_9 = (has_head(v377_8) ? constant_7 : Space{});
        Space v377_11;
        if (!v377_9.empty()) {
          const Space v379_10 = routine_43(c, v370_27_head, v370_27_tail);
          v377_11 = compose(v377_9,v379_10);
        }
        const Space v377_12 = unite(v377_7,v377_11);
        v370_27_result = unite(v370_27_result,v377_12);
      }
      const Space v370_27 = std::move(v370_27_result);
      v365_28 = compose(v365_10,v370_27);
    }
    const Space v365_29 = unite(v365_8,v365_28);
    v364_29_result = unite(v364_29_result,v365_29);
  }
  const Space v364_29 = std::move(v364_29_result);
  return v364_29;
}

static Space routine_36(Context& c, const Space& s0) {
  const Space v380_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v380_2 = first_matching(s0,constant_0,false);
  const Space v380_3 = unite(v380_1,v380_2);
  Space v380_6;
  if (!v380_3.empty()) {
    const Space v381_4 = routine_68(c, s0);
    const Space v381_5 = routine_68(c, v381_4);
    v380_6 = compose(v380_3,v381_5);
  }
  Space v380_9;
  if (!v380_3.empty()) {
    const Space v382_7 = routine_82(c, s0);
    const Space v382_8 = subtract(s0,v382_7);
    v380_9 = compose(v380_3,v382_8);
  }
  const Space v380_10 = (has_head(v380_9) ? constant_7 : Space{});
  const Space v380_11 = first_matching(v380_9,constant_0,false);
  const Space v380_12 = unite(v380_10,v380_11);
  Space v380_15;
  if (!v380_12.empty()) {
    const Space v383_13 = routine_68(c, v380_9);
    const Space v383_14 = routine_68(c, v383_13);
    v380_15 = compose(v380_12,v383_14);
  }
  const Space v380_16 = subtract(s0,v380_15);
  const Space v380_17 = intersect(v380_6,v380_16);
  return v380_17;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v384_11_result;
  for (int v384_11_label = 1; v384_11_label <= 2; ++v384_11_label) {
    const Space v384_11_tail = child(s0,v384_11_label);
    if (v384_11_tail.empty()) continue;
    const Path v384_11_head{v384_11_label};
    const Space v385_2 = singleton(v384_11_head);
    const Space v385_3 = intersect(constant_5,v385_2);
    const Space v385_4 = (has_head(v385_3) ? constant_7 : Space{});
    const Space v385_5 = subtract(constant_0,v385_4);
    Space v385_8;
    if (!v385_5.empty()) {
      const Path v386_6 = concat_path(p0,v384_11_head);
      Space v386_7_result;
      for (int v386_7_label = 1; v386_7_label <= 2; ++v386_7_label) {
        const Space v386_7_tail = child(v384_11_tail,v386_7_label);
        if (v386_7_tail.empty()) continue;
        const Path v386_7_head{v386_7_label};
        const Space v387_2 = singleton(v386_7_head);
        const Space v387_3 = intersect(constant_5,v387_2);
        const Space v387_4 = (has_head(v387_3) ? constant_7 : Space{});
        const Space v387_5 = subtract(constant_0,v387_4);
        Space v387_8;
        if (!v387_5.empty()) {
          const Path v388_6 = concat_path(v386_6,v386_7_head);
          const Space v388_7 = routine_83(c, v388_6, v386_7_tail);
          v387_8 = compose(v387_5,v388_7);
        }
        const Space v387_9 = intersect(constant_5,v387_2);
        const Space v387_10 = (has_head(v387_9) ? constant_7 : Space{});
        Space v387_12;
        if (!v387_10.empty()) {
          const Path v389_6 = concat_path(v386_6,v386_7_head);
          const Space v389_11 = routine_84(c, v389_6, v386_7_tail);
          v387_12 = compose(v387_10,v389_11);
        }
        const Space v387_13 = unite(v387_8,v387_12);
        v386_7_result = unite(v386_7_result,v387_13);
      }
      const Space v386_7 = std::move(v386_7_result);
      v385_8 = compose(v385_5,v386_7);
    }
    const Space v385_9 = intersect(constant_5,v385_2);
    const Space v385_10 = (has_head(v385_9) ? constant_7 : Space{});
    Space v385_12;
    if (!v385_10.empty()) {
      const Path v390_6 = concat_path(p0,v384_11_head);
      Space v390_11_result;
      for (int v390_11_label = 1; v390_11_label <= 2; ++v390_11_label) {
        const Space v390_11_tail = child(v384_11_tail,v390_11_label);
        if (v390_11_tail.empty()) continue;
        const Path v390_11_head{v390_11_label};
        const Space v391_2 = singleton(v390_11_head);
        const Space v391_3 = intersect(constant_5,v391_2);
        const Space v391_4 = (has_head(v391_3) ? constant_7 : Space{});
        const Space v391_5 = subtract(constant_0,v391_4);
        Space v391_8;
        if (!v391_5.empty()) {
          const Path v392_6 = concat_path(v390_6,v390_11_head);
          const Space v392_7 = routine_83(c, v392_6, v390_11_tail);
          v391_8 = compose(v391_5,v392_7);
        }
        const Space v391_9 = intersect(constant_5,v391_2);
        const Space v391_10 = (has_head(v391_9) ? constant_7 : Space{});
        Space v391_12;
        if (!v391_10.empty()) {
          const Path v393_6 = concat_path(v390_6,v390_11_head);
          const Space v393_11 = routine_72(c, v393_6, v390_11_tail);
          v391_12 = compose(v391_10,v393_11);
        }
        const Space v391_13 = unite(v391_8,v391_12);
        v390_11_result = unite(v390_11_result,v391_13);
      }
      const Space v390_11 = std::move(v390_11_result);
      v385_12 = compose(v385_10,v390_11);
    }
    const Space v385_13 = unite(v385_8,v385_12);
    v384_11_result = unite(v384_11_result,v385_13);
  }
  const Space v384_11 = std::move(v384_11_result);
  return v384_11;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  Space v394_9_result;
  for (int v394_9_label = 1; v394_9_label <= 2; ++v394_9_label) {
    const Space v394_9_tail = child(s0,v394_9_label);
    if (v394_9_tail.empty()) continue;
    const Path v394_9_head{v394_9_label};
    const Space v395_2 = singleton(v394_9_head);
    const Space v395_3 = intersect(constant_5,v395_2);
    const Space v395_4 = (has_head(v395_3) ? constant_7 : Space{});
    const Space v395_5 = subtract(constant_0,v395_4);
    Space v395_8;
    if (!v395_5.empty()) {
      const Path v396_6 = concat_path(p0,v394_9_head);
      Space v396_7_result;
      for (int v396_7_label = 1; v396_7_label <= 2; ++v396_7_label) {
        const Space v396_7_tail = child(v394_9_tail,v396_7_label);
        if (v396_7_tail.empty()) continue;
        const Path v396_7_head{v396_7_label};
        const Space v397_2 = singleton(v396_7_head);
        const Space v397_3 = intersect(constant_5,v397_2);
        const Space v397_4 = (has_head(v397_3) ? constant_7 : Space{});
        const Space v397_5 = subtract(constant_0,v397_4);
        Space v397_8;
        if (!v397_5.empty()) {
          const Path v398_6 = concat_path(v396_6,v396_7_head);
          const Space v398_7 = routine_83(c, v398_6, v396_7_tail);
          v397_8 = compose(v397_5,v398_7);
        }
        const Space v397_9 = intersect(constant_5,v397_2);
        const Space v397_10 = (has_head(v397_9) ? constant_7 : Space{});
        Space v397_12;
        if (!v397_10.empty()) {
          const Path v399_6 = concat_path(v396_6,v396_7_head);
          const Space v399_11 = routine_84(c, v399_6, v396_7_tail);
          v397_12 = compose(v397_10,v399_11);
        }
        const Space v397_13 = unite(v397_8,v397_12);
        v396_7_result = unite(v396_7_result,v397_13);
      }
      const Space v396_7 = std::move(v396_7_result);
      v395_8 = compose(v395_5,v396_7);
    }
    const Space v395_9 = intersect(constant_5,v395_2);
    const Space v395_10 = (has_head(v395_9) ? constant_7 : Space{});
    const Space v395_11 = compose(v395_10,constant_10);
    const Space v395_12 = unite(v395_8,v395_11);
    v394_9_result = unite(v394_9_result,v395_12);
  }
  const Space v394_9 = std::move(v394_9_result);
  return v394_9;
}

static Space routine_39(Context& c, const Space& s0) {
  const Space v400_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v400_2 = first_matching(s0,constant_0,false);
  const Space v400_3 = unite(v400_1,v400_2);
  Space v400_6;
  if (!v400_3.empty()) {
    const Space v401_4 = routine_82(c, s0);
    const Space v401_5 = subtract(s0,v401_4);
    v400_6 = compose(v400_3,v401_5);
  }
  const Space v400_7 = (has_head(v400_6) ? constant_7 : Space{});
  const Space v400_8 = first_matching(v400_6,constant_0,false);
  const Space v400_9 = unite(v400_7,v400_8);
  Space v400_12;
  if (!v400_9.empty()) {
    const Space v402_10 = routine_68(c, v400_6);
    const Space v402_11 = routine_68(c, v402_10);
    v400_12 = compose(v400_9,v402_11);
  }
  Space v400_15;
  if (!v400_3.empty()) {
    const Space v403_13 = routine_69(c, s0);
    const Space v403_14 = routine_69(c, v403_13);
    v400_15 = compose(v400_3,v403_14);
  }
  const Space v400_16 = subtract(s0,v400_15);
  const Space v400_17 = intersect(v400_12,v400_16);
  return v400_17;
}

static Space routine_40(Context& c, const Path& p0, const Space& s0) {
  Space v404_11_result;
  for (int v404_11_label = 1; v404_11_label <= 2; ++v404_11_label) {
    const Space v404_11_tail = child(s0,v404_11_label);
    if (v404_11_tail.empty()) continue;
    const Path v404_11_head{v404_11_label};
    const Space v405_2 = singleton(v404_11_head);
    const Space v405_3 = intersect(constant_5,v405_2);
    const Space v405_4 = (has_head(v405_3) ? constant_7 : Space{});
    const Space v405_5 = subtract(constant_0,v405_4);
    Space v405_8;
    if (!v405_5.empty()) {
      const Path v406_6 = concat_path(p0,v404_11_head);
      Space v406_7_result;
      for (int v406_7_label = 1; v406_7_label <= 2; ++v406_7_label) {
        const Space v406_7_tail = child(v404_11_tail,v406_7_label);
        if (v406_7_tail.empty()) continue;
        const Path v406_7_head{v406_7_label};
        const Space v407_2 = singleton(v406_7_head);
        const Space v407_3 = intersect(constant_5,v407_2);
        const Space v407_4 = (has_head(v407_3) ? constant_7 : Space{});
        const Space v407_5 = subtract(constant_0,v407_4);
        Space v407_8;
        if (!v407_5.empty()) {
          const Path v408_6 = concat_path(v406_6,v406_7_head);
          const Space v408_7 = routine_85(c, v408_6, v406_7_tail);
          v407_8 = compose(v407_5,v408_7);
        }
        const Space v407_9 = intersect(constant_5,v407_2);
        const Space v407_10 = (has_head(v407_9) ? constant_7 : Space{});
        Space v407_12;
        if (!v407_10.empty()) {
          const Path v409_6 = concat_path(v406_6,v406_7_head);
          const Space v409_11 = routine_86(c, v409_6, v406_7_tail);
          v407_12 = compose(v407_10,v409_11);
        }
        const Space v407_13 = unite(v407_8,v407_12);
        v406_7_result = unite(v406_7_result,v407_13);
      }
      const Space v406_7 = std::move(v406_7_result);
      v405_8 = compose(v405_5,v406_7);
    }
    const Space v405_9 = intersect(constant_5,v405_2);
    const Space v405_10 = (has_head(v405_9) ? constant_7 : Space{});
    Space v405_12;
    if (!v405_10.empty()) {
      const Path v410_6 = concat_path(p0,v404_11_head);
      Space v410_11_result;
      for (int v410_11_label = 1; v410_11_label <= 2; ++v410_11_label) {
        const Space v410_11_tail = child(v404_11_tail,v410_11_label);
        if (v410_11_tail.empty()) continue;
        const Path v410_11_head{v410_11_label};
        const Space v411_2 = singleton(v410_11_head);
        const Space v411_3 = intersect(constant_5,v411_2);
        const Space v411_4 = (has_head(v411_3) ? constant_7 : Space{});
        const Space v411_5 = subtract(constant_0,v411_4);
        Space v411_8;
        if (!v411_5.empty()) {
          const Path v412_6 = concat_path(v410_6,v410_11_head);
          const Space v412_7 = routine_85(c, v412_6, v410_11_tail);
          v411_8 = compose(v411_5,v412_7);
        }
        const Space v411_9 = intersect(constant_5,v411_2);
        const Space v411_10 = (has_head(v411_9) ? constant_7 : Space{});
        Space v411_12;
        if (!v411_10.empty()) {
          const Path v413_6 = concat_path(v410_6,v410_11_head);
          const Space v413_11 = routine_76(c, v413_6, v410_11_tail);
          v411_12 = compose(v411_10,v413_11);
        }
        const Space v411_13 = unite(v411_8,v411_12);
        v410_11_result = unite(v410_11_result,v411_13);
      }
      const Space v410_11 = std::move(v410_11_result);
      v405_12 = compose(v405_10,v410_11);
    }
    const Space v405_13 = unite(v405_8,v405_12);
    v404_11_result = unite(v404_11_result,v405_13);
  }
  const Space v404_11 = std::move(v404_11_result);
  return v404_11;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0) {
  Space v414_9_result;
  for (int v414_9_label = 1; v414_9_label <= 2; ++v414_9_label) {
    const Space v414_9_tail = child(s0,v414_9_label);
    if (v414_9_tail.empty()) continue;
    const Path v414_9_head{v414_9_label};
    const Space v415_2 = singleton(v414_9_head);
    const Space v415_3 = intersect(constant_5,v415_2);
    const Space v415_4 = (has_head(v415_3) ? constant_7 : Space{});
    const Space v415_5 = subtract(constant_0,v415_4);
    Space v415_8;
    if (!v415_5.empty()) {
      const Path v416_6 = concat_path(p0,v414_9_head);
      Space v416_7_result;
      for (int v416_7_label = 1; v416_7_label <= 2; ++v416_7_label) {
        const Space v416_7_tail = child(v414_9_tail,v416_7_label);
        if (v416_7_tail.empty()) continue;
        const Path v416_7_head{v416_7_label};
        const Space v417_2 = singleton(v416_7_head);
        const Space v417_3 = intersect(constant_5,v417_2);
        const Space v417_4 = (has_head(v417_3) ? constant_7 : Space{});
        const Space v417_5 = subtract(constant_0,v417_4);
        Space v417_8;
        if (!v417_5.empty()) {
          const Path v418_6 = concat_path(v416_6,v416_7_head);
          const Space v418_7 = routine_85(c, v418_6, v416_7_tail);
          v417_8 = compose(v417_5,v418_7);
        }
        const Space v417_9 = intersect(constant_5,v417_2);
        const Space v417_10 = (has_head(v417_9) ? constant_7 : Space{});
        Space v417_12;
        if (!v417_10.empty()) {
          const Path v419_6 = concat_path(v416_6,v416_7_head);
          const Space v419_11 = routine_86(c, v419_6, v416_7_tail);
          v417_12 = compose(v417_10,v419_11);
        }
        const Space v417_13 = unite(v417_8,v417_12);
        v416_7_result = unite(v416_7_result,v417_13);
      }
      const Space v416_7 = std::move(v416_7_result);
      v415_8 = compose(v415_5,v416_7);
    }
    const Space v415_9 = intersect(constant_5,v415_2);
    const Space v415_10 = (has_head(v415_9) ? constant_7 : Space{});
    const Space v415_11 = compose(v415_10,constant_10);
    const Space v415_12 = unite(v415_8,v415_11);
    v414_9_result = unite(v414_9_result,v415_12);
  }
  const Space v414_9 = std::move(v414_9_result);
  return v414_9;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0) {
  Space v420_11_result;
  for (int v420_11_label = 1; v420_11_label <= 2; ++v420_11_label) {
    const Space v420_11_tail = child(s0,v420_11_label);
    if (v420_11_tail.empty()) continue;
    const Path v420_11_head{v420_11_label};
    const Space v421_2 = singleton(v420_11_head);
    const Space v421_3 = intersect(constant_5,v421_2);
    const Space v421_4 = (has_head(v421_3) ? constant_7 : Space{});
    const Space v421_5 = subtract(constant_0,v421_4);
    Space v421_8;
    if (!v421_5.empty()) {
      const Path v422_6 = concat_path(p0,v420_11_head);
      Space v422_7_result;
      for (int v422_7_label = 1; v422_7_label <= 2; ++v422_7_label) {
        const Space v422_7_tail = child(v420_11_tail,v422_7_label);
        if (v422_7_tail.empty()) continue;
        const Path v422_7_head{v422_7_label};
        const Space v423_2 = singleton(v422_7_head);
        const Space v423_3 = intersect(constant_5,v423_2);
        const Space v423_4 = (has_head(v423_3) ? constant_7 : Space{});
        const Space v423_5 = subtract(constant_0,v423_4);
        Space v423_8;
        if (!v423_5.empty()) {
          const Path v424_6 = concat_path(v422_6,v422_7_head);
          const Space v424_7 = routine_87(c, v424_6, v422_7_tail);
          v423_8 = compose(v423_5,v424_7);
        }
        const Space v423_9 = intersect(constant_5,v423_2);
        const Space v423_10 = (has_head(v423_9) ? constant_7 : Space{});
        Space v423_12;
        if (!v423_10.empty()) {
          const Path v425_6 = concat_path(v422_6,v422_7_head);
          const Space v425_11 = routine_88(c, v425_6, v422_7_tail);
          v423_12 = compose(v423_10,v425_11);
        }
        const Space v423_13 = unite(v423_8,v423_12);
        v422_7_result = unite(v422_7_result,v423_13);
      }
      const Space v422_7 = std::move(v422_7_result);
      v421_8 = compose(v421_5,v422_7);
    }
    const Space v421_9 = intersect(constant_5,v421_2);
    const Space v421_10 = (has_head(v421_9) ? constant_7 : Space{});
    Space v421_12;
    if (!v421_10.empty()) {
      const Path v426_6 = concat_path(p0,v420_11_head);
      Space v426_11_result;
      for (int v426_11_label = 1; v426_11_label <= 2; ++v426_11_label) {
        const Space v426_11_tail = child(v420_11_tail,v426_11_label);
        if (v426_11_tail.empty()) continue;
        const Path v426_11_head{v426_11_label};
        const Space v427_2 = singleton(v426_11_head);
        const Space v427_3 = intersect(constant_5,v427_2);
        const Space v427_4 = (has_head(v427_3) ? constant_7 : Space{});
        const Space v427_5 = subtract(constant_0,v427_4);
        Space v427_8;
        if (!v427_5.empty()) {
          const Path v428_6 = concat_path(v426_6,v426_11_head);
          const Space v428_7 = routine_87(c, v428_6, v426_11_tail);
          v427_8 = compose(v427_5,v428_7);
        }
        const Space v427_9 = intersect(constant_5,v427_2);
        const Space v427_10 = (has_head(v427_9) ? constant_7 : Space{});
        Space v427_12;
        if (!v427_10.empty()) {
          const Path v429_6 = concat_path(v426_6,v426_11_head);
          const Space v429_11 = routine_79(c, v429_6, v426_11_tail);
          v427_12 = compose(v427_10,v429_11);
        }
        const Space v427_13 = unite(v427_8,v427_12);
        v426_11_result = unite(v426_11_result,v427_13);
      }
      const Space v426_11 = std::move(v426_11_result);
      v421_12 = compose(v421_10,v426_11);
    }
    const Space v421_13 = unite(v421_8,v421_12);
    v420_11_result = unite(v420_11_result,v421_13);
  }
  const Space v420_11 = std::move(v420_11_result);
  return v420_11;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0) {
  Space v430_8_result;
  for (int v430_8_label = 1; v430_8_label <= 2; ++v430_8_label) {
    const Space v430_8_tail = child(s0,v430_8_label);
    if (v430_8_tail.empty()) continue;
    const Path v430_8_head{v430_8_label};
    const Space v431_2 = singleton(v430_8_head);
    const Space v431_3 = intersect(constant_5,v431_2);
    const Space v431_4 = (has_head(v431_3) ? constant_7 : Space{});
    const Space v431_5 = subtract(constant_0,v431_4);
    Space v431_8;
    if (!v431_5.empty()) {
      const Path v432_6 = concat_path(p0,v430_8_head);
      Space v432_7_result;
      for (int v432_7_label = 1; v432_7_label <= 2; ++v432_7_label) {
        const Space v432_7_tail = child(v430_8_tail,v432_7_label);
        if (v432_7_tail.empty()) continue;
        const Path v432_7_head{v432_7_label};
        const Space v433_2 = singleton(v432_7_head);
        const Space v433_3 = intersect(constant_5,v433_2);
        const Space v433_4 = (has_head(v433_3) ? constant_7 : Space{});
        const Space v433_5 = subtract(constant_0,v433_4);
        Space v433_8;
        if (!v433_5.empty()) {
          const Path v434_6 = concat_path(v432_6,v432_7_head);
          const Space v434_7 = routine_87(c, v434_6, v432_7_tail);
          v433_8 = compose(v433_5,v434_7);
        }
        const Space v433_9 = intersect(constant_5,v433_2);
        const Space v433_10 = (has_head(v433_9) ? constant_7 : Space{});
        Space v433_12;
        if (!v433_10.empty()) {
          const Path v435_6 = concat_path(v432_6,v432_7_head);
          const Space v435_11 = routine_88(c, v435_6, v432_7_tail);
          v433_12 = compose(v433_10,v435_11);
        }
        const Space v433_13 = unite(v433_8,v433_12);
        v432_7_result = unite(v432_7_result,v433_13);
      }
      const Space v432_7 = std::move(v432_7_result);
      v431_8 = compose(v431_5,v432_7);
    }
    const Space v431_9 = intersect(constant_5,v431_2);
    const Space v431_10 = (has_head(v431_9) ? constant_7 : Space{});
    const Space v431_11 = compose(v431_10,v430_8_tail);
    const Space v431_12 = unite(v431_8,v431_11);
    v430_8_result = unite(v430_8_result,v431_12);
  }
  const Space v430_8 = std::move(v430_8_result);
  return v430_8;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v436_12_result;
  for (int v436_12_label = 1; v436_12_label <= 2; ++v436_12_label) {
    const Space v436_12_tail = child(s0,v436_12_label);
    if (v436_12_tail.empty()) continue;
    const Path v436_12_head{v436_12_label};
    const Space v437_2 = singleton(v436_12_head);
    const Space v437_3 = intersect(constant_5,v437_2);
    const Space v437_4 = (has_head(v437_3) ? constant_7 : Space{});
    const Space v437_5 = subtract(constant_0,v437_4);
    Space v437_8;
    if (!v437_5.empty()) {
      const Path v438_6 = concat_path(p0,v436_12_head);
      Space v438_7_result;
      for (int v438_7_label = 1; v438_7_label <= 2; ++v438_7_label) {
        const Space v438_7_tail = child(v436_12_tail,v438_7_label);
        if (v438_7_tail.empty()) continue;
        const Path v438_7_head{v438_7_label};
        const Space v439_2 = singleton(v438_7_head);
        const Space v439_3 = intersect(constant_5,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_7 : Space{});
        const Space v439_5 = subtract(constant_0,v439_4);
        Space v439_8;
        if (!v439_5.empty()) {
          const Path v440_6 = concat_path(v438_6,v438_7_head);
          const Space v440_7 = routine_89(c, v440_6, v438_7_tail, s1);
          v439_8 = compose(v439_5,v440_7);
        }
        const Space v439_9 = intersect(constant_5,v439_2);
        const Space v439_10 = (has_head(v439_9) ? constant_7 : Space{});
        Space v439_12;
        if (!v439_10.empty()) {
          const Path v441_6 = concat_path(v438_6,v438_7_head);
          const Space v441_11 = routine_90(c, v441_6, v438_7_tail, s1);
          v439_12 = compose(v439_10,v441_11);
        }
        const Space v439_13 = unite(v439_8,v439_12);
        v438_7_result = unite(v438_7_result,v439_13);
      }
      const Space v438_7 = std::move(v438_7_result);
      v437_8 = compose(v437_5,v438_7);
    }
    const Space v437_9 = intersect(constant_5,v437_2);
    const Space v437_10 = (has_head(v437_9) ? constant_7 : Space{});
    Space v437_12;
    if (!v437_10.empty()) {
      const Path v442_6 = concat_path(p0,v436_12_head);
      Space v442_11_result;
      for (int v442_11_label = 1; v442_11_label <= 2; ++v442_11_label) {
        const Space v442_11_tail = child(v436_12_tail,v442_11_label);
        if (v442_11_tail.empty()) continue;
        const Path v442_11_head{v442_11_label};
        const Space v443_2 = singleton(v442_11_head);
        const Space v443_3 = intersect(constant_5,v443_2);
        const Space v443_4 = (has_head(v443_3) ? constant_7 : Space{});
        const Space v443_5 = subtract(constant_0,v443_4);
        Space v443_8;
        if (!v443_5.empty()) {
          const Path v444_6 = concat_path(v442_6,v442_11_head);
          const Space v444_7 = routine_89(c, v444_6, v442_11_tail, s1);
          v443_8 = compose(v443_5,v444_7);
        }
        const Space v443_9 = intersect(constant_5,v443_2);
        const Space v443_10 = (has_head(v443_9) ? constant_7 : Space{});
        Space v443_12;
        if (!v443_10.empty()) {
          const Path v445_6 = concat_path(v442_6,v442_11_head);
          const Space v445_11 = routine_19(c, v445_6, v442_11_tail, s1);
          v443_12 = compose(v443_10,v445_11);
        }
        const Space v443_13 = unite(v443_8,v443_12);
        v442_11_result = unite(v442_11_result,v443_13);
      }
      const Space v442_11 = std::move(v442_11_result);
      v437_12 = compose(v437_10,v442_11);
    }
    const Space v437_13 = unite(v437_8,v437_12);
    v436_12_result = unite(v436_12_result,v437_13);
  }
  const Space v436_12 = std::move(v436_12_result);
  return v436_12;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v446_12_result;
  for (int v446_12_label = 1; v446_12_label <= 2; ++v446_12_label) {
    const Space v446_12_tail = child(s0,v446_12_label);
    if (v446_12_tail.empty()) continue;
    const Path v446_12_head{v446_12_label};
    const Space v447_2 = singleton(v446_12_head);
    const Space v447_3 = intersect(constant_5,v447_2);
    const Space v447_4 = (has_head(v447_3) ? constant_7 : Space{});
    const Space v447_5 = subtract(constant_0,v447_4);
    Space v447_8;
    if (!v447_5.empty()) {
      const Path v448_6 = concat_path(p0,v446_12_head);
      Space v448_7_result;
      for (int v448_7_label = 1; v448_7_label <= 2; ++v448_7_label) {
        const Space v448_7_tail = child(v446_12_tail,v448_7_label);
        if (v448_7_tail.empty()) continue;
        const Path v448_7_head{v448_7_label};
        const Space v449_2 = singleton(v448_7_head);
        const Space v449_3 = intersect(constant_5,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_7 : Space{});
        const Space v449_5 = subtract(constant_0,v449_4);
        Space v449_8;
        if (!v449_5.empty()) {
          const Path v450_6 = concat_path(v448_6,v448_7_head);
          const Space v450_7 = routine_89(c, v450_6, v448_7_tail, s1);
          v449_8 = compose(v449_5,v450_7);
        }
        const Space v449_9 = intersect(constant_5,v449_2);
        const Space v449_10 = (has_head(v449_9) ? constant_7 : Space{});
        Space v449_12;
        if (!v449_10.empty()) {
          const Path v451_6 = concat_path(v448_6,v448_7_head);
          const Space v451_11 = routine_90(c, v451_6, v448_7_tail, s1);
          v449_12 = compose(v449_10,v451_11);
        }
        const Space v449_13 = unite(v449_8,v449_12);
        v448_7_result = unite(v448_7_result,v449_13);
      }
      const Space v448_7 = std::move(v448_7_result);
      v447_8 = compose(v447_5,v448_7);
    }
    const Space v447_9 = intersect(constant_5,v447_2);
    const Space v447_10 = (has_head(v447_9) ? constant_7 : Space{});
    Space v447_12;
    if (!v447_10.empty()) {
      const Path v452_6 = concat_path(p0,v446_12_head);
      Space v452_11_result;
      for (int v452_11_label = 1; v452_11_label <= 2; ++v452_11_label) {
        const Space v452_11_tail = child(v446_12_tail,v452_11_label);
        if (v452_11_tail.empty()) continue;
        const Path v452_11_head{v452_11_label};
        const Space v453_2 = singleton(v452_11_head);
        const Space v453_3 = intersect(constant_5,v453_2);
        const Space v453_4 = (has_head(v453_3) ? constant_7 : Space{});
        const Space v453_5 = subtract(constant_0,v453_4);
        Space v453_7;
        if (!v453_5.empty()) {
          const Space v454_6 = routine_20(c, v452_11_head, v452_6, v452_11_tail, s1);
          v453_7 = compose(v453_5,v454_6);
        }
        const Space v453_8 = intersect(constant_5,v453_2);
        const Space v453_9 = (has_head(v453_8) ? constant_7 : Space{});
        Space v453_11;
        if (!v453_9.empty()) {
          const Space v455_10 = routine_21(c, v452_11_head, v452_6, v452_11_tail, s1);
          v453_11 = compose(v453_9,v455_10);
        }
        const Space v453_12 = unite(v453_7,v453_11);
        v452_11_result = unite(v452_11_result,v453_12);
      }
      const Space v452_11 = std::move(v452_11_result);
      v447_12 = compose(v447_10,v452_11);
    }
    const Space v447_13 = unite(v447_8,v447_12);
    v446_12_result = unite(v446_12_result,v447_13);
  }
  const Space v446_12 = std::move(v446_12_result);
  return v446_12;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v456_13_result;
  for (int v456_13_label = 1; v456_13_label <= 2; ++v456_13_label) {
    const Space v456_13_tail = child(s0,v456_13_label);
    if (v456_13_tail.empty()) continue;
    const Path v456_13_head{v456_13_label};
    const Space v457_2 = singleton(v456_13_head);
    const Space v457_3 = intersect(constant_5,v457_2);
    const Space v457_4 = (has_head(v457_3) ? constant_7 : Space{});
    const Space v457_5 = subtract(constant_0,v457_4);
    Space v457_8;
    if (!v457_5.empty()) {
      const Path v458_6 = concat_path(p0,v456_13_head);
      Space v458_7_result;
      for (int v458_7_label = 1; v458_7_label <= 2; ++v458_7_label) {
        const Space v458_7_tail = child(v456_13_tail,v458_7_label);
        if (v458_7_tail.empty()) continue;
        const Path v458_7_head{v458_7_label};
        const Space v459_2 = singleton(v458_7_head);
        const Space v459_3 = intersect(constant_5,v459_2);
        const Space v459_4 = (has_head(v459_3) ? constant_7 : Space{});
        const Space v459_5 = subtract(constant_0,v459_4);
        Space v459_8;
        if (!v459_5.empty()) {
          const Path v460_6 = concat_path(v458_6,v458_7_head);
          const Space v460_7 = routine_91(c, v460_6, p1, v458_7_tail, s1);
          v459_8 = compose(v459_5,v460_7);
        }
        const Space v459_9 = intersect(constant_5,v459_2);
        const Space v459_10 = (has_head(v459_9) ? constant_7 : Space{});
        Space v459_12;
        if (!v459_10.empty()) {
          const Path v461_6 = concat_path(v458_6,v458_7_head);
          const Space v461_11 = routine_92(c, v461_6, p1, v458_7_tail, s1);
          v459_12 = compose(v459_10,v461_11);
        }
        const Space v459_13 = unite(v459_8,v459_12);
        v458_7_result = unite(v458_7_result,v459_13);
      }
      const Space v458_7 = std::move(v458_7_result);
      v457_8 = compose(v457_5,v458_7);
    }
    const Space v457_9 = intersect(constant_5,v457_2);
    const Space v457_10 = (has_head(v457_9) ? constant_7 : Space{});
    Space v457_12;
    if (!v457_10.empty()) {
      const Path v462_6 = concat_path(p0,v456_13_head);
      Space v462_11_result;
      for (int v462_11_label = 1; v462_11_label <= 2; ++v462_11_label) {
        const Space v462_11_tail = child(v456_13_tail,v462_11_label);
        if (v462_11_tail.empty()) continue;
        const Path v462_11_head{v462_11_label};
        const Space v463_2 = singleton(v462_11_head);
        const Space v463_3 = intersect(constant_5,v463_2);
        const Space v463_4 = (has_head(v463_3) ? constant_7 : Space{});
        const Space v463_5 = subtract(constant_0,v463_4);
        Space v463_8;
        if (!v463_5.empty()) {
          const Path v464_6 = concat_path(v462_6,v462_11_head);
          const Space v464_7 = routine_91(c, v464_6, p1, v462_11_tail, s1);
          v463_8 = compose(v463_5,v464_7);
        }
        const Space v463_9 = intersect(constant_5,v463_2);
        const Space v463_10 = (has_head(v463_9) ? constant_7 : Space{});
        Space v463_12;
        if (!v463_10.empty()) {
          const Path v465_6 = concat_path(v462_6,v462_11_head);
          const Space v465_11 = routine_48(c, v465_6, p1, v462_11_tail, s1);
          v463_12 = compose(v463_10,v465_11);
        }
        const Space v463_13 = unite(v463_8,v463_12);
        v462_11_result = unite(v462_11_result,v463_13);
      }
      const Space v462_11 = std::move(v462_11_result);
      v457_12 = compose(v457_10,v462_11);
    }
    const Space v457_13 = unite(v457_8,v457_12);
    v456_13_result = unite(v456_13_result,v457_13);
  }
  const Space v456_13 = std::move(v456_13_result);
  return v456_13;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v466_8 = unwrap(constant_9,p1);
  const Space v466_10 = unwrap(constant_9,p0);
  const Space v466_12 = unwrap(s1,constant_8);
  const Space v466_14 = unwrap(constant_9,p1);
  const Space v466_16 = unwrap(constant_9,p0);
  Space v466_29_result;
  for (int v466_29_label = 1; v466_29_label <= 2; ++v466_29_label) {
    const Space v466_29_tail = child(s0,v466_29_label);
    if (v466_29_tail.empty()) continue;
    const Path v466_29_head{v466_29_label};
    const Space v467_2 = singleton(v466_29_head);
    const Space v467_3 = intersect(constant_5,v467_2);
    const Space v467_4 = (has_head(v467_3) ? constant_7 : Space{});
    const Space v467_5 = subtract(constant_0,v467_4);
    Space v467_8;
    if (!v467_5.empty()) {
      const Path v468_6 = concat_path(p0,v466_29_head);
      Space v468_7_result;
      for (int v468_7_label = 1; v468_7_label <= 2; ++v468_7_label) {
        const Space v468_7_tail = child(v466_29_tail,v468_7_label);
        if (v468_7_tail.empty()) continue;
        const Path v468_7_head{v468_7_label};
        const Space v469_2 = singleton(v468_7_head);
        const Space v469_3 = intersect(constant_5,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_7 : Space{});
        const Space v469_5 = subtract(constant_0,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_7_head);
          const Space v470_7 = routine_91(c, v470_6, p1, v468_7_tail, s1);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_5,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_7 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_7_head);
          const Space v471_11 = routine_92(c, v471_6, p1, v468_7_tail, s1);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_7_result = unite(v468_7_result,v469_13);
      }
      const Space v468_7 = std::move(v468_7_result);
      v467_8 = compose(v467_5,v468_7);
    }
    const Space v467_9 = intersect(constant_5,v467_2);
    const Space v467_10 = (has_head(v467_9) ? constant_7 : Space{});
    Space v467_28;
    if (!v467_10.empty()) {
      const Path v472_6 = concat_path(p0,v466_29_head);
      const Space v472_11 = unwrap(v466_10,v466_29_head);
      const Space v472_12 = compose(v466_8,v472_11);
      const Path v472_13 = concat_path(p1,v472_6);
      const Space v472_14 = singleton(v472_13);
      const Space v472_15 = subtract(v472_12,v472_14);
      const Space v472_16 = intersect(v472_15,v466_12);
      const Space v472_17 = routine_51(c, v472_16);
      Space v472_18_result;
      for (int v472_18_label = 1; v472_18_label <= 2; ++v472_18_label) {
        const Space v472_18_tail = child(v472_17,v472_18_label);
        if (v472_18_tail.empty()) continue;
        const Path v472_18_head{v472_18_label};
        const Space v473_2 = singleton(v472_18_head);
        const Space v473_3 = intersect(constant_5,v473_2);
        const Space v473_4 = (has_head(v473_3) ? constant_7 : Space{});
        const Space v473_5 = subtract(constant_0,v473_4);
        Space v473_7;
        if (!v473_5.empty()) {
          const Space v474_6 = routine_52(c, v472_18_head, v472_18_tail);
          v473_7 = compose(v473_5,v474_6);
        }
        const Space v473_8 = intersect(constant_5,v473_2);
        const Space v473_9 = (has_head(v473_8) ? constant_7 : Space{});
        Space v473_11;
        if (!v473_9.empty()) {
          const Space v475_10 = routine_53(c, v472_18_head, v472_18_tail);
          v473_11 = compose(v473_9,v475_10);
        }
        const Space v473_12 = unite(v473_7,v473_11);
        v472_18_result = unite(v472_18_result,v473_12);
      }
      const Space v472_18 = std::move(v472_18_result);
      const Space v472_19 = unwrap(v466_16,v466_29_head);
      const Space v472_20 = compose(v466_14,v472_19);
      const Space v472_21 = subtract(v472_20,v472_14);
      const Space v472_22 = intersect(v472_21,v466_12);
      const Space v472_23 = routine_36(c, v472_22);
      Space v472_24_result;
      for (int v472_24_label = 1; v472_24_label <= 2; ++v472_24_label) {
        const Space v472_24_tail = child(v472_23,v472_24_label);
        if (v472_24_tail.empty()) continue;
        const Path v472_24_head{v472_24_label};
        const Space v476_2 = singleton(v472_24_head);
        const Space v476_3 = intersect(constant_5,v476_2);
        const Space v476_4 = (has_head(v476_3) ? constant_7 : Space{});
        const Space v476_5 = subtract(constant_0,v476_4);
        Space v476_7;
        if (!v476_5.empty()) {
          const Space v477_6 = routine_54(c, v472_24_head, v472_24_tail);
          v476_7 = compose(v476_5,v477_6);
        }
        const Space v476_8 = intersect(constant_5,v476_2);
        const Space v476_9 = (has_head(v476_8) ? constant_7 : Space{});
        Space v476_11;
        if (!v476_9.empty()) {
          const Space v478_10 = routine_55(c, v472_24_head, v472_24_tail);
          v476_11 = compose(v476_9,v478_10);
        }
        const Space v476_12 = unite(v476_7,v476_11);
        v472_24_result = unite(v472_24_result,v476_12);
      }
      const Space v472_24 = std::move(v472_24_result);
      const Space v472_25 = subtract(v472_18,v472_24);
      const Space v472_26 = compose(v472_25,v472_14);
      Space v472_27_result;
      for (int v472_27_label = 1; v472_27_label <= 2; ++v472_27_label) {
        const Space v472_27_tail = child(v472_26,v472_27_label);
        if (v472_27_tail.empty()) continue;
        const Path v472_27_head{v472_27_label};
        const Space v479_2 = singleton(v472_27_head);
        const Space v479_3 = intersect(constant_5,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_7 : Space{});
        const Space v479_5 = subtract(constant_0,v479_4);
        Space v479_7;
        if (!v479_5.empty()) {
          const Space v480_6 = routine_56(c, v472_27_head, v472_27_tail);
          v479_7 = compose(v479_5,v480_6);
        }
        const Space v479_8 = intersect(constant_5,v479_2);
        const Space v479_9 = (has_head(v479_8) ? constant_7 : Space{});
        Space v479_11;
        if (!v479_9.empty()) {
          const Space v481_10 = routine_57(c, v472_27_head, v472_27_tail);
          v479_11 = compose(v479_9,v481_10);
        }
        const Space v479_12 = unite(v479_7,v479_11);
        v472_27_result = unite(v472_27_result,v479_12);
      }
      const Space v472_27 = std::move(v472_27_result);
      v467_28 = compose(v467_10,v472_27);
    }
    const Space v467_29 = unite(v467_8,v467_28);
    v466_29_result = unite(v466_29_result,v467_29);
  }
  const Space v466_29 = std::move(v466_29_result);
  return v466_29;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v482_5 = unwrap(constant_9,p1);
  const Space v482_7 = unwrap(constant_9,p0);
  const Space v482_8 = compose(v482_5,v482_7);
  const Path v482_9 = concat_path(p1,p0);
  const Space v482_10 = singleton(v482_9);
  const Space v482_11 = subtract(v482_8,v482_10);
  const Space v482_13 = unwrap(s1,constant_8);
  const Space v482_14 = intersect(v482_11,v482_13);
  const Space v482_16 = unwrap(constant_9,p1);
  const Space v482_18 = unwrap(constant_9,p0);
  const Space v482_19 = compose(v482_16,v482_18);
  const Space v482_20 = subtract(v482_19,v482_10);
  const Space v482_21 = intersect(v482_20,v482_13);
  const Space v482_22 = routine_69(c, v482_21);
  const Space v482_23 = subtract(v482_14,v482_22);
  const Space v482_25 = unwrap(constant_9,p1);
  const Space v482_27 = unwrap(constant_9,p0);
  const Space v482_28 = compose(v482_25,v482_27);
  const Space v482_29 = subtract(v482_28,v482_10);
  const Space v482_30 = intersect(v482_29,v482_13);
  const Space v482_31 = routine_68(c, v482_30);
  const Space v482_32 = intersect(v482_23,v482_31);
  Space v482_42_result;
  for (int v482_42_label = 1; v482_42_label <= 2; ++v482_42_label) {
    const Space v482_42_tail = child(v482_32,v482_42_label);
    if (v482_42_tail.empty()) continue;
    const Path v482_42_head{v482_42_label};
    const Space v483_2 = singleton(v482_42_head);
    const Space v483_3 = intersect(constant_5,v483_2);
    const Space v483_4 = (has_head(v483_3) ? constant_7 : Space{});
    const Space v483_5 = subtract(constant_0,v483_4);
    Space v483_7;
    if (!v483_5.empty()) {
      Space v484_6_result;
      for (int v484_6_label = 1; v484_6_label <= 2; ++v484_6_label) {
        const Space v484_6_tail = child(v482_42_tail,v484_6_label);
        if (v484_6_tail.empty()) continue;
        const Path v484_6_head{v484_6_label};
        const Space v485_2 = singleton(v484_6_head);
        const Space v485_3 = intersect(constant_5,v485_2);
        const Space v485_4 = (has_head(v485_3) ? constant_7 : Space{});
        const Space v485_5 = subtract(constant_0,v485_4);
        Space v485_8;
        if (!v485_5.empty()) {
          const Path v486_6 = concat_path(v482_42_head,v484_6_head);
          const Space v486_7 = routine_93(c, v486_6, v484_6_tail);
          v485_8 = compose(v485_5,v486_7);
        }
        const Space v485_9 = intersect(constant_5,v485_2);
        const Space v485_10 = (has_head(v485_9) ? constant_7 : Space{});
        Space v485_12;
        if (!v485_10.empty()) {
          const Path v487_6 = concat_path(v482_42_head,v484_6_head);
          const Space v487_11 = routine_94(c, v487_6, v484_6_tail);
          v485_12 = compose(v485_10,v487_11);
        }
        const Space v485_13 = unite(v485_8,v485_12);
        v484_6_result = unite(v484_6_result,v485_13);
      }
      const Space v484_6 = std::move(v484_6_result);
      v483_7 = compose(v483_5,v484_6);
    }
    const Space v483_8 = intersect(constant_5,v483_2);
    const Space v483_9 = (has_head(v483_8) ? constant_7 : Space{});
    Space v483_11;
    if (!v483_9.empty()) {
      Space v488_10_result;
      for (int v488_10_label = 1; v488_10_label <= 2; ++v488_10_label) {
        const Space v488_10_tail = child(v482_42_tail,v488_10_label);
        if (v488_10_tail.empty()) continue;
        const Path v488_10_head{v488_10_label};
        const Space v489_2 = singleton(v488_10_head);
        const Space v489_3 = intersect(constant_5,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_7 : Space{});
        const Space v489_5 = subtract(constant_0,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v482_42_head,v488_10_head);
          const Space v490_7 = routine_93(c, v490_6, v488_10_tail);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_5,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_7 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v482_42_head,v488_10_head);
          const Space v491_11 = routine_95(c, v491_6, v488_10_tail);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_10_result = unite(v488_10_result,v489_13);
      }
      const Space v488_10 = std::move(v488_10_result);
      v483_11 = compose(v483_9,v488_10);
    }
    const Space v483_12 = unite(v483_7,v483_11);
    v482_42_result = unite(v482_42_result,v483_12);
  }
  const Space v482_42 = std::move(v482_42_result);
  const Space v482_44 = unwrap(constant_9,p1);
  const Space v482_46 = unwrap(constant_9,p0);
  const Space v482_47 = compose(v482_44,v482_46);
  const Space v482_48 = subtract(v482_47,v482_10);
  const Space v482_49 = intersect(v482_48,v482_13);
  const Space v482_51 = unwrap(constant_9,p1);
  const Space v482_53 = unwrap(constant_9,p0);
  const Space v482_54 = compose(v482_51,v482_53);
  const Space v482_55 = subtract(v482_54,v482_10);
  const Space v482_56 = intersect(v482_55,v482_13);
  const Space v482_57 = routine_68(c, v482_56);
  const Space v482_58 = routine_69(c, v482_57);
  const Space v482_59 = subtract(v482_49,v482_58);
  const Space v482_61 = unwrap(constant_9,p1);
  const Space v482_63 = unwrap(constant_9,p0);
  const Space v482_64 = compose(v482_61,v482_63);
  const Space v482_65 = subtract(v482_64,v482_10);
  const Space v482_66 = intersect(v482_65,v482_13);
  const Space v482_67 = routine_69(c, v482_66);
  const Space v482_68 = intersect(v482_59,v482_67);
  Space v482_78_result;
  for (int v482_78_label = 1; v482_78_label <= 2; ++v482_78_label) {
    const Space v482_78_tail = child(v482_68,v482_78_label);
    if (v482_78_tail.empty()) continue;
    const Path v482_78_head{v482_78_label};
    const Space v492_2 = singleton(v482_78_head);
    const Space v492_3 = intersect(constant_5,v492_2);
    const Space v492_4 = (has_head(v492_3) ? constant_7 : Space{});
    const Space v492_5 = subtract(constant_0,v492_4);
    Space v492_7;
    if (!v492_5.empty()) {
      Space v493_6_result;
      for (int v493_6_label = 1; v493_6_label <= 2; ++v493_6_label) {
        const Space v493_6_tail = child(v482_78_tail,v493_6_label);
        if (v493_6_tail.empty()) continue;
        const Path v493_6_head{v493_6_label};
        const Space v494_2 = singleton(v493_6_head);
        const Space v494_3 = intersect(constant_5,v494_2);
        const Space v494_4 = (has_head(v494_3) ? constant_7 : Space{});
        const Space v494_5 = subtract(constant_0,v494_4);
        Space v494_8;
        if (!v494_5.empty()) {
          const Path v495_6 = concat_path(v482_78_head,v493_6_head);
          const Space v495_7 = routine_96(c, v495_6, v493_6_tail);
          v494_8 = compose(v494_5,v495_7);
        }
        const Space v494_9 = intersect(constant_5,v494_2);
        const Space v494_10 = (has_head(v494_9) ? constant_7 : Space{});
        Space v494_12;
        if (!v494_10.empty()) {
          const Path v496_6 = concat_path(v482_78_head,v493_6_head);
          const Space v496_11 = routine_97(c, v496_6, v493_6_tail);
          v494_12 = compose(v494_10,v496_11);
        }
        const Space v494_13 = unite(v494_8,v494_12);
        v493_6_result = unite(v493_6_result,v494_13);
      }
      const Space v493_6 = std::move(v493_6_result);
      v492_7 = compose(v492_5,v493_6);
    }
    const Space v492_8 = intersect(constant_5,v492_2);
    const Space v492_9 = (has_head(v492_8) ? constant_7 : Space{});
    Space v492_11;
    if (!v492_9.empty()) {
      Space v497_10_result;
      for (int v497_10_label = 1; v497_10_label <= 2; ++v497_10_label) {
        const Space v497_10_tail = child(v482_78_tail,v497_10_label);
        if (v497_10_tail.empty()) continue;
        const Path v497_10_head{v497_10_label};
        const Space v498_2 = singleton(v497_10_head);
        const Space v498_3 = intersect(constant_5,v498_2);
        const Space v498_4 = (has_head(v498_3) ? constant_7 : Space{});
        const Space v498_5 = subtract(constant_0,v498_4);
        Space v498_8;
        if (!v498_5.empty()) {
          const Path v499_6 = concat_path(v482_78_head,v497_10_head);
          const Space v499_7 = routine_96(c, v499_6, v497_10_tail);
          v498_8 = compose(v498_5,v499_7);
        }
        const Space v498_9 = intersect(constant_5,v498_2);
        const Space v498_10 = (has_head(v498_9) ? constant_7 : Space{});
        Space v498_12;
        if (!v498_10.empty()) {
          const Path v500_6 = concat_path(v482_78_head,v497_10_head);
          const Space v500_11 = routine_98(c, v500_6, v497_10_tail);
          v498_12 = compose(v498_10,v500_11);
        }
        const Space v498_13 = unite(v498_8,v498_12);
        v497_10_result = unite(v497_10_result,v498_13);
      }
      const Space v497_10 = std::move(v497_10_result);
      v492_11 = compose(v492_9,v497_10);
    }
    const Space v492_12 = unite(v492_7,v492_11);
    v482_78_result = unite(v482_78_result,v492_12);
  }
  const Space v482_78 = std::move(v482_78_result);
  const Space v482_79 = subtract(v482_42,v482_78);
  const Space v482_80 = compose(v482_79,v482_10);
  Space v482_90_result;
  for (int v482_90_label = 1; v482_90_label <= 2; ++v482_90_label) {
    const Space v482_90_tail = child(v482_80,v482_90_label);
    if (v482_90_tail.empty()) continue;
    const Path v482_90_head{v482_90_label};
    const Space v501_2 = singleton(v482_90_head);
    const Space v501_3 = intersect(constant_5,v501_2);
    const Space v501_4 = (has_head(v501_3) ? constant_7 : Space{});
    const Space v501_5 = subtract(constant_0,v501_4);
    Space v501_7;
    if (!v501_5.empty()) {
      Space v502_6_result;
      for (int v502_6_label = 1; v502_6_label <= 2; ++v502_6_label) {
        const Space v502_6_tail = child(v482_90_tail,v502_6_label);
        if (v502_6_tail.empty()) continue;
        const Path v502_6_head{v502_6_label};
        const Space v503_2 = singleton(v502_6_head);
        const Space v503_3 = intersect(constant_5,v503_2);
        const Space v503_4 = (has_head(v503_3) ? constant_7 : Space{});
        const Space v503_5 = subtract(constant_0,v503_4);
        Space v503_8;
        if (!v503_5.empty()) {
          const Path v504_6 = concat_path(v482_90_head,v502_6_head);
          const Space v504_7 = routine_99(c, v504_6, v502_6_tail);
          v503_8 = compose(v503_5,v504_7);
        }
        const Space v503_9 = intersect(constant_5,v503_2);
        const Space v503_10 = (has_head(v503_9) ? constant_7 : Space{});
        Space v503_12;
        if (!v503_10.empty()) {
          const Path v505_6 = concat_path(v482_90_head,v502_6_head);
          const Space v505_11 = routine_100(c, v505_6, v502_6_tail);
          v503_12 = compose(v503_10,v505_11);
        }
        const Space v503_13 = unite(v503_8,v503_12);
        v502_6_result = unite(v502_6_result,v503_13);
      }
      const Space v502_6 = std::move(v502_6_result);
      v501_7 = compose(v501_5,v502_6);
    }
    const Space v501_8 = intersect(constant_5,v501_2);
    const Space v501_9 = (has_head(v501_8) ? constant_7 : Space{});
    Space v501_11;
    if (!v501_9.empty()) {
      Space v506_10_result;
      for (int v506_10_label = 1; v506_10_label <= 2; ++v506_10_label) {
        const Space v506_10_tail = child(v482_90_tail,v506_10_label);
        if (v506_10_tail.empty()) continue;
        const Path v506_10_head{v506_10_label};
        const Space v507_2 = singleton(v506_10_head);
        const Space v507_3 = intersect(constant_5,v507_2);
        const Space v507_4 = (has_head(v507_3) ? constant_7 : Space{});
        const Space v507_5 = subtract(constant_0,v507_4);
        Space v507_8;
        if (!v507_5.empty()) {
          const Path v508_6 = concat_path(v482_90_head,v506_10_head);
          const Space v508_7 = routine_99(c, v508_6, v506_10_tail);
          v507_8 = compose(v507_5,v508_7);
        }
        const Space v507_9 = intersect(constant_5,v507_2);
        const Space v507_10 = (has_head(v507_9) ? constant_7 : Space{});
        Space v507_12;
        if (!v507_10.empty()) {
          const Path v509_6 = concat_path(v482_90_head,v506_10_head);
          const Space v509_11 = routine_101(c, v509_6, v506_10_tail);
          v507_12 = compose(v507_10,v509_11);
        }
        const Space v507_13 = unite(v507_8,v507_12);
        v506_10_result = unite(v506_10_result,v507_13);
      }
      const Space v506_10 = std::move(v506_10_result);
      v501_11 = compose(v501_9,v506_10);
    }
    const Space v501_12 = unite(v501_7,v501_11);
    v482_90_result = unite(v482_90_result,v501_12);
  }
  const Space v482_90 = std::move(v482_90_result);
  return v482_90;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v510_13_result;
  for (int v510_13_label = 1; v510_13_label <= 2; ++v510_13_label) {
    const Space v510_13_tail = child(s0,v510_13_label);
    if (v510_13_tail.empty()) continue;
    const Path v510_13_head{v510_13_label};
    const Space v511_2 = singleton(v510_13_head);
    const Space v511_3 = intersect(constant_5,v511_2);
    const Space v511_4 = (has_head(v511_3) ? constant_7 : Space{});
    const Space v511_5 = subtract(constant_0,v511_4);
    Space v511_8;
    if (!v511_5.empty()) {
      const Path v512_6 = concat_path(p0,v510_13_head);
      Space v512_7_result;
      for (int v512_7_label = 1; v512_7_label <= 2; ++v512_7_label) {
        const Space v512_7_tail = child(v510_13_tail,v512_7_label);
        if (v512_7_tail.empty()) continue;
        const Path v512_7_head{v512_7_label};
        const Space v513_2 = singleton(v512_7_head);
        const Space v513_3 = intersect(constant_5,v513_2);
        const Space v513_4 = (has_head(v513_3) ? constant_7 : Space{});
        const Space v513_5 = subtract(constant_0,v513_4);
        Space v513_8;
        if (!v513_5.empty()) {
          const Path v514_6 = concat_path(v512_6,v512_7_head);
          const Space v514_7 = routine_102(c, v514_6, p1, v512_7_tail, s1);
          v513_8 = compose(v513_5,v514_7);
        }
        const Space v513_9 = intersect(constant_5,v513_2);
        const Space v513_10 = (has_head(v513_9) ? constant_7 : Space{});
        Space v513_12;
        if (!v513_10.empty()) {
          const Path v515_6 = concat_path(v512_6,v512_7_head);
          const Space v515_11 = routine_103(c, v515_6, p1, v512_7_tail, s1);
          v513_12 = compose(v513_10,v515_11);
        }
        const Space v513_13 = unite(v513_8,v513_12);
        v512_7_result = unite(v512_7_result,v513_13);
      }
      const Space v512_7 = std::move(v512_7_result);
      v511_8 = compose(v511_5,v512_7);
    }
    const Space v511_9 = intersect(constant_5,v511_2);
    const Space v511_10 = (has_head(v511_9) ? constant_7 : Space{});
    Space v511_12;
    if (!v511_10.empty()) {
      const Path v516_6 = concat_path(p0,v510_13_head);
      Space v516_11_result;
      for (int v516_11_label = 1; v516_11_label <= 2; ++v516_11_label) {
        const Space v516_11_tail = child(v510_13_tail,v516_11_label);
        if (v516_11_tail.empty()) continue;
        const Path v516_11_head{v516_11_label};
        const Space v517_2 = singleton(v516_11_head);
        const Space v517_3 = intersect(constant_5,v517_2);
        const Space v517_4 = (has_head(v517_3) ? constant_7 : Space{});
        const Space v517_5 = subtract(constant_0,v517_4);
        Space v517_8;
        if (!v517_5.empty()) {
          const Path v518_6 = concat_path(v516_6,v516_11_head);
          const Space v518_7 = routine_102(c, v518_6, p1, v516_11_tail, s1);
          v517_8 = compose(v517_5,v518_7);
        }
        const Space v517_9 = intersect(constant_5,v517_2);
        const Space v517_10 = (has_head(v517_9) ? constant_7 : Space{});
        Space v517_12;
        if (!v517_10.empty()) {
          const Path v519_6 = concat_path(v516_6,v516_11_head);
          const Space v519_11 = routine_48(c, v519_6, p1, v516_11_tail, s1);
          v517_12 = compose(v517_10,v519_11);
        }
        const Space v517_13 = unite(v517_8,v517_12);
        v516_11_result = unite(v516_11_result,v517_13);
      }
      const Space v516_11 = std::move(v516_11_result);
      v511_12 = compose(v511_10,v516_11);
    }
    const Space v511_13 = unite(v511_8,v511_12);
    v510_13_result = unite(v510_13_result,v511_13);
  }
  const Space v510_13 = std::move(v510_13_result);
  return v510_13;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v520_8 = unwrap(constant_9,p1);
  const Space v520_10 = unwrap(constant_9,p0);
  const Space v520_12 = unwrap(s1,constant_8);
  const Space v520_14 = unwrap(constant_9,p1);
  const Space v520_16 = unwrap(constant_9,p0);
  Space v520_29_result;
  for (int v520_29_label = 1; v520_29_label <= 2; ++v520_29_label) {
    const Space v520_29_tail = child(s0,v520_29_label);
    if (v520_29_tail.empty()) continue;
    const Path v520_29_head{v520_29_label};
    const Space v521_2 = singleton(v520_29_head);
    const Space v521_3 = intersect(constant_5,v521_2);
    const Space v521_4 = (has_head(v521_3) ? constant_7 : Space{});
    const Space v521_5 = subtract(constant_0,v521_4);
    Space v521_8;
    if (!v521_5.empty()) {
      const Path v522_6 = concat_path(p0,v520_29_head);
      Space v522_7_result;
      for (int v522_7_label = 1; v522_7_label <= 2; ++v522_7_label) {
        const Space v522_7_tail = child(v520_29_tail,v522_7_label);
        if (v522_7_tail.empty()) continue;
        const Path v522_7_head{v522_7_label};
        const Space v523_2 = singleton(v522_7_head);
        const Space v523_3 = intersect(constant_5,v523_2);
        const Space v523_4 = (has_head(v523_3) ? constant_7 : Space{});
        const Space v523_5 = subtract(constant_0,v523_4);
        Space v523_8;
        if (!v523_5.empty()) {
          const Path v524_6 = concat_path(v522_6,v522_7_head);
          const Space v524_7 = routine_102(c, v524_6, p1, v522_7_tail, s1);
          v523_8 = compose(v523_5,v524_7);
        }
        const Space v523_9 = intersect(constant_5,v523_2);
        const Space v523_10 = (has_head(v523_9) ? constant_7 : Space{});
        Space v523_12;
        if (!v523_10.empty()) {
          const Path v525_6 = concat_path(v522_6,v522_7_head);
          const Space v525_11 = routine_103(c, v525_6, p1, v522_7_tail, s1);
          v523_12 = compose(v523_10,v525_11);
        }
        const Space v523_13 = unite(v523_8,v523_12);
        v522_7_result = unite(v522_7_result,v523_13);
      }
      const Space v522_7 = std::move(v522_7_result);
      v521_8 = compose(v521_5,v522_7);
    }
    const Space v521_9 = intersect(constant_5,v521_2);
    const Space v521_10 = (has_head(v521_9) ? constant_7 : Space{});
    Space v521_28;
    if (!v521_10.empty()) {
      const Path v526_6 = concat_path(p0,v520_29_head);
      const Space v526_11 = unwrap(v520_10,v520_29_head);
      const Space v526_12 = compose(v520_8,v526_11);
      const Path v526_13 = concat_path(p1,v526_6);
      const Space v526_14 = singleton(v526_13);
      const Space v526_15 = subtract(v526_12,v526_14);
      const Space v526_16 = intersect(v526_15,v520_12);
      const Space v526_17 = routine_51(c, v526_16);
      Space v526_18_result;
      for (int v526_18_label = 1; v526_18_label <= 2; ++v526_18_label) {
        const Space v526_18_tail = child(v526_17,v526_18_label);
        if (v526_18_tail.empty()) continue;
        const Path v526_18_head{v526_18_label};
        const Space v527_2 = singleton(v526_18_head);
        const Space v527_3 = intersect(constant_5,v527_2);
        const Space v527_4 = (has_head(v527_3) ? constant_7 : Space{});
        const Space v527_5 = subtract(constant_0,v527_4);
        Space v527_7;
        if (!v527_5.empty()) {
          const Space v528_6 = routine_52(c, v526_18_head, v526_18_tail);
          v527_7 = compose(v527_5,v528_6);
        }
        const Space v527_8 = intersect(constant_5,v527_2);
        const Space v527_9 = (has_head(v527_8) ? constant_7 : Space{});
        Space v527_11;
        if (!v527_9.empty()) {
          const Space v529_10 = routine_53(c, v526_18_head, v526_18_tail);
          v527_11 = compose(v527_9,v529_10);
        }
        const Space v527_12 = unite(v527_7,v527_11);
        v526_18_result = unite(v526_18_result,v527_12);
      }
      const Space v526_18 = std::move(v526_18_result);
      const Space v526_19 = unwrap(v520_16,v520_29_head);
      const Space v526_20 = compose(v520_14,v526_19);
      const Space v526_21 = subtract(v526_20,v526_14);
      const Space v526_22 = intersect(v526_21,v520_12);
      const Space v526_23 = routine_36(c, v526_22);
      Space v526_24_result;
      for (int v526_24_label = 1; v526_24_label <= 2; ++v526_24_label) {
        const Space v526_24_tail = child(v526_23,v526_24_label);
        if (v526_24_tail.empty()) continue;
        const Path v526_24_head{v526_24_label};
        const Space v530_2 = singleton(v526_24_head);
        const Space v530_3 = intersect(constant_5,v530_2);
        const Space v530_4 = (has_head(v530_3) ? constant_7 : Space{});
        const Space v530_5 = subtract(constant_0,v530_4);
        Space v530_7;
        if (!v530_5.empty()) {
          const Space v531_6 = routine_54(c, v526_24_head, v526_24_tail);
          v530_7 = compose(v530_5,v531_6);
        }
        const Space v530_8 = intersect(constant_5,v530_2);
        const Space v530_9 = (has_head(v530_8) ? constant_7 : Space{});
        Space v530_11;
        if (!v530_9.empty()) {
          const Space v532_10 = routine_55(c, v526_24_head, v526_24_tail);
          v530_11 = compose(v530_9,v532_10);
        }
        const Space v530_12 = unite(v530_7,v530_11);
        v526_24_result = unite(v526_24_result,v530_12);
      }
      const Space v526_24 = std::move(v526_24_result);
      const Space v526_25 = subtract(v526_18,v526_24);
      const Space v526_26 = compose(v526_25,v526_14);
      Space v526_27_result;
      for (int v526_27_label = 1; v526_27_label <= 2; ++v526_27_label) {
        const Space v526_27_tail = child(v526_26,v526_27_label);
        if (v526_27_tail.empty()) continue;
        const Path v526_27_head{v526_27_label};
        const Space v533_2 = singleton(v526_27_head);
        const Space v533_3 = intersect(constant_5,v533_2);
        const Space v533_4 = (has_head(v533_3) ? constant_7 : Space{});
        const Space v533_5 = subtract(constant_0,v533_4);
        Space v533_7;
        if (!v533_5.empty()) {
          const Space v534_6 = routine_56(c, v526_27_head, v526_27_tail);
          v533_7 = compose(v533_5,v534_6);
        }
        const Space v533_8 = intersect(constant_5,v533_2);
        const Space v533_9 = (has_head(v533_8) ? constant_7 : Space{});
        Space v533_11;
        if (!v533_9.empty()) {
          const Space v535_10 = routine_57(c, v526_27_head, v526_27_tail);
          v533_11 = compose(v533_9,v535_10);
        }
        const Space v533_12 = unite(v533_7,v533_11);
        v526_27_result = unite(v526_27_result,v533_12);
      }
      const Space v526_27 = std::move(v526_27_result);
      v521_28 = compose(v521_10,v526_27);
    }
    const Space v521_29 = unite(v521_8,v521_28);
    v520_29_result = unite(v520_29_result,v521_29);
  }
  const Space v520_29 = std::move(v520_29_result);
  return v520_29;
}

static Space routine_51(Context& c, const Space& s0) {
  const Space v536_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v536_2 = first_matching(s0,constant_0,false);
  const Space v536_3 = unite(v536_1,v536_2);
  Space v536_6;
  if (!v536_3.empty()) {
    const Space v537_4 = routine_82(c, s0);
    const Space v537_5 = subtract(s0,v537_4);
    v536_6 = compose(v536_3,v537_5);
  }
  Space v536_9;
  if (!v536_3.empty()) {
    const Space v538_7 = routine_68(c, s0);
    const Space v538_8 = routine_68(c, v538_7);
    v536_9 = compose(v536_3,v538_8);
  }
  const Space v536_10 = subtract(s0,v536_9);
  const Space v536_11 = intersect(v536_6,v536_10);
  return v536_11;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v539_11_result;
  for (int v539_11_label = 1; v539_11_label <= 2; ++v539_11_label) {
    const Space v539_11_tail = child(s0,v539_11_label);
    if (v539_11_tail.empty()) continue;
    const Path v539_11_head{v539_11_label};
    const Space v540_2 = singleton(v539_11_head);
    const Space v540_3 = intersect(constant_5,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_7 : Space{});
    const Space v540_5 = subtract(constant_0,v540_4);
    Space v540_8;
    if (!v540_5.empty()) {
      const Path v541_6 = concat_path(p0,v539_11_head);
      Space v541_7_result;
      for (int v541_7_label = 1; v541_7_label <= 2; ++v541_7_label) {
        const Space v541_7_tail = child(v539_11_tail,v541_7_label);
        if (v541_7_tail.empty()) continue;
        const Path v541_7_head{v541_7_label};
        const Space v542_2 = singleton(v541_7_head);
        const Space v542_3 = intersect(constant_5,v542_2);
        const Space v542_4 = (has_head(v542_3) ? constant_7 : Space{});
        const Space v542_5 = subtract(constant_0,v542_4);
        Space v542_8;
        if (!v542_5.empty()) {
          const Path v543_6 = concat_path(v541_6,v541_7_head);
          const Space v543_7 = routine_104(c, v543_6, v541_7_tail);
          v542_8 = compose(v542_5,v543_7);
        }
        const Space v542_9 = intersect(constant_5,v542_2);
        const Space v542_10 = (has_head(v542_9) ? constant_7 : Space{});
        Space v542_12;
        if (!v542_10.empty()) {
          const Path v544_6 = concat_path(v541_6,v541_7_head);
          const Space v544_11 = routine_105(c, v544_6, v541_7_tail);
          v542_12 = compose(v542_10,v544_11);
        }
        const Space v542_13 = unite(v542_8,v542_12);
        v541_7_result = unite(v541_7_result,v542_13);
      }
      const Space v541_7 = std::move(v541_7_result);
      v540_8 = compose(v540_5,v541_7);
    }
    const Space v540_9 = intersect(constant_5,v540_2);
    const Space v540_10 = (has_head(v540_9) ? constant_7 : Space{});
    Space v540_12;
    if (!v540_10.empty()) {
      const Path v545_6 = concat_path(p0,v539_11_head);
      Space v545_11_result;
      for (int v545_11_label = 1; v545_11_label <= 2; ++v545_11_label) {
        const Space v545_11_tail = child(v539_11_tail,v545_11_label);
        if (v545_11_tail.empty()) continue;
        const Path v545_11_head{v545_11_label};
        const Space v546_2 = singleton(v545_11_head);
        const Space v546_3 = intersect(constant_5,v546_2);
        const Space v546_4 = (has_head(v546_3) ? constant_7 : Space{});
        const Space v546_5 = subtract(constant_0,v546_4);
        Space v546_8;
        if (!v546_5.empty()) {
          const Path v547_6 = concat_path(v545_6,v545_11_head);
          const Space v547_7 = routine_104(c, v547_6, v545_11_tail);
          v546_8 = compose(v546_5,v547_7);
        }
        const Space v546_9 = intersect(constant_5,v546_2);
        const Space v546_10 = (has_head(v546_9) ? constant_7 : Space{});
        Space v546_12;
        if (!v546_10.empty()) {
          const Path v548_6 = concat_path(v545_6,v545_11_head);
          const Space v548_11 = routine_95(c, v548_6, v545_11_tail);
          v546_12 = compose(v546_10,v548_11);
        }
        const Space v546_13 = unite(v546_8,v546_12);
        v545_11_result = unite(v545_11_result,v546_13);
      }
      const Space v545_11 = std::move(v545_11_result);
      v540_12 = compose(v540_10,v545_11);
    }
    const Space v540_13 = unite(v540_8,v540_12);
    v539_11_result = unite(v539_11_result,v540_13);
  }
  const Space v539_11 = std::move(v539_11_result);
  return v539_11;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0) {
  Space v549_9_result;
  for (int v549_9_label = 1; v549_9_label <= 2; ++v549_9_label) {
    const Space v549_9_tail = child(s0,v549_9_label);
    if (v549_9_tail.empty()) continue;
    const Path v549_9_head{v549_9_label};
    const Space v550_2 = singleton(v549_9_head);
    const Space v550_3 = intersect(constant_5,v550_2);
    const Space v550_4 = (has_head(v550_3) ? constant_7 : Space{});
    const Space v550_5 = subtract(constant_0,v550_4);
    Space v550_8;
    if (!v550_5.empty()) {
      const Path v551_6 = concat_path(p0,v549_9_head);
      Space v551_7_result;
      for (int v551_7_label = 1; v551_7_label <= 2; ++v551_7_label) {
        const Space v551_7_tail = child(v549_9_tail,v551_7_label);
        if (v551_7_tail.empty()) continue;
        const Path v551_7_head{v551_7_label};
        const Space v552_2 = singleton(v551_7_head);
        const Space v552_3 = intersect(constant_5,v552_2);
        const Space v552_4 = (has_head(v552_3) ? constant_7 : Space{});
        const Space v552_5 = subtract(constant_0,v552_4);
        Space v552_8;
        if (!v552_5.empty()) {
          const Path v553_6 = concat_path(v551_6,v551_7_head);
          const Space v553_7 = routine_104(c, v553_6, v551_7_tail);
          v552_8 = compose(v552_5,v553_7);
        }
        const Space v552_9 = intersect(constant_5,v552_2);
        const Space v552_10 = (has_head(v552_9) ? constant_7 : Space{});
        Space v552_12;
        if (!v552_10.empty()) {
          const Path v554_6 = concat_path(v551_6,v551_7_head);
          const Space v554_11 = routine_105(c, v554_6, v551_7_tail);
          v552_12 = compose(v552_10,v554_11);
        }
        const Space v552_13 = unite(v552_8,v552_12);
        v551_7_result = unite(v551_7_result,v552_13);
      }
      const Space v551_7 = std::move(v551_7_result);
      v550_8 = compose(v550_5,v551_7);
    }
    const Space v550_9 = intersect(constant_5,v550_2);
    const Space v550_10 = (has_head(v550_9) ? constant_7 : Space{});
    const Space v550_11 = compose(v550_10,constant_10);
    const Space v550_12 = unite(v550_8,v550_11);
    v549_9_result = unite(v549_9_result,v550_12);
  }
  const Space v549_9 = std::move(v549_9_result);
  return v549_9;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0) {
  Space v555_11_result;
  for (int v555_11_label = 1; v555_11_label <= 2; ++v555_11_label) {
    const Space v555_11_tail = child(s0,v555_11_label);
    if (v555_11_tail.empty()) continue;
    const Path v555_11_head{v555_11_label};
    const Space v556_2 = singleton(v555_11_head);
    const Space v556_3 = intersect(constant_5,v556_2);
    const Space v556_4 = (has_head(v556_3) ? constant_7 : Space{});
    const Space v556_5 = subtract(constant_0,v556_4);
    Space v556_8;
    if (!v556_5.empty()) {
      const Path v557_6 = concat_path(p0,v555_11_head);
      Space v557_7_result;
      for (int v557_7_label = 1; v557_7_label <= 2; ++v557_7_label) {
        const Space v557_7_tail = child(v555_11_tail,v557_7_label);
        if (v557_7_tail.empty()) continue;
        const Path v557_7_head{v557_7_label};
        const Space v558_2 = singleton(v557_7_head);
        const Space v558_3 = intersect(constant_5,v558_2);
        const Space v558_4 = (has_head(v558_3) ? constant_7 : Space{});
        const Space v558_5 = subtract(constant_0,v558_4);
        Space v558_8;
        if (!v558_5.empty()) {
          const Path v559_6 = concat_path(v557_6,v557_7_head);
          const Space v559_7 = routine_106(c, v559_6, v557_7_tail);
          v558_8 = compose(v558_5,v559_7);
        }
        const Space v558_9 = intersect(constant_5,v558_2);
        const Space v558_10 = (has_head(v558_9) ? constant_7 : Space{});
        Space v558_12;
        if (!v558_10.empty()) {
          const Path v560_6 = concat_path(v557_6,v557_7_head);
          const Space v560_11 = routine_107(c, v560_6, v557_7_tail);
          v558_12 = compose(v558_10,v560_11);
        }
        const Space v558_13 = unite(v558_8,v558_12);
        v557_7_result = unite(v557_7_result,v558_13);
      }
      const Space v557_7 = std::move(v557_7_result);
      v556_8 = compose(v556_5,v557_7);
    }
    const Space v556_9 = intersect(constant_5,v556_2);
    const Space v556_10 = (has_head(v556_9) ? constant_7 : Space{});
    Space v556_12;
    if (!v556_10.empty()) {
      const Path v561_6 = concat_path(p0,v555_11_head);
      Space v561_11_result;
      for (int v561_11_label = 1; v561_11_label <= 2; ++v561_11_label) {
        const Space v561_11_tail = child(v555_11_tail,v561_11_label);
        if (v561_11_tail.empty()) continue;
        const Path v561_11_head{v561_11_label};
        const Space v562_2 = singleton(v561_11_head);
        const Space v562_3 = intersect(constant_5,v562_2);
        const Space v562_4 = (has_head(v562_3) ? constant_7 : Space{});
        const Space v562_5 = subtract(constant_0,v562_4);
        Space v562_8;
        if (!v562_5.empty()) {
          const Path v563_6 = concat_path(v561_6,v561_11_head);
          const Space v563_7 = routine_106(c, v563_6, v561_11_tail);
          v562_8 = compose(v562_5,v563_7);
        }
        const Space v562_9 = intersect(constant_5,v562_2);
        const Space v562_10 = (has_head(v562_9) ? constant_7 : Space{});
        Space v562_12;
        if (!v562_10.empty()) {
          const Path v564_6 = concat_path(v561_6,v561_11_head);
          const Space v564_11 = routine_98(c, v564_6, v561_11_tail);
          v562_12 = compose(v562_10,v564_11);
        }
        const Space v562_13 = unite(v562_8,v562_12);
        v561_11_result = unite(v561_11_result,v562_13);
      }
      const Space v561_11 = std::move(v561_11_result);
      v556_12 = compose(v556_10,v561_11);
    }
    const Space v556_13 = unite(v556_8,v556_12);
    v555_11_result = unite(v555_11_result,v556_13);
  }
  const Space v555_11 = std::move(v555_11_result);
  return v555_11;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v565_9_result;
  for (int v565_9_label = 1; v565_9_label <= 2; ++v565_9_label) {
    const Space v565_9_tail = child(s0,v565_9_label);
    if (v565_9_tail.empty()) continue;
    const Path v565_9_head{v565_9_label};
    const Space v566_2 = singleton(v565_9_head);
    const Space v566_3 = intersect(constant_5,v566_2);
    const Space v566_4 = (has_head(v566_3) ? constant_7 : Space{});
    const Space v566_5 = subtract(constant_0,v566_4);
    Space v566_8;
    if (!v566_5.empty()) {
      const Path v567_6 = concat_path(p0,v565_9_head);
      Space v567_7_result;
      for (int v567_7_label = 1; v567_7_label <= 2; ++v567_7_label) {
        const Space v567_7_tail = child(v565_9_tail,v567_7_label);
        if (v567_7_tail.empty()) continue;
        const Path v567_7_head{v567_7_label};
        const Space v568_2 = singleton(v567_7_head);
        const Space v568_3 = intersect(constant_5,v568_2);
        const Space v568_4 = (has_head(v568_3) ? constant_7 : Space{});
        const Space v568_5 = subtract(constant_0,v568_4);
        Space v568_8;
        if (!v568_5.empty()) {
          const Path v569_6 = concat_path(v567_6,v567_7_head);
          const Space v569_7 = routine_106(c, v569_6, v567_7_tail);
          v568_8 = compose(v568_5,v569_7);
        }
        const Space v568_9 = intersect(constant_5,v568_2);
        const Space v568_10 = (has_head(v568_9) ? constant_7 : Space{});
        Space v568_12;
        if (!v568_10.empty()) {
          const Path v570_6 = concat_path(v567_6,v567_7_head);
          const Space v570_11 = routine_107(c, v570_6, v567_7_tail);
          v568_12 = compose(v568_10,v570_11);
        }
        const Space v568_13 = unite(v568_8,v568_12);
        v567_7_result = unite(v567_7_result,v568_13);
      }
      const Space v567_7 = std::move(v567_7_result);
      v566_8 = compose(v566_5,v567_7);
    }
    const Space v566_9 = intersect(constant_5,v566_2);
    const Space v566_10 = (has_head(v566_9) ? constant_7 : Space{});
    const Space v566_11 = compose(v566_10,constant_10);
    const Space v566_12 = unite(v566_8,v566_11);
    v565_9_result = unite(v565_9_result,v566_12);
  }
  const Space v565_9 = std::move(v565_9_result);
  return v565_9;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v571_11_result;
  for (int v571_11_label = 1; v571_11_label <= 2; ++v571_11_label) {
    const Space v571_11_tail = child(s0,v571_11_label);
    if (v571_11_tail.empty()) continue;
    const Path v571_11_head{v571_11_label};
    const Space v572_2 = singleton(v571_11_head);
    const Space v572_3 = intersect(constant_5,v572_2);
    const Space v572_4 = (has_head(v572_3) ? constant_7 : Space{});
    const Space v572_5 = subtract(constant_0,v572_4);
    Space v572_8;
    if (!v572_5.empty()) {
      const Path v573_6 = concat_path(p0,v571_11_head);
      Space v573_7_result;
      for (int v573_7_label = 1; v573_7_label <= 2; ++v573_7_label) {
        const Space v573_7_tail = child(v571_11_tail,v573_7_label);
        if (v573_7_tail.empty()) continue;
        const Path v573_7_head{v573_7_label};
        const Space v574_2 = singleton(v573_7_head);
        const Space v574_3 = intersect(constant_5,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_7 : Space{});
        const Space v574_5 = subtract(constant_0,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_7_head);
          const Space v575_7 = routine_108(c, v575_6, v573_7_tail);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_5,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_7 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_7_head);
          const Space v576_11 = routine_109(c, v576_6, v573_7_tail);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_7_result = unite(v573_7_result,v574_13);
      }
      const Space v573_7 = std::move(v573_7_result);
      v572_8 = compose(v572_5,v573_7);
    }
    const Space v572_9 = intersect(constant_5,v572_2);
    const Space v572_10 = (has_head(v572_9) ? constant_7 : Space{});
    Space v572_12;
    if (!v572_10.empty()) {
      const Path v577_6 = concat_path(p0,v571_11_head);
      Space v577_11_result;
      for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
        const Space v577_11_tail = child(v571_11_tail,v577_11_label);
        if (v577_11_tail.empty()) continue;
        const Path v577_11_head{v577_11_label};
        const Space v578_2 = singleton(v577_11_head);
        const Space v578_3 = intersect(constant_5,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_7 : Space{});
        const Space v578_5 = subtract(constant_0,v578_4);
        Space v578_8;
        if (!v578_5.empty()) {
          const Path v579_6 = concat_path(v577_6,v577_11_head);
          const Space v579_7 = routine_108(c, v579_6, v577_11_tail);
          v578_8 = compose(v578_5,v579_7);
        }
        const Space v578_9 = intersect(constant_5,v578_2);
        const Space v578_10 = (has_head(v578_9) ? constant_7 : Space{});
        Space v578_12;
        if (!v578_10.empty()) {
          const Path v580_6 = concat_path(v577_6,v577_11_head);
          const Space v580_11 = routine_101(c, v580_6, v577_11_tail);
          v578_12 = compose(v578_10,v580_11);
        }
        const Space v578_13 = unite(v578_8,v578_12);
        v577_11_result = unite(v577_11_result,v578_13);
      }
      const Space v577_11 = std::move(v577_11_result);
      v572_12 = compose(v572_10,v577_11);
    }
    const Space v572_13 = unite(v572_8,v572_12);
    v571_11_result = unite(v571_11_result,v572_13);
  }
  const Space v571_11 = std::move(v571_11_result);
  return v571_11;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v581_8_result;
  for (int v581_8_label = 1; v581_8_label <= 2; ++v581_8_label) {
    const Space v581_8_tail = child(s0,v581_8_label);
    if (v581_8_tail.empty()) continue;
    const Path v581_8_head{v581_8_label};
    const Space v582_2 = singleton(v581_8_head);
    const Space v582_3 = intersect(constant_5,v582_2);
    const Space v582_4 = (has_head(v582_3) ? constant_7 : Space{});
    const Space v582_5 = subtract(constant_0,v582_4);
    Space v582_8;
    if (!v582_5.empty()) {
      const Path v583_6 = concat_path(p0,v581_8_head);
      Space v583_7_result;
      for (int v583_7_label = 1; v583_7_label <= 2; ++v583_7_label) {
        const Space v583_7_tail = child(v581_8_tail,v583_7_label);
        if (v583_7_tail.empty()) continue;
        const Path v583_7_head{v583_7_label};
        const Space v584_2 = singleton(v583_7_head);
        const Space v584_3 = intersect(constant_5,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_7 : Space{});
        const Space v584_5 = subtract(constant_0,v584_4);
        Space v584_8;
        if (!v584_5.empty()) {
          const Path v585_6 = concat_path(v583_6,v583_7_head);
          const Space v585_7 = routine_108(c, v585_6, v583_7_tail);
          v584_8 = compose(v584_5,v585_7);
        }
        const Space v584_9 = intersect(constant_5,v584_2);
        const Space v584_10 = (has_head(v584_9) ? constant_7 : Space{});
        Space v584_12;
        if (!v584_10.empty()) {
          const Path v586_6 = concat_path(v583_6,v583_7_head);
          const Space v586_11 = routine_109(c, v586_6, v583_7_tail);
          v584_12 = compose(v584_10,v586_11);
        }
        const Space v584_13 = unite(v584_8,v584_12);
        v583_7_result = unite(v583_7_result,v584_13);
      }
      const Space v583_7 = std::move(v583_7_result);
      v582_8 = compose(v582_5,v583_7);
    }
    const Space v582_9 = intersect(constant_5,v582_2);
    const Space v582_10 = (has_head(v582_9) ? constant_7 : Space{});
    const Space v582_11 = compose(v582_10,v581_8_tail);
    const Space v582_12 = unite(v582_8,v582_11);
    v581_8_result = unite(v581_8_result,v582_12);
  }
  const Space v581_8 = std::move(v581_8_result);
  return v581_8;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0) {
  Space v587_11_result;
  for (int v587_11_label = 1; v587_11_label <= 2; ++v587_11_label) {
    const Space v587_11_tail = child(s0,v587_11_label);
    if (v587_11_tail.empty()) continue;
    const Path v587_11_head{v587_11_label};
    const Space v588_2 = singleton(v587_11_head);
    const Space v588_3 = intersect(constant_5,v588_2);
    const Space v588_4 = (has_head(v588_3) ? constant_7 : Space{});
    const Space v588_5 = subtract(constant_0,v588_4);
    Space v588_8;
    if (!v588_5.empty()) {
      const Path v589_6 = concat_path(p0,v587_11_head);
      Space v589_7_result;
      for (int v589_7_label = 1; v589_7_label <= 2; ++v589_7_label) {
        const Space v589_7_tail = child(v587_11_tail,v589_7_label);
        if (v589_7_tail.empty()) continue;
        const Path v589_7_head{v589_7_label};
        const Space v590_2 = singleton(v589_7_head);
        const Space v590_3 = intersect(constant_5,v590_2);
        const Space v590_4 = (has_head(v590_3) ? constant_7 : Space{});
        const Space v590_5 = subtract(constant_0,v590_4);
        Space v590_8;
        if (!v590_5.empty()) {
          const Path v591_6 = concat_path(v589_6,v589_7_head);
          const Space v591_7 = routine_110(c, v591_6, v589_7_tail);
          v590_8 = compose(v590_5,v591_7);
        }
        const Space v590_9 = intersect(constant_5,v590_2);
        const Space v590_10 = (has_head(v590_9) ? constant_7 : Space{});
        Space v590_12;
        if (!v590_10.empty()) {
          const Path v592_6 = concat_path(v589_6,v589_7_head);
          const Space v592_11 = routine_111(c, v592_6, v589_7_tail);
          v590_12 = compose(v590_10,v592_11);
        }
        const Space v590_13 = unite(v590_8,v590_12);
        v589_7_result = unite(v589_7_result,v590_13);
      }
      const Space v589_7 = std::move(v589_7_result);
      v588_8 = compose(v588_5,v589_7);
    }
    const Space v588_9 = intersect(constant_5,v588_2);
    const Space v588_10 = (has_head(v588_9) ? constant_7 : Space{});
    Space v588_12;
    if (!v588_10.empty()) {
      const Path v593_6 = concat_path(p0,v587_11_head);
      Space v593_11_result;
      for (int v593_11_label = 1; v593_11_label <= 2; ++v593_11_label) {
        const Space v593_11_tail = child(v587_11_tail,v593_11_label);
        if (v593_11_tail.empty()) continue;
        const Path v593_11_head{v593_11_label};
        const Space v594_2 = singleton(v593_11_head);
        const Space v594_3 = intersect(constant_5,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_7 : Space{});
        const Space v594_5 = subtract(constant_0,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_11_head);
          const Space v595_7 = routine_110(c, v595_6, v593_11_tail);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_5,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_7 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_11_head);
          const Space v596_11 = routine_9(c, v596_6, v593_11_tail);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_11_result = unite(v593_11_result,v594_13);
      }
      const Space v593_11 = std::move(v593_11_result);
      v588_12 = compose(v588_10,v593_11);
    }
    const Space v588_13 = unite(v588_8,v588_12);
    v587_11_result = unite(v587_11_result,v588_13);
  }
  const Space v587_11 = std::move(v587_11_result);
  return v587_11;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0) {
  Space v597_11_result;
  for (int v597_11_label = 1; v597_11_label <= 2; ++v597_11_label) {
    const Space v597_11_tail = child(s0,v597_11_label);
    if (v597_11_tail.empty()) continue;
    const Path v597_11_head{v597_11_label};
    const Space v598_2 = singleton(v597_11_head);
    const Space v598_3 = intersect(constant_5,v598_2);
    const Space v598_4 = (has_head(v598_3) ? constant_7 : Space{});
    const Space v598_5 = subtract(constant_0,v598_4);
    Space v598_8;
    if (!v598_5.empty()) {
      const Path v599_6 = concat_path(p0,v597_11_head);
      Space v599_7_result;
      for (int v599_7_label = 1; v599_7_label <= 2; ++v599_7_label) {
        const Space v599_7_tail = child(v597_11_tail,v599_7_label);
        if (v599_7_tail.empty()) continue;
        const Path v599_7_head{v599_7_label};
        const Space v600_2 = singleton(v599_7_head);
        const Space v600_3 = intersect(constant_5,v600_2);
        const Space v600_4 = (has_head(v600_3) ? constant_7 : Space{});
        const Space v600_5 = subtract(constant_0,v600_4);
        Space v600_8;
        if (!v600_5.empty()) {
          const Path v601_6 = concat_path(v599_6,v599_7_head);
          const Space v601_7 = routine_110(c, v601_6, v599_7_tail);
          v600_8 = compose(v600_5,v601_7);
        }
        const Space v600_9 = intersect(constant_5,v600_2);
        const Space v600_10 = (has_head(v600_9) ? constant_7 : Space{});
        Space v600_12;
        if (!v600_10.empty()) {
          const Path v602_6 = concat_path(v599_6,v599_7_head);
          const Space v602_11 = routine_111(c, v602_6, v599_7_tail);
          v600_12 = compose(v600_10,v602_11);
        }
        const Space v600_13 = unite(v600_8,v600_12);
        v599_7_result = unite(v599_7_result,v600_13);
      }
      const Space v599_7 = std::move(v599_7_result);
      v598_8 = compose(v598_5,v599_7);
    }
    const Space v598_9 = intersect(constant_5,v598_2);
    const Space v598_10 = (has_head(v598_9) ? constant_7 : Space{});
    Space v598_12;
    if (!v598_10.empty()) {
      const Path v603_6 = concat_path(p0,v597_11_head);
      Space v603_11_result;
      for (int v603_11_label = 1; v603_11_label <= 2; ++v603_11_label) {
        const Space v603_11_tail = child(v597_11_tail,v603_11_label);
        if (v603_11_tail.empty()) continue;
        const Path v603_11_head{v603_11_label};
        const Space v604_2 = singleton(v603_11_head);
        const Space v604_3 = intersect(constant_5,v604_2);
        const Space v604_4 = (has_head(v604_3) ? constant_7 : Space{});
        const Space v604_5 = subtract(constant_0,v604_4);
        Space v604_7;
        if (!v604_5.empty()) {
          const Space v605_6 = routine_10(c, v603_11_head, v603_6, v603_11_tail);
          v604_7 = compose(v604_5,v605_6);
        }
        const Space v604_8 = intersect(constant_5,v604_2);
        const Space v604_9 = (has_head(v604_8) ? constant_7 : Space{});
        Space v604_11;
        if (!v604_9.empty()) {
          const Space v606_10 = routine_11(c, v603_11_head, v603_6, v603_11_tail);
          v604_11 = compose(v604_9,v606_10);
        }
        const Space v604_12 = unite(v604_7,v604_11);
        v603_11_result = unite(v603_11_result,v604_12);
      }
      const Space v603_11 = std::move(v603_11_result);
      v598_12 = compose(v598_10,v603_11);
    }
    const Space v598_13 = unite(v598_8,v598_12);
    v597_11_result = unite(v597_11_result,v598_13);
  }
  const Space v597_11 = std::move(v597_11_result);
  return v597_11;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v607_12_result;
  for (int v607_12_label = 1; v607_12_label <= 2; ++v607_12_label) {
    const Space v607_12_tail = child(s0,v607_12_label);
    if (v607_12_tail.empty()) continue;
    const Path v607_12_head{v607_12_label};
    const Space v608_2 = singleton(v607_12_head);
    const Space v608_3 = intersect(constant_5,v608_2);
    const Space v608_4 = (has_head(v608_3) ? constant_7 : Space{});
    const Space v608_5 = subtract(constant_0,v608_4);
    Space v608_8;
    if (!v608_5.empty()) {
      const Path v609_6 = concat_path(p0,v607_12_head);
      Space v609_7_result;
      for (int v609_7_label = 1; v609_7_label <= 2; ++v609_7_label) {
        const Space v609_7_tail = child(v607_12_tail,v609_7_label);
        if (v609_7_tail.empty()) continue;
        const Path v609_7_head{v609_7_label};
        const Space v610_2 = singleton(v609_7_head);
        const Space v610_3 = intersect(constant_5,v610_2);
        const Space v610_4 = (has_head(v610_3) ? constant_7 : Space{});
        const Space v610_5 = subtract(constant_0,v610_4);
        Space v610_8;
        if (!v610_5.empty()) {
          const Path v611_6 = concat_path(v609_6,v609_7_head);
          const Space v611_7 = routine_112(c, v611_6, p1, v609_7_tail);
          v610_8 = compose(v610_5,v611_7);
        }
        const Space v610_9 = intersect(constant_5,v610_2);
        const Space v610_10 = (has_head(v610_9) ? constant_7 : Space{});
        Space v610_12;
        if (!v610_10.empty()) {
          const Path v612_6 = concat_path(v609_6,v609_7_head);
          const Space v612_11 = routine_113(c, v612_6, p1, v609_7_tail);
          v610_12 = compose(v610_10,v612_11);
        }
        const Space v610_13 = unite(v610_8,v610_12);
        v609_7_result = unite(v609_7_result,v610_13);
      }
      const Space v609_7 = std::move(v609_7_result);
      v608_8 = compose(v608_5,v609_7);
    }
    const Space v608_9 = intersect(constant_5,v608_2);
    const Space v608_10 = (has_head(v608_9) ? constant_7 : Space{});
    Space v608_12;
    if (!v608_10.empty()) {
      const Path v613_6 = concat_path(p0,v607_12_head);
      Space v613_11_result;
      for (int v613_11_label = 1; v613_11_label <= 2; ++v613_11_label) {
        const Space v613_11_tail = child(v607_12_tail,v613_11_label);
        if (v613_11_tail.empty()) continue;
        const Path v613_11_head{v613_11_label};
        const Space v614_2 = singleton(v613_11_head);
        const Space v614_3 = intersect(constant_5,v614_2);
        const Space v614_4 = (has_head(v614_3) ? constant_7 : Space{});
        const Space v614_5 = subtract(constant_0,v614_4);
        Space v614_8;
        if (!v614_5.empty()) {
          const Path v615_6 = concat_path(v613_6,v613_11_head);
          const Space v615_7 = routine_112(c, v615_6, p1, v613_11_tail);
          v614_8 = compose(v614_5,v615_7);
        }
        const Space v614_9 = intersect(constant_5,v614_2);
        const Space v614_10 = (has_head(v614_9) ? constant_7 : Space{});
        Space v614_12;
        if (!v614_10.empty()) {
          const Path v616_6 = concat_path(v613_6,v613_11_head);
          const Space v616_11 = routine_26(c, v616_6, p1, v613_11_tail);
          v614_12 = compose(v614_10,v616_11);
        }
        const Space v614_13 = unite(v614_8,v614_12);
        v613_11_result = unite(v613_11_result,v614_13);
      }
      const Space v613_11 = std::move(v613_11_result);
      v608_12 = compose(v608_10,v613_11);
    }
    const Space v608_13 = unite(v608_8,v608_12);
    v607_12_result = unite(v607_12_result,v608_13);
  }
  const Space v607_12 = std::move(v607_12_result);
  return v607_12;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v617_7 = unwrap(constant_9,p1);
  const Space v617_9 = unwrap(constant_9,p0);
  Space v617_13_result;
  for (int v617_13_label = 1; v617_13_label <= 2; ++v617_13_label) {
    const Space v617_13_tail = child(s0,v617_13_label);
    if (v617_13_tail.empty()) continue;
    const Path v617_13_head{v617_13_label};
    const Space v618_2 = singleton(v617_13_head);
    const Space v618_3 = intersect(constant_5,v618_2);
    const Space v618_4 = (has_head(v618_3) ? constant_7 : Space{});
    const Space v618_5 = subtract(constant_0,v618_4);
    Space v618_8;
    if (!v618_5.empty()) {
      const Path v619_6 = concat_path(p0,v617_13_head);
      Space v619_7_result;
      for (int v619_7_label = 1; v619_7_label <= 2; ++v619_7_label) {
        const Space v619_7_tail = child(v617_13_tail,v619_7_label);
        if (v619_7_tail.empty()) continue;
        const Path v619_7_head{v619_7_label};
        const Space v620_2 = singleton(v619_7_head);
        const Space v620_3 = intersect(constant_5,v620_2);
        const Space v620_4 = (has_head(v620_3) ? constant_7 : Space{});
        const Space v620_5 = subtract(constant_0,v620_4);
        Space v620_8;
        if (!v620_5.empty()) {
          const Path v621_6 = concat_path(v619_6,v619_7_head);
          const Space v621_7 = routine_112(c, v621_6, p1, v619_7_tail);
          v620_8 = compose(v620_5,v621_7);
        }
        const Space v620_9 = intersect(constant_5,v620_2);
        const Space v620_10 = (has_head(v620_9) ? constant_7 : Space{});
        Space v620_12;
        if (!v620_10.empty()) {
          const Path v622_6 = concat_path(v619_6,v619_7_head);
          const Space v622_11 = routine_113(c, v622_6, p1, v619_7_tail);
          v620_12 = compose(v620_10,v622_11);
        }
        const Space v620_13 = unite(v620_8,v620_12);
        v619_7_result = unite(v619_7_result,v620_13);
      }
      const Space v619_7 = std::move(v619_7_result);
      v618_8 = compose(v618_5,v619_7);
    }
    const Space v618_9 = intersect(constant_5,v618_2);
    const Space v618_10 = (has_head(v618_9) ? constant_7 : Space{});
    const Space v618_11 = unwrap(v617_9,v617_13_head);
    const Space v618_12 = compose(v617_7,v618_11);
    const Path v623_6 = concat_path(p0,v617_13_head);
    const Path v618_13 = concat_path(p1,v623_6);
    const Space v618_14 = singleton(v618_13);
    const Space v618_15 = subtract(v618_12,v618_14);
    const Space v618_16 = compose(v618_10,v618_15);
    const Space v618_17 = unite(v618_8,v618_16);
    v617_13_result = unite(v617_13_result,v618_17);
  }
  const Space v617_13 = std::move(v617_13_result);
  return v617_13;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v624_12_result;
  for (int v624_12_label = 1; v624_12_label <= 2; ++v624_12_label) {
    const Space v624_12_tail = child(s0,v624_12_label);
    if (v624_12_tail.empty()) continue;
    const Path v624_12_head{v624_12_label};
    const Space v625_2 = singleton(v624_12_head);
    const Space v625_3 = intersect(constant_5,v625_2);
    const Space v625_4 = (has_head(v625_3) ? constant_7 : Space{});
    const Space v625_5 = subtract(constant_0,v625_4);
    Space v625_8;
    if (!v625_5.empty()) {
      const Path v626_6 = concat_path(p0,v624_12_head);
      Space v626_7_result;
      for (int v626_7_label = 1; v626_7_label <= 2; ++v626_7_label) {
        const Space v626_7_tail = child(v624_12_tail,v626_7_label);
        if (v626_7_tail.empty()) continue;
        const Path v626_7_head{v626_7_label};
        const Space v627_2 = singleton(v626_7_head);
        const Space v627_3 = intersect(constant_5,v627_2);
        const Space v627_4 = (has_head(v627_3) ? constant_7 : Space{});
        const Space v627_5 = subtract(constant_0,v627_4);
        Space v627_8;
        if (!v627_5.empty()) {
          const Path v628_6 = concat_path(v626_6,v626_7_head);
          const Space v628_7 = routine_114(c, v628_6, p1, v626_7_tail);
          v627_8 = compose(v627_5,v628_7);
        }
        const Space v627_9 = intersect(constant_5,v627_2);
        const Space v627_10 = (has_head(v627_9) ? constant_7 : Space{});
        Space v627_12;
        if (!v627_10.empty()) {
          const Path v629_6 = concat_path(v626_6,v626_7_head);
          const Space v629_11 = routine_115(c, v629_6, p1, v626_7_tail);
          v627_12 = compose(v627_10,v629_11);
        }
        const Space v627_13 = unite(v627_8,v627_12);
        v626_7_result = unite(v626_7_result,v627_13);
      }
      const Space v626_7 = std::move(v626_7_result);
      v625_8 = compose(v625_5,v626_7);
    }
    const Space v625_9 = intersect(constant_5,v625_2);
    const Space v625_10 = (has_head(v625_9) ? constant_7 : Space{});
    Space v625_12;
    if (!v625_10.empty()) {
      const Path v630_6 = concat_path(p0,v624_12_head);
      Space v630_11_result;
      for (int v630_11_label = 1; v630_11_label <= 2; ++v630_11_label) {
        const Space v630_11_tail = child(v624_12_tail,v630_11_label);
        if (v630_11_tail.empty()) continue;
        const Path v630_11_head{v630_11_label};
        const Space v631_2 = singleton(v630_11_head);
        const Space v631_3 = intersect(constant_5,v631_2);
        const Space v631_4 = (has_head(v631_3) ? constant_7 : Space{});
        const Space v631_5 = subtract(constant_0,v631_4);
        Space v631_8;
        if (!v631_5.empty()) {
          const Path v632_6 = concat_path(v630_6,v630_11_head);
          const Space v632_7 = routine_114(c, v632_6, p1, v630_11_tail);
          v631_8 = compose(v631_5,v632_7);
        }
        const Space v631_9 = intersect(constant_5,v631_2);
        const Space v631_10 = (has_head(v631_9) ? constant_7 : Space{});
        Space v631_12;
        if (!v631_10.empty()) {
          const Path v633_6 = concat_path(v630_6,v630_11_head);
          const Space v633_11 = routine_26(c, v633_6, p1, v630_11_tail);
          v631_12 = compose(v631_10,v633_11);
        }
        const Space v631_13 = unite(v631_8,v631_12);
        v630_11_result = unite(v630_11_result,v631_13);
      }
      const Space v630_11 = std::move(v630_11_result);
      v625_12 = compose(v625_10,v630_11);
    }
    const Space v625_13 = unite(v625_8,v625_12);
    v624_12_result = unite(v624_12_result,v625_13);
  }
  const Space v624_12 = std::move(v624_12_result);
  return v624_12;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v634_7 = unwrap(constant_9,p1);
  const Space v634_9 = unwrap(constant_9,p0);
  Space v634_13_result;
  for (int v634_13_label = 1; v634_13_label <= 2; ++v634_13_label) {
    const Space v634_13_tail = child(s0,v634_13_label);
    if (v634_13_tail.empty()) continue;
    const Path v634_13_head{v634_13_label};
    const Space v635_2 = singleton(v634_13_head);
    const Space v635_3 = intersect(constant_5,v635_2);
    const Space v635_4 = (has_head(v635_3) ? constant_7 : Space{});
    const Space v635_5 = subtract(constant_0,v635_4);
    Space v635_8;
    if (!v635_5.empty()) {
      const Path v636_6 = concat_path(p0,v634_13_head);
      Space v636_7_result;
      for (int v636_7_label = 1; v636_7_label <= 2; ++v636_7_label) {
        const Space v636_7_tail = child(v634_13_tail,v636_7_label);
        if (v636_7_tail.empty()) continue;
        const Path v636_7_head{v636_7_label};
        const Space v637_2 = singleton(v636_7_head);
        const Space v637_3 = intersect(constant_5,v637_2);
        const Space v637_4 = (has_head(v637_3) ? constant_7 : Space{});
        const Space v637_5 = subtract(constant_0,v637_4);
        Space v637_8;
        if (!v637_5.empty()) {
          const Path v638_6 = concat_path(v636_6,v636_7_head);
          const Space v638_7 = routine_114(c, v638_6, p1, v636_7_tail);
          v637_8 = compose(v637_5,v638_7);
        }
        const Space v637_9 = intersect(constant_5,v637_2);
        const Space v637_10 = (has_head(v637_9) ? constant_7 : Space{});
        Space v637_12;
        if (!v637_10.empty()) {
          const Path v639_6 = concat_path(v636_6,v636_7_head);
          const Space v639_11 = routine_115(c, v639_6, p1, v636_7_tail);
          v637_12 = compose(v637_10,v639_11);
        }
        const Space v637_13 = unite(v637_8,v637_12);
        v636_7_result = unite(v636_7_result,v637_13);
      }
      const Space v636_7 = std::move(v636_7_result);
      v635_8 = compose(v635_5,v636_7);
    }
    const Space v635_9 = intersect(constant_5,v635_2);
    const Space v635_10 = (has_head(v635_9) ? constant_7 : Space{});
    const Space v635_11 = unwrap(v634_9,v634_13_head);
    const Space v635_12 = compose(v634_7,v635_11);
    const Path v640_6 = concat_path(p0,v634_13_head);
    const Path v635_13 = concat_path(p1,v640_6);
    const Space v635_14 = singleton(v635_13);
    const Space v635_15 = subtract(v635_12,v635_14);
    const Space v635_16 = compose(v635_10,v635_15);
    const Space v635_17 = unite(v635_8,v635_16);
    v634_13_result = unite(v634_13_result,v635_17);
  }
  const Space v634_13 = std::move(v634_13_result);
  return v634_13;
}

static Space routine_64(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v641_12_result;
  for (int v641_12_label = 1; v641_12_label <= 2; ++v641_12_label) {
    const Space v641_12_tail = child(s0,v641_12_label);
    if (v641_12_tail.empty()) continue;
    const Path v641_12_head{v641_12_label};
    const Space v642_2 = singleton(v641_12_head);
    const Space v642_3 = intersect(constant_5,v642_2);
    const Space v642_4 = (has_head(v642_3) ? constant_7 : Space{});
    const Space v642_5 = subtract(constant_0,v642_4);
    Space v642_8;
    if (!v642_5.empty()) {
      const Path v643_6 = concat_path(p0,v641_12_head);
      Space v643_7_result;
      for (int v643_7_label = 1; v643_7_label <= 2; ++v643_7_label) {
        const Space v643_7_tail = child(v641_12_tail,v643_7_label);
        if (v643_7_tail.empty()) continue;
        const Path v643_7_head{v643_7_label};
        const Space v644_2 = singleton(v643_7_head);
        const Space v644_3 = intersect(constant_5,v644_2);
        const Space v644_4 = (has_head(v644_3) ? constant_7 : Space{});
        const Space v644_5 = subtract(constant_0,v644_4);
        Space v644_8;
        if (!v644_5.empty()) {
          const Path v645_6 = concat_path(v643_6,v643_7_head);
          const Space v645_7 = routine_116(c, v645_6, v643_7_tail, s1);
          v644_8 = compose(v644_5,v645_7);
        }
        const Space v644_9 = intersect(constant_5,v644_2);
        const Space v644_10 = (has_head(v644_9) ? constant_7 : Space{});
        Space v644_12;
        if (!v644_10.empty()) {
          const Path v646_6 = concat_path(v643_6,v643_7_head);
          const Space v646_11 = routine_117(c, v646_6, v643_7_tail, s1);
          v644_12 = compose(v644_10,v646_11);
        }
        const Space v644_13 = unite(v644_8,v644_12);
        v643_7_result = unite(v643_7_result,v644_13);
      }
      const Space v643_7 = std::move(v643_7_result);
      v642_8 = compose(v642_5,v643_7);
    }
    const Space v642_9 = intersect(constant_5,v642_2);
    const Space v642_10 = (has_head(v642_9) ? constant_7 : Space{});
    Space v642_12;
    if (!v642_10.empty()) {
      const Path v647_6 = concat_path(p0,v641_12_head);
      Space v647_11_result;
      for (int v647_11_label = 1; v647_11_label <= 2; ++v647_11_label) {
        const Space v647_11_tail = child(v641_12_tail,v647_11_label);
        if (v647_11_tail.empty()) continue;
        const Path v647_11_head{v647_11_label};
        const Space v648_2 = singleton(v647_11_head);
        const Space v648_3 = intersect(constant_5,v648_2);
        const Space v648_4 = (has_head(v648_3) ? constant_7 : Space{});
        const Space v648_5 = subtract(constant_0,v648_4);
        Space v648_8;
        if (!v648_5.empty()) {
          const Path v649_6 = concat_path(v647_6,v647_11_head);
          const Space v649_7 = routine_116(c, v649_6, v647_11_tail, s1);
          v648_8 = compose(v648_5,v649_7);
        }
        const Space v648_9 = intersect(constant_5,v648_2);
        const Space v648_10 = (has_head(v648_9) ? constant_7 : Space{});
        Space v648_12;
        if (!v648_10.empty()) {
          const Path v650_6 = concat_path(v647_6,v647_11_head);
          const Space v650_11 = routine_14(c, v650_6, v647_11_tail, s1);
          v648_12 = compose(v648_10,v650_11);
        }
        const Space v648_13 = unite(v648_8,v648_12);
        v647_11_result = unite(v647_11_result,v648_13);
      }
      const Space v647_11 = std::move(v647_11_result);
      v642_12 = compose(v642_10,v647_11);
    }
    const Space v642_13 = unite(v642_8,v642_12);
    v641_12_result = unite(v641_12_result,v642_13);
  }
  const Space v641_12 = std::move(v641_12_result);
  return v641_12;
}

static Space routine_65(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v651_12_result;
  for (int v651_12_label = 1; v651_12_label <= 2; ++v651_12_label) {
    const Space v651_12_tail = child(s0,v651_12_label);
    if (v651_12_tail.empty()) continue;
    const Path v651_12_head{v651_12_label};
    const Space v652_2 = singleton(v651_12_head);
    const Space v652_3 = intersect(constant_5,v652_2);
    const Space v652_4 = (has_head(v652_3) ? constant_7 : Space{});
    const Space v652_5 = subtract(constant_0,v652_4);
    Space v652_8;
    if (!v652_5.empty()) {
      const Path v653_6 = concat_path(p0,v651_12_head);
      Space v653_7_result;
      for (int v653_7_label = 1; v653_7_label <= 2; ++v653_7_label) {
        const Space v653_7_tail = child(v651_12_tail,v653_7_label);
        if (v653_7_tail.empty()) continue;
        const Path v653_7_head{v653_7_label};
        const Space v654_2 = singleton(v653_7_head);
        const Space v654_3 = intersect(constant_5,v654_2);
        const Space v654_4 = (has_head(v654_3) ? constant_7 : Space{});
        const Space v654_5 = subtract(constant_0,v654_4);
        Space v654_8;
        if (!v654_5.empty()) {
          const Path v655_6 = concat_path(v653_6,v653_7_head);
          const Space v655_7 = routine_116(c, v655_6, v653_7_tail, s1);
          v654_8 = compose(v654_5,v655_7);
        }
        const Space v654_9 = intersect(constant_5,v654_2);
        const Space v654_10 = (has_head(v654_9) ? constant_7 : Space{});
        Space v654_12;
        if (!v654_10.empty()) {
          const Path v656_6 = concat_path(v653_6,v653_7_head);
          const Space v656_11 = routine_117(c, v656_6, v653_7_tail, s1);
          v654_12 = compose(v654_10,v656_11);
        }
        const Space v654_13 = unite(v654_8,v654_12);
        v653_7_result = unite(v653_7_result,v654_13);
      }
      const Space v653_7 = std::move(v653_7_result);
      v652_8 = compose(v652_5,v653_7);
    }
    const Space v652_9 = intersect(constant_5,v652_2);
    const Space v652_10 = (has_head(v652_9) ? constant_7 : Space{});
    Space v652_12;
    if (!v652_10.empty()) {
      const Path v657_6 = concat_path(p0,v651_12_head);
      Space v657_11_result;
      for (int v657_11_label = 1; v657_11_label <= 2; ++v657_11_label) {
        const Space v657_11_tail = child(v651_12_tail,v657_11_label);
        if (v657_11_tail.empty()) continue;
        const Path v657_11_head{v657_11_label};
        const Space v658_2 = singleton(v657_11_head);
        const Space v658_3 = intersect(constant_5,v658_2);
        const Space v658_4 = (has_head(v658_3) ? constant_7 : Space{});
        const Space v658_5 = subtract(constant_0,v658_4);
        Space v658_7;
        if (!v658_5.empty()) {
          const Space v659_6 = routine_15(c, v657_11_head, v657_6, v657_11_tail, s1);
          v658_7 = compose(v658_5,v659_6);
        }
        const Space v658_8 = intersect(constant_5,v658_2);
        const Space v658_9 = (has_head(v658_8) ? constant_7 : Space{});
        Space v658_11;
        if (!v658_9.empty()) {
          const Space v660_10 = routine_16(c, v657_11_head, v657_6, v657_11_tail, s1);
          v658_11 = compose(v658_9,v660_10);
        }
        const Space v658_12 = unite(v658_7,v658_11);
        v657_11_result = unite(v657_11_result,v658_12);
      }
      const Space v657_11 = std::move(v657_11_result);
      v652_12 = compose(v652_10,v657_11);
    }
    const Space v652_13 = unite(v652_8,v652_12);
    v651_12_result = unite(v651_12_result,v652_13);
  }
  const Space v651_12 = std::move(v651_12_result);
  return v651_12;
}

static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v661_13_result;
  for (int v661_13_label = 1; v661_13_label <= 2; ++v661_13_label) {
    const Space v661_13_tail = child(s0,v661_13_label);
    if (v661_13_tail.empty()) continue;
    const Path v661_13_head{v661_13_label};
    const Space v662_2 = singleton(v661_13_head);
    const Space v662_3 = intersect(constant_5,v662_2);
    const Space v662_4 = (has_head(v662_3) ? constant_7 : Space{});
    const Space v662_5 = subtract(constant_0,v662_4);
    Space v662_8;
    if (!v662_5.empty()) {
      const Path v663_6 = concat_path(p0,v661_13_head);
      Space v663_7_result;
      for (int v663_7_label = 1; v663_7_label <= 2; ++v663_7_label) {
        const Space v663_7_tail = child(v661_13_tail,v663_7_label);
        if (v663_7_tail.empty()) continue;
        const Path v663_7_head{v663_7_label};
        const Space v664_2 = singleton(v663_7_head);
        const Space v664_3 = intersect(constant_5,v664_2);
        const Space v664_4 = (has_head(v664_3) ? constant_7 : Space{});
        const Space v664_5 = subtract(constant_0,v664_4);
        Space v664_8;
        if (!v664_5.empty()) {
          const Path v665_6 = concat_path(v663_6,v663_7_head);
          const Space v665_7 = routine_118(c, v665_6, p1, v663_7_tail, s1);
          v664_8 = compose(v664_5,v665_7);
        }
        const Space v664_9 = intersect(constant_5,v664_2);
        const Space v664_10 = (has_head(v664_9) ? constant_7 : Space{});
        Space v664_12;
        if (!v664_10.empty()) {
          const Path v666_6 = concat_path(v663_6,v663_7_head);
          const Space v666_11 = routine_119(c, v666_6, p1, v663_7_tail, s1);
          v664_12 = compose(v664_10,v666_11);
        }
        const Space v664_13 = unite(v664_8,v664_12);
        v663_7_result = unite(v663_7_result,v664_13);
      }
      const Space v663_7 = std::move(v663_7_result);
      v662_8 = compose(v662_5,v663_7);
    }
    const Space v662_9 = intersect(constant_5,v662_2);
    const Space v662_10 = (has_head(v662_9) ? constant_7 : Space{});
    Space v662_12;
    if (!v662_10.empty()) {
      const Path v667_6 = concat_path(p0,v661_13_head);
      Space v667_11_result;
      for (int v667_11_label = 1; v667_11_label <= 2; ++v667_11_label) {
        const Space v667_11_tail = child(v661_13_tail,v667_11_label);
        if (v667_11_tail.empty()) continue;
        const Path v667_11_head{v667_11_label};
        const Space v668_2 = singleton(v667_11_head);
        const Space v668_3 = intersect(constant_5,v668_2);
        const Space v668_4 = (has_head(v668_3) ? constant_7 : Space{});
        const Space v668_5 = subtract(constant_0,v668_4);
        Space v668_8;
        if (!v668_5.empty()) {
          const Path v669_6 = concat_path(v667_6,v667_11_head);
          const Space v669_7 = routine_118(c, v669_6, p1, v667_11_tail, s1);
          v668_8 = compose(v668_5,v669_7);
        }
        const Space v668_9 = intersect(constant_5,v668_2);
        const Space v668_10 = (has_head(v668_9) ? constant_7 : Space{});
        Space v668_12;
        if (!v668_10.empty()) {
          const Path v670_6 = concat_path(v667_6,v667_11_head);
          const Space v670_11 = routine_33(c, v670_6, p1, v667_11_tail, s1);
          v668_12 = compose(v668_10,v670_11);
        }
        const Space v668_13 = unite(v668_8,v668_12);
        v667_11_result = unite(v667_11_result,v668_13);
      }
      const Space v667_11 = std::move(v667_11_result);
      v662_12 = compose(v662_10,v667_11);
    }
    const Space v662_13 = unite(v662_8,v662_12);
    v661_13_result = unite(v661_13_result,v662_13);
  }
  const Space v661_13 = std::move(v661_13_result);
  return v661_13;
}

static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v671_8 = unwrap(constant_9,p1);
  const Space v671_10 = unwrap(constant_9,p0);
  const Space v671_12 = unwrap(s1,constant_8);
  const Space v671_14 = unwrap(constant_9,p1);
  const Space v671_16 = unwrap(constant_9,p0);
  Space v671_29_result;
  for (int v671_29_label = 1; v671_29_label <= 2; ++v671_29_label) {
    const Space v671_29_tail = child(s0,v671_29_label);
    if (v671_29_tail.empty()) continue;
    const Path v671_29_head{v671_29_label};
    const Space v672_2 = singleton(v671_29_head);
    const Space v672_3 = intersect(constant_5,v672_2);
    const Space v672_4 = (has_head(v672_3) ? constant_7 : Space{});
    const Space v672_5 = subtract(constant_0,v672_4);
    Space v672_8;
    if (!v672_5.empty()) {
      const Path v673_6 = concat_path(p0,v671_29_head);
      Space v673_7_result;
      for (int v673_7_label = 1; v673_7_label <= 2; ++v673_7_label) {
        const Space v673_7_tail = child(v671_29_tail,v673_7_label);
        if (v673_7_tail.empty()) continue;
        const Path v673_7_head{v673_7_label};
        const Space v674_2 = singleton(v673_7_head);
        const Space v674_3 = intersect(constant_5,v674_2);
        const Space v674_4 = (has_head(v674_3) ? constant_7 : Space{});
        const Space v674_5 = subtract(constant_0,v674_4);
        Space v674_8;
        if (!v674_5.empty()) {
          const Path v675_6 = concat_path(v673_6,v673_7_head);
          const Space v675_7 = routine_118(c, v675_6, p1, v673_7_tail, s1);
          v674_8 = compose(v674_5,v675_7);
        }
        const Space v674_9 = intersect(constant_5,v674_2);
        const Space v674_10 = (has_head(v674_9) ? constant_7 : Space{});
        Space v674_12;
        if (!v674_10.empty()) {
          const Path v676_6 = concat_path(v673_6,v673_7_head);
          const Space v676_11 = routine_119(c, v676_6, p1, v673_7_tail, s1);
          v674_12 = compose(v674_10,v676_11);
        }
        const Space v674_13 = unite(v674_8,v674_12);
        v673_7_result = unite(v673_7_result,v674_13);
      }
      const Space v673_7 = std::move(v673_7_result);
      v672_8 = compose(v672_5,v673_7);
    }
    const Space v672_9 = intersect(constant_5,v672_2);
    const Space v672_10 = (has_head(v672_9) ? constant_7 : Space{});
    Space v672_28;
    if (!v672_10.empty()) {
      const Path v677_6 = concat_path(p0,v671_29_head);
      const Space v677_11 = unwrap(v671_10,v671_29_head);
      const Space v677_12 = compose(v671_8,v677_11);
      const Path v677_13 = concat_path(p1,v677_6);
      const Space v677_14 = singleton(v677_13);
      const Space v677_15 = subtract(v677_12,v677_14);
      const Space v677_16 = intersect(v677_15,v671_12);
      const Space v677_17 = routine_36(c, v677_16);
      Space v677_18_result;
      for (int v677_18_label = 1; v677_18_label <= 2; ++v677_18_label) {
        const Space v677_18_tail = child(v677_17,v677_18_label);
        if (v677_18_tail.empty()) continue;
        const Path v677_18_head{v677_18_label};
        const Space v678_2 = singleton(v677_18_head);
        const Space v678_3 = intersect(constant_5,v678_2);
        const Space v678_4 = (has_head(v678_3) ? constant_7 : Space{});
        const Space v678_5 = subtract(constant_0,v678_4);
        Space v678_7;
        if (!v678_5.empty()) {
          const Space v679_6 = routine_37(c, v677_18_head, v677_18_tail);
          v678_7 = compose(v678_5,v679_6);
        }
        const Space v678_8 = intersect(constant_5,v678_2);
        const Space v678_9 = (has_head(v678_8) ? constant_7 : Space{});
        Space v678_11;
        if (!v678_9.empty()) {
          const Space v680_10 = routine_38(c, v677_18_head, v677_18_tail);
          v678_11 = compose(v678_9,v680_10);
        }
        const Space v678_12 = unite(v678_7,v678_11);
        v677_18_result = unite(v677_18_result,v678_12);
      }
      const Space v677_18 = std::move(v677_18_result);
      const Space v677_19 = unwrap(v671_16,v671_29_head);
      const Space v677_20 = compose(v671_14,v677_19);
      const Space v677_21 = subtract(v677_20,v677_14);
      const Space v677_22 = intersect(v677_21,v671_12);
      const Space v677_23 = routine_39(c, v677_22);
      Space v677_24_result;
      for (int v677_24_label = 1; v677_24_label <= 2; ++v677_24_label) {
        const Space v677_24_tail = child(v677_23,v677_24_label);
        if (v677_24_tail.empty()) continue;
        const Path v677_24_head{v677_24_label};
        const Space v681_2 = singleton(v677_24_head);
        const Space v681_3 = intersect(constant_5,v681_2);
        const Space v681_4 = (has_head(v681_3) ? constant_7 : Space{});
        const Space v681_5 = subtract(constant_0,v681_4);
        Space v681_7;
        if (!v681_5.empty()) {
          const Space v682_6 = routine_40(c, v677_24_head, v677_24_tail);
          v681_7 = compose(v681_5,v682_6);
        }
        const Space v681_8 = intersect(constant_5,v681_2);
        const Space v681_9 = (has_head(v681_8) ? constant_7 : Space{});
        Space v681_11;
        if (!v681_9.empty()) {
          const Space v683_10 = routine_41(c, v677_24_head, v677_24_tail);
          v681_11 = compose(v681_9,v683_10);
        }
        const Space v681_12 = unite(v681_7,v681_11);
        v677_24_result = unite(v677_24_result,v681_12);
      }
      const Space v677_24 = std::move(v677_24_result);
      const Space v677_25 = subtract(v677_18,v677_24);
      const Space v677_26 = compose(v677_25,v677_14);
      Space v677_27_result;
      for (int v677_27_label = 1; v677_27_label <= 2; ++v677_27_label) {
        const Space v677_27_tail = child(v677_26,v677_27_label);
        if (v677_27_tail.empty()) continue;
        const Path v677_27_head{v677_27_label};
        const Space v684_2 = singleton(v677_27_head);
        const Space v684_3 = intersect(constant_5,v684_2);
        const Space v684_4 = (has_head(v684_3) ? constant_7 : Space{});
        const Space v684_5 = subtract(constant_0,v684_4);
        Space v684_7;
        if (!v684_5.empty()) {
          const Space v685_6 = routine_42(c, v677_27_head, v677_27_tail);
          v684_7 = compose(v684_5,v685_6);
        }
        const Space v684_8 = intersect(constant_5,v684_2);
        const Space v684_9 = (has_head(v684_8) ? constant_7 : Space{});
        Space v684_11;
        if (!v684_9.empty()) {
          const Space v686_10 = routine_43(c, v677_27_head, v677_27_tail);
          v684_11 = compose(v684_9,v686_10);
        }
        const Space v684_12 = unite(v684_7,v684_11);
        v677_27_result = unite(v677_27_result,v684_12);
      }
      const Space v677_27 = std::move(v677_27_result);
      v672_28 = compose(v672_10,v677_27);
    }
    const Space v672_29 = unite(v672_8,v672_28);
    v671_29_result = unite(v671_29_result,v672_29);
  }
  const Space v671_29 = std::move(v671_29_result);
  return v671_29;
}

static Space routine_68(Context& c, const Space& s0) {
  const Space v687_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v687_2 = first_matching(s0,constant_0,false);
  const Space v687_3 = unite(v687_1,v687_2);
  Space v687_19;
  if (!v687_3.empty()) {
    const Space v688_5 = intersect(constant_0,v687_2);
    const Space v688_6 = (has_head(v687_2) ? constant_7 : Space{});
    const Space v688_7 = unite(v688_5,v688_6);
    const Space v688_9 = compose(v688_7,constant_0);
    const Space v688_10 = subtract(s0,v688_9);
    const Space v688_12 = subtract(constant_0,v687_2);
    const Space v688_13 = subtract(v688_12,v688_6);
    Space v688_17;
    if (!v688_13.empty()) {
      const Space v689_15 = first_listed(s0,constant_12,true);
      const Space v689_16 = routine_120(c, constant_11, v689_15, s0);
      v688_17 = compose(v688_13,v689_16);
    }
    const Space v688_18 = subtract(v688_10,v688_17);
    v687_19 = compose(v687_3,v688_18);
  }
  return v687_19;
}

static Space routine_69(Context& c, const Space& s0) {
  const Space v690_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v690_2 = first_matching(s0,constant_0,false);
  const Space v690_3 = unite(v690_1,v690_2);
  Space v690_13;
  if (!v690_3.empty()) {
    Space v691_6;
    if (!v690_3.empty()) {
      const Space v692_4 = routine_82(c, s0);
      const Space v692_5 = subtract(s0,v692_4);
      v691_6 = compose(v690_3,v692_5);
    }
    const Space v691_7 = (has_head(v691_6) ? constant_7 : Space{});
    const Space v691_8 = first_matching(v691_6,constant_0,false);
    const Space v691_9 = unite(v691_7,v691_8);
    Space v691_12;
    if (!v691_9.empty()) {
      const Space v693_10 = routine_82(c, v691_6);
      const Space v693_11 = subtract(v691_6,v693_10);
      v691_12 = compose(v691_9,v693_11);
    }
    v690_13 = compose(v690_3,v691_12);
  }
  return v690_13;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v694_11_result;
  for (int v694_11_label = 1; v694_11_label <= 2; ++v694_11_label) {
    const Space v694_11_tail = child(s0,v694_11_label);
    if (v694_11_tail.empty()) continue;
    const Path v694_11_head{v694_11_label};
    const Space v695_2 = singleton(v694_11_head);
    const Space v695_3 = intersect(constant_5,v695_2);
    const Space v695_4 = (has_head(v695_3) ? constant_7 : Space{});
    const Space v695_5 = subtract(constant_0,v695_4);
    Space v695_8;
    if (!v695_5.empty()) {
      const Path v696_6 = concat_path(p0,v694_11_head);
      Space v696_7_result;
      for (int v696_7_label = 1; v696_7_label <= 2; ++v696_7_label) {
        const Space v696_7_tail = child(v694_11_tail,v696_7_label);
        if (v696_7_tail.empty()) continue;
        const Path v696_7_head{v696_7_label};
        const Space v697_2 = singleton(v696_7_head);
        const Space v697_3 = intersect(constant_5,v697_2);
        const Space v697_4 = (has_head(v697_3) ? constant_7 : Space{});
        const Space v697_5 = subtract(constant_0,v697_4);
        Space v697_8;
        if (!v697_5.empty()) {
          const Path v698_6 = concat_path(v696_6,v696_7_head);
          const Space v698_7 = routine_121(c, v698_6, v696_7_tail);
          v697_8 = compose(v697_5,v698_7);
        }
        const Space v697_9 = intersect(constant_5,v697_2);
        const Space v697_10 = (has_head(v697_9) ? constant_7 : Space{});
        Space v697_12;
        if (!v697_10.empty()) {
          const Path v699_6 = concat_path(v696_6,v696_7_head);
          const Space v699_11 = routine_122(c, v699_6, v696_7_tail);
          v697_12 = compose(v697_10,v699_11);
        }
        const Space v697_13 = unite(v697_8,v697_12);
        v696_7_result = unite(v696_7_result,v697_13);
      }
      const Space v696_7 = std::move(v696_7_result);
      v695_8 = compose(v695_5,v696_7);
    }
    const Space v695_9 = intersect(constant_5,v695_2);
    const Space v695_10 = (has_head(v695_9) ? constant_7 : Space{});
    Space v695_12;
    if (!v695_10.empty()) {
      const Path v700_6 = concat_path(p0,v694_11_head);
      Space v700_11_result;
      for (int v700_11_label = 1; v700_11_label <= 2; ++v700_11_label) {
        const Space v700_11_tail = child(v694_11_tail,v700_11_label);
        if (v700_11_tail.empty()) continue;
        const Path v700_11_head{v700_11_label};
        const Space v701_2 = singleton(v700_11_head);
        const Space v701_3 = intersect(constant_5,v701_2);
        const Space v701_4 = (has_head(v701_3) ? constant_7 : Space{});
        const Space v701_5 = subtract(constant_0,v701_4);
        Space v701_8;
        if (!v701_5.empty()) {
          const Path v702_6 = concat_path(v700_6,v700_11_head);
          const Space v702_7 = routine_121(c, v702_6, v700_11_tail);
          v701_8 = compose(v701_5,v702_7);
        }
        const Space v701_9 = intersect(constant_5,v701_2);
        const Space v701_10 = (has_head(v701_9) ? constant_7 : Space{});
        Space v701_12;
        if (!v701_10.empty()) {
          const Path v703_6 = concat_path(v700_6,v700_11_head);
          const Space v703_11 = routine_72(c, v703_6, v700_11_tail);
          v701_12 = compose(v701_10,v703_11);
        }
        const Space v701_13 = unite(v701_8,v701_12);
        v700_11_result = unite(v700_11_result,v701_13);
      }
      const Space v700_11 = std::move(v700_11_result);
      v695_12 = compose(v695_10,v700_11);
    }
    const Space v695_13 = unite(v695_8,v695_12);
    v694_11_result = unite(v694_11_result,v695_13);
  }
  const Space v694_11 = std::move(v694_11_result);
  return v694_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v704_9_result;
  for (int v704_9_label = 1; v704_9_label <= 2; ++v704_9_label) {
    const Space v704_9_tail = child(s0,v704_9_label);
    if (v704_9_tail.empty()) continue;
    const Path v704_9_head{v704_9_label};
    const Space v705_2 = singleton(v704_9_head);
    const Space v705_3 = intersect(constant_5,v705_2);
    const Space v705_4 = (has_head(v705_3) ? constant_7 : Space{});
    const Space v705_5 = subtract(constant_0,v705_4);
    Space v705_8;
    if (!v705_5.empty()) {
      const Path v706_6 = concat_path(p0,v704_9_head);
      Space v706_7_result;
      for (int v706_7_label = 1; v706_7_label <= 2; ++v706_7_label) {
        const Space v706_7_tail = child(v704_9_tail,v706_7_label);
        if (v706_7_tail.empty()) continue;
        const Path v706_7_head{v706_7_label};
        const Space v707_2 = singleton(v706_7_head);
        const Space v707_3 = intersect(constant_5,v707_2);
        const Space v707_4 = (has_head(v707_3) ? constant_7 : Space{});
        const Space v707_5 = subtract(constant_0,v707_4);
        Space v707_8;
        if (!v707_5.empty()) {
          const Path v708_6 = concat_path(v706_6,v706_7_head);
          const Space v708_7 = routine_121(c, v708_6, v706_7_tail);
          v707_8 = compose(v707_5,v708_7);
        }
        const Space v707_9 = intersect(constant_5,v707_2);
        const Space v707_10 = (has_head(v707_9) ? constant_7 : Space{});
        Space v707_12;
        if (!v707_10.empty()) {
          const Path v709_6 = concat_path(v706_6,v706_7_head);
          const Space v709_11 = routine_122(c, v709_6, v706_7_tail);
          v707_12 = compose(v707_10,v709_11);
        }
        const Space v707_13 = unite(v707_8,v707_12);
        v706_7_result = unite(v706_7_result,v707_13);
      }
      const Space v706_7 = std::move(v706_7_result);
      v705_8 = compose(v705_5,v706_7);
    }
    const Space v705_9 = intersect(constant_5,v705_2);
    const Space v705_10 = (has_head(v705_9) ? constant_7 : Space{});
    const Space v705_11 = compose(v705_10,constant_10);
    const Space v705_12 = unite(v705_8,v705_11);
    v704_9_result = unite(v704_9_result,v705_12);
  }
  const Space v704_9 = std::move(v704_9_result);
  return v704_9;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  return constant_10;
}

static Space routine_73(Context& c, const Space& s0) {
  const Space v711_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v711_2 = first_matching(s0,constant_0,false);
  const Space v711_3 = unite(v711_1,v711_2);
  Space v711_13;
  if (!v711_3.empty()) {
    Space v712_6;
    if (!v711_3.empty()) {
      const Space v713_4 = routine_68(c, s0);
      const Space v713_5 = routine_68(c, v713_4);
      v712_6 = compose(v711_3,v713_5);
    }
    const Space v712_7 = (has_head(v712_6) ? constant_7 : Space{});
    const Space v712_8 = first_matching(v712_6,constant_0,false);
    const Space v712_9 = unite(v712_7,v712_8);
    Space v712_12;
    if (!v712_9.empty()) {
      const Space v714_10 = routine_68(c, v712_6);
      const Space v714_11 = routine_68(c, v714_10);
      v712_12 = compose(v712_9,v714_11);
    }
    v711_13 = compose(v711_3,v712_12);
  }
  return v711_13;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  Space v715_11_result;
  for (int v715_11_label = 1; v715_11_label <= 2; ++v715_11_label) {
    const Space v715_11_tail = child(s0,v715_11_label);
    if (v715_11_tail.empty()) continue;
    const Path v715_11_head{v715_11_label};
    const Space v716_2 = singleton(v715_11_head);
    const Space v716_3 = intersect(constant_5,v716_2);
    const Space v716_4 = (has_head(v716_3) ? constant_7 : Space{});
    const Space v716_5 = subtract(constant_0,v716_4);
    Space v716_8;
    if (!v716_5.empty()) {
      const Path v717_6 = concat_path(p0,v715_11_head);
      Space v717_7_result;
      for (int v717_7_label = 1; v717_7_label <= 2; ++v717_7_label) {
        const Space v717_7_tail = child(v715_11_tail,v717_7_label);
        if (v717_7_tail.empty()) continue;
        const Path v717_7_head{v717_7_label};
        const Space v718_2 = singleton(v717_7_head);
        const Space v718_3 = intersect(constant_5,v718_2);
        const Space v718_4 = (has_head(v718_3) ? constant_7 : Space{});
        const Space v718_5 = subtract(constant_0,v718_4);
        Space v718_8;
        if (!v718_5.empty()) {
          const Path v719_6 = concat_path(v717_6,v717_7_head);
          const Space v719_7 = routine_123(c, v719_6, v717_7_tail);
          v718_8 = compose(v718_5,v719_7);
        }
        const Space v718_9 = intersect(constant_5,v718_2);
        const Space v718_10 = (has_head(v718_9) ? constant_7 : Space{});
        Space v718_12;
        if (!v718_10.empty()) {
          const Path v720_6 = concat_path(v717_6,v717_7_head);
          const Space v720_11 = routine_124(c, v720_6, v717_7_tail);
          v718_12 = compose(v718_10,v720_11);
        }
        const Space v718_13 = unite(v718_8,v718_12);
        v717_7_result = unite(v717_7_result,v718_13);
      }
      const Space v717_7 = std::move(v717_7_result);
      v716_8 = compose(v716_5,v717_7);
    }
    const Space v716_9 = intersect(constant_5,v716_2);
    const Space v716_10 = (has_head(v716_9) ? constant_7 : Space{});
    Space v716_12;
    if (!v716_10.empty()) {
      const Path v721_6 = concat_path(p0,v715_11_head);
      Space v721_11_result;
      for (int v721_11_label = 1; v721_11_label <= 2; ++v721_11_label) {
        const Space v721_11_tail = child(v715_11_tail,v721_11_label);
        if (v721_11_tail.empty()) continue;
        const Path v721_11_head{v721_11_label};
        const Space v722_2 = singleton(v721_11_head);
        const Space v722_3 = intersect(constant_5,v722_2);
        const Space v722_4 = (has_head(v722_3) ? constant_7 : Space{});
        const Space v722_5 = subtract(constant_0,v722_4);
        Space v722_8;
        if (!v722_5.empty()) {
          const Path v723_6 = concat_path(v721_6,v721_11_head);
          const Space v723_7 = routine_123(c, v723_6, v721_11_tail);
          v722_8 = compose(v722_5,v723_7);
        }
        const Space v722_9 = intersect(constant_5,v722_2);
        const Space v722_10 = (has_head(v722_9) ? constant_7 : Space{});
        Space v722_12;
        if (!v722_10.empty()) {
          const Path v724_6 = concat_path(v721_6,v721_11_head);
          const Space v724_11 = routine_76(c, v724_6, v721_11_tail);
          v722_12 = compose(v722_10,v724_11);
        }
        const Space v722_13 = unite(v722_8,v722_12);
        v721_11_result = unite(v721_11_result,v722_13);
      }
      const Space v721_11 = std::move(v721_11_result);
      v716_12 = compose(v716_10,v721_11);
    }
    const Space v716_13 = unite(v716_8,v716_12);
    v715_11_result = unite(v715_11_result,v716_13);
  }
  const Space v715_11 = std::move(v715_11_result);
  return v715_11;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  Space v725_9_result;
  for (int v725_9_label = 1; v725_9_label <= 2; ++v725_9_label) {
    const Space v725_9_tail = child(s0,v725_9_label);
    if (v725_9_tail.empty()) continue;
    const Path v725_9_head{v725_9_label};
    const Space v726_2 = singleton(v725_9_head);
    const Space v726_3 = intersect(constant_5,v726_2);
    const Space v726_4 = (has_head(v726_3) ? constant_7 : Space{});
    const Space v726_5 = subtract(constant_0,v726_4);
    Space v726_8;
    if (!v726_5.empty()) {
      const Path v727_6 = concat_path(p0,v725_9_head);
      Space v727_7_result;
      for (int v727_7_label = 1; v727_7_label <= 2; ++v727_7_label) {
        const Space v727_7_tail = child(v725_9_tail,v727_7_label);
        if (v727_7_tail.empty()) continue;
        const Path v727_7_head{v727_7_label};
        const Space v728_2 = singleton(v727_7_head);
        const Space v728_3 = intersect(constant_5,v728_2);
        const Space v728_4 = (has_head(v728_3) ? constant_7 : Space{});
        const Space v728_5 = subtract(constant_0,v728_4);
        Space v728_8;
        if (!v728_5.empty()) {
          const Path v729_6 = concat_path(v727_6,v727_7_head);
          const Space v729_7 = routine_123(c, v729_6, v727_7_tail);
          v728_8 = compose(v728_5,v729_7);
        }
        const Space v728_9 = intersect(constant_5,v728_2);
        const Space v728_10 = (has_head(v728_9) ? constant_7 : Space{});
        Space v728_12;
        if (!v728_10.empty()) {
          const Path v730_6 = concat_path(v727_6,v727_7_head);
          const Space v730_11 = routine_124(c, v730_6, v727_7_tail);
          v728_12 = compose(v728_10,v730_11);
        }
        const Space v728_13 = unite(v728_8,v728_12);
        v727_7_result = unite(v727_7_result,v728_13);
      }
      const Space v727_7 = std::move(v727_7_result);
      v726_8 = compose(v726_5,v727_7);
    }
    const Space v726_9 = intersect(constant_5,v726_2);
    const Space v726_10 = (has_head(v726_9) ? constant_7 : Space{});
    const Space v726_11 = compose(v726_10,constant_10);
    const Space v726_12 = unite(v726_8,v726_11);
    v725_9_result = unite(v725_9_result,v726_12);
  }
  const Space v725_9 = std::move(v725_9_result);
  return v725_9;
}

static Space routine_76(Context& c, const Path& p0, const Space& s0) {
  return constant_10;
}

static Space routine_77(Context& c, const Path& p0, const Space& s0) {
  Space v732_11_result;
  for (int v732_11_label = 1; v732_11_label <= 2; ++v732_11_label) {
    const Space v732_11_tail = child(s0,v732_11_label);
    if (v732_11_tail.empty()) continue;
    const Path v732_11_head{v732_11_label};
    const Space v733_2 = singleton(v732_11_head);
    const Space v733_3 = intersect(constant_5,v733_2);
    const Space v733_4 = (has_head(v733_3) ? constant_7 : Space{});
    const Space v733_5 = subtract(constant_0,v733_4);
    Space v733_8;
    if (!v733_5.empty()) {
      const Path v734_6 = concat_path(p0,v732_11_head);
      Space v734_7_result;
      for (int v734_7_label = 1; v734_7_label <= 2; ++v734_7_label) {
        const Space v734_7_tail = child(v732_11_tail,v734_7_label);
        if (v734_7_tail.empty()) continue;
        const Path v734_7_head{v734_7_label};
        const Space v735_2 = singleton(v734_7_head);
        const Space v735_3 = intersect(constant_5,v735_2);
        const Space v735_4 = (has_head(v735_3) ? constant_7 : Space{});
        const Space v735_5 = subtract(constant_0,v735_4);
        Space v735_8;
        if (!v735_5.empty()) {
          const Path v736_6 = concat_path(v734_6,v734_7_head);
          const Space v736_7 = routine_125(c, v736_6, v734_7_tail);
          v735_8 = compose(v735_5,v736_7);
        }
        const Space v735_9 = intersect(constant_5,v735_2);
        const Space v735_10 = (has_head(v735_9) ? constant_7 : Space{});
        Space v735_12;
        if (!v735_10.empty()) {
          const Path v737_6 = concat_path(v734_6,v734_7_head);
          const Space v737_11 = routine_126(c, v737_6, v734_7_tail);
          v735_12 = compose(v735_10,v737_11);
        }
        const Space v735_13 = unite(v735_8,v735_12);
        v734_7_result = unite(v734_7_result,v735_13);
      }
      const Space v734_7 = std::move(v734_7_result);
      v733_8 = compose(v733_5,v734_7);
    }
    const Space v733_9 = intersect(constant_5,v733_2);
    const Space v733_10 = (has_head(v733_9) ? constant_7 : Space{});
    Space v733_12;
    if (!v733_10.empty()) {
      const Path v738_6 = concat_path(p0,v732_11_head);
      Space v738_11_result;
      for (int v738_11_label = 1; v738_11_label <= 2; ++v738_11_label) {
        const Space v738_11_tail = child(v732_11_tail,v738_11_label);
        if (v738_11_tail.empty()) continue;
        const Path v738_11_head{v738_11_label};
        const Space v739_2 = singleton(v738_11_head);
        const Space v739_3 = intersect(constant_5,v739_2);
        const Space v739_4 = (has_head(v739_3) ? constant_7 : Space{});
        const Space v739_5 = subtract(constant_0,v739_4);
        Space v739_8;
        if (!v739_5.empty()) {
          const Path v740_6 = concat_path(v738_6,v738_11_head);
          const Space v740_7 = routine_125(c, v740_6, v738_11_tail);
          v739_8 = compose(v739_5,v740_7);
        }
        const Space v739_9 = intersect(constant_5,v739_2);
        const Space v739_10 = (has_head(v739_9) ? constant_7 : Space{});
        Space v739_12;
        if (!v739_10.empty()) {
          const Path v741_6 = concat_path(v738_6,v738_11_head);
          const Space v741_11 = routine_79(c, v741_6, v738_11_tail);
          v739_12 = compose(v739_10,v741_11);
        }
        const Space v739_13 = unite(v739_8,v739_12);
        v738_11_result = unite(v738_11_result,v739_13);
      }
      const Space v738_11 = std::move(v738_11_result);
      v733_12 = compose(v733_10,v738_11);
    }
    const Space v733_13 = unite(v733_8,v733_12);
    v732_11_result = unite(v732_11_result,v733_13);
  }
  const Space v732_11 = std::move(v732_11_result);
  return v732_11;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v742_8_result;
  for (int v742_8_label = 1; v742_8_label <= 2; ++v742_8_label) {
    const Space v742_8_tail = child(s0,v742_8_label);
    if (v742_8_tail.empty()) continue;
    const Path v742_8_head{v742_8_label};
    const Space v743_2 = singleton(v742_8_head);
    const Space v743_3 = intersect(constant_5,v743_2);
    const Space v743_4 = (has_head(v743_3) ? constant_7 : Space{});
    const Space v743_5 = subtract(constant_0,v743_4);
    Space v743_8;
    if (!v743_5.empty()) {
      const Path v744_6 = concat_path(p0,v742_8_head);
      Space v744_7_result;
      for (int v744_7_label = 1; v744_7_label <= 2; ++v744_7_label) {
        const Space v744_7_tail = child(v742_8_tail,v744_7_label);
        if (v744_7_tail.empty()) continue;
        const Path v744_7_head{v744_7_label};
        const Space v745_2 = singleton(v744_7_head);
        const Space v745_3 = intersect(constant_5,v745_2);
        const Space v745_4 = (has_head(v745_3) ? constant_7 : Space{});
        const Space v745_5 = subtract(constant_0,v745_4);
        Space v745_8;
        if (!v745_5.empty()) {
          const Path v746_6 = concat_path(v744_6,v744_7_head);
          const Space v746_7 = routine_125(c, v746_6, v744_7_tail);
          v745_8 = compose(v745_5,v746_7);
        }
        const Space v745_9 = intersect(constant_5,v745_2);
        const Space v745_10 = (has_head(v745_9) ? constant_7 : Space{});
        Space v745_12;
        if (!v745_10.empty()) {
          const Path v747_6 = concat_path(v744_6,v744_7_head);
          const Space v747_11 = routine_126(c, v747_6, v744_7_tail);
          v745_12 = compose(v745_10,v747_11);
        }
        const Space v745_13 = unite(v745_8,v745_12);
        v744_7_result = unite(v744_7_result,v745_13);
      }
      const Space v744_7 = std::move(v744_7_result);
      v743_8 = compose(v743_5,v744_7);
    }
    const Space v743_9 = intersect(constant_5,v743_2);
    const Space v743_10 = (has_head(v743_9) ? constant_7 : Space{});
    const Space v743_11 = compose(v743_10,v742_8_tail);
    const Space v743_12 = unite(v743_8,v743_11);
    v742_8_result = unite(v742_8_result,v743_12);
  }
  const Space v742_8 = std::move(v742_8_result);
  return v742_8;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v749_13_result;
  for (int v749_13_label = 1; v749_13_label <= 2; ++v749_13_label) {
    const Space v749_13_tail = child(s0,v749_13_label);
    if (v749_13_tail.empty()) continue;
    const Path v749_13_head{v749_13_label};
    const Space v750_2 = singleton(v749_13_head);
    const Space v750_3 = intersect(constant_5,v750_2);
    const Space v750_4 = (has_head(v750_3) ? constant_7 : Space{});
    const Space v750_5 = subtract(constant_0,v750_4);
    Space v750_8;
    if (!v750_5.empty()) {
      const Path v751_6 = concat_path(p0,v749_13_head);
      Space v751_7_result;
      for (int v751_7_label = 1; v751_7_label <= 2; ++v751_7_label) {
        const Space v751_7_tail = child(v749_13_tail,v751_7_label);
        if (v751_7_tail.empty()) continue;
        const Path v751_7_head{v751_7_label};
        const Space v752_2 = singleton(v751_7_head);
        const Space v752_3 = intersect(constant_5,v752_2);
        const Space v752_4 = (has_head(v752_3) ? constant_7 : Space{});
        const Space v752_5 = subtract(constant_0,v752_4);
        Space v752_8;
        if (!v752_5.empty()) {
          const Path v753_6 = concat_path(v751_6,v751_7_head);
          const Space v753_7 = routine_127(c, v753_6, p1, v751_7_tail, s1);
          v752_8 = compose(v752_5,v753_7);
        }
        const Space v752_9 = intersect(constant_5,v752_2);
        const Space v752_10 = (has_head(v752_9) ? constant_7 : Space{});
        Space v752_12;
        if (!v752_10.empty()) {
          const Path v754_6 = concat_path(v751_6,v751_7_head);
          const Space v754_11 = routine_128(c, v754_6, p1, v751_7_tail, s1);
          v752_12 = compose(v752_10,v754_11);
        }
        const Space v752_13 = unite(v752_8,v752_12);
        v751_7_result = unite(v751_7_result,v752_13);
      }
      const Space v751_7 = std::move(v751_7_result);
      v750_8 = compose(v750_5,v751_7);
    }
    const Space v750_9 = intersect(constant_5,v750_2);
    const Space v750_10 = (has_head(v750_9) ? constant_7 : Space{});
    Space v750_12;
    if (!v750_10.empty()) {
      const Path v755_6 = concat_path(p0,v749_13_head);
      Space v755_11_result;
      for (int v755_11_label = 1; v755_11_label <= 2; ++v755_11_label) {
        const Space v755_11_tail = child(v749_13_tail,v755_11_label);
        if (v755_11_tail.empty()) continue;
        const Path v755_11_head{v755_11_label};
        const Space v756_2 = singleton(v755_11_head);
        const Space v756_3 = intersect(constant_5,v756_2);
        const Space v756_4 = (has_head(v756_3) ? constant_7 : Space{});
        const Space v756_5 = subtract(constant_0,v756_4);
        Space v756_8;
        if (!v756_5.empty()) {
          const Path v757_6 = concat_path(v755_6,v755_11_head);
          const Space v757_7 = routine_127(c, v757_6, p1, v755_11_tail, s1);
          v756_8 = compose(v756_5,v757_7);
        }
        const Space v756_9 = intersect(constant_5,v756_2);
        const Space v756_10 = (has_head(v756_9) ? constant_7 : Space{});
        Space v756_12;
        if (!v756_10.empty()) {
          const Path v758_6 = concat_path(v755_6,v755_11_head);
          const Space v758_11 = routine_33(c, v758_6, p1, v755_11_tail, s1);
          v756_12 = compose(v756_10,v758_11);
        }
        const Space v756_13 = unite(v756_8,v756_12);
        v755_11_result = unite(v755_11_result,v756_13);
      }
      const Space v755_11 = std::move(v755_11_result);
      v750_12 = compose(v750_10,v755_11);
    }
    const Space v750_13 = unite(v750_8,v750_12);
    v749_13_result = unite(v749_13_result,v750_13);
  }
  const Space v749_13 = std::move(v749_13_result);
  return v749_13;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v759_8 = unwrap(constant_9,p1);
  const Space v759_10 = unwrap(constant_9,p0);
  const Space v759_12 = unwrap(s1,constant_8);
  const Space v759_14 = unwrap(constant_9,p1);
  const Space v759_16 = unwrap(constant_9,p0);
  Space v759_29_result;
  for (int v759_29_label = 1; v759_29_label <= 2; ++v759_29_label) {
    const Space v759_29_tail = child(s0,v759_29_label);
    if (v759_29_tail.empty()) continue;
    const Path v759_29_head{v759_29_label};
    const Space v760_2 = singleton(v759_29_head);
    const Space v760_3 = intersect(constant_5,v760_2);
    const Space v760_4 = (has_head(v760_3) ? constant_7 : Space{});
    const Space v760_5 = subtract(constant_0,v760_4);
    Space v760_8;
    if (!v760_5.empty()) {
      const Path v761_6 = concat_path(p0,v759_29_head);
      Space v761_7_result;
      for (int v761_7_label = 1; v761_7_label <= 2; ++v761_7_label) {
        const Space v761_7_tail = child(v759_29_tail,v761_7_label);
        if (v761_7_tail.empty()) continue;
        const Path v761_7_head{v761_7_label};
        const Space v762_2 = singleton(v761_7_head);
        const Space v762_3 = intersect(constant_5,v762_2);
        const Space v762_4 = (has_head(v762_3) ? constant_7 : Space{});
        const Space v762_5 = subtract(constant_0,v762_4);
        Space v762_8;
        if (!v762_5.empty()) {
          const Path v763_6 = concat_path(v761_6,v761_7_head);
          const Space v763_7 = routine_127(c, v763_6, p1, v761_7_tail, s1);
          v762_8 = compose(v762_5,v763_7);
        }
        const Space v762_9 = intersect(constant_5,v762_2);
        const Space v762_10 = (has_head(v762_9) ? constant_7 : Space{});
        Space v762_12;
        if (!v762_10.empty()) {
          const Path v764_6 = concat_path(v761_6,v761_7_head);
          const Space v764_11 = routine_128(c, v764_6, p1, v761_7_tail, s1);
          v762_12 = compose(v762_10,v764_11);
        }
        const Space v762_13 = unite(v762_8,v762_12);
        v761_7_result = unite(v761_7_result,v762_13);
      }
      const Space v761_7 = std::move(v761_7_result);
      v760_8 = compose(v760_5,v761_7);
    }
    const Space v760_9 = intersect(constant_5,v760_2);
    const Space v760_10 = (has_head(v760_9) ? constant_7 : Space{});
    Space v760_28;
    if (!v760_10.empty()) {
      const Path v765_6 = concat_path(p0,v759_29_head);
      const Space v765_11 = unwrap(v759_10,v759_29_head);
      const Space v765_12 = compose(v759_8,v765_11);
      const Path v765_13 = concat_path(p1,v765_6);
      const Space v765_14 = singleton(v765_13);
      const Space v765_15 = subtract(v765_12,v765_14);
      const Space v765_16 = intersect(v765_15,v759_12);
      const Space v765_17 = routine_36(c, v765_16);
      Space v765_18_result;
      for (int v765_18_label = 1; v765_18_label <= 2; ++v765_18_label) {
        const Space v765_18_tail = child(v765_17,v765_18_label);
        if (v765_18_tail.empty()) continue;
        const Path v765_18_head{v765_18_label};
        const Space v766_2 = singleton(v765_18_head);
        const Space v766_3 = intersect(constant_5,v766_2);
        const Space v766_4 = (has_head(v766_3) ? constant_7 : Space{});
        const Space v766_5 = subtract(constant_0,v766_4);
        Space v766_7;
        if (!v766_5.empty()) {
          const Space v767_6 = routine_37(c, v765_18_head, v765_18_tail);
          v766_7 = compose(v766_5,v767_6);
        }
        const Space v766_8 = intersect(constant_5,v766_2);
        const Space v766_9 = (has_head(v766_8) ? constant_7 : Space{});
        Space v766_11;
        if (!v766_9.empty()) {
          const Space v768_10 = routine_38(c, v765_18_head, v765_18_tail);
          v766_11 = compose(v766_9,v768_10);
        }
        const Space v766_12 = unite(v766_7,v766_11);
        v765_18_result = unite(v765_18_result,v766_12);
      }
      const Space v765_18 = std::move(v765_18_result);
      const Space v765_19 = unwrap(v759_16,v759_29_head);
      const Space v765_20 = compose(v759_14,v765_19);
      const Space v765_21 = subtract(v765_20,v765_14);
      const Space v765_22 = intersect(v765_21,v759_12);
      const Space v765_23 = routine_39(c, v765_22);
      Space v765_24_result;
      for (int v765_24_label = 1; v765_24_label <= 2; ++v765_24_label) {
        const Space v765_24_tail = child(v765_23,v765_24_label);
        if (v765_24_tail.empty()) continue;
        const Path v765_24_head{v765_24_label};
        const Space v769_2 = singleton(v765_24_head);
        const Space v769_3 = intersect(constant_5,v769_2);
        const Space v769_4 = (has_head(v769_3) ? constant_7 : Space{});
        const Space v769_5 = subtract(constant_0,v769_4);
        Space v769_7;
        if (!v769_5.empty()) {
          const Space v770_6 = routine_40(c, v765_24_head, v765_24_tail);
          v769_7 = compose(v769_5,v770_6);
        }
        const Space v769_8 = intersect(constant_5,v769_2);
        const Space v769_9 = (has_head(v769_8) ? constant_7 : Space{});
        Space v769_11;
        if (!v769_9.empty()) {
          const Space v771_10 = routine_41(c, v765_24_head, v765_24_tail);
          v769_11 = compose(v769_9,v771_10);
        }
        const Space v769_12 = unite(v769_7,v769_11);
        v765_24_result = unite(v765_24_result,v769_12);
      }
      const Space v765_24 = std::move(v765_24_result);
      const Space v765_25 = subtract(v765_18,v765_24);
      const Space v765_26 = compose(v765_25,v765_14);
      Space v765_27_result;
      for (int v765_27_label = 1; v765_27_label <= 2; ++v765_27_label) {
        const Space v765_27_tail = child(v765_26,v765_27_label);
        if (v765_27_tail.empty()) continue;
        const Path v765_27_head{v765_27_label};
        const Space v772_2 = singleton(v765_27_head);
        const Space v772_3 = intersect(constant_5,v772_2);
        const Space v772_4 = (has_head(v772_3) ? constant_7 : Space{});
        const Space v772_5 = subtract(constant_0,v772_4);
        Space v772_7;
        if (!v772_5.empty()) {
          const Space v773_6 = routine_42(c, v765_27_head, v765_27_tail);
          v772_7 = compose(v772_5,v773_6);
        }
        const Space v772_8 = intersect(constant_5,v772_2);
        const Space v772_9 = (has_head(v772_8) ? constant_7 : Space{});
        Space v772_11;
        if (!v772_9.empty()) {
          const Space v774_10 = routine_43(c, v765_27_head, v765_27_tail);
          v772_11 = compose(v772_9,v774_10);
        }
        const Space v772_12 = unite(v772_7,v772_11);
        v765_27_result = unite(v765_27_result,v772_12);
      }
      const Space v765_27 = std::move(v765_27_result);
      v760_28 = compose(v760_10,v765_27);
    }
    const Space v760_29 = unite(v760_8,v760_28);
    v759_29_result = unite(v759_29_result,v760_29);
  }
  const Space v759_29 = std::move(v759_29_result);
  return v759_29;
}

static Space routine_82(Context& c, const Space& s0) {
  const Space v775_2 = first_matching(s0,constant_0,false);
  const Space v775_3 = intersect(constant_0,v775_2);
  const Space v775_4 = (has_head(v775_2) ? constant_7 : Space{});
  const Space v775_5 = unite(v775_3,v775_4);
  const Space v775_7 = compose(v775_5,constant_0);
  const Space v775_9 = subtract(constant_0,v775_2);
  const Space v775_10 = subtract(v775_9,v775_4);
  Space v775_18;
  if (!v775_10.empty()) {
    const Space v776_11 = first_listed(s0,constant_12,true);
    const Space v776_12 = first_matching(v776_11,constant_0,false);
    Space v776_15;
    if (!v776_12.empty()) {
      const Space v777_14 = routine_129(c, constant_11, s0);
      v776_15 = compose(v776_12,v777_14);
    }
    Space v776_16_result;
    for (int v776_16_label = 1; v776_16_label <= 2; ++v776_16_label) {
      const Space v776_16_tail = child(v776_11,v776_16_label);
      if (v776_16_tail.empty()) continue;
      const Path v776_16_head{v776_16_label};
      const Space v778_2 = routine_120(c, v776_16_head, v776_16_tail, s0);
      v776_16_result = unite(v776_16_result,v778_2);
    }
    const Space v776_16 = std::move(v776_16_result);
    const Space v776_17 = unite(v776_15,v776_16);
    v775_18 = compose(v775_10,v776_17);
  }
  const Space v775_19 = unite(v775_7,v775_18);
  return v775_19;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v779_11_result;
  for (int v779_11_label = 1; v779_11_label <= 2; ++v779_11_label) {
    const Space v779_11_tail = child(s0,v779_11_label);
    if (v779_11_tail.empty()) continue;
    const Path v779_11_head{v779_11_label};
    const Space v780_2 = singleton(v779_11_head);
    const Space v780_3 = intersect(constant_5,v780_2);
    const Space v780_4 = (has_head(v780_3) ? constant_7 : Space{});
    const Space v780_5 = subtract(constant_0,v780_4);
    Space v780_8;
    if (!v780_5.empty()) {
      const Path v781_6 = concat_path(p0,v779_11_head);
      Space v781_7_result;
      for (int v781_7_label = 1; v781_7_label <= 2; ++v781_7_label) {
        const Space v781_7_tail = child(v779_11_tail,v781_7_label);
        if (v781_7_tail.empty()) continue;
        const Path v781_7_head{v781_7_label};
        const Space v782_2 = singleton(v781_7_head);
        const Space v782_3 = intersect(constant_5,v782_2);
        const Space v782_4 = (has_head(v782_3) ? constant_7 : Space{});
        const Space v782_5 = subtract(constant_0,v782_4);
        Space v782_8;
        if (!v782_5.empty()) {
          const Path v783_6 = concat_path(v781_6,v781_7_head);
          const Space v783_7 = routine_130(c, v783_6, v781_7_tail);
          v782_8 = compose(v782_5,v783_7);
        }
        const Space v782_9 = intersect(constant_5,v782_2);
        const Space v782_10 = (has_head(v782_9) ? constant_7 : Space{});
        Space v782_12;
        if (!v782_10.empty()) {
          const Path v784_6 = concat_path(v781_6,v781_7_head);
          const Space v784_11 = routine_131(c, v784_6, v781_7_tail);
          v782_12 = compose(v782_10,v784_11);
        }
        const Space v782_13 = unite(v782_8,v782_12);
        v781_7_result = unite(v781_7_result,v782_13);
      }
      const Space v781_7 = std::move(v781_7_result);
      v780_8 = compose(v780_5,v781_7);
    }
    const Space v780_9 = intersect(constant_5,v780_2);
    const Space v780_10 = (has_head(v780_9) ? constant_7 : Space{});
    Space v780_12;
    if (!v780_10.empty()) {
      const Path v785_6 = concat_path(p0,v779_11_head);
      Space v785_11_result;
      for (int v785_11_label = 1; v785_11_label <= 2; ++v785_11_label) {
        const Space v785_11_tail = child(v779_11_tail,v785_11_label);
        if (v785_11_tail.empty()) continue;
        const Path v785_11_head{v785_11_label};
        const Space v786_2 = singleton(v785_11_head);
        const Space v786_3 = intersect(constant_5,v786_2);
        const Space v786_4 = (has_head(v786_3) ? constant_7 : Space{});
        const Space v786_5 = subtract(constant_0,v786_4);
        Space v786_8;
        if (!v786_5.empty()) {
          const Path v787_6 = concat_path(v785_6,v785_11_head);
          const Space v787_7 = routine_130(c, v787_6, v785_11_tail);
          v786_8 = compose(v786_5,v787_7);
        }
        const Space v786_9 = intersect(constant_5,v786_2);
        const Space v786_10 = (has_head(v786_9) ? constant_7 : Space{});
        Space v786_12;
        if (!v786_10.empty()) {
          const Path v788_6 = concat_path(v785_6,v785_11_head);
          const Space v788_11 = routine_72(c, v788_6, v785_11_tail);
          v786_12 = compose(v786_10,v788_11);
        }
        const Space v786_13 = unite(v786_8,v786_12);
        v785_11_result = unite(v785_11_result,v786_13);
      }
      const Space v785_11 = std::move(v785_11_result);
      v780_12 = compose(v780_10,v785_11);
    }
    const Space v780_13 = unite(v780_8,v780_12);
    v779_11_result = unite(v779_11_result,v780_13);
  }
  const Space v779_11 = std::move(v779_11_result);
  return v779_11;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0) {
  Space v789_9_result;
  for (int v789_9_label = 1; v789_9_label <= 2; ++v789_9_label) {
    const Space v789_9_tail = child(s0,v789_9_label);
    if (v789_9_tail.empty()) continue;
    const Path v789_9_head{v789_9_label};
    const Space v790_2 = singleton(v789_9_head);
    const Space v790_3 = intersect(constant_5,v790_2);
    const Space v790_4 = (has_head(v790_3) ? constant_7 : Space{});
    const Space v790_5 = subtract(constant_0,v790_4);
    Space v790_8;
    if (!v790_5.empty()) {
      const Path v791_6 = concat_path(p0,v789_9_head);
      Space v791_7_result;
      for (int v791_7_label = 1; v791_7_label <= 2; ++v791_7_label) {
        const Space v791_7_tail = child(v789_9_tail,v791_7_label);
        if (v791_7_tail.empty()) continue;
        const Path v791_7_head{v791_7_label};
        const Space v792_2 = singleton(v791_7_head);
        const Space v792_3 = intersect(constant_5,v792_2);
        const Space v792_4 = (has_head(v792_3) ? constant_7 : Space{});
        const Space v792_5 = subtract(constant_0,v792_4);
        Space v792_8;
        if (!v792_5.empty()) {
          const Path v793_6 = concat_path(v791_6,v791_7_head);
          const Space v793_7 = routine_130(c, v793_6, v791_7_tail);
          v792_8 = compose(v792_5,v793_7);
        }
        const Space v792_9 = intersect(constant_5,v792_2);
        const Space v792_10 = (has_head(v792_9) ? constant_7 : Space{});
        Space v792_12;
        if (!v792_10.empty()) {
          const Path v794_6 = concat_path(v791_6,v791_7_head);
          const Space v794_11 = routine_131(c, v794_6, v791_7_tail);
          v792_12 = compose(v792_10,v794_11);
        }
        const Space v792_13 = unite(v792_8,v792_12);
        v791_7_result = unite(v791_7_result,v792_13);
      }
      const Space v791_7 = std::move(v791_7_result);
      v790_8 = compose(v790_5,v791_7);
    }
    const Space v790_9 = intersect(constant_5,v790_2);
    const Space v790_10 = (has_head(v790_9) ? constant_7 : Space{});
    const Space v790_11 = compose(v790_10,constant_10);
    const Space v790_12 = unite(v790_8,v790_11);
    v789_9_result = unite(v789_9_result,v790_12);
  }
  const Space v789_9 = std::move(v789_9_result);
  return v789_9;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0) {
  Space v795_11_result;
  for (int v795_11_label = 1; v795_11_label <= 2; ++v795_11_label) {
    const Space v795_11_tail = child(s0,v795_11_label);
    if (v795_11_tail.empty()) continue;
    const Path v795_11_head{v795_11_label};
    const Space v796_2 = singleton(v795_11_head);
    const Space v796_3 = intersect(constant_5,v796_2);
    const Space v796_4 = (has_head(v796_3) ? constant_7 : Space{});
    const Space v796_5 = subtract(constant_0,v796_4);
    Space v796_8;
    if (!v796_5.empty()) {
      const Path v797_6 = concat_path(p0,v795_11_head);
      Space v797_7_result;
      for (int v797_7_label = 1; v797_7_label <= 2; ++v797_7_label) {
        const Space v797_7_tail = child(v795_11_tail,v797_7_label);
        if (v797_7_tail.empty()) continue;
        const Path v797_7_head{v797_7_label};
        const Space v798_2 = singleton(v797_7_head);
        const Space v798_3 = intersect(constant_5,v798_2);
        const Space v798_4 = (has_head(v798_3) ? constant_7 : Space{});
        const Space v798_5 = subtract(constant_0,v798_4);
        Space v798_8;
        if (!v798_5.empty()) {
          const Path v799_6 = concat_path(v797_6,v797_7_head);
          const Space v799_7 = routine_132(c, v799_6, v797_7_tail);
          v798_8 = compose(v798_5,v799_7);
        }
        const Space v798_9 = intersect(constant_5,v798_2);
        const Space v798_10 = (has_head(v798_9) ? constant_7 : Space{});
        Space v798_12;
        if (!v798_10.empty()) {
          const Path v800_6 = concat_path(v797_6,v797_7_head);
          const Space v800_11 = routine_133(c, v800_6, v797_7_tail);
          v798_12 = compose(v798_10,v800_11);
        }
        const Space v798_13 = unite(v798_8,v798_12);
        v797_7_result = unite(v797_7_result,v798_13);
      }
      const Space v797_7 = std::move(v797_7_result);
      v796_8 = compose(v796_5,v797_7);
    }
    const Space v796_9 = intersect(constant_5,v796_2);
    const Space v796_10 = (has_head(v796_9) ? constant_7 : Space{});
    Space v796_12;
    if (!v796_10.empty()) {
      const Path v801_6 = concat_path(p0,v795_11_head);
      Space v801_11_result;
      for (int v801_11_label = 1; v801_11_label <= 2; ++v801_11_label) {
        const Space v801_11_tail = child(v795_11_tail,v801_11_label);
        if (v801_11_tail.empty()) continue;
        const Path v801_11_head{v801_11_label};
        const Space v802_2 = singleton(v801_11_head);
        const Space v802_3 = intersect(constant_5,v802_2);
        const Space v802_4 = (has_head(v802_3) ? constant_7 : Space{});
        const Space v802_5 = subtract(constant_0,v802_4);
        Space v802_8;
        if (!v802_5.empty()) {
          const Path v803_6 = concat_path(v801_6,v801_11_head);
          const Space v803_7 = routine_132(c, v803_6, v801_11_tail);
          v802_8 = compose(v802_5,v803_7);
        }
        const Space v802_9 = intersect(constant_5,v802_2);
        const Space v802_10 = (has_head(v802_9) ? constant_7 : Space{});
        Space v802_12;
        if (!v802_10.empty()) {
          const Path v804_6 = concat_path(v801_6,v801_11_head);
          const Space v804_11 = routine_76(c, v804_6, v801_11_tail);
          v802_12 = compose(v802_10,v804_11);
        }
        const Space v802_13 = unite(v802_8,v802_12);
        v801_11_result = unite(v801_11_result,v802_13);
      }
      const Space v801_11 = std::move(v801_11_result);
      v796_12 = compose(v796_10,v801_11);
    }
    const Space v796_13 = unite(v796_8,v796_12);
    v795_11_result = unite(v795_11_result,v796_13);
  }
  const Space v795_11 = std::move(v795_11_result);
  return v795_11;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0) {
  Space v805_9_result;
  for (int v805_9_label = 1; v805_9_label <= 2; ++v805_9_label) {
    const Space v805_9_tail = child(s0,v805_9_label);
    if (v805_9_tail.empty()) continue;
    const Path v805_9_head{v805_9_label};
    const Space v806_2 = singleton(v805_9_head);
    const Space v806_3 = intersect(constant_5,v806_2);
    const Space v806_4 = (has_head(v806_3) ? constant_7 : Space{});
    const Space v806_5 = subtract(constant_0,v806_4);
    Space v806_8;
    if (!v806_5.empty()) {
      const Path v807_6 = concat_path(p0,v805_9_head);
      Space v807_7_result;
      for (int v807_7_label = 1; v807_7_label <= 2; ++v807_7_label) {
        const Space v807_7_tail = child(v805_9_tail,v807_7_label);
        if (v807_7_tail.empty()) continue;
        const Path v807_7_head{v807_7_label};
        const Space v808_2 = singleton(v807_7_head);
        const Space v808_3 = intersect(constant_5,v808_2);
        const Space v808_4 = (has_head(v808_3) ? constant_7 : Space{});
        const Space v808_5 = subtract(constant_0,v808_4);
        Space v808_8;
        if (!v808_5.empty()) {
          const Path v809_6 = concat_path(v807_6,v807_7_head);
          const Space v809_7 = routine_132(c, v809_6, v807_7_tail);
          v808_8 = compose(v808_5,v809_7);
        }
        const Space v808_9 = intersect(constant_5,v808_2);
        const Space v808_10 = (has_head(v808_9) ? constant_7 : Space{});
        Space v808_12;
        if (!v808_10.empty()) {
          const Path v810_6 = concat_path(v807_6,v807_7_head);
          const Space v810_11 = routine_133(c, v810_6, v807_7_tail);
          v808_12 = compose(v808_10,v810_11);
        }
        const Space v808_13 = unite(v808_8,v808_12);
        v807_7_result = unite(v807_7_result,v808_13);
      }
      const Space v807_7 = std::move(v807_7_result);
      v806_8 = compose(v806_5,v807_7);
    }
    const Space v806_9 = intersect(constant_5,v806_2);
    const Space v806_10 = (has_head(v806_9) ? constant_7 : Space{});
    const Space v806_11 = compose(v806_10,constant_10);
    const Space v806_12 = unite(v806_8,v806_11);
    v805_9_result = unite(v805_9_result,v806_12);
  }
  const Space v805_9 = std::move(v805_9_result);
  return v805_9;
}

static Space routine_87(Context& c, const Path& p0, const Space& s0) {
  Space v811_11_result;
  for (int v811_11_label = 1; v811_11_label <= 2; ++v811_11_label) {
    const Space v811_11_tail = child(s0,v811_11_label);
    if (v811_11_tail.empty()) continue;
    const Path v811_11_head{v811_11_label};
    const Space v812_2 = singleton(v811_11_head);
    const Space v812_3 = intersect(constant_5,v812_2);
    const Space v812_4 = (has_head(v812_3) ? constant_7 : Space{});
    const Space v812_5 = subtract(constant_0,v812_4);
    Space v812_8;
    if (!v812_5.empty()) {
      const Path v813_6 = concat_path(p0,v811_11_head);
      Space v813_7_result;
      for (int v813_7_label = 1; v813_7_label <= 2; ++v813_7_label) {
        const Space v813_7_tail = child(v811_11_tail,v813_7_label);
        if (v813_7_tail.empty()) continue;
        const Path v813_7_head{v813_7_label};
        const Space v814_2 = singleton(v813_7_head);
        const Space v814_3 = intersect(constant_5,v814_2);
        const Space v814_4 = (has_head(v814_3) ? constant_7 : Space{});
        const Space v814_5 = subtract(constant_0,v814_4);
        Space v814_8;
        if (!v814_5.empty()) {
          const Path v815_6 = concat_path(v813_6,v813_7_head);
          const Space v815_7 = routine_134(c, v815_6, v813_7_tail);
          v814_8 = compose(v814_5,v815_7);
        }
        const Space v814_9 = intersect(constant_5,v814_2);
        const Space v814_10 = (has_head(v814_9) ? constant_7 : Space{});
        Space v814_12;
        if (!v814_10.empty()) {
          const Path v816_6 = concat_path(v813_6,v813_7_head);
          const Space v816_11 = routine_135(c, v816_6, v813_7_tail);
          v814_12 = compose(v814_10,v816_11);
        }
        const Space v814_13 = unite(v814_8,v814_12);
        v813_7_result = unite(v813_7_result,v814_13);
      }
      const Space v813_7 = std::move(v813_7_result);
      v812_8 = compose(v812_5,v813_7);
    }
    const Space v812_9 = intersect(constant_5,v812_2);
    const Space v812_10 = (has_head(v812_9) ? constant_7 : Space{});
    Space v812_12;
    if (!v812_10.empty()) {
      const Path v817_6 = concat_path(p0,v811_11_head);
      Space v817_11_result;
      for (int v817_11_label = 1; v817_11_label <= 2; ++v817_11_label) {
        const Space v817_11_tail = child(v811_11_tail,v817_11_label);
        if (v817_11_tail.empty()) continue;
        const Path v817_11_head{v817_11_label};
        const Space v818_2 = singleton(v817_11_head);
        const Space v818_3 = intersect(constant_5,v818_2);
        const Space v818_4 = (has_head(v818_3) ? constant_7 : Space{});
        const Space v818_5 = subtract(constant_0,v818_4);
        Space v818_8;
        if (!v818_5.empty()) {
          const Path v819_6 = concat_path(v817_6,v817_11_head);
          const Space v819_7 = routine_134(c, v819_6, v817_11_tail);
          v818_8 = compose(v818_5,v819_7);
        }
        const Space v818_9 = intersect(constant_5,v818_2);
        const Space v818_10 = (has_head(v818_9) ? constant_7 : Space{});
        Space v818_12;
        if (!v818_10.empty()) {
          const Path v820_6 = concat_path(v817_6,v817_11_head);
          const Space v820_11 = routine_79(c, v820_6, v817_11_tail);
          v818_12 = compose(v818_10,v820_11);
        }
        const Space v818_13 = unite(v818_8,v818_12);
        v817_11_result = unite(v817_11_result,v818_13);
      }
      const Space v817_11 = std::move(v817_11_result);
      v812_12 = compose(v812_10,v817_11);
    }
    const Space v812_13 = unite(v812_8,v812_12);
    v811_11_result = unite(v811_11_result,v812_13);
  }
  const Space v811_11 = std::move(v811_11_result);
  return v811_11;
}

static Space routine_88(Context& c, const Path& p0, const Space& s0) {
  Space v821_8_result;
  for (int v821_8_label = 1; v821_8_label <= 2; ++v821_8_label) {
    const Space v821_8_tail = child(s0,v821_8_label);
    if (v821_8_tail.empty()) continue;
    const Path v821_8_head{v821_8_label};
    const Space v822_2 = singleton(v821_8_head);
    const Space v822_3 = intersect(constant_5,v822_2);
    const Space v822_4 = (has_head(v822_3) ? constant_7 : Space{});
    const Space v822_5 = subtract(constant_0,v822_4);
    Space v822_8;
    if (!v822_5.empty()) {
      const Path v823_6 = concat_path(p0,v821_8_head);
      Space v823_7_result;
      for (int v823_7_label = 1; v823_7_label <= 2; ++v823_7_label) {
        const Space v823_7_tail = child(v821_8_tail,v823_7_label);
        if (v823_7_tail.empty()) continue;
        const Path v823_7_head{v823_7_label};
        const Space v824_2 = singleton(v823_7_head);
        const Space v824_3 = intersect(constant_5,v824_2);
        const Space v824_4 = (has_head(v824_3) ? constant_7 : Space{});
        const Space v824_5 = subtract(constant_0,v824_4);
        Space v824_8;
        if (!v824_5.empty()) {
          const Path v825_6 = concat_path(v823_6,v823_7_head);
          const Space v825_7 = routine_134(c, v825_6, v823_7_tail);
          v824_8 = compose(v824_5,v825_7);
        }
        const Space v824_9 = intersect(constant_5,v824_2);
        const Space v824_10 = (has_head(v824_9) ? constant_7 : Space{});
        Space v824_12;
        if (!v824_10.empty()) {
          const Path v826_6 = concat_path(v823_6,v823_7_head);
          const Space v826_11 = routine_135(c, v826_6, v823_7_tail);
          v824_12 = compose(v824_10,v826_11);
        }
        const Space v824_13 = unite(v824_8,v824_12);
        v823_7_result = unite(v823_7_result,v824_13);
      }
      const Space v823_7 = std::move(v823_7_result);
      v822_8 = compose(v822_5,v823_7);
    }
    const Space v822_9 = intersect(constant_5,v822_2);
    const Space v822_10 = (has_head(v822_9) ? constant_7 : Space{});
    const Space v822_11 = compose(v822_10,v821_8_tail);
    const Space v822_12 = unite(v822_8,v822_11);
    v821_8_result = unite(v821_8_result,v822_12);
  }
  const Space v821_8 = std::move(v821_8_result);
  return v821_8;
}

static Space routine_89(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v827_12_result;
  for (int v827_12_label = 1; v827_12_label <= 2; ++v827_12_label) {
    const Space v827_12_tail = child(s0,v827_12_label);
    if (v827_12_tail.empty()) continue;
    const Path v827_12_head{v827_12_label};
    const Space v828_2 = singleton(v827_12_head);
    const Space v828_3 = intersect(constant_5,v828_2);
    const Space v828_4 = (has_head(v828_3) ? constant_7 : Space{});
    const Space v828_5 = subtract(constant_0,v828_4);
    Space v828_8;
    if (!v828_5.empty()) {
      const Path v829_6 = concat_path(p0,v827_12_head);
      Space v829_7_result;
      for (int v829_7_label = 1; v829_7_label <= 2; ++v829_7_label) {
        const Space v829_7_tail = child(v827_12_tail,v829_7_label);
        if (v829_7_tail.empty()) continue;
        const Path v829_7_head{v829_7_label};
        const Space v830_2 = singleton(v829_7_head);
        const Space v830_3 = intersect(constant_5,v830_2);
        const Space v830_4 = (has_head(v830_3) ? constant_7 : Space{});
        const Space v830_5 = subtract(constant_0,v830_4);
        Space v830_8;
        if (!v830_5.empty()) {
          const Path v831_6 = concat_path(v829_6,v829_7_head);
          const Space v831_7 = routine_136(c, v831_6, v829_7_tail, s1);
          v830_8 = compose(v830_5,v831_7);
        }
        const Space v830_9 = intersect(constant_5,v830_2);
        const Space v830_10 = (has_head(v830_9) ? constant_7 : Space{});
        Space v830_12;
        if (!v830_10.empty()) {
          const Path v832_6 = concat_path(v829_6,v829_7_head);
          const Space v832_11 = routine_137(c, v832_6, v829_7_tail, s1);
          v830_12 = compose(v830_10,v832_11);
        }
        const Space v830_13 = unite(v830_8,v830_12);
        v829_7_result = unite(v829_7_result,v830_13);
      }
      const Space v829_7 = std::move(v829_7_result);
      v828_8 = compose(v828_5,v829_7);
    }
    const Space v828_9 = intersect(constant_5,v828_2);
    const Space v828_10 = (has_head(v828_9) ? constant_7 : Space{});
    Space v828_12;
    if (!v828_10.empty()) {
      const Path v833_6 = concat_path(p0,v827_12_head);
      Space v833_11_result;
      for (int v833_11_label = 1; v833_11_label <= 2; ++v833_11_label) {
        const Space v833_11_tail = child(v827_12_tail,v833_11_label);
        if (v833_11_tail.empty()) continue;
        const Path v833_11_head{v833_11_label};
        const Space v834_2 = singleton(v833_11_head);
        const Space v834_3 = intersect(constant_5,v834_2);
        const Space v834_4 = (has_head(v834_3) ? constant_7 : Space{});
        const Space v834_5 = subtract(constant_0,v834_4);
        Space v834_8;
        if (!v834_5.empty()) {
          const Path v835_6 = concat_path(v833_6,v833_11_head);
          const Space v835_7 = routine_136(c, v835_6, v833_11_tail, s1);
          v834_8 = compose(v834_5,v835_7);
        }
        const Space v834_9 = intersect(constant_5,v834_2);
        const Space v834_10 = (has_head(v834_9) ? constant_7 : Space{});
        Space v834_12;
        if (!v834_10.empty()) {
          const Path v836_6 = concat_path(v833_6,v833_11_head);
          const Space v836_11 = routine_19(c, v836_6, v833_11_tail, s1);
          v834_12 = compose(v834_10,v836_11);
        }
        const Space v834_13 = unite(v834_8,v834_12);
        v833_11_result = unite(v833_11_result,v834_13);
      }
      const Space v833_11 = std::move(v833_11_result);
      v828_12 = compose(v828_10,v833_11);
    }
    const Space v828_13 = unite(v828_8,v828_12);
    v827_12_result = unite(v827_12_result,v828_13);
  }
  const Space v827_12 = std::move(v827_12_result);
  return v827_12;
}

static Space routine_90(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v837_12_result;
  for (int v837_12_label = 1; v837_12_label <= 2; ++v837_12_label) {
    const Space v837_12_tail = child(s0,v837_12_label);
    if (v837_12_tail.empty()) continue;
    const Path v837_12_head{v837_12_label};
    const Space v838_2 = singleton(v837_12_head);
    const Space v838_3 = intersect(constant_5,v838_2);
    const Space v838_4 = (has_head(v838_3) ? constant_7 : Space{});
    const Space v838_5 = subtract(constant_0,v838_4);
    Space v838_8;
    if (!v838_5.empty()) {
      const Path v839_6 = concat_path(p0,v837_12_head);
      Space v839_7_result;
      for (int v839_7_label = 1; v839_7_label <= 2; ++v839_7_label) {
        const Space v839_7_tail = child(v837_12_tail,v839_7_label);
        if (v839_7_tail.empty()) continue;
        const Path v839_7_head{v839_7_label};
        const Space v840_2 = singleton(v839_7_head);
        const Space v840_3 = intersect(constant_5,v840_2);
        const Space v840_4 = (has_head(v840_3) ? constant_7 : Space{});
        const Space v840_5 = subtract(constant_0,v840_4);
        Space v840_8;
        if (!v840_5.empty()) {
          const Path v841_6 = concat_path(v839_6,v839_7_head);
          const Space v841_7 = routine_136(c, v841_6, v839_7_tail, s1);
          v840_8 = compose(v840_5,v841_7);
        }
        const Space v840_9 = intersect(constant_5,v840_2);
        const Space v840_10 = (has_head(v840_9) ? constant_7 : Space{});
        Space v840_12;
        if (!v840_10.empty()) {
          const Path v842_6 = concat_path(v839_6,v839_7_head);
          const Space v842_11 = routine_137(c, v842_6, v839_7_tail, s1);
          v840_12 = compose(v840_10,v842_11);
        }
        const Space v840_13 = unite(v840_8,v840_12);
        v839_7_result = unite(v839_7_result,v840_13);
      }
      const Space v839_7 = std::move(v839_7_result);
      v838_8 = compose(v838_5,v839_7);
    }
    const Space v838_9 = intersect(constant_5,v838_2);
    const Space v838_10 = (has_head(v838_9) ? constant_7 : Space{});
    Space v838_12;
    if (!v838_10.empty()) {
      const Path v843_6 = concat_path(p0,v837_12_head);
      Space v843_11_result;
      for (int v843_11_label = 1; v843_11_label <= 2; ++v843_11_label) {
        const Space v843_11_tail = child(v837_12_tail,v843_11_label);
        if (v843_11_tail.empty()) continue;
        const Path v843_11_head{v843_11_label};
        const Space v844_2 = singleton(v843_11_head);
        const Space v844_3 = intersect(constant_5,v844_2);
        const Space v844_4 = (has_head(v844_3) ? constant_7 : Space{});
        const Space v844_5 = subtract(constant_0,v844_4);
        Space v844_7;
        if (!v844_5.empty()) {
          const Space v845_6 = routine_20(c, v843_11_head, v843_6, v843_11_tail, s1);
          v844_7 = compose(v844_5,v845_6);
        }
        const Space v844_8 = intersect(constant_5,v844_2);
        const Space v844_9 = (has_head(v844_8) ? constant_7 : Space{});
        Space v844_11;
        if (!v844_9.empty()) {
          const Space v846_10 = routine_21(c, v843_11_head, v843_6, v843_11_tail, s1);
          v844_11 = compose(v844_9,v846_10);
        }
        const Space v844_12 = unite(v844_7,v844_11);
        v843_11_result = unite(v843_11_result,v844_12);
      }
      const Space v843_11 = std::move(v843_11_result);
      v838_12 = compose(v838_10,v843_11);
    }
    const Space v838_13 = unite(v838_8,v838_12);
    v837_12_result = unite(v837_12_result,v838_13);
  }
  const Space v837_12 = std::move(v837_12_result);
  return v837_12;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v847_13_result;
  for (int v847_13_label = 1; v847_13_label <= 2; ++v847_13_label) {
    const Space v847_13_tail = child(s0,v847_13_label);
    if (v847_13_tail.empty()) continue;
    const Path v847_13_head{v847_13_label};
    const Space v848_2 = singleton(v847_13_head);
    const Space v848_3 = intersect(constant_5,v848_2);
    const Space v848_4 = (has_head(v848_3) ? constant_7 : Space{});
    const Space v848_5 = subtract(constant_0,v848_4);
    Space v848_8;
    if (!v848_5.empty()) {
      const Path v849_6 = concat_path(p0,v847_13_head);
      Space v849_7_result;
      for (int v849_7_label = 1; v849_7_label <= 2; ++v849_7_label) {
        const Space v849_7_tail = child(v847_13_tail,v849_7_label);
        if (v849_7_tail.empty()) continue;
        const Path v849_7_head{v849_7_label};
        const Space v850_2 = singleton(v849_7_head);
        const Space v850_3 = intersect(constant_5,v850_2);
        const Space v850_4 = (has_head(v850_3) ? constant_7 : Space{});
        const Space v850_5 = subtract(constant_0,v850_4);
        Space v850_8;
        if (!v850_5.empty()) {
          const Path v851_6 = concat_path(v849_6,v849_7_head);
          const Space v851_7 = routine_138(c, v851_6, p1, v849_7_tail, s1);
          v850_8 = compose(v850_5,v851_7);
        }
        const Space v850_9 = intersect(constant_5,v850_2);
        const Space v850_10 = (has_head(v850_9) ? constant_7 : Space{});
        Space v850_12;
        if (!v850_10.empty()) {
          const Path v852_6 = concat_path(v849_6,v849_7_head);
          const Space v852_11 = routine_139(c, v852_6, p1, v849_7_tail, s1);
          v850_12 = compose(v850_10,v852_11);
        }
        const Space v850_13 = unite(v850_8,v850_12);
        v849_7_result = unite(v849_7_result,v850_13);
      }
      const Space v849_7 = std::move(v849_7_result);
      v848_8 = compose(v848_5,v849_7);
    }
    const Space v848_9 = intersect(constant_5,v848_2);
    const Space v848_10 = (has_head(v848_9) ? constant_7 : Space{});
    Space v848_12;
    if (!v848_10.empty()) {
      const Path v853_6 = concat_path(p0,v847_13_head);
      Space v853_11_result;
      for (int v853_11_label = 1; v853_11_label <= 2; ++v853_11_label) {
        const Space v853_11_tail = child(v847_13_tail,v853_11_label);
        if (v853_11_tail.empty()) continue;
        const Path v853_11_head{v853_11_label};
        const Space v854_2 = singleton(v853_11_head);
        const Space v854_3 = intersect(constant_5,v854_2);
        const Space v854_4 = (has_head(v854_3) ? constant_7 : Space{});
        const Space v854_5 = subtract(constant_0,v854_4);
        Space v854_8;
        if (!v854_5.empty()) {
          const Path v855_6 = concat_path(v853_6,v853_11_head);
          const Space v855_7 = routine_138(c, v855_6, p1, v853_11_tail, s1);
          v854_8 = compose(v854_5,v855_7);
        }
        const Space v854_9 = intersect(constant_5,v854_2);
        const Space v854_10 = (has_head(v854_9) ? constant_7 : Space{});
        Space v854_12;
        if (!v854_10.empty()) {
          const Path v856_6 = concat_path(v853_6,v853_11_head);
          const Space v856_11 = routine_48(c, v856_6, p1, v853_11_tail, s1);
          v854_12 = compose(v854_10,v856_11);
        }
        const Space v854_13 = unite(v854_8,v854_12);
        v853_11_result = unite(v853_11_result,v854_13);
      }
      const Space v853_11 = std::move(v853_11_result);
      v848_12 = compose(v848_10,v853_11);
    }
    const Space v848_13 = unite(v848_8,v848_12);
    v847_13_result = unite(v847_13_result,v848_13);
  }
  const Space v847_13 = std::move(v847_13_result);
  return v847_13;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v857_8 = unwrap(constant_9,p1);
  const Space v857_10 = unwrap(constant_9,p0);
  const Space v857_12 = unwrap(s1,constant_8);
  const Space v857_14 = unwrap(constant_9,p1);
  const Space v857_16 = unwrap(constant_9,p0);
  Space v857_29_result;
  for (int v857_29_label = 1; v857_29_label <= 2; ++v857_29_label) {
    const Space v857_29_tail = child(s0,v857_29_label);
    if (v857_29_tail.empty()) continue;
    const Path v857_29_head{v857_29_label};
    const Space v858_2 = singleton(v857_29_head);
    const Space v858_3 = intersect(constant_5,v858_2);
    const Space v858_4 = (has_head(v858_3) ? constant_7 : Space{});
    const Space v858_5 = subtract(constant_0,v858_4);
    Space v858_8;
    if (!v858_5.empty()) {
      const Path v859_6 = concat_path(p0,v857_29_head);
      Space v859_7_result;
      for (int v859_7_label = 1; v859_7_label <= 2; ++v859_7_label) {
        const Space v859_7_tail = child(v857_29_tail,v859_7_label);
        if (v859_7_tail.empty()) continue;
        const Path v859_7_head{v859_7_label};
        const Space v860_2 = singleton(v859_7_head);
        const Space v860_3 = intersect(constant_5,v860_2);
        const Space v860_4 = (has_head(v860_3) ? constant_7 : Space{});
        const Space v860_5 = subtract(constant_0,v860_4);
        Space v860_8;
        if (!v860_5.empty()) {
          const Path v861_6 = concat_path(v859_6,v859_7_head);
          const Space v861_7 = routine_138(c, v861_6, p1, v859_7_tail, s1);
          v860_8 = compose(v860_5,v861_7);
        }
        const Space v860_9 = intersect(constant_5,v860_2);
        const Space v860_10 = (has_head(v860_9) ? constant_7 : Space{});
        Space v860_12;
        if (!v860_10.empty()) {
          const Path v862_6 = concat_path(v859_6,v859_7_head);
          const Space v862_11 = routine_139(c, v862_6, p1, v859_7_tail, s1);
          v860_12 = compose(v860_10,v862_11);
        }
        const Space v860_13 = unite(v860_8,v860_12);
        v859_7_result = unite(v859_7_result,v860_13);
      }
      const Space v859_7 = std::move(v859_7_result);
      v858_8 = compose(v858_5,v859_7);
    }
    const Space v858_9 = intersect(constant_5,v858_2);
    const Space v858_10 = (has_head(v858_9) ? constant_7 : Space{});
    Space v858_28;
    if (!v858_10.empty()) {
      const Path v863_6 = concat_path(p0,v857_29_head);
      const Space v863_11 = unwrap(v857_10,v857_29_head);
      const Space v863_12 = compose(v857_8,v863_11);
      const Path v863_13 = concat_path(p1,v863_6);
      const Space v863_14 = singleton(v863_13);
      const Space v863_15 = subtract(v863_12,v863_14);
      const Space v863_16 = intersect(v863_15,v857_12);
      const Space v863_17 = routine_51(c, v863_16);
      Space v863_18_result;
      for (int v863_18_label = 1; v863_18_label <= 2; ++v863_18_label) {
        const Space v863_18_tail = child(v863_17,v863_18_label);
        if (v863_18_tail.empty()) continue;
        const Path v863_18_head{v863_18_label};
        const Space v864_2 = singleton(v863_18_head);
        const Space v864_3 = intersect(constant_5,v864_2);
        const Space v864_4 = (has_head(v864_3) ? constant_7 : Space{});
        const Space v864_5 = subtract(constant_0,v864_4);
        Space v864_7;
        if (!v864_5.empty()) {
          const Space v865_6 = routine_52(c, v863_18_head, v863_18_tail);
          v864_7 = compose(v864_5,v865_6);
        }
        const Space v864_8 = intersect(constant_5,v864_2);
        const Space v864_9 = (has_head(v864_8) ? constant_7 : Space{});
        Space v864_11;
        if (!v864_9.empty()) {
          const Space v866_10 = routine_53(c, v863_18_head, v863_18_tail);
          v864_11 = compose(v864_9,v866_10);
        }
        const Space v864_12 = unite(v864_7,v864_11);
        v863_18_result = unite(v863_18_result,v864_12);
      }
      const Space v863_18 = std::move(v863_18_result);
      const Space v863_19 = unwrap(v857_16,v857_29_head);
      const Space v863_20 = compose(v857_14,v863_19);
      const Space v863_21 = subtract(v863_20,v863_14);
      const Space v863_22 = intersect(v863_21,v857_12);
      const Space v863_23 = routine_36(c, v863_22);
      Space v863_24_result;
      for (int v863_24_label = 1; v863_24_label <= 2; ++v863_24_label) {
        const Space v863_24_tail = child(v863_23,v863_24_label);
        if (v863_24_tail.empty()) continue;
        const Path v863_24_head{v863_24_label};
        const Space v867_2 = singleton(v863_24_head);
        const Space v867_3 = intersect(constant_5,v867_2);
        const Space v867_4 = (has_head(v867_3) ? constant_7 : Space{});
        const Space v867_5 = subtract(constant_0,v867_4);
        Space v867_7;
        if (!v867_5.empty()) {
          const Space v868_6 = routine_54(c, v863_24_head, v863_24_tail);
          v867_7 = compose(v867_5,v868_6);
        }
        const Space v867_8 = intersect(constant_5,v867_2);
        const Space v867_9 = (has_head(v867_8) ? constant_7 : Space{});
        Space v867_11;
        if (!v867_9.empty()) {
          const Space v869_10 = routine_55(c, v863_24_head, v863_24_tail);
          v867_11 = compose(v867_9,v869_10);
        }
        const Space v867_12 = unite(v867_7,v867_11);
        v863_24_result = unite(v863_24_result,v867_12);
      }
      const Space v863_24 = std::move(v863_24_result);
      const Space v863_25 = subtract(v863_18,v863_24);
      const Space v863_26 = compose(v863_25,v863_14);
      Space v863_27_result;
      for (int v863_27_label = 1; v863_27_label <= 2; ++v863_27_label) {
        const Space v863_27_tail = child(v863_26,v863_27_label);
        if (v863_27_tail.empty()) continue;
        const Path v863_27_head{v863_27_label};
        const Space v870_2 = singleton(v863_27_head);
        const Space v870_3 = intersect(constant_5,v870_2);
        const Space v870_4 = (has_head(v870_3) ? constant_7 : Space{});
        const Space v870_5 = subtract(constant_0,v870_4);
        Space v870_7;
        if (!v870_5.empty()) {
          const Space v871_6 = routine_56(c, v863_27_head, v863_27_tail);
          v870_7 = compose(v870_5,v871_6);
        }
        const Space v870_8 = intersect(constant_5,v870_2);
        const Space v870_9 = (has_head(v870_8) ? constant_7 : Space{});
        Space v870_11;
        if (!v870_9.empty()) {
          const Space v872_10 = routine_57(c, v863_27_head, v863_27_tail);
          v870_11 = compose(v870_9,v872_10);
        }
        const Space v870_12 = unite(v870_7,v870_11);
        v863_27_result = unite(v863_27_result,v870_12);
      }
      const Space v863_27 = std::move(v863_27_result);
      v858_28 = compose(v858_10,v863_27);
    }
    const Space v858_29 = unite(v858_8,v858_28);
    v857_29_result = unite(v857_29_result,v858_29);
  }
  const Space v857_29 = std::move(v857_29_result);
  return v857_29;
}

static Space routine_93(Context& c, const Path& p0, const Space& s0) {
  Space v873_11_result;
  for (int v873_11_label = 1; v873_11_label <= 2; ++v873_11_label) {
    const Space v873_11_tail = child(s0,v873_11_label);
    if (v873_11_tail.empty()) continue;
    const Path v873_11_head{v873_11_label};
    const Space v874_2 = singleton(v873_11_head);
    const Space v874_3 = intersect(constant_5,v874_2);
    const Space v874_4 = (has_head(v874_3) ? constant_7 : Space{});
    const Space v874_5 = subtract(constant_0,v874_4);
    Space v874_8;
    if (!v874_5.empty()) {
      const Path v875_6 = concat_path(p0,v873_11_head);
      Space v875_7_result;
      for (int v875_7_label = 1; v875_7_label <= 2; ++v875_7_label) {
        const Space v875_7_tail = child(v873_11_tail,v875_7_label);
        if (v875_7_tail.empty()) continue;
        const Path v875_7_head{v875_7_label};
        const Space v876_2 = singleton(v875_7_head);
        const Space v876_3 = intersect(constant_5,v876_2);
        const Space v876_4 = (has_head(v876_3) ? constant_7 : Space{});
        const Space v876_5 = subtract(constant_0,v876_4);
        Space v876_8;
        if (!v876_5.empty()) {
          const Path v877_6 = concat_path(v875_6,v875_7_head);
          const Space v877_7 = routine_140(c, v877_6, v875_7_tail);
          v876_8 = compose(v876_5,v877_7);
        }
        const Space v876_9 = intersect(constant_5,v876_2);
        const Space v876_10 = (has_head(v876_9) ? constant_7 : Space{});
        Space v876_12;
        if (!v876_10.empty()) {
          const Path v878_6 = concat_path(v875_6,v875_7_head);
          const Space v878_11 = routine_141(c, v878_6, v875_7_tail);
          v876_12 = compose(v876_10,v878_11);
        }
        const Space v876_13 = unite(v876_8,v876_12);
        v875_7_result = unite(v875_7_result,v876_13);
      }
      const Space v875_7 = std::move(v875_7_result);
      v874_8 = compose(v874_5,v875_7);
    }
    const Space v874_9 = intersect(constant_5,v874_2);
    const Space v874_10 = (has_head(v874_9) ? constant_7 : Space{});
    Space v874_12;
    if (!v874_10.empty()) {
      const Path v879_6 = concat_path(p0,v873_11_head);
      Space v879_11_result;
      for (int v879_11_label = 1; v879_11_label <= 2; ++v879_11_label) {
        const Space v879_11_tail = child(v873_11_tail,v879_11_label);
        if (v879_11_tail.empty()) continue;
        const Path v879_11_head{v879_11_label};
        const Space v880_2 = singleton(v879_11_head);
        const Space v880_3 = intersect(constant_5,v880_2);
        const Space v880_4 = (has_head(v880_3) ? constant_7 : Space{});
        const Space v880_5 = subtract(constant_0,v880_4);
        Space v880_8;
        if (!v880_5.empty()) {
          const Path v881_6 = concat_path(v879_6,v879_11_head);
          const Space v881_7 = routine_140(c, v881_6, v879_11_tail);
          v880_8 = compose(v880_5,v881_7);
        }
        const Space v880_9 = intersect(constant_5,v880_2);
        const Space v880_10 = (has_head(v880_9) ? constant_7 : Space{});
        Space v880_12;
        if (!v880_10.empty()) {
          const Path v882_6 = concat_path(v879_6,v879_11_head);
          const Space v882_11 = routine_95(c, v882_6, v879_11_tail);
          v880_12 = compose(v880_10,v882_11);
        }
        const Space v880_13 = unite(v880_8,v880_12);
        v879_11_result = unite(v879_11_result,v880_13);
      }
      const Space v879_11 = std::move(v879_11_result);
      v874_12 = compose(v874_10,v879_11);
    }
    const Space v874_13 = unite(v874_8,v874_12);
    v873_11_result = unite(v873_11_result,v874_13);
  }
  const Space v873_11 = std::move(v873_11_result);
  return v873_11;
}

static Space routine_94(Context& c, const Path& p0, const Space& s0) {
  Space v883_9_result;
  for (int v883_9_label = 1; v883_9_label <= 2; ++v883_9_label) {
    const Space v883_9_tail = child(s0,v883_9_label);
    if (v883_9_tail.empty()) continue;
    const Path v883_9_head{v883_9_label};
    const Space v884_2 = singleton(v883_9_head);
    const Space v884_3 = intersect(constant_5,v884_2);
    const Space v884_4 = (has_head(v884_3) ? constant_7 : Space{});
    const Space v884_5 = subtract(constant_0,v884_4);
    Space v884_8;
    if (!v884_5.empty()) {
      const Path v885_6 = concat_path(p0,v883_9_head);
      Space v885_7_result;
      for (int v885_7_label = 1; v885_7_label <= 2; ++v885_7_label) {
        const Space v885_7_tail = child(v883_9_tail,v885_7_label);
        if (v885_7_tail.empty()) continue;
        const Path v885_7_head{v885_7_label};
        const Space v886_2 = singleton(v885_7_head);
        const Space v886_3 = intersect(constant_5,v886_2);
        const Space v886_4 = (has_head(v886_3) ? constant_7 : Space{});
        const Space v886_5 = subtract(constant_0,v886_4);
        Space v886_8;
        if (!v886_5.empty()) {
          const Path v887_6 = concat_path(v885_6,v885_7_head);
          const Space v887_7 = routine_140(c, v887_6, v885_7_tail);
          v886_8 = compose(v886_5,v887_7);
        }
        const Space v886_9 = intersect(constant_5,v886_2);
        const Space v886_10 = (has_head(v886_9) ? constant_7 : Space{});
        Space v886_12;
        if (!v886_10.empty()) {
          const Path v888_6 = concat_path(v885_6,v885_7_head);
          const Space v888_11 = routine_141(c, v888_6, v885_7_tail);
          v886_12 = compose(v886_10,v888_11);
        }
        const Space v886_13 = unite(v886_8,v886_12);
        v885_7_result = unite(v885_7_result,v886_13);
      }
      const Space v885_7 = std::move(v885_7_result);
      v884_8 = compose(v884_5,v885_7);
    }
    const Space v884_9 = intersect(constant_5,v884_2);
    const Space v884_10 = (has_head(v884_9) ? constant_7 : Space{});
    const Space v884_11 = compose(v884_10,constant_10);
    const Space v884_12 = unite(v884_8,v884_11);
    v883_9_result = unite(v883_9_result,v884_12);
  }
  const Space v883_9 = std::move(v883_9_result);
  return v883_9;
}

static Space routine_95(Context& c, const Path& p0, const Space& s0) {
  return constant_10;
}

static Space routine_96(Context& c, const Path& p0, const Space& s0) {
  Space v890_11_result;
  for (int v890_11_label = 1; v890_11_label <= 2; ++v890_11_label) {
    const Space v890_11_tail = child(s0,v890_11_label);
    if (v890_11_tail.empty()) continue;
    const Path v890_11_head{v890_11_label};
    const Space v891_2 = singleton(v890_11_head);
    const Space v891_3 = intersect(constant_5,v891_2);
    const Space v891_4 = (has_head(v891_3) ? constant_7 : Space{});
    const Space v891_5 = subtract(constant_0,v891_4);
    Space v891_8;
    if (!v891_5.empty()) {
      const Path v892_6 = concat_path(p0,v890_11_head);
      Space v892_7_result;
      for (int v892_7_label = 1; v892_7_label <= 2; ++v892_7_label) {
        const Space v892_7_tail = child(v890_11_tail,v892_7_label);
        if (v892_7_tail.empty()) continue;
        const Path v892_7_head{v892_7_label};
        const Space v893_2 = singleton(v892_7_head);
        const Space v893_3 = intersect(constant_5,v893_2);
        const Space v893_4 = (has_head(v893_3) ? constant_7 : Space{});
        const Space v893_5 = subtract(constant_0,v893_4);
        Space v893_8;
        if (!v893_5.empty()) {
          const Path v894_6 = concat_path(v892_6,v892_7_head);
          const Space v894_7 = routine_142(c, v894_6, v892_7_tail);
          v893_8 = compose(v893_5,v894_7);
        }
        const Space v893_9 = intersect(constant_5,v893_2);
        const Space v893_10 = (has_head(v893_9) ? constant_7 : Space{});
        Space v893_12;
        if (!v893_10.empty()) {
          const Path v895_6 = concat_path(v892_6,v892_7_head);
          const Space v895_11 = routine_143(c, v895_6, v892_7_tail);
          v893_12 = compose(v893_10,v895_11);
        }
        const Space v893_13 = unite(v893_8,v893_12);
        v892_7_result = unite(v892_7_result,v893_13);
      }
      const Space v892_7 = std::move(v892_7_result);
      v891_8 = compose(v891_5,v892_7);
    }
    const Space v891_9 = intersect(constant_5,v891_2);
    const Space v891_10 = (has_head(v891_9) ? constant_7 : Space{});
    Space v891_12;
    if (!v891_10.empty()) {
      const Path v896_6 = concat_path(p0,v890_11_head);
      Space v896_11_result;
      for (int v896_11_label = 1; v896_11_label <= 2; ++v896_11_label) {
        const Space v896_11_tail = child(v890_11_tail,v896_11_label);
        if (v896_11_tail.empty()) continue;
        const Path v896_11_head{v896_11_label};
        const Space v897_2 = singleton(v896_11_head);
        const Space v897_3 = intersect(constant_5,v897_2);
        const Space v897_4 = (has_head(v897_3) ? constant_7 : Space{});
        const Space v897_5 = subtract(constant_0,v897_4);
        Space v897_8;
        if (!v897_5.empty()) {
          const Path v898_6 = concat_path(v896_6,v896_11_head);
          const Space v898_7 = routine_142(c, v898_6, v896_11_tail);
          v897_8 = compose(v897_5,v898_7);
        }
        const Space v897_9 = intersect(constant_5,v897_2);
        const Space v897_10 = (has_head(v897_9) ? constant_7 : Space{});
        Space v897_12;
        if (!v897_10.empty()) {
          const Path v899_6 = concat_path(v896_6,v896_11_head);
          const Space v899_11 = routine_98(c, v899_6, v896_11_tail);
          v897_12 = compose(v897_10,v899_11);
        }
        const Space v897_13 = unite(v897_8,v897_12);
        v896_11_result = unite(v896_11_result,v897_13);
      }
      const Space v896_11 = std::move(v896_11_result);
      v891_12 = compose(v891_10,v896_11);
    }
    const Space v891_13 = unite(v891_8,v891_12);
    v890_11_result = unite(v890_11_result,v891_13);
  }
  const Space v890_11 = std::move(v890_11_result);
  return v890_11;
}

static Space routine_97(Context& c, const Path& p0, const Space& s0) {
  Space v900_9_result;
  for (int v900_9_label = 1; v900_9_label <= 2; ++v900_9_label) {
    const Space v900_9_tail = child(s0,v900_9_label);
    if (v900_9_tail.empty()) continue;
    const Path v900_9_head{v900_9_label};
    const Space v901_2 = singleton(v900_9_head);
    const Space v901_3 = intersect(constant_5,v901_2);
    const Space v901_4 = (has_head(v901_3) ? constant_7 : Space{});
    const Space v901_5 = subtract(constant_0,v901_4);
    Space v901_8;
    if (!v901_5.empty()) {
      const Path v902_6 = concat_path(p0,v900_9_head);
      Space v902_7_result;
      for (int v902_7_label = 1; v902_7_label <= 2; ++v902_7_label) {
        const Space v902_7_tail = child(v900_9_tail,v902_7_label);
        if (v902_7_tail.empty()) continue;
        const Path v902_7_head{v902_7_label};
        const Space v903_2 = singleton(v902_7_head);
        const Space v903_3 = intersect(constant_5,v903_2);
        const Space v903_4 = (has_head(v903_3) ? constant_7 : Space{});
        const Space v903_5 = subtract(constant_0,v903_4);
        Space v903_8;
        if (!v903_5.empty()) {
          const Path v904_6 = concat_path(v902_6,v902_7_head);
          const Space v904_7 = routine_142(c, v904_6, v902_7_tail);
          v903_8 = compose(v903_5,v904_7);
        }
        const Space v903_9 = intersect(constant_5,v903_2);
        const Space v903_10 = (has_head(v903_9) ? constant_7 : Space{});
        Space v903_12;
        if (!v903_10.empty()) {
          const Path v905_6 = concat_path(v902_6,v902_7_head);
          const Space v905_11 = routine_143(c, v905_6, v902_7_tail);
          v903_12 = compose(v903_10,v905_11);
        }
        const Space v903_13 = unite(v903_8,v903_12);
        v902_7_result = unite(v902_7_result,v903_13);
      }
      const Space v902_7 = std::move(v902_7_result);
      v901_8 = compose(v901_5,v902_7);
    }
    const Space v901_9 = intersect(constant_5,v901_2);
    const Space v901_10 = (has_head(v901_9) ? constant_7 : Space{});
    const Space v901_11 = compose(v901_10,constant_10);
    const Space v901_12 = unite(v901_8,v901_11);
    v900_9_result = unite(v900_9_result,v901_12);
  }
  const Space v900_9 = std::move(v900_9_result);
  return v900_9;
}

static Space routine_98(Context& c, const Path& p0, const Space& s0) {
  return constant_10;
}

static Space routine_99(Context& c, const Path& p0, const Space& s0) {
  Space v907_11_result;
  for (int v907_11_label = 1; v907_11_label <= 2; ++v907_11_label) {
    const Space v907_11_tail = child(s0,v907_11_label);
    if (v907_11_tail.empty()) continue;
    const Path v907_11_head{v907_11_label};
    const Space v908_2 = singleton(v907_11_head);
    const Space v908_3 = intersect(constant_5,v908_2);
    const Space v908_4 = (has_head(v908_3) ? constant_7 : Space{});
    const Space v908_5 = subtract(constant_0,v908_4);
    Space v908_8;
    if (!v908_5.empty()) {
      const Path v909_6 = concat_path(p0,v907_11_head);
      Space v909_7_result;
      for (int v909_7_label = 1; v909_7_label <= 2; ++v909_7_label) {
        const Space v909_7_tail = child(v907_11_tail,v909_7_label);
        if (v909_7_tail.empty()) continue;
        const Path v909_7_head{v909_7_label};
        const Space v910_2 = singleton(v909_7_head);
        const Space v910_3 = intersect(constant_5,v910_2);
        const Space v910_4 = (has_head(v910_3) ? constant_7 : Space{});
        const Space v910_5 = subtract(constant_0,v910_4);
        Space v910_8;
        if (!v910_5.empty()) {
          const Path v911_6 = concat_path(v909_6,v909_7_head);
          const Space v911_7 = routine_144(c, v911_6, v909_7_tail);
          v910_8 = compose(v910_5,v911_7);
        }
        const Space v910_9 = intersect(constant_5,v910_2);
        const Space v910_10 = (has_head(v910_9) ? constant_7 : Space{});
        Space v910_12;
        if (!v910_10.empty()) {
          const Path v912_6 = concat_path(v909_6,v909_7_head);
          const Space v912_11 = routine_145(c, v912_6, v909_7_tail);
          v910_12 = compose(v910_10,v912_11);
        }
        const Space v910_13 = unite(v910_8,v910_12);
        v909_7_result = unite(v909_7_result,v910_13);
      }
      const Space v909_7 = std::move(v909_7_result);
      v908_8 = compose(v908_5,v909_7);
    }
    const Space v908_9 = intersect(constant_5,v908_2);
    const Space v908_10 = (has_head(v908_9) ? constant_7 : Space{});
    Space v908_12;
    if (!v908_10.empty()) {
      const Path v913_6 = concat_path(p0,v907_11_head);
      Space v913_11_result;
      for (int v913_11_label = 1; v913_11_label <= 2; ++v913_11_label) {
        const Space v913_11_tail = child(v907_11_tail,v913_11_label);
        if (v913_11_tail.empty()) continue;
        const Path v913_11_head{v913_11_label};
        const Space v914_2 = singleton(v913_11_head);
        const Space v914_3 = intersect(constant_5,v914_2);
        const Space v914_4 = (has_head(v914_3) ? constant_7 : Space{});
        const Space v914_5 = subtract(constant_0,v914_4);
        Space v914_8;
        if (!v914_5.empty()) {
          const Path v915_6 = concat_path(v913_6,v913_11_head);
          const Space v915_7 = routine_144(c, v915_6, v913_11_tail);
          v914_8 = compose(v914_5,v915_7);
        }
        const Space v914_9 = intersect(constant_5,v914_2);
        const Space v914_10 = (has_head(v914_9) ? constant_7 : Space{});
        Space v914_12;
        if (!v914_10.empty()) {
          const Path v916_6 = concat_path(v913_6,v913_11_head);
          const Space v916_11 = routine_101(c, v916_6, v913_11_tail);
          v914_12 = compose(v914_10,v916_11);
        }
        const Space v914_13 = unite(v914_8,v914_12);
        v913_11_result = unite(v913_11_result,v914_13);
      }
      const Space v913_11 = std::move(v913_11_result);
      v908_12 = compose(v908_10,v913_11);
    }
    const Space v908_13 = unite(v908_8,v908_12);
    v907_11_result = unite(v907_11_result,v908_13);
  }
  const Space v907_11 = std::move(v907_11_result);
  return v907_11;
}

static Space routine_100(Context& c, const Path& p0, const Space& s0) {
  Space v917_8_result;
  for (int v917_8_label = 1; v917_8_label <= 2; ++v917_8_label) {
    const Space v917_8_tail = child(s0,v917_8_label);
    if (v917_8_tail.empty()) continue;
    const Path v917_8_head{v917_8_label};
    const Space v918_2 = singleton(v917_8_head);
    const Space v918_3 = intersect(constant_5,v918_2);
    const Space v918_4 = (has_head(v918_3) ? constant_7 : Space{});
    const Space v918_5 = subtract(constant_0,v918_4);
    Space v918_8;
    if (!v918_5.empty()) {
      const Path v919_6 = concat_path(p0,v917_8_head);
      Space v919_7_result;
      for (int v919_7_label = 1; v919_7_label <= 2; ++v919_7_label) {
        const Space v919_7_tail = child(v917_8_tail,v919_7_label);
        if (v919_7_tail.empty()) continue;
        const Path v919_7_head{v919_7_label};
        const Space v920_2 = singleton(v919_7_head);
        const Space v920_3 = intersect(constant_5,v920_2);
        const Space v920_4 = (has_head(v920_3) ? constant_7 : Space{});
        const Space v920_5 = subtract(constant_0,v920_4);
        Space v920_8;
        if (!v920_5.empty()) {
          const Path v921_6 = concat_path(v919_6,v919_7_head);
          const Space v921_7 = routine_144(c, v921_6, v919_7_tail);
          v920_8 = compose(v920_5,v921_7);
        }
        const Space v920_9 = intersect(constant_5,v920_2);
        const Space v920_10 = (has_head(v920_9) ? constant_7 : Space{});
        Space v920_12;
        if (!v920_10.empty()) {
          const Path v922_6 = concat_path(v919_6,v919_7_head);
          const Space v922_11 = routine_145(c, v922_6, v919_7_tail);
          v920_12 = compose(v920_10,v922_11);
        }
        const Space v920_13 = unite(v920_8,v920_12);
        v919_7_result = unite(v919_7_result,v920_13);
      }
      const Space v919_7 = std::move(v919_7_result);
      v918_8 = compose(v918_5,v919_7);
    }
    const Space v918_9 = intersect(constant_5,v918_2);
    const Space v918_10 = (has_head(v918_9) ? constant_7 : Space{});
    const Space v918_11 = compose(v918_10,v917_8_tail);
    const Space v918_12 = unite(v918_8,v918_11);
    v917_8_result = unite(v917_8_result,v918_12);
  }
  const Space v917_8 = std::move(v917_8_result);
  return v917_8;
}

static Space routine_101(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v924_13_result;
  for (int v924_13_label = 1; v924_13_label <= 2; ++v924_13_label) {
    const Space v924_13_tail = child(s0,v924_13_label);
    if (v924_13_tail.empty()) continue;
    const Path v924_13_head{v924_13_label};
    const Space v925_2 = singleton(v924_13_head);
    const Space v925_3 = intersect(constant_5,v925_2);
    const Space v925_4 = (has_head(v925_3) ? constant_7 : Space{});
    const Space v925_5 = subtract(constant_0,v925_4);
    Space v925_8;
    if (!v925_5.empty()) {
      const Path v926_6 = concat_path(p0,v924_13_head);
      Space v926_7_result;
      for (int v926_7_label = 1; v926_7_label <= 2; ++v926_7_label) {
        const Space v926_7_tail = child(v924_13_tail,v926_7_label);
        if (v926_7_tail.empty()) continue;
        const Path v926_7_head{v926_7_label};
        const Space v927_2 = singleton(v926_7_head);
        const Space v927_3 = intersect(constant_5,v927_2);
        const Space v927_4 = (has_head(v927_3) ? constant_7 : Space{});
        const Space v927_5 = subtract(constant_0,v927_4);
        Space v927_8;
        if (!v927_5.empty()) {
          const Path v928_6 = concat_path(v926_6,v926_7_head);
          const Space v928_7 = routine_146(c, v928_6, p1, v926_7_tail, s1);
          v927_8 = compose(v927_5,v928_7);
        }
        const Space v927_9 = intersect(constant_5,v927_2);
        const Space v927_10 = (has_head(v927_9) ? constant_7 : Space{});
        Space v927_12;
        if (!v927_10.empty()) {
          const Path v929_6 = concat_path(v926_6,v926_7_head);
          const Space v929_11 = routine_147(c, v929_6, p1, v926_7_tail, s1);
          v927_12 = compose(v927_10,v929_11);
        }
        const Space v927_13 = unite(v927_8,v927_12);
        v926_7_result = unite(v926_7_result,v927_13);
      }
      const Space v926_7 = std::move(v926_7_result);
      v925_8 = compose(v925_5,v926_7);
    }
    const Space v925_9 = intersect(constant_5,v925_2);
    const Space v925_10 = (has_head(v925_9) ? constant_7 : Space{});
    Space v925_12;
    if (!v925_10.empty()) {
      const Path v930_6 = concat_path(p0,v924_13_head);
      Space v930_11_result;
      for (int v930_11_label = 1; v930_11_label <= 2; ++v930_11_label) {
        const Space v930_11_tail = child(v924_13_tail,v930_11_label);
        if (v930_11_tail.empty()) continue;
        const Path v930_11_head{v930_11_label};
        const Space v931_2 = singleton(v930_11_head);
        const Space v931_3 = intersect(constant_5,v931_2);
        const Space v931_4 = (has_head(v931_3) ? constant_7 : Space{});
        const Space v931_5 = subtract(constant_0,v931_4);
        Space v931_8;
        if (!v931_5.empty()) {
          const Path v932_6 = concat_path(v930_6,v930_11_head);
          const Space v932_7 = routine_146(c, v932_6, p1, v930_11_tail, s1);
          v931_8 = compose(v931_5,v932_7);
        }
        const Space v931_9 = intersect(constant_5,v931_2);
        const Space v931_10 = (has_head(v931_9) ? constant_7 : Space{});
        Space v931_12;
        if (!v931_10.empty()) {
          const Path v933_6 = concat_path(v930_6,v930_11_head);
          const Space v933_11 = routine_48(c, v933_6, p1, v930_11_tail, s1);
          v931_12 = compose(v931_10,v933_11);
        }
        const Space v931_13 = unite(v931_8,v931_12);
        v930_11_result = unite(v930_11_result,v931_13);
      }
      const Space v930_11 = std::move(v930_11_result);
      v925_12 = compose(v925_10,v930_11);
    }
    const Space v925_13 = unite(v925_8,v925_12);
    v924_13_result = unite(v924_13_result,v925_13);
  }
  const Space v924_13 = std::move(v924_13_result);
  return v924_13;
}

static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v934_8 = unwrap(constant_9,p1);
  const Space v934_10 = unwrap(constant_9,p0);
  const Space v934_12 = unwrap(s1,constant_8);
  const Space v934_14 = unwrap(constant_9,p1);
  const Space v934_16 = unwrap(constant_9,p0);
  Space v934_29_result;
  for (int v934_29_label = 1; v934_29_label <= 2; ++v934_29_label) {
    const Space v934_29_tail = child(s0,v934_29_label);
    if (v934_29_tail.empty()) continue;
    const Path v934_29_head{v934_29_label};
    const Space v935_2 = singleton(v934_29_head);
    const Space v935_3 = intersect(constant_5,v935_2);
    const Space v935_4 = (has_head(v935_3) ? constant_7 : Space{});
    const Space v935_5 = subtract(constant_0,v935_4);
    Space v935_8;
    if (!v935_5.empty()) {
      const Path v936_6 = concat_path(p0,v934_29_head);
      Space v936_7_result;
      for (int v936_7_label = 1; v936_7_label <= 2; ++v936_7_label) {
        const Space v936_7_tail = child(v934_29_tail,v936_7_label);
        if (v936_7_tail.empty()) continue;
        const Path v936_7_head{v936_7_label};
        const Space v937_2 = singleton(v936_7_head);
        const Space v937_3 = intersect(constant_5,v937_2);
        const Space v937_4 = (has_head(v937_3) ? constant_7 : Space{});
        const Space v937_5 = subtract(constant_0,v937_4);
        Space v937_8;
        if (!v937_5.empty()) {
          const Path v938_6 = concat_path(v936_6,v936_7_head);
          const Space v938_7 = routine_146(c, v938_6, p1, v936_7_tail, s1);
          v937_8 = compose(v937_5,v938_7);
        }
        const Space v937_9 = intersect(constant_5,v937_2);
        const Space v937_10 = (has_head(v937_9) ? constant_7 : Space{});
        Space v937_12;
        if (!v937_10.empty()) {
          const Path v939_6 = concat_path(v936_6,v936_7_head);
          const Space v939_11 = routine_147(c, v939_6, p1, v936_7_tail, s1);
          v937_12 = compose(v937_10,v939_11);
        }
        const Space v937_13 = unite(v937_8,v937_12);
        v936_7_result = unite(v936_7_result,v937_13);
      }
      const Space v936_7 = std::move(v936_7_result);
      v935_8 = compose(v935_5,v936_7);
    }
    const Space v935_9 = intersect(constant_5,v935_2);
    const Space v935_10 = (has_head(v935_9) ? constant_7 : Space{});
    Space v935_28;
    if (!v935_10.empty()) {
      const Path v940_6 = concat_path(p0,v934_29_head);
      const Space v940_11 = unwrap(v934_10,v934_29_head);
      const Space v940_12 = compose(v934_8,v940_11);
      const Path v940_13 = concat_path(p1,v940_6);
      const Space v940_14 = singleton(v940_13);
      const Space v940_15 = subtract(v940_12,v940_14);
      const Space v940_16 = intersect(v940_15,v934_12);
      const Space v940_17 = routine_51(c, v940_16);
      Space v940_18_result;
      for (int v940_18_label = 1; v940_18_label <= 2; ++v940_18_label) {
        const Space v940_18_tail = child(v940_17,v940_18_label);
        if (v940_18_tail.empty()) continue;
        const Path v940_18_head{v940_18_label};
        const Space v941_2 = singleton(v940_18_head);
        const Space v941_3 = intersect(constant_5,v941_2);
        const Space v941_4 = (has_head(v941_3) ? constant_7 : Space{});
        const Space v941_5 = subtract(constant_0,v941_4);
        Space v941_7;
        if (!v941_5.empty()) {
          const Space v942_6 = routine_52(c, v940_18_head, v940_18_tail);
          v941_7 = compose(v941_5,v942_6);
        }
        const Space v941_8 = intersect(constant_5,v941_2);
        const Space v941_9 = (has_head(v941_8) ? constant_7 : Space{});
        Space v941_11;
        if (!v941_9.empty()) {
          const Space v943_10 = routine_53(c, v940_18_head, v940_18_tail);
          v941_11 = compose(v941_9,v943_10);
        }
        const Space v941_12 = unite(v941_7,v941_11);
        v940_18_result = unite(v940_18_result,v941_12);
      }
      const Space v940_18 = std::move(v940_18_result);
      const Space v940_19 = unwrap(v934_16,v934_29_head);
      const Space v940_20 = compose(v934_14,v940_19);
      const Space v940_21 = subtract(v940_20,v940_14);
      const Space v940_22 = intersect(v940_21,v934_12);
      const Space v940_23 = routine_36(c, v940_22);
      Space v940_24_result;
      for (int v940_24_label = 1; v940_24_label <= 2; ++v940_24_label) {
        const Space v940_24_tail = child(v940_23,v940_24_label);
        if (v940_24_tail.empty()) continue;
        const Path v940_24_head{v940_24_label};
        const Space v944_2 = singleton(v940_24_head);
        const Space v944_3 = intersect(constant_5,v944_2);
        const Space v944_4 = (has_head(v944_3) ? constant_7 : Space{});
        const Space v944_5 = subtract(constant_0,v944_4);
        Space v944_7;
        if (!v944_5.empty()) {
          const Space v945_6 = routine_54(c, v940_24_head, v940_24_tail);
          v944_7 = compose(v944_5,v945_6);
        }
        const Space v944_8 = intersect(constant_5,v944_2);
        const Space v944_9 = (has_head(v944_8) ? constant_7 : Space{});
        Space v944_11;
        if (!v944_9.empty()) {
          const Space v946_10 = routine_55(c, v940_24_head, v940_24_tail);
          v944_11 = compose(v944_9,v946_10);
        }
        const Space v944_12 = unite(v944_7,v944_11);
        v940_24_result = unite(v940_24_result,v944_12);
      }
      const Space v940_24 = std::move(v940_24_result);
      const Space v940_25 = subtract(v940_18,v940_24);
      const Space v940_26 = compose(v940_25,v940_14);
      Space v940_27_result;
      for (int v940_27_label = 1; v940_27_label <= 2; ++v940_27_label) {
        const Space v940_27_tail = child(v940_26,v940_27_label);
        if (v940_27_tail.empty()) continue;
        const Path v940_27_head{v940_27_label};
        const Space v947_2 = singleton(v940_27_head);
        const Space v947_3 = intersect(constant_5,v947_2);
        const Space v947_4 = (has_head(v947_3) ? constant_7 : Space{});
        const Space v947_5 = subtract(constant_0,v947_4);
        Space v947_7;
        if (!v947_5.empty()) {
          const Space v948_6 = routine_56(c, v940_27_head, v940_27_tail);
          v947_7 = compose(v947_5,v948_6);
        }
        const Space v947_8 = intersect(constant_5,v947_2);
        const Space v947_9 = (has_head(v947_8) ? constant_7 : Space{});
        Space v947_11;
        if (!v947_9.empty()) {
          const Space v949_10 = routine_57(c, v940_27_head, v940_27_tail);
          v947_11 = compose(v947_9,v949_10);
        }
        const Space v947_12 = unite(v947_7,v947_11);
        v940_27_result = unite(v940_27_result,v947_12);
      }
      const Space v940_27 = std::move(v940_27_result);
      v935_28 = compose(v935_10,v940_27);
    }
    const Space v935_29 = unite(v935_8,v935_28);
    v934_29_result = unite(v934_29_result,v935_29);
  }
  const Space v934_29 = std::move(v934_29_result);
  return v934_29;
}

static Space routine_104(Context& c, const Path& p0, const Space& s0) {
  Space v950_11_result;
  for (int v950_11_label = 1; v950_11_label <= 2; ++v950_11_label) {
    const Space v950_11_tail = child(s0,v950_11_label);
    if (v950_11_tail.empty()) continue;
    const Path v950_11_head{v950_11_label};
    const Space v951_2 = singleton(v950_11_head);
    const Space v951_3 = intersect(constant_5,v951_2);
    const Space v951_4 = (has_head(v951_3) ? constant_7 : Space{});
    const Space v951_5 = subtract(constant_0,v951_4);
    Space v951_8;
    if (!v951_5.empty()) {
      const Path v952_6 = concat_path(p0,v950_11_head);
      Space v952_7_result;
      for (int v952_7_label = 1; v952_7_label <= 2; ++v952_7_label) {
        const Space v952_7_tail = child(v950_11_tail,v952_7_label);
        if (v952_7_tail.empty()) continue;
        const Path v952_7_head{v952_7_label};
        const Space v953_2 = singleton(v952_7_head);
        const Space v953_3 = intersect(constant_5,v953_2);
        const Space v953_4 = (has_head(v953_3) ? constant_7 : Space{});
        const Space v953_5 = subtract(constant_0,v953_4);
        Space v953_8;
        if (!v953_5.empty()) {
          const Path v954_6 = concat_path(v952_6,v952_7_head);
          const Space v954_7 = routine_148(c, v954_6, v952_7_tail);
          v953_8 = compose(v953_5,v954_7);
        }
        const Space v953_9 = intersect(constant_5,v953_2);
        const Space v953_10 = (has_head(v953_9) ? constant_7 : Space{});
        Space v953_12;
        if (!v953_10.empty()) {
          const Path v955_6 = concat_path(v952_6,v952_7_head);
          const Space v955_11 = routine_149(c, v955_6, v952_7_tail);
          v953_12 = compose(v953_10,v955_11);
        }
        const Space v953_13 = unite(v953_8,v953_12);
        v952_7_result = unite(v952_7_result,v953_13);
      }
      const Space v952_7 = std::move(v952_7_result);
      v951_8 = compose(v951_5,v952_7);
    }
    const Space v951_9 = intersect(constant_5,v951_2);
    const Space v951_10 = (has_head(v951_9) ? constant_7 : Space{});
    Space v951_12;
    if (!v951_10.empty()) {
      const Path v956_6 = concat_path(p0,v950_11_head);
      Space v956_11_result;
      for (int v956_11_label = 1; v956_11_label <= 2; ++v956_11_label) {
        const Space v956_11_tail = child(v950_11_tail,v956_11_label);
        if (v956_11_tail.empty()) continue;
        const Path v956_11_head{v956_11_label};
        const Space v957_2 = singleton(v956_11_head);
        const Space v957_3 = intersect(constant_5,v957_2);
        const Space v957_4 = (has_head(v957_3) ? constant_7 : Space{});
        const Space v957_5 = subtract(constant_0,v957_4);
        Space v957_8;
        if (!v957_5.empty()) {
          const Path v958_6 = concat_path(v956_6,v956_11_head);
          const Space v958_7 = routine_148(c, v958_6, v956_11_tail);
          v957_8 = compose(v957_5,v958_7);
        }
        const Space v957_9 = intersect(constant_5,v957_2);
        const Space v957_10 = (has_head(v957_9) ? constant_7 : Space{});
        Space v957_12;
        if (!v957_10.empty()) {
          const Path v959_6 = concat_path(v956_6,v956_11_head);
          const Space v959_11 = routine_95(c, v959_6, v956_11_tail);
          v957_12 = compose(v957_10,v959_11);
        }
        const Space v957_13 = unite(v957_8,v957_12);
        v956_11_result = unite(v956_11_result,v957_13);
      }
      const Space v956_11 = std::move(v956_11_result);
      v951_12 = compose(v951_10,v956_11);
    }
    const Space v951_13 = unite(v951_8,v951_12);
    v950_11_result = unite(v950_11_result,v951_13);
  }
  const Space v950_11 = std::move(v950_11_result);
  return v950_11;
}

static Space routine_105(Context& c, const Path& p0, const Space& s0) {
  Space v960_9_result;
  for (int v960_9_label = 1; v960_9_label <= 2; ++v960_9_label) {
    const Space v960_9_tail = child(s0,v960_9_label);
    if (v960_9_tail.empty()) continue;
    const Path v960_9_head{v960_9_label};
    const Space v961_2 = singleton(v960_9_head);
    const Space v961_3 = intersect(constant_5,v961_2);
    const Space v961_4 = (has_head(v961_3) ? constant_7 : Space{});
    const Space v961_5 = subtract(constant_0,v961_4);
    Space v961_8;
    if (!v961_5.empty()) {
      const Path v962_6 = concat_path(p0,v960_9_head);
      Space v962_7_result;
      for (int v962_7_label = 1; v962_7_label <= 2; ++v962_7_label) {
        const Space v962_7_tail = child(v960_9_tail,v962_7_label);
        if (v962_7_tail.empty()) continue;
        const Path v962_7_head{v962_7_label};
        const Space v963_2 = singleton(v962_7_head);
        const Space v963_3 = intersect(constant_5,v963_2);
        const Space v963_4 = (has_head(v963_3) ? constant_7 : Space{});
        const Space v963_5 = subtract(constant_0,v963_4);
        Space v963_8;
        if (!v963_5.empty()) {
          const Path v964_6 = concat_path(v962_6,v962_7_head);
          const Space v964_7 = routine_148(c, v964_6, v962_7_tail);
          v963_8 = compose(v963_5,v964_7);
        }
        const Space v963_9 = intersect(constant_5,v963_2);
        const Space v963_10 = (has_head(v963_9) ? constant_7 : Space{});
        Space v963_12;
        if (!v963_10.empty()) {
          const Path v965_6 = concat_path(v962_6,v962_7_head);
          const Space v965_11 = routine_149(c, v965_6, v962_7_tail);
          v963_12 = compose(v963_10,v965_11);
        }
        const Space v963_13 = unite(v963_8,v963_12);
        v962_7_result = unite(v962_7_result,v963_13);
      }
      const Space v962_7 = std::move(v962_7_result);
      v961_8 = compose(v961_5,v962_7);
    }
    const Space v961_9 = intersect(constant_5,v961_2);
    const Space v961_10 = (has_head(v961_9) ? constant_7 : Space{});
    const Space v961_11 = compose(v961_10,constant_10);
    const Space v961_12 = unite(v961_8,v961_11);
    v960_9_result = unite(v960_9_result,v961_12);
  }
  const Space v960_9 = std::move(v960_9_result);
  return v960_9;
}

static Space routine_106(Context& c, const Path& p0, const Space& s0) {
  Space v966_11_result;
  for (int v966_11_label = 1; v966_11_label <= 2; ++v966_11_label) {
    const Space v966_11_tail = child(s0,v966_11_label);
    if (v966_11_tail.empty()) continue;
    const Path v966_11_head{v966_11_label};
    const Space v967_2 = singleton(v966_11_head);
    const Space v967_3 = intersect(constant_5,v967_2);
    const Space v967_4 = (has_head(v967_3) ? constant_7 : Space{});
    const Space v967_5 = subtract(constant_0,v967_4);
    Space v967_8;
    if (!v967_5.empty()) {
      const Path v968_6 = concat_path(p0,v966_11_head);
      Space v968_7_result;
      for (int v968_7_label = 1; v968_7_label <= 2; ++v968_7_label) {
        const Space v968_7_tail = child(v966_11_tail,v968_7_label);
        if (v968_7_tail.empty()) continue;
        const Path v968_7_head{v968_7_label};
        const Space v969_2 = singleton(v968_7_head);
        const Space v969_3 = intersect(constant_5,v969_2);
        const Space v969_4 = (has_head(v969_3) ? constant_7 : Space{});
        const Space v969_5 = subtract(constant_0,v969_4);
        Space v969_8;
        if (!v969_5.empty()) {
          const Path v970_6 = concat_path(v968_6,v968_7_head);
          const Space v970_7 = routine_150(c, v970_6, v968_7_tail);
          v969_8 = compose(v969_5,v970_7);
        }
        const Space v969_9 = intersect(constant_5,v969_2);
        const Space v969_10 = (has_head(v969_9) ? constant_7 : Space{});
        Space v969_12;
        if (!v969_10.empty()) {
          const Path v971_6 = concat_path(v968_6,v968_7_head);
          const Space v971_11 = routine_151(c, v971_6, v968_7_tail);
          v969_12 = compose(v969_10,v971_11);
        }
        const Space v969_13 = unite(v969_8,v969_12);
        v968_7_result = unite(v968_7_result,v969_13);
      }
      const Space v968_7 = std::move(v968_7_result);
      v967_8 = compose(v967_5,v968_7);
    }
    const Space v967_9 = intersect(constant_5,v967_2);
    const Space v967_10 = (has_head(v967_9) ? constant_7 : Space{});
    Space v967_12;
    if (!v967_10.empty()) {
      const Path v972_6 = concat_path(p0,v966_11_head);
      Space v972_11_result;
      for (int v972_11_label = 1; v972_11_label <= 2; ++v972_11_label) {
        const Space v972_11_tail = child(v966_11_tail,v972_11_label);
        if (v972_11_tail.empty()) continue;
        const Path v972_11_head{v972_11_label};
        const Space v973_2 = singleton(v972_11_head);
        const Space v973_3 = intersect(constant_5,v973_2);
        const Space v973_4 = (has_head(v973_3) ? constant_7 : Space{});
        const Space v973_5 = subtract(constant_0,v973_4);
        Space v973_8;
        if (!v973_5.empty()) {
          const Path v974_6 = concat_path(v972_6,v972_11_head);
          const Space v974_7 = routine_150(c, v974_6, v972_11_tail);
          v973_8 = compose(v973_5,v974_7);
        }
        const Space v973_9 = intersect(constant_5,v973_2);
        const Space v973_10 = (has_head(v973_9) ? constant_7 : Space{});
        Space v973_12;
        if (!v973_10.empty()) {
          const Path v975_6 = concat_path(v972_6,v972_11_head);
          const Space v975_11 = routine_98(c, v975_6, v972_11_tail);
          v973_12 = compose(v973_10,v975_11);
        }
        const Space v973_13 = unite(v973_8,v973_12);
        v972_11_result = unite(v972_11_result,v973_13);
      }
      const Space v972_11 = std::move(v972_11_result);
      v967_12 = compose(v967_10,v972_11);
    }
    const Space v967_13 = unite(v967_8,v967_12);
    v966_11_result = unite(v966_11_result,v967_13);
  }
  const Space v966_11 = std::move(v966_11_result);
  return v966_11;
}

static Space routine_107(Context& c, const Path& p0, const Space& s0) {
  Space v976_9_result;
  for (int v976_9_label = 1; v976_9_label <= 2; ++v976_9_label) {
    const Space v976_9_tail = child(s0,v976_9_label);
    if (v976_9_tail.empty()) continue;
    const Path v976_9_head{v976_9_label};
    const Space v977_2 = singleton(v976_9_head);
    const Space v977_3 = intersect(constant_5,v977_2);
    const Space v977_4 = (has_head(v977_3) ? constant_7 : Space{});
    const Space v977_5 = subtract(constant_0,v977_4);
    Space v977_8;
    if (!v977_5.empty()) {
      const Path v978_6 = concat_path(p0,v976_9_head);
      Space v978_7_result;
      for (int v978_7_label = 1; v978_7_label <= 2; ++v978_7_label) {
        const Space v978_7_tail = child(v976_9_tail,v978_7_label);
        if (v978_7_tail.empty()) continue;
        const Path v978_7_head{v978_7_label};
        const Space v979_2 = singleton(v978_7_head);
        const Space v979_3 = intersect(constant_5,v979_2);
        const Space v979_4 = (has_head(v979_3) ? constant_7 : Space{});
        const Space v979_5 = subtract(constant_0,v979_4);
        Space v979_8;
        if (!v979_5.empty()) {
          const Path v980_6 = concat_path(v978_6,v978_7_head);
          const Space v980_7 = routine_150(c, v980_6, v978_7_tail);
          v979_8 = compose(v979_5,v980_7);
        }
        const Space v979_9 = intersect(constant_5,v979_2);
        const Space v979_10 = (has_head(v979_9) ? constant_7 : Space{});
        Space v979_12;
        if (!v979_10.empty()) {
          const Path v981_6 = concat_path(v978_6,v978_7_head);
          const Space v981_11 = routine_151(c, v981_6, v978_7_tail);
          v979_12 = compose(v979_10,v981_11);
        }
        const Space v979_13 = unite(v979_8,v979_12);
        v978_7_result = unite(v978_7_result,v979_13);
      }
      const Space v978_7 = std::move(v978_7_result);
      v977_8 = compose(v977_5,v978_7);
    }
    const Space v977_9 = intersect(constant_5,v977_2);
    const Space v977_10 = (has_head(v977_9) ? constant_7 : Space{});
    const Space v977_11 = compose(v977_10,constant_10);
    const Space v977_12 = unite(v977_8,v977_11);
    v976_9_result = unite(v976_9_result,v977_12);
  }
  const Space v976_9 = std::move(v976_9_result);
  return v976_9;
}

static Space routine_108(Context& c, const Path& p0, const Space& s0) {
  Space v982_11_result;
  for (int v982_11_label = 1; v982_11_label <= 2; ++v982_11_label) {
    const Space v982_11_tail = child(s0,v982_11_label);
    if (v982_11_tail.empty()) continue;
    const Path v982_11_head{v982_11_label};
    const Space v983_2 = singleton(v982_11_head);
    const Space v983_3 = intersect(constant_5,v983_2);
    const Space v983_4 = (has_head(v983_3) ? constant_7 : Space{});
    const Space v983_5 = subtract(constant_0,v983_4);
    Space v983_8;
    if (!v983_5.empty()) {
      const Path v984_6 = concat_path(p0,v982_11_head);
      Space v984_7_result;
      for (int v984_7_label = 1; v984_7_label <= 2; ++v984_7_label) {
        const Space v984_7_tail = child(v982_11_tail,v984_7_label);
        if (v984_7_tail.empty()) continue;
        const Path v984_7_head{v984_7_label};
        const Space v985_2 = singleton(v984_7_head);
        const Space v985_3 = intersect(constant_5,v985_2);
        const Space v985_4 = (has_head(v985_3) ? constant_7 : Space{});
        const Space v985_5 = subtract(constant_0,v985_4);
        Space v985_8;
        if (!v985_5.empty()) {
          const Path v986_6 = concat_path(v984_6,v984_7_head);
          const Space v986_7 = routine_152(c, v986_6, v984_7_tail);
          v985_8 = compose(v985_5,v986_7);
        }
        const Space v985_9 = intersect(constant_5,v985_2);
        const Space v985_10 = (has_head(v985_9) ? constant_7 : Space{});
        Space v985_12;
        if (!v985_10.empty()) {
          const Path v987_6 = concat_path(v984_6,v984_7_head);
          const Space v987_11 = routine_153(c, v987_6, v984_7_tail);
          v985_12 = compose(v985_10,v987_11);
        }
        const Space v985_13 = unite(v985_8,v985_12);
        v984_7_result = unite(v984_7_result,v985_13);
      }
      const Space v984_7 = std::move(v984_7_result);
      v983_8 = compose(v983_5,v984_7);
    }
    const Space v983_9 = intersect(constant_5,v983_2);
    const Space v983_10 = (has_head(v983_9) ? constant_7 : Space{});
    Space v983_12;
    if (!v983_10.empty()) {
      const Path v988_6 = concat_path(p0,v982_11_head);
      Space v988_11_result;
      for (int v988_11_label = 1; v988_11_label <= 2; ++v988_11_label) {
        const Space v988_11_tail = child(v982_11_tail,v988_11_label);
        if (v988_11_tail.empty()) continue;
        const Path v988_11_head{v988_11_label};
        const Space v989_2 = singleton(v988_11_head);
        const Space v989_3 = intersect(constant_5,v989_2);
        const Space v989_4 = (has_head(v989_3) ? constant_7 : Space{});
        const Space v989_5 = subtract(constant_0,v989_4);
        Space v989_8;
        if (!v989_5.empty()) {
          const Path v990_6 = concat_path(v988_6,v988_11_head);
          const Space v990_7 = routine_152(c, v990_6, v988_11_tail);
          v989_8 = compose(v989_5,v990_7);
        }
        const Space v989_9 = intersect(constant_5,v989_2);
        const Space v989_10 = (has_head(v989_9) ? constant_7 : Space{});
        Space v989_12;
        if (!v989_10.empty()) {
          const Path v991_6 = concat_path(v988_6,v988_11_head);
          const Space v991_11 = routine_101(c, v991_6, v988_11_tail);
          v989_12 = compose(v989_10,v991_11);
        }
        const Space v989_13 = unite(v989_8,v989_12);
        v988_11_result = unite(v988_11_result,v989_13);
      }
      const Space v988_11 = std::move(v988_11_result);
      v983_12 = compose(v983_10,v988_11);
    }
    const Space v983_13 = unite(v983_8,v983_12);
    v982_11_result = unite(v982_11_result,v983_13);
  }
  const Space v982_11 = std::move(v982_11_result);
  return v982_11;
}

static Space routine_109(Context& c, const Path& p0, const Space& s0) {
  Space v992_8_result;
  for (int v992_8_label = 1; v992_8_label <= 2; ++v992_8_label) {
    const Space v992_8_tail = child(s0,v992_8_label);
    if (v992_8_tail.empty()) continue;
    const Path v992_8_head{v992_8_label};
    const Space v993_2 = singleton(v992_8_head);
    const Space v993_3 = intersect(constant_5,v993_2);
    const Space v993_4 = (has_head(v993_3) ? constant_7 : Space{});
    const Space v993_5 = subtract(constant_0,v993_4);
    Space v993_8;
    if (!v993_5.empty()) {
      const Path v994_6 = concat_path(p0,v992_8_head);
      Space v994_7_result;
      for (int v994_7_label = 1; v994_7_label <= 2; ++v994_7_label) {
        const Space v994_7_tail = child(v992_8_tail,v994_7_label);
        if (v994_7_tail.empty()) continue;
        const Path v994_7_head{v994_7_label};
        const Space v995_2 = singleton(v994_7_head);
        const Space v995_3 = intersect(constant_5,v995_2);
        const Space v995_4 = (has_head(v995_3) ? constant_7 : Space{});
        const Space v995_5 = subtract(constant_0,v995_4);
        Space v995_8;
        if (!v995_5.empty()) {
          const Path v996_6 = concat_path(v994_6,v994_7_head);
          const Space v996_7 = routine_152(c, v996_6, v994_7_tail);
          v995_8 = compose(v995_5,v996_7);
        }
        const Space v995_9 = intersect(constant_5,v995_2);
        const Space v995_10 = (has_head(v995_9) ? constant_7 : Space{});
        Space v995_12;
        if (!v995_10.empty()) {
          const Path v997_6 = concat_path(v994_6,v994_7_head);
          const Space v997_11 = routine_153(c, v997_6, v994_7_tail);
          v995_12 = compose(v995_10,v997_11);
        }
        const Space v995_13 = unite(v995_8,v995_12);
        v994_7_result = unite(v994_7_result,v995_13);
      }
      const Space v994_7 = std::move(v994_7_result);
      v993_8 = compose(v993_5,v994_7);
    }
    const Space v993_9 = intersect(constant_5,v993_2);
    const Space v993_10 = (has_head(v993_9) ? constant_7 : Space{});
    const Space v993_11 = compose(v993_10,v992_8_tail);
    const Space v993_12 = unite(v993_8,v993_11);
    v992_8_result = unite(v992_8_result,v993_12);
  }
  const Space v992_8 = std::move(v992_8_result);
  return v992_8;
}

static Space routine_110(Context& c, const Path& p0, const Space& s0) {
  Space v998_4_result;
  for (int v998_4_label = 1; v998_4_label <= 2; ++v998_4_label) {
    const Space v998_4_tail = child(s0,v998_4_label);
    if (v998_4_tail.empty()) continue;
    const Path v998_4_head{v998_4_label};
    const Space v999_2 = singleton(v998_4_head);
    const Space v999_3 = intersect(constant_5,v999_2);
    const Space v999_4 = (has_head(v999_3) ? constant_7 : Space{});
    Space v999_7;
    if (!v999_4.empty()) {
      const Path v1000_5 = concat_path(p0,v998_4_head);
      Space v1000_6_result;
      for (int v1000_6_label = 1; v1000_6_label <= 2; ++v1000_6_label) {
        const Space v1000_6_tail = child(v998_4_tail,v1000_6_label);
        if (v1000_6_tail.empty()) continue;
        const Path v1000_6_head{v1000_6_label};
        const Space v1001_2 = singleton(v1000_6_head);
        const Space v1001_3 = intersect(constant_5,v1001_2);
        const Space v1001_4 = (has_head(v1001_3) ? constant_7 : Space{});
        Space v1001_7;
        if (!v1001_4.empty()) {
          const Path v1002_5 = concat_path(v1000_5,v1000_6_head);
          const Space v1002_6 = routine_9(c, v1002_5, v1000_6_tail);
          v1001_7 = compose(v1001_4,v1002_6);
        }
        v1000_6_result = unite(v1000_6_result,v1001_7);
      }
      const Space v1000_6 = std::move(v1000_6_result);
      v999_7 = compose(v999_4,v1000_6);
    }
    v998_4_result = unite(v998_4_result,v999_7);
  }
  const Space v998_4 = std::move(v998_4_result);
  return v998_4;
}

static Space routine_111(Context& c, const Path& p0, const Space& s0) {
  Space v1003_6_result;
  for (int v1003_6_label = 1; v1003_6_label <= 2; ++v1003_6_label) {
    const Space v1003_6_tail = child(s0,v1003_6_label);
    if (v1003_6_tail.empty()) continue;
    const Path v1003_6_head{v1003_6_label};
    const Space v1004_2 = singleton(v1003_6_head);
    const Space v1004_3 = intersect(constant_5,v1004_2);
    const Space v1004_4 = (has_head(v1004_3) ? constant_7 : Space{});
    Space v1004_7;
    if (!v1004_4.empty()) {
      const Path v1005_5 = concat_path(p0,v1003_6_head);
      Space v1005_6_result;
      for (int v1005_6_label = 1; v1005_6_label <= 2; ++v1005_6_label) {
        const Space v1005_6_tail = child(v1003_6_tail,v1005_6_label);
        if (v1005_6_tail.empty()) continue;
        const Path v1005_6_head{v1005_6_label};
        const Space v1006_2 = singleton(v1005_6_head);
        const Space v1006_3 = intersect(constant_5,v1006_2);
        const Space v1006_4 = (has_head(v1006_3) ? constant_7 : Space{});
        const Space v1006_5 = subtract(constant_0,v1006_4);
        Space v1006_7;
        if (!v1006_5.empty()) {
          const Space v1007_6 = routine_10(c, v1005_6_head, v1005_5, v1005_6_tail);
          v1006_7 = compose(v1006_5,v1007_6);
        }
        const Space v1006_8 = intersect(constant_5,v1006_2);
        const Space v1006_9 = (has_head(v1006_8) ? constant_7 : Space{});
        Space v1006_11;
        if (!v1006_9.empty()) {
          const Space v1008_10 = routine_11(c, v1005_6_head, v1005_5, v1005_6_tail);
          v1006_11 = compose(v1006_9,v1008_10);
        }
        const Space v1006_12 = unite(v1006_7,v1006_11);
        v1005_6_result = unite(v1005_6_result,v1006_12);
      }
      const Space v1005_6 = std::move(v1005_6_result);
      v1004_7 = compose(v1004_4,v1005_6);
    }
    v1003_6_result = unite(v1003_6_result,v1004_7);
  }
  const Space v1003_6 = std::move(v1003_6_result);
  return v1003_6;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1009_12_result;
  for (int v1009_12_label = 1; v1009_12_label <= 2; ++v1009_12_label) {
    const Space v1009_12_tail = child(s0,v1009_12_label);
    if (v1009_12_tail.empty()) continue;
    const Path v1009_12_head{v1009_12_label};
    const Space v1010_2 = singleton(v1009_12_head);
    const Space v1010_3 = intersect(constant_5,v1010_2);
    const Space v1010_4 = (has_head(v1010_3) ? constant_7 : Space{});
    const Space v1010_5 = subtract(constant_0,v1010_4);
    Space v1010_8;
    if (!v1010_5.empty()) {
      const Path v1011_6 = concat_path(p0,v1009_12_head);
      Space v1011_7_result;
      for (int v1011_7_label = 1; v1011_7_label <= 2; ++v1011_7_label) {
        const Space v1011_7_tail = child(v1009_12_tail,v1011_7_label);
        if (v1011_7_tail.empty()) continue;
        const Path v1011_7_head{v1011_7_label};
        const Space v1012_2 = singleton(v1011_7_head);
        const Space v1012_3 = intersect(constant_5,v1012_2);
        const Space v1012_4 = (has_head(v1012_3) ? constant_7 : Space{});
        const Space v1012_5 = subtract(constant_0,v1012_4);
        Space v1012_8;
        if (!v1012_5.empty()) {
          const Path v1013_6 = concat_path(v1011_6,v1011_7_head);
          const Space v1013_7 = routine_154(c, v1013_6, p1, v1011_7_tail);
          v1012_8 = compose(v1012_5,v1013_7);
        }
        const Space v1012_9 = intersect(constant_5,v1012_2);
        const Space v1012_10 = (has_head(v1012_9) ? constant_7 : Space{});
        Space v1012_12;
        if (!v1012_10.empty()) {
          const Path v1014_6 = concat_path(v1011_6,v1011_7_head);
          const Space v1014_11 = routine_155(c, v1014_6, p1, v1011_7_tail);
          v1012_12 = compose(v1012_10,v1014_11);
        }
        const Space v1012_13 = unite(v1012_8,v1012_12);
        v1011_7_result = unite(v1011_7_result,v1012_13);
      }
      const Space v1011_7 = std::move(v1011_7_result);
      v1010_8 = compose(v1010_5,v1011_7);
    }
    const Space v1010_9 = intersect(constant_5,v1010_2);
    const Space v1010_10 = (has_head(v1010_9) ? constant_7 : Space{});
    Space v1010_12;
    if (!v1010_10.empty()) {
      const Path v1015_6 = concat_path(p0,v1009_12_head);
      Space v1015_11_result;
      for (int v1015_11_label = 1; v1015_11_label <= 2; ++v1015_11_label) {
        const Space v1015_11_tail = child(v1009_12_tail,v1015_11_label);
        if (v1015_11_tail.empty()) continue;
        const Path v1015_11_head{v1015_11_label};
        const Space v1016_2 = singleton(v1015_11_head);
        const Space v1016_3 = intersect(constant_5,v1016_2);
        const Space v1016_4 = (has_head(v1016_3) ? constant_7 : Space{});
        const Space v1016_5 = subtract(constant_0,v1016_4);
        Space v1016_8;
        if (!v1016_5.empty()) {
          const Path v1017_6 = concat_path(v1015_6,v1015_11_head);
          const Space v1017_7 = routine_154(c, v1017_6, p1, v1015_11_tail);
          v1016_8 = compose(v1016_5,v1017_7);
        }
        const Space v1016_9 = intersect(constant_5,v1016_2);
        const Space v1016_10 = (has_head(v1016_9) ? constant_7 : Space{});
        Space v1016_12;
        if (!v1016_10.empty()) {
          const Path v1018_6 = concat_path(v1015_6,v1015_11_head);
          const Space v1018_11 = routine_26(c, v1018_6, p1, v1015_11_tail);
          v1016_12 = compose(v1016_10,v1018_11);
        }
        const Space v1016_13 = unite(v1016_8,v1016_12);
        v1015_11_result = unite(v1015_11_result,v1016_13);
      }
      const Space v1015_11 = std::move(v1015_11_result);
      v1010_12 = compose(v1010_10,v1015_11);
    }
    const Space v1010_13 = unite(v1010_8,v1010_12);
    v1009_12_result = unite(v1009_12_result,v1010_13);
  }
  const Space v1009_12 = std::move(v1009_12_result);
  return v1009_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1019_7 = unwrap(constant_9,p1);
  const Space v1019_9 = unwrap(constant_9,p0);
  Space v1019_13_result;
  for (int v1019_13_label = 1; v1019_13_label <= 2; ++v1019_13_label) {
    const Space v1019_13_tail = child(s0,v1019_13_label);
    if (v1019_13_tail.empty()) continue;
    const Path v1019_13_head{v1019_13_label};
    const Space v1020_2 = singleton(v1019_13_head);
    const Space v1020_3 = intersect(constant_5,v1020_2);
    const Space v1020_4 = (has_head(v1020_3) ? constant_7 : Space{});
    const Space v1020_5 = subtract(constant_0,v1020_4);
    Space v1020_8;
    if (!v1020_5.empty()) {
      const Path v1021_6 = concat_path(p0,v1019_13_head);
      Space v1021_7_result;
      for (int v1021_7_label = 1; v1021_7_label <= 2; ++v1021_7_label) {
        const Space v1021_7_tail = child(v1019_13_tail,v1021_7_label);
        if (v1021_7_tail.empty()) continue;
        const Path v1021_7_head{v1021_7_label};
        const Space v1022_2 = singleton(v1021_7_head);
        const Space v1022_3 = intersect(constant_5,v1022_2);
        const Space v1022_4 = (has_head(v1022_3) ? constant_7 : Space{});
        const Space v1022_5 = subtract(constant_0,v1022_4);
        Space v1022_8;
        if (!v1022_5.empty()) {
          const Path v1023_6 = concat_path(v1021_6,v1021_7_head);
          const Space v1023_7 = routine_154(c, v1023_6, p1, v1021_7_tail);
          v1022_8 = compose(v1022_5,v1023_7);
        }
        const Space v1022_9 = intersect(constant_5,v1022_2);
        const Space v1022_10 = (has_head(v1022_9) ? constant_7 : Space{});
        Space v1022_12;
        if (!v1022_10.empty()) {
          const Path v1024_6 = concat_path(v1021_6,v1021_7_head);
          const Space v1024_11 = routine_155(c, v1024_6, p1, v1021_7_tail);
          v1022_12 = compose(v1022_10,v1024_11);
        }
        const Space v1022_13 = unite(v1022_8,v1022_12);
        v1021_7_result = unite(v1021_7_result,v1022_13);
      }
      const Space v1021_7 = std::move(v1021_7_result);
      v1020_8 = compose(v1020_5,v1021_7);
    }
    const Space v1020_9 = intersect(constant_5,v1020_2);
    const Space v1020_10 = (has_head(v1020_9) ? constant_7 : Space{});
    const Space v1020_11 = unwrap(v1019_9,v1019_13_head);
    const Space v1020_12 = compose(v1019_7,v1020_11);
    const Path v1025_6 = concat_path(p0,v1019_13_head);
    const Path v1020_13 = concat_path(p1,v1025_6);
    const Space v1020_14 = singleton(v1020_13);
    const Space v1020_15 = subtract(v1020_12,v1020_14);
    const Space v1020_16 = compose(v1020_10,v1020_15);
    const Space v1020_17 = unite(v1020_8,v1020_16);
    v1019_13_result = unite(v1019_13_result,v1020_17);
  }
  const Space v1019_13 = std::move(v1019_13_result);
  return v1019_13;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1026_12_result;
  for (int v1026_12_label = 1; v1026_12_label <= 2; ++v1026_12_label) {
    const Space v1026_12_tail = child(s0,v1026_12_label);
    if (v1026_12_tail.empty()) continue;
    const Path v1026_12_head{v1026_12_label};
    const Space v1027_2 = singleton(v1026_12_head);
    const Space v1027_3 = intersect(constant_5,v1027_2);
    const Space v1027_4 = (has_head(v1027_3) ? constant_7 : Space{});
    const Space v1027_5 = subtract(constant_0,v1027_4);
    Space v1027_8;
    if (!v1027_5.empty()) {
      const Path v1028_6 = concat_path(p0,v1026_12_head);
      Space v1028_7_result;
      for (int v1028_7_label = 1; v1028_7_label <= 2; ++v1028_7_label) {
        const Space v1028_7_tail = child(v1026_12_tail,v1028_7_label);
        if (v1028_7_tail.empty()) continue;
        const Path v1028_7_head{v1028_7_label};
        const Space v1029_2 = singleton(v1028_7_head);
        const Space v1029_3 = intersect(constant_5,v1029_2);
        const Space v1029_4 = (has_head(v1029_3) ? constant_7 : Space{});
        const Space v1029_5 = subtract(constant_0,v1029_4);
        Space v1029_8;
        if (!v1029_5.empty()) {
          const Path v1030_6 = concat_path(v1028_6,v1028_7_head);
          const Space v1030_7 = routine_156(c, v1030_6, p1, v1028_7_tail);
          v1029_8 = compose(v1029_5,v1030_7);
        }
        const Space v1029_9 = intersect(constant_5,v1029_2);
        const Space v1029_10 = (has_head(v1029_9) ? constant_7 : Space{});
        Space v1029_12;
        if (!v1029_10.empty()) {
          const Path v1031_6 = concat_path(v1028_6,v1028_7_head);
          const Space v1031_11 = routine_157(c, v1031_6, p1, v1028_7_tail);
          v1029_12 = compose(v1029_10,v1031_11);
        }
        const Space v1029_13 = unite(v1029_8,v1029_12);
        v1028_7_result = unite(v1028_7_result,v1029_13);
      }
      const Space v1028_7 = std::move(v1028_7_result);
      v1027_8 = compose(v1027_5,v1028_7);
    }
    const Space v1027_9 = intersect(constant_5,v1027_2);
    const Space v1027_10 = (has_head(v1027_9) ? constant_7 : Space{});
    Space v1027_12;
    if (!v1027_10.empty()) {
      const Path v1032_6 = concat_path(p0,v1026_12_head);
      Space v1032_11_result;
      for (int v1032_11_label = 1; v1032_11_label <= 2; ++v1032_11_label) {
        const Space v1032_11_tail = child(v1026_12_tail,v1032_11_label);
        if (v1032_11_tail.empty()) continue;
        const Path v1032_11_head{v1032_11_label};
        const Space v1033_2 = singleton(v1032_11_head);
        const Space v1033_3 = intersect(constant_5,v1033_2);
        const Space v1033_4 = (has_head(v1033_3) ? constant_7 : Space{});
        const Space v1033_5 = subtract(constant_0,v1033_4);
        Space v1033_8;
        if (!v1033_5.empty()) {
          const Path v1034_6 = concat_path(v1032_6,v1032_11_head);
          const Space v1034_7 = routine_156(c, v1034_6, p1, v1032_11_tail);
          v1033_8 = compose(v1033_5,v1034_7);
        }
        const Space v1033_9 = intersect(constant_5,v1033_2);
        const Space v1033_10 = (has_head(v1033_9) ? constant_7 : Space{});
        Space v1033_12;
        if (!v1033_10.empty()) {
          const Path v1035_6 = concat_path(v1032_6,v1032_11_head);
          const Space v1035_11 = routine_26(c, v1035_6, p1, v1032_11_tail);
          v1033_12 = compose(v1033_10,v1035_11);
        }
        const Space v1033_13 = unite(v1033_8,v1033_12);
        v1032_11_result = unite(v1032_11_result,v1033_13);
      }
      const Space v1032_11 = std::move(v1032_11_result);
      v1027_12 = compose(v1027_10,v1032_11);
    }
    const Space v1027_13 = unite(v1027_8,v1027_12);
    v1026_12_result = unite(v1026_12_result,v1027_13);
  }
  const Space v1026_12 = std::move(v1026_12_result);
  return v1026_12;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1036_7 = unwrap(constant_9,p1);
  const Space v1036_9 = unwrap(constant_9,p0);
  Space v1036_13_result;
  for (int v1036_13_label = 1; v1036_13_label <= 2; ++v1036_13_label) {
    const Space v1036_13_tail = child(s0,v1036_13_label);
    if (v1036_13_tail.empty()) continue;
    const Path v1036_13_head{v1036_13_label};
    const Space v1037_2 = singleton(v1036_13_head);
    const Space v1037_3 = intersect(constant_5,v1037_2);
    const Space v1037_4 = (has_head(v1037_3) ? constant_7 : Space{});
    const Space v1037_5 = subtract(constant_0,v1037_4);
    Space v1037_8;
    if (!v1037_5.empty()) {
      const Path v1038_6 = concat_path(p0,v1036_13_head);
      Space v1038_7_result;
      for (int v1038_7_label = 1; v1038_7_label <= 2; ++v1038_7_label) {
        const Space v1038_7_tail = child(v1036_13_tail,v1038_7_label);
        if (v1038_7_tail.empty()) continue;
        const Path v1038_7_head{v1038_7_label};
        const Space v1039_2 = singleton(v1038_7_head);
        const Space v1039_3 = intersect(constant_5,v1039_2);
        const Space v1039_4 = (has_head(v1039_3) ? constant_7 : Space{});
        const Space v1039_5 = subtract(constant_0,v1039_4);
        Space v1039_8;
        if (!v1039_5.empty()) {
          const Path v1040_6 = concat_path(v1038_6,v1038_7_head);
          const Space v1040_7 = routine_156(c, v1040_6, p1, v1038_7_tail);
          v1039_8 = compose(v1039_5,v1040_7);
        }
        const Space v1039_9 = intersect(constant_5,v1039_2);
        const Space v1039_10 = (has_head(v1039_9) ? constant_7 : Space{});
        Space v1039_12;
        if (!v1039_10.empty()) {
          const Path v1041_6 = concat_path(v1038_6,v1038_7_head);
          const Space v1041_11 = routine_157(c, v1041_6, p1, v1038_7_tail);
          v1039_12 = compose(v1039_10,v1041_11);
        }
        const Space v1039_13 = unite(v1039_8,v1039_12);
        v1038_7_result = unite(v1038_7_result,v1039_13);
      }
      const Space v1038_7 = std::move(v1038_7_result);
      v1037_8 = compose(v1037_5,v1038_7);
    }
    const Space v1037_9 = intersect(constant_5,v1037_2);
    const Space v1037_10 = (has_head(v1037_9) ? constant_7 : Space{});
    const Space v1037_11 = unwrap(v1036_9,v1036_13_head);
    const Space v1037_12 = compose(v1036_7,v1037_11);
    const Path v1042_6 = concat_path(p0,v1036_13_head);
    const Path v1037_13 = concat_path(p1,v1042_6);
    const Space v1037_14 = singleton(v1037_13);
    const Space v1037_15 = subtract(v1037_12,v1037_14);
    const Space v1037_16 = compose(v1037_10,v1037_15);
    const Space v1037_17 = unite(v1037_8,v1037_16);
    v1036_13_result = unite(v1036_13_result,v1037_17);
  }
  const Space v1036_13 = std::move(v1036_13_result);
  return v1036_13;
}

static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1043_5_result;
  for (int v1043_5_label = 1; v1043_5_label <= 2; ++v1043_5_label) {
    const Space v1043_5_tail = child(s0,v1043_5_label);
    if (v1043_5_tail.empty()) continue;
    const Path v1043_5_head{v1043_5_label};
    const Space v1044_2 = singleton(v1043_5_head);
    const Space v1044_3 = intersect(constant_5,v1044_2);
    const Space v1044_4 = (has_head(v1044_3) ? constant_7 : Space{});
    Space v1044_7;
    if (!v1044_4.empty()) {
      const Path v1045_5 = concat_path(p0,v1043_5_head);
      Space v1045_6_result;
      for (int v1045_6_label = 1; v1045_6_label <= 2; ++v1045_6_label) {
        const Space v1045_6_tail = child(v1043_5_tail,v1045_6_label);
        if (v1045_6_tail.empty()) continue;
        const Path v1045_6_head{v1045_6_label};
        const Space v1046_2 = singleton(v1045_6_head);
        const Space v1046_3 = intersect(constant_5,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_7 : Space{});
        Space v1046_7;
        if (!v1046_4.empty()) {
          const Path v1047_5 = concat_path(v1045_5,v1045_6_head);
          const Space v1047_6 = routine_14(c, v1047_5, v1045_6_tail, s1);
          v1046_7 = compose(v1046_4,v1047_6);
        }
        v1045_6_result = unite(v1045_6_result,v1046_7);
      }
      const Space v1045_6 = std::move(v1045_6_result);
      v1044_7 = compose(v1044_4,v1045_6);
    }
    v1043_5_result = unite(v1043_5_result,v1044_7);
  }
  const Space v1043_5 = std::move(v1043_5_result);
  return v1043_5;
}

static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1048_7_result;
  for (int v1048_7_label = 1; v1048_7_label <= 2; ++v1048_7_label) {
    const Space v1048_7_tail = child(s0,v1048_7_label);
    if (v1048_7_tail.empty()) continue;
    const Path v1048_7_head{v1048_7_label};
    const Space v1049_2 = singleton(v1048_7_head);
    const Space v1049_3 = intersect(constant_5,v1049_2);
    const Space v1049_4 = (has_head(v1049_3) ? constant_7 : Space{});
    Space v1049_7;
    if (!v1049_4.empty()) {
      const Path v1050_5 = concat_path(p0,v1048_7_head);
      Space v1050_6_result;
      for (int v1050_6_label = 1; v1050_6_label <= 2; ++v1050_6_label) {
        const Space v1050_6_tail = child(v1048_7_tail,v1050_6_label);
        if (v1050_6_tail.empty()) continue;
        const Path v1050_6_head{v1050_6_label};
        const Space v1051_2 = singleton(v1050_6_head);
        const Space v1051_3 = intersect(constant_5,v1051_2);
        const Space v1051_4 = (has_head(v1051_3) ? constant_7 : Space{});
        const Space v1051_5 = subtract(constant_0,v1051_4);
        Space v1051_7;
        if (!v1051_5.empty()) {
          const Space v1052_6 = routine_15(c, v1050_6_head, v1050_5, v1050_6_tail, s1);
          v1051_7 = compose(v1051_5,v1052_6);
        }
        const Space v1051_8 = intersect(constant_5,v1051_2);
        const Space v1051_9 = (has_head(v1051_8) ? constant_7 : Space{});
        Space v1051_11;
        if (!v1051_9.empty()) {
          const Space v1053_10 = routine_16(c, v1050_6_head, v1050_5, v1050_6_tail, s1);
          v1051_11 = compose(v1051_9,v1053_10);
        }
        const Space v1051_12 = unite(v1051_7,v1051_11);
        v1050_6_result = unite(v1050_6_result,v1051_12);
      }
      const Space v1050_6 = std::move(v1050_6_result);
      v1049_7 = compose(v1049_4,v1050_6);
    }
    v1048_7_result = unite(v1048_7_result,v1049_7);
  }
  const Space v1048_7 = std::move(v1048_7_result);
  return v1048_7;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1054_13_result;
  for (int v1054_13_label = 1; v1054_13_label <= 2; ++v1054_13_label) {
    const Space v1054_13_tail = child(s0,v1054_13_label);
    if (v1054_13_tail.empty()) continue;
    const Path v1054_13_head{v1054_13_label};
    const Space v1055_2 = singleton(v1054_13_head);
    const Space v1055_3 = intersect(constant_5,v1055_2);
    const Space v1055_4 = (has_head(v1055_3) ? constant_7 : Space{});
    const Space v1055_5 = subtract(constant_0,v1055_4);
    Space v1055_8;
    if (!v1055_5.empty()) {
      const Path v1056_6 = concat_path(p0,v1054_13_head);
      Space v1056_7_result;
      for (int v1056_7_label = 1; v1056_7_label <= 2; ++v1056_7_label) {
        const Space v1056_7_tail = child(v1054_13_tail,v1056_7_label);
        if (v1056_7_tail.empty()) continue;
        const Path v1056_7_head{v1056_7_label};
        const Space v1057_2 = singleton(v1056_7_head);
        const Space v1057_3 = intersect(constant_5,v1057_2);
        const Space v1057_4 = (has_head(v1057_3) ? constant_7 : Space{});
        const Space v1057_5 = subtract(constant_0,v1057_4);
        Space v1057_8;
        if (!v1057_5.empty()) {
          const Path v1058_6 = concat_path(v1056_6,v1056_7_head);
          const Space v1058_7 = routine_158(c, v1058_6, p1, v1056_7_tail, s1);
          v1057_8 = compose(v1057_5,v1058_7);
        }
        const Space v1057_9 = intersect(constant_5,v1057_2);
        const Space v1057_10 = (has_head(v1057_9) ? constant_7 : Space{});
        Space v1057_12;
        if (!v1057_10.empty()) {
          const Path v1059_6 = concat_path(v1056_6,v1056_7_head);
          const Space v1059_11 = routine_159(c, v1059_6, p1, v1056_7_tail, s1);
          v1057_12 = compose(v1057_10,v1059_11);
        }
        const Space v1057_13 = unite(v1057_8,v1057_12);
        v1056_7_result = unite(v1056_7_result,v1057_13);
      }
      const Space v1056_7 = std::move(v1056_7_result);
      v1055_8 = compose(v1055_5,v1056_7);
    }
    const Space v1055_9 = intersect(constant_5,v1055_2);
    const Space v1055_10 = (has_head(v1055_9) ? constant_7 : Space{});
    Space v1055_12;
    if (!v1055_10.empty()) {
      const Path v1060_6 = concat_path(p0,v1054_13_head);
      Space v1060_11_result;
      for (int v1060_11_label = 1; v1060_11_label <= 2; ++v1060_11_label) {
        const Space v1060_11_tail = child(v1054_13_tail,v1060_11_label);
        if (v1060_11_tail.empty()) continue;
        const Path v1060_11_head{v1060_11_label};
        const Space v1061_2 = singleton(v1060_11_head);
        const Space v1061_3 = intersect(constant_5,v1061_2);
        const Space v1061_4 = (has_head(v1061_3) ? constant_7 : Space{});
        const Space v1061_5 = subtract(constant_0,v1061_4);
        Space v1061_8;
        if (!v1061_5.empty()) {
          const Path v1062_6 = concat_path(v1060_6,v1060_11_head);
          const Space v1062_7 = routine_158(c, v1062_6, p1, v1060_11_tail, s1);
          v1061_8 = compose(v1061_5,v1062_7);
        }
        const Space v1061_9 = intersect(constant_5,v1061_2);
        const Space v1061_10 = (has_head(v1061_9) ? constant_7 : Space{});
        Space v1061_12;
        if (!v1061_10.empty()) {
          const Path v1063_6 = concat_path(v1060_6,v1060_11_head);
          const Space v1063_11 = routine_33(c, v1063_6, p1, v1060_11_tail, s1);
          v1061_12 = compose(v1061_10,v1063_11);
        }
        const Space v1061_13 = unite(v1061_8,v1061_12);
        v1060_11_result = unite(v1060_11_result,v1061_13);
      }
      const Space v1060_11 = std::move(v1060_11_result);
      v1055_12 = compose(v1055_10,v1060_11);
    }
    const Space v1055_13 = unite(v1055_8,v1055_12);
    v1054_13_result = unite(v1054_13_result,v1055_13);
  }
  const Space v1054_13 = std::move(v1054_13_result);
  return v1054_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1064_8 = unwrap(constant_9,p1);
  const Space v1064_10 = unwrap(constant_9,p0);
  const Space v1064_12 = unwrap(s1,constant_8);
  const Space v1064_14 = unwrap(constant_9,p1);
  const Space v1064_16 = unwrap(constant_9,p0);
  Space v1064_29_result;
  for (int v1064_29_label = 1; v1064_29_label <= 2; ++v1064_29_label) {
    const Space v1064_29_tail = child(s0,v1064_29_label);
    if (v1064_29_tail.empty()) continue;
    const Path v1064_29_head{v1064_29_label};
    const Space v1065_2 = singleton(v1064_29_head);
    const Space v1065_3 = intersect(constant_5,v1065_2);
    const Space v1065_4 = (has_head(v1065_3) ? constant_7 : Space{});
    const Space v1065_5 = subtract(constant_0,v1065_4);
    Space v1065_8;
    if (!v1065_5.empty()) {
      const Path v1066_6 = concat_path(p0,v1064_29_head);
      Space v1066_7_result;
      for (int v1066_7_label = 1; v1066_7_label <= 2; ++v1066_7_label) {
        const Space v1066_7_tail = child(v1064_29_tail,v1066_7_label);
        if (v1066_7_tail.empty()) continue;
        const Path v1066_7_head{v1066_7_label};
        const Space v1067_2 = singleton(v1066_7_head);
        const Space v1067_3 = intersect(constant_5,v1067_2);
        const Space v1067_4 = (has_head(v1067_3) ? constant_7 : Space{});
        const Space v1067_5 = subtract(constant_0,v1067_4);
        Space v1067_8;
        if (!v1067_5.empty()) {
          const Path v1068_6 = concat_path(v1066_6,v1066_7_head);
          const Space v1068_7 = routine_158(c, v1068_6, p1, v1066_7_tail, s1);
          v1067_8 = compose(v1067_5,v1068_7);
        }
        const Space v1067_9 = intersect(constant_5,v1067_2);
        const Space v1067_10 = (has_head(v1067_9) ? constant_7 : Space{});
        Space v1067_12;
        if (!v1067_10.empty()) {
          const Path v1069_6 = concat_path(v1066_6,v1066_7_head);
          const Space v1069_11 = routine_159(c, v1069_6, p1, v1066_7_tail, s1);
          v1067_12 = compose(v1067_10,v1069_11);
        }
        const Space v1067_13 = unite(v1067_8,v1067_12);
        v1066_7_result = unite(v1066_7_result,v1067_13);
      }
      const Space v1066_7 = std::move(v1066_7_result);
      v1065_8 = compose(v1065_5,v1066_7);
    }
    const Space v1065_9 = intersect(constant_5,v1065_2);
    const Space v1065_10 = (has_head(v1065_9) ? constant_7 : Space{});
    Space v1065_28;
    if (!v1065_10.empty()) {
      const Path v1070_6 = concat_path(p0,v1064_29_head);
      const Space v1070_11 = unwrap(v1064_10,v1064_29_head);
      const Space v1070_12 = compose(v1064_8,v1070_11);
      const Path v1070_13 = concat_path(p1,v1070_6);
      const Space v1070_14 = singleton(v1070_13);
      const Space v1070_15 = subtract(v1070_12,v1070_14);
      const Space v1070_16 = intersect(v1070_15,v1064_12);
      const Space v1070_17 = routine_36(c, v1070_16);
      Space v1070_18_result;
      for (int v1070_18_label = 1; v1070_18_label <= 2; ++v1070_18_label) {
        const Space v1070_18_tail = child(v1070_17,v1070_18_label);
        if (v1070_18_tail.empty()) continue;
        const Path v1070_18_head{v1070_18_label};
        const Space v1071_2 = singleton(v1070_18_head);
        const Space v1071_3 = intersect(constant_5,v1071_2);
        const Space v1071_4 = (has_head(v1071_3) ? constant_7 : Space{});
        const Space v1071_5 = subtract(constant_0,v1071_4);
        Space v1071_7;
        if (!v1071_5.empty()) {
          const Space v1072_6 = routine_37(c, v1070_18_head, v1070_18_tail);
          v1071_7 = compose(v1071_5,v1072_6);
        }
        const Space v1071_8 = intersect(constant_5,v1071_2);
        const Space v1071_9 = (has_head(v1071_8) ? constant_7 : Space{});
        Space v1071_11;
        if (!v1071_9.empty()) {
          const Space v1073_10 = routine_38(c, v1070_18_head, v1070_18_tail);
          v1071_11 = compose(v1071_9,v1073_10);
        }
        const Space v1071_12 = unite(v1071_7,v1071_11);
        v1070_18_result = unite(v1070_18_result,v1071_12);
      }
      const Space v1070_18 = std::move(v1070_18_result);
      const Space v1070_19 = unwrap(v1064_16,v1064_29_head);
      const Space v1070_20 = compose(v1064_14,v1070_19);
      const Space v1070_21 = subtract(v1070_20,v1070_14);
      const Space v1070_22 = intersect(v1070_21,v1064_12);
      const Space v1070_23 = routine_39(c, v1070_22);
      Space v1070_24_result;
      for (int v1070_24_label = 1; v1070_24_label <= 2; ++v1070_24_label) {
        const Space v1070_24_tail = child(v1070_23,v1070_24_label);
        if (v1070_24_tail.empty()) continue;
        const Path v1070_24_head{v1070_24_label};
        const Space v1074_2 = singleton(v1070_24_head);
        const Space v1074_3 = intersect(constant_5,v1074_2);
        const Space v1074_4 = (has_head(v1074_3) ? constant_7 : Space{});
        const Space v1074_5 = subtract(constant_0,v1074_4);
        Space v1074_7;
        if (!v1074_5.empty()) {
          const Space v1075_6 = routine_40(c, v1070_24_head, v1070_24_tail);
          v1074_7 = compose(v1074_5,v1075_6);
        }
        const Space v1074_8 = intersect(constant_5,v1074_2);
        const Space v1074_9 = (has_head(v1074_8) ? constant_7 : Space{});
        Space v1074_11;
        if (!v1074_9.empty()) {
          const Space v1076_10 = routine_41(c, v1070_24_head, v1070_24_tail);
          v1074_11 = compose(v1074_9,v1076_10);
        }
        const Space v1074_12 = unite(v1074_7,v1074_11);
        v1070_24_result = unite(v1070_24_result,v1074_12);
      }
      const Space v1070_24 = std::move(v1070_24_result);
      const Space v1070_25 = subtract(v1070_18,v1070_24);
      const Space v1070_26 = compose(v1070_25,v1070_14);
      Space v1070_27_result;
      for (int v1070_27_label = 1; v1070_27_label <= 2; ++v1070_27_label) {
        const Space v1070_27_tail = child(v1070_26,v1070_27_label);
        if (v1070_27_tail.empty()) continue;
        const Path v1070_27_head{v1070_27_label};
        const Space v1077_2 = singleton(v1070_27_head);
        const Space v1077_3 = intersect(constant_5,v1077_2);
        const Space v1077_4 = (has_head(v1077_3) ? constant_7 : Space{});
        const Space v1077_5 = subtract(constant_0,v1077_4);
        Space v1077_7;
        if (!v1077_5.empty()) {
          const Space v1078_6 = routine_42(c, v1070_27_head, v1070_27_tail);
          v1077_7 = compose(v1077_5,v1078_6);
        }
        const Space v1077_8 = intersect(constant_5,v1077_2);
        const Space v1077_9 = (has_head(v1077_8) ? constant_7 : Space{});
        Space v1077_11;
        if (!v1077_9.empty()) {
          const Space v1079_10 = routine_43(c, v1070_27_head, v1070_27_tail);
          v1077_11 = compose(v1077_9,v1079_10);
        }
        const Space v1077_12 = unite(v1077_7,v1077_11);
        v1070_27_result = unite(v1070_27_result,v1077_12);
      }
      const Space v1070_27 = std::move(v1070_27_result);
      v1065_28 = compose(v1065_10,v1070_27);
    }
    const Space v1065_29 = unite(v1065_8,v1065_28);
    v1064_29_result = unite(v1064_29_result,v1065_29);
  }
  const Space v1064_29 = std::move(v1064_29_result);
  return v1064_29;
}

static Space routine_120(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1080_3 = first_matching(s0,constant_0,false);
  Space v1080_7;
  if (!v1080_3.empty()) {
    const Space v1081_4 = unwrap(s1,p0);
    const Space v1081_5 = routine_82(c, v1081_4);
    const Space v1081_6 = wrap(v1081_5,p0);
    v1080_7 = compose(v1080_3,v1081_6);
  }
  Space v1080_8_result;
  for (int v1080_8_label = 1; v1080_8_label <= 2; ++v1080_8_label) {
    const Space v1080_8_tail = child(s0,v1080_8_label);
    if (v1080_8_tail.empty()) continue;
    const Path v1080_8_head{v1080_8_label};
    const Path v1082_2 = concat_path(p0,v1080_8_head);
    const Space v1082_3 = routine_120(c, v1082_2, v1080_8_tail, s1);
    v1080_8_result = unite(v1080_8_result,v1082_3);
  }
  const Space v1080_8 = std::move(v1080_8_result);
  const Space v1080_9 = unite(v1080_7,v1080_8);
  return v1080_9;
}

static Space routine_121(Context& c, const Path& p0, const Space& s0) {
  Space v1083_11_result;
  for (int v1083_11_label = 1; v1083_11_label <= 2; ++v1083_11_label) {
    const Space v1083_11_tail = child(s0,v1083_11_label);
    if (v1083_11_tail.empty()) continue;
    const Path v1083_11_head{v1083_11_label};
    const Space v1084_2 = singleton(v1083_11_head);
    const Space v1084_3 = intersect(constant_5,v1084_2);
    const Space v1084_4 = (has_head(v1084_3) ? constant_7 : Space{});
    const Space v1084_5 = subtract(constant_0,v1084_4);
    Space v1084_8;
    if (!v1084_5.empty()) {
      const Path v1085_6 = concat_path(p0,v1083_11_head);
      Space v1085_7_result;
      for (int v1085_7_label = 1; v1085_7_label <= 2; ++v1085_7_label) {
        const Space v1085_7_tail = child(v1083_11_tail,v1085_7_label);
        if (v1085_7_tail.empty()) continue;
        const Path v1085_7_head{v1085_7_label};
        const Space v1086_2 = singleton(v1085_7_head);
        const Space v1086_3 = intersect(constant_5,v1086_2);
        const Space v1086_4 = (has_head(v1086_3) ? constant_7 : Space{});
        const Space v1086_5 = subtract(constant_0,v1086_4);
        Space v1086_8;
        if (!v1086_5.empty()) {
          const Path v1087_6 = concat_path(v1085_6,v1085_7_head);
          const Space v1087_7 = routine_160(c, v1087_6, v1085_7_tail);
          v1086_8 = compose(v1086_5,v1087_7);
        }
        const Space v1086_9 = intersect(constant_5,v1086_2);
        const Space v1086_10 = (has_head(v1086_9) ? constant_7 : Space{});
        Space v1086_12;
        if (!v1086_10.empty()) {
          const Path v1088_6 = concat_path(v1085_6,v1085_7_head);
          const Space v1088_11 = routine_161(c, v1088_6, v1085_7_tail);
          v1086_12 = compose(v1086_10,v1088_11);
        }
        const Space v1086_13 = unite(v1086_8,v1086_12);
        v1085_7_result = unite(v1085_7_result,v1086_13);
      }
      const Space v1085_7 = std::move(v1085_7_result);
      v1084_8 = compose(v1084_5,v1085_7);
    }
    const Space v1084_9 = intersect(constant_5,v1084_2);
    const Space v1084_10 = (has_head(v1084_9) ? constant_7 : Space{});
    Space v1084_12;
    if (!v1084_10.empty()) {
      const Path v1089_6 = concat_path(p0,v1083_11_head);
      Space v1089_11_result;
      for (int v1089_11_label = 1; v1089_11_label <= 2; ++v1089_11_label) {
        const Space v1089_11_tail = child(v1083_11_tail,v1089_11_label);
        if (v1089_11_tail.empty()) continue;
        const Path v1089_11_head{v1089_11_label};
        const Space v1090_2 = singleton(v1089_11_head);
        const Space v1090_3 = intersect(constant_5,v1090_2);
        const Space v1090_4 = (has_head(v1090_3) ? constant_7 : Space{});
        const Space v1090_5 = subtract(constant_0,v1090_4);
        Space v1090_8;
        if (!v1090_5.empty()) {
          const Path v1091_6 = concat_path(v1089_6,v1089_11_head);
          const Space v1091_7 = routine_160(c, v1091_6, v1089_11_tail);
          v1090_8 = compose(v1090_5,v1091_7);
        }
        const Space v1090_9 = intersect(constant_5,v1090_2);
        const Space v1090_10 = (has_head(v1090_9) ? constant_7 : Space{});
        Space v1090_12;
        if (!v1090_10.empty()) {
          const Path v1092_6 = concat_path(v1089_6,v1089_11_head);
          const Space v1092_11 = routine_72(c, v1092_6, v1089_11_tail);
          v1090_12 = compose(v1090_10,v1092_11);
        }
        const Space v1090_13 = unite(v1090_8,v1090_12);
        v1089_11_result = unite(v1089_11_result,v1090_13);
      }
      const Space v1089_11 = std::move(v1089_11_result);
      v1084_12 = compose(v1084_10,v1089_11);
    }
    const Space v1084_13 = unite(v1084_8,v1084_12);
    v1083_11_result = unite(v1083_11_result,v1084_13);
  }
  const Space v1083_11 = std::move(v1083_11_result);
  return v1083_11;
}

static Space routine_122(Context& c, const Path& p0, const Space& s0) {
  Space v1093_9_result;
  for (int v1093_9_label = 1; v1093_9_label <= 2; ++v1093_9_label) {
    const Space v1093_9_tail = child(s0,v1093_9_label);
    if (v1093_9_tail.empty()) continue;
    const Path v1093_9_head{v1093_9_label};
    const Space v1094_2 = singleton(v1093_9_head);
    const Space v1094_3 = intersect(constant_5,v1094_2);
    const Space v1094_4 = (has_head(v1094_3) ? constant_7 : Space{});
    const Space v1094_5 = subtract(constant_0,v1094_4);
    Space v1094_8;
    if (!v1094_5.empty()) {
      const Path v1095_6 = concat_path(p0,v1093_9_head);
      Space v1095_7_result;
      for (int v1095_7_label = 1; v1095_7_label <= 2; ++v1095_7_label) {
        const Space v1095_7_tail = child(v1093_9_tail,v1095_7_label);
        if (v1095_7_tail.empty()) continue;
        const Path v1095_7_head{v1095_7_label};
        const Space v1096_2 = singleton(v1095_7_head);
        const Space v1096_3 = intersect(constant_5,v1096_2);
        const Space v1096_4 = (has_head(v1096_3) ? constant_7 : Space{});
        const Space v1096_5 = subtract(constant_0,v1096_4);
        Space v1096_8;
        if (!v1096_5.empty()) {
          const Path v1097_6 = concat_path(v1095_6,v1095_7_head);
          const Space v1097_7 = routine_160(c, v1097_6, v1095_7_tail);
          v1096_8 = compose(v1096_5,v1097_7);
        }
        const Space v1096_9 = intersect(constant_5,v1096_2);
        const Space v1096_10 = (has_head(v1096_9) ? constant_7 : Space{});
        Space v1096_12;
        if (!v1096_10.empty()) {
          const Path v1098_6 = concat_path(v1095_6,v1095_7_head);
          const Space v1098_11 = routine_161(c, v1098_6, v1095_7_tail);
          v1096_12 = compose(v1096_10,v1098_11);
        }
        const Space v1096_13 = unite(v1096_8,v1096_12);
        v1095_7_result = unite(v1095_7_result,v1096_13);
      }
      const Space v1095_7 = std::move(v1095_7_result);
      v1094_8 = compose(v1094_5,v1095_7);
    }
    const Space v1094_9 = intersect(constant_5,v1094_2);
    const Space v1094_10 = (has_head(v1094_9) ? constant_7 : Space{});
    const Space v1094_11 = compose(v1094_10,constant_10);
    const Space v1094_12 = unite(v1094_8,v1094_11);
    v1093_9_result = unite(v1093_9_result,v1094_12);
  }
  const Space v1093_9 = std::move(v1093_9_result);
  return v1093_9;
}

static Space routine_123(Context& c, const Path& p0, const Space& s0) {
  Space v1099_11_result;
  for (int v1099_11_label = 1; v1099_11_label <= 2; ++v1099_11_label) {
    const Space v1099_11_tail = child(s0,v1099_11_label);
    if (v1099_11_tail.empty()) continue;
    const Path v1099_11_head{v1099_11_label};
    const Space v1100_2 = singleton(v1099_11_head);
    const Space v1100_3 = intersect(constant_5,v1100_2);
    const Space v1100_4 = (has_head(v1100_3) ? constant_7 : Space{});
    const Space v1100_5 = subtract(constant_0,v1100_4);
    Space v1100_8;
    if (!v1100_5.empty()) {
      const Path v1101_6 = concat_path(p0,v1099_11_head);
      Space v1101_7_result;
      for (int v1101_7_label = 1; v1101_7_label <= 2; ++v1101_7_label) {
        const Space v1101_7_tail = child(v1099_11_tail,v1101_7_label);
        if (v1101_7_tail.empty()) continue;
        const Path v1101_7_head{v1101_7_label};
        const Space v1102_2 = singleton(v1101_7_head);
        const Space v1102_3 = intersect(constant_5,v1102_2);
        const Space v1102_4 = (has_head(v1102_3) ? constant_7 : Space{});
        const Space v1102_5 = subtract(constant_0,v1102_4);
        Space v1102_8;
        if (!v1102_5.empty()) {
          const Path v1103_6 = concat_path(v1101_6,v1101_7_head);
          const Space v1103_7 = routine_162(c, v1103_6, v1101_7_tail);
          v1102_8 = compose(v1102_5,v1103_7);
        }
        const Space v1102_9 = intersect(constant_5,v1102_2);
        const Space v1102_10 = (has_head(v1102_9) ? constant_7 : Space{});
        Space v1102_12;
        if (!v1102_10.empty()) {
          const Path v1104_6 = concat_path(v1101_6,v1101_7_head);
          const Space v1104_11 = routine_163(c, v1104_6, v1101_7_tail);
          v1102_12 = compose(v1102_10,v1104_11);
        }
        const Space v1102_13 = unite(v1102_8,v1102_12);
        v1101_7_result = unite(v1101_7_result,v1102_13);
      }
      const Space v1101_7 = std::move(v1101_7_result);
      v1100_8 = compose(v1100_5,v1101_7);
    }
    const Space v1100_9 = intersect(constant_5,v1100_2);
    const Space v1100_10 = (has_head(v1100_9) ? constant_7 : Space{});
    Space v1100_12;
    if (!v1100_10.empty()) {
      const Path v1105_6 = concat_path(p0,v1099_11_head);
      Space v1105_11_result;
      for (int v1105_11_label = 1; v1105_11_label <= 2; ++v1105_11_label) {
        const Space v1105_11_tail = child(v1099_11_tail,v1105_11_label);
        if (v1105_11_tail.empty()) continue;
        const Path v1105_11_head{v1105_11_label};
        const Space v1106_2 = singleton(v1105_11_head);
        const Space v1106_3 = intersect(constant_5,v1106_2);
        const Space v1106_4 = (has_head(v1106_3) ? constant_7 : Space{});
        const Space v1106_5 = subtract(constant_0,v1106_4);
        Space v1106_8;
        if (!v1106_5.empty()) {
          const Path v1107_6 = concat_path(v1105_6,v1105_11_head);
          const Space v1107_7 = routine_162(c, v1107_6, v1105_11_tail);
          v1106_8 = compose(v1106_5,v1107_7);
        }
        const Space v1106_9 = intersect(constant_5,v1106_2);
        const Space v1106_10 = (has_head(v1106_9) ? constant_7 : Space{});
        Space v1106_12;
        if (!v1106_10.empty()) {
          const Path v1108_6 = concat_path(v1105_6,v1105_11_head);
          const Space v1108_11 = routine_76(c, v1108_6, v1105_11_tail);
          v1106_12 = compose(v1106_10,v1108_11);
        }
        const Space v1106_13 = unite(v1106_8,v1106_12);
        v1105_11_result = unite(v1105_11_result,v1106_13);
      }
      const Space v1105_11 = std::move(v1105_11_result);
      v1100_12 = compose(v1100_10,v1105_11);
    }
    const Space v1100_13 = unite(v1100_8,v1100_12);
    v1099_11_result = unite(v1099_11_result,v1100_13);
  }
  const Space v1099_11 = std::move(v1099_11_result);
  return v1099_11;
}

static Space routine_124(Context& c, const Path& p0, const Space& s0) {
  Space v1109_9_result;
  for (int v1109_9_label = 1; v1109_9_label <= 2; ++v1109_9_label) {
    const Space v1109_9_tail = child(s0,v1109_9_label);
    if (v1109_9_tail.empty()) continue;
    const Path v1109_9_head{v1109_9_label};
    const Space v1110_2 = singleton(v1109_9_head);
    const Space v1110_3 = intersect(constant_5,v1110_2);
    const Space v1110_4 = (has_head(v1110_3) ? constant_7 : Space{});
    const Space v1110_5 = subtract(constant_0,v1110_4);
    Space v1110_8;
    if (!v1110_5.empty()) {
      const Path v1111_6 = concat_path(p0,v1109_9_head);
      Space v1111_7_result;
      for (int v1111_7_label = 1; v1111_7_label <= 2; ++v1111_7_label) {
        const Space v1111_7_tail = child(v1109_9_tail,v1111_7_label);
        if (v1111_7_tail.empty()) continue;
        const Path v1111_7_head{v1111_7_label};
        const Space v1112_2 = singleton(v1111_7_head);
        const Space v1112_3 = intersect(constant_5,v1112_2);
        const Space v1112_4 = (has_head(v1112_3) ? constant_7 : Space{});
        const Space v1112_5 = subtract(constant_0,v1112_4);
        Space v1112_8;
        if (!v1112_5.empty()) {
          const Path v1113_6 = concat_path(v1111_6,v1111_7_head);
          const Space v1113_7 = routine_162(c, v1113_6, v1111_7_tail);
          v1112_8 = compose(v1112_5,v1113_7);
        }
        const Space v1112_9 = intersect(constant_5,v1112_2);
        const Space v1112_10 = (has_head(v1112_9) ? constant_7 : Space{});
        Space v1112_12;
        if (!v1112_10.empty()) {
          const Path v1114_6 = concat_path(v1111_6,v1111_7_head);
          const Space v1114_11 = routine_163(c, v1114_6, v1111_7_tail);
          v1112_12 = compose(v1112_10,v1114_11);
        }
        const Space v1112_13 = unite(v1112_8,v1112_12);
        v1111_7_result = unite(v1111_7_result,v1112_13);
      }
      const Space v1111_7 = std::move(v1111_7_result);
      v1110_8 = compose(v1110_5,v1111_7);
    }
    const Space v1110_9 = intersect(constant_5,v1110_2);
    const Space v1110_10 = (has_head(v1110_9) ? constant_7 : Space{});
    const Space v1110_11 = compose(v1110_10,constant_10);
    const Space v1110_12 = unite(v1110_8,v1110_11);
    v1109_9_result = unite(v1109_9_result,v1110_12);
  }
  const Space v1109_9 = std::move(v1109_9_result);
  return v1109_9;
}

static Space routine_125(Context& c, const Path& p0, const Space& s0) {
  Space v1115_11_result;
  for (int v1115_11_label = 1; v1115_11_label <= 2; ++v1115_11_label) {
    const Space v1115_11_tail = child(s0,v1115_11_label);
    if (v1115_11_tail.empty()) continue;
    const Path v1115_11_head{v1115_11_label};
    const Space v1116_2 = singleton(v1115_11_head);
    const Space v1116_3 = intersect(constant_5,v1116_2);
    const Space v1116_4 = (has_head(v1116_3) ? constant_7 : Space{});
    const Space v1116_5 = subtract(constant_0,v1116_4);
    Space v1116_8;
    if (!v1116_5.empty()) {
      const Path v1117_6 = concat_path(p0,v1115_11_head);
      Space v1117_7_result;
      for (int v1117_7_label = 1; v1117_7_label <= 2; ++v1117_7_label) {
        const Space v1117_7_tail = child(v1115_11_tail,v1117_7_label);
        if (v1117_7_tail.empty()) continue;
        const Path v1117_7_head{v1117_7_label};
        const Space v1118_2 = singleton(v1117_7_head);
        const Space v1118_3 = intersect(constant_5,v1118_2);
        const Space v1118_4 = (has_head(v1118_3) ? constant_7 : Space{});
        const Space v1118_5 = subtract(constant_0,v1118_4);
        Space v1118_8;
        if (!v1118_5.empty()) {
          const Path v1119_6 = concat_path(v1117_6,v1117_7_head);
          const Space v1119_7 = routine_164(c, v1119_6, v1117_7_tail);
          v1118_8 = compose(v1118_5,v1119_7);
        }
        const Space v1118_9 = intersect(constant_5,v1118_2);
        const Space v1118_10 = (has_head(v1118_9) ? constant_7 : Space{});
        Space v1118_12;
        if (!v1118_10.empty()) {
          const Path v1120_6 = concat_path(v1117_6,v1117_7_head);
          const Space v1120_11 = routine_165(c, v1120_6, v1117_7_tail);
          v1118_12 = compose(v1118_10,v1120_11);
        }
        const Space v1118_13 = unite(v1118_8,v1118_12);
        v1117_7_result = unite(v1117_7_result,v1118_13);
      }
      const Space v1117_7 = std::move(v1117_7_result);
      v1116_8 = compose(v1116_5,v1117_7);
    }
    const Space v1116_9 = intersect(constant_5,v1116_2);
    const Space v1116_10 = (has_head(v1116_9) ? constant_7 : Space{});
    Space v1116_12;
    if (!v1116_10.empty()) {
      const Path v1121_6 = concat_path(p0,v1115_11_head);
      Space v1121_11_result;
      for (int v1121_11_label = 1; v1121_11_label <= 2; ++v1121_11_label) {
        const Space v1121_11_tail = child(v1115_11_tail,v1121_11_label);
        if (v1121_11_tail.empty()) continue;
        const Path v1121_11_head{v1121_11_label};
        const Space v1122_2 = singleton(v1121_11_head);
        const Space v1122_3 = intersect(constant_5,v1122_2);
        const Space v1122_4 = (has_head(v1122_3) ? constant_7 : Space{});
        const Space v1122_5 = subtract(constant_0,v1122_4);
        Space v1122_8;
        if (!v1122_5.empty()) {
          const Path v1123_6 = concat_path(v1121_6,v1121_11_head);
          const Space v1123_7 = routine_164(c, v1123_6, v1121_11_tail);
          v1122_8 = compose(v1122_5,v1123_7);
        }
        const Space v1122_9 = intersect(constant_5,v1122_2);
        const Space v1122_10 = (has_head(v1122_9) ? constant_7 : Space{});
        Space v1122_12;
        if (!v1122_10.empty()) {
          const Path v1124_6 = concat_path(v1121_6,v1121_11_head);
          const Space v1124_11 = routine_79(c, v1124_6, v1121_11_tail);
          v1122_12 = compose(v1122_10,v1124_11);
        }
        const Space v1122_13 = unite(v1122_8,v1122_12);
        v1121_11_result = unite(v1121_11_result,v1122_13);
      }
      const Space v1121_11 = std::move(v1121_11_result);
      v1116_12 = compose(v1116_10,v1121_11);
    }
    const Space v1116_13 = unite(v1116_8,v1116_12);
    v1115_11_result = unite(v1115_11_result,v1116_13);
  }
  const Space v1115_11 = std::move(v1115_11_result);
  return v1115_11;
}

static Space routine_126(Context& c, const Path& p0, const Space& s0) {
  Space v1125_8_result;
  for (int v1125_8_label = 1; v1125_8_label <= 2; ++v1125_8_label) {
    const Space v1125_8_tail = child(s0,v1125_8_label);
    if (v1125_8_tail.empty()) continue;
    const Path v1125_8_head{v1125_8_label};
    const Space v1126_2 = singleton(v1125_8_head);
    const Space v1126_3 = intersect(constant_5,v1126_2);
    const Space v1126_4 = (has_head(v1126_3) ? constant_7 : Space{});
    const Space v1126_5 = subtract(constant_0,v1126_4);
    Space v1126_8;
    if (!v1126_5.empty()) {
      const Path v1127_6 = concat_path(p0,v1125_8_head);
      Space v1127_7_result;
      for (int v1127_7_label = 1; v1127_7_label <= 2; ++v1127_7_label) {
        const Space v1127_7_tail = child(v1125_8_tail,v1127_7_label);
        if (v1127_7_tail.empty()) continue;
        const Path v1127_7_head{v1127_7_label};
        const Space v1128_2 = singleton(v1127_7_head);
        const Space v1128_3 = intersect(constant_5,v1128_2);
        const Space v1128_4 = (has_head(v1128_3) ? constant_7 : Space{});
        const Space v1128_5 = subtract(constant_0,v1128_4);
        Space v1128_8;
        if (!v1128_5.empty()) {
          const Path v1129_6 = concat_path(v1127_6,v1127_7_head);
          const Space v1129_7 = routine_164(c, v1129_6, v1127_7_tail);
          v1128_8 = compose(v1128_5,v1129_7);
        }
        const Space v1128_9 = intersect(constant_5,v1128_2);
        const Space v1128_10 = (has_head(v1128_9) ? constant_7 : Space{});
        Space v1128_12;
        if (!v1128_10.empty()) {
          const Path v1130_6 = concat_path(v1127_6,v1127_7_head);
          const Space v1130_11 = routine_165(c, v1130_6, v1127_7_tail);
          v1128_12 = compose(v1128_10,v1130_11);
        }
        const Space v1128_13 = unite(v1128_8,v1128_12);
        v1127_7_result = unite(v1127_7_result,v1128_13);
      }
      const Space v1127_7 = std::move(v1127_7_result);
      v1126_8 = compose(v1126_5,v1127_7);
    }
    const Space v1126_9 = intersect(constant_5,v1126_2);
    const Space v1126_10 = (has_head(v1126_9) ? constant_7 : Space{});
    const Space v1126_11 = compose(v1126_10,v1125_8_tail);
    const Space v1126_12 = unite(v1126_8,v1126_11);
    v1125_8_result = unite(v1125_8_result,v1126_12);
  }
  const Space v1125_8 = std::move(v1125_8_result);
  return v1125_8;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1131_13_result;
  for (int v1131_13_label = 1; v1131_13_label <= 2; ++v1131_13_label) {
    const Space v1131_13_tail = child(s0,v1131_13_label);
    if (v1131_13_tail.empty()) continue;
    const Path v1131_13_head{v1131_13_label};
    const Space v1132_2 = singleton(v1131_13_head);
    const Space v1132_3 = intersect(constant_5,v1132_2);
    const Space v1132_4 = (has_head(v1132_3) ? constant_7 : Space{});
    const Space v1132_5 = subtract(constant_0,v1132_4);
    Space v1132_8;
    if (!v1132_5.empty()) {
      const Path v1133_6 = concat_path(p0,v1131_13_head);
      Space v1133_7_result;
      for (int v1133_7_label = 1; v1133_7_label <= 2; ++v1133_7_label) {
        const Space v1133_7_tail = child(v1131_13_tail,v1133_7_label);
        if (v1133_7_tail.empty()) continue;
        const Path v1133_7_head{v1133_7_label};
        const Space v1134_2 = singleton(v1133_7_head);
        const Space v1134_3 = intersect(constant_5,v1134_2);
        const Space v1134_4 = (has_head(v1134_3) ? constant_7 : Space{});
        const Space v1134_5 = subtract(constant_0,v1134_4);
        Space v1134_8;
        if (!v1134_5.empty()) {
          const Path v1135_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1135_7 = routine_166(c, v1135_6, p1, v1133_7_tail, s1);
          v1134_8 = compose(v1134_5,v1135_7);
        }
        const Space v1134_9 = intersect(constant_5,v1134_2);
        const Space v1134_10 = (has_head(v1134_9) ? constant_7 : Space{});
        Space v1134_12;
        if (!v1134_10.empty()) {
          const Path v1136_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1136_11 = routine_167(c, v1136_6, p1, v1133_7_tail, s1);
          v1134_12 = compose(v1134_10,v1136_11);
        }
        const Space v1134_13 = unite(v1134_8,v1134_12);
        v1133_7_result = unite(v1133_7_result,v1134_13);
      }
      const Space v1133_7 = std::move(v1133_7_result);
      v1132_8 = compose(v1132_5,v1133_7);
    }
    const Space v1132_9 = intersect(constant_5,v1132_2);
    const Space v1132_10 = (has_head(v1132_9) ? constant_7 : Space{});
    Space v1132_12;
    if (!v1132_10.empty()) {
      const Path v1137_6 = concat_path(p0,v1131_13_head);
      Space v1137_11_result;
      for (int v1137_11_label = 1; v1137_11_label <= 2; ++v1137_11_label) {
        const Space v1137_11_tail = child(v1131_13_tail,v1137_11_label);
        if (v1137_11_tail.empty()) continue;
        const Path v1137_11_head{v1137_11_label};
        const Space v1138_2 = singleton(v1137_11_head);
        const Space v1138_3 = intersect(constant_5,v1138_2);
        const Space v1138_4 = (has_head(v1138_3) ? constant_7 : Space{});
        const Space v1138_5 = subtract(constant_0,v1138_4);
        Space v1138_8;
        if (!v1138_5.empty()) {
          const Path v1139_6 = concat_path(v1137_6,v1137_11_head);
          const Space v1139_7 = routine_166(c, v1139_6, p1, v1137_11_tail, s1);
          v1138_8 = compose(v1138_5,v1139_7);
        }
        const Space v1138_9 = intersect(constant_5,v1138_2);
        const Space v1138_10 = (has_head(v1138_9) ? constant_7 : Space{});
        Space v1138_12;
        if (!v1138_10.empty()) {
          const Path v1140_6 = concat_path(v1137_6,v1137_11_head);
          const Space v1140_11 = routine_33(c, v1140_6, p1, v1137_11_tail, s1);
          v1138_12 = compose(v1138_10,v1140_11);
        }
        const Space v1138_13 = unite(v1138_8,v1138_12);
        v1137_11_result = unite(v1137_11_result,v1138_13);
      }
      const Space v1137_11 = std::move(v1137_11_result);
      v1132_12 = compose(v1132_10,v1137_11);
    }
    const Space v1132_13 = unite(v1132_8,v1132_12);
    v1131_13_result = unite(v1131_13_result,v1132_13);
  }
  const Space v1131_13 = std::move(v1131_13_result);
  return v1131_13;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1141_8 = unwrap(constant_9,p1);
  const Space v1141_10 = unwrap(constant_9,p0);
  const Space v1141_12 = unwrap(s1,constant_8);
  const Space v1141_14 = unwrap(constant_9,p1);
  const Space v1141_16 = unwrap(constant_9,p0);
  Space v1141_29_result;
  for (int v1141_29_label = 1; v1141_29_label <= 2; ++v1141_29_label) {
    const Space v1141_29_tail = child(s0,v1141_29_label);
    if (v1141_29_tail.empty()) continue;
    const Path v1141_29_head{v1141_29_label};
    const Space v1142_2 = singleton(v1141_29_head);
    const Space v1142_3 = intersect(constant_5,v1142_2);
    const Space v1142_4 = (has_head(v1142_3) ? constant_7 : Space{});
    const Space v1142_5 = subtract(constant_0,v1142_4);
    Space v1142_8;
    if (!v1142_5.empty()) {
      const Path v1143_6 = concat_path(p0,v1141_29_head);
      Space v1143_7_result;
      for (int v1143_7_label = 1; v1143_7_label <= 2; ++v1143_7_label) {
        const Space v1143_7_tail = child(v1141_29_tail,v1143_7_label);
        if (v1143_7_tail.empty()) continue;
        const Path v1143_7_head{v1143_7_label};
        const Space v1144_2 = singleton(v1143_7_head);
        const Space v1144_3 = intersect(constant_5,v1144_2);
        const Space v1144_4 = (has_head(v1144_3) ? constant_7 : Space{});
        const Space v1144_5 = subtract(constant_0,v1144_4);
        Space v1144_8;
        if (!v1144_5.empty()) {
          const Path v1145_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1145_7 = routine_166(c, v1145_6, p1, v1143_7_tail, s1);
          v1144_8 = compose(v1144_5,v1145_7);
        }
        const Space v1144_9 = intersect(constant_5,v1144_2);
        const Space v1144_10 = (has_head(v1144_9) ? constant_7 : Space{});
        Space v1144_12;
        if (!v1144_10.empty()) {
          const Path v1146_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1146_11 = routine_167(c, v1146_6, p1, v1143_7_tail, s1);
          v1144_12 = compose(v1144_10,v1146_11);
        }
        const Space v1144_13 = unite(v1144_8,v1144_12);
        v1143_7_result = unite(v1143_7_result,v1144_13);
      }
      const Space v1143_7 = std::move(v1143_7_result);
      v1142_8 = compose(v1142_5,v1143_7);
    }
    const Space v1142_9 = intersect(constant_5,v1142_2);
    const Space v1142_10 = (has_head(v1142_9) ? constant_7 : Space{});
    Space v1142_28;
    if (!v1142_10.empty()) {
      const Path v1147_6 = concat_path(p0,v1141_29_head);
      const Space v1147_11 = unwrap(v1141_10,v1141_29_head);
      const Space v1147_12 = compose(v1141_8,v1147_11);
      const Path v1147_13 = concat_path(p1,v1147_6);
      const Space v1147_14 = singleton(v1147_13);
      const Space v1147_15 = subtract(v1147_12,v1147_14);
      const Space v1147_16 = intersect(v1147_15,v1141_12);
      const Space v1147_17 = routine_36(c, v1147_16);
      Space v1147_18_result;
      for (int v1147_18_label = 1; v1147_18_label <= 2; ++v1147_18_label) {
        const Space v1147_18_tail = child(v1147_17,v1147_18_label);
        if (v1147_18_tail.empty()) continue;
        const Path v1147_18_head{v1147_18_label};
        const Space v1148_2 = singleton(v1147_18_head);
        const Space v1148_3 = intersect(constant_5,v1148_2);
        const Space v1148_4 = (has_head(v1148_3) ? constant_7 : Space{});
        const Space v1148_5 = subtract(constant_0,v1148_4);
        Space v1148_7;
        if (!v1148_5.empty()) {
          const Space v1149_6 = routine_37(c, v1147_18_head, v1147_18_tail);
          v1148_7 = compose(v1148_5,v1149_6);
        }
        const Space v1148_8 = intersect(constant_5,v1148_2);
        const Space v1148_9 = (has_head(v1148_8) ? constant_7 : Space{});
        Space v1148_11;
        if (!v1148_9.empty()) {
          const Space v1150_10 = routine_38(c, v1147_18_head, v1147_18_tail);
          v1148_11 = compose(v1148_9,v1150_10);
        }
        const Space v1148_12 = unite(v1148_7,v1148_11);
        v1147_18_result = unite(v1147_18_result,v1148_12);
      }
      const Space v1147_18 = std::move(v1147_18_result);
      const Space v1147_19 = unwrap(v1141_16,v1141_29_head);
      const Space v1147_20 = compose(v1141_14,v1147_19);
      const Space v1147_21 = subtract(v1147_20,v1147_14);
      const Space v1147_22 = intersect(v1147_21,v1141_12);
      const Space v1147_23 = routine_39(c, v1147_22);
      Space v1147_24_result;
      for (int v1147_24_label = 1; v1147_24_label <= 2; ++v1147_24_label) {
        const Space v1147_24_tail = child(v1147_23,v1147_24_label);
        if (v1147_24_tail.empty()) continue;
        const Path v1147_24_head{v1147_24_label};
        const Space v1151_2 = singleton(v1147_24_head);
        const Space v1151_3 = intersect(constant_5,v1151_2);
        const Space v1151_4 = (has_head(v1151_3) ? constant_7 : Space{});
        const Space v1151_5 = subtract(constant_0,v1151_4);
        Space v1151_7;
        if (!v1151_5.empty()) {
          const Space v1152_6 = routine_40(c, v1147_24_head, v1147_24_tail);
          v1151_7 = compose(v1151_5,v1152_6);
        }
        const Space v1151_8 = intersect(constant_5,v1151_2);
        const Space v1151_9 = (has_head(v1151_8) ? constant_7 : Space{});
        Space v1151_11;
        if (!v1151_9.empty()) {
          const Space v1153_10 = routine_41(c, v1147_24_head, v1147_24_tail);
          v1151_11 = compose(v1151_9,v1153_10);
        }
        const Space v1151_12 = unite(v1151_7,v1151_11);
        v1147_24_result = unite(v1147_24_result,v1151_12);
      }
      const Space v1147_24 = std::move(v1147_24_result);
      const Space v1147_25 = subtract(v1147_18,v1147_24);
      const Space v1147_26 = compose(v1147_25,v1147_14);
      Space v1147_27_result;
      for (int v1147_27_label = 1; v1147_27_label <= 2; ++v1147_27_label) {
        const Space v1147_27_tail = child(v1147_26,v1147_27_label);
        if (v1147_27_tail.empty()) continue;
        const Path v1147_27_head{v1147_27_label};
        const Space v1154_2 = singleton(v1147_27_head);
        const Space v1154_3 = intersect(constant_5,v1154_2);
        const Space v1154_4 = (has_head(v1154_3) ? constant_7 : Space{});
        const Space v1154_5 = subtract(constant_0,v1154_4);
        Space v1154_7;
        if (!v1154_5.empty()) {
          const Space v1155_6 = routine_42(c, v1147_27_head, v1147_27_tail);
          v1154_7 = compose(v1154_5,v1155_6);
        }
        const Space v1154_8 = intersect(constant_5,v1154_2);
        const Space v1154_9 = (has_head(v1154_8) ? constant_7 : Space{});
        Space v1154_11;
        if (!v1154_9.empty()) {
          const Space v1156_10 = routine_43(c, v1147_27_head, v1147_27_tail);
          v1154_11 = compose(v1154_9,v1156_10);
        }
        const Space v1154_12 = unite(v1154_7,v1154_11);
        v1147_27_result = unite(v1147_27_result,v1154_12);
      }
      const Space v1147_27 = std::move(v1147_27_result);
      v1142_28 = compose(v1142_10,v1147_27);
    }
    const Space v1142_29 = unite(v1142_8,v1142_28);
    v1141_29_result = unite(v1141_29_result,v1142_29);
  }
  const Space v1141_29 = std::move(v1141_29_result);
  return v1141_29;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0) {
  const Space v1157_3 = unwrap(s0,p0);
  const Space v1157_4 = first_matching(v1157_3,constant_0,false);
  const Space v1157_5 = intersect(constant_0,v1157_4);
  const Space v1157_6 = (has_head(v1157_4) ? constant_7 : Space{});
  const Space v1157_7 = unite(v1157_5,v1157_6);
  const Space v1157_9 = compose(v1157_7,constant_0);
  const Space v1157_11 = subtract(constant_0,v1157_4);
  const Space v1157_12 = subtract(v1157_11,v1157_6);
  Space v1157_16;
  if (!v1157_12.empty()) {
    const Space v1158_14 = first_listed(v1157_3,constant_12,true);
    const Space v1158_15 = routine_120(c, constant_11, v1158_14, v1157_3);
    v1157_16 = compose(v1157_12,v1158_15);
  }
  const Space v1157_17 = unite(v1157_9,v1157_16);
  const Space v1157_18 = wrap(v1157_17,p0);
  return v1157_18;
}

static Space routine_130(Context& c, const Path& p0, const Space& s0) {
  Space v1159_11_result;
  for (int v1159_11_label = 1; v1159_11_label <= 2; ++v1159_11_label) {
    const Space v1159_11_tail = child(s0,v1159_11_label);
    if (v1159_11_tail.empty()) continue;
    const Path v1159_11_head{v1159_11_label};
    const Space v1160_2 = singleton(v1159_11_head);
    const Space v1160_3 = intersect(constant_5,v1160_2);
    const Space v1160_4 = (has_head(v1160_3) ? constant_7 : Space{});
    const Space v1160_5 = subtract(constant_0,v1160_4);
    Space v1160_8;
    if (!v1160_5.empty()) {
      const Path v1161_6 = concat_path(p0,v1159_11_head);
      Space v1161_7_result;
      for (int v1161_7_label = 1; v1161_7_label <= 2; ++v1161_7_label) {
        const Space v1161_7_tail = child(v1159_11_tail,v1161_7_label);
        if (v1161_7_tail.empty()) continue;
        const Path v1161_7_head{v1161_7_label};
        const Space v1162_2 = singleton(v1161_7_head);
        const Space v1162_3 = intersect(constant_5,v1162_2);
        const Space v1162_4 = (has_head(v1162_3) ? constant_7 : Space{});
        const Space v1162_5 = subtract(constant_0,v1162_4);
        Space v1162_8;
        if (!v1162_5.empty()) {
          const Path v1163_6 = concat_path(v1161_6,v1161_7_head);
          const Space v1163_7 = routine_168(c, v1163_6, v1161_7_tail);
          v1162_8 = compose(v1162_5,v1163_7);
        }
        const Space v1162_9 = intersect(constant_5,v1162_2);
        const Space v1162_10 = (has_head(v1162_9) ? constant_7 : Space{});
        Space v1162_12;
        if (!v1162_10.empty()) {
          const Path v1164_6 = concat_path(v1161_6,v1161_7_head);
          const Space v1164_11 = routine_169(c, v1164_6, v1161_7_tail);
          v1162_12 = compose(v1162_10,v1164_11);
        }
        const Space v1162_13 = unite(v1162_8,v1162_12);
        v1161_7_result = unite(v1161_7_result,v1162_13);
      }
      const Space v1161_7 = std::move(v1161_7_result);
      v1160_8 = compose(v1160_5,v1161_7);
    }
    const Space v1160_9 = intersect(constant_5,v1160_2);
    const Space v1160_10 = (has_head(v1160_9) ? constant_7 : Space{});
    Space v1160_12;
    if (!v1160_10.empty()) {
      const Path v1165_6 = concat_path(p0,v1159_11_head);
      Space v1165_11_result;
      for (int v1165_11_label = 1; v1165_11_label <= 2; ++v1165_11_label) {
        const Space v1165_11_tail = child(v1159_11_tail,v1165_11_label);
        if (v1165_11_tail.empty()) continue;
        const Path v1165_11_head{v1165_11_label};
        const Space v1166_2 = singleton(v1165_11_head);
        const Space v1166_3 = intersect(constant_5,v1166_2);
        const Space v1166_4 = (has_head(v1166_3) ? constant_7 : Space{});
        const Space v1166_5 = subtract(constant_0,v1166_4);
        Space v1166_8;
        if (!v1166_5.empty()) {
          const Path v1167_6 = concat_path(v1165_6,v1165_11_head);
          const Space v1167_7 = routine_168(c, v1167_6, v1165_11_tail);
          v1166_8 = compose(v1166_5,v1167_7);
        }
        const Space v1166_9 = intersect(constant_5,v1166_2);
        const Space v1166_10 = (has_head(v1166_9) ? constant_7 : Space{});
        Space v1166_12;
        if (!v1166_10.empty()) {
          const Path v1168_6 = concat_path(v1165_6,v1165_11_head);
          const Space v1168_11 = routine_72(c, v1168_6, v1165_11_tail);
          v1166_12 = compose(v1166_10,v1168_11);
        }
        const Space v1166_13 = unite(v1166_8,v1166_12);
        v1165_11_result = unite(v1165_11_result,v1166_13);
      }
      const Space v1165_11 = std::move(v1165_11_result);
      v1160_12 = compose(v1160_10,v1165_11);
    }
    const Space v1160_13 = unite(v1160_8,v1160_12);
    v1159_11_result = unite(v1159_11_result,v1160_13);
  }
  const Space v1159_11 = std::move(v1159_11_result);
  return v1159_11;
}

static Space routine_131(Context& c, const Path& p0, const Space& s0) {
  Space v1169_9_result;
  for (int v1169_9_label = 1; v1169_9_label <= 2; ++v1169_9_label) {
    const Space v1169_9_tail = child(s0,v1169_9_label);
    if (v1169_9_tail.empty()) continue;
    const Path v1169_9_head{v1169_9_label};
    const Space v1170_2 = singleton(v1169_9_head);
    const Space v1170_3 = intersect(constant_5,v1170_2);
    const Space v1170_4 = (has_head(v1170_3) ? constant_7 : Space{});
    const Space v1170_5 = subtract(constant_0,v1170_4);
    Space v1170_8;
    if (!v1170_5.empty()) {
      const Path v1171_6 = concat_path(p0,v1169_9_head);
      Space v1171_7_result;
      for (int v1171_7_label = 1; v1171_7_label <= 2; ++v1171_7_label) {
        const Space v1171_7_tail = child(v1169_9_tail,v1171_7_label);
        if (v1171_7_tail.empty()) continue;
        const Path v1171_7_head{v1171_7_label};
        const Space v1172_2 = singleton(v1171_7_head);
        const Space v1172_3 = intersect(constant_5,v1172_2);
        const Space v1172_4 = (has_head(v1172_3) ? constant_7 : Space{});
        const Space v1172_5 = subtract(constant_0,v1172_4);
        Space v1172_8;
        if (!v1172_5.empty()) {
          const Path v1173_6 = concat_path(v1171_6,v1171_7_head);
          const Space v1173_7 = routine_168(c, v1173_6, v1171_7_tail);
          v1172_8 = compose(v1172_5,v1173_7);
        }
        const Space v1172_9 = intersect(constant_5,v1172_2);
        const Space v1172_10 = (has_head(v1172_9) ? constant_7 : Space{});
        Space v1172_12;
        if (!v1172_10.empty()) {
          const Path v1174_6 = concat_path(v1171_6,v1171_7_head);
          const Space v1174_11 = routine_169(c, v1174_6, v1171_7_tail);
          v1172_12 = compose(v1172_10,v1174_11);
        }
        const Space v1172_13 = unite(v1172_8,v1172_12);
        v1171_7_result = unite(v1171_7_result,v1172_13);
      }
      const Space v1171_7 = std::move(v1171_7_result);
      v1170_8 = compose(v1170_5,v1171_7);
    }
    const Space v1170_9 = intersect(constant_5,v1170_2);
    const Space v1170_10 = (has_head(v1170_9) ? constant_7 : Space{});
    const Space v1170_11 = compose(v1170_10,constant_10);
    const Space v1170_12 = unite(v1170_8,v1170_11);
    v1169_9_result = unite(v1169_9_result,v1170_12);
  }
  const Space v1169_9 = std::move(v1169_9_result);
  return v1169_9;
}

static Space routine_132(Context& c, const Path& p0, const Space& s0) {
  Space v1175_11_result;
  for (int v1175_11_label = 1; v1175_11_label <= 2; ++v1175_11_label) {
    const Space v1175_11_tail = child(s0,v1175_11_label);
    if (v1175_11_tail.empty()) continue;
    const Path v1175_11_head{v1175_11_label};
    const Space v1176_2 = singleton(v1175_11_head);
    const Space v1176_3 = intersect(constant_5,v1176_2);
    const Space v1176_4 = (has_head(v1176_3) ? constant_7 : Space{});
    const Space v1176_5 = subtract(constant_0,v1176_4);
    Space v1176_8;
    if (!v1176_5.empty()) {
      const Path v1177_6 = concat_path(p0,v1175_11_head);
      Space v1177_7_result;
      for (int v1177_7_label = 1; v1177_7_label <= 2; ++v1177_7_label) {
        const Space v1177_7_tail = child(v1175_11_tail,v1177_7_label);
        if (v1177_7_tail.empty()) continue;
        const Path v1177_7_head{v1177_7_label};
        const Space v1178_2 = singleton(v1177_7_head);
        const Space v1178_3 = intersect(constant_5,v1178_2);
        const Space v1178_4 = (has_head(v1178_3) ? constant_7 : Space{});
        const Space v1178_5 = subtract(constant_0,v1178_4);
        Space v1178_8;
        if (!v1178_5.empty()) {
          const Path v1179_6 = concat_path(v1177_6,v1177_7_head);
          const Space v1179_7 = routine_170(c, v1179_6, v1177_7_tail);
          v1178_8 = compose(v1178_5,v1179_7);
        }
        const Space v1178_9 = intersect(constant_5,v1178_2);
        const Space v1178_10 = (has_head(v1178_9) ? constant_7 : Space{});
        Space v1178_12;
        if (!v1178_10.empty()) {
          const Path v1180_6 = concat_path(v1177_6,v1177_7_head);
          const Space v1180_11 = routine_171(c, v1180_6, v1177_7_tail);
          v1178_12 = compose(v1178_10,v1180_11);
        }
        const Space v1178_13 = unite(v1178_8,v1178_12);
        v1177_7_result = unite(v1177_7_result,v1178_13);
      }
      const Space v1177_7 = std::move(v1177_7_result);
      v1176_8 = compose(v1176_5,v1177_7);
    }
    const Space v1176_9 = intersect(constant_5,v1176_2);
    const Space v1176_10 = (has_head(v1176_9) ? constant_7 : Space{});
    Space v1176_12;
    if (!v1176_10.empty()) {
      const Path v1181_6 = concat_path(p0,v1175_11_head);
      Space v1181_11_result;
      for (int v1181_11_label = 1; v1181_11_label <= 2; ++v1181_11_label) {
        const Space v1181_11_tail = child(v1175_11_tail,v1181_11_label);
        if (v1181_11_tail.empty()) continue;
        const Path v1181_11_head{v1181_11_label};
        const Space v1182_2 = singleton(v1181_11_head);
        const Space v1182_3 = intersect(constant_5,v1182_2);
        const Space v1182_4 = (has_head(v1182_3) ? constant_7 : Space{});
        const Space v1182_5 = subtract(constant_0,v1182_4);
        Space v1182_8;
        if (!v1182_5.empty()) {
          const Path v1183_6 = concat_path(v1181_6,v1181_11_head);
          const Space v1183_7 = routine_170(c, v1183_6, v1181_11_tail);
          v1182_8 = compose(v1182_5,v1183_7);
        }
        const Space v1182_9 = intersect(constant_5,v1182_2);
        const Space v1182_10 = (has_head(v1182_9) ? constant_7 : Space{});
        Space v1182_12;
        if (!v1182_10.empty()) {
          const Path v1184_6 = concat_path(v1181_6,v1181_11_head);
          const Space v1184_11 = routine_76(c, v1184_6, v1181_11_tail);
          v1182_12 = compose(v1182_10,v1184_11);
        }
        const Space v1182_13 = unite(v1182_8,v1182_12);
        v1181_11_result = unite(v1181_11_result,v1182_13);
      }
      const Space v1181_11 = std::move(v1181_11_result);
      v1176_12 = compose(v1176_10,v1181_11);
    }
    const Space v1176_13 = unite(v1176_8,v1176_12);
    v1175_11_result = unite(v1175_11_result,v1176_13);
  }
  const Space v1175_11 = std::move(v1175_11_result);
  return v1175_11;
}

static Space routine_133(Context& c, const Path& p0, const Space& s0) {
  Space v1185_9_result;
  for (int v1185_9_label = 1; v1185_9_label <= 2; ++v1185_9_label) {
    const Space v1185_9_tail = child(s0,v1185_9_label);
    if (v1185_9_tail.empty()) continue;
    const Path v1185_9_head{v1185_9_label};
    const Space v1186_2 = singleton(v1185_9_head);
    const Space v1186_3 = intersect(constant_5,v1186_2);
    const Space v1186_4 = (has_head(v1186_3) ? constant_7 : Space{});
    const Space v1186_5 = subtract(constant_0,v1186_4);
    Space v1186_8;
    if (!v1186_5.empty()) {
      const Path v1187_6 = concat_path(p0,v1185_9_head);
      Space v1187_7_result;
      for (int v1187_7_label = 1; v1187_7_label <= 2; ++v1187_7_label) {
        const Space v1187_7_tail = child(v1185_9_tail,v1187_7_label);
        if (v1187_7_tail.empty()) continue;
        const Path v1187_7_head{v1187_7_label};
        const Space v1188_2 = singleton(v1187_7_head);
        const Space v1188_3 = intersect(constant_5,v1188_2);
        const Space v1188_4 = (has_head(v1188_3) ? constant_7 : Space{});
        const Space v1188_5 = subtract(constant_0,v1188_4);
        Space v1188_8;
        if (!v1188_5.empty()) {
          const Path v1189_6 = concat_path(v1187_6,v1187_7_head);
          const Space v1189_7 = routine_170(c, v1189_6, v1187_7_tail);
          v1188_8 = compose(v1188_5,v1189_7);
        }
        const Space v1188_9 = intersect(constant_5,v1188_2);
        const Space v1188_10 = (has_head(v1188_9) ? constant_7 : Space{});
        Space v1188_12;
        if (!v1188_10.empty()) {
          const Path v1190_6 = concat_path(v1187_6,v1187_7_head);
          const Space v1190_11 = routine_171(c, v1190_6, v1187_7_tail);
          v1188_12 = compose(v1188_10,v1190_11);
        }
        const Space v1188_13 = unite(v1188_8,v1188_12);
        v1187_7_result = unite(v1187_7_result,v1188_13);
      }
      const Space v1187_7 = std::move(v1187_7_result);
      v1186_8 = compose(v1186_5,v1187_7);
    }
    const Space v1186_9 = intersect(constant_5,v1186_2);
    const Space v1186_10 = (has_head(v1186_9) ? constant_7 : Space{});
    const Space v1186_11 = compose(v1186_10,constant_10);
    const Space v1186_12 = unite(v1186_8,v1186_11);
    v1185_9_result = unite(v1185_9_result,v1186_12);
  }
  const Space v1185_9 = std::move(v1185_9_result);
  return v1185_9;
}

static Space routine_134(Context& c, const Path& p0, const Space& s0) {
  Space v1191_11_result;
  for (int v1191_11_label = 1; v1191_11_label <= 2; ++v1191_11_label) {
    const Space v1191_11_tail = child(s0,v1191_11_label);
    if (v1191_11_tail.empty()) continue;
    const Path v1191_11_head{v1191_11_label};
    const Space v1192_2 = singleton(v1191_11_head);
    const Space v1192_3 = intersect(constant_5,v1192_2);
    const Space v1192_4 = (has_head(v1192_3) ? constant_7 : Space{});
    const Space v1192_5 = subtract(constant_0,v1192_4);
    Space v1192_8;
    if (!v1192_5.empty()) {
      const Path v1193_6 = concat_path(p0,v1191_11_head);
      Space v1193_7_result;
      for (int v1193_7_label = 1; v1193_7_label <= 2; ++v1193_7_label) {
        const Space v1193_7_tail = child(v1191_11_tail,v1193_7_label);
        if (v1193_7_tail.empty()) continue;
        const Path v1193_7_head{v1193_7_label};
        const Space v1194_2 = singleton(v1193_7_head);
        const Space v1194_3 = intersect(constant_5,v1194_2);
        const Space v1194_4 = (has_head(v1194_3) ? constant_7 : Space{});
        const Space v1194_5 = subtract(constant_0,v1194_4);
        Space v1194_8;
        if (!v1194_5.empty()) {
          const Path v1195_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1195_7 = routine_172(c, v1195_6, v1193_7_tail);
          v1194_8 = compose(v1194_5,v1195_7);
        }
        const Space v1194_9 = intersect(constant_5,v1194_2);
        const Space v1194_10 = (has_head(v1194_9) ? constant_7 : Space{});
        Space v1194_12;
        if (!v1194_10.empty()) {
          const Path v1196_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1196_11 = routine_173(c, v1196_6, v1193_7_tail);
          v1194_12 = compose(v1194_10,v1196_11);
        }
        const Space v1194_13 = unite(v1194_8,v1194_12);
        v1193_7_result = unite(v1193_7_result,v1194_13);
      }
      const Space v1193_7 = std::move(v1193_7_result);
      v1192_8 = compose(v1192_5,v1193_7);
    }
    const Space v1192_9 = intersect(constant_5,v1192_2);
    const Space v1192_10 = (has_head(v1192_9) ? constant_7 : Space{});
    Space v1192_12;
    if (!v1192_10.empty()) {
      const Path v1197_6 = concat_path(p0,v1191_11_head);
      Space v1197_11_result;
      for (int v1197_11_label = 1; v1197_11_label <= 2; ++v1197_11_label) {
        const Space v1197_11_tail = child(v1191_11_tail,v1197_11_label);
        if (v1197_11_tail.empty()) continue;
        const Path v1197_11_head{v1197_11_label};
        const Space v1198_2 = singleton(v1197_11_head);
        const Space v1198_3 = intersect(constant_5,v1198_2);
        const Space v1198_4 = (has_head(v1198_3) ? constant_7 : Space{});
        const Space v1198_5 = subtract(constant_0,v1198_4);
        Space v1198_8;
        if (!v1198_5.empty()) {
          const Path v1199_6 = concat_path(v1197_6,v1197_11_head);
          const Space v1199_7 = routine_172(c, v1199_6, v1197_11_tail);
          v1198_8 = compose(v1198_5,v1199_7);
        }
        const Space v1198_9 = intersect(constant_5,v1198_2);
        const Space v1198_10 = (has_head(v1198_9) ? constant_7 : Space{});
        Space v1198_12;
        if (!v1198_10.empty()) {
          const Path v1200_6 = concat_path(v1197_6,v1197_11_head);
          const Space v1200_11 = routine_79(c, v1200_6, v1197_11_tail);
          v1198_12 = compose(v1198_10,v1200_11);
        }
        const Space v1198_13 = unite(v1198_8,v1198_12);
        v1197_11_result = unite(v1197_11_result,v1198_13);
      }
      const Space v1197_11 = std::move(v1197_11_result);
      v1192_12 = compose(v1192_10,v1197_11);
    }
    const Space v1192_13 = unite(v1192_8,v1192_12);
    v1191_11_result = unite(v1191_11_result,v1192_13);
  }
  const Space v1191_11 = std::move(v1191_11_result);
  return v1191_11;
}

static Space routine_135(Context& c, const Path& p0, const Space& s0) {
  Space v1201_8_result;
  for (int v1201_8_label = 1; v1201_8_label <= 2; ++v1201_8_label) {
    const Space v1201_8_tail = child(s0,v1201_8_label);
    if (v1201_8_tail.empty()) continue;
    const Path v1201_8_head{v1201_8_label};
    const Space v1202_2 = singleton(v1201_8_head);
    const Space v1202_3 = intersect(constant_5,v1202_2);
    const Space v1202_4 = (has_head(v1202_3) ? constant_7 : Space{});
    const Space v1202_5 = subtract(constant_0,v1202_4);
    Space v1202_8;
    if (!v1202_5.empty()) {
      const Path v1203_6 = concat_path(p0,v1201_8_head);
      Space v1203_7_result;
      for (int v1203_7_label = 1; v1203_7_label <= 2; ++v1203_7_label) {
        const Space v1203_7_tail = child(v1201_8_tail,v1203_7_label);
        if (v1203_7_tail.empty()) continue;
        const Path v1203_7_head{v1203_7_label};
        const Space v1204_2 = singleton(v1203_7_head);
        const Space v1204_3 = intersect(constant_5,v1204_2);
        const Space v1204_4 = (has_head(v1204_3) ? constant_7 : Space{});
        const Space v1204_5 = subtract(constant_0,v1204_4);
        Space v1204_8;
        if (!v1204_5.empty()) {
          const Path v1205_6 = concat_path(v1203_6,v1203_7_head);
          const Space v1205_7 = routine_172(c, v1205_6, v1203_7_tail);
          v1204_8 = compose(v1204_5,v1205_7);
        }
        const Space v1204_9 = intersect(constant_5,v1204_2);
        const Space v1204_10 = (has_head(v1204_9) ? constant_7 : Space{});
        Space v1204_12;
        if (!v1204_10.empty()) {
          const Path v1206_6 = concat_path(v1203_6,v1203_7_head);
          const Space v1206_11 = routine_173(c, v1206_6, v1203_7_tail);
          v1204_12 = compose(v1204_10,v1206_11);
        }
        const Space v1204_13 = unite(v1204_8,v1204_12);
        v1203_7_result = unite(v1203_7_result,v1204_13);
      }
      const Space v1203_7 = std::move(v1203_7_result);
      v1202_8 = compose(v1202_5,v1203_7);
    }
    const Space v1202_9 = intersect(constant_5,v1202_2);
    const Space v1202_10 = (has_head(v1202_9) ? constant_7 : Space{});
    const Space v1202_11 = compose(v1202_10,v1201_8_tail);
    const Space v1202_12 = unite(v1202_8,v1202_11);
    v1201_8_result = unite(v1201_8_result,v1202_12);
  }
  const Space v1201_8 = std::move(v1201_8_result);
  return v1201_8;
}

static Space routine_136(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1207_5_result;
  for (int v1207_5_label = 1; v1207_5_label <= 2; ++v1207_5_label) {
    const Space v1207_5_tail = child(s0,v1207_5_label);
    if (v1207_5_tail.empty()) continue;
    const Path v1207_5_head{v1207_5_label};
    const Space v1208_2 = singleton(v1207_5_head);
    const Space v1208_3 = intersect(constant_5,v1208_2);
    const Space v1208_4 = (has_head(v1208_3) ? constant_7 : Space{});
    Space v1208_7;
    if (!v1208_4.empty()) {
      const Path v1209_5 = concat_path(p0,v1207_5_head);
      Space v1209_6_result;
      for (int v1209_6_label = 1; v1209_6_label <= 2; ++v1209_6_label) {
        const Space v1209_6_tail = child(v1207_5_tail,v1209_6_label);
        if (v1209_6_tail.empty()) continue;
        const Path v1209_6_head{v1209_6_label};
        const Space v1210_2 = singleton(v1209_6_head);
        const Space v1210_3 = intersect(constant_5,v1210_2);
        const Space v1210_4 = (has_head(v1210_3) ? constant_7 : Space{});
        Space v1210_7;
        if (!v1210_4.empty()) {
          const Path v1211_5 = concat_path(v1209_5,v1209_6_head);
          const Space v1211_6 = routine_19(c, v1211_5, v1209_6_tail, s1);
          v1210_7 = compose(v1210_4,v1211_6);
        }
        v1209_6_result = unite(v1209_6_result,v1210_7);
      }
      const Space v1209_6 = std::move(v1209_6_result);
      v1208_7 = compose(v1208_4,v1209_6);
    }
    v1207_5_result = unite(v1207_5_result,v1208_7);
  }
  const Space v1207_5 = std::move(v1207_5_result);
  return v1207_5;
}

static Space routine_137(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1212_7_result;
  for (int v1212_7_label = 1; v1212_7_label <= 2; ++v1212_7_label) {
    const Space v1212_7_tail = child(s0,v1212_7_label);
    if (v1212_7_tail.empty()) continue;
    const Path v1212_7_head{v1212_7_label};
    const Space v1213_2 = singleton(v1212_7_head);
    const Space v1213_3 = intersect(constant_5,v1213_2);
    const Space v1213_4 = (has_head(v1213_3) ? constant_7 : Space{});
    Space v1213_7;
    if (!v1213_4.empty()) {
      const Path v1214_5 = concat_path(p0,v1212_7_head);
      Space v1214_6_result;
      for (int v1214_6_label = 1; v1214_6_label <= 2; ++v1214_6_label) {
        const Space v1214_6_tail = child(v1212_7_tail,v1214_6_label);
        if (v1214_6_tail.empty()) continue;
        const Path v1214_6_head{v1214_6_label};
        const Space v1215_2 = singleton(v1214_6_head);
        const Space v1215_3 = intersect(constant_5,v1215_2);
        const Space v1215_4 = (has_head(v1215_3) ? constant_7 : Space{});
        const Space v1215_5 = subtract(constant_0,v1215_4);
        Space v1215_7;
        if (!v1215_5.empty()) {
          const Space v1216_6 = routine_20(c, v1214_6_head, v1214_5, v1214_6_tail, s1);
          v1215_7 = compose(v1215_5,v1216_6);
        }
        const Space v1215_8 = intersect(constant_5,v1215_2);
        const Space v1215_9 = (has_head(v1215_8) ? constant_7 : Space{});
        Space v1215_11;
        if (!v1215_9.empty()) {
          const Space v1217_10 = routine_21(c, v1214_6_head, v1214_5, v1214_6_tail, s1);
          v1215_11 = compose(v1215_9,v1217_10);
        }
        const Space v1215_12 = unite(v1215_7,v1215_11);
        v1214_6_result = unite(v1214_6_result,v1215_12);
      }
      const Space v1214_6 = std::move(v1214_6_result);
      v1213_7 = compose(v1213_4,v1214_6);
    }
    v1212_7_result = unite(v1212_7_result,v1213_7);
  }
  const Space v1212_7 = std::move(v1212_7_result);
  return v1212_7;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1218_13_result;
  for (int v1218_13_label = 1; v1218_13_label <= 2; ++v1218_13_label) {
    const Space v1218_13_tail = child(s0,v1218_13_label);
    if (v1218_13_tail.empty()) continue;
    const Path v1218_13_head{v1218_13_label};
    const Space v1219_2 = singleton(v1218_13_head);
    const Space v1219_3 = intersect(constant_5,v1219_2);
    const Space v1219_4 = (has_head(v1219_3) ? constant_7 : Space{});
    const Space v1219_5 = subtract(constant_0,v1219_4);
    Space v1219_8;
    if (!v1219_5.empty()) {
      const Path v1220_6 = concat_path(p0,v1218_13_head);
      Space v1220_7_result;
      for (int v1220_7_label = 1; v1220_7_label <= 2; ++v1220_7_label) {
        const Space v1220_7_tail = child(v1218_13_tail,v1220_7_label);
        if (v1220_7_tail.empty()) continue;
        const Path v1220_7_head{v1220_7_label};
        const Space v1221_2 = singleton(v1220_7_head);
        const Space v1221_3 = intersect(constant_5,v1221_2);
        const Space v1221_4 = (has_head(v1221_3) ? constant_7 : Space{});
        const Space v1221_5 = subtract(constant_0,v1221_4);
        Space v1221_8;
        if (!v1221_5.empty()) {
          const Path v1222_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1222_7 = routine_174(c, v1222_6, p1, v1220_7_tail, s1);
          v1221_8 = compose(v1221_5,v1222_7);
        }
        const Space v1221_9 = intersect(constant_5,v1221_2);
        const Space v1221_10 = (has_head(v1221_9) ? constant_7 : Space{});
        Space v1221_12;
        if (!v1221_10.empty()) {
          const Path v1223_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1223_11 = routine_175(c, v1223_6, p1, v1220_7_tail, s1);
          v1221_12 = compose(v1221_10,v1223_11);
        }
        const Space v1221_13 = unite(v1221_8,v1221_12);
        v1220_7_result = unite(v1220_7_result,v1221_13);
      }
      const Space v1220_7 = std::move(v1220_7_result);
      v1219_8 = compose(v1219_5,v1220_7);
    }
    const Space v1219_9 = intersect(constant_5,v1219_2);
    const Space v1219_10 = (has_head(v1219_9) ? constant_7 : Space{});
    Space v1219_12;
    if (!v1219_10.empty()) {
      const Path v1224_6 = concat_path(p0,v1218_13_head);
      Space v1224_11_result;
      for (int v1224_11_label = 1; v1224_11_label <= 2; ++v1224_11_label) {
        const Space v1224_11_tail = child(v1218_13_tail,v1224_11_label);
        if (v1224_11_tail.empty()) continue;
        const Path v1224_11_head{v1224_11_label};
        const Space v1225_2 = singleton(v1224_11_head);
        const Space v1225_3 = intersect(constant_5,v1225_2);
        const Space v1225_4 = (has_head(v1225_3) ? constant_7 : Space{});
        const Space v1225_5 = subtract(constant_0,v1225_4);
        Space v1225_8;
        if (!v1225_5.empty()) {
          const Path v1226_6 = concat_path(v1224_6,v1224_11_head);
          const Space v1226_7 = routine_174(c, v1226_6, p1, v1224_11_tail, s1);
          v1225_8 = compose(v1225_5,v1226_7);
        }
        const Space v1225_9 = intersect(constant_5,v1225_2);
        const Space v1225_10 = (has_head(v1225_9) ? constant_7 : Space{});
        Space v1225_12;
        if (!v1225_10.empty()) {
          const Path v1227_6 = concat_path(v1224_6,v1224_11_head);
          const Space v1227_11 = routine_48(c, v1227_6, p1, v1224_11_tail, s1);
          v1225_12 = compose(v1225_10,v1227_11);
        }
        const Space v1225_13 = unite(v1225_8,v1225_12);
        v1224_11_result = unite(v1224_11_result,v1225_13);
      }
      const Space v1224_11 = std::move(v1224_11_result);
      v1219_12 = compose(v1219_10,v1224_11);
    }
    const Space v1219_13 = unite(v1219_8,v1219_12);
    v1218_13_result = unite(v1218_13_result,v1219_13);
  }
  const Space v1218_13 = std::move(v1218_13_result);
  return v1218_13;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1228_8 = unwrap(constant_9,p1);
  const Space v1228_10 = unwrap(constant_9,p0);
  const Space v1228_12 = unwrap(s1,constant_8);
  const Space v1228_14 = unwrap(constant_9,p1);
  const Space v1228_16 = unwrap(constant_9,p0);
  Space v1228_29_result;
  for (int v1228_29_label = 1; v1228_29_label <= 2; ++v1228_29_label) {
    const Space v1228_29_tail = child(s0,v1228_29_label);
    if (v1228_29_tail.empty()) continue;
    const Path v1228_29_head{v1228_29_label};
    const Space v1229_2 = singleton(v1228_29_head);
    const Space v1229_3 = intersect(constant_5,v1229_2);
    const Space v1229_4 = (has_head(v1229_3) ? constant_7 : Space{});
    const Space v1229_5 = subtract(constant_0,v1229_4);
    Space v1229_8;
    if (!v1229_5.empty()) {
      const Path v1230_6 = concat_path(p0,v1228_29_head);
      Space v1230_7_result;
      for (int v1230_7_label = 1; v1230_7_label <= 2; ++v1230_7_label) {
        const Space v1230_7_tail = child(v1228_29_tail,v1230_7_label);
        if (v1230_7_tail.empty()) continue;
        const Path v1230_7_head{v1230_7_label};
        const Space v1231_2 = singleton(v1230_7_head);
        const Space v1231_3 = intersect(constant_5,v1231_2);
        const Space v1231_4 = (has_head(v1231_3) ? constant_7 : Space{});
        const Space v1231_5 = subtract(constant_0,v1231_4);
        Space v1231_8;
        if (!v1231_5.empty()) {
          const Path v1232_6 = concat_path(v1230_6,v1230_7_head);
          const Space v1232_7 = routine_174(c, v1232_6, p1, v1230_7_tail, s1);
          v1231_8 = compose(v1231_5,v1232_7);
        }
        const Space v1231_9 = intersect(constant_5,v1231_2);
        const Space v1231_10 = (has_head(v1231_9) ? constant_7 : Space{});
        Space v1231_12;
        if (!v1231_10.empty()) {
          const Path v1233_6 = concat_path(v1230_6,v1230_7_head);
          const Space v1233_11 = routine_175(c, v1233_6, p1, v1230_7_tail, s1);
          v1231_12 = compose(v1231_10,v1233_11);
        }
        const Space v1231_13 = unite(v1231_8,v1231_12);
        v1230_7_result = unite(v1230_7_result,v1231_13);
      }
      const Space v1230_7 = std::move(v1230_7_result);
      v1229_8 = compose(v1229_5,v1230_7);
    }
    const Space v1229_9 = intersect(constant_5,v1229_2);
    const Space v1229_10 = (has_head(v1229_9) ? constant_7 : Space{});
    Space v1229_28;
    if (!v1229_10.empty()) {
      const Path v1234_6 = concat_path(p0,v1228_29_head);
      const Space v1234_11 = unwrap(v1228_10,v1228_29_head);
      const Space v1234_12 = compose(v1228_8,v1234_11);
      const Path v1234_13 = concat_path(p1,v1234_6);
      const Space v1234_14 = singleton(v1234_13);
      const Space v1234_15 = subtract(v1234_12,v1234_14);
      const Space v1234_16 = intersect(v1234_15,v1228_12);
      const Space v1234_17 = routine_51(c, v1234_16);
      Space v1234_18_result;
      for (int v1234_18_label = 1; v1234_18_label <= 2; ++v1234_18_label) {
        const Space v1234_18_tail = child(v1234_17,v1234_18_label);
        if (v1234_18_tail.empty()) continue;
        const Path v1234_18_head{v1234_18_label};
        const Space v1235_2 = singleton(v1234_18_head);
        const Space v1235_3 = intersect(constant_5,v1235_2);
        const Space v1235_4 = (has_head(v1235_3) ? constant_7 : Space{});
        const Space v1235_5 = subtract(constant_0,v1235_4);
        Space v1235_7;
        if (!v1235_5.empty()) {
          const Space v1236_6 = routine_52(c, v1234_18_head, v1234_18_tail);
          v1235_7 = compose(v1235_5,v1236_6);
        }
        const Space v1235_8 = intersect(constant_5,v1235_2);
        const Space v1235_9 = (has_head(v1235_8) ? constant_7 : Space{});
        Space v1235_11;
        if (!v1235_9.empty()) {
          const Space v1237_10 = routine_53(c, v1234_18_head, v1234_18_tail);
          v1235_11 = compose(v1235_9,v1237_10);
        }
        const Space v1235_12 = unite(v1235_7,v1235_11);
        v1234_18_result = unite(v1234_18_result,v1235_12);
      }
      const Space v1234_18 = std::move(v1234_18_result);
      const Space v1234_19 = unwrap(v1228_16,v1228_29_head);
      const Space v1234_20 = compose(v1228_14,v1234_19);
      const Space v1234_21 = subtract(v1234_20,v1234_14);
      const Space v1234_22 = intersect(v1234_21,v1228_12);
      const Space v1234_23 = routine_36(c, v1234_22);
      Space v1234_24_result;
      for (int v1234_24_label = 1; v1234_24_label <= 2; ++v1234_24_label) {
        const Space v1234_24_tail = child(v1234_23,v1234_24_label);
        if (v1234_24_tail.empty()) continue;
        const Path v1234_24_head{v1234_24_label};
        const Space v1238_2 = singleton(v1234_24_head);
        const Space v1238_3 = intersect(constant_5,v1238_2);
        const Space v1238_4 = (has_head(v1238_3) ? constant_7 : Space{});
        const Space v1238_5 = subtract(constant_0,v1238_4);
        Space v1238_7;
        if (!v1238_5.empty()) {
          const Space v1239_6 = routine_54(c, v1234_24_head, v1234_24_tail);
          v1238_7 = compose(v1238_5,v1239_6);
        }
        const Space v1238_8 = intersect(constant_5,v1238_2);
        const Space v1238_9 = (has_head(v1238_8) ? constant_7 : Space{});
        Space v1238_11;
        if (!v1238_9.empty()) {
          const Space v1240_10 = routine_55(c, v1234_24_head, v1234_24_tail);
          v1238_11 = compose(v1238_9,v1240_10);
        }
        const Space v1238_12 = unite(v1238_7,v1238_11);
        v1234_24_result = unite(v1234_24_result,v1238_12);
      }
      const Space v1234_24 = std::move(v1234_24_result);
      const Space v1234_25 = subtract(v1234_18,v1234_24);
      const Space v1234_26 = compose(v1234_25,v1234_14);
      Space v1234_27_result;
      for (int v1234_27_label = 1; v1234_27_label <= 2; ++v1234_27_label) {
        const Space v1234_27_tail = child(v1234_26,v1234_27_label);
        if (v1234_27_tail.empty()) continue;
        const Path v1234_27_head{v1234_27_label};
        const Space v1241_2 = singleton(v1234_27_head);
        const Space v1241_3 = intersect(constant_5,v1241_2);
        const Space v1241_4 = (has_head(v1241_3) ? constant_7 : Space{});
        const Space v1241_5 = subtract(constant_0,v1241_4);
        Space v1241_7;
        if (!v1241_5.empty()) {
          const Space v1242_6 = routine_56(c, v1234_27_head, v1234_27_tail);
          v1241_7 = compose(v1241_5,v1242_6);
        }
        const Space v1241_8 = intersect(constant_5,v1241_2);
        const Space v1241_9 = (has_head(v1241_8) ? constant_7 : Space{});
        Space v1241_11;
        if (!v1241_9.empty()) {
          const Space v1243_10 = routine_57(c, v1234_27_head, v1234_27_tail);
          v1241_11 = compose(v1241_9,v1243_10);
        }
        const Space v1241_12 = unite(v1241_7,v1241_11);
        v1234_27_result = unite(v1234_27_result,v1241_12);
      }
      const Space v1234_27 = std::move(v1234_27_result);
      v1229_28 = compose(v1229_10,v1234_27);
    }
    const Space v1229_29 = unite(v1229_8,v1229_28);
    v1228_29_result = unite(v1228_29_result,v1229_29);
  }
  const Space v1228_29 = std::move(v1228_29_result);
  return v1228_29;
}

static Space routine_140(Context& c, const Path& p0, const Space& s0) {
  Space v1244_11_result;
  for (int v1244_11_label = 1; v1244_11_label <= 2; ++v1244_11_label) {
    const Space v1244_11_tail = child(s0,v1244_11_label);
    if (v1244_11_tail.empty()) continue;
    const Path v1244_11_head{v1244_11_label};
    const Space v1245_2 = singleton(v1244_11_head);
    const Space v1245_3 = intersect(constant_5,v1245_2);
    const Space v1245_4 = (has_head(v1245_3) ? constant_7 : Space{});
    const Space v1245_5 = subtract(constant_0,v1245_4);
    Space v1245_8;
    if (!v1245_5.empty()) {
      const Path v1246_6 = concat_path(p0,v1244_11_head);
      Space v1246_7_result;
      for (int v1246_7_label = 1; v1246_7_label <= 2; ++v1246_7_label) {
        const Space v1246_7_tail = child(v1244_11_tail,v1246_7_label);
        if (v1246_7_tail.empty()) continue;
        const Path v1246_7_head{v1246_7_label};
        const Space v1247_2 = singleton(v1246_7_head);
        const Space v1247_3 = intersect(constant_5,v1247_2);
        const Space v1247_4 = (has_head(v1247_3) ? constant_7 : Space{});
        const Space v1247_5 = subtract(constant_0,v1247_4);
        Space v1247_8;
        if (!v1247_5.empty()) {
          const Path v1248_6 = concat_path(v1246_6,v1246_7_head);
          const Space v1248_7 = routine_176(c, v1248_6, v1246_7_tail);
          v1247_8 = compose(v1247_5,v1248_7);
        }
        const Space v1247_9 = intersect(constant_5,v1247_2);
        const Space v1247_10 = (has_head(v1247_9) ? constant_7 : Space{});
        Space v1247_12;
        if (!v1247_10.empty()) {
          const Path v1249_6 = concat_path(v1246_6,v1246_7_head);
          const Space v1249_11 = routine_177(c, v1249_6, v1246_7_tail);
          v1247_12 = compose(v1247_10,v1249_11);
        }
        const Space v1247_13 = unite(v1247_8,v1247_12);
        v1246_7_result = unite(v1246_7_result,v1247_13);
      }
      const Space v1246_7 = std::move(v1246_7_result);
      v1245_8 = compose(v1245_5,v1246_7);
    }
    const Space v1245_9 = intersect(constant_5,v1245_2);
    const Space v1245_10 = (has_head(v1245_9) ? constant_7 : Space{});
    Space v1245_12;
    if (!v1245_10.empty()) {
      const Path v1250_6 = concat_path(p0,v1244_11_head);
      Space v1250_11_result;
      for (int v1250_11_label = 1; v1250_11_label <= 2; ++v1250_11_label) {
        const Space v1250_11_tail = child(v1244_11_tail,v1250_11_label);
        if (v1250_11_tail.empty()) continue;
        const Path v1250_11_head{v1250_11_label};
        const Space v1251_2 = singleton(v1250_11_head);
        const Space v1251_3 = intersect(constant_5,v1251_2);
        const Space v1251_4 = (has_head(v1251_3) ? constant_7 : Space{});
        const Space v1251_5 = subtract(constant_0,v1251_4);
        Space v1251_8;
        if (!v1251_5.empty()) {
          const Path v1252_6 = concat_path(v1250_6,v1250_11_head);
          const Space v1252_7 = routine_176(c, v1252_6, v1250_11_tail);
          v1251_8 = compose(v1251_5,v1252_7);
        }
        const Space v1251_9 = intersect(constant_5,v1251_2);
        const Space v1251_10 = (has_head(v1251_9) ? constant_7 : Space{});
        Space v1251_12;
        if (!v1251_10.empty()) {
          const Path v1253_6 = concat_path(v1250_6,v1250_11_head);
          const Space v1253_11 = routine_95(c, v1253_6, v1250_11_tail);
          v1251_12 = compose(v1251_10,v1253_11);
        }
        const Space v1251_13 = unite(v1251_8,v1251_12);
        v1250_11_result = unite(v1250_11_result,v1251_13);
      }
      const Space v1250_11 = std::move(v1250_11_result);
      v1245_12 = compose(v1245_10,v1250_11);
    }
    const Space v1245_13 = unite(v1245_8,v1245_12);
    v1244_11_result = unite(v1244_11_result,v1245_13);
  }
  const Space v1244_11 = std::move(v1244_11_result);
  return v1244_11;
}

static Space routine_141(Context& c, const Path& p0, const Space& s0) {
  Space v1254_9_result;
  for (int v1254_9_label = 1; v1254_9_label <= 2; ++v1254_9_label) {
    const Space v1254_9_tail = child(s0,v1254_9_label);
    if (v1254_9_tail.empty()) continue;
    const Path v1254_9_head{v1254_9_label};
    const Space v1255_2 = singleton(v1254_9_head);
    const Space v1255_3 = intersect(constant_5,v1255_2);
    const Space v1255_4 = (has_head(v1255_3) ? constant_7 : Space{});
    const Space v1255_5 = subtract(constant_0,v1255_4);
    Space v1255_8;
    if (!v1255_5.empty()) {
      const Path v1256_6 = concat_path(p0,v1254_9_head);
      Space v1256_7_result;
      for (int v1256_7_label = 1; v1256_7_label <= 2; ++v1256_7_label) {
        const Space v1256_7_tail = child(v1254_9_tail,v1256_7_label);
        if (v1256_7_tail.empty()) continue;
        const Path v1256_7_head{v1256_7_label};
        const Space v1257_2 = singleton(v1256_7_head);
        const Space v1257_3 = intersect(constant_5,v1257_2);
        const Space v1257_4 = (has_head(v1257_3) ? constant_7 : Space{});
        const Space v1257_5 = subtract(constant_0,v1257_4);
        Space v1257_8;
        if (!v1257_5.empty()) {
          const Path v1258_6 = concat_path(v1256_6,v1256_7_head);
          const Space v1258_7 = routine_176(c, v1258_6, v1256_7_tail);
          v1257_8 = compose(v1257_5,v1258_7);
        }
        const Space v1257_9 = intersect(constant_5,v1257_2);
        const Space v1257_10 = (has_head(v1257_9) ? constant_7 : Space{});
        Space v1257_12;
        if (!v1257_10.empty()) {
          const Path v1259_6 = concat_path(v1256_6,v1256_7_head);
          const Space v1259_11 = routine_177(c, v1259_6, v1256_7_tail);
          v1257_12 = compose(v1257_10,v1259_11);
        }
        const Space v1257_13 = unite(v1257_8,v1257_12);
        v1256_7_result = unite(v1256_7_result,v1257_13);
      }
      const Space v1256_7 = std::move(v1256_7_result);
      v1255_8 = compose(v1255_5,v1256_7);
    }
    const Space v1255_9 = intersect(constant_5,v1255_2);
    const Space v1255_10 = (has_head(v1255_9) ? constant_7 : Space{});
    const Space v1255_11 = compose(v1255_10,constant_10);
    const Space v1255_12 = unite(v1255_8,v1255_11);
    v1254_9_result = unite(v1254_9_result,v1255_12);
  }
  const Space v1254_9 = std::move(v1254_9_result);
  return v1254_9;
}

static Space routine_142(Context& c, const Path& p0, const Space& s0) {
  Space v1260_11_result;
  for (int v1260_11_label = 1; v1260_11_label <= 2; ++v1260_11_label) {
    const Space v1260_11_tail = child(s0,v1260_11_label);
    if (v1260_11_tail.empty()) continue;
    const Path v1260_11_head{v1260_11_label};
    const Space v1261_2 = singleton(v1260_11_head);
    const Space v1261_3 = intersect(constant_5,v1261_2);
    const Space v1261_4 = (has_head(v1261_3) ? constant_7 : Space{});
    const Space v1261_5 = subtract(constant_0,v1261_4);
    Space v1261_8;
    if (!v1261_5.empty()) {
      const Path v1262_6 = concat_path(p0,v1260_11_head);
      Space v1262_7_result;
      for (int v1262_7_label = 1; v1262_7_label <= 2; ++v1262_7_label) {
        const Space v1262_7_tail = child(v1260_11_tail,v1262_7_label);
        if (v1262_7_tail.empty()) continue;
        const Path v1262_7_head{v1262_7_label};
        const Space v1263_2 = singleton(v1262_7_head);
        const Space v1263_3 = intersect(constant_5,v1263_2);
        const Space v1263_4 = (has_head(v1263_3) ? constant_7 : Space{});
        const Space v1263_5 = subtract(constant_0,v1263_4);
        Space v1263_8;
        if (!v1263_5.empty()) {
          const Path v1264_6 = concat_path(v1262_6,v1262_7_head);
          const Space v1264_7 = routine_178(c, v1264_6, v1262_7_tail);
          v1263_8 = compose(v1263_5,v1264_7);
        }
        const Space v1263_9 = intersect(constant_5,v1263_2);
        const Space v1263_10 = (has_head(v1263_9) ? constant_7 : Space{});
        Space v1263_12;
        if (!v1263_10.empty()) {
          const Path v1265_6 = concat_path(v1262_6,v1262_7_head);
          const Space v1265_11 = routine_179(c, v1265_6, v1262_7_tail);
          v1263_12 = compose(v1263_10,v1265_11);
        }
        const Space v1263_13 = unite(v1263_8,v1263_12);
        v1262_7_result = unite(v1262_7_result,v1263_13);
      }
      const Space v1262_7 = std::move(v1262_7_result);
      v1261_8 = compose(v1261_5,v1262_7);
    }
    const Space v1261_9 = intersect(constant_5,v1261_2);
    const Space v1261_10 = (has_head(v1261_9) ? constant_7 : Space{});
    Space v1261_12;
    if (!v1261_10.empty()) {
      const Path v1266_6 = concat_path(p0,v1260_11_head);
      Space v1266_11_result;
      for (int v1266_11_label = 1; v1266_11_label <= 2; ++v1266_11_label) {
        const Space v1266_11_tail = child(v1260_11_tail,v1266_11_label);
        if (v1266_11_tail.empty()) continue;
        const Path v1266_11_head{v1266_11_label};
        const Space v1267_2 = singleton(v1266_11_head);
        const Space v1267_3 = intersect(constant_5,v1267_2);
        const Space v1267_4 = (has_head(v1267_3) ? constant_7 : Space{});
        const Space v1267_5 = subtract(constant_0,v1267_4);
        Space v1267_8;
        if (!v1267_5.empty()) {
          const Path v1268_6 = concat_path(v1266_6,v1266_11_head);
          const Space v1268_7 = routine_178(c, v1268_6, v1266_11_tail);
          v1267_8 = compose(v1267_5,v1268_7);
        }
        const Space v1267_9 = intersect(constant_5,v1267_2);
        const Space v1267_10 = (has_head(v1267_9) ? constant_7 : Space{});
        Space v1267_12;
        if (!v1267_10.empty()) {
          const Path v1269_6 = concat_path(v1266_6,v1266_11_head);
          const Space v1269_11 = routine_98(c, v1269_6, v1266_11_tail);
          v1267_12 = compose(v1267_10,v1269_11);
        }
        const Space v1267_13 = unite(v1267_8,v1267_12);
        v1266_11_result = unite(v1266_11_result,v1267_13);
      }
      const Space v1266_11 = std::move(v1266_11_result);
      v1261_12 = compose(v1261_10,v1266_11);
    }
    const Space v1261_13 = unite(v1261_8,v1261_12);
    v1260_11_result = unite(v1260_11_result,v1261_13);
  }
  const Space v1260_11 = std::move(v1260_11_result);
  return v1260_11;
}

static Space routine_143(Context& c, const Path& p0, const Space& s0) {
  Space v1270_9_result;
  for (int v1270_9_label = 1; v1270_9_label <= 2; ++v1270_9_label) {
    const Space v1270_9_tail = child(s0,v1270_9_label);
    if (v1270_9_tail.empty()) continue;
    const Path v1270_9_head{v1270_9_label};
    const Space v1271_2 = singleton(v1270_9_head);
    const Space v1271_3 = intersect(constant_5,v1271_2);
    const Space v1271_4 = (has_head(v1271_3) ? constant_7 : Space{});
    const Space v1271_5 = subtract(constant_0,v1271_4);
    Space v1271_8;
    if (!v1271_5.empty()) {
      const Path v1272_6 = concat_path(p0,v1270_9_head);
      Space v1272_7_result;
      for (int v1272_7_label = 1; v1272_7_label <= 2; ++v1272_7_label) {
        const Space v1272_7_tail = child(v1270_9_tail,v1272_7_label);
        if (v1272_7_tail.empty()) continue;
        const Path v1272_7_head{v1272_7_label};
        const Space v1273_2 = singleton(v1272_7_head);
        const Space v1273_3 = intersect(constant_5,v1273_2);
        const Space v1273_4 = (has_head(v1273_3) ? constant_7 : Space{});
        const Space v1273_5 = subtract(constant_0,v1273_4);
        Space v1273_8;
        if (!v1273_5.empty()) {
          const Path v1274_6 = concat_path(v1272_6,v1272_7_head);
          const Space v1274_7 = routine_178(c, v1274_6, v1272_7_tail);
          v1273_8 = compose(v1273_5,v1274_7);
        }
        const Space v1273_9 = intersect(constant_5,v1273_2);
        const Space v1273_10 = (has_head(v1273_9) ? constant_7 : Space{});
        Space v1273_12;
        if (!v1273_10.empty()) {
          const Path v1275_6 = concat_path(v1272_6,v1272_7_head);
          const Space v1275_11 = routine_179(c, v1275_6, v1272_7_tail);
          v1273_12 = compose(v1273_10,v1275_11);
        }
        const Space v1273_13 = unite(v1273_8,v1273_12);
        v1272_7_result = unite(v1272_7_result,v1273_13);
      }
      const Space v1272_7 = std::move(v1272_7_result);
      v1271_8 = compose(v1271_5,v1272_7);
    }
    const Space v1271_9 = intersect(constant_5,v1271_2);
    const Space v1271_10 = (has_head(v1271_9) ? constant_7 : Space{});
    const Space v1271_11 = compose(v1271_10,constant_10);
    const Space v1271_12 = unite(v1271_8,v1271_11);
    v1270_9_result = unite(v1270_9_result,v1271_12);
  }
  const Space v1270_9 = std::move(v1270_9_result);
  return v1270_9;
}

static Space routine_144(Context& c, const Path& p0, const Space& s0) {
  Space v1276_11_result;
  for (int v1276_11_label = 1; v1276_11_label <= 2; ++v1276_11_label) {
    const Space v1276_11_tail = child(s0,v1276_11_label);
    if (v1276_11_tail.empty()) continue;
    const Path v1276_11_head{v1276_11_label};
    const Space v1277_2 = singleton(v1276_11_head);
    const Space v1277_3 = intersect(constant_5,v1277_2);
    const Space v1277_4 = (has_head(v1277_3) ? constant_7 : Space{});
    const Space v1277_5 = subtract(constant_0,v1277_4);
    Space v1277_8;
    if (!v1277_5.empty()) {
      const Path v1278_6 = concat_path(p0,v1276_11_head);
      Space v1278_7_result;
      for (int v1278_7_label = 1; v1278_7_label <= 2; ++v1278_7_label) {
        const Space v1278_7_tail = child(v1276_11_tail,v1278_7_label);
        if (v1278_7_tail.empty()) continue;
        const Path v1278_7_head{v1278_7_label};
        const Space v1279_2 = singleton(v1278_7_head);
        const Space v1279_3 = intersect(constant_5,v1279_2);
        const Space v1279_4 = (has_head(v1279_3) ? constant_7 : Space{});
        const Space v1279_5 = subtract(constant_0,v1279_4);
        Space v1279_8;
        if (!v1279_5.empty()) {
          const Path v1280_6 = concat_path(v1278_6,v1278_7_head);
          const Space v1280_7 = routine_180(c, v1280_6, v1278_7_tail);
          v1279_8 = compose(v1279_5,v1280_7);
        }
        const Space v1279_9 = intersect(constant_5,v1279_2);
        const Space v1279_10 = (has_head(v1279_9) ? constant_7 : Space{});
        Space v1279_12;
        if (!v1279_10.empty()) {
          const Path v1281_6 = concat_path(v1278_6,v1278_7_head);
          const Space v1281_11 = routine_181(c, v1281_6, v1278_7_tail);
          v1279_12 = compose(v1279_10,v1281_11);
        }
        const Space v1279_13 = unite(v1279_8,v1279_12);
        v1278_7_result = unite(v1278_7_result,v1279_13);
      }
      const Space v1278_7 = std::move(v1278_7_result);
      v1277_8 = compose(v1277_5,v1278_7);
    }
    const Space v1277_9 = intersect(constant_5,v1277_2);
    const Space v1277_10 = (has_head(v1277_9) ? constant_7 : Space{});
    Space v1277_12;
    if (!v1277_10.empty()) {
      const Path v1282_6 = concat_path(p0,v1276_11_head);
      Space v1282_11_result;
      for (int v1282_11_label = 1; v1282_11_label <= 2; ++v1282_11_label) {
        const Space v1282_11_tail = child(v1276_11_tail,v1282_11_label);
        if (v1282_11_tail.empty()) continue;
        const Path v1282_11_head{v1282_11_label};
        const Space v1283_2 = singleton(v1282_11_head);
        const Space v1283_3 = intersect(constant_5,v1283_2);
        const Space v1283_4 = (has_head(v1283_3) ? constant_7 : Space{});
        const Space v1283_5 = subtract(constant_0,v1283_4);
        Space v1283_8;
        if (!v1283_5.empty()) {
          const Path v1284_6 = concat_path(v1282_6,v1282_11_head);
          const Space v1284_7 = routine_180(c, v1284_6, v1282_11_tail);
          v1283_8 = compose(v1283_5,v1284_7);
        }
        const Space v1283_9 = intersect(constant_5,v1283_2);
        const Space v1283_10 = (has_head(v1283_9) ? constant_7 : Space{});
        Space v1283_12;
        if (!v1283_10.empty()) {
          const Path v1285_6 = concat_path(v1282_6,v1282_11_head);
          const Space v1285_11 = routine_101(c, v1285_6, v1282_11_tail);
          v1283_12 = compose(v1283_10,v1285_11);
        }
        const Space v1283_13 = unite(v1283_8,v1283_12);
        v1282_11_result = unite(v1282_11_result,v1283_13);
      }
      const Space v1282_11 = std::move(v1282_11_result);
      v1277_12 = compose(v1277_10,v1282_11);
    }
    const Space v1277_13 = unite(v1277_8,v1277_12);
    v1276_11_result = unite(v1276_11_result,v1277_13);
  }
  const Space v1276_11 = std::move(v1276_11_result);
  return v1276_11;
}

static Space routine_145(Context& c, const Path& p0, const Space& s0) {
  Space v1286_8_result;
  for (int v1286_8_label = 1; v1286_8_label <= 2; ++v1286_8_label) {
    const Space v1286_8_tail = child(s0,v1286_8_label);
    if (v1286_8_tail.empty()) continue;
    const Path v1286_8_head{v1286_8_label};
    const Space v1287_2 = singleton(v1286_8_head);
    const Space v1287_3 = intersect(constant_5,v1287_2);
    const Space v1287_4 = (has_head(v1287_3) ? constant_7 : Space{});
    const Space v1287_5 = subtract(constant_0,v1287_4);
    Space v1287_8;
    if (!v1287_5.empty()) {
      const Path v1288_6 = concat_path(p0,v1286_8_head);
      Space v1288_7_result;
      for (int v1288_7_label = 1; v1288_7_label <= 2; ++v1288_7_label) {
        const Space v1288_7_tail = child(v1286_8_tail,v1288_7_label);
        if (v1288_7_tail.empty()) continue;
        const Path v1288_7_head{v1288_7_label};
        const Space v1289_2 = singleton(v1288_7_head);
        const Space v1289_3 = intersect(constant_5,v1289_2);
        const Space v1289_4 = (has_head(v1289_3) ? constant_7 : Space{});
        const Space v1289_5 = subtract(constant_0,v1289_4);
        Space v1289_8;
        if (!v1289_5.empty()) {
          const Path v1290_6 = concat_path(v1288_6,v1288_7_head);
          const Space v1290_7 = routine_180(c, v1290_6, v1288_7_tail);
          v1289_8 = compose(v1289_5,v1290_7);
        }
        const Space v1289_9 = intersect(constant_5,v1289_2);
        const Space v1289_10 = (has_head(v1289_9) ? constant_7 : Space{});
        Space v1289_12;
        if (!v1289_10.empty()) {
          const Path v1291_6 = concat_path(v1288_6,v1288_7_head);
          const Space v1291_11 = routine_181(c, v1291_6, v1288_7_tail);
          v1289_12 = compose(v1289_10,v1291_11);
        }
        const Space v1289_13 = unite(v1289_8,v1289_12);
        v1288_7_result = unite(v1288_7_result,v1289_13);
      }
      const Space v1288_7 = std::move(v1288_7_result);
      v1287_8 = compose(v1287_5,v1288_7);
    }
    const Space v1287_9 = intersect(constant_5,v1287_2);
    const Space v1287_10 = (has_head(v1287_9) ? constant_7 : Space{});
    const Space v1287_11 = compose(v1287_10,v1286_8_tail);
    const Space v1287_12 = unite(v1287_8,v1287_11);
    v1286_8_result = unite(v1286_8_result,v1287_12);
  }
  const Space v1286_8 = std::move(v1286_8_result);
  return v1286_8;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1292_13_result;
  for (int v1292_13_label = 1; v1292_13_label <= 2; ++v1292_13_label) {
    const Space v1292_13_tail = child(s0,v1292_13_label);
    if (v1292_13_tail.empty()) continue;
    const Path v1292_13_head{v1292_13_label};
    const Space v1293_2 = singleton(v1292_13_head);
    const Space v1293_3 = intersect(constant_5,v1293_2);
    const Space v1293_4 = (has_head(v1293_3) ? constant_7 : Space{});
    const Space v1293_5 = subtract(constant_0,v1293_4);
    Space v1293_8;
    if (!v1293_5.empty()) {
      const Path v1294_6 = concat_path(p0,v1292_13_head);
      Space v1294_7_result;
      for (int v1294_7_label = 1; v1294_7_label <= 2; ++v1294_7_label) {
        const Space v1294_7_tail = child(v1292_13_tail,v1294_7_label);
        if (v1294_7_tail.empty()) continue;
        const Path v1294_7_head{v1294_7_label};
        const Space v1295_2 = singleton(v1294_7_head);
        const Space v1295_3 = intersect(constant_5,v1295_2);
        const Space v1295_4 = (has_head(v1295_3) ? constant_7 : Space{});
        const Space v1295_5 = subtract(constant_0,v1295_4);
        Space v1295_8;
        if (!v1295_5.empty()) {
          const Path v1296_6 = concat_path(v1294_6,v1294_7_head);
          const Space v1296_7 = routine_182(c, v1296_6, p1, v1294_7_tail, s1);
          v1295_8 = compose(v1295_5,v1296_7);
        }
        const Space v1295_9 = intersect(constant_5,v1295_2);
        const Space v1295_10 = (has_head(v1295_9) ? constant_7 : Space{});
        Space v1295_12;
        if (!v1295_10.empty()) {
          const Path v1297_6 = concat_path(v1294_6,v1294_7_head);
          const Space v1297_11 = routine_183(c, v1297_6, p1, v1294_7_tail, s1);
          v1295_12 = compose(v1295_10,v1297_11);
        }
        const Space v1295_13 = unite(v1295_8,v1295_12);
        v1294_7_result = unite(v1294_7_result,v1295_13);
      }
      const Space v1294_7 = std::move(v1294_7_result);
      v1293_8 = compose(v1293_5,v1294_7);
    }
    const Space v1293_9 = intersect(constant_5,v1293_2);
    const Space v1293_10 = (has_head(v1293_9) ? constant_7 : Space{});
    Space v1293_12;
    if (!v1293_10.empty()) {
      const Path v1298_6 = concat_path(p0,v1292_13_head);
      Space v1298_11_result;
      for (int v1298_11_label = 1; v1298_11_label <= 2; ++v1298_11_label) {
        const Space v1298_11_tail = child(v1292_13_tail,v1298_11_label);
        if (v1298_11_tail.empty()) continue;
        const Path v1298_11_head{v1298_11_label};
        const Space v1299_2 = singleton(v1298_11_head);
        const Space v1299_3 = intersect(constant_5,v1299_2);
        const Space v1299_4 = (has_head(v1299_3) ? constant_7 : Space{});
        const Space v1299_5 = subtract(constant_0,v1299_4);
        Space v1299_8;
        if (!v1299_5.empty()) {
          const Path v1300_6 = concat_path(v1298_6,v1298_11_head);
          const Space v1300_7 = routine_182(c, v1300_6, p1, v1298_11_tail, s1);
          v1299_8 = compose(v1299_5,v1300_7);
        }
        const Space v1299_9 = intersect(constant_5,v1299_2);
        const Space v1299_10 = (has_head(v1299_9) ? constant_7 : Space{});
        Space v1299_12;
        if (!v1299_10.empty()) {
          const Path v1301_6 = concat_path(v1298_6,v1298_11_head);
          const Space v1301_11 = routine_48(c, v1301_6, p1, v1298_11_tail, s1);
          v1299_12 = compose(v1299_10,v1301_11);
        }
        const Space v1299_13 = unite(v1299_8,v1299_12);
        v1298_11_result = unite(v1298_11_result,v1299_13);
      }
      const Space v1298_11 = std::move(v1298_11_result);
      v1293_12 = compose(v1293_10,v1298_11);
    }
    const Space v1293_13 = unite(v1293_8,v1293_12);
    v1292_13_result = unite(v1292_13_result,v1293_13);
  }
  const Space v1292_13 = std::move(v1292_13_result);
  return v1292_13;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1302_8 = unwrap(constant_9,p1);
  const Space v1302_10 = unwrap(constant_9,p0);
  const Space v1302_12 = unwrap(s1,constant_8);
  const Space v1302_14 = unwrap(constant_9,p1);
  const Space v1302_16 = unwrap(constant_9,p0);
  Space v1302_29_result;
  for (int v1302_29_label = 1; v1302_29_label <= 2; ++v1302_29_label) {
    const Space v1302_29_tail = child(s0,v1302_29_label);
    if (v1302_29_tail.empty()) continue;
    const Path v1302_29_head{v1302_29_label};
    const Space v1303_2 = singleton(v1302_29_head);
    const Space v1303_3 = intersect(constant_5,v1303_2);
    const Space v1303_4 = (has_head(v1303_3) ? constant_7 : Space{});
    const Space v1303_5 = subtract(constant_0,v1303_4);
    Space v1303_8;
    if (!v1303_5.empty()) {
      const Path v1304_6 = concat_path(p0,v1302_29_head);
      Space v1304_7_result;
      for (int v1304_7_label = 1; v1304_7_label <= 2; ++v1304_7_label) {
        const Space v1304_7_tail = child(v1302_29_tail,v1304_7_label);
        if (v1304_7_tail.empty()) continue;
        const Path v1304_7_head{v1304_7_label};
        const Space v1305_2 = singleton(v1304_7_head);
        const Space v1305_3 = intersect(constant_5,v1305_2);
        const Space v1305_4 = (has_head(v1305_3) ? constant_7 : Space{});
        const Space v1305_5 = subtract(constant_0,v1305_4);
        Space v1305_8;
        if (!v1305_5.empty()) {
          const Path v1306_6 = concat_path(v1304_6,v1304_7_head);
          const Space v1306_7 = routine_182(c, v1306_6, p1, v1304_7_tail, s1);
          v1305_8 = compose(v1305_5,v1306_7);
        }
        const Space v1305_9 = intersect(constant_5,v1305_2);
        const Space v1305_10 = (has_head(v1305_9) ? constant_7 : Space{});
        Space v1305_12;
        if (!v1305_10.empty()) {
          const Path v1307_6 = concat_path(v1304_6,v1304_7_head);
          const Space v1307_11 = routine_183(c, v1307_6, p1, v1304_7_tail, s1);
          v1305_12 = compose(v1305_10,v1307_11);
        }
        const Space v1305_13 = unite(v1305_8,v1305_12);
        v1304_7_result = unite(v1304_7_result,v1305_13);
      }
      const Space v1304_7 = std::move(v1304_7_result);
      v1303_8 = compose(v1303_5,v1304_7);
    }
    const Space v1303_9 = intersect(constant_5,v1303_2);
    const Space v1303_10 = (has_head(v1303_9) ? constant_7 : Space{});
    Space v1303_28;
    if (!v1303_10.empty()) {
      const Path v1308_6 = concat_path(p0,v1302_29_head);
      const Space v1308_11 = unwrap(v1302_10,v1302_29_head);
      const Space v1308_12 = compose(v1302_8,v1308_11);
      const Path v1308_13 = concat_path(p1,v1308_6);
      const Space v1308_14 = singleton(v1308_13);
      const Space v1308_15 = subtract(v1308_12,v1308_14);
      const Space v1308_16 = intersect(v1308_15,v1302_12);
      const Space v1308_17 = routine_51(c, v1308_16);
      Space v1308_18_result;
      for (int v1308_18_label = 1; v1308_18_label <= 2; ++v1308_18_label) {
        const Space v1308_18_tail = child(v1308_17,v1308_18_label);
        if (v1308_18_tail.empty()) continue;
        const Path v1308_18_head{v1308_18_label};
        const Space v1309_2 = singleton(v1308_18_head);
        const Space v1309_3 = intersect(constant_5,v1309_2);
        const Space v1309_4 = (has_head(v1309_3) ? constant_7 : Space{});
        const Space v1309_5 = subtract(constant_0,v1309_4);
        Space v1309_7;
        if (!v1309_5.empty()) {
          const Space v1310_6 = routine_52(c, v1308_18_head, v1308_18_tail);
          v1309_7 = compose(v1309_5,v1310_6);
        }
        const Space v1309_8 = intersect(constant_5,v1309_2);
        const Space v1309_9 = (has_head(v1309_8) ? constant_7 : Space{});
        Space v1309_11;
        if (!v1309_9.empty()) {
          const Space v1311_10 = routine_53(c, v1308_18_head, v1308_18_tail);
          v1309_11 = compose(v1309_9,v1311_10);
        }
        const Space v1309_12 = unite(v1309_7,v1309_11);
        v1308_18_result = unite(v1308_18_result,v1309_12);
      }
      const Space v1308_18 = std::move(v1308_18_result);
      const Space v1308_19 = unwrap(v1302_16,v1302_29_head);
      const Space v1308_20 = compose(v1302_14,v1308_19);
      const Space v1308_21 = subtract(v1308_20,v1308_14);
      const Space v1308_22 = intersect(v1308_21,v1302_12);
      const Space v1308_23 = routine_36(c, v1308_22);
      Space v1308_24_result;
      for (int v1308_24_label = 1; v1308_24_label <= 2; ++v1308_24_label) {
        const Space v1308_24_tail = child(v1308_23,v1308_24_label);
        if (v1308_24_tail.empty()) continue;
        const Path v1308_24_head{v1308_24_label};
        const Space v1312_2 = singleton(v1308_24_head);
        const Space v1312_3 = intersect(constant_5,v1312_2);
        const Space v1312_4 = (has_head(v1312_3) ? constant_7 : Space{});
        const Space v1312_5 = subtract(constant_0,v1312_4);
        Space v1312_7;
        if (!v1312_5.empty()) {
          const Space v1313_6 = routine_54(c, v1308_24_head, v1308_24_tail);
          v1312_7 = compose(v1312_5,v1313_6);
        }
        const Space v1312_8 = intersect(constant_5,v1312_2);
        const Space v1312_9 = (has_head(v1312_8) ? constant_7 : Space{});
        Space v1312_11;
        if (!v1312_9.empty()) {
          const Space v1314_10 = routine_55(c, v1308_24_head, v1308_24_tail);
          v1312_11 = compose(v1312_9,v1314_10);
        }
        const Space v1312_12 = unite(v1312_7,v1312_11);
        v1308_24_result = unite(v1308_24_result,v1312_12);
      }
      const Space v1308_24 = std::move(v1308_24_result);
      const Space v1308_25 = subtract(v1308_18,v1308_24);
      const Space v1308_26 = compose(v1308_25,v1308_14);
      Space v1308_27_result;
      for (int v1308_27_label = 1; v1308_27_label <= 2; ++v1308_27_label) {
        const Space v1308_27_tail = child(v1308_26,v1308_27_label);
        if (v1308_27_tail.empty()) continue;
        const Path v1308_27_head{v1308_27_label};
        const Space v1315_2 = singleton(v1308_27_head);
        const Space v1315_3 = intersect(constant_5,v1315_2);
        const Space v1315_4 = (has_head(v1315_3) ? constant_7 : Space{});
        const Space v1315_5 = subtract(constant_0,v1315_4);
        Space v1315_7;
        if (!v1315_5.empty()) {
          const Space v1316_6 = routine_56(c, v1308_27_head, v1308_27_tail);
          v1315_7 = compose(v1315_5,v1316_6);
        }
        const Space v1315_8 = intersect(constant_5,v1315_2);
        const Space v1315_9 = (has_head(v1315_8) ? constant_7 : Space{});
        Space v1315_11;
        if (!v1315_9.empty()) {
          const Space v1317_10 = routine_57(c, v1308_27_head, v1308_27_tail);
          v1315_11 = compose(v1315_9,v1317_10);
        }
        const Space v1315_12 = unite(v1315_7,v1315_11);
        v1308_27_result = unite(v1308_27_result,v1315_12);
      }
      const Space v1308_27 = std::move(v1308_27_result);
      v1303_28 = compose(v1303_10,v1308_27);
    }
    const Space v1303_29 = unite(v1303_8,v1303_28);
    v1302_29_result = unite(v1302_29_result,v1303_29);
  }
  const Space v1302_29 = std::move(v1302_29_result);
  return v1302_29;
}

static Space routine_148(Context& c, const Path& p0, const Space& s0) {
  Space v1318_11_result;
  for (int v1318_11_label = 1; v1318_11_label <= 2; ++v1318_11_label) {
    const Space v1318_11_tail = child(s0,v1318_11_label);
    if (v1318_11_tail.empty()) continue;
    const Path v1318_11_head{v1318_11_label};
    const Space v1319_2 = singleton(v1318_11_head);
    const Space v1319_3 = intersect(constant_5,v1319_2);
    const Space v1319_4 = (has_head(v1319_3) ? constant_7 : Space{});
    const Space v1319_5 = subtract(constant_0,v1319_4);
    Space v1319_8;
    if (!v1319_5.empty()) {
      const Path v1320_6 = concat_path(p0,v1318_11_head);
      Space v1320_7_result;
      for (int v1320_7_label = 1; v1320_7_label <= 2; ++v1320_7_label) {
        const Space v1320_7_tail = child(v1318_11_tail,v1320_7_label);
        if (v1320_7_tail.empty()) continue;
        const Path v1320_7_head{v1320_7_label};
        const Space v1321_2 = singleton(v1320_7_head);
        const Space v1321_3 = intersect(constant_5,v1321_2);
        const Space v1321_4 = (has_head(v1321_3) ? constant_7 : Space{});
        const Space v1321_5 = subtract(constant_0,v1321_4);
        Space v1321_8;
        if (!v1321_5.empty()) {
          const Path v1322_6 = concat_path(v1320_6,v1320_7_head);
          const Space v1322_7 = routine_184(c, v1322_6, v1320_7_tail);
          v1321_8 = compose(v1321_5,v1322_7);
        }
        const Space v1321_9 = intersect(constant_5,v1321_2);
        const Space v1321_10 = (has_head(v1321_9) ? constant_7 : Space{});
        Space v1321_12;
        if (!v1321_10.empty()) {
          const Path v1323_6 = concat_path(v1320_6,v1320_7_head);
          const Space v1323_11 = routine_185(c, v1323_6, v1320_7_tail);
          v1321_12 = compose(v1321_10,v1323_11);
        }
        const Space v1321_13 = unite(v1321_8,v1321_12);
        v1320_7_result = unite(v1320_7_result,v1321_13);
      }
      const Space v1320_7 = std::move(v1320_7_result);
      v1319_8 = compose(v1319_5,v1320_7);
    }
    const Space v1319_9 = intersect(constant_5,v1319_2);
    const Space v1319_10 = (has_head(v1319_9) ? constant_7 : Space{});
    Space v1319_12;
    if (!v1319_10.empty()) {
      const Path v1324_6 = concat_path(p0,v1318_11_head);
      Space v1324_11_result;
      for (int v1324_11_label = 1; v1324_11_label <= 2; ++v1324_11_label) {
        const Space v1324_11_tail = child(v1318_11_tail,v1324_11_label);
        if (v1324_11_tail.empty()) continue;
        const Path v1324_11_head{v1324_11_label};
        const Space v1325_2 = singleton(v1324_11_head);
        const Space v1325_3 = intersect(constant_5,v1325_2);
        const Space v1325_4 = (has_head(v1325_3) ? constant_7 : Space{});
        const Space v1325_5 = subtract(constant_0,v1325_4);
        Space v1325_8;
        if (!v1325_5.empty()) {
          const Path v1326_6 = concat_path(v1324_6,v1324_11_head);
          const Space v1326_7 = routine_184(c, v1326_6, v1324_11_tail);
          v1325_8 = compose(v1325_5,v1326_7);
        }
        const Space v1325_9 = intersect(constant_5,v1325_2);
        const Space v1325_10 = (has_head(v1325_9) ? constant_7 : Space{});
        Space v1325_12;
        if (!v1325_10.empty()) {
          const Path v1327_6 = concat_path(v1324_6,v1324_11_head);
          const Space v1327_11 = routine_95(c, v1327_6, v1324_11_tail);
          v1325_12 = compose(v1325_10,v1327_11);
        }
        const Space v1325_13 = unite(v1325_8,v1325_12);
        v1324_11_result = unite(v1324_11_result,v1325_13);
      }
      const Space v1324_11 = std::move(v1324_11_result);
      v1319_12 = compose(v1319_10,v1324_11);
    }
    const Space v1319_13 = unite(v1319_8,v1319_12);
    v1318_11_result = unite(v1318_11_result,v1319_13);
  }
  const Space v1318_11 = std::move(v1318_11_result);
  return v1318_11;
}

static Space routine_149(Context& c, const Path& p0, const Space& s0) {
  Space v1328_9_result;
  for (int v1328_9_label = 1; v1328_9_label <= 2; ++v1328_9_label) {
    const Space v1328_9_tail = child(s0,v1328_9_label);
    if (v1328_9_tail.empty()) continue;
    const Path v1328_9_head{v1328_9_label};
    const Space v1329_2 = singleton(v1328_9_head);
    const Space v1329_3 = intersect(constant_5,v1329_2);
    const Space v1329_4 = (has_head(v1329_3) ? constant_7 : Space{});
    const Space v1329_5 = subtract(constant_0,v1329_4);
    Space v1329_8;
    if (!v1329_5.empty()) {
      const Path v1330_6 = concat_path(p0,v1328_9_head);
      Space v1330_7_result;
      for (int v1330_7_label = 1; v1330_7_label <= 2; ++v1330_7_label) {
        const Space v1330_7_tail = child(v1328_9_tail,v1330_7_label);
        if (v1330_7_tail.empty()) continue;
        const Path v1330_7_head{v1330_7_label};
        const Space v1331_2 = singleton(v1330_7_head);
        const Space v1331_3 = intersect(constant_5,v1331_2);
        const Space v1331_4 = (has_head(v1331_3) ? constant_7 : Space{});
        const Space v1331_5 = subtract(constant_0,v1331_4);
        Space v1331_8;
        if (!v1331_5.empty()) {
          const Path v1332_6 = concat_path(v1330_6,v1330_7_head);
          const Space v1332_7 = routine_184(c, v1332_6, v1330_7_tail);
          v1331_8 = compose(v1331_5,v1332_7);
        }
        const Space v1331_9 = intersect(constant_5,v1331_2);
        const Space v1331_10 = (has_head(v1331_9) ? constant_7 : Space{});
        Space v1331_12;
        if (!v1331_10.empty()) {
          const Path v1333_6 = concat_path(v1330_6,v1330_7_head);
          const Space v1333_11 = routine_185(c, v1333_6, v1330_7_tail);
          v1331_12 = compose(v1331_10,v1333_11);
        }
        const Space v1331_13 = unite(v1331_8,v1331_12);
        v1330_7_result = unite(v1330_7_result,v1331_13);
      }
      const Space v1330_7 = std::move(v1330_7_result);
      v1329_8 = compose(v1329_5,v1330_7);
    }
    const Space v1329_9 = intersect(constant_5,v1329_2);
    const Space v1329_10 = (has_head(v1329_9) ? constant_7 : Space{});
    const Space v1329_11 = compose(v1329_10,constant_10);
    const Space v1329_12 = unite(v1329_8,v1329_11);
    v1328_9_result = unite(v1328_9_result,v1329_12);
  }
  const Space v1328_9 = std::move(v1328_9_result);
  return v1328_9;
}

static Space routine_150(Context& c, const Path& p0, const Space& s0) {
  Space v1334_11_result;
  for (int v1334_11_label = 1; v1334_11_label <= 2; ++v1334_11_label) {
    const Space v1334_11_tail = child(s0,v1334_11_label);
    if (v1334_11_tail.empty()) continue;
    const Path v1334_11_head{v1334_11_label};
    const Space v1335_2 = singleton(v1334_11_head);
    const Space v1335_3 = intersect(constant_5,v1335_2);
    const Space v1335_4 = (has_head(v1335_3) ? constant_7 : Space{});
    const Space v1335_5 = subtract(constant_0,v1335_4);
    Space v1335_8;
    if (!v1335_5.empty()) {
      const Path v1336_6 = concat_path(p0,v1334_11_head);
      Space v1336_7_result;
      for (int v1336_7_label = 1; v1336_7_label <= 2; ++v1336_7_label) {
        const Space v1336_7_tail = child(v1334_11_tail,v1336_7_label);
        if (v1336_7_tail.empty()) continue;
        const Path v1336_7_head{v1336_7_label};
        const Space v1337_2 = singleton(v1336_7_head);
        const Space v1337_3 = intersect(constant_5,v1337_2);
        const Space v1337_4 = (has_head(v1337_3) ? constant_7 : Space{});
        const Space v1337_5 = subtract(constant_0,v1337_4);
        Space v1337_8;
        if (!v1337_5.empty()) {
          const Path v1338_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1338_7 = routine_186(c, v1338_6, v1336_7_tail);
          v1337_8 = compose(v1337_5,v1338_7);
        }
        const Space v1337_9 = intersect(constant_5,v1337_2);
        const Space v1337_10 = (has_head(v1337_9) ? constant_7 : Space{});
        Space v1337_12;
        if (!v1337_10.empty()) {
          const Path v1339_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1339_11 = routine_187(c, v1339_6, v1336_7_tail);
          v1337_12 = compose(v1337_10,v1339_11);
        }
        const Space v1337_13 = unite(v1337_8,v1337_12);
        v1336_7_result = unite(v1336_7_result,v1337_13);
      }
      const Space v1336_7 = std::move(v1336_7_result);
      v1335_8 = compose(v1335_5,v1336_7);
    }
    const Space v1335_9 = intersect(constant_5,v1335_2);
    const Space v1335_10 = (has_head(v1335_9) ? constant_7 : Space{});
    Space v1335_12;
    if (!v1335_10.empty()) {
      const Path v1340_6 = concat_path(p0,v1334_11_head);
      Space v1340_11_result;
      for (int v1340_11_label = 1; v1340_11_label <= 2; ++v1340_11_label) {
        const Space v1340_11_tail = child(v1334_11_tail,v1340_11_label);
        if (v1340_11_tail.empty()) continue;
        const Path v1340_11_head{v1340_11_label};
        const Space v1341_2 = singleton(v1340_11_head);
        const Space v1341_3 = intersect(constant_5,v1341_2);
        const Space v1341_4 = (has_head(v1341_3) ? constant_7 : Space{});
        const Space v1341_5 = subtract(constant_0,v1341_4);
        Space v1341_8;
        if (!v1341_5.empty()) {
          const Path v1342_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1342_7 = routine_186(c, v1342_6, v1340_11_tail);
          v1341_8 = compose(v1341_5,v1342_7);
        }
        const Space v1341_9 = intersect(constant_5,v1341_2);
        const Space v1341_10 = (has_head(v1341_9) ? constant_7 : Space{});
        Space v1341_12;
        if (!v1341_10.empty()) {
          const Path v1343_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1343_11 = routine_98(c, v1343_6, v1340_11_tail);
          v1341_12 = compose(v1341_10,v1343_11);
        }
        const Space v1341_13 = unite(v1341_8,v1341_12);
        v1340_11_result = unite(v1340_11_result,v1341_13);
      }
      const Space v1340_11 = std::move(v1340_11_result);
      v1335_12 = compose(v1335_10,v1340_11);
    }
    const Space v1335_13 = unite(v1335_8,v1335_12);
    v1334_11_result = unite(v1334_11_result,v1335_13);
  }
  const Space v1334_11 = std::move(v1334_11_result);
  return v1334_11;
}

static Space routine_151(Context& c, const Path& p0, const Space& s0) {
  Space v1344_9_result;
  for (int v1344_9_label = 1; v1344_9_label <= 2; ++v1344_9_label) {
    const Space v1344_9_tail = child(s0,v1344_9_label);
    if (v1344_9_tail.empty()) continue;
    const Path v1344_9_head{v1344_9_label};
    const Space v1345_2 = singleton(v1344_9_head);
    const Space v1345_3 = intersect(constant_5,v1345_2);
    const Space v1345_4 = (has_head(v1345_3) ? constant_7 : Space{});
    const Space v1345_5 = subtract(constant_0,v1345_4);
    Space v1345_8;
    if (!v1345_5.empty()) {
      const Path v1346_6 = concat_path(p0,v1344_9_head);
      Space v1346_7_result;
      for (int v1346_7_label = 1; v1346_7_label <= 2; ++v1346_7_label) {
        const Space v1346_7_tail = child(v1344_9_tail,v1346_7_label);
        if (v1346_7_tail.empty()) continue;
        const Path v1346_7_head{v1346_7_label};
        const Space v1347_2 = singleton(v1346_7_head);
        const Space v1347_3 = intersect(constant_5,v1347_2);
        const Space v1347_4 = (has_head(v1347_3) ? constant_7 : Space{});
        const Space v1347_5 = subtract(constant_0,v1347_4);
        Space v1347_8;
        if (!v1347_5.empty()) {
          const Path v1348_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1348_7 = routine_186(c, v1348_6, v1346_7_tail);
          v1347_8 = compose(v1347_5,v1348_7);
        }
        const Space v1347_9 = intersect(constant_5,v1347_2);
        const Space v1347_10 = (has_head(v1347_9) ? constant_7 : Space{});
        Space v1347_12;
        if (!v1347_10.empty()) {
          const Path v1349_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1349_11 = routine_187(c, v1349_6, v1346_7_tail);
          v1347_12 = compose(v1347_10,v1349_11);
        }
        const Space v1347_13 = unite(v1347_8,v1347_12);
        v1346_7_result = unite(v1346_7_result,v1347_13);
      }
      const Space v1346_7 = std::move(v1346_7_result);
      v1345_8 = compose(v1345_5,v1346_7);
    }
    const Space v1345_9 = intersect(constant_5,v1345_2);
    const Space v1345_10 = (has_head(v1345_9) ? constant_7 : Space{});
    const Space v1345_11 = compose(v1345_10,constant_10);
    const Space v1345_12 = unite(v1345_8,v1345_11);
    v1344_9_result = unite(v1344_9_result,v1345_12);
  }
  const Space v1344_9 = std::move(v1344_9_result);
  return v1344_9;
}

static Space routine_152(Context& c, const Path& p0, const Space& s0) {
  Space v1350_11_result;
  for (int v1350_11_label = 1; v1350_11_label <= 2; ++v1350_11_label) {
    const Space v1350_11_tail = child(s0,v1350_11_label);
    if (v1350_11_tail.empty()) continue;
    const Path v1350_11_head{v1350_11_label};
    const Space v1351_2 = singleton(v1350_11_head);
    const Space v1351_3 = intersect(constant_5,v1351_2);
    const Space v1351_4 = (has_head(v1351_3) ? constant_7 : Space{});
    const Space v1351_5 = subtract(constant_0,v1351_4);
    Space v1351_8;
    if (!v1351_5.empty()) {
      const Path v1352_6 = concat_path(p0,v1350_11_head);
      Space v1352_7_result;
      for (int v1352_7_label = 1; v1352_7_label <= 2; ++v1352_7_label) {
        const Space v1352_7_tail = child(v1350_11_tail,v1352_7_label);
        if (v1352_7_tail.empty()) continue;
        const Path v1352_7_head{v1352_7_label};
        const Space v1353_2 = singleton(v1352_7_head);
        const Space v1353_3 = intersect(constant_5,v1353_2);
        const Space v1353_4 = (has_head(v1353_3) ? constant_7 : Space{});
        const Space v1353_5 = subtract(constant_0,v1353_4);
        Space v1353_8;
        if (!v1353_5.empty()) {
          const Path v1354_6 = concat_path(v1352_6,v1352_7_head);
          const Space v1354_7 = routine_188(c, v1354_6, v1352_7_tail);
          v1353_8 = compose(v1353_5,v1354_7);
        }
        const Space v1353_9 = intersect(constant_5,v1353_2);
        const Space v1353_10 = (has_head(v1353_9) ? constant_7 : Space{});
        Space v1353_12;
        if (!v1353_10.empty()) {
          const Path v1355_6 = concat_path(v1352_6,v1352_7_head);
          const Space v1355_11 = routine_189(c, v1355_6, v1352_7_tail);
          v1353_12 = compose(v1353_10,v1355_11);
        }
        const Space v1353_13 = unite(v1353_8,v1353_12);
        v1352_7_result = unite(v1352_7_result,v1353_13);
      }
      const Space v1352_7 = std::move(v1352_7_result);
      v1351_8 = compose(v1351_5,v1352_7);
    }
    const Space v1351_9 = intersect(constant_5,v1351_2);
    const Space v1351_10 = (has_head(v1351_9) ? constant_7 : Space{});
    Space v1351_12;
    if (!v1351_10.empty()) {
      const Path v1356_6 = concat_path(p0,v1350_11_head);
      Space v1356_11_result;
      for (int v1356_11_label = 1; v1356_11_label <= 2; ++v1356_11_label) {
        const Space v1356_11_tail = child(v1350_11_tail,v1356_11_label);
        if (v1356_11_tail.empty()) continue;
        const Path v1356_11_head{v1356_11_label};
        const Space v1357_2 = singleton(v1356_11_head);
        const Space v1357_3 = intersect(constant_5,v1357_2);
        const Space v1357_4 = (has_head(v1357_3) ? constant_7 : Space{});
        const Space v1357_5 = subtract(constant_0,v1357_4);
        Space v1357_8;
        if (!v1357_5.empty()) {
          const Path v1358_6 = concat_path(v1356_6,v1356_11_head);
          const Space v1358_7 = routine_188(c, v1358_6, v1356_11_tail);
          v1357_8 = compose(v1357_5,v1358_7);
        }
        const Space v1357_9 = intersect(constant_5,v1357_2);
        const Space v1357_10 = (has_head(v1357_9) ? constant_7 : Space{});
        Space v1357_12;
        if (!v1357_10.empty()) {
          const Path v1359_6 = concat_path(v1356_6,v1356_11_head);
          const Space v1359_11 = routine_101(c, v1359_6, v1356_11_tail);
          v1357_12 = compose(v1357_10,v1359_11);
        }
        const Space v1357_13 = unite(v1357_8,v1357_12);
        v1356_11_result = unite(v1356_11_result,v1357_13);
      }
      const Space v1356_11 = std::move(v1356_11_result);
      v1351_12 = compose(v1351_10,v1356_11);
    }
    const Space v1351_13 = unite(v1351_8,v1351_12);
    v1350_11_result = unite(v1350_11_result,v1351_13);
  }
  const Space v1350_11 = std::move(v1350_11_result);
  return v1350_11;
}

static Space routine_153(Context& c, const Path& p0, const Space& s0) {
  Space v1360_8_result;
  for (int v1360_8_label = 1; v1360_8_label <= 2; ++v1360_8_label) {
    const Space v1360_8_tail = child(s0,v1360_8_label);
    if (v1360_8_tail.empty()) continue;
    const Path v1360_8_head{v1360_8_label};
    const Space v1361_2 = singleton(v1360_8_head);
    const Space v1361_3 = intersect(constant_5,v1361_2);
    const Space v1361_4 = (has_head(v1361_3) ? constant_7 : Space{});
    const Space v1361_5 = subtract(constant_0,v1361_4);
    Space v1361_8;
    if (!v1361_5.empty()) {
      const Path v1362_6 = concat_path(p0,v1360_8_head);
      Space v1362_7_result;
      for (int v1362_7_label = 1; v1362_7_label <= 2; ++v1362_7_label) {
        const Space v1362_7_tail = child(v1360_8_tail,v1362_7_label);
        if (v1362_7_tail.empty()) continue;
        const Path v1362_7_head{v1362_7_label};
        const Space v1363_2 = singleton(v1362_7_head);
        const Space v1363_3 = intersect(constant_5,v1363_2);
        const Space v1363_4 = (has_head(v1363_3) ? constant_7 : Space{});
        const Space v1363_5 = subtract(constant_0,v1363_4);
        Space v1363_8;
        if (!v1363_5.empty()) {
          const Path v1364_6 = concat_path(v1362_6,v1362_7_head);
          const Space v1364_7 = routine_188(c, v1364_6, v1362_7_tail);
          v1363_8 = compose(v1363_5,v1364_7);
        }
        const Space v1363_9 = intersect(constant_5,v1363_2);
        const Space v1363_10 = (has_head(v1363_9) ? constant_7 : Space{});
        Space v1363_12;
        if (!v1363_10.empty()) {
          const Path v1365_6 = concat_path(v1362_6,v1362_7_head);
          const Space v1365_11 = routine_189(c, v1365_6, v1362_7_tail);
          v1363_12 = compose(v1363_10,v1365_11);
        }
        const Space v1363_13 = unite(v1363_8,v1363_12);
        v1362_7_result = unite(v1362_7_result,v1363_13);
      }
      const Space v1362_7 = std::move(v1362_7_result);
      v1361_8 = compose(v1361_5,v1362_7);
    }
    const Space v1361_9 = intersect(constant_5,v1361_2);
    const Space v1361_10 = (has_head(v1361_9) ? constant_7 : Space{});
    const Space v1361_11 = compose(v1361_10,v1360_8_tail);
    const Space v1361_12 = unite(v1361_8,v1361_11);
    v1360_8_result = unite(v1360_8_result,v1361_12);
  }
  const Space v1360_8 = std::move(v1360_8_result);
  return v1360_8;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1366_12_result;
  for (int v1366_12_label = 1; v1366_12_label <= 2; ++v1366_12_label) {
    const Space v1366_12_tail = child(s0,v1366_12_label);
    if (v1366_12_tail.empty()) continue;
    const Path v1366_12_head{v1366_12_label};
    const Space v1367_2 = singleton(v1366_12_head);
    const Space v1367_3 = intersect(constant_5,v1367_2);
    const Space v1367_4 = (has_head(v1367_3) ? constant_7 : Space{});
    const Space v1367_5 = subtract(constant_0,v1367_4);
    Space v1367_8;
    if (!v1367_5.empty()) {
      const Path v1368_6 = concat_path(p0,v1366_12_head);
      Space v1368_7_result;
      for (int v1368_7_label = 1; v1368_7_label <= 2; ++v1368_7_label) {
        const Space v1368_7_tail = child(v1366_12_tail,v1368_7_label);
        if (v1368_7_tail.empty()) continue;
        const Path v1368_7_head{v1368_7_label};
        const Space v1369_2 = singleton(v1368_7_head);
        const Space v1369_3 = intersect(constant_5,v1369_2);
        const Space v1369_4 = (has_head(v1369_3) ? constant_7 : Space{});
        const Space v1369_5 = subtract(constant_0,v1369_4);
        Space v1369_8;
        if (!v1369_5.empty()) {
          const Path v1370_6 = concat_path(v1368_6,v1368_7_head);
          const Space v1370_7 = routine_190(c, v1370_6, p1, v1368_7_tail);
          v1369_8 = compose(v1369_5,v1370_7);
        }
        const Space v1369_9 = intersect(constant_5,v1369_2);
        const Space v1369_10 = (has_head(v1369_9) ? constant_7 : Space{});
        Space v1369_12;
        if (!v1369_10.empty()) {
          const Path v1371_6 = concat_path(v1368_6,v1368_7_head);
          const Space v1371_11 = routine_191(c, v1371_6, p1, v1368_7_tail);
          v1369_12 = compose(v1369_10,v1371_11);
        }
        const Space v1369_13 = unite(v1369_8,v1369_12);
        v1368_7_result = unite(v1368_7_result,v1369_13);
      }
      const Space v1368_7 = std::move(v1368_7_result);
      v1367_8 = compose(v1367_5,v1368_7);
    }
    const Space v1367_9 = intersect(constant_5,v1367_2);
    const Space v1367_10 = (has_head(v1367_9) ? constant_7 : Space{});
    Space v1367_12;
    if (!v1367_10.empty()) {
      const Path v1372_6 = concat_path(p0,v1366_12_head);
      Space v1372_11_result;
      for (int v1372_11_label = 1; v1372_11_label <= 2; ++v1372_11_label) {
        const Space v1372_11_tail = child(v1366_12_tail,v1372_11_label);
        if (v1372_11_tail.empty()) continue;
        const Path v1372_11_head{v1372_11_label};
        const Space v1373_2 = singleton(v1372_11_head);
        const Space v1373_3 = intersect(constant_5,v1373_2);
        const Space v1373_4 = (has_head(v1373_3) ? constant_7 : Space{});
        const Space v1373_5 = subtract(constant_0,v1373_4);
        Space v1373_8;
        if (!v1373_5.empty()) {
          const Path v1374_6 = concat_path(v1372_6,v1372_11_head);
          const Space v1374_7 = routine_190(c, v1374_6, p1, v1372_11_tail);
          v1373_8 = compose(v1373_5,v1374_7);
        }
        const Space v1373_9 = intersect(constant_5,v1373_2);
        const Space v1373_10 = (has_head(v1373_9) ? constant_7 : Space{});
        Space v1373_12;
        if (!v1373_10.empty()) {
          const Path v1375_6 = concat_path(v1372_6,v1372_11_head);
          const Space v1375_11 = routine_26(c, v1375_6, p1, v1372_11_tail);
          v1373_12 = compose(v1373_10,v1375_11);
        }
        const Space v1373_13 = unite(v1373_8,v1373_12);
        v1372_11_result = unite(v1372_11_result,v1373_13);
      }
      const Space v1372_11 = std::move(v1372_11_result);
      v1367_12 = compose(v1367_10,v1372_11);
    }
    const Space v1367_13 = unite(v1367_8,v1367_12);
    v1366_12_result = unite(v1366_12_result,v1367_13);
  }
  const Space v1366_12 = std::move(v1366_12_result);
  return v1366_12;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1376_7 = unwrap(constant_9,p1);
  const Space v1376_9 = unwrap(constant_9,p0);
  Space v1376_13_result;
  for (int v1376_13_label = 1; v1376_13_label <= 2; ++v1376_13_label) {
    const Space v1376_13_tail = child(s0,v1376_13_label);
    if (v1376_13_tail.empty()) continue;
    const Path v1376_13_head{v1376_13_label};
    const Space v1377_2 = singleton(v1376_13_head);
    const Space v1377_3 = intersect(constant_5,v1377_2);
    const Space v1377_4 = (has_head(v1377_3) ? constant_7 : Space{});
    const Space v1377_5 = subtract(constant_0,v1377_4);
    Space v1377_8;
    if (!v1377_5.empty()) {
      const Path v1378_6 = concat_path(p0,v1376_13_head);
      Space v1378_7_result;
      for (int v1378_7_label = 1; v1378_7_label <= 2; ++v1378_7_label) {
        const Space v1378_7_tail = child(v1376_13_tail,v1378_7_label);
        if (v1378_7_tail.empty()) continue;
        const Path v1378_7_head{v1378_7_label};
        const Space v1379_2 = singleton(v1378_7_head);
        const Space v1379_3 = intersect(constant_5,v1379_2);
        const Space v1379_4 = (has_head(v1379_3) ? constant_7 : Space{});
        const Space v1379_5 = subtract(constant_0,v1379_4);
        Space v1379_8;
        if (!v1379_5.empty()) {
          const Path v1380_6 = concat_path(v1378_6,v1378_7_head);
          const Space v1380_7 = routine_190(c, v1380_6, p1, v1378_7_tail);
          v1379_8 = compose(v1379_5,v1380_7);
        }
        const Space v1379_9 = intersect(constant_5,v1379_2);
        const Space v1379_10 = (has_head(v1379_9) ? constant_7 : Space{});
        Space v1379_12;
        if (!v1379_10.empty()) {
          const Path v1381_6 = concat_path(v1378_6,v1378_7_head);
          const Space v1381_11 = routine_191(c, v1381_6, p1, v1378_7_tail);
          v1379_12 = compose(v1379_10,v1381_11);
        }
        const Space v1379_13 = unite(v1379_8,v1379_12);
        v1378_7_result = unite(v1378_7_result,v1379_13);
      }
      const Space v1378_7 = std::move(v1378_7_result);
      v1377_8 = compose(v1377_5,v1378_7);
    }
    const Space v1377_9 = intersect(constant_5,v1377_2);
    const Space v1377_10 = (has_head(v1377_9) ? constant_7 : Space{});
    const Space v1377_11 = unwrap(v1376_9,v1376_13_head);
    const Space v1377_12 = compose(v1376_7,v1377_11);
    const Path v1382_6 = concat_path(p0,v1376_13_head);
    const Path v1377_13 = concat_path(p1,v1382_6);
    const Space v1377_14 = singleton(v1377_13);
    const Space v1377_15 = subtract(v1377_12,v1377_14);
    const Space v1377_16 = compose(v1377_10,v1377_15);
    const Space v1377_17 = unite(v1377_8,v1377_16);
    v1376_13_result = unite(v1376_13_result,v1377_17);
  }
  const Space v1376_13 = std::move(v1376_13_result);
  return v1376_13;
}

static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1383_5_result;
  for (int v1383_5_label = 1; v1383_5_label <= 2; ++v1383_5_label) {
    const Space v1383_5_tail = child(s0,v1383_5_label);
    if (v1383_5_tail.empty()) continue;
    const Path v1383_5_head{v1383_5_label};
    const Space v1384_2 = singleton(v1383_5_head);
    const Space v1384_3 = intersect(constant_5,v1384_2);
    const Space v1384_4 = (has_head(v1384_3) ? constant_7 : Space{});
    Space v1384_7;
    if (!v1384_4.empty()) {
      const Path v1385_5 = concat_path(p0,v1383_5_head);
      Space v1385_6_result;
      for (int v1385_6_label = 1; v1385_6_label <= 2; ++v1385_6_label) {
        const Space v1385_6_tail = child(v1383_5_tail,v1385_6_label);
        if (v1385_6_tail.empty()) continue;
        const Path v1385_6_head{v1385_6_label};
        const Space v1386_2 = singleton(v1385_6_head);
        const Space v1386_3 = intersect(constant_5,v1386_2);
        const Space v1386_4 = (has_head(v1386_3) ? constant_7 : Space{});
        Space v1386_7;
        if (!v1386_4.empty()) {
          const Path v1387_5 = concat_path(v1385_5,v1385_6_head);
          const Space v1387_6 = routine_26(c, v1387_5, p1, v1385_6_tail);
          v1386_7 = compose(v1386_4,v1387_6);
        }
        v1385_6_result = unite(v1385_6_result,v1386_7);
      }
      const Space v1385_6 = std::move(v1385_6_result);
      v1384_7 = compose(v1384_4,v1385_6);
    }
    v1383_5_result = unite(v1383_5_result,v1384_7);
  }
  const Space v1383_5 = std::move(v1383_5_result);
  return v1383_5;
}

static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1388_5 = unwrap(constant_9,p1);
  const Space v1388_7 = unwrap(constant_9,p0);
  Space v1388_8_result;
  for (int v1388_8_label = 1; v1388_8_label <= 2; ++v1388_8_label) {
    const Space v1388_8_tail = child(s0,v1388_8_label);
    if (v1388_8_tail.empty()) continue;
    const Path v1388_8_head{v1388_8_label};
    const Space v1389_2 = singleton(v1388_8_head);
    const Space v1389_3 = intersect(constant_5,v1389_2);
    const Space v1389_4 = (has_head(v1389_3) ? constant_7 : Space{});
    const Space v1389_5 = unwrap(v1388_7,v1388_8_head);
    const Space v1389_6 = compose(v1388_5,v1389_5);
    const Path v1389_7 = concat_path(p0,v1388_8_head);
    const Path v1389_8 = concat_path(p1,v1389_7);
    const Space v1389_9 = singleton(v1389_8);
    const Space v1389_10 = subtract(v1389_6,v1389_9);
    const Space v1389_11 = compose(v1389_4,v1389_10);
    v1388_8_result = unite(v1388_8_result,v1389_11);
  }
  const Space v1388_8 = std::move(v1388_8_result);
  return v1388_8;
}

static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1390_13_result;
  for (int v1390_13_label = 1; v1390_13_label <= 2; ++v1390_13_label) {
    const Space v1390_13_tail = child(s0,v1390_13_label);
    if (v1390_13_tail.empty()) continue;
    const Path v1390_13_head{v1390_13_label};
    const Space v1391_2 = singleton(v1390_13_head);
    const Space v1391_3 = intersect(constant_5,v1391_2);
    const Space v1391_4 = (has_head(v1391_3) ? constant_7 : Space{});
    const Space v1391_5 = subtract(constant_0,v1391_4);
    Space v1391_8;
    if (!v1391_5.empty()) {
      const Path v1392_6 = concat_path(p0,v1390_13_head);
      Space v1392_7_result;
      for (int v1392_7_label = 1; v1392_7_label <= 2; ++v1392_7_label) {
        const Space v1392_7_tail = child(v1390_13_tail,v1392_7_label);
        if (v1392_7_tail.empty()) continue;
        const Path v1392_7_head{v1392_7_label};
        const Space v1393_2 = singleton(v1392_7_head);
        const Space v1393_3 = intersect(constant_5,v1393_2);
        const Space v1393_4 = (has_head(v1393_3) ? constant_7 : Space{});
        const Space v1393_5 = subtract(constant_0,v1393_4);
        Space v1393_8;
        if (!v1393_5.empty()) {
          const Path v1394_6 = concat_path(v1392_6,v1392_7_head);
          const Space v1394_7 = routine_192(c, v1394_6, p1, v1392_7_tail, s1);
          v1393_8 = compose(v1393_5,v1394_7);
        }
        const Space v1393_9 = intersect(constant_5,v1393_2);
        const Space v1393_10 = (has_head(v1393_9) ? constant_7 : Space{});
        Space v1393_12;
        if (!v1393_10.empty()) {
          const Path v1395_6 = concat_path(v1392_6,v1392_7_head);
          const Space v1395_11 = routine_193(c, v1395_6, p1, v1392_7_tail, s1);
          v1393_12 = compose(v1393_10,v1395_11);
        }
        const Space v1393_13 = unite(v1393_8,v1393_12);
        v1392_7_result = unite(v1392_7_result,v1393_13);
      }
      const Space v1392_7 = std::move(v1392_7_result);
      v1391_8 = compose(v1391_5,v1392_7);
    }
    const Space v1391_9 = intersect(constant_5,v1391_2);
    const Space v1391_10 = (has_head(v1391_9) ? constant_7 : Space{});
    Space v1391_12;
    if (!v1391_10.empty()) {
      const Path v1396_6 = concat_path(p0,v1390_13_head);
      Space v1396_11_result;
      for (int v1396_11_label = 1; v1396_11_label <= 2; ++v1396_11_label) {
        const Space v1396_11_tail = child(v1390_13_tail,v1396_11_label);
        if (v1396_11_tail.empty()) continue;
        const Path v1396_11_head{v1396_11_label};
        const Space v1397_2 = singleton(v1396_11_head);
        const Space v1397_3 = intersect(constant_5,v1397_2);
        const Space v1397_4 = (has_head(v1397_3) ? constant_7 : Space{});
        const Space v1397_5 = subtract(constant_0,v1397_4);
        Space v1397_8;
        if (!v1397_5.empty()) {
          const Path v1398_6 = concat_path(v1396_6,v1396_11_head);
          const Space v1398_7 = routine_192(c, v1398_6, p1, v1396_11_tail, s1);
          v1397_8 = compose(v1397_5,v1398_7);
        }
        const Space v1397_9 = intersect(constant_5,v1397_2);
        const Space v1397_10 = (has_head(v1397_9) ? constant_7 : Space{});
        Space v1397_12;
        if (!v1397_10.empty()) {
          const Path v1399_6 = concat_path(v1396_6,v1396_11_head);
          const Space v1399_11 = routine_33(c, v1399_6, p1, v1396_11_tail, s1);
          v1397_12 = compose(v1397_10,v1399_11);
        }
        const Space v1397_13 = unite(v1397_8,v1397_12);
        v1396_11_result = unite(v1396_11_result,v1397_13);
      }
      const Space v1396_11 = std::move(v1396_11_result);
      v1391_12 = compose(v1391_10,v1396_11);
    }
    const Space v1391_13 = unite(v1391_8,v1391_12);
    v1390_13_result = unite(v1390_13_result,v1391_13);
  }
  const Space v1390_13 = std::move(v1390_13_result);
  return v1390_13;
}

static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1400_8 = unwrap(constant_9,p1);
  const Space v1400_10 = unwrap(constant_9,p0);
  const Space v1400_12 = unwrap(s1,constant_8);
  const Space v1400_14 = unwrap(constant_9,p1);
  const Space v1400_16 = unwrap(constant_9,p0);
  Space v1400_29_result;
  for (int v1400_29_label = 1; v1400_29_label <= 2; ++v1400_29_label) {
    const Space v1400_29_tail = child(s0,v1400_29_label);
    if (v1400_29_tail.empty()) continue;
    const Path v1400_29_head{v1400_29_label};
    const Space v1401_2 = singleton(v1400_29_head);
    const Space v1401_3 = intersect(constant_5,v1401_2);
    const Space v1401_4 = (has_head(v1401_3) ? constant_7 : Space{});
    const Space v1401_5 = subtract(constant_0,v1401_4);
    Space v1401_8;
    if (!v1401_5.empty()) {
      const Path v1402_6 = concat_path(p0,v1400_29_head);
      Space v1402_7_result;
      for (int v1402_7_label = 1; v1402_7_label <= 2; ++v1402_7_label) {
        const Space v1402_7_tail = child(v1400_29_tail,v1402_7_label);
        if (v1402_7_tail.empty()) continue;
        const Path v1402_7_head{v1402_7_label};
        const Space v1403_2 = singleton(v1402_7_head);
        const Space v1403_3 = intersect(constant_5,v1403_2);
        const Space v1403_4 = (has_head(v1403_3) ? constant_7 : Space{});
        const Space v1403_5 = subtract(constant_0,v1403_4);
        Space v1403_8;
        if (!v1403_5.empty()) {
          const Path v1404_6 = concat_path(v1402_6,v1402_7_head);
          const Space v1404_7 = routine_192(c, v1404_6, p1, v1402_7_tail, s1);
          v1403_8 = compose(v1403_5,v1404_7);
        }
        const Space v1403_9 = intersect(constant_5,v1403_2);
        const Space v1403_10 = (has_head(v1403_9) ? constant_7 : Space{});
        Space v1403_12;
        if (!v1403_10.empty()) {
          const Path v1405_6 = concat_path(v1402_6,v1402_7_head);
          const Space v1405_11 = routine_193(c, v1405_6, p1, v1402_7_tail, s1);
          v1403_12 = compose(v1403_10,v1405_11);
        }
        const Space v1403_13 = unite(v1403_8,v1403_12);
        v1402_7_result = unite(v1402_7_result,v1403_13);
      }
      const Space v1402_7 = std::move(v1402_7_result);
      v1401_8 = compose(v1401_5,v1402_7);
    }
    const Space v1401_9 = intersect(constant_5,v1401_2);
    const Space v1401_10 = (has_head(v1401_9) ? constant_7 : Space{});
    Space v1401_28;
    if (!v1401_10.empty()) {
      const Path v1406_6 = concat_path(p0,v1400_29_head);
      const Space v1406_11 = unwrap(v1400_10,v1400_29_head);
      const Space v1406_12 = compose(v1400_8,v1406_11);
      const Path v1406_13 = concat_path(p1,v1406_6);
      const Space v1406_14 = singleton(v1406_13);
      const Space v1406_15 = subtract(v1406_12,v1406_14);
      const Space v1406_16 = intersect(v1406_15,v1400_12);
      const Space v1406_17 = routine_36(c, v1406_16);
      Space v1406_18_result;
      for (int v1406_18_label = 1; v1406_18_label <= 2; ++v1406_18_label) {
        const Space v1406_18_tail = child(v1406_17,v1406_18_label);
        if (v1406_18_tail.empty()) continue;
        const Path v1406_18_head{v1406_18_label};
        const Space v1407_2 = singleton(v1406_18_head);
        const Space v1407_3 = intersect(constant_5,v1407_2);
        const Space v1407_4 = (has_head(v1407_3) ? constant_7 : Space{});
        const Space v1407_5 = subtract(constant_0,v1407_4);
        Space v1407_7;
        if (!v1407_5.empty()) {
          const Space v1408_6 = routine_37(c, v1406_18_head, v1406_18_tail);
          v1407_7 = compose(v1407_5,v1408_6);
        }
        const Space v1407_8 = intersect(constant_5,v1407_2);
        const Space v1407_9 = (has_head(v1407_8) ? constant_7 : Space{});
        Space v1407_11;
        if (!v1407_9.empty()) {
          const Space v1409_10 = routine_38(c, v1406_18_head, v1406_18_tail);
          v1407_11 = compose(v1407_9,v1409_10);
        }
        const Space v1407_12 = unite(v1407_7,v1407_11);
        v1406_18_result = unite(v1406_18_result,v1407_12);
      }
      const Space v1406_18 = std::move(v1406_18_result);
      const Space v1406_19 = unwrap(v1400_16,v1400_29_head);
      const Space v1406_20 = compose(v1400_14,v1406_19);
      const Space v1406_21 = subtract(v1406_20,v1406_14);
      const Space v1406_22 = intersect(v1406_21,v1400_12);
      const Space v1406_23 = routine_39(c, v1406_22);
      Space v1406_24_result;
      for (int v1406_24_label = 1; v1406_24_label <= 2; ++v1406_24_label) {
        const Space v1406_24_tail = child(v1406_23,v1406_24_label);
        if (v1406_24_tail.empty()) continue;
        const Path v1406_24_head{v1406_24_label};
        const Space v1410_2 = singleton(v1406_24_head);
        const Space v1410_3 = intersect(constant_5,v1410_2);
        const Space v1410_4 = (has_head(v1410_3) ? constant_7 : Space{});
        const Space v1410_5 = subtract(constant_0,v1410_4);
        Space v1410_7;
        if (!v1410_5.empty()) {
          const Space v1411_6 = routine_40(c, v1406_24_head, v1406_24_tail);
          v1410_7 = compose(v1410_5,v1411_6);
        }
        const Space v1410_8 = intersect(constant_5,v1410_2);
        const Space v1410_9 = (has_head(v1410_8) ? constant_7 : Space{});
        Space v1410_11;
        if (!v1410_9.empty()) {
          const Space v1412_10 = routine_41(c, v1406_24_head, v1406_24_tail);
          v1410_11 = compose(v1410_9,v1412_10);
        }
        const Space v1410_12 = unite(v1410_7,v1410_11);
        v1406_24_result = unite(v1406_24_result,v1410_12);
      }
      const Space v1406_24 = std::move(v1406_24_result);
      const Space v1406_25 = subtract(v1406_18,v1406_24);
      const Space v1406_26 = compose(v1406_25,v1406_14);
      Space v1406_27_result;
      for (int v1406_27_label = 1; v1406_27_label <= 2; ++v1406_27_label) {
        const Space v1406_27_tail = child(v1406_26,v1406_27_label);
        if (v1406_27_tail.empty()) continue;
        const Path v1406_27_head{v1406_27_label};
        const Space v1413_2 = singleton(v1406_27_head);
        const Space v1413_3 = intersect(constant_5,v1413_2);
        const Space v1413_4 = (has_head(v1413_3) ? constant_7 : Space{});
        const Space v1413_5 = subtract(constant_0,v1413_4);
        Space v1413_7;
        if (!v1413_5.empty()) {
          const Space v1414_6 = routine_42(c, v1406_27_head, v1406_27_tail);
          v1413_7 = compose(v1413_5,v1414_6);
        }
        const Space v1413_8 = intersect(constant_5,v1413_2);
        const Space v1413_9 = (has_head(v1413_8) ? constant_7 : Space{});
        Space v1413_11;
        if (!v1413_9.empty()) {
          const Space v1415_10 = routine_43(c, v1406_27_head, v1406_27_tail);
          v1413_11 = compose(v1413_9,v1415_10);
        }
        const Space v1413_12 = unite(v1413_7,v1413_11);
        v1406_27_result = unite(v1406_27_result,v1413_12);
      }
      const Space v1406_27 = std::move(v1406_27_result);
      v1401_28 = compose(v1401_10,v1406_27);
    }
    const Space v1401_29 = unite(v1401_8,v1401_28);
    v1400_29_result = unite(v1400_29_result,v1401_29);
  }
  const Space v1400_29 = std::move(v1400_29_result);
  return v1400_29;
}

static Space routine_160(Context& c, const Path& p0, const Space& s0) {
  Space v1416_11_result;
  for (int v1416_11_label = 1; v1416_11_label <= 2; ++v1416_11_label) {
    const Space v1416_11_tail = child(s0,v1416_11_label);
    if (v1416_11_tail.empty()) continue;
    const Path v1416_11_head{v1416_11_label};
    const Space v1417_2 = singleton(v1416_11_head);
    const Space v1417_3 = intersect(constant_5,v1417_2);
    const Space v1417_4 = (has_head(v1417_3) ? constant_7 : Space{});
    const Space v1417_5 = subtract(constant_0,v1417_4);
    Space v1417_8;
    if (!v1417_5.empty()) {
      const Path v1418_6 = concat_path(p0,v1416_11_head);
      Space v1418_7_result;
      for (int v1418_7_label = 1; v1418_7_label <= 2; ++v1418_7_label) {
        const Space v1418_7_tail = child(v1416_11_tail,v1418_7_label);
        if (v1418_7_tail.empty()) continue;
        const Path v1418_7_head{v1418_7_label};
        const Space v1419_2 = singleton(v1418_7_head);
        const Space v1419_3 = intersect(constant_5,v1419_2);
        const Space v1419_4 = (has_head(v1419_3) ? constant_7 : Space{});
        const Space v1419_5 = subtract(constant_0,v1419_4);
        Space v1419_8;
        if (!v1419_5.empty()) {
          const Path v1420_6 = concat_path(v1418_6,v1418_7_head);
          const Space v1420_7 = routine_194(c, v1420_6, v1418_7_tail);
          v1419_8 = compose(v1419_5,v1420_7);
        }
        const Space v1419_9 = intersect(constant_5,v1419_2);
        const Space v1419_10 = (has_head(v1419_9) ? constant_7 : Space{});
        Space v1419_12;
        if (!v1419_10.empty()) {
          const Path v1421_6 = concat_path(v1418_6,v1418_7_head);
          const Space v1421_11 = routine_195(c, v1421_6, v1418_7_tail);
          v1419_12 = compose(v1419_10,v1421_11);
        }
        const Space v1419_13 = unite(v1419_8,v1419_12);
        v1418_7_result = unite(v1418_7_result,v1419_13);
      }
      const Space v1418_7 = std::move(v1418_7_result);
      v1417_8 = compose(v1417_5,v1418_7);
    }
    const Space v1417_9 = intersect(constant_5,v1417_2);
    const Space v1417_10 = (has_head(v1417_9) ? constant_7 : Space{});
    Space v1417_12;
    if (!v1417_10.empty()) {
      const Path v1422_6 = concat_path(p0,v1416_11_head);
      Space v1422_11_result;
      for (int v1422_11_label = 1; v1422_11_label <= 2; ++v1422_11_label) {
        const Space v1422_11_tail = child(v1416_11_tail,v1422_11_label);
        if (v1422_11_tail.empty()) continue;
        const Path v1422_11_head{v1422_11_label};
        const Space v1423_2 = singleton(v1422_11_head);
        const Space v1423_3 = intersect(constant_5,v1423_2);
        const Space v1423_4 = (has_head(v1423_3) ? constant_7 : Space{});
        const Space v1423_5 = subtract(constant_0,v1423_4);
        Space v1423_8;
        if (!v1423_5.empty()) {
          const Path v1424_6 = concat_path(v1422_6,v1422_11_head);
          const Space v1424_7 = routine_194(c, v1424_6, v1422_11_tail);
          v1423_8 = compose(v1423_5,v1424_7);
        }
        const Space v1423_9 = intersect(constant_5,v1423_2);
        const Space v1423_10 = (has_head(v1423_9) ? constant_7 : Space{});
        Space v1423_12;
        if (!v1423_10.empty()) {
          const Path v1425_6 = concat_path(v1422_6,v1422_11_head);
          const Space v1425_11 = routine_72(c, v1425_6, v1422_11_tail);
          v1423_12 = compose(v1423_10,v1425_11);
        }
        const Space v1423_13 = unite(v1423_8,v1423_12);
        v1422_11_result = unite(v1422_11_result,v1423_13);
      }
      const Space v1422_11 = std::move(v1422_11_result);
      v1417_12 = compose(v1417_10,v1422_11);
    }
    const Space v1417_13 = unite(v1417_8,v1417_12);
    v1416_11_result = unite(v1416_11_result,v1417_13);
  }
  const Space v1416_11 = std::move(v1416_11_result);
  return v1416_11;
}

static Space routine_161(Context& c, const Path& p0, const Space& s0) {
  Space v1426_9_result;
  for (int v1426_9_label = 1; v1426_9_label <= 2; ++v1426_9_label) {
    const Space v1426_9_tail = child(s0,v1426_9_label);
    if (v1426_9_tail.empty()) continue;
    const Path v1426_9_head{v1426_9_label};
    const Space v1427_2 = singleton(v1426_9_head);
    const Space v1427_3 = intersect(constant_5,v1427_2);
    const Space v1427_4 = (has_head(v1427_3) ? constant_7 : Space{});
    const Space v1427_5 = subtract(constant_0,v1427_4);
    Space v1427_8;
    if (!v1427_5.empty()) {
      const Path v1428_6 = concat_path(p0,v1426_9_head);
      Space v1428_7_result;
      for (int v1428_7_label = 1; v1428_7_label <= 2; ++v1428_7_label) {
        const Space v1428_7_tail = child(v1426_9_tail,v1428_7_label);
        if (v1428_7_tail.empty()) continue;
        const Path v1428_7_head{v1428_7_label};
        const Space v1429_2 = singleton(v1428_7_head);
        const Space v1429_3 = intersect(constant_5,v1429_2);
        const Space v1429_4 = (has_head(v1429_3) ? constant_7 : Space{});
        const Space v1429_5 = subtract(constant_0,v1429_4);
        Space v1429_8;
        if (!v1429_5.empty()) {
          const Path v1430_6 = concat_path(v1428_6,v1428_7_head);
          const Space v1430_7 = routine_194(c, v1430_6, v1428_7_tail);
          v1429_8 = compose(v1429_5,v1430_7);
        }
        const Space v1429_9 = intersect(constant_5,v1429_2);
        const Space v1429_10 = (has_head(v1429_9) ? constant_7 : Space{});
        Space v1429_12;
        if (!v1429_10.empty()) {
          const Path v1431_6 = concat_path(v1428_6,v1428_7_head);
          const Space v1431_11 = routine_195(c, v1431_6, v1428_7_tail);
          v1429_12 = compose(v1429_10,v1431_11);
        }
        const Space v1429_13 = unite(v1429_8,v1429_12);
        v1428_7_result = unite(v1428_7_result,v1429_13);
      }
      const Space v1428_7 = std::move(v1428_7_result);
      v1427_8 = compose(v1427_5,v1428_7);
    }
    const Space v1427_9 = intersect(constant_5,v1427_2);
    const Space v1427_10 = (has_head(v1427_9) ? constant_7 : Space{});
    const Space v1427_11 = compose(v1427_10,constant_10);
    const Space v1427_12 = unite(v1427_8,v1427_11);
    v1426_9_result = unite(v1426_9_result,v1427_12);
  }
  const Space v1426_9 = std::move(v1426_9_result);
  return v1426_9;
}

static Space routine_162(Context& c, const Path& p0, const Space& s0) {
  Space v1432_11_result;
  for (int v1432_11_label = 1; v1432_11_label <= 2; ++v1432_11_label) {
    const Space v1432_11_tail = child(s0,v1432_11_label);
    if (v1432_11_tail.empty()) continue;
    const Path v1432_11_head{v1432_11_label};
    const Space v1433_2 = singleton(v1432_11_head);
    const Space v1433_3 = intersect(constant_5,v1433_2);
    const Space v1433_4 = (has_head(v1433_3) ? constant_7 : Space{});
    const Space v1433_5 = subtract(constant_0,v1433_4);
    Space v1433_8;
    if (!v1433_5.empty()) {
      const Path v1434_6 = concat_path(p0,v1432_11_head);
      Space v1434_7_result;
      for (int v1434_7_label = 1; v1434_7_label <= 2; ++v1434_7_label) {
        const Space v1434_7_tail = child(v1432_11_tail,v1434_7_label);
        if (v1434_7_tail.empty()) continue;
        const Path v1434_7_head{v1434_7_label};
        const Space v1435_2 = singleton(v1434_7_head);
        const Space v1435_3 = intersect(constant_5,v1435_2);
        const Space v1435_4 = (has_head(v1435_3) ? constant_7 : Space{});
        const Space v1435_5 = subtract(constant_0,v1435_4);
        Space v1435_8;
        if (!v1435_5.empty()) {
          const Path v1436_6 = concat_path(v1434_6,v1434_7_head);
          const Space v1436_7 = routine_196(c, v1436_6, v1434_7_tail);
          v1435_8 = compose(v1435_5,v1436_7);
        }
        const Space v1435_9 = intersect(constant_5,v1435_2);
        const Space v1435_10 = (has_head(v1435_9) ? constant_7 : Space{});
        Space v1435_12;
        if (!v1435_10.empty()) {
          const Path v1437_6 = concat_path(v1434_6,v1434_7_head);
          const Space v1437_11 = routine_197(c, v1437_6, v1434_7_tail);
          v1435_12 = compose(v1435_10,v1437_11);
        }
        const Space v1435_13 = unite(v1435_8,v1435_12);
        v1434_7_result = unite(v1434_7_result,v1435_13);
      }
      const Space v1434_7 = std::move(v1434_7_result);
      v1433_8 = compose(v1433_5,v1434_7);
    }
    const Space v1433_9 = intersect(constant_5,v1433_2);
    const Space v1433_10 = (has_head(v1433_9) ? constant_7 : Space{});
    Space v1433_12;
    if (!v1433_10.empty()) {
      const Path v1438_6 = concat_path(p0,v1432_11_head);
      Space v1438_11_result;
      for (int v1438_11_label = 1; v1438_11_label <= 2; ++v1438_11_label) {
        const Space v1438_11_tail = child(v1432_11_tail,v1438_11_label);
        if (v1438_11_tail.empty()) continue;
        const Path v1438_11_head{v1438_11_label};
        const Space v1439_2 = singleton(v1438_11_head);
        const Space v1439_3 = intersect(constant_5,v1439_2);
        const Space v1439_4 = (has_head(v1439_3) ? constant_7 : Space{});
        const Space v1439_5 = subtract(constant_0,v1439_4);
        Space v1439_8;
        if (!v1439_5.empty()) {
          const Path v1440_6 = concat_path(v1438_6,v1438_11_head);
          const Space v1440_7 = routine_196(c, v1440_6, v1438_11_tail);
          v1439_8 = compose(v1439_5,v1440_7);
        }
        const Space v1439_9 = intersect(constant_5,v1439_2);
        const Space v1439_10 = (has_head(v1439_9) ? constant_7 : Space{});
        Space v1439_12;
        if (!v1439_10.empty()) {
          const Path v1441_6 = concat_path(v1438_6,v1438_11_head);
          const Space v1441_11 = routine_76(c, v1441_6, v1438_11_tail);
          v1439_12 = compose(v1439_10,v1441_11);
        }
        const Space v1439_13 = unite(v1439_8,v1439_12);
        v1438_11_result = unite(v1438_11_result,v1439_13);
      }
      const Space v1438_11 = std::move(v1438_11_result);
      v1433_12 = compose(v1433_10,v1438_11);
    }
    const Space v1433_13 = unite(v1433_8,v1433_12);
    v1432_11_result = unite(v1432_11_result,v1433_13);
  }
  const Space v1432_11 = std::move(v1432_11_result);
  return v1432_11;
}

static Space routine_163(Context& c, const Path& p0, const Space& s0) {
  Space v1442_9_result;
  for (int v1442_9_label = 1; v1442_9_label <= 2; ++v1442_9_label) {
    const Space v1442_9_tail = child(s0,v1442_9_label);
    if (v1442_9_tail.empty()) continue;
    const Path v1442_9_head{v1442_9_label};
    const Space v1443_2 = singleton(v1442_9_head);
    const Space v1443_3 = intersect(constant_5,v1443_2);
    const Space v1443_4 = (has_head(v1443_3) ? constant_7 : Space{});
    const Space v1443_5 = subtract(constant_0,v1443_4);
    Space v1443_8;
    if (!v1443_5.empty()) {
      const Path v1444_6 = concat_path(p0,v1442_9_head);
      Space v1444_7_result;
      for (int v1444_7_label = 1; v1444_7_label <= 2; ++v1444_7_label) {
        const Space v1444_7_tail = child(v1442_9_tail,v1444_7_label);
        if (v1444_7_tail.empty()) continue;
        const Path v1444_7_head{v1444_7_label};
        const Space v1445_2 = singleton(v1444_7_head);
        const Space v1445_3 = intersect(constant_5,v1445_2);
        const Space v1445_4 = (has_head(v1445_3) ? constant_7 : Space{});
        const Space v1445_5 = subtract(constant_0,v1445_4);
        Space v1445_8;
        if (!v1445_5.empty()) {
          const Path v1446_6 = concat_path(v1444_6,v1444_7_head);
          const Space v1446_7 = routine_196(c, v1446_6, v1444_7_tail);
          v1445_8 = compose(v1445_5,v1446_7);
        }
        const Space v1445_9 = intersect(constant_5,v1445_2);
        const Space v1445_10 = (has_head(v1445_9) ? constant_7 : Space{});
        Space v1445_12;
        if (!v1445_10.empty()) {
          const Path v1447_6 = concat_path(v1444_6,v1444_7_head);
          const Space v1447_11 = routine_197(c, v1447_6, v1444_7_tail);
          v1445_12 = compose(v1445_10,v1447_11);
        }
        const Space v1445_13 = unite(v1445_8,v1445_12);
        v1444_7_result = unite(v1444_7_result,v1445_13);
      }
      const Space v1444_7 = std::move(v1444_7_result);
      v1443_8 = compose(v1443_5,v1444_7);
    }
    const Space v1443_9 = intersect(constant_5,v1443_2);
    const Space v1443_10 = (has_head(v1443_9) ? constant_7 : Space{});
    const Space v1443_11 = compose(v1443_10,constant_10);
    const Space v1443_12 = unite(v1443_8,v1443_11);
    v1442_9_result = unite(v1442_9_result,v1443_12);
  }
  const Space v1442_9 = std::move(v1442_9_result);
  return v1442_9;
}

static Space routine_164(Context& c, const Path& p0, const Space& s0) {
  Space v1448_11_result;
  for (int v1448_11_label = 1; v1448_11_label <= 2; ++v1448_11_label) {
    const Space v1448_11_tail = child(s0,v1448_11_label);
    if (v1448_11_tail.empty()) continue;
    const Path v1448_11_head{v1448_11_label};
    const Space v1449_2 = singleton(v1448_11_head);
    const Space v1449_3 = intersect(constant_5,v1449_2);
    const Space v1449_4 = (has_head(v1449_3) ? constant_7 : Space{});
    const Space v1449_5 = subtract(constant_0,v1449_4);
    Space v1449_8;
    if (!v1449_5.empty()) {
      const Path v1450_6 = concat_path(p0,v1448_11_head);
      Space v1450_7_result;
      for (int v1450_7_label = 1; v1450_7_label <= 2; ++v1450_7_label) {
        const Space v1450_7_tail = child(v1448_11_tail,v1450_7_label);
        if (v1450_7_tail.empty()) continue;
        const Path v1450_7_head{v1450_7_label};
        const Space v1451_2 = singleton(v1450_7_head);
        const Space v1451_3 = intersect(constant_5,v1451_2);
        const Space v1451_4 = (has_head(v1451_3) ? constant_7 : Space{});
        const Space v1451_5 = subtract(constant_0,v1451_4);
        Space v1451_8;
        if (!v1451_5.empty()) {
          const Path v1452_6 = concat_path(v1450_6,v1450_7_head);
          const Space v1452_7 = routine_198(c, v1452_6, v1450_7_tail);
          v1451_8 = compose(v1451_5,v1452_7);
        }
        const Space v1451_9 = intersect(constant_5,v1451_2);
        const Space v1451_10 = (has_head(v1451_9) ? constant_7 : Space{});
        Space v1451_12;
        if (!v1451_10.empty()) {
          const Path v1453_6 = concat_path(v1450_6,v1450_7_head);
          const Space v1453_11 = routine_199(c, v1453_6, v1450_7_tail);
          v1451_12 = compose(v1451_10,v1453_11);
        }
        const Space v1451_13 = unite(v1451_8,v1451_12);
        v1450_7_result = unite(v1450_7_result,v1451_13);
      }
      const Space v1450_7 = std::move(v1450_7_result);
      v1449_8 = compose(v1449_5,v1450_7);
    }
    const Space v1449_9 = intersect(constant_5,v1449_2);
    const Space v1449_10 = (has_head(v1449_9) ? constant_7 : Space{});
    Space v1449_12;
    if (!v1449_10.empty()) {
      const Path v1454_6 = concat_path(p0,v1448_11_head);
      Space v1454_11_result;
      for (int v1454_11_label = 1; v1454_11_label <= 2; ++v1454_11_label) {
        const Space v1454_11_tail = child(v1448_11_tail,v1454_11_label);
        if (v1454_11_tail.empty()) continue;
        const Path v1454_11_head{v1454_11_label};
        const Space v1455_2 = singleton(v1454_11_head);
        const Space v1455_3 = intersect(constant_5,v1455_2);
        const Space v1455_4 = (has_head(v1455_3) ? constant_7 : Space{});
        const Space v1455_5 = subtract(constant_0,v1455_4);
        Space v1455_8;
        if (!v1455_5.empty()) {
          const Path v1456_6 = concat_path(v1454_6,v1454_11_head);
          const Space v1456_7 = routine_198(c, v1456_6, v1454_11_tail);
          v1455_8 = compose(v1455_5,v1456_7);
        }
        const Space v1455_9 = intersect(constant_5,v1455_2);
        const Space v1455_10 = (has_head(v1455_9) ? constant_7 : Space{});
        Space v1455_12;
        if (!v1455_10.empty()) {
          const Path v1457_6 = concat_path(v1454_6,v1454_11_head);
          const Space v1457_11 = routine_79(c, v1457_6, v1454_11_tail);
          v1455_12 = compose(v1455_10,v1457_11);
        }
        const Space v1455_13 = unite(v1455_8,v1455_12);
        v1454_11_result = unite(v1454_11_result,v1455_13);
      }
      const Space v1454_11 = std::move(v1454_11_result);
      v1449_12 = compose(v1449_10,v1454_11);
    }
    const Space v1449_13 = unite(v1449_8,v1449_12);
    v1448_11_result = unite(v1448_11_result,v1449_13);
  }
  const Space v1448_11 = std::move(v1448_11_result);
  return v1448_11;
}

static Space routine_165(Context& c, const Path& p0, const Space& s0) {
  Space v1458_8_result;
  for (int v1458_8_label = 1; v1458_8_label <= 2; ++v1458_8_label) {
    const Space v1458_8_tail = child(s0,v1458_8_label);
    if (v1458_8_tail.empty()) continue;
    const Path v1458_8_head{v1458_8_label};
    const Space v1459_2 = singleton(v1458_8_head);
    const Space v1459_3 = intersect(constant_5,v1459_2);
    const Space v1459_4 = (has_head(v1459_3) ? constant_7 : Space{});
    const Space v1459_5 = subtract(constant_0,v1459_4);
    Space v1459_8;
    if (!v1459_5.empty()) {
      const Path v1460_6 = concat_path(p0,v1458_8_head);
      Space v1460_7_result;
      for (int v1460_7_label = 1; v1460_7_label <= 2; ++v1460_7_label) {
        const Space v1460_7_tail = child(v1458_8_tail,v1460_7_label);
        if (v1460_7_tail.empty()) continue;
        const Path v1460_7_head{v1460_7_label};
        const Space v1461_2 = singleton(v1460_7_head);
        const Space v1461_3 = intersect(constant_5,v1461_2);
        const Space v1461_4 = (has_head(v1461_3) ? constant_7 : Space{});
        const Space v1461_5 = subtract(constant_0,v1461_4);
        Space v1461_8;
        if (!v1461_5.empty()) {
          const Path v1462_6 = concat_path(v1460_6,v1460_7_head);
          const Space v1462_7 = routine_198(c, v1462_6, v1460_7_tail);
          v1461_8 = compose(v1461_5,v1462_7);
        }
        const Space v1461_9 = intersect(constant_5,v1461_2);
        const Space v1461_10 = (has_head(v1461_9) ? constant_7 : Space{});
        Space v1461_12;
        if (!v1461_10.empty()) {
          const Path v1463_6 = concat_path(v1460_6,v1460_7_head);
          const Space v1463_11 = routine_199(c, v1463_6, v1460_7_tail);
          v1461_12 = compose(v1461_10,v1463_11);
        }
        const Space v1461_13 = unite(v1461_8,v1461_12);
        v1460_7_result = unite(v1460_7_result,v1461_13);
      }
      const Space v1460_7 = std::move(v1460_7_result);
      v1459_8 = compose(v1459_5,v1460_7);
    }
    const Space v1459_9 = intersect(constant_5,v1459_2);
    const Space v1459_10 = (has_head(v1459_9) ? constant_7 : Space{});
    const Space v1459_11 = compose(v1459_10,v1458_8_tail);
    const Space v1459_12 = unite(v1459_8,v1459_11);
    v1458_8_result = unite(v1458_8_result,v1459_12);
  }
  const Space v1458_8 = std::move(v1458_8_result);
  return v1458_8;
}

static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1464_6_result;
  for (int v1464_6_label = 1; v1464_6_label <= 2; ++v1464_6_label) {
    const Space v1464_6_tail = child(s0,v1464_6_label);
    if (v1464_6_tail.empty()) continue;
    const Path v1464_6_head{v1464_6_label};
    const Space v1465_2 = singleton(v1464_6_head);
    const Space v1465_3 = intersect(constant_5,v1465_2);
    const Space v1465_4 = (has_head(v1465_3) ? constant_7 : Space{});
    Space v1465_7;
    if (!v1465_4.empty()) {
      const Path v1466_5 = concat_path(p0,v1464_6_head);
      Space v1466_6_result;
      for (int v1466_6_label = 1; v1466_6_label <= 2; ++v1466_6_label) {
        const Space v1466_6_tail = child(v1464_6_tail,v1466_6_label);
        if (v1466_6_tail.empty()) continue;
        const Path v1466_6_head{v1466_6_label};
        const Space v1467_2 = singleton(v1466_6_head);
        const Space v1467_3 = intersect(constant_5,v1467_2);
        const Space v1467_4 = (has_head(v1467_3) ? constant_7 : Space{});
        Space v1467_7;
        if (!v1467_4.empty()) {
          const Path v1468_5 = concat_path(v1466_5,v1466_6_head);
          const Space v1468_6 = routine_33(c, v1468_5, p1, v1466_6_tail, s1);
          v1467_7 = compose(v1467_4,v1468_6);
        }
        v1466_6_result = unite(v1466_6_result,v1467_7);
      }
      const Space v1466_6 = std::move(v1466_6_result);
      v1465_7 = compose(v1465_4,v1466_6);
    }
    v1464_6_result = unite(v1464_6_result,v1465_7);
  }
  const Space v1464_6 = std::move(v1464_6_result);
  return v1464_6;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1469_6 = unwrap(constant_9,p1);
  const Space v1469_8 = unwrap(constant_9,p0);
  const Space v1469_10 = unwrap(s1,constant_8);
  const Space v1469_12 = unwrap(constant_9,p1);
  const Space v1469_14 = unwrap(constant_9,p0);
  Space v1469_24_result;
  for (int v1469_24_label = 1; v1469_24_label <= 2; ++v1469_24_label) {
    const Space v1469_24_tail = child(s0,v1469_24_label);
    if (v1469_24_tail.empty()) continue;
    const Path v1469_24_head{v1469_24_label};
    const Space v1470_2 = singleton(v1469_24_head);
    const Space v1470_3 = intersect(constant_5,v1470_2);
    const Space v1470_4 = (has_head(v1470_3) ? constant_7 : Space{});
    Space v1470_23;
    if (!v1470_4.empty()) {
      const Space v1471_5 = unwrap(v1469_8,v1469_24_head);
      const Space v1471_6 = compose(v1469_6,v1471_5);
      const Path v1471_7 = concat_path(p0,v1469_24_head);
      const Path v1471_8 = concat_path(p1,v1471_7);
      const Space v1471_9 = singleton(v1471_8);
      const Space v1471_10 = subtract(v1471_6,v1471_9);
      const Space v1471_11 = intersect(v1471_10,v1469_10);
      const Space v1471_12 = routine_36(c, v1471_11);
      Space v1471_13_result;
      for (int v1471_13_label = 1; v1471_13_label <= 2; ++v1471_13_label) {
        const Space v1471_13_tail = child(v1471_12,v1471_13_label);
        if (v1471_13_tail.empty()) continue;
        const Path v1471_13_head{v1471_13_label};
        const Space v1472_2 = singleton(v1471_13_head);
        const Space v1472_3 = intersect(constant_5,v1472_2);
        const Space v1472_4 = (has_head(v1472_3) ? constant_7 : Space{});
        const Space v1472_5 = subtract(constant_0,v1472_4);
        Space v1472_7;
        if (!v1472_5.empty()) {
          const Space v1473_6 = routine_37(c, v1471_13_head, v1471_13_tail);
          v1472_7 = compose(v1472_5,v1473_6);
        }
        const Space v1472_8 = intersect(constant_5,v1472_2);
        const Space v1472_9 = (has_head(v1472_8) ? constant_7 : Space{});
        Space v1472_11;
        if (!v1472_9.empty()) {
          const Space v1474_10 = routine_38(c, v1471_13_head, v1471_13_tail);
          v1472_11 = compose(v1472_9,v1474_10);
        }
        const Space v1472_12 = unite(v1472_7,v1472_11);
        v1471_13_result = unite(v1471_13_result,v1472_12);
      }
      const Space v1471_13 = std::move(v1471_13_result);
      const Space v1471_14 = unwrap(v1469_14,v1469_24_head);
      const Space v1471_15 = compose(v1469_12,v1471_14);
      const Space v1471_16 = subtract(v1471_15,v1471_9);
      const Space v1471_17 = intersect(v1471_16,v1469_10);
      const Space v1471_18 = routine_39(c, v1471_17);
      Space v1471_19_result;
      for (int v1471_19_label = 1; v1471_19_label <= 2; ++v1471_19_label) {
        const Space v1471_19_tail = child(v1471_18,v1471_19_label);
        if (v1471_19_tail.empty()) continue;
        const Path v1471_19_head{v1471_19_label};
        const Space v1475_2 = singleton(v1471_19_head);
        const Space v1475_3 = intersect(constant_5,v1475_2);
        const Space v1475_4 = (has_head(v1475_3) ? constant_7 : Space{});
        const Space v1475_5 = subtract(constant_0,v1475_4);
        Space v1475_7;
        if (!v1475_5.empty()) {
          const Space v1476_6 = routine_40(c, v1471_19_head, v1471_19_tail);
          v1475_7 = compose(v1475_5,v1476_6);
        }
        const Space v1475_8 = intersect(constant_5,v1475_2);
        const Space v1475_9 = (has_head(v1475_8) ? constant_7 : Space{});
        Space v1475_11;
        if (!v1475_9.empty()) {
          const Space v1477_10 = routine_41(c, v1471_19_head, v1471_19_tail);
          v1475_11 = compose(v1475_9,v1477_10);
        }
        const Space v1475_12 = unite(v1475_7,v1475_11);
        v1471_19_result = unite(v1471_19_result,v1475_12);
      }
      const Space v1471_19 = std::move(v1471_19_result);
      const Space v1471_20 = subtract(v1471_13,v1471_19);
      const Space v1471_21 = compose(v1471_20,v1471_9);
      Space v1471_22_result;
      for (int v1471_22_label = 1; v1471_22_label <= 2; ++v1471_22_label) {
        const Space v1471_22_tail = child(v1471_21,v1471_22_label);
        if (v1471_22_tail.empty()) continue;
        const Path v1471_22_head{v1471_22_label};
        const Space v1478_2 = singleton(v1471_22_head);
        const Space v1478_3 = intersect(constant_5,v1478_2);
        const Space v1478_4 = (has_head(v1478_3) ? constant_7 : Space{});
        const Space v1478_5 = subtract(constant_0,v1478_4);
        Space v1478_7;
        if (!v1478_5.empty()) {
          const Space v1479_6 = routine_42(c, v1471_22_head, v1471_22_tail);
          v1478_7 = compose(v1478_5,v1479_6);
        }
        const Space v1478_8 = intersect(constant_5,v1478_2);
        const Space v1478_9 = (has_head(v1478_8) ? constant_7 : Space{});
        Space v1478_11;
        if (!v1478_9.empty()) {
          const Space v1480_10 = routine_43(c, v1471_22_head, v1471_22_tail);
          v1478_11 = compose(v1478_9,v1480_10);
        }
        const Space v1478_12 = unite(v1478_7,v1478_11);
        v1471_22_result = unite(v1471_22_result,v1478_12);
      }
      const Space v1471_22 = std::move(v1471_22_result);
      v1470_23 = compose(v1470_4,v1471_22);
    }
    v1469_24_result = unite(v1469_24_result,v1470_23);
  }
  const Space v1469_24 = std::move(v1469_24_result);
  return v1469_24;
}

static Space routine_168(Context& c, const Path& p0, const Space& s0) {
  Space v1481_11_result;
  for (int v1481_11_label = 1; v1481_11_label <= 2; ++v1481_11_label) {
    const Space v1481_11_tail = child(s0,v1481_11_label);
    if (v1481_11_tail.empty()) continue;
    const Path v1481_11_head{v1481_11_label};
    const Space v1482_2 = singleton(v1481_11_head);
    const Space v1482_3 = intersect(constant_5,v1482_2);
    const Space v1482_4 = (has_head(v1482_3) ? constant_7 : Space{});
    const Space v1482_5 = subtract(constant_0,v1482_4);
    Space v1482_8;
    if (!v1482_5.empty()) {
      const Path v1483_6 = concat_path(p0,v1481_11_head);
      Space v1483_7_result;
      for (int v1483_7_label = 1; v1483_7_label <= 2; ++v1483_7_label) {
        const Space v1483_7_tail = child(v1481_11_tail,v1483_7_label);
        if (v1483_7_tail.empty()) continue;
        const Path v1483_7_head{v1483_7_label};
        const Space v1484_2 = singleton(v1483_7_head);
        const Space v1484_3 = intersect(constant_5,v1484_2);
        const Space v1484_4 = (has_head(v1484_3) ? constant_7 : Space{});
        const Space v1484_5 = subtract(constant_0,v1484_4);
        Space v1484_8;
        if (!v1484_5.empty()) {
          const Path v1485_6 = concat_path(v1483_6,v1483_7_head);
          const Space v1485_7 = routine_200(c, v1485_6, v1483_7_tail);
          v1484_8 = compose(v1484_5,v1485_7);
        }
        const Space v1484_9 = intersect(constant_5,v1484_2);
        const Space v1484_10 = (has_head(v1484_9) ? constant_7 : Space{});
        Space v1484_12;
        if (!v1484_10.empty()) {
          const Path v1486_6 = concat_path(v1483_6,v1483_7_head);
          const Space v1486_11 = routine_201(c, v1486_6, v1483_7_tail);
          v1484_12 = compose(v1484_10,v1486_11);
        }
        const Space v1484_13 = unite(v1484_8,v1484_12);
        v1483_7_result = unite(v1483_7_result,v1484_13);
      }
      const Space v1483_7 = std::move(v1483_7_result);
      v1482_8 = compose(v1482_5,v1483_7);
    }
    const Space v1482_9 = intersect(constant_5,v1482_2);
    const Space v1482_10 = (has_head(v1482_9) ? constant_7 : Space{});
    Space v1482_12;
    if (!v1482_10.empty()) {
      const Path v1487_6 = concat_path(p0,v1481_11_head);
      Space v1487_11_result;
      for (int v1487_11_label = 1; v1487_11_label <= 2; ++v1487_11_label) {
        const Space v1487_11_tail = child(v1481_11_tail,v1487_11_label);
        if (v1487_11_tail.empty()) continue;
        const Path v1487_11_head{v1487_11_label};
        const Space v1488_2 = singleton(v1487_11_head);
        const Space v1488_3 = intersect(constant_5,v1488_2);
        const Space v1488_4 = (has_head(v1488_3) ? constant_7 : Space{});
        const Space v1488_5 = subtract(constant_0,v1488_4);
        Space v1488_8;
        if (!v1488_5.empty()) {
          const Path v1489_6 = concat_path(v1487_6,v1487_11_head);
          const Space v1489_7 = routine_200(c, v1489_6, v1487_11_tail);
          v1488_8 = compose(v1488_5,v1489_7);
        }
        const Space v1488_9 = intersect(constant_5,v1488_2);
        const Space v1488_10 = (has_head(v1488_9) ? constant_7 : Space{});
        Space v1488_12;
        if (!v1488_10.empty()) {
          const Path v1490_6 = concat_path(v1487_6,v1487_11_head);
          const Space v1490_11 = routine_72(c, v1490_6, v1487_11_tail);
          v1488_12 = compose(v1488_10,v1490_11);
        }
        const Space v1488_13 = unite(v1488_8,v1488_12);
        v1487_11_result = unite(v1487_11_result,v1488_13);
      }
      const Space v1487_11 = std::move(v1487_11_result);
      v1482_12 = compose(v1482_10,v1487_11);
    }
    const Space v1482_13 = unite(v1482_8,v1482_12);
    v1481_11_result = unite(v1481_11_result,v1482_13);
  }
  const Space v1481_11 = std::move(v1481_11_result);
  return v1481_11;
}

static Space routine_169(Context& c, const Path& p0, const Space& s0) {
  Space v1491_9_result;
  for (int v1491_9_label = 1; v1491_9_label <= 2; ++v1491_9_label) {
    const Space v1491_9_tail = child(s0,v1491_9_label);
    if (v1491_9_tail.empty()) continue;
    const Path v1491_9_head{v1491_9_label};
    const Space v1492_2 = singleton(v1491_9_head);
    const Space v1492_3 = intersect(constant_5,v1492_2);
    const Space v1492_4 = (has_head(v1492_3) ? constant_7 : Space{});
    const Space v1492_5 = subtract(constant_0,v1492_4);
    Space v1492_8;
    if (!v1492_5.empty()) {
      const Path v1493_6 = concat_path(p0,v1491_9_head);
      Space v1493_7_result;
      for (int v1493_7_label = 1; v1493_7_label <= 2; ++v1493_7_label) {
        const Space v1493_7_tail = child(v1491_9_tail,v1493_7_label);
        if (v1493_7_tail.empty()) continue;
        const Path v1493_7_head{v1493_7_label};
        const Space v1494_2 = singleton(v1493_7_head);
        const Space v1494_3 = intersect(constant_5,v1494_2);
        const Space v1494_4 = (has_head(v1494_3) ? constant_7 : Space{});
        const Space v1494_5 = subtract(constant_0,v1494_4);
        Space v1494_8;
        if (!v1494_5.empty()) {
          const Path v1495_6 = concat_path(v1493_6,v1493_7_head);
          const Space v1495_7 = routine_200(c, v1495_6, v1493_7_tail);
          v1494_8 = compose(v1494_5,v1495_7);
        }
        const Space v1494_9 = intersect(constant_5,v1494_2);
        const Space v1494_10 = (has_head(v1494_9) ? constant_7 : Space{});
        Space v1494_12;
        if (!v1494_10.empty()) {
          const Path v1496_6 = concat_path(v1493_6,v1493_7_head);
          const Space v1496_11 = routine_201(c, v1496_6, v1493_7_tail);
          v1494_12 = compose(v1494_10,v1496_11);
        }
        const Space v1494_13 = unite(v1494_8,v1494_12);
        v1493_7_result = unite(v1493_7_result,v1494_13);
      }
      const Space v1493_7 = std::move(v1493_7_result);
      v1492_8 = compose(v1492_5,v1493_7);
    }
    const Space v1492_9 = intersect(constant_5,v1492_2);
    const Space v1492_10 = (has_head(v1492_9) ? constant_7 : Space{});
    const Space v1492_11 = compose(v1492_10,constant_10);
    const Space v1492_12 = unite(v1492_8,v1492_11);
    v1491_9_result = unite(v1491_9_result,v1492_12);
  }
  const Space v1491_9 = std::move(v1491_9_result);
  return v1491_9;
}

static Space routine_170(Context& c, const Path& p0, const Space& s0) {
  Space v1497_11_result;
  for (int v1497_11_label = 1; v1497_11_label <= 2; ++v1497_11_label) {
    const Space v1497_11_tail = child(s0,v1497_11_label);
    if (v1497_11_tail.empty()) continue;
    const Path v1497_11_head{v1497_11_label};
    const Space v1498_2 = singleton(v1497_11_head);
    const Space v1498_3 = intersect(constant_5,v1498_2);
    const Space v1498_4 = (has_head(v1498_3) ? constant_7 : Space{});
    const Space v1498_5 = subtract(constant_0,v1498_4);
    Space v1498_8;
    if (!v1498_5.empty()) {
      const Path v1499_6 = concat_path(p0,v1497_11_head);
      Space v1499_7_result;
      for (int v1499_7_label = 1; v1499_7_label <= 2; ++v1499_7_label) {
        const Space v1499_7_tail = child(v1497_11_tail,v1499_7_label);
        if (v1499_7_tail.empty()) continue;
        const Path v1499_7_head{v1499_7_label};
        const Space v1500_2 = singleton(v1499_7_head);
        const Space v1500_3 = intersect(constant_5,v1500_2);
        const Space v1500_4 = (has_head(v1500_3) ? constant_7 : Space{});
        const Space v1500_5 = subtract(constant_0,v1500_4);
        Space v1500_8;
        if (!v1500_5.empty()) {
          const Path v1501_6 = concat_path(v1499_6,v1499_7_head);
          const Space v1501_7 = routine_202(c, v1501_6, v1499_7_tail);
          v1500_8 = compose(v1500_5,v1501_7);
        }
        const Space v1500_9 = intersect(constant_5,v1500_2);
        const Space v1500_10 = (has_head(v1500_9) ? constant_7 : Space{});
        Space v1500_12;
        if (!v1500_10.empty()) {
          const Path v1502_6 = concat_path(v1499_6,v1499_7_head);
          const Space v1502_11 = routine_203(c, v1502_6, v1499_7_tail);
          v1500_12 = compose(v1500_10,v1502_11);
        }
        const Space v1500_13 = unite(v1500_8,v1500_12);
        v1499_7_result = unite(v1499_7_result,v1500_13);
      }
      const Space v1499_7 = std::move(v1499_7_result);
      v1498_8 = compose(v1498_5,v1499_7);
    }
    const Space v1498_9 = intersect(constant_5,v1498_2);
    const Space v1498_10 = (has_head(v1498_9) ? constant_7 : Space{});
    Space v1498_12;
    if (!v1498_10.empty()) {
      const Path v1503_6 = concat_path(p0,v1497_11_head);
      Space v1503_11_result;
      for (int v1503_11_label = 1; v1503_11_label <= 2; ++v1503_11_label) {
        const Space v1503_11_tail = child(v1497_11_tail,v1503_11_label);
        if (v1503_11_tail.empty()) continue;
        const Path v1503_11_head{v1503_11_label};
        const Space v1504_2 = singleton(v1503_11_head);
        const Space v1504_3 = intersect(constant_5,v1504_2);
        const Space v1504_4 = (has_head(v1504_3) ? constant_7 : Space{});
        const Space v1504_5 = subtract(constant_0,v1504_4);
        Space v1504_8;
        if (!v1504_5.empty()) {
          const Path v1505_6 = concat_path(v1503_6,v1503_11_head);
          const Space v1505_7 = routine_202(c, v1505_6, v1503_11_tail);
          v1504_8 = compose(v1504_5,v1505_7);
        }
        const Space v1504_9 = intersect(constant_5,v1504_2);
        const Space v1504_10 = (has_head(v1504_9) ? constant_7 : Space{});
        Space v1504_12;
        if (!v1504_10.empty()) {
          const Path v1506_6 = concat_path(v1503_6,v1503_11_head);
          const Space v1506_11 = routine_76(c, v1506_6, v1503_11_tail);
          v1504_12 = compose(v1504_10,v1506_11);
        }
        const Space v1504_13 = unite(v1504_8,v1504_12);
        v1503_11_result = unite(v1503_11_result,v1504_13);
      }
      const Space v1503_11 = std::move(v1503_11_result);
      v1498_12 = compose(v1498_10,v1503_11);
    }
    const Space v1498_13 = unite(v1498_8,v1498_12);
    v1497_11_result = unite(v1497_11_result,v1498_13);
  }
  const Space v1497_11 = std::move(v1497_11_result);
  return v1497_11;
}

static Space routine_171(Context& c, const Path& p0, const Space& s0) {
  Space v1507_9_result;
  for (int v1507_9_label = 1; v1507_9_label <= 2; ++v1507_9_label) {
    const Space v1507_9_tail = child(s0,v1507_9_label);
    if (v1507_9_tail.empty()) continue;
    const Path v1507_9_head{v1507_9_label};
    const Space v1508_2 = singleton(v1507_9_head);
    const Space v1508_3 = intersect(constant_5,v1508_2);
    const Space v1508_4 = (has_head(v1508_3) ? constant_7 : Space{});
    const Space v1508_5 = subtract(constant_0,v1508_4);
    Space v1508_8;
    if (!v1508_5.empty()) {
      const Path v1509_6 = concat_path(p0,v1507_9_head);
      Space v1509_7_result;
      for (int v1509_7_label = 1; v1509_7_label <= 2; ++v1509_7_label) {
        const Space v1509_7_tail = child(v1507_9_tail,v1509_7_label);
        if (v1509_7_tail.empty()) continue;
        const Path v1509_7_head{v1509_7_label};
        const Space v1510_2 = singleton(v1509_7_head);
        const Space v1510_3 = intersect(constant_5,v1510_2);
        const Space v1510_4 = (has_head(v1510_3) ? constant_7 : Space{});
        const Space v1510_5 = subtract(constant_0,v1510_4);
        Space v1510_8;
        if (!v1510_5.empty()) {
          const Path v1511_6 = concat_path(v1509_6,v1509_7_head);
          const Space v1511_7 = routine_202(c, v1511_6, v1509_7_tail);
          v1510_8 = compose(v1510_5,v1511_7);
        }
        const Space v1510_9 = intersect(constant_5,v1510_2);
        const Space v1510_10 = (has_head(v1510_9) ? constant_7 : Space{});
        Space v1510_12;
        if (!v1510_10.empty()) {
          const Path v1512_6 = concat_path(v1509_6,v1509_7_head);
          const Space v1512_11 = routine_203(c, v1512_6, v1509_7_tail);
          v1510_12 = compose(v1510_10,v1512_11);
        }
        const Space v1510_13 = unite(v1510_8,v1510_12);
        v1509_7_result = unite(v1509_7_result,v1510_13);
      }
      const Space v1509_7 = std::move(v1509_7_result);
      v1508_8 = compose(v1508_5,v1509_7);
    }
    const Space v1508_9 = intersect(constant_5,v1508_2);
    const Space v1508_10 = (has_head(v1508_9) ? constant_7 : Space{});
    const Space v1508_11 = compose(v1508_10,constant_10);
    const Space v1508_12 = unite(v1508_8,v1508_11);
    v1507_9_result = unite(v1507_9_result,v1508_12);
  }
  const Space v1507_9 = std::move(v1507_9_result);
  return v1507_9;
}

static Space routine_172(Context& c, const Path& p0, const Space& s0) {
  Space v1513_11_result;
  for (int v1513_11_label = 1; v1513_11_label <= 2; ++v1513_11_label) {
    const Space v1513_11_tail = child(s0,v1513_11_label);
    if (v1513_11_tail.empty()) continue;
    const Path v1513_11_head{v1513_11_label};
    const Space v1514_2 = singleton(v1513_11_head);
    const Space v1514_3 = intersect(constant_5,v1514_2);
    const Space v1514_4 = (has_head(v1514_3) ? constant_7 : Space{});
    const Space v1514_5 = subtract(constant_0,v1514_4);
    Space v1514_8;
    if (!v1514_5.empty()) {
      const Path v1515_6 = concat_path(p0,v1513_11_head);
      Space v1515_7_result;
      for (int v1515_7_label = 1; v1515_7_label <= 2; ++v1515_7_label) {
        const Space v1515_7_tail = child(v1513_11_tail,v1515_7_label);
        if (v1515_7_tail.empty()) continue;
        const Path v1515_7_head{v1515_7_label};
        const Space v1516_2 = singleton(v1515_7_head);
        const Space v1516_3 = intersect(constant_5,v1516_2);
        const Space v1516_4 = (has_head(v1516_3) ? constant_7 : Space{});
        const Space v1516_5 = subtract(constant_0,v1516_4);
        Space v1516_8;
        if (!v1516_5.empty()) {
          const Path v1517_6 = concat_path(v1515_6,v1515_7_head);
          const Space v1517_7 = routine_204(c, v1517_6, v1515_7_tail);
          v1516_8 = compose(v1516_5,v1517_7);
        }
        const Space v1516_9 = intersect(constant_5,v1516_2);
        const Space v1516_10 = (has_head(v1516_9) ? constant_7 : Space{});
        Space v1516_12;
        if (!v1516_10.empty()) {
          const Path v1518_6 = concat_path(v1515_6,v1515_7_head);
          const Space v1518_11 = routine_205(c, v1518_6, v1515_7_tail);
          v1516_12 = compose(v1516_10,v1518_11);
        }
        const Space v1516_13 = unite(v1516_8,v1516_12);
        v1515_7_result = unite(v1515_7_result,v1516_13);
      }
      const Space v1515_7 = std::move(v1515_7_result);
      v1514_8 = compose(v1514_5,v1515_7);
    }
    const Space v1514_9 = intersect(constant_5,v1514_2);
    const Space v1514_10 = (has_head(v1514_9) ? constant_7 : Space{});
    Space v1514_12;
    if (!v1514_10.empty()) {
      const Path v1519_6 = concat_path(p0,v1513_11_head);
      Space v1519_11_result;
      for (int v1519_11_label = 1; v1519_11_label <= 2; ++v1519_11_label) {
        const Space v1519_11_tail = child(v1513_11_tail,v1519_11_label);
        if (v1519_11_tail.empty()) continue;
        const Path v1519_11_head{v1519_11_label};
        const Space v1520_2 = singleton(v1519_11_head);
        const Space v1520_3 = intersect(constant_5,v1520_2);
        const Space v1520_4 = (has_head(v1520_3) ? constant_7 : Space{});
        const Space v1520_5 = subtract(constant_0,v1520_4);
        Space v1520_8;
        if (!v1520_5.empty()) {
          const Path v1521_6 = concat_path(v1519_6,v1519_11_head);
          const Space v1521_7 = routine_204(c, v1521_6, v1519_11_tail);
          v1520_8 = compose(v1520_5,v1521_7);
        }
        const Space v1520_9 = intersect(constant_5,v1520_2);
        const Space v1520_10 = (has_head(v1520_9) ? constant_7 : Space{});
        Space v1520_12;
        if (!v1520_10.empty()) {
          const Path v1522_6 = concat_path(v1519_6,v1519_11_head);
          const Space v1522_11 = routine_79(c, v1522_6, v1519_11_tail);
          v1520_12 = compose(v1520_10,v1522_11);
        }
        const Space v1520_13 = unite(v1520_8,v1520_12);
        v1519_11_result = unite(v1519_11_result,v1520_13);
      }
      const Space v1519_11 = std::move(v1519_11_result);
      v1514_12 = compose(v1514_10,v1519_11);
    }
    const Space v1514_13 = unite(v1514_8,v1514_12);
    v1513_11_result = unite(v1513_11_result,v1514_13);
  }
  const Space v1513_11 = std::move(v1513_11_result);
  return v1513_11;
}

static Space routine_173(Context& c, const Path& p0, const Space& s0) {
  Space v1523_8_result;
  for (int v1523_8_label = 1; v1523_8_label <= 2; ++v1523_8_label) {
    const Space v1523_8_tail = child(s0,v1523_8_label);
    if (v1523_8_tail.empty()) continue;
    const Path v1523_8_head{v1523_8_label};
    const Space v1524_2 = singleton(v1523_8_head);
    const Space v1524_3 = intersect(constant_5,v1524_2);
    const Space v1524_4 = (has_head(v1524_3) ? constant_7 : Space{});
    const Space v1524_5 = subtract(constant_0,v1524_4);
    Space v1524_8;
    if (!v1524_5.empty()) {
      const Path v1525_6 = concat_path(p0,v1523_8_head);
      Space v1525_7_result;
      for (int v1525_7_label = 1; v1525_7_label <= 2; ++v1525_7_label) {
        const Space v1525_7_tail = child(v1523_8_tail,v1525_7_label);
        if (v1525_7_tail.empty()) continue;
        const Path v1525_7_head{v1525_7_label};
        const Space v1526_2 = singleton(v1525_7_head);
        const Space v1526_3 = intersect(constant_5,v1526_2);
        const Space v1526_4 = (has_head(v1526_3) ? constant_7 : Space{});
        const Space v1526_5 = subtract(constant_0,v1526_4);
        Space v1526_8;
        if (!v1526_5.empty()) {
          const Path v1527_6 = concat_path(v1525_6,v1525_7_head);
          const Space v1527_7 = routine_204(c, v1527_6, v1525_7_tail);
          v1526_8 = compose(v1526_5,v1527_7);
        }
        const Space v1526_9 = intersect(constant_5,v1526_2);
        const Space v1526_10 = (has_head(v1526_9) ? constant_7 : Space{});
        Space v1526_12;
        if (!v1526_10.empty()) {
          const Path v1528_6 = concat_path(v1525_6,v1525_7_head);
          const Space v1528_11 = routine_205(c, v1528_6, v1525_7_tail);
          v1526_12 = compose(v1526_10,v1528_11);
        }
        const Space v1526_13 = unite(v1526_8,v1526_12);
        v1525_7_result = unite(v1525_7_result,v1526_13);
      }
      const Space v1525_7 = std::move(v1525_7_result);
      v1524_8 = compose(v1524_5,v1525_7);
    }
    const Space v1524_9 = intersect(constant_5,v1524_2);
    const Space v1524_10 = (has_head(v1524_9) ? constant_7 : Space{});
    const Space v1524_11 = compose(v1524_10,v1523_8_tail);
    const Space v1524_12 = unite(v1524_8,v1524_11);
    v1523_8_result = unite(v1523_8_result,v1524_12);
  }
  const Space v1523_8 = std::move(v1523_8_result);
  return v1523_8;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1529_13_result;
  for (int v1529_13_label = 1; v1529_13_label <= 2; ++v1529_13_label) {
    const Space v1529_13_tail = child(s0,v1529_13_label);
    if (v1529_13_tail.empty()) continue;
    const Path v1529_13_head{v1529_13_label};
    const Space v1530_2 = singleton(v1529_13_head);
    const Space v1530_3 = intersect(constant_5,v1530_2);
    const Space v1530_4 = (has_head(v1530_3) ? constant_7 : Space{});
    const Space v1530_5 = subtract(constant_0,v1530_4);
    Space v1530_8;
    if (!v1530_5.empty()) {
      const Path v1531_6 = concat_path(p0,v1529_13_head);
      Space v1531_7_result;
      for (int v1531_7_label = 1; v1531_7_label <= 2; ++v1531_7_label) {
        const Space v1531_7_tail = child(v1529_13_tail,v1531_7_label);
        if (v1531_7_tail.empty()) continue;
        const Path v1531_7_head{v1531_7_label};
        const Space v1532_2 = singleton(v1531_7_head);
        const Space v1532_3 = intersect(constant_5,v1532_2);
        const Space v1532_4 = (has_head(v1532_3) ? constant_7 : Space{});
        const Space v1532_5 = subtract(constant_0,v1532_4);
        Space v1532_8;
        if (!v1532_5.empty()) {
          const Path v1533_6 = concat_path(v1531_6,v1531_7_head);
          const Space v1533_7 = routine_206(c, v1533_6, p1, v1531_7_tail, s1);
          v1532_8 = compose(v1532_5,v1533_7);
        }
        const Space v1532_9 = intersect(constant_5,v1532_2);
        const Space v1532_10 = (has_head(v1532_9) ? constant_7 : Space{});
        Space v1532_12;
        if (!v1532_10.empty()) {
          const Path v1534_6 = concat_path(v1531_6,v1531_7_head);
          const Space v1534_11 = routine_207(c, v1534_6, p1, v1531_7_tail, s1);
          v1532_12 = compose(v1532_10,v1534_11);
        }
        const Space v1532_13 = unite(v1532_8,v1532_12);
        v1531_7_result = unite(v1531_7_result,v1532_13);
      }
      const Space v1531_7 = std::move(v1531_7_result);
      v1530_8 = compose(v1530_5,v1531_7);
    }
    const Space v1530_9 = intersect(constant_5,v1530_2);
    const Space v1530_10 = (has_head(v1530_9) ? constant_7 : Space{});
    Space v1530_12;
    if (!v1530_10.empty()) {
      const Path v1535_6 = concat_path(p0,v1529_13_head);
      Space v1535_11_result;
      for (int v1535_11_label = 1; v1535_11_label <= 2; ++v1535_11_label) {
        const Space v1535_11_tail = child(v1529_13_tail,v1535_11_label);
        if (v1535_11_tail.empty()) continue;
        const Path v1535_11_head{v1535_11_label};
        const Space v1536_2 = singleton(v1535_11_head);
        const Space v1536_3 = intersect(constant_5,v1536_2);
        const Space v1536_4 = (has_head(v1536_3) ? constant_7 : Space{});
        const Space v1536_5 = subtract(constant_0,v1536_4);
        Space v1536_8;
        if (!v1536_5.empty()) {
          const Path v1537_6 = concat_path(v1535_6,v1535_11_head);
          const Space v1537_7 = routine_206(c, v1537_6, p1, v1535_11_tail, s1);
          v1536_8 = compose(v1536_5,v1537_7);
        }
        const Space v1536_9 = intersect(constant_5,v1536_2);
        const Space v1536_10 = (has_head(v1536_9) ? constant_7 : Space{});
        Space v1536_12;
        if (!v1536_10.empty()) {
          const Path v1538_6 = concat_path(v1535_6,v1535_11_head);
          const Space v1538_11 = routine_48(c, v1538_6, p1, v1535_11_tail, s1);
          v1536_12 = compose(v1536_10,v1538_11);
        }
        const Space v1536_13 = unite(v1536_8,v1536_12);
        v1535_11_result = unite(v1535_11_result,v1536_13);
      }
      const Space v1535_11 = std::move(v1535_11_result);
      v1530_12 = compose(v1530_10,v1535_11);
    }
    const Space v1530_13 = unite(v1530_8,v1530_12);
    v1529_13_result = unite(v1529_13_result,v1530_13);
  }
  const Space v1529_13 = std::move(v1529_13_result);
  return v1529_13;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1539_8 = unwrap(constant_9,p1);
  const Space v1539_10 = unwrap(constant_9,p0);
  const Space v1539_12 = unwrap(s1,constant_8);
  const Space v1539_14 = unwrap(constant_9,p1);
  const Space v1539_16 = unwrap(constant_9,p0);
  Space v1539_29_result;
  for (int v1539_29_label = 1; v1539_29_label <= 2; ++v1539_29_label) {
    const Space v1539_29_tail = child(s0,v1539_29_label);
    if (v1539_29_tail.empty()) continue;
    const Path v1539_29_head{v1539_29_label};
    const Space v1540_2 = singleton(v1539_29_head);
    const Space v1540_3 = intersect(constant_5,v1540_2);
    const Space v1540_4 = (has_head(v1540_3) ? constant_7 : Space{});
    const Space v1540_5 = subtract(constant_0,v1540_4);
    Space v1540_8;
    if (!v1540_5.empty()) {
      const Path v1541_6 = concat_path(p0,v1539_29_head);
      Space v1541_7_result;
      for (int v1541_7_label = 1; v1541_7_label <= 2; ++v1541_7_label) {
        const Space v1541_7_tail = child(v1539_29_tail,v1541_7_label);
        if (v1541_7_tail.empty()) continue;
        const Path v1541_7_head{v1541_7_label};
        const Space v1542_2 = singleton(v1541_7_head);
        const Space v1542_3 = intersect(constant_5,v1542_2);
        const Space v1542_4 = (has_head(v1542_3) ? constant_7 : Space{});
        const Space v1542_5 = subtract(constant_0,v1542_4);
        Space v1542_8;
        if (!v1542_5.empty()) {
          const Path v1543_6 = concat_path(v1541_6,v1541_7_head);
          const Space v1543_7 = routine_206(c, v1543_6, p1, v1541_7_tail, s1);
          v1542_8 = compose(v1542_5,v1543_7);
        }
        const Space v1542_9 = intersect(constant_5,v1542_2);
        const Space v1542_10 = (has_head(v1542_9) ? constant_7 : Space{});
        Space v1542_12;
        if (!v1542_10.empty()) {
          const Path v1544_6 = concat_path(v1541_6,v1541_7_head);
          const Space v1544_11 = routine_207(c, v1544_6, p1, v1541_7_tail, s1);
          v1542_12 = compose(v1542_10,v1544_11);
        }
        const Space v1542_13 = unite(v1542_8,v1542_12);
        v1541_7_result = unite(v1541_7_result,v1542_13);
      }
      const Space v1541_7 = std::move(v1541_7_result);
      v1540_8 = compose(v1540_5,v1541_7);
    }
    const Space v1540_9 = intersect(constant_5,v1540_2);
    const Space v1540_10 = (has_head(v1540_9) ? constant_7 : Space{});
    Space v1540_28;
    if (!v1540_10.empty()) {
      const Path v1545_6 = concat_path(p0,v1539_29_head);
      const Space v1545_11 = unwrap(v1539_10,v1539_29_head);
      const Space v1545_12 = compose(v1539_8,v1545_11);
      const Path v1545_13 = concat_path(p1,v1545_6);
      const Space v1545_14 = singleton(v1545_13);
      const Space v1545_15 = subtract(v1545_12,v1545_14);
      const Space v1545_16 = intersect(v1545_15,v1539_12);
      const Space v1545_17 = routine_51(c, v1545_16);
      Space v1545_18_result;
      for (int v1545_18_label = 1; v1545_18_label <= 2; ++v1545_18_label) {
        const Space v1545_18_tail = child(v1545_17,v1545_18_label);
        if (v1545_18_tail.empty()) continue;
        const Path v1545_18_head{v1545_18_label};
        const Space v1546_2 = singleton(v1545_18_head);
        const Space v1546_3 = intersect(constant_5,v1546_2);
        const Space v1546_4 = (has_head(v1546_3) ? constant_7 : Space{});
        const Space v1546_5 = subtract(constant_0,v1546_4);
        Space v1546_7;
        if (!v1546_5.empty()) {
          const Space v1547_6 = routine_52(c, v1545_18_head, v1545_18_tail);
          v1546_7 = compose(v1546_5,v1547_6);
        }
        const Space v1546_8 = intersect(constant_5,v1546_2);
        const Space v1546_9 = (has_head(v1546_8) ? constant_7 : Space{});
        Space v1546_11;
        if (!v1546_9.empty()) {
          const Space v1548_10 = routine_53(c, v1545_18_head, v1545_18_tail);
          v1546_11 = compose(v1546_9,v1548_10);
        }
        const Space v1546_12 = unite(v1546_7,v1546_11);
        v1545_18_result = unite(v1545_18_result,v1546_12);
      }
      const Space v1545_18 = std::move(v1545_18_result);
      const Space v1545_19 = unwrap(v1539_16,v1539_29_head);
      const Space v1545_20 = compose(v1539_14,v1545_19);
      const Space v1545_21 = subtract(v1545_20,v1545_14);
      const Space v1545_22 = intersect(v1545_21,v1539_12);
      const Space v1545_23 = routine_36(c, v1545_22);
      Space v1545_24_result;
      for (int v1545_24_label = 1; v1545_24_label <= 2; ++v1545_24_label) {
        const Space v1545_24_tail = child(v1545_23,v1545_24_label);
        if (v1545_24_tail.empty()) continue;
        const Path v1545_24_head{v1545_24_label};
        const Space v1549_2 = singleton(v1545_24_head);
        const Space v1549_3 = intersect(constant_5,v1549_2);
        const Space v1549_4 = (has_head(v1549_3) ? constant_7 : Space{});
        const Space v1549_5 = subtract(constant_0,v1549_4);
        Space v1549_7;
        if (!v1549_5.empty()) {
          const Space v1550_6 = routine_54(c, v1545_24_head, v1545_24_tail);
          v1549_7 = compose(v1549_5,v1550_6);
        }
        const Space v1549_8 = intersect(constant_5,v1549_2);
        const Space v1549_9 = (has_head(v1549_8) ? constant_7 : Space{});
        Space v1549_11;
        if (!v1549_9.empty()) {
          const Space v1551_10 = routine_55(c, v1545_24_head, v1545_24_tail);
          v1549_11 = compose(v1549_9,v1551_10);
        }
        const Space v1549_12 = unite(v1549_7,v1549_11);
        v1545_24_result = unite(v1545_24_result,v1549_12);
      }
      const Space v1545_24 = std::move(v1545_24_result);
      const Space v1545_25 = subtract(v1545_18,v1545_24);
      const Space v1545_26 = compose(v1545_25,v1545_14);
      Space v1545_27_result;
      for (int v1545_27_label = 1; v1545_27_label <= 2; ++v1545_27_label) {
        const Space v1545_27_tail = child(v1545_26,v1545_27_label);
        if (v1545_27_tail.empty()) continue;
        const Path v1545_27_head{v1545_27_label};
        const Space v1552_2 = singleton(v1545_27_head);
        const Space v1552_3 = intersect(constant_5,v1552_2);
        const Space v1552_4 = (has_head(v1552_3) ? constant_7 : Space{});
        const Space v1552_5 = subtract(constant_0,v1552_4);
        Space v1552_7;
        if (!v1552_5.empty()) {
          const Space v1553_6 = routine_56(c, v1545_27_head, v1545_27_tail);
          v1552_7 = compose(v1552_5,v1553_6);
        }
        const Space v1552_8 = intersect(constant_5,v1552_2);
        const Space v1552_9 = (has_head(v1552_8) ? constant_7 : Space{});
        Space v1552_11;
        if (!v1552_9.empty()) {
          const Space v1554_10 = routine_57(c, v1545_27_head, v1545_27_tail);
          v1552_11 = compose(v1552_9,v1554_10);
        }
        const Space v1552_12 = unite(v1552_7,v1552_11);
        v1545_27_result = unite(v1545_27_result,v1552_12);
      }
      const Space v1545_27 = std::move(v1545_27_result);
      v1540_28 = compose(v1540_10,v1545_27);
    }
    const Space v1540_29 = unite(v1540_8,v1540_28);
    v1539_29_result = unite(v1539_29_result,v1540_29);
  }
  const Space v1539_29 = std::move(v1539_29_result);
  return v1539_29;
}

static Space routine_176(Context& c, const Path& p0, const Space& s0) {
  Space v1555_11_result;
  for (int v1555_11_label = 1; v1555_11_label <= 2; ++v1555_11_label) {
    const Space v1555_11_tail = child(s0,v1555_11_label);
    if (v1555_11_tail.empty()) continue;
    const Path v1555_11_head{v1555_11_label};
    const Space v1556_2 = singleton(v1555_11_head);
    const Space v1556_3 = intersect(constant_5,v1556_2);
    const Space v1556_4 = (has_head(v1556_3) ? constant_7 : Space{});
    const Space v1556_5 = subtract(constant_0,v1556_4);
    Space v1556_8;
    if (!v1556_5.empty()) {
      const Path v1557_6 = concat_path(p0,v1555_11_head);
      Space v1557_7_result;
      for (int v1557_7_label = 1; v1557_7_label <= 2; ++v1557_7_label) {
        const Space v1557_7_tail = child(v1555_11_tail,v1557_7_label);
        if (v1557_7_tail.empty()) continue;
        const Path v1557_7_head{v1557_7_label};
        const Space v1558_2 = singleton(v1557_7_head);
        const Space v1558_3 = intersect(constant_5,v1558_2);
        const Space v1558_4 = (has_head(v1558_3) ? constant_7 : Space{});
        const Space v1558_5 = subtract(constant_0,v1558_4);
        Space v1558_8;
        if (!v1558_5.empty()) {
          const Path v1559_6 = concat_path(v1557_6,v1557_7_head);
          const Space v1559_7 = routine_208(c, v1559_6, v1557_7_tail);
          v1558_8 = compose(v1558_5,v1559_7);
        }
        const Space v1558_9 = intersect(constant_5,v1558_2);
        const Space v1558_10 = (has_head(v1558_9) ? constant_7 : Space{});
        Space v1558_12;
        if (!v1558_10.empty()) {
          const Path v1560_6 = concat_path(v1557_6,v1557_7_head);
          const Space v1560_11 = routine_209(c, v1560_6, v1557_7_tail);
          v1558_12 = compose(v1558_10,v1560_11);
        }
        const Space v1558_13 = unite(v1558_8,v1558_12);
        v1557_7_result = unite(v1557_7_result,v1558_13);
      }
      const Space v1557_7 = std::move(v1557_7_result);
      v1556_8 = compose(v1556_5,v1557_7);
    }
    const Space v1556_9 = intersect(constant_5,v1556_2);
    const Space v1556_10 = (has_head(v1556_9) ? constant_7 : Space{});
    Space v1556_12;
    if (!v1556_10.empty()) {
      const Path v1561_6 = concat_path(p0,v1555_11_head);
      Space v1561_11_result;
      for (int v1561_11_label = 1; v1561_11_label <= 2; ++v1561_11_label) {
        const Space v1561_11_tail = child(v1555_11_tail,v1561_11_label);
        if (v1561_11_tail.empty()) continue;
        const Path v1561_11_head{v1561_11_label};
        const Space v1562_2 = singleton(v1561_11_head);
        const Space v1562_3 = intersect(constant_5,v1562_2);
        const Space v1562_4 = (has_head(v1562_3) ? constant_7 : Space{});
        const Space v1562_5 = subtract(constant_0,v1562_4);
        Space v1562_8;
        if (!v1562_5.empty()) {
          const Path v1563_6 = concat_path(v1561_6,v1561_11_head);
          const Space v1563_7 = routine_208(c, v1563_6, v1561_11_tail);
          v1562_8 = compose(v1562_5,v1563_7);
        }
        const Space v1562_9 = intersect(constant_5,v1562_2);
        const Space v1562_10 = (has_head(v1562_9) ? constant_7 : Space{});
        Space v1562_12;
        if (!v1562_10.empty()) {
          const Path v1564_6 = concat_path(v1561_6,v1561_11_head);
          const Space v1564_11 = routine_95(c, v1564_6, v1561_11_tail);
          v1562_12 = compose(v1562_10,v1564_11);
        }
        const Space v1562_13 = unite(v1562_8,v1562_12);
        v1561_11_result = unite(v1561_11_result,v1562_13);
      }
      const Space v1561_11 = std::move(v1561_11_result);
      v1556_12 = compose(v1556_10,v1561_11);
    }
    const Space v1556_13 = unite(v1556_8,v1556_12);
    v1555_11_result = unite(v1555_11_result,v1556_13);
  }
  const Space v1555_11 = std::move(v1555_11_result);
  return v1555_11;
}

static Space routine_177(Context& c, const Path& p0, const Space& s0) {
  Space v1565_9_result;
  for (int v1565_9_label = 1; v1565_9_label <= 2; ++v1565_9_label) {
    const Space v1565_9_tail = child(s0,v1565_9_label);
    if (v1565_9_tail.empty()) continue;
    const Path v1565_9_head{v1565_9_label};
    const Space v1566_2 = singleton(v1565_9_head);
    const Space v1566_3 = intersect(constant_5,v1566_2);
    const Space v1566_4 = (has_head(v1566_3) ? constant_7 : Space{});
    const Space v1566_5 = subtract(constant_0,v1566_4);
    Space v1566_8;
    if (!v1566_5.empty()) {
      const Path v1567_6 = concat_path(p0,v1565_9_head);
      Space v1567_7_result;
      for (int v1567_7_label = 1; v1567_7_label <= 2; ++v1567_7_label) {
        const Space v1567_7_tail = child(v1565_9_tail,v1567_7_label);
        if (v1567_7_tail.empty()) continue;
        const Path v1567_7_head{v1567_7_label};
        const Space v1568_2 = singleton(v1567_7_head);
        const Space v1568_3 = intersect(constant_5,v1568_2);
        const Space v1568_4 = (has_head(v1568_3) ? constant_7 : Space{});
        const Space v1568_5 = subtract(constant_0,v1568_4);
        Space v1568_8;
        if (!v1568_5.empty()) {
          const Path v1569_6 = concat_path(v1567_6,v1567_7_head);
          const Space v1569_7 = routine_208(c, v1569_6, v1567_7_tail);
          v1568_8 = compose(v1568_5,v1569_7);
        }
        const Space v1568_9 = intersect(constant_5,v1568_2);
        const Space v1568_10 = (has_head(v1568_9) ? constant_7 : Space{});
        Space v1568_12;
        if (!v1568_10.empty()) {
          const Path v1570_6 = concat_path(v1567_6,v1567_7_head);
          const Space v1570_11 = routine_209(c, v1570_6, v1567_7_tail);
          v1568_12 = compose(v1568_10,v1570_11);
        }
        const Space v1568_13 = unite(v1568_8,v1568_12);
        v1567_7_result = unite(v1567_7_result,v1568_13);
      }
      const Space v1567_7 = std::move(v1567_7_result);
      v1566_8 = compose(v1566_5,v1567_7);
    }
    const Space v1566_9 = intersect(constant_5,v1566_2);
    const Space v1566_10 = (has_head(v1566_9) ? constant_7 : Space{});
    const Space v1566_11 = compose(v1566_10,constant_10);
    const Space v1566_12 = unite(v1566_8,v1566_11);
    v1565_9_result = unite(v1565_9_result,v1566_12);
  }
  const Space v1565_9 = std::move(v1565_9_result);
  return v1565_9;
}

static Space routine_178(Context& c, const Path& p0, const Space& s0) {
  Space v1571_11_result;
  for (int v1571_11_label = 1; v1571_11_label <= 2; ++v1571_11_label) {
    const Space v1571_11_tail = child(s0,v1571_11_label);
    if (v1571_11_tail.empty()) continue;
    const Path v1571_11_head{v1571_11_label};
    const Space v1572_2 = singleton(v1571_11_head);
    const Space v1572_3 = intersect(constant_5,v1572_2);
    const Space v1572_4 = (has_head(v1572_3) ? constant_7 : Space{});
    const Space v1572_5 = subtract(constant_0,v1572_4);
    Space v1572_8;
    if (!v1572_5.empty()) {
      const Path v1573_6 = concat_path(p0,v1571_11_head);
      Space v1573_7_result;
      for (int v1573_7_label = 1; v1573_7_label <= 2; ++v1573_7_label) {
        const Space v1573_7_tail = child(v1571_11_tail,v1573_7_label);
        if (v1573_7_tail.empty()) continue;
        const Path v1573_7_head{v1573_7_label};
        const Space v1574_2 = singleton(v1573_7_head);
        const Space v1574_3 = intersect(constant_5,v1574_2);
        const Space v1574_4 = (has_head(v1574_3) ? constant_7 : Space{});
        const Space v1574_5 = subtract(constant_0,v1574_4);
        Space v1574_8;
        if (!v1574_5.empty()) {
          const Path v1575_6 = concat_path(v1573_6,v1573_7_head);
          const Space v1575_7 = routine_210(c, v1575_6, v1573_7_tail);
          v1574_8 = compose(v1574_5,v1575_7);
        }
        const Space v1574_9 = intersect(constant_5,v1574_2);
        const Space v1574_10 = (has_head(v1574_9) ? constant_7 : Space{});
        Space v1574_12;
        if (!v1574_10.empty()) {
          const Path v1576_6 = concat_path(v1573_6,v1573_7_head);
          const Space v1576_11 = routine_211(c, v1576_6, v1573_7_tail);
          v1574_12 = compose(v1574_10,v1576_11);
        }
        const Space v1574_13 = unite(v1574_8,v1574_12);
        v1573_7_result = unite(v1573_7_result,v1574_13);
      }
      const Space v1573_7 = std::move(v1573_7_result);
      v1572_8 = compose(v1572_5,v1573_7);
    }
    const Space v1572_9 = intersect(constant_5,v1572_2);
    const Space v1572_10 = (has_head(v1572_9) ? constant_7 : Space{});
    Space v1572_12;
    if (!v1572_10.empty()) {
      const Path v1577_6 = concat_path(p0,v1571_11_head);
      Space v1577_11_result;
      for (int v1577_11_label = 1; v1577_11_label <= 2; ++v1577_11_label) {
        const Space v1577_11_tail = child(v1571_11_tail,v1577_11_label);
        if (v1577_11_tail.empty()) continue;
        const Path v1577_11_head{v1577_11_label};
        const Space v1578_2 = singleton(v1577_11_head);
        const Space v1578_3 = intersect(constant_5,v1578_2);
        const Space v1578_4 = (has_head(v1578_3) ? constant_7 : Space{});
        const Space v1578_5 = subtract(constant_0,v1578_4);
        Space v1578_8;
        if (!v1578_5.empty()) {
          const Path v1579_6 = concat_path(v1577_6,v1577_11_head);
          const Space v1579_7 = routine_210(c, v1579_6, v1577_11_tail);
          v1578_8 = compose(v1578_5,v1579_7);
        }
        const Space v1578_9 = intersect(constant_5,v1578_2);
        const Space v1578_10 = (has_head(v1578_9) ? constant_7 : Space{});
        Space v1578_12;
        if (!v1578_10.empty()) {
          const Path v1580_6 = concat_path(v1577_6,v1577_11_head);
          const Space v1580_11 = routine_98(c, v1580_6, v1577_11_tail);
          v1578_12 = compose(v1578_10,v1580_11);
        }
        const Space v1578_13 = unite(v1578_8,v1578_12);
        v1577_11_result = unite(v1577_11_result,v1578_13);
      }
      const Space v1577_11 = std::move(v1577_11_result);
      v1572_12 = compose(v1572_10,v1577_11);
    }
    const Space v1572_13 = unite(v1572_8,v1572_12);
    v1571_11_result = unite(v1571_11_result,v1572_13);
  }
  const Space v1571_11 = std::move(v1571_11_result);
  return v1571_11;
}

static Space routine_179(Context& c, const Path& p0, const Space& s0) {
  Space v1581_9_result;
  for (int v1581_9_label = 1; v1581_9_label <= 2; ++v1581_9_label) {
    const Space v1581_9_tail = child(s0,v1581_9_label);
    if (v1581_9_tail.empty()) continue;
    const Path v1581_9_head{v1581_9_label};
    const Space v1582_2 = singleton(v1581_9_head);
    const Space v1582_3 = intersect(constant_5,v1582_2);
    const Space v1582_4 = (has_head(v1582_3) ? constant_7 : Space{});
    const Space v1582_5 = subtract(constant_0,v1582_4);
    Space v1582_8;
    if (!v1582_5.empty()) {
      const Path v1583_6 = concat_path(p0,v1581_9_head);
      Space v1583_7_result;
      for (int v1583_7_label = 1; v1583_7_label <= 2; ++v1583_7_label) {
        const Space v1583_7_tail = child(v1581_9_tail,v1583_7_label);
        if (v1583_7_tail.empty()) continue;
        const Path v1583_7_head{v1583_7_label};
        const Space v1584_2 = singleton(v1583_7_head);
        const Space v1584_3 = intersect(constant_5,v1584_2);
        const Space v1584_4 = (has_head(v1584_3) ? constant_7 : Space{});
        const Space v1584_5 = subtract(constant_0,v1584_4);
        Space v1584_8;
        if (!v1584_5.empty()) {
          const Path v1585_6 = concat_path(v1583_6,v1583_7_head);
          const Space v1585_7 = routine_210(c, v1585_6, v1583_7_tail);
          v1584_8 = compose(v1584_5,v1585_7);
        }
        const Space v1584_9 = intersect(constant_5,v1584_2);
        const Space v1584_10 = (has_head(v1584_9) ? constant_7 : Space{});
        Space v1584_12;
        if (!v1584_10.empty()) {
          const Path v1586_6 = concat_path(v1583_6,v1583_7_head);
          const Space v1586_11 = routine_211(c, v1586_6, v1583_7_tail);
          v1584_12 = compose(v1584_10,v1586_11);
        }
        const Space v1584_13 = unite(v1584_8,v1584_12);
        v1583_7_result = unite(v1583_7_result,v1584_13);
      }
      const Space v1583_7 = std::move(v1583_7_result);
      v1582_8 = compose(v1582_5,v1583_7);
    }
    const Space v1582_9 = intersect(constant_5,v1582_2);
    const Space v1582_10 = (has_head(v1582_9) ? constant_7 : Space{});
    const Space v1582_11 = compose(v1582_10,constant_10);
    const Space v1582_12 = unite(v1582_8,v1582_11);
    v1581_9_result = unite(v1581_9_result,v1582_12);
  }
  const Space v1581_9 = std::move(v1581_9_result);
  return v1581_9;
}

static Space routine_180(Context& c, const Path& p0, const Space& s0) {
  Space v1587_11_result;
  for (int v1587_11_label = 1; v1587_11_label <= 2; ++v1587_11_label) {
    const Space v1587_11_tail = child(s0,v1587_11_label);
    if (v1587_11_tail.empty()) continue;
    const Path v1587_11_head{v1587_11_label};
    const Space v1588_2 = singleton(v1587_11_head);
    const Space v1588_3 = intersect(constant_5,v1588_2);
    const Space v1588_4 = (has_head(v1588_3) ? constant_7 : Space{});
    const Space v1588_5 = subtract(constant_0,v1588_4);
    Space v1588_8;
    if (!v1588_5.empty()) {
      const Path v1589_6 = concat_path(p0,v1587_11_head);
      Space v1589_7_result;
      for (int v1589_7_label = 1; v1589_7_label <= 2; ++v1589_7_label) {
        const Space v1589_7_tail = child(v1587_11_tail,v1589_7_label);
        if (v1589_7_tail.empty()) continue;
        const Path v1589_7_head{v1589_7_label};
        const Space v1590_2 = singleton(v1589_7_head);
        const Space v1590_3 = intersect(constant_5,v1590_2);
        const Space v1590_4 = (has_head(v1590_3) ? constant_7 : Space{});
        const Space v1590_5 = subtract(constant_0,v1590_4);
        Space v1590_8;
        if (!v1590_5.empty()) {
          const Path v1591_6 = concat_path(v1589_6,v1589_7_head);
          const Space v1591_7 = routine_212(c, v1591_6, v1589_7_tail);
          v1590_8 = compose(v1590_5,v1591_7);
        }
        const Space v1590_9 = intersect(constant_5,v1590_2);
        const Space v1590_10 = (has_head(v1590_9) ? constant_7 : Space{});
        Space v1590_12;
        if (!v1590_10.empty()) {
          const Path v1592_6 = concat_path(v1589_6,v1589_7_head);
          const Space v1592_11 = routine_213(c, v1592_6, v1589_7_tail);
          v1590_12 = compose(v1590_10,v1592_11);
        }
        const Space v1590_13 = unite(v1590_8,v1590_12);
        v1589_7_result = unite(v1589_7_result,v1590_13);
      }
      const Space v1589_7 = std::move(v1589_7_result);
      v1588_8 = compose(v1588_5,v1589_7);
    }
    const Space v1588_9 = intersect(constant_5,v1588_2);
    const Space v1588_10 = (has_head(v1588_9) ? constant_7 : Space{});
    Space v1588_12;
    if (!v1588_10.empty()) {
      const Path v1593_6 = concat_path(p0,v1587_11_head);
      Space v1593_11_result;
      for (int v1593_11_label = 1; v1593_11_label <= 2; ++v1593_11_label) {
        const Space v1593_11_tail = child(v1587_11_tail,v1593_11_label);
        if (v1593_11_tail.empty()) continue;
        const Path v1593_11_head{v1593_11_label};
        const Space v1594_2 = singleton(v1593_11_head);
        const Space v1594_3 = intersect(constant_5,v1594_2);
        const Space v1594_4 = (has_head(v1594_3) ? constant_7 : Space{});
        const Space v1594_5 = subtract(constant_0,v1594_4);
        Space v1594_8;
        if (!v1594_5.empty()) {
          const Path v1595_6 = concat_path(v1593_6,v1593_11_head);
          const Space v1595_7 = routine_212(c, v1595_6, v1593_11_tail);
          v1594_8 = compose(v1594_5,v1595_7);
        }
        const Space v1594_9 = intersect(constant_5,v1594_2);
        const Space v1594_10 = (has_head(v1594_9) ? constant_7 : Space{});
        Space v1594_12;
        if (!v1594_10.empty()) {
          const Path v1596_6 = concat_path(v1593_6,v1593_11_head);
          const Space v1596_11 = routine_101(c, v1596_6, v1593_11_tail);
          v1594_12 = compose(v1594_10,v1596_11);
        }
        const Space v1594_13 = unite(v1594_8,v1594_12);
        v1593_11_result = unite(v1593_11_result,v1594_13);
      }
      const Space v1593_11 = std::move(v1593_11_result);
      v1588_12 = compose(v1588_10,v1593_11);
    }
    const Space v1588_13 = unite(v1588_8,v1588_12);
    v1587_11_result = unite(v1587_11_result,v1588_13);
  }
  const Space v1587_11 = std::move(v1587_11_result);
  return v1587_11;
}

static Space routine_181(Context& c, const Path& p0, const Space& s0) {
  Space v1597_8_result;
  for (int v1597_8_label = 1; v1597_8_label <= 2; ++v1597_8_label) {
    const Space v1597_8_tail = child(s0,v1597_8_label);
    if (v1597_8_tail.empty()) continue;
    const Path v1597_8_head{v1597_8_label};
    const Space v1598_2 = singleton(v1597_8_head);
    const Space v1598_3 = intersect(constant_5,v1598_2);
    const Space v1598_4 = (has_head(v1598_3) ? constant_7 : Space{});
    const Space v1598_5 = subtract(constant_0,v1598_4);
    Space v1598_8;
    if (!v1598_5.empty()) {
      const Path v1599_6 = concat_path(p0,v1597_8_head);
      Space v1599_7_result;
      for (int v1599_7_label = 1; v1599_7_label <= 2; ++v1599_7_label) {
        const Space v1599_7_tail = child(v1597_8_tail,v1599_7_label);
        if (v1599_7_tail.empty()) continue;
        const Path v1599_7_head{v1599_7_label};
        const Space v1600_2 = singleton(v1599_7_head);
        const Space v1600_3 = intersect(constant_5,v1600_2);
        const Space v1600_4 = (has_head(v1600_3) ? constant_7 : Space{});
        const Space v1600_5 = subtract(constant_0,v1600_4);
        Space v1600_8;
        if (!v1600_5.empty()) {
          const Path v1601_6 = concat_path(v1599_6,v1599_7_head);
          const Space v1601_7 = routine_212(c, v1601_6, v1599_7_tail);
          v1600_8 = compose(v1600_5,v1601_7);
        }
        const Space v1600_9 = intersect(constant_5,v1600_2);
        const Space v1600_10 = (has_head(v1600_9) ? constant_7 : Space{});
        Space v1600_12;
        if (!v1600_10.empty()) {
          const Path v1602_6 = concat_path(v1599_6,v1599_7_head);
          const Space v1602_11 = routine_213(c, v1602_6, v1599_7_tail);
          v1600_12 = compose(v1600_10,v1602_11);
        }
        const Space v1600_13 = unite(v1600_8,v1600_12);
        v1599_7_result = unite(v1599_7_result,v1600_13);
      }
      const Space v1599_7 = std::move(v1599_7_result);
      v1598_8 = compose(v1598_5,v1599_7);
    }
    const Space v1598_9 = intersect(constant_5,v1598_2);
    const Space v1598_10 = (has_head(v1598_9) ? constant_7 : Space{});
    const Space v1598_11 = compose(v1598_10,v1597_8_tail);
    const Space v1598_12 = unite(v1598_8,v1598_11);
    v1597_8_result = unite(v1597_8_result,v1598_12);
  }
  const Space v1597_8 = std::move(v1597_8_result);
  return v1597_8;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1603_6_result;
  for (int v1603_6_label = 1; v1603_6_label <= 2; ++v1603_6_label) {
    const Space v1603_6_tail = child(s0,v1603_6_label);
    if (v1603_6_tail.empty()) continue;
    const Path v1603_6_head{v1603_6_label};
    const Space v1604_2 = singleton(v1603_6_head);
    const Space v1604_3 = intersect(constant_5,v1604_2);
    const Space v1604_4 = (has_head(v1604_3) ? constant_7 : Space{});
    Space v1604_7;
    if (!v1604_4.empty()) {
      const Path v1605_5 = concat_path(p0,v1603_6_head);
      Space v1605_6_result;
      for (int v1605_6_label = 1; v1605_6_label <= 2; ++v1605_6_label) {
        const Space v1605_6_tail = child(v1603_6_tail,v1605_6_label);
        if (v1605_6_tail.empty()) continue;
        const Path v1605_6_head{v1605_6_label};
        const Space v1606_2 = singleton(v1605_6_head);
        const Space v1606_3 = intersect(constant_5,v1606_2);
        const Space v1606_4 = (has_head(v1606_3) ? constant_7 : Space{});
        Space v1606_7;
        if (!v1606_4.empty()) {
          const Path v1607_5 = concat_path(v1605_5,v1605_6_head);
          const Space v1607_6 = routine_48(c, v1607_5, p1, v1605_6_tail, s1);
          v1606_7 = compose(v1606_4,v1607_6);
        }
        v1605_6_result = unite(v1605_6_result,v1606_7);
      }
      const Space v1605_6 = std::move(v1605_6_result);
      v1604_7 = compose(v1604_4,v1605_6);
    }
    v1603_6_result = unite(v1603_6_result,v1604_7);
  }
  const Space v1603_6 = std::move(v1603_6_result);
  return v1603_6;
}

static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1608_6 = unwrap(constant_9,p1);
  const Space v1608_8 = unwrap(constant_9,p0);
  const Space v1608_10 = unwrap(s1,constant_8);
  const Space v1608_12 = unwrap(constant_9,p1);
  const Space v1608_14 = unwrap(constant_9,p0);
  Space v1608_24_result;
  for (int v1608_24_label = 1; v1608_24_label <= 2; ++v1608_24_label) {
    const Space v1608_24_tail = child(s0,v1608_24_label);
    if (v1608_24_tail.empty()) continue;
    const Path v1608_24_head{v1608_24_label};
    const Space v1609_2 = singleton(v1608_24_head);
    const Space v1609_3 = intersect(constant_5,v1609_2);
    const Space v1609_4 = (has_head(v1609_3) ? constant_7 : Space{});
    Space v1609_23;
    if (!v1609_4.empty()) {
      const Space v1610_5 = unwrap(v1608_8,v1608_24_head);
      const Space v1610_6 = compose(v1608_6,v1610_5);
      const Path v1610_7 = concat_path(p0,v1608_24_head);
      const Path v1610_8 = concat_path(p1,v1610_7);
      const Space v1610_9 = singleton(v1610_8);
      const Space v1610_10 = subtract(v1610_6,v1610_9);
      const Space v1610_11 = intersect(v1610_10,v1608_10);
      const Space v1610_12 = routine_51(c, v1610_11);
      Space v1610_13_result;
      for (int v1610_13_label = 1; v1610_13_label <= 2; ++v1610_13_label) {
        const Space v1610_13_tail = child(v1610_12,v1610_13_label);
        if (v1610_13_tail.empty()) continue;
        const Path v1610_13_head{v1610_13_label};
        const Space v1611_2 = singleton(v1610_13_head);
        const Space v1611_3 = intersect(constant_5,v1611_2);
        const Space v1611_4 = (has_head(v1611_3) ? constant_7 : Space{});
        const Space v1611_5 = subtract(constant_0,v1611_4);
        Space v1611_7;
        if (!v1611_5.empty()) {
          const Space v1612_6 = routine_52(c, v1610_13_head, v1610_13_tail);
          v1611_7 = compose(v1611_5,v1612_6);
        }
        const Space v1611_8 = intersect(constant_5,v1611_2);
        const Space v1611_9 = (has_head(v1611_8) ? constant_7 : Space{});
        Space v1611_11;
        if (!v1611_9.empty()) {
          const Space v1613_10 = routine_53(c, v1610_13_head, v1610_13_tail);
          v1611_11 = compose(v1611_9,v1613_10);
        }
        const Space v1611_12 = unite(v1611_7,v1611_11);
        v1610_13_result = unite(v1610_13_result,v1611_12);
      }
      const Space v1610_13 = std::move(v1610_13_result);
      const Space v1610_14 = unwrap(v1608_14,v1608_24_head);
      const Space v1610_15 = compose(v1608_12,v1610_14);
      const Space v1610_16 = subtract(v1610_15,v1610_9);
      const Space v1610_17 = intersect(v1610_16,v1608_10);
      const Space v1610_18 = routine_36(c, v1610_17);
      Space v1610_19_result;
      for (int v1610_19_label = 1; v1610_19_label <= 2; ++v1610_19_label) {
        const Space v1610_19_tail = child(v1610_18,v1610_19_label);
        if (v1610_19_tail.empty()) continue;
        const Path v1610_19_head{v1610_19_label};
        const Space v1614_2 = singleton(v1610_19_head);
        const Space v1614_3 = intersect(constant_5,v1614_2);
        const Space v1614_4 = (has_head(v1614_3) ? constant_7 : Space{});
        const Space v1614_5 = subtract(constant_0,v1614_4);
        Space v1614_7;
        if (!v1614_5.empty()) {
          const Space v1615_6 = routine_54(c, v1610_19_head, v1610_19_tail);
          v1614_7 = compose(v1614_5,v1615_6);
        }
        const Space v1614_8 = intersect(constant_5,v1614_2);
        const Space v1614_9 = (has_head(v1614_8) ? constant_7 : Space{});
        Space v1614_11;
        if (!v1614_9.empty()) {
          const Space v1616_10 = routine_55(c, v1610_19_head, v1610_19_tail);
          v1614_11 = compose(v1614_9,v1616_10);
        }
        const Space v1614_12 = unite(v1614_7,v1614_11);
        v1610_19_result = unite(v1610_19_result,v1614_12);
      }
      const Space v1610_19 = std::move(v1610_19_result);
      const Space v1610_20 = subtract(v1610_13,v1610_19);
      const Space v1610_21 = compose(v1610_20,v1610_9);
      Space v1610_22_result;
      for (int v1610_22_label = 1; v1610_22_label <= 2; ++v1610_22_label) {
        const Space v1610_22_tail = child(v1610_21,v1610_22_label);
        if (v1610_22_tail.empty()) continue;
        const Path v1610_22_head{v1610_22_label};
        const Space v1617_2 = singleton(v1610_22_head);
        const Space v1617_3 = intersect(constant_5,v1617_2);
        const Space v1617_4 = (has_head(v1617_3) ? constant_7 : Space{});
        const Space v1617_5 = subtract(constant_0,v1617_4);
        Space v1617_7;
        if (!v1617_5.empty()) {
          const Space v1618_6 = routine_56(c, v1610_22_head, v1610_22_tail);
          v1617_7 = compose(v1617_5,v1618_6);
        }
        const Space v1617_8 = intersect(constant_5,v1617_2);
        const Space v1617_9 = (has_head(v1617_8) ? constant_7 : Space{});
        Space v1617_11;
        if (!v1617_9.empty()) {
          const Space v1619_10 = routine_57(c, v1610_22_head, v1610_22_tail);
          v1617_11 = compose(v1617_9,v1619_10);
        }
        const Space v1617_12 = unite(v1617_7,v1617_11);
        v1610_22_result = unite(v1610_22_result,v1617_12);
      }
      const Space v1610_22 = std::move(v1610_22_result);
      v1609_23 = compose(v1609_4,v1610_22);
    }
    v1608_24_result = unite(v1608_24_result,v1609_23);
  }
  const Space v1608_24 = std::move(v1608_24_result);
  return v1608_24;
}

static Space routine_184(Context& c, const Path& p0, const Space& s0) {
  Space v1620_11_result;
  for (int v1620_11_label = 1; v1620_11_label <= 2; ++v1620_11_label) {
    const Space v1620_11_tail = child(s0,v1620_11_label);
    if (v1620_11_tail.empty()) continue;
    const Path v1620_11_head{v1620_11_label};
    const Space v1621_2 = singleton(v1620_11_head);
    const Space v1621_3 = intersect(constant_5,v1621_2);
    const Space v1621_4 = (has_head(v1621_3) ? constant_7 : Space{});
    const Space v1621_5 = subtract(constant_0,v1621_4);
    Space v1621_8;
    if (!v1621_5.empty()) {
      const Path v1622_6 = concat_path(p0,v1620_11_head);
      Space v1622_7_result;
      for (int v1622_7_label = 1; v1622_7_label <= 2; ++v1622_7_label) {
        const Space v1622_7_tail = child(v1620_11_tail,v1622_7_label);
        if (v1622_7_tail.empty()) continue;
        const Path v1622_7_head{v1622_7_label};
        const Space v1623_2 = singleton(v1622_7_head);
        const Space v1623_3 = intersect(constant_5,v1623_2);
        const Space v1623_4 = (has_head(v1623_3) ? constant_7 : Space{});
        const Space v1623_5 = subtract(constant_0,v1623_4);
        Space v1623_8;
        if (!v1623_5.empty()) {
          const Path v1624_6 = concat_path(v1622_6,v1622_7_head);
          const Space v1624_7 = routine_214(c, v1624_6, v1622_7_tail);
          v1623_8 = compose(v1623_5,v1624_7);
        }
        const Space v1623_9 = intersect(constant_5,v1623_2);
        const Space v1623_10 = (has_head(v1623_9) ? constant_7 : Space{});
        Space v1623_12;
        if (!v1623_10.empty()) {
          const Path v1625_6 = concat_path(v1622_6,v1622_7_head);
          const Space v1625_11 = routine_215(c, v1625_6, v1622_7_tail);
          v1623_12 = compose(v1623_10,v1625_11);
        }
        const Space v1623_13 = unite(v1623_8,v1623_12);
        v1622_7_result = unite(v1622_7_result,v1623_13);
      }
      const Space v1622_7 = std::move(v1622_7_result);
      v1621_8 = compose(v1621_5,v1622_7);
    }
    const Space v1621_9 = intersect(constant_5,v1621_2);
    const Space v1621_10 = (has_head(v1621_9) ? constant_7 : Space{});
    Space v1621_12;
    if (!v1621_10.empty()) {
      const Path v1626_6 = concat_path(p0,v1620_11_head);
      Space v1626_11_result;
      for (int v1626_11_label = 1; v1626_11_label <= 2; ++v1626_11_label) {
        const Space v1626_11_tail = child(v1620_11_tail,v1626_11_label);
        if (v1626_11_tail.empty()) continue;
        const Path v1626_11_head{v1626_11_label};
        const Space v1627_2 = singleton(v1626_11_head);
        const Space v1627_3 = intersect(constant_5,v1627_2);
        const Space v1627_4 = (has_head(v1627_3) ? constant_7 : Space{});
        const Space v1627_5 = subtract(constant_0,v1627_4);
        Space v1627_8;
        if (!v1627_5.empty()) {
          const Path v1628_6 = concat_path(v1626_6,v1626_11_head);
          const Space v1628_7 = routine_214(c, v1628_6, v1626_11_tail);
          v1627_8 = compose(v1627_5,v1628_7);
        }
        const Space v1627_9 = intersect(constant_5,v1627_2);
        const Space v1627_10 = (has_head(v1627_9) ? constant_7 : Space{});
        Space v1627_12;
        if (!v1627_10.empty()) {
          const Path v1629_6 = concat_path(v1626_6,v1626_11_head);
          const Space v1629_11 = routine_95(c, v1629_6, v1626_11_tail);
          v1627_12 = compose(v1627_10,v1629_11);
        }
        const Space v1627_13 = unite(v1627_8,v1627_12);
        v1626_11_result = unite(v1626_11_result,v1627_13);
      }
      const Space v1626_11 = std::move(v1626_11_result);
      v1621_12 = compose(v1621_10,v1626_11);
    }
    const Space v1621_13 = unite(v1621_8,v1621_12);
    v1620_11_result = unite(v1620_11_result,v1621_13);
  }
  const Space v1620_11 = std::move(v1620_11_result);
  return v1620_11;
}

static Space routine_185(Context& c, const Path& p0, const Space& s0) {
  Space v1630_9_result;
  for (int v1630_9_label = 1; v1630_9_label <= 2; ++v1630_9_label) {
    const Space v1630_9_tail = child(s0,v1630_9_label);
    if (v1630_9_tail.empty()) continue;
    const Path v1630_9_head{v1630_9_label};
    const Space v1631_2 = singleton(v1630_9_head);
    const Space v1631_3 = intersect(constant_5,v1631_2);
    const Space v1631_4 = (has_head(v1631_3) ? constant_7 : Space{});
    const Space v1631_5 = subtract(constant_0,v1631_4);
    Space v1631_8;
    if (!v1631_5.empty()) {
      const Path v1632_6 = concat_path(p0,v1630_9_head);
      Space v1632_7_result;
      for (int v1632_7_label = 1; v1632_7_label <= 2; ++v1632_7_label) {
        const Space v1632_7_tail = child(v1630_9_tail,v1632_7_label);
        if (v1632_7_tail.empty()) continue;
        const Path v1632_7_head{v1632_7_label};
        const Space v1633_2 = singleton(v1632_7_head);
        const Space v1633_3 = intersect(constant_5,v1633_2);
        const Space v1633_4 = (has_head(v1633_3) ? constant_7 : Space{});
        const Space v1633_5 = subtract(constant_0,v1633_4);
        Space v1633_8;
        if (!v1633_5.empty()) {
          const Path v1634_6 = concat_path(v1632_6,v1632_7_head);
          const Space v1634_7 = routine_214(c, v1634_6, v1632_7_tail);
          v1633_8 = compose(v1633_5,v1634_7);
        }
        const Space v1633_9 = intersect(constant_5,v1633_2);
        const Space v1633_10 = (has_head(v1633_9) ? constant_7 : Space{});
        Space v1633_12;
        if (!v1633_10.empty()) {
          const Path v1635_6 = concat_path(v1632_6,v1632_7_head);
          const Space v1635_11 = routine_215(c, v1635_6, v1632_7_tail);
          v1633_12 = compose(v1633_10,v1635_11);
        }
        const Space v1633_13 = unite(v1633_8,v1633_12);
        v1632_7_result = unite(v1632_7_result,v1633_13);
      }
      const Space v1632_7 = std::move(v1632_7_result);
      v1631_8 = compose(v1631_5,v1632_7);
    }
    const Space v1631_9 = intersect(constant_5,v1631_2);
    const Space v1631_10 = (has_head(v1631_9) ? constant_7 : Space{});
    const Space v1631_11 = compose(v1631_10,constant_10);
    const Space v1631_12 = unite(v1631_8,v1631_11);
    v1630_9_result = unite(v1630_9_result,v1631_12);
  }
  const Space v1630_9 = std::move(v1630_9_result);
  return v1630_9;
}

static Space routine_186(Context& c, const Path& p0, const Space& s0) {
  Space v1636_11_result;
  for (int v1636_11_label = 1; v1636_11_label <= 2; ++v1636_11_label) {
    const Space v1636_11_tail = child(s0,v1636_11_label);
    if (v1636_11_tail.empty()) continue;
    const Path v1636_11_head{v1636_11_label};
    const Space v1637_2 = singleton(v1636_11_head);
    const Space v1637_3 = intersect(constant_5,v1637_2);
    const Space v1637_4 = (has_head(v1637_3) ? constant_7 : Space{});
    const Space v1637_5 = subtract(constant_0,v1637_4);
    Space v1637_8;
    if (!v1637_5.empty()) {
      const Path v1638_6 = concat_path(p0,v1636_11_head);
      Space v1638_7_result;
      for (int v1638_7_label = 1; v1638_7_label <= 2; ++v1638_7_label) {
        const Space v1638_7_tail = child(v1636_11_tail,v1638_7_label);
        if (v1638_7_tail.empty()) continue;
        const Path v1638_7_head{v1638_7_label};
        const Space v1639_2 = singleton(v1638_7_head);
        const Space v1639_3 = intersect(constant_5,v1639_2);
        const Space v1639_4 = (has_head(v1639_3) ? constant_7 : Space{});
        const Space v1639_5 = subtract(constant_0,v1639_4);
        Space v1639_8;
        if (!v1639_5.empty()) {
          const Path v1640_6 = concat_path(v1638_6,v1638_7_head);
          const Space v1640_7 = routine_216(c, v1640_6, v1638_7_tail);
          v1639_8 = compose(v1639_5,v1640_7);
        }
        const Space v1639_9 = intersect(constant_5,v1639_2);
        const Space v1639_10 = (has_head(v1639_9) ? constant_7 : Space{});
        Space v1639_12;
        if (!v1639_10.empty()) {
          const Path v1641_6 = concat_path(v1638_6,v1638_7_head);
          const Space v1641_11 = routine_217(c, v1641_6, v1638_7_tail);
          v1639_12 = compose(v1639_10,v1641_11);
        }
        const Space v1639_13 = unite(v1639_8,v1639_12);
        v1638_7_result = unite(v1638_7_result,v1639_13);
      }
      const Space v1638_7 = std::move(v1638_7_result);
      v1637_8 = compose(v1637_5,v1638_7);
    }
    const Space v1637_9 = intersect(constant_5,v1637_2);
    const Space v1637_10 = (has_head(v1637_9) ? constant_7 : Space{});
    Space v1637_12;
    if (!v1637_10.empty()) {
      const Path v1642_6 = concat_path(p0,v1636_11_head);
      Space v1642_11_result;
      for (int v1642_11_label = 1; v1642_11_label <= 2; ++v1642_11_label) {
        const Space v1642_11_tail = child(v1636_11_tail,v1642_11_label);
        if (v1642_11_tail.empty()) continue;
        const Path v1642_11_head{v1642_11_label};
        const Space v1643_2 = singleton(v1642_11_head);
        const Space v1643_3 = intersect(constant_5,v1643_2);
        const Space v1643_4 = (has_head(v1643_3) ? constant_7 : Space{});
        const Space v1643_5 = subtract(constant_0,v1643_4);
        Space v1643_8;
        if (!v1643_5.empty()) {
          const Path v1644_6 = concat_path(v1642_6,v1642_11_head);
          const Space v1644_7 = routine_216(c, v1644_6, v1642_11_tail);
          v1643_8 = compose(v1643_5,v1644_7);
        }
        const Space v1643_9 = intersect(constant_5,v1643_2);
        const Space v1643_10 = (has_head(v1643_9) ? constant_7 : Space{});
        Space v1643_12;
        if (!v1643_10.empty()) {
          const Path v1645_6 = concat_path(v1642_6,v1642_11_head);
          const Space v1645_11 = routine_98(c, v1645_6, v1642_11_tail);
          v1643_12 = compose(v1643_10,v1645_11);
        }
        const Space v1643_13 = unite(v1643_8,v1643_12);
        v1642_11_result = unite(v1642_11_result,v1643_13);
      }
      const Space v1642_11 = std::move(v1642_11_result);
      v1637_12 = compose(v1637_10,v1642_11);
    }
    const Space v1637_13 = unite(v1637_8,v1637_12);
    v1636_11_result = unite(v1636_11_result,v1637_13);
  }
  const Space v1636_11 = std::move(v1636_11_result);
  return v1636_11;
}

static Space routine_187(Context& c, const Path& p0, const Space& s0) {
  Space v1646_9_result;
  for (int v1646_9_label = 1; v1646_9_label <= 2; ++v1646_9_label) {
    const Space v1646_9_tail = child(s0,v1646_9_label);
    if (v1646_9_tail.empty()) continue;
    const Path v1646_9_head{v1646_9_label};
    const Space v1647_2 = singleton(v1646_9_head);
    const Space v1647_3 = intersect(constant_5,v1647_2);
    const Space v1647_4 = (has_head(v1647_3) ? constant_7 : Space{});
    const Space v1647_5 = subtract(constant_0,v1647_4);
    Space v1647_8;
    if (!v1647_5.empty()) {
      const Path v1648_6 = concat_path(p0,v1646_9_head);
      Space v1648_7_result;
      for (int v1648_7_label = 1; v1648_7_label <= 2; ++v1648_7_label) {
        const Space v1648_7_tail = child(v1646_9_tail,v1648_7_label);
        if (v1648_7_tail.empty()) continue;
        const Path v1648_7_head{v1648_7_label};
        const Space v1649_2 = singleton(v1648_7_head);
        const Space v1649_3 = intersect(constant_5,v1649_2);
        const Space v1649_4 = (has_head(v1649_3) ? constant_7 : Space{});
        const Space v1649_5 = subtract(constant_0,v1649_4);
        Space v1649_8;
        if (!v1649_5.empty()) {
          const Path v1650_6 = concat_path(v1648_6,v1648_7_head);
          const Space v1650_7 = routine_216(c, v1650_6, v1648_7_tail);
          v1649_8 = compose(v1649_5,v1650_7);
        }
        const Space v1649_9 = intersect(constant_5,v1649_2);
        const Space v1649_10 = (has_head(v1649_9) ? constant_7 : Space{});
        Space v1649_12;
        if (!v1649_10.empty()) {
          const Path v1651_6 = concat_path(v1648_6,v1648_7_head);
          const Space v1651_11 = routine_217(c, v1651_6, v1648_7_tail);
          v1649_12 = compose(v1649_10,v1651_11);
        }
        const Space v1649_13 = unite(v1649_8,v1649_12);
        v1648_7_result = unite(v1648_7_result,v1649_13);
      }
      const Space v1648_7 = std::move(v1648_7_result);
      v1647_8 = compose(v1647_5,v1648_7);
    }
    const Space v1647_9 = intersect(constant_5,v1647_2);
    const Space v1647_10 = (has_head(v1647_9) ? constant_7 : Space{});
    const Space v1647_11 = compose(v1647_10,constant_10);
    const Space v1647_12 = unite(v1647_8,v1647_11);
    v1646_9_result = unite(v1646_9_result,v1647_12);
  }
  const Space v1646_9 = std::move(v1646_9_result);
  return v1646_9;
}

static Space routine_188(Context& c, const Path& p0, const Space& s0) {
  Space v1652_11_result;
  for (int v1652_11_label = 1; v1652_11_label <= 2; ++v1652_11_label) {
    const Space v1652_11_tail = child(s0,v1652_11_label);
    if (v1652_11_tail.empty()) continue;
    const Path v1652_11_head{v1652_11_label};
    const Space v1653_2 = singleton(v1652_11_head);
    const Space v1653_3 = intersect(constant_5,v1653_2);
    const Space v1653_4 = (has_head(v1653_3) ? constant_7 : Space{});
    const Space v1653_5 = subtract(constant_0,v1653_4);
    Space v1653_8;
    if (!v1653_5.empty()) {
      const Path v1654_6 = concat_path(p0,v1652_11_head);
      Space v1654_7_result;
      for (int v1654_7_label = 1; v1654_7_label <= 2; ++v1654_7_label) {
        const Space v1654_7_tail = child(v1652_11_tail,v1654_7_label);
        if (v1654_7_tail.empty()) continue;
        const Path v1654_7_head{v1654_7_label};
        const Space v1655_2 = singleton(v1654_7_head);
        const Space v1655_3 = intersect(constant_5,v1655_2);
        const Space v1655_4 = (has_head(v1655_3) ? constant_7 : Space{});
        const Space v1655_5 = subtract(constant_0,v1655_4);
        Space v1655_8;
        if (!v1655_5.empty()) {
          const Path v1656_6 = concat_path(v1654_6,v1654_7_head);
          const Space v1656_7 = routine_218(c, v1656_6, v1654_7_tail);
          v1655_8 = compose(v1655_5,v1656_7);
        }
        const Space v1655_9 = intersect(constant_5,v1655_2);
        const Space v1655_10 = (has_head(v1655_9) ? constant_7 : Space{});
        Space v1655_12;
        if (!v1655_10.empty()) {
          const Path v1657_6 = concat_path(v1654_6,v1654_7_head);
          const Space v1657_11 = routine_219(c, v1657_6, v1654_7_tail);
          v1655_12 = compose(v1655_10,v1657_11);
        }
        const Space v1655_13 = unite(v1655_8,v1655_12);
        v1654_7_result = unite(v1654_7_result,v1655_13);
      }
      const Space v1654_7 = std::move(v1654_7_result);
      v1653_8 = compose(v1653_5,v1654_7);
    }
    const Space v1653_9 = intersect(constant_5,v1653_2);
    const Space v1653_10 = (has_head(v1653_9) ? constant_7 : Space{});
    Space v1653_12;
    if (!v1653_10.empty()) {
      const Path v1658_6 = concat_path(p0,v1652_11_head);
      Space v1658_11_result;
      for (int v1658_11_label = 1; v1658_11_label <= 2; ++v1658_11_label) {
        const Space v1658_11_tail = child(v1652_11_tail,v1658_11_label);
        if (v1658_11_tail.empty()) continue;
        const Path v1658_11_head{v1658_11_label};
        const Space v1659_2 = singleton(v1658_11_head);
        const Space v1659_3 = intersect(constant_5,v1659_2);
        const Space v1659_4 = (has_head(v1659_3) ? constant_7 : Space{});
        const Space v1659_5 = subtract(constant_0,v1659_4);
        Space v1659_8;
        if (!v1659_5.empty()) {
          const Path v1660_6 = concat_path(v1658_6,v1658_11_head);
          const Space v1660_7 = routine_218(c, v1660_6, v1658_11_tail);
          v1659_8 = compose(v1659_5,v1660_7);
        }
        const Space v1659_9 = intersect(constant_5,v1659_2);
        const Space v1659_10 = (has_head(v1659_9) ? constant_7 : Space{});
        Space v1659_12;
        if (!v1659_10.empty()) {
          const Path v1661_6 = concat_path(v1658_6,v1658_11_head);
          const Space v1661_11 = routine_101(c, v1661_6, v1658_11_tail);
          v1659_12 = compose(v1659_10,v1661_11);
        }
        const Space v1659_13 = unite(v1659_8,v1659_12);
        v1658_11_result = unite(v1658_11_result,v1659_13);
      }
      const Space v1658_11 = std::move(v1658_11_result);
      v1653_12 = compose(v1653_10,v1658_11);
    }
    const Space v1653_13 = unite(v1653_8,v1653_12);
    v1652_11_result = unite(v1652_11_result,v1653_13);
  }
  const Space v1652_11 = std::move(v1652_11_result);
  return v1652_11;
}

static Space routine_189(Context& c, const Path& p0, const Space& s0) {
  Space v1662_8_result;
  for (int v1662_8_label = 1; v1662_8_label <= 2; ++v1662_8_label) {
    const Space v1662_8_tail = child(s0,v1662_8_label);
    if (v1662_8_tail.empty()) continue;
    const Path v1662_8_head{v1662_8_label};
    const Space v1663_2 = singleton(v1662_8_head);
    const Space v1663_3 = intersect(constant_5,v1663_2);
    const Space v1663_4 = (has_head(v1663_3) ? constant_7 : Space{});
    const Space v1663_5 = subtract(constant_0,v1663_4);
    Space v1663_8;
    if (!v1663_5.empty()) {
      const Path v1664_6 = concat_path(p0,v1662_8_head);
      Space v1664_7_result;
      for (int v1664_7_label = 1; v1664_7_label <= 2; ++v1664_7_label) {
        const Space v1664_7_tail = child(v1662_8_tail,v1664_7_label);
        if (v1664_7_tail.empty()) continue;
        const Path v1664_7_head{v1664_7_label};
        const Space v1665_2 = singleton(v1664_7_head);
        const Space v1665_3 = intersect(constant_5,v1665_2);
        const Space v1665_4 = (has_head(v1665_3) ? constant_7 : Space{});
        const Space v1665_5 = subtract(constant_0,v1665_4);
        Space v1665_8;
        if (!v1665_5.empty()) {
          const Path v1666_6 = concat_path(v1664_6,v1664_7_head);
          const Space v1666_7 = routine_218(c, v1666_6, v1664_7_tail);
          v1665_8 = compose(v1665_5,v1666_7);
        }
        const Space v1665_9 = intersect(constant_5,v1665_2);
        const Space v1665_10 = (has_head(v1665_9) ? constant_7 : Space{});
        Space v1665_12;
        if (!v1665_10.empty()) {
          const Path v1667_6 = concat_path(v1664_6,v1664_7_head);
          const Space v1667_11 = routine_219(c, v1667_6, v1664_7_tail);
          v1665_12 = compose(v1665_10,v1667_11);
        }
        const Space v1665_13 = unite(v1665_8,v1665_12);
        v1664_7_result = unite(v1664_7_result,v1665_13);
      }
      const Space v1664_7 = std::move(v1664_7_result);
      v1663_8 = compose(v1663_5,v1664_7);
    }
    const Space v1663_9 = intersect(constant_5,v1663_2);
    const Space v1663_10 = (has_head(v1663_9) ? constant_7 : Space{});
    const Space v1663_11 = compose(v1663_10,v1662_8_tail);
    const Space v1663_12 = unite(v1663_8,v1663_11);
    v1662_8_result = unite(v1662_8_result,v1663_12);
  }
  const Space v1662_8 = std::move(v1662_8_result);
  return v1662_8;
}

static Space routine_190(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1668_3 = Space{};
  return v1668_3;
}

static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1669_5 = unwrap(constant_9,p1);
  const Space v1669_7 = unwrap(constant_9,p0);
  Space v1669_8_result;
  for (int v1669_8_label = 1; v1669_8_label <= 2; ++v1669_8_label) {
    const Space v1669_8_tail = child(s0,v1669_8_label);
    if (v1669_8_tail.empty()) continue;
    const Path v1669_8_head{v1669_8_label};
    const Space v1670_2 = singleton(v1669_8_head);
    const Space v1670_3 = intersect(constant_5,v1670_2);
    const Space v1670_4 = (has_head(v1670_3) ? constant_7 : Space{});
    const Space v1670_5 = unwrap(v1669_7,v1669_8_head);
    const Space v1670_6 = compose(v1669_5,v1670_5);
    const Path v1670_7 = concat_path(p0,v1669_8_head);
    const Path v1670_8 = concat_path(p1,v1670_7);
    const Space v1670_9 = singleton(v1670_8);
    const Space v1670_10 = subtract(v1670_6,v1670_9);
    const Space v1670_11 = compose(v1670_4,v1670_10);
    v1669_8_result = unite(v1669_8_result,v1670_11);
  }
  const Space v1669_8 = std::move(v1669_8_result);
  return v1669_8;
}

static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1671_4 = Space{};
  return v1671_4;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1672_6 = unwrap(constant_9,p1);
  const Space v1672_8 = unwrap(constant_9,p0);
  const Space v1672_10 = unwrap(s1,constant_8);
  const Space v1672_12 = unwrap(constant_9,p1);
  const Space v1672_14 = unwrap(constant_9,p0);
  Space v1672_24_result;
  for (int v1672_24_label = 1; v1672_24_label <= 2; ++v1672_24_label) {
    const Space v1672_24_tail = child(s0,v1672_24_label);
    if (v1672_24_tail.empty()) continue;
    const Path v1672_24_head{v1672_24_label};
    const Space v1673_2 = singleton(v1672_24_head);
    const Space v1673_3 = intersect(constant_5,v1673_2);
    const Space v1673_4 = (has_head(v1673_3) ? constant_7 : Space{});
    Space v1673_23;
    if (!v1673_4.empty()) {
      const Space v1674_5 = unwrap(v1672_8,v1672_24_head);
      const Space v1674_6 = compose(v1672_6,v1674_5);
      const Path v1674_7 = concat_path(p0,v1672_24_head);
      const Path v1674_8 = concat_path(p1,v1674_7);
      const Space v1674_9 = singleton(v1674_8);
      const Space v1674_10 = subtract(v1674_6,v1674_9);
      const Space v1674_11 = intersect(v1674_10,v1672_10);
      const Space v1674_12 = routine_36(c, v1674_11);
      Space v1674_13_result;
      for (int v1674_13_label = 1; v1674_13_label <= 2; ++v1674_13_label) {
        const Space v1674_13_tail = child(v1674_12,v1674_13_label);
        if (v1674_13_tail.empty()) continue;
        const Path v1674_13_head{v1674_13_label};
        const Space v1675_2 = singleton(v1674_13_head);
        const Space v1675_3 = intersect(constant_5,v1675_2);
        const Space v1675_4 = (has_head(v1675_3) ? constant_7 : Space{});
        const Space v1675_5 = subtract(constant_0,v1675_4);
        Space v1675_7;
        if (!v1675_5.empty()) {
          const Space v1676_6 = routine_37(c, v1674_13_head, v1674_13_tail);
          v1675_7 = compose(v1675_5,v1676_6);
        }
        const Space v1675_8 = intersect(constant_5,v1675_2);
        const Space v1675_9 = (has_head(v1675_8) ? constant_7 : Space{});
        Space v1675_11;
        if (!v1675_9.empty()) {
          const Space v1677_10 = routine_38(c, v1674_13_head, v1674_13_tail);
          v1675_11 = compose(v1675_9,v1677_10);
        }
        const Space v1675_12 = unite(v1675_7,v1675_11);
        v1674_13_result = unite(v1674_13_result,v1675_12);
      }
      const Space v1674_13 = std::move(v1674_13_result);
      const Space v1674_14 = unwrap(v1672_14,v1672_24_head);
      const Space v1674_15 = compose(v1672_12,v1674_14);
      const Space v1674_16 = subtract(v1674_15,v1674_9);
      const Space v1674_17 = intersect(v1674_16,v1672_10);
      const Space v1674_18 = routine_39(c, v1674_17);
      Space v1674_19_result;
      for (int v1674_19_label = 1; v1674_19_label <= 2; ++v1674_19_label) {
        const Space v1674_19_tail = child(v1674_18,v1674_19_label);
        if (v1674_19_tail.empty()) continue;
        const Path v1674_19_head{v1674_19_label};
        const Space v1678_2 = singleton(v1674_19_head);
        const Space v1678_3 = intersect(constant_5,v1678_2);
        const Space v1678_4 = (has_head(v1678_3) ? constant_7 : Space{});
        const Space v1678_5 = subtract(constant_0,v1678_4);
        Space v1678_7;
        if (!v1678_5.empty()) {
          const Space v1679_6 = routine_40(c, v1674_19_head, v1674_19_tail);
          v1678_7 = compose(v1678_5,v1679_6);
        }
        const Space v1678_8 = intersect(constant_5,v1678_2);
        const Space v1678_9 = (has_head(v1678_8) ? constant_7 : Space{});
        Space v1678_11;
        if (!v1678_9.empty()) {
          const Space v1680_10 = routine_41(c, v1674_19_head, v1674_19_tail);
          v1678_11 = compose(v1678_9,v1680_10);
        }
        const Space v1678_12 = unite(v1678_7,v1678_11);
        v1674_19_result = unite(v1674_19_result,v1678_12);
      }
      const Space v1674_19 = std::move(v1674_19_result);
      const Space v1674_20 = subtract(v1674_13,v1674_19);
      const Space v1674_21 = compose(v1674_20,v1674_9);
      Space v1674_22_result;
      for (int v1674_22_label = 1; v1674_22_label <= 2; ++v1674_22_label) {
        const Space v1674_22_tail = child(v1674_21,v1674_22_label);
        if (v1674_22_tail.empty()) continue;
        const Path v1674_22_head{v1674_22_label};
        const Space v1681_2 = singleton(v1674_22_head);
        const Space v1681_3 = intersect(constant_5,v1681_2);
        const Space v1681_4 = (has_head(v1681_3) ? constant_7 : Space{});
        const Space v1681_5 = subtract(constant_0,v1681_4);
        Space v1681_7;
        if (!v1681_5.empty()) {
          const Space v1682_6 = routine_42(c, v1674_22_head, v1674_22_tail);
          v1681_7 = compose(v1681_5,v1682_6);
        }
        const Space v1681_8 = intersect(constant_5,v1681_2);
        const Space v1681_9 = (has_head(v1681_8) ? constant_7 : Space{});
        Space v1681_11;
        if (!v1681_9.empty()) {
          const Space v1683_10 = routine_43(c, v1674_22_head, v1674_22_tail);
          v1681_11 = compose(v1681_9,v1683_10);
        }
        const Space v1681_12 = unite(v1681_7,v1681_11);
        v1674_22_result = unite(v1674_22_result,v1681_12);
      }
      const Space v1674_22 = std::move(v1674_22_result);
      v1673_23 = compose(v1673_4,v1674_22);
    }
    v1672_24_result = unite(v1672_24_result,v1673_23);
  }
  const Space v1672_24 = std::move(v1672_24_result);
  return v1672_24;
}

static Space routine_194(Context& c, const Path& p0, const Space& s0) {
  Space v1684_11_result;
  for (int v1684_11_label = 1; v1684_11_label <= 2; ++v1684_11_label) {
    const Space v1684_11_tail = child(s0,v1684_11_label);
    if (v1684_11_tail.empty()) continue;
    const Path v1684_11_head{v1684_11_label};
    const Space v1685_2 = singleton(v1684_11_head);
    const Space v1685_3 = intersect(constant_5,v1685_2);
    const Space v1685_4 = (has_head(v1685_3) ? constant_7 : Space{});
    const Space v1685_5 = subtract(constant_0,v1685_4);
    Space v1685_8;
    if (!v1685_5.empty()) {
      const Path v1686_6 = concat_path(p0,v1684_11_head);
      Space v1686_7_result;
      for (int v1686_7_label = 1; v1686_7_label <= 2; ++v1686_7_label) {
        const Space v1686_7_tail = child(v1684_11_tail,v1686_7_label);
        if (v1686_7_tail.empty()) continue;
        const Path v1686_7_head{v1686_7_label};
        const Space v1687_2 = singleton(v1686_7_head);
        const Space v1687_3 = intersect(constant_5,v1687_2);
        const Space v1687_4 = (has_head(v1687_3) ? constant_7 : Space{});
        const Space v1687_5 = subtract(constant_0,v1687_4);
        Space v1687_8;
        if (!v1687_5.empty()) {
          const Path v1688_6 = concat_path(v1686_6,v1686_7_head);
          const Space v1688_7 = routine_220(c, v1688_6, v1686_7_tail);
          v1687_8 = compose(v1687_5,v1688_7);
        }
        const Space v1687_9 = intersect(constant_5,v1687_2);
        const Space v1687_10 = (has_head(v1687_9) ? constant_7 : Space{});
        Space v1687_12;
        if (!v1687_10.empty()) {
          const Path v1689_6 = concat_path(v1686_6,v1686_7_head);
          const Space v1689_11 = routine_221(c, v1689_6, v1686_7_tail);
          v1687_12 = compose(v1687_10,v1689_11);
        }
        const Space v1687_13 = unite(v1687_8,v1687_12);
        v1686_7_result = unite(v1686_7_result,v1687_13);
      }
      const Space v1686_7 = std::move(v1686_7_result);
      v1685_8 = compose(v1685_5,v1686_7);
    }
    const Space v1685_9 = intersect(constant_5,v1685_2);
    const Space v1685_10 = (has_head(v1685_9) ? constant_7 : Space{});
    Space v1685_12;
    if (!v1685_10.empty()) {
      const Path v1690_6 = concat_path(p0,v1684_11_head);
      Space v1690_11_result;
      for (int v1690_11_label = 1; v1690_11_label <= 2; ++v1690_11_label) {
        const Space v1690_11_tail = child(v1684_11_tail,v1690_11_label);
        if (v1690_11_tail.empty()) continue;
        const Path v1690_11_head{v1690_11_label};
        const Space v1691_2 = singleton(v1690_11_head);
        const Space v1691_3 = intersect(constant_5,v1691_2);
        const Space v1691_4 = (has_head(v1691_3) ? constant_7 : Space{});
        const Space v1691_5 = subtract(constant_0,v1691_4);
        Space v1691_8;
        if (!v1691_5.empty()) {
          const Path v1692_6 = concat_path(v1690_6,v1690_11_head);
          const Space v1692_7 = routine_220(c, v1692_6, v1690_11_tail);
          v1691_8 = compose(v1691_5,v1692_7);
        }
        const Space v1691_9 = intersect(constant_5,v1691_2);
        const Space v1691_10 = (has_head(v1691_9) ? constant_7 : Space{});
        Space v1691_12;
        if (!v1691_10.empty()) {
          const Path v1693_6 = concat_path(v1690_6,v1690_11_head);
          const Space v1693_11 = routine_72(c, v1693_6, v1690_11_tail);
          v1691_12 = compose(v1691_10,v1693_11);
        }
        const Space v1691_13 = unite(v1691_8,v1691_12);
        v1690_11_result = unite(v1690_11_result,v1691_13);
      }
      const Space v1690_11 = std::move(v1690_11_result);
      v1685_12 = compose(v1685_10,v1690_11);
    }
    const Space v1685_13 = unite(v1685_8,v1685_12);
    v1684_11_result = unite(v1684_11_result,v1685_13);
  }
  const Space v1684_11 = std::move(v1684_11_result);
  return v1684_11;
}

static Space routine_195(Context& c, const Path& p0, const Space& s0) {
  Space v1694_9_result;
  for (int v1694_9_label = 1; v1694_9_label <= 2; ++v1694_9_label) {
    const Space v1694_9_tail = child(s0,v1694_9_label);
    if (v1694_9_tail.empty()) continue;
    const Path v1694_9_head{v1694_9_label};
    const Space v1695_2 = singleton(v1694_9_head);
    const Space v1695_3 = intersect(constant_5,v1695_2);
    const Space v1695_4 = (has_head(v1695_3) ? constant_7 : Space{});
    const Space v1695_5 = subtract(constant_0,v1695_4);
    Space v1695_8;
    if (!v1695_5.empty()) {
      const Path v1696_6 = concat_path(p0,v1694_9_head);
      Space v1696_7_result;
      for (int v1696_7_label = 1; v1696_7_label <= 2; ++v1696_7_label) {
        const Space v1696_7_tail = child(v1694_9_tail,v1696_7_label);
        if (v1696_7_tail.empty()) continue;
        const Path v1696_7_head{v1696_7_label};
        const Space v1697_2 = singleton(v1696_7_head);
        const Space v1697_3 = intersect(constant_5,v1697_2);
        const Space v1697_4 = (has_head(v1697_3) ? constant_7 : Space{});
        const Space v1697_5 = subtract(constant_0,v1697_4);
        Space v1697_8;
        if (!v1697_5.empty()) {
          const Path v1698_6 = concat_path(v1696_6,v1696_7_head);
          const Space v1698_7 = routine_220(c, v1698_6, v1696_7_tail);
          v1697_8 = compose(v1697_5,v1698_7);
        }
        const Space v1697_9 = intersect(constant_5,v1697_2);
        const Space v1697_10 = (has_head(v1697_9) ? constant_7 : Space{});
        Space v1697_12;
        if (!v1697_10.empty()) {
          const Path v1699_6 = concat_path(v1696_6,v1696_7_head);
          const Space v1699_11 = routine_221(c, v1699_6, v1696_7_tail);
          v1697_12 = compose(v1697_10,v1699_11);
        }
        const Space v1697_13 = unite(v1697_8,v1697_12);
        v1696_7_result = unite(v1696_7_result,v1697_13);
      }
      const Space v1696_7 = std::move(v1696_7_result);
      v1695_8 = compose(v1695_5,v1696_7);
    }
    const Space v1695_9 = intersect(constant_5,v1695_2);
    const Space v1695_10 = (has_head(v1695_9) ? constant_7 : Space{});
    const Space v1695_11 = compose(v1695_10,constant_10);
    const Space v1695_12 = unite(v1695_8,v1695_11);
    v1694_9_result = unite(v1694_9_result,v1695_12);
  }
  const Space v1694_9 = std::move(v1694_9_result);
  return v1694_9;
}

static Space routine_196(Context& c, const Path& p0, const Space& s0) {
  Space v1700_11_result;
  for (int v1700_11_label = 1; v1700_11_label <= 2; ++v1700_11_label) {
    const Space v1700_11_tail = child(s0,v1700_11_label);
    if (v1700_11_tail.empty()) continue;
    const Path v1700_11_head{v1700_11_label};
    const Space v1701_2 = singleton(v1700_11_head);
    const Space v1701_3 = intersect(constant_5,v1701_2);
    const Space v1701_4 = (has_head(v1701_3) ? constant_7 : Space{});
    const Space v1701_5 = subtract(constant_0,v1701_4);
    Space v1701_8;
    if (!v1701_5.empty()) {
      const Path v1702_6 = concat_path(p0,v1700_11_head);
      Space v1702_7_result;
      for (int v1702_7_label = 1; v1702_7_label <= 2; ++v1702_7_label) {
        const Space v1702_7_tail = child(v1700_11_tail,v1702_7_label);
        if (v1702_7_tail.empty()) continue;
        const Path v1702_7_head{v1702_7_label};
        const Space v1703_2 = singleton(v1702_7_head);
        const Space v1703_3 = intersect(constant_5,v1703_2);
        const Space v1703_4 = (has_head(v1703_3) ? constant_7 : Space{});
        const Space v1703_5 = subtract(constant_0,v1703_4);
        Space v1703_8;
        if (!v1703_5.empty()) {
          const Path v1704_6 = concat_path(v1702_6,v1702_7_head);
          const Space v1704_7 = routine_222(c, v1704_6, v1702_7_tail);
          v1703_8 = compose(v1703_5,v1704_7);
        }
        const Space v1703_9 = intersect(constant_5,v1703_2);
        const Space v1703_10 = (has_head(v1703_9) ? constant_7 : Space{});
        Space v1703_12;
        if (!v1703_10.empty()) {
          const Path v1705_6 = concat_path(v1702_6,v1702_7_head);
          const Space v1705_11 = routine_223(c, v1705_6, v1702_7_tail);
          v1703_12 = compose(v1703_10,v1705_11);
        }
        const Space v1703_13 = unite(v1703_8,v1703_12);
        v1702_7_result = unite(v1702_7_result,v1703_13);
      }
      const Space v1702_7 = std::move(v1702_7_result);
      v1701_8 = compose(v1701_5,v1702_7);
    }
    const Space v1701_9 = intersect(constant_5,v1701_2);
    const Space v1701_10 = (has_head(v1701_9) ? constant_7 : Space{});
    Space v1701_12;
    if (!v1701_10.empty()) {
      const Path v1706_6 = concat_path(p0,v1700_11_head);
      Space v1706_11_result;
      for (int v1706_11_label = 1; v1706_11_label <= 2; ++v1706_11_label) {
        const Space v1706_11_tail = child(v1700_11_tail,v1706_11_label);
        if (v1706_11_tail.empty()) continue;
        const Path v1706_11_head{v1706_11_label};
        const Space v1707_2 = singleton(v1706_11_head);
        const Space v1707_3 = intersect(constant_5,v1707_2);
        const Space v1707_4 = (has_head(v1707_3) ? constant_7 : Space{});
        const Space v1707_5 = subtract(constant_0,v1707_4);
        Space v1707_8;
        if (!v1707_5.empty()) {
          const Path v1708_6 = concat_path(v1706_6,v1706_11_head);
          const Space v1708_7 = routine_222(c, v1708_6, v1706_11_tail);
          v1707_8 = compose(v1707_5,v1708_7);
        }
        const Space v1707_9 = intersect(constant_5,v1707_2);
        const Space v1707_10 = (has_head(v1707_9) ? constant_7 : Space{});
        Space v1707_12;
        if (!v1707_10.empty()) {
          const Path v1709_6 = concat_path(v1706_6,v1706_11_head);
          const Space v1709_11 = routine_76(c, v1709_6, v1706_11_tail);
          v1707_12 = compose(v1707_10,v1709_11);
        }
        const Space v1707_13 = unite(v1707_8,v1707_12);
        v1706_11_result = unite(v1706_11_result,v1707_13);
      }
      const Space v1706_11 = std::move(v1706_11_result);
      v1701_12 = compose(v1701_10,v1706_11);
    }
    const Space v1701_13 = unite(v1701_8,v1701_12);
    v1700_11_result = unite(v1700_11_result,v1701_13);
  }
  const Space v1700_11 = std::move(v1700_11_result);
  return v1700_11;
}

static Space routine_197(Context& c, const Path& p0, const Space& s0) {
  Space v1710_9_result;
  for (int v1710_9_label = 1; v1710_9_label <= 2; ++v1710_9_label) {
    const Space v1710_9_tail = child(s0,v1710_9_label);
    if (v1710_9_tail.empty()) continue;
    const Path v1710_9_head{v1710_9_label};
    const Space v1711_2 = singleton(v1710_9_head);
    const Space v1711_3 = intersect(constant_5,v1711_2);
    const Space v1711_4 = (has_head(v1711_3) ? constant_7 : Space{});
    const Space v1711_5 = subtract(constant_0,v1711_4);
    Space v1711_8;
    if (!v1711_5.empty()) {
      const Path v1712_6 = concat_path(p0,v1710_9_head);
      Space v1712_7_result;
      for (int v1712_7_label = 1; v1712_7_label <= 2; ++v1712_7_label) {
        const Space v1712_7_tail = child(v1710_9_tail,v1712_7_label);
        if (v1712_7_tail.empty()) continue;
        const Path v1712_7_head{v1712_7_label};
        const Space v1713_2 = singleton(v1712_7_head);
        const Space v1713_3 = intersect(constant_5,v1713_2);
        const Space v1713_4 = (has_head(v1713_3) ? constant_7 : Space{});
        const Space v1713_5 = subtract(constant_0,v1713_4);
        Space v1713_8;
        if (!v1713_5.empty()) {
          const Path v1714_6 = concat_path(v1712_6,v1712_7_head);
          const Space v1714_7 = routine_222(c, v1714_6, v1712_7_tail);
          v1713_8 = compose(v1713_5,v1714_7);
        }
        const Space v1713_9 = intersect(constant_5,v1713_2);
        const Space v1713_10 = (has_head(v1713_9) ? constant_7 : Space{});
        Space v1713_12;
        if (!v1713_10.empty()) {
          const Path v1715_6 = concat_path(v1712_6,v1712_7_head);
          const Space v1715_11 = routine_223(c, v1715_6, v1712_7_tail);
          v1713_12 = compose(v1713_10,v1715_11);
        }
        const Space v1713_13 = unite(v1713_8,v1713_12);
        v1712_7_result = unite(v1712_7_result,v1713_13);
      }
      const Space v1712_7 = std::move(v1712_7_result);
      v1711_8 = compose(v1711_5,v1712_7);
    }
    const Space v1711_9 = intersect(constant_5,v1711_2);
    const Space v1711_10 = (has_head(v1711_9) ? constant_7 : Space{});
    const Space v1711_11 = compose(v1711_10,constant_10);
    const Space v1711_12 = unite(v1711_8,v1711_11);
    v1710_9_result = unite(v1710_9_result,v1711_12);
  }
  const Space v1710_9 = std::move(v1710_9_result);
  return v1710_9;
}

static Space routine_198(Context& c, const Path& p0, const Space& s0) {
  Space v1716_11_result;
  for (int v1716_11_label = 1; v1716_11_label <= 2; ++v1716_11_label) {
    const Space v1716_11_tail = child(s0,v1716_11_label);
    if (v1716_11_tail.empty()) continue;
    const Path v1716_11_head{v1716_11_label};
    const Space v1717_2 = singleton(v1716_11_head);
    const Space v1717_3 = intersect(constant_5,v1717_2);
    const Space v1717_4 = (has_head(v1717_3) ? constant_7 : Space{});
    const Space v1717_5 = subtract(constant_0,v1717_4);
    Space v1717_8;
    if (!v1717_5.empty()) {
      const Path v1718_6 = concat_path(p0,v1716_11_head);
      Space v1718_7_result;
      for (int v1718_7_label = 1; v1718_7_label <= 2; ++v1718_7_label) {
        const Space v1718_7_tail = child(v1716_11_tail,v1718_7_label);
        if (v1718_7_tail.empty()) continue;
        const Path v1718_7_head{v1718_7_label};
        const Space v1719_2 = singleton(v1718_7_head);
        const Space v1719_3 = intersect(constant_5,v1719_2);
        const Space v1719_4 = (has_head(v1719_3) ? constant_7 : Space{});
        const Space v1719_5 = subtract(constant_0,v1719_4);
        Space v1719_8;
        if (!v1719_5.empty()) {
          const Path v1720_6 = concat_path(v1718_6,v1718_7_head);
          const Space v1720_7 = routine_224(c, v1720_6, v1718_7_tail);
          v1719_8 = compose(v1719_5,v1720_7);
        }
        const Space v1719_9 = intersect(constant_5,v1719_2);
        const Space v1719_10 = (has_head(v1719_9) ? constant_7 : Space{});
        Space v1719_12;
        if (!v1719_10.empty()) {
          const Path v1721_6 = concat_path(v1718_6,v1718_7_head);
          const Space v1721_11 = routine_225(c, v1721_6, v1718_7_tail);
          v1719_12 = compose(v1719_10,v1721_11);
        }
        const Space v1719_13 = unite(v1719_8,v1719_12);
        v1718_7_result = unite(v1718_7_result,v1719_13);
      }
      const Space v1718_7 = std::move(v1718_7_result);
      v1717_8 = compose(v1717_5,v1718_7);
    }
    const Space v1717_9 = intersect(constant_5,v1717_2);
    const Space v1717_10 = (has_head(v1717_9) ? constant_7 : Space{});
    Space v1717_12;
    if (!v1717_10.empty()) {
      const Path v1722_6 = concat_path(p0,v1716_11_head);
      Space v1722_11_result;
      for (int v1722_11_label = 1; v1722_11_label <= 2; ++v1722_11_label) {
        const Space v1722_11_tail = child(v1716_11_tail,v1722_11_label);
        if (v1722_11_tail.empty()) continue;
        const Path v1722_11_head{v1722_11_label};
        const Space v1723_2 = singleton(v1722_11_head);
        const Space v1723_3 = intersect(constant_5,v1723_2);
        const Space v1723_4 = (has_head(v1723_3) ? constant_7 : Space{});
        const Space v1723_5 = subtract(constant_0,v1723_4);
        Space v1723_8;
        if (!v1723_5.empty()) {
          const Path v1724_6 = concat_path(v1722_6,v1722_11_head);
          const Space v1724_7 = routine_224(c, v1724_6, v1722_11_tail);
          v1723_8 = compose(v1723_5,v1724_7);
        }
        const Space v1723_9 = intersect(constant_5,v1723_2);
        const Space v1723_10 = (has_head(v1723_9) ? constant_7 : Space{});
        Space v1723_12;
        if (!v1723_10.empty()) {
          const Path v1725_6 = concat_path(v1722_6,v1722_11_head);
          const Space v1725_11 = routine_79(c, v1725_6, v1722_11_tail);
          v1723_12 = compose(v1723_10,v1725_11);
        }
        const Space v1723_13 = unite(v1723_8,v1723_12);
        v1722_11_result = unite(v1722_11_result,v1723_13);
      }
      const Space v1722_11 = std::move(v1722_11_result);
      v1717_12 = compose(v1717_10,v1722_11);
    }
    const Space v1717_13 = unite(v1717_8,v1717_12);
    v1716_11_result = unite(v1716_11_result,v1717_13);
  }
  const Space v1716_11 = std::move(v1716_11_result);
  return v1716_11;
}

static Space routine_199(Context& c, const Path& p0, const Space& s0) {
  Space v1726_8_result;
  for (int v1726_8_label = 1; v1726_8_label <= 2; ++v1726_8_label) {
    const Space v1726_8_tail = child(s0,v1726_8_label);
    if (v1726_8_tail.empty()) continue;
    const Path v1726_8_head{v1726_8_label};
    const Space v1727_2 = singleton(v1726_8_head);
    const Space v1727_3 = intersect(constant_5,v1727_2);
    const Space v1727_4 = (has_head(v1727_3) ? constant_7 : Space{});
    const Space v1727_5 = subtract(constant_0,v1727_4);
    Space v1727_8;
    if (!v1727_5.empty()) {
      const Path v1728_6 = concat_path(p0,v1726_8_head);
      Space v1728_7_result;
      for (int v1728_7_label = 1; v1728_7_label <= 2; ++v1728_7_label) {
        const Space v1728_7_tail = child(v1726_8_tail,v1728_7_label);
        if (v1728_7_tail.empty()) continue;
        const Path v1728_7_head{v1728_7_label};
        const Space v1729_2 = singleton(v1728_7_head);
        const Space v1729_3 = intersect(constant_5,v1729_2);
        const Space v1729_4 = (has_head(v1729_3) ? constant_7 : Space{});
        const Space v1729_5 = subtract(constant_0,v1729_4);
        Space v1729_8;
        if (!v1729_5.empty()) {
          const Path v1730_6 = concat_path(v1728_6,v1728_7_head);
          const Space v1730_7 = routine_224(c, v1730_6, v1728_7_tail);
          v1729_8 = compose(v1729_5,v1730_7);
        }
        const Space v1729_9 = intersect(constant_5,v1729_2);
        const Space v1729_10 = (has_head(v1729_9) ? constant_7 : Space{});
        Space v1729_12;
        if (!v1729_10.empty()) {
          const Path v1731_6 = concat_path(v1728_6,v1728_7_head);
          const Space v1731_11 = routine_225(c, v1731_6, v1728_7_tail);
          v1729_12 = compose(v1729_10,v1731_11);
        }
        const Space v1729_13 = unite(v1729_8,v1729_12);
        v1728_7_result = unite(v1728_7_result,v1729_13);
      }
      const Space v1728_7 = std::move(v1728_7_result);
      v1727_8 = compose(v1727_5,v1728_7);
    }
    const Space v1727_9 = intersect(constant_5,v1727_2);
    const Space v1727_10 = (has_head(v1727_9) ? constant_7 : Space{});
    const Space v1727_11 = compose(v1727_10,v1726_8_tail);
    const Space v1727_12 = unite(v1727_8,v1727_11);
    v1726_8_result = unite(v1726_8_result,v1727_12);
  }
  const Space v1726_8 = std::move(v1726_8_result);
  return v1726_8;
}

static Space routine_200(Context& c, const Path& p0, const Space& s0) {
  Space v1732_4_result;
  for (int v1732_4_label = 1; v1732_4_label <= 2; ++v1732_4_label) {
    const Space v1732_4_tail = child(s0,v1732_4_label);
    if (v1732_4_tail.empty()) continue;
    const Path v1732_4_head{v1732_4_label};
    const Space v1733_2 = singleton(v1732_4_head);
    const Space v1733_3 = intersect(constant_5,v1733_2);
    const Space v1733_4 = (has_head(v1733_3) ? constant_7 : Space{});
    Space v1733_7;
    if (!v1733_4.empty()) {
      const Path v1734_5 = concat_path(p0,v1732_4_head);
      Space v1734_6_result;
      for (int v1734_6_label = 1; v1734_6_label <= 2; ++v1734_6_label) {
        const Space v1734_6_tail = child(v1732_4_tail,v1734_6_label);
        if (v1734_6_tail.empty()) continue;
        const Path v1734_6_head{v1734_6_label};
        const Space v1735_2 = singleton(v1734_6_head);
        const Space v1735_3 = intersect(constant_5,v1735_2);
        const Space v1735_4 = (has_head(v1735_3) ? constant_7 : Space{});
        Space v1735_7;
        if (!v1735_4.empty()) {
          const Path v1736_5 = concat_path(v1734_5,v1734_6_head);
          const Space v1736_6 = routine_72(c, v1736_5, v1734_6_tail);
          v1735_7 = compose(v1735_4,v1736_6);
        }
        v1734_6_result = unite(v1734_6_result,v1735_7);
      }
      const Space v1734_6 = std::move(v1734_6_result);
      v1733_7 = compose(v1733_4,v1734_6);
    }
    v1732_4_result = unite(v1732_4_result,v1733_7);
  }
  const Space v1732_4 = std::move(v1732_4_result);
  return v1732_4;
}

static Space routine_201(Context& c, const Path& p0, const Space& s0) {
  Space v1737_4_result;
  for (int v1737_4_label = 1; v1737_4_label <= 2; ++v1737_4_label) {
    const Space v1737_4_tail = child(s0,v1737_4_label);
    if (v1737_4_tail.empty()) continue;
    const Path v1737_4_head{v1737_4_label};
    const Space v1738_2 = singleton(v1737_4_head);
    const Space v1738_3 = intersect(constant_5,v1738_2);
    const Space v1738_4 = (has_head(v1738_3) ? constant_7 : Space{});
    const Space v1738_5 = compose(v1738_4,constant_10);
    v1737_4_result = unite(v1737_4_result,v1738_5);
  }
  const Space v1737_4 = std::move(v1737_4_result);
  return v1737_4;
}

static Space routine_202(Context& c, const Path& p0, const Space& s0) {
  Space v1739_4_result;
  for (int v1739_4_label = 1; v1739_4_label <= 2; ++v1739_4_label) {
    const Space v1739_4_tail = child(s0,v1739_4_label);
    if (v1739_4_tail.empty()) continue;
    const Path v1739_4_head{v1739_4_label};
    const Space v1740_2 = singleton(v1739_4_head);
    const Space v1740_3 = intersect(constant_5,v1740_2);
    const Space v1740_4 = (has_head(v1740_3) ? constant_7 : Space{});
    Space v1740_7;
    if (!v1740_4.empty()) {
      const Path v1741_5 = concat_path(p0,v1739_4_head);
      Space v1741_6_result;
      for (int v1741_6_label = 1; v1741_6_label <= 2; ++v1741_6_label) {
        const Space v1741_6_tail = child(v1739_4_tail,v1741_6_label);
        if (v1741_6_tail.empty()) continue;
        const Path v1741_6_head{v1741_6_label};
        const Space v1742_2 = singleton(v1741_6_head);
        const Space v1742_3 = intersect(constant_5,v1742_2);
        const Space v1742_4 = (has_head(v1742_3) ? constant_7 : Space{});
        Space v1742_7;
        if (!v1742_4.empty()) {
          const Path v1743_5 = concat_path(v1741_5,v1741_6_head);
          const Space v1743_6 = routine_76(c, v1743_5, v1741_6_tail);
          v1742_7 = compose(v1742_4,v1743_6);
        }
        v1741_6_result = unite(v1741_6_result,v1742_7);
      }
      const Space v1741_6 = std::move(v1741_6_result);
      v1740_7 = compose(v1740_4,v1741_6);
    }
    v1739_4_result = unite(v1739_4_result,v1740_7);
  }
  const Space v1739_4 = std::move(v1739_4_result);
  return v1739_4;
}

static Space routine_203(Context& c, const Path& p0, const Space& s0) {
  Space v1744_4_result;
  for (int v1744_4_label = 1; v1744_4_label <= 2; ++v1744_4_label) {
    const Space v1744_4_tail = child(s0,v1744_4_label);
    if (v1744_4_tail.empty()) continue;
    const Path v1744_4_head{v1744_4_label};
    const Space v1745_2 = singleton(v1744_4_head);
    const Space v1745_3 = intersect(constant_5,v1745_2);
    const Space v1745_4 = (has_head(v1745_3) ? constant_7 : Space{});
    const Space v1745_5 = compose(v1745_4,constant_10);
    v1744_4_result = unite(v1744_4_result,v1745_5);
  }
  const Space v1744_4 = std::move(v1744_4_result);
  return v1744_4;
}

static Space routine_204(Context& c, const Path& p0, const Space& s0) {
  Space v1746_4_result;
  for (int v1746_4_label = 1; v1746_4_label <= 2; ++v1746_4_label) {
    const Space v1746_4_tail = child(s0,v1746_4_label);
    if (v1746_4_tail.empty()) continue;
    const Path v1746_4_head{v1746_4_label};
    const Space v1747_2 = singleton(v1746_4_head);
    const Space v1747_3 = intersect(constant_5,v1747_2);
    const Space v1747_4 = (has_head(v1747_3) ? constant_7 : Space{});
    Space v1747_7;
    if (!v1747_4.empty()) {
      const Path v1748_5 = concat_path(p0,v1746_4_head);
      Space v1748_6_result;
      for (int v1748_6_label = 1; v1748_6_label <= 2; ++v1748_6_label) {
        const Space v1748_6_tail = child(v1746_4_tail,v1748_6_label);
        if (v1748_6_tail.empty()) continue;
        const Path v1748_6_head{v1748_6_label};
        const Space v1749_2 = singleton(v1748_6_head);
        const Space v1749_3 = intersect(constant_5,v1749_2);
        const Space v1749_4 = (has_head(v1749_3) ? constant_7 : Space{});
        Space v1749_7;
        if (!v1749_4.empty()) {
          const Path v1750_5 = concat_path(v1748_5,v1748_6_head);
          const Space v1750_6 = routine_79(c, v1750_5, v1748_6_tail);
          v1749_7 = compose(v1749_4,v1750_6);
        }
        v1748_6_result = unite(v1748_6_result,v1749_7);
      }
      const Space v1748_6 = std::move(v1748_6_result);
      v1747_7 = compose(v1747_4,v1748_6);
    }
    v1746_4_result = unite(v1746_4_result,v1747_7);
  }
  const Space v1746_4 = std::move(v1746_4_result);
  return v1746_4;
}

static Space routine_205(Context& c, const Path& p0, const Space& s0) {
  Space v1751_3_result;
  for (int v1751_3_label = 1; v1751_3_label <= 2; ++v1751_3_label) {
    const Space v1751_3_tail = child(s0,v1751_3_label);
    if (v1751_3_tail.empty()) continue;
    const Path v1751_3_head{v1751_3_label};
    const Space v1752_2 = singleton(v1751_3_head);
    const Space v1752_3 = intersect(constant_5,v1752_2);
    const Space v1752_4 = (has_head(v1752_3) ? constant_7 : Space{});
    const Space v1752_5 = compose(v1752_4,v1751_3_tail);
    v1751_3_result = unite(v1751_3_result,v1752_5);
  }
  const Space v1751_3 = std::move(v1751_3_result);
  return v1751_3;
}

static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1753_4 = Space{};
  return v1753_4;
}

static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1754_6 = unwrap(constant_9,p1);
  const Space v1754_8 = unwrap(constant_9,p0);
  const Space v1754_10 = unwrap(s1,constant_8);
  const Space v1754_12 = unwrap(constant_9,p1);
  const Space v1754_14 = unwrap(constant_9,p0);
  Space v1754_24_result;
  for (int v1754_24_label = 1; v1754_24_label <= 2; ++v1754_24_label) {
    const Space v1754_24_tail = child(s0,v1754_24_label);
    if (v1754_24_tail.empty()) continue;
    const Path v1754_24_head{v1754_24_label};
    const Space v1755_2 = singleton(v1754_24_head);
    const Space v1755_3 = intersect(constant_5,v1755_2);
    const Space v1755_4 = (has_head(v1755_3) ? constant_7 : Space{});
    Space v1755_23;
    if (!v1755_4.empty()) {
      const Space v1756_5 = unwrap(v1754_8,v1754_24_head);
      const Space v1756_6 = compose(v1754_6,v1756_5);
      const Path v1756_7 = concat_path(p0,v1754_24_head);
      const Path v1756_8 = concat_path(p1,v1756_7);
      const Space v1756_9 = singleton(v1756_8);
      const Space v1756_10 = subtract(v1756_6,v1756_9);
      const Space v1756_11 = intersect(v1756_10,v1754_10);
      const Space v1756_12 = routine_51(c, v1756_11);
      Space v1756_13_result;
      for (int v1756_13_label = 1; v1756_13_label <= 2; ++v1756_13_label) {
        const Space v1756_13_tail = child(v1756_12,v1756_13_label);
        if (v1756_13_tail.empty()) continue;
        const Path v1756_13_head{v1756_13_label};
        const Space v1757_2 = singleton(v1756_13_head);
        const Space v1757_3 = intersect(constant_5,v1757_2);
        const Space v1757_4 = (has_head(v1757_3) ? constant_7 : Space{});
        const Space v1757_5 = subtract(constant_0,v1757_4);
        Space v1757_7;
        if (!v1757_5.empty()) {
          const Space v1758_6 = routine_52(c, v1756_13_head, v1756_13_tail);
          v1757_7 = compose(v1757_5,v1758_6);
        }
        const Space v1757_8 = intersect(constant_5,v1757_2);
        const Space v1757_9 = (has_head(v1757_8) ? constant_7 : Space{});
        Space v1757_11;
        if (!v1757_9.empty()) {
          const Space v1759_10 = routine_53(c, v1756_13_head, v1756_13_tail);
          v1757_11 = compose(v1757_9,v1759_10);
        }
        const Space v1757_12 = unite(v1757_7,v1757_11);
        v1756_13_result = unite(v1756_13_result,v1757_12);
      }
      const Space v1756_13 = std::move(v1756_13_result);
      const Space v1756_14 = unwrap(v1754_14,v1754_24_head);
      const Space v1756_15 = compose(v1754_12,v1756_14);
      const Space v1756_16 = subtract(v1756_15,v1756_9);
      const Space v1756_17 = intersect(v1756_16,v1754_10);
      const Space v1756_18 = routine_36(c, v1756_17);
      Space v1756_19_result;
      for (int v1756_19_label = 1; v1756_19_label <= 2; ++v1756_19_label) {
        const Space v1756_19_tail = child(v1756_18,v1756_19_label);
        if (v1756_19_tail.empty()) continue;
        const Path v1756_19_head{v1756_19_label};
        const Space v1760_2 = singleton(v1756_19_head);
        const Space v1760_3 = intersect(constant_5,v1760_2);
        const Space v1760_4 = (has_head(v1760_3) ? constant_7 : Space{});
        const Space v1760_5 = subtract(constant_0,v1760_4);
        Space v1760_7;
        if (!v1760_5.empty()) {
          const Space v1761_6 = routine_54(c, v1756_19_head, v1756_19_tail);
          v1760_7 = compose(v1760_5,v1761_6);
        }
        const Space v1760_8 = intersect(constant_5,v1760_2);
        const Space v1760_9 = (has_head(v1760_8) ? constant_7 : Space{});
        Space v1760_11;
        if (!v1760_9.empty()) {
          const Space v1762_10 = routine_55(c, v1756_19_head, v1756_19_tail);
          v1760_11 = compose(v1760_9,v1762_10);
        }
        const Space v1760_12 = unite(v1760_7,v1760_11);
        v1756_19_result = unite(v1756_19_result,v1760_12);
      }
      const Space v1756_19 = std::move(v1756_19_result);
      const Space v1756_20 = subtract(v1756_13,v1756_19);
      const Space v1756_21 = compose(v1756_20,v1756_9);
      Space v1756_22_result;
      for (int v1756_22_label = 1; v1756_22_label <= 2; ++v1756_22_label) {
        const Space v1756_22_tail = child(v1756_21,v1756_22_label);
        if (v1756_22_tail.empty()) continue;
        const Path v1756_22_head{v1756_22_label};
        const Space v1763_2 = singleton(v1756_22_head);
        const Space v1763_3 = intersect(constant_5,v1763_2);
        const Space v1763_4 = (has_head(v1763_3) ? constant_7 : Space{});
        const Space v1763_5 = subtract(constant_0,v1763_4);
        Space v1763_7;
        if (!v1763_5.empty()) {
          const Space v1764_6 = routine_56(c, v1756_22_head, v1756_22_tail);
          v1763_7 = compose(v1763_5,v1764_6);
        }
        const Space v1763_8 = intersect(constant_5,v1763_2);
        const Space v1763_9 = (has_head(v1763_8) ? constant_7 : Space{});
        Space v1763_11;
        if (!v1763_9.empty()) {
          const Space v1765_10 = routine_57(c, v1756_22_head, v1756_22_tail);
          v1763_11 = compose(v1763_9,v1765_10);
        }
        const Space v1763_12 = unite(v1763_7,v1763_11);
        v1756_22_result = unite(v1756_22_result,v1763_12);
      }
      const Space v1756_22 = std::move(v1756_22_result);
      v1755_23 = compose(v1755_4,v1756_22);
    }
    v1754_24_result = unite(v1754_24_result,v1755_23);
  }
  const Space v1754_24 = std::move(v1754_24_result);
  return v1754_24;
}

static Space routine_208(Context& c, const Path& p0, const Space& s0) {
  Space v1766_11_result;
  for (int v1766_11_label = 1; v1766_11_label <= 2; ++v1766_11_label) {
    const Space v1766_11_tail = child(s0,v1766_11_label);
    if (v1766_11_tail.empty()) continue;
    const Path v1766_11_head{v1766_11_label};
    const Space v1767_2 = singleton(v1766_11_head);
    const Space v1767_3 = intersect(constant_5,v1767_2);
    const Space v1767_4 = (has_head(v1767_3) ? constant_7 : Space{});
    const Space v1767_5 = subtract(constant_0,v1767_4);
    Space v1767_8;
    if (!v1767_5.empty()) {
      const Path v1768_6 = concat_path(p0,v1766_11_head);
      Space v1768_7_result;
      for (int v1768_7_label = 1; v1768_7_label <= 2; ++v1768_7_label) {
        const Space v1768_7_tail = child(v1766_11_tail,v1768_7_label);
        if (v1768_7_tail.empty()) continue;
        const Path v1768_7_head{v1768_7_label};
        const Space v1769_2 = singleton(v1768_7_head);
        const Space v1769_3 = intersect(constant_5,v1769_2);
        const Space v1769_4 = (has_head(v1769_3) ? constant_7 : Space{});
        const Space v1769_5 = subtract(constant_0,v1769_4);
        Space v1769_8;
        if (!v1769_5.empty()) {
          const Path v1770_6 = concat_path(v1768_6,v1768_7_head);
          const Space v1770_7 = routine_226(c, v1770_6, v1768_7_tail);
          v1769_8 = compose(v1769_5,v1770_7);
        }
        const Space v1769_9 = intersect(constant_5,v1769_2);
        const Space v1769_10 = (has_head(v1769_9) ? constant_7 : Space{});
        Space v1769_12;
        if (!v1769_10.empty()) {
          const Path v1771_6 = concat_path(v1768_6,v1768_7_head);
          const Space v1771_11 = routine_227(c, v1771_6, v1768_7_tail);
          v1769_12 = compose(v1769_10,v1771_11);
        }
        const Space v1769_13 = unite(v1769_8,v1769_12);
        v1768_7_result = unite(v1768_7_result,v1769_13);
      }
      const Space v1768_7 = std::move(v1768_7_result);
      v1767_8 = compose(v1767_5,v1768_7);
    }
    const Space v1767_9 = intersect(constant_5,v1767_2);
    const Space v1767_10 = (has_head(v1767_9) ? constant_7 : Space{});
    Space v1767_12;
    if (!v1767_10.empty()) {
      const Path v1772_6 = concat_path(p0,v1766_11_head);
      Space v1772_11_result;
      for (int v1772_11_label = 1; v1772_11_label <= 2; ++v1772_11_label) {
        const Space v1772_11_tail = child(v1766_11_tail,v1772_11_label);
        if (v1772_11_tail.empty()) continue;
        const Path v1772_11_head{v1772_11_label};
        const Space v1773_2 = singleton(v1772_11_head);
        const Space v1773_3 = intersect(constant_5,v1773_2);
        const Space v1773_4 = (has_head(v1773_3) ? constant_7 : Space{});
        const Space v1773_5 = subtract(constant_0,v1773_4);
        Space v1773_8;
        if (!v1773_5.empty()) {
          const Path v1774_6 = concat_path(v1772_6,v1772_11_head);
          const Space v1774_7 = routine_226(c, v1774_6, v1772_11_tail);
          v1773_8 = compose(v1773_5,v1774_7);
        }
        const Space v1773_9 = intersect(constant_5,v1773_2);
        const Space v1773_10 = (has_head(v1773_9) ? constant_7 : Space{});
        Space v1773_12;
        if (!v1773_10.empty()) {
          const Path v1775_6 = concat_path(v1772_6,v1772_11_head);
          const Space v1775_11 = routine_95(c, v1775_6, v1772_11_tail);
          v1773_12 = compose(v1773_10,v1775_11);
        }
        const Space v1773_13 = unite(v1773_8,v1773_12);
        v1772_11_result = unite(v1772_11_result,v1773_13);
      }
      const Space v1772_11 = std::move(v1772_11_result);
      v1767_12 = compose(v1767_10,v1772_11);
    }
    const Space v1767_13 = unite(v1767_8,v1767_12);
    v1766_11_result = unite(v1766_11_result,v1767_13);
  }
  const Space v1766_11 = std::move(v1766_11_result);
  return v1766_11;
}

static Space routine_209(Context& c, const Path& p0, const Space& s0) {
  Space v1776_9_result;
  for (int v1776_9_label = 1; v1776_9_label <= 2; ++v1776_9_label) {
    const Space v1776_9_tail = child(s0,v1776_9_label);
    if (v1776_9_tail.empty()) continue;
    const Path v1776_9_head{v1776_9_label};
    const Space v1777_2 = singleton(v1776_9_head);
    const Space v1777_3 = intersect(constant_5,v1777_2);
    const Space v1777_4 = (has_head(v1777_3) ? constant_7 : Space{});
    const Space v1777_5 = subtract(constant_0,v1777_4);
    Space v1777_8;
    if (!v1777_5.empty()) {
      const Path v1778_6 = concat_path(p0,v1776_9_head);
      Space v1778_7_result;
      for (int v1778_7_label = 1; v1778_7_label <= 2; ++v1778_7_label) {
        const Space v1778_7_tail = child(v1776_9_tail,v1778_7_label);
        if (v1778_7_tail.empty()) continue;
        const Path v1778_7_head{v1778_7_label};
        const Space v1779_2 = singleton(v1778_7_head);
        const Space v1779_3 = intersect(constant_5,v1779_2);
        const Space v1779_4 = (has_head(v1779_3) ? constant_7 : Space{});
        const Space v1779_5 = subtract(constant_0,v1779_4);
        Space v1779_8;
        if (!v1779_5.empty()) {
          const Path v1780_6 = concat_path(v1778_6,v1778_7_head);
          const Space v1780_7 = routine_226(c, v1780_6, v1778_7_tail);
          v1779_8 = compose(v1779_5,v1780_7);
        }
        const Space v1779_9 = intersect(constant_5,v1779_2);
        const Space v1779_10 = (has_head(v1779_9) ? constant_7 : Space{});
        Space v1779_12;
        if (!v1779_10.empty()) {
          const Path v1781_6 = concat_path(v1778_6,v1778_7_head);
          const Space v1781_11 = routine_227(c, v1781_6, v1778_7_tail);
          v1779_12 = compose(v1779_10,v1781_11);
        }
        const Space v1779_13 = unite(v1779_8,v1779_12);
        v1778_7_result = unite(v1778_7_result,v1779_13);
      }
      const Space v1778_7 = std::move(v1778_7_result);
      v1777_8 = compose(v1777_5,v1778_7);
    }
    const Space v1777_9 = intersect(constant_5,v1777_2);
    const Space v1777_10 = (has_head(v1777_9) ? constant_7 : Space{});
    const Space v1777_11 = compose(v1777_10,constant_10);
    const Space v1777_12 = unite(v1777_8,v1777_11);
    v1776_9_result = unite(v1776_9_result,v1777_12);
  }
  const Space v1776_9 = std::move(v1776_9_result);
  return v1776_9;
}

static Space routine_210(Context& c, const Path& p0, const Space& s0) {
  Space v1782_11_result;
  for (int v1782_11_label = 1; v1782_11_label <= 2; ++v1782_11_label) {
    const Space v1782_11_tail = child(s0,v1782_11_label);
    if (v1782_11_tail.empty()) continue;
    const Path v1782_11_head{v1782_11_label};
    const Space v1783_2 = singleton(v1782_11_head);
    const Space v1783_3 = intersect(constant_5,v1783_2);
    const Space v1783_4 = (has_head(v1783_3) ? constant_7 : Space{});
    const Space v1783_5 = subtract(constant_0,v1783_4);
    Space v1783_8;
    if (!v1783_5.empty()) {
      const Path v1784_6 = concat_path(p0,v1782_11_head);
      Space v1784_7_result;
      for (int v1784_7_label = 1; v1784_7_label <= 2; ++v1784_7_label) {
        const Space v1784_7_tail = child(v1782_11_tail,v1784_7_label);
        if (v1784_7_tail.empty()) continue;
        const Path v1784_7_head{v1784_7_label};
        const Space v1785_2 = singleton(v1784_7_head);
        const Space v1785_3 = intersect(constant_5,v1785_2);
        const Space v1785_4 = (has_head(v1785_3) ? constant_7 : Space{});
        const Space v1785_5 = subtract(constant_0,v1785_4);
        Space v1785_8;
        if (!v1785_5.empty()) {
          const Path v1786_6 = concat_path(v1784_6,v1784_7_head);
          const Space v1786_7 = routine_228(c, v1786_6, v1784_7_tail);
          v1785_8 = compose(v1785_5,v1786_7);
        }
        const Space v1785_9 = intersect(constant_5,v1785_2);
        const Space v1785_10 = (has_head(v1785_9) ? constant_7 : Space{});
        Space v1785_12;
        if (!v1785_10.empty()) {
          const Path v1787_6 = concat_path(v1784_6,v1784_7_head);
          const Space v1787_11 = routine_229(c, v1787_6, v1784_7_tail);
          v1785_12 = compose(v1785_10,v1787_11);
        }
        const Space v1785_13 = unite(v1785_8,v1785_12);
        v1784_7_result = unite(v1784_7_result,v1785_13);
      }
      const Space v1784_7 = std::move(v1784_7_result);
      v1783_8 = compose(v1783_5,v1784_7);
    }
    const Space v1783_9 = intersect(constant_5,v1783_2);
    const Space v1783_10 = (has_head(v1783_9) ? constant_7 : Space{});
    Space v1783_12;
    if (!v1783_10.empty()) {
      const Path v1788_6 = concat_path(p0,v1782_11_head);
      Space v1788_11_result;
      for (int v1788_11_label = 1; v1788_11_label <= 2; ++v1788_11_label) {
        const Space v1788_11_tail = child(v1782_11_tail,v1788_11_label);
        if (v1788_11_tail.empty()) continue;
        const Path v1788_11_head{v1788_11_label};
        const Space v1789_2 = singleton(v1788_11_head);
        const Space v1789_3 = intersect(constant_5,v1789_2);
        const Space v1789_4 = (has_head(v1789_3) ? constant_7 : Space{});
        const Space v1789_5 = subtract(constant_0,v1789_4);
        Space v1789_8;
        if (!v1789_5.empty()) {
          const Path v1790_6 = concat_path(v1788_6,v1788_11_head);
          const Space v1790_7 = routine_228(c, v1790_6, v1788_11_tail);
          v1789_8 = compose(v1789_5,v1790_7);
        }
        const Space v1789_9 = intersect(constant_5,v1789_2);
        const Space v1789_10 = (has_head(v1789_9) ? constant_7 : Space{});
        Space v1789_12;
        if (!v1789_10.empty()) {
          const Path v1791_6 = concat_path(v1788_6,v1788_11_head);
          const Space v1791_11 = routine_98(c, v1791_6, v1788_11_tail);
          v1789_12 = compose(v1789_10,v1791_11);
        }
        const Space v1789_13 = unite(v1789_8,v1789_12);
        v1788_11_result = unite(v1788_11_result,v1789_13);
      }
      const Space v1788_11 = std::move(v1788_11_result);
      v1783_12 = compose(v1783_10,v1788_11);
    }
    const Space v1783_13 = unite(v1783_8,v1783_12);
    v1782_11_result = unite(v1782_11_result,v1783_13);
  }
  const Space v1782_11 = std::move(v1782_11_result);
  return v1782_11;
}

static Space routine_211(Context& c, const Path& p0, const Space& s0) {
  Space v1792_9_result;
  for (int v1792_9_label = 1; v1792_9_label <= 2; ++v1792_9_label) {
    const Space v1792_9_tail = child(s0,v1792_9_label);
    if (v1792_9_tail.empty()) continue;
    const Path v1792_9_head{v1792_9_label};
    const Space v1793_2 = singleton(v1792_9_head);
    const Space v1793_3 = intersect(constant_5,v1793_2);
    const Space v1793_4 = (has_head(v1793_3) ? constant_7 : Space{});
    const Space v1793_5 = subtract(constant_0,v1793_4);
    Space v1793_8;
    if (!v1793_5.empty()) {
      const Path v1794_6 = concat_path(p0,v1792_9_head);
      Space v1794_7_result;
      for (int v1794_7_label = 1; v1794_7_label <= 2; ++v1794_7_label) {
        const Space v1794_7_tail = child(v1792_9_tail,v1794_7_label);
        if (v1794_7_tail.empty()) continue;
        const Path v1794_7_head{v1794_7_label};
        const Space v1795_2 = singleton(v1794_7_head);
        const Space v1795_3 = intersect(constant_5,v1795_2);
        const Space v1795_4 = (has_head(v1795_3) ? constant_7 : Space{});
        const Space v1795_5 = subtract(constant_0,v1795_4);
        Space v1795_8;
        if (!v1795_5.empty()) {
          const Path v1796_6 = concat_path(v1794_6,v1794_7_head);
          const Space v1796_7 = routine_228(c, v1796_6, v1794_7_tail);
          v1795_8 = compose(v1795_5,v1796_7);
        }
        const Space v1795_9 = intersect(constant_5,v1795_2);
        const Space v1795_10 = (has_head(v1795_9) ? constant_7 : Space{});
        Space v1795_12;
        if (!v1795_10.empty()) {
          const Path v1797_6 = concat_path(v1794_6,v1794_7_head);
          const Space v1797_11 = routine_229(c, v1797_6, v1794_7_tail);
          v1795_12 = compose(v1795_10,v1797_11);
        }
        const Space v1795_13 = unite(v1795_8,v1795_12);
        v1794_7_result = unite(v1794_7_result,v1795_13);
      }
      const Space v1794_7 = std::move(v1794_7_result);
      v1793_8 = compose(v1793_5,v1794_7);
    }
    const Space v1793_9 = intersect(constant_5,v1793_2);
    const Space v1793_10 = (has_head(v1793_9) ? constant_7 : Space{});
    const Space v1793_11 = compose(v1793_10,constant_10);
    const Space v1793_12 = unite(v1793_8,v1793_11);
    v1792_9_result = unite(v1792_9_result,v1793_12);
  }
  const Space v1792_9 = std::move(v1792_9_result);
  return v1792_9;
}

static Space routine_212(Context& c, const Path& p0, const Space& s0) {
  Space v1798_11_result;
  for (int v1798_11_label = 1; v1798_11_label <= 2; ++v1798_11_label) {
    const Space v1798_11_tail = child(s0,v1798_11_label);
    if (v1798_11_tail.empty()) continue;
    const Path v1798_11_head{v1798_11_label};
    const Space v1799_2 = singleton(v1798_11_head);
    const Space v1799_3 = intersect(constant_5,v1799_2);
    const Space v1799_4 = (has_head(v1799_3) ? constant_7 : Space{});
    const Space v1799_5 = subtract(constant_0,v1799_4);
    Space v1799_8;
    if (!v1799_5.empty()) {
      const Path v1800_6 = concat_path(p0,v1798_11_head);
      Space v1800_7_result;
      for (int v1800_7_label = 1; v1800_7_label <= 2; ++v1800_7_label) {
        const Space v1800_7_tail = child(v1798_11_tail,v1800_7_label);
        if (v1800_7_tail.empty()) continue;
        const Path v1800_7_head{v1800_7_label};
        const Space v1801_2 = singleton(v1800_7_head);
        const Space v1801_3 = intersect(constant_5,v1801_2);
        const Space v1801_4 = (has_head(v1801_3) ? constant_7 : Space{});
        const Space v1801_5 = subtract(constant_0,v1801_4);
        Space v1801_8;
        if (!v1801_5.empty()) {
          const Path v1802_6 = concat_path(v1800_6,v1800_7_head);
          const Space v1802_7 = routine_230(c, v1802_6, v1800_7_tail);
          v1801_8 = compose(v1801_5,v1802_7);
        }
        const Space v1801_9 = intersect(constant_5,v1801_2);
        const Space v1801_10 = (has_head(v1801_9) ? constant_7 : Space{});
        Space v1801_12;
        if (!v1801_10.empty()) {
          const Path v1803_6 = concat_path(v1800_6,v1800_7_head);
          const Space v1803_11 = routine_231(c, v1803_6, v1800_7_tail);
          v1801_12 = compose(v1801_10,v1803_11);
        }
        const Space v1801_13 = unite(v1801_8,v1801_12);
        v1800_7_result = unite(v1800_7_result,v1801_13);
      }
      const Space v1800_7 = std::move(v1800_7_result);
      v1799_8 = compose(v1799_5,v1800_7);
    }
    const Space v1799_9 = intersect(constant_5,v1799_2);
    const Space v1799_10 = (has_head(v1799_9) ? constant_7 : Space{});
    Space v1799_12;
    if (!v1799_10.empty()) {
      const Path v1804_6 = concat_path(p0,v1798_11_head);
      Space v1804_11_result;
      for (int v1804_11_label = 1; v1804_11_label <= 2; ++v1804_11_label) {
        const Space v1804_11_tail = child(v1798_11_tail,v1804_11_label);
        if (v1804_11_tail.empty()) continue;
        const Path v1804_11_head{v1804_11_label};
        const Space v1805_2 = singleton(v1804_11_head);
        const Space v1805_3 = intersect(constant_5,v1805_2);
        const Space v1805_4 = (has_head(v1805_3) ? constant_7 : Space{});
        const Space v1805_5 = subtract(constant_0,v1805_4);
        Space v1805_8;
        if (!v1805_5.empty()) {
          const Path v1806_6 = concat_path(v1804_6,v1804_11_head);
          const Space v1806_7 = routine_230(c, v1806_6, v1804_11_tail);
          v1805_8 = compose(v1805_5,v1806_7);
        }
        const Space v1805_9 = intersect(constant_5,v1805_2);
        const Space v1805_10 = (has_head(v1805_9) ? constant_7 : Space{});
        Space v1805_12;
        if (!v1805_10.empty()) {
          const Path v1807_6 = concat_path(v1804_6,v1804_11_head);
          const Space v1807_11 = routine_101(c, v1807_6, v1804_11_tail);
          v1805_12 = compose(v1805_10,v1807_11);
        }
        const Space v1805_13 = unite(v1805_8,v1805_12);
        v1804_11_result = unite(v1804_11_result,v1805_13);
      }
      const Space v1804_11 = std::move(v1804_11_result);
      v1799_12 = compose(v1799_10,v1804_11);
    }
    const Space v1799_13 = unite(v1799_8,v1799_12);
    v1798_11_result = unite(v1798_11_result,v1799_13);
  }
  const Space v1798_11 = std::move(v1798_11_result);
  return v1798_11;
}

static Space routine_213(Context& c, const Path& p0, const Space& s0) {
  Space v1808_8_result;
  for (int v1808_8_label = 1; v1808_8_label <= 2; ++v1808_8_label) {
    const Space v1808_8_tail = child(s0,v1808_8_label);
    if (v1808_8_tail.empty()) continue;
    const Path v1808_8_head{v1808_8_label};
    const Space v1809_2 = singleton(v1808_8_head);
    const Space v1809_3 = intersect(constant_5,v1809_2);
    const Space v1809_4 = (has_head(v1809_3) ? constant_7 : Space{});
    const Space v1809_5 = subtract(constant_0,v1809_4);
    Space v1809_8;
    if (!v1809_5.empty()) {
      const Path v1810_6 = concat_path(p0,v1808_8_head);
      Space v1810_7_result;
      for (int v1810_7_label = 1; v1810_7_label <= 2; ++v1810_7_label) {
        const Space v1810_7_tail = child(v1808_8_tail,v1810_7_label);
        if (v1810_7_tail.empty()) continue;
        const Path v1810_7_head{v1810_7_label};
        const Space v1811_2 = singleton(v1810_7_head);
        const Space v1811_3 = intersect(constant_5,v1811_2);
        const Space v1811_4 = (has_head(v1811_3) ? constant_7 : Space{});
        const Space v1811_5 = subtract(constant_0,v1811_4);
        Space v1811_8;
        if (!v1811_5.empty()) {
          const Path v1812_6 = concat_path(v1810_6,v1810_7_head);
          const Space v1812_7 = routine_230(c, v1812_6, v1810_7_tail);
          v1811_8 = compose(v1811_5,v1812_7);
        }
        const Space v1811_9 = intersect(constant_5,v1811_2);
        const Space v1811_10 = (has_head(v1811_9) ? constant_7 : Space{});
        Space v1811_12;
        if (!v1811_10.empty()) {
          const Path v1813_6 = concat_path(v1810_6,v1810_7_head);
          const Space v1813_11 = routine_231(c, v1813_6, v1810_7_tail);
          v1811_12 = compose(v1811_10,v1813_11);
        }
        const Space v1811_13 = unite(v1811_8,v1811_12);
        v1810_7_result = unite(v1810_7_result,v1811_13);
      }
      const Space v1810_7 = std::move(v1810_7_result);
      v1809_8 = compose(v1809_5,v1810_7);
    }
    const Space v1809_9 = intersect(constant_5,v1809_2);
    const Space v1809_10 = (has_head(v1809_9) ? constant_7 : Space{});
    const Space v1809_11 = compose(v1809_10,v1808_8_tail);
    const Space v1809_12 = unite(v1809_8,v1809_11);
    v1808_8_result = unite(v1808_8_result,v1809_12);
  }
  const Space v1808_8 = std::move(v1808_8_result);
  return v1808_8;
}

static Space routine_214(Context& c, const Path& p0, const Space& s0) {
  Space v1814_4_result;
  for (int v1814_4_label = 1; v1814_4_label <= 2; ++v1814_4_label) {
    const Space v1814_4_tail = child(s0,v1814_4_label);
    if (v1814_4_tail.empty()) continue;
    const Path v1814_4_head{v1814_4_label};
    const Space v1815_2 = singleton(v1814_4_head);
    const Space v1815_3 = intersect(constant_5,v1815_2);
    const Space v1815_4 = (has_head(v1815_3) ? constant_7 : Space{});
    Space v1815_7;
    if (!v1815_4.empty()) {
      const Path v1816_5 = concat_path(p0,v1814_4_head);
      Space v1816_6_result;
      for (int v1816_6_label = 1; v1816_6_label <= 2; ++v1816_6_label) {
        const Space v1816_6_tail = child(v1814_4_tail,v1816_6_label);
        if (v1816_6_tail.empty()) continue;
        const Path v1816_6_head{v1816_6_label};
        const Space v1817_2 = singleton(v1816_6_head);
        const Space v1817_3 = intersect(constant_5,v1817_2);
        const Space v1817_4 = (has_head(v1817_3) ? constant_7 : Space{});
        Space v1817_7;
        if (!v1817_4.empty()) {
          const Path v1818_5 = concat_path(v1816_5,v1816_6_head);
          const Space v1818_6 = routine_95(c, v1818_5, v1816_6_tail);
          v1817_7 = compose(v1817_4,v1818_6);
        }
        v1816_6_result = unite(v1816_6_result,v1817_7);
      }
      const Space v1816_6 = std::move(v1816_6_result);
      v1815_7 = compose(v1815_4,v1816_6);
    }
    v1814_4_result = unite(v1814_4_result,v1815_7);
  }
  const Space v1814_4 = std::move(v1814_4_result);
  return v1814_4;
}

static Space routine_215(Context& c, const Path& p0, const Space& s0) {
  Space v1819_4_result;
  for (int v1819_4_label = 1; v1819_4_label <= 2; ++v1819_4_label) {
    const Space v1819_4_tail = child(s0,v1819_4_label);
    if (v1819_4_tail.empty()) continue;
    const Path v1819_4_head{v1819_4_label};
    const Space v1820_2 = singleton(v1819_4_head);
    const Space v1820_3 = intersect(constant_5,v1820_2);
    const Space v1820_4 = (has_head(v1820_3) ? constant_7 : Space{});
    const Space v1820_5 = compose(v1820_4,constant_10);
    v1819_4_result = unite(v1819_4_result,v1820_5);
  }
  const Space v1819_4 = std::move(v1819_4_result);
  return v1819_4;
}

static Space routine_216(Context& c, const Path& p0, const Space& s0) {
  Space v1821_4_result;
  for (int v1821_4_label = 1; v1821_4_label <= 2; ++v1821_4_label) {
    const Space v1821_4_tail = child(s0,v1821_4_label);
    if (v1821_4_tail.empty()) continue;
    const Path v1821_4_head{v1821_4_label};
    const Space v1822_2 = singleton(v1821_4_head);
    const Space v1822_3 = intersect(constant_5,v1822_2);
    const Space v1822_4 = (has_head(v1822_3) ? constant_7 : Space{});
    Space v1822_7;
    if (!v1822_4.empty()) {
      const Path v1823_5 = concat_path(p0,v1821_4_head);
      Space v1823_6_result;
      for (int v1823_6_label = 1; v1823_6_label <= 2; ++v1823_6_label) {
        const Space v1823_6_tail = child(v1821_4_tail,v1823_6_label);
        if (v1823_6_tail.empty()) continue;
        const Path v1823_6_head{v1823_6_label};
        const Space v1824_2 = singleton(v1823_6_head);
        const Space v1824_3 = intersect(constant_5,v1824_2);
        const Space v1824_4 = (has_head(v1824_3) ? constant_7 : Space{});
        Space v1824_7;
        if (!v1824_4.empty()) {
          const Path v1825_5 = concat_path(v1823_5,v1823_6_head);
          const Space v1825_6 = routine_98(c, v1825_5, v1823_6_tail);
          v1824_7 = compose(v1824_4,v1825_6);
        }
        v1823_6_result = unite(v1823_6_result,v1824_7);
      }
      const Space v1823_6 = std::move(v1823_6_result);
      v1822_7 = compose(v1822_4,v1823_6);
    }
    v1821_4_result = unite(v1821_4_result,v1822_7);
  }
  const Space v1821_4 = std::move(v1821_4_result);
  return v1821_4;
}

static Space routine_217(Context& c, const Path& p0, const Space& s0) {
  Space v1826_4_result;
  for (int v1826_4_label = 1; v1826_4_label <= 2; ++v1826_4_label) {
    const Space v1826_4_tail = child(s0,v1826_4_label);
    if (v1826_4_tail.empty()) continue;
    const Path v1826_4_head{v1826_4_label};
    const Space v1827_2 = singleton(v1826_4_head);
    const Space v1827_3 = intersect(constant_5,v1827_2);
    const Space v1827_4 = (has_head(v1827_3) ? constant_7 : Space{});
    const Space v1827_5 = compose(v1827_4,constant_10);
    v1826_4_result = unite(v1826_4_result,v1827_5);
  }
  const Space v1826_4 = std::move(v1826_4_result);
  return v1826_4;
}

static Space routine_218(Context& c, const Path& p0, const Space& s0) {
  Space v1828_4_result;
  for (int v1828_4_label = 1; v1828_4_label <= 2; ++v1828_4_label) {
    const Space v1828_4_tail = child(s0,v1828_4_label);
    if (v1828_4_tail.empty()) continue;
    const Path v1828_4_head{v1828_4_label};
    const Space v1829_2 = singleton(v1828_4_head);
    const Space v1829_3 = intersect(constant_5,v1829_2);
    const Space v1829_4 = (has_head(v1829_3) ? constant_7 : Space{});
    Space v1829_7;
    if (!v1829_4.empty()) {
      const Path v1830_5 = concat_path(p0,v1828_4_head);
      Space v1830_6_result;
      for (int v1830_6_label = 1; v1830_6_label <= 2; ++v1830_6_label) {
        const Space v1830_6_tail = child(v1828_4_tail,v1830_6_label);
        if (v1830_6_tail.empty()) continue;
        const Path v1830_6_head{v1830_6_label};
        const Space v1831_2 = singleton(v1830_6_head);
        const Space v1831_3 = intersect(constant_5,v1831_2);
        const Space v1831_4 = (has_head(v1831_3) ? constant_7 : Space{});
        Space v1831_7;
        if (!v1831_4.empty()) {
          const Path v1832_5 = concat_path(v1830_5,v1830_6_head);
          const Space v1832_6 = routine_101(c, v1832_5, v1830_6_tail);
          v1831_7 = compose(v1831_4,v1832_6);
        }
        v1830_6_result = unite(v1830_6_result,v1831_7);
      }
      const Space v1830_6 = std::move(v1830_6_result);
      v1829_7 = compose(v1829_4,v1830_6);
    }
    v1828_4_result = unite(v1828_4_result,v1829_7);
  }
  const Space v1828_4 = std::move(v1828_4_result);
  return v1828_4;
}

static Space routine_219(Context& c, const Path& p0, const Space& s0) {
  Space v1833_3_result;
  for (int v1833_3_label = 1; v1833_3_label <= 2; ++v1833_3_label) {
    const Space v1833_3_tail = child(s0,v1833_3_label);
    if (v1833_3_tail.empty()) continue;
    const Path v1833_3_head{v1833_3_label};
    const Space v1834_2 = singleton(v1833_3_head);
    const Space v1834_3 = intersect(constant_5,v1834_2);
    const Space v1834_4 = (has_head(v1834_3) ? constant_7 : Space{});
    const Space v1834_5 = compose(v1834_4,v1833_3_tail);
    v1833_3_result = unite(v1833_3_result,v1834_5);
  }
  const Space v1833_3 = std::move(v1833_3_result);
  return v1833_3;
}

static Space routine_220(Context& c, const Path& p0, const Space& s0) {
  const Space v1835_2 = Space{};
  return v1835_2;
}

static Space routine_221(Context& c, const Path& p0, const Space& s0) {
  Space v1836_4_result;
  for (int v1836_4_label = 1; v1836_4_label <= 2; ++v1836_4_label) {
    const Space v1836_4_tail = child(s0,v1836_4_label);
    if (v1836_4_tail.empty()) continue;
    const Path v1836_4_head{v1836_4_label};
    const Space v1837_2 = singleton(v1836_4_head);
    const Space v1837_3 = intersect(constant_5,v1837_2);
    const Space v1837_4 = (has_head(v1837_3) ? constant_7 : Space{});
    const Space v1837_5 = compose(v1837_4,constant_10);
    v1836_4_result = unite(v1836_4_result,v1837_5);
  }
  const Space v1836_4 = std::move(v1836_4_result);
  return v1836_4;
}

static Space routine_222(Context& c, const Path& p0, const Space& s0) {
  const Space v1838_2 = Space{};
  return v1838_2;
}

static Space routine_223(Context& c, const Path& p0, const Space& s0) {
  Space v1839_4_result;
  for (int v1839_4_label = 1; v1839_4_label <= 2; ++v1839_4_label) {
    const Space v1839_4_tail = child(s0,v1839_4_label);
    if (v1839_4_tail.empty()) continue;
    const Path v1839_4_head{v1839_4_label};
    const Space v1840_2 = singleton(v1839_4_head);
    const Space v1840_3 = intersect(constant_5,v1840_2);
    const Space v1840_4 = (has_head(v1840_3) ? constant_7 : Space{});
    const Space v1840_5 = compose(v1840_4,constant_10);
    v1839_4_result = unite(v1839_4_result,v1840_5);
  }
  const Space v1839_4 = std::move(v1839_4_result);
  return v1839_4;
}

static Space routine_224(Context& c, const Path& p0, const Space& s0) {
  const Space v1841_2 = Space{};
  return v1841_2;
}

static Space routine_225(Context& c, const Path& p0, const Space& s0) {
  Space v1842_3_result;
  for (int v1842_3_label = 1; v1842_3_label <= 2; ++v1842_3_label) {
    const Space v1842_3_tail = child(s0,v1842_3_label);
    if (v1842_3_tail.empty()) continue;
    const Path v1842_3_head{v1842_3_label};
    const Space v1843_2 = singleton(v1842_3_head);
    const Space v1843_3 = intersect(constant_5,v1843_2);
    const Space v1843_4 = (has_head(v1843_3) ? constant_7 : Space{});
    const Space v1843_5 = compose(v1843_4,v1842_3_tail);
    v1842_3_result = unite(v1842_3_result,v1843_5);
  }
  const Space v1842_3 = std::move(v1842_3_result);
  return v1842_3;
}

static Space routine_226(Context& c, const Path& p0, const Space& s0) {
  const Space v1844_2 = Space{};
  return v1844_2;
}

static Space routine_227(Context& c, const Path& p0, const Space& s0) {
  Space v1845_4_result;
  for (int v1845_4_label = 1; v1845_4_label <= 2; ++v1845_4_label) {
    const Space v1845_4_tail = child(s0,v1845_4_label);
    if (v1845_4_tail.empty()) continue;
    const Path v1845_4_head{v1845_4_label};
    const Space v1846_2 = singleton(v1845_4_head);
    const Space v1846_3 = intersect(constant_5,v1846_2);
    const Space v1846_4 = (has_head(v1846_3) ? constant_7 : Space{});
    const Space v1846_5 = compose(v1846_4,constant_10);
    v1845_4_result = unite(v1845_4_result,v1846_5);
  }
  const Space v1845_4 = std::move(v1845_4_result);
  return v1845_4;
}

static Space routine_228(Context& c, const Path& p0, const Space& s0) {
  const Space v1847_2 = Space{};
  return v1847_2;
}

static Space routine_229(Context& c, const Path& p0, const Space& s0) {
  Space v1848_4_result;
  for (int v1848_4_label = 1; v1848_4_label <= 2; ++v1848_4_label) {
    const Space v1848_4_tail = child(s0,v1848_4_label);
    if (v1848_4_tail.empty()) continue;
    const Path v1848_4_head{v1848_4_label};
    const Space v1849_2 = singleton(v1848_4_head);
    const Space v1849_3 = intersect(constant_5,v1849_2);
    const Space v1849_4 = (has_head(v1849_3) ? constant_7 : Space{});
    const Space v1849_5 = compose(v1849_4,constant_10);
    v1848_4_result = unite(v1848_4_result,v1849_5);
  }
  const Space v1848_4 = std::move(v1848_4_result);
  return v1848_4;
}

static Space routine_230(Context& c, const Path& p0, const Space& s0) {
  const Space v1850_2 = Space{};
  return v1850_2;
}

static Space routine_231(Context& c, const Path& p0, const Space& s0) {
  Space v1851_3_result;
  for (int v1851_3_label = 1; v1851_3_label <= 2; ++v1851_3_label) {
    const Space v1851_3_tail = child(s0,v1851_3_label);
    if (v1851_3_tail.empty()) continue;
    const Path v1851_3_head{v1851_3_label};
    const Space v1852_2 = singleton(v1851_3_head);
    const Space v1852_3 = intersect(constant_5,v1852_2);
    const Space v1852_4 = (has_head(v1852_3) ? constant_7 : Space{});
    const Space v1852_5 = compose(v1852_4,v1851_3_tail);
    v1851_3_result = unite(v1851_3_result,v1852_5);
  }
  const Space v1851_3 = std::move(v1851_3_result);
  return v1851_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
