#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("125 3 1 2 3 3 1 2 4 3 1 2 7 3 1 2 10 3 1 2 18 3 1 2 19 3 1 2 23 3 1 2 24 3 1 2 25 3 1 3 7 3 1 3 16 3 1 3 17 3 1 3 18 3 1 3 23 3 1 3 24 3 1 3 25 3 1 4 5 3 1 4 6 3 1 4 10 3 1 4 16 3 1 4 17 3 1 4 19 3 1 4 20 3 1 4 21 3 1 5 2 3 1 5 7 3 1 5 18 3 1 5 24 3 1 7 4 3 1 7 21 3 1 7 23 3 1 7 24 3 1 8 4 3 1 8 5 3 1 8 9 3 1 8 19 3 1 8 23 3 1 9 2 3 1 9 7 3 1 9 11 3 1 9 14 3 1 9 15 3 1 9 16 3 1 9 17 3 1 9 25 3 1 10 2 3 1 10 8 3 1 10 13 3 1 10 21 3 1 11 12 3 1 11 16 3 1 11 23 3 1 11 25 3 1 12 8 3 1 12 11 3 1 12 14 3 1 12 16 3 1 12 17 3 1 12 24 3 1 12 25 3 1 12 26 3 1 13 5 3 1 13 9 3 1 13 15 3 1 13 18 3 1 14 3 3 1 14 5 3 1 14 11 3 1 14 14 3 1 14 17 3 1 14 19 3 1 14 21 3 1 14 22 3 1 14 23 3 1 15 2 3 1 15 7 3 1 15 9 3 1 15 12 3 1 15 21 3 1 15 22 3 1 16 5 3 1 16 11 3 1 16 13 3 1 16 14 3 1 16 16 3 1 16 17 3 1 16 19 3 1 16 22 3 1 16 23 3 1 17 3 3 1 17 5 3 1 17 8 3 1 17 13 3 1 17 16 3 1 17 17 3 1 17 18 3 1 17 21 3 1 17 23 3 1 18 2 3 1 18 3 3 1 18 9 3 1 18 21 3 1 19 18 3 1 20 8 3 1 20 13 3 1 21 10 3 1 21 15 3 1 22 8 3 1 22 16 3 1 22 22 3 1 22 24 3 1 22 25 3 1 23 19 3 1 23 23 3 1 24 3 3 1 24 9 3 1 24 17 3 1 24 22 3 1 25 3 3 1 25 4 3 1 25 8 3 1 25 13 3 1 25 15 3 1 25 21 3 1 25 24");
static Space routine_0(Context& c);
static Space routine_0(Context& c) {
  return constant_0;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"26 1 4 67 101 108 108 2 1 57 3 1 52 4 2 49 48 5 2 49 51 6 2 50 52 7 1 56 8 1 49 9 2 49 52 10 2 50 50 11 1 53 12 2 49 53 13 1 50 14 2 49 55 15 2 50 49 16 2 49 56 17 1 54 18 2 50 48 19 2 49 50 20 2 50 51 21 1 51 22 2 49 54 23 2 49 49 24 2 49 57 25 1 55 26 1 48"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
