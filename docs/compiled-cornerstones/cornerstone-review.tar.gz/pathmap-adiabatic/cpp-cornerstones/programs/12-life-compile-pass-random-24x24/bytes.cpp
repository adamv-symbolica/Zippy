#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,2};
static const Space constant_1 = literal_text("2 4 1 1 1 3 4 1 1 1 4");
static const Path constant_2 = Path{1,1,1,3};
static const Space constant_3 = literal_text("5 4 1 1 1 9 4 1 1 1 10 4 1 1 1 11 4 1 1 1 12 4 1 1 1 13");
static const Path constant_4 = Path{1,1,1,4};
static const Space constant_5 = literal_text("5 4 1 1 1 4 4 1 1 1 9 4 1 1 1 11 4 1 1 1 14 4 1 1 1 15");
static const Path constant_6 = Path{1,1,1,5};
static const Space constant_7 = literal_text("3 4 1 1 1 6 4 1 1 1 7 4 1 1 1 8");
static const Path constant_8 = Path{1,1,1,6};
static const Space constant_9 = literal_text("4 4 1 1 1 7 4 1 1 1 8 4 1 1 1 13 4 1 1 1 19");
static const Path constant_10 = Path{1,1,1,7};
static const Space constant_11 = literal_text("5 4 1 1 1 2 4 1 1 1 10 4 1 1 1 12 4 1 1 1 13 4 1 1 1 20");
static const Path constant_12 = Path{1,1,1,8};
static const Space constant_13 = literal_text("5 4 1 1 1 13 4 1 1 1 15 4 1 1 1 18 4 1 1 1 21 4 1 1 1 24");
static const Path constant_14 = Path{1,1,1,9};
static const Space constant_15 = literal_text("3 4 1 1 1 16 4 1 1 1 17 4 1 1 1 18");
static const Path constant_16 = Path{1,1,1,10};
static const Space constant_17 = literal_text("7 4 1 1 1 3 4 1 1 1 6 4 1 1 1 9 4 1 1 1 15 4 1 1 1 21 4 1 1 1 22 4 1 1 1 25");
static const Path constant_18 = Path{1,1,1,11};
static const Space constant_19 = literal_text("5 4 1 1 1 5 4 1 1 1 13 4 1 1 1 15 4 1 1 1 18 4 1 1 1 24");
static const Path constant_20 = Path{1,1,1,12};
static const Space constant_21 = literal_text("6 4 1 1 1 5 4 1 1 1 7 4 1 1 1 8 4 1 1 1 12 4 1 1 1 18 4 1 1 1 23");
static const Path constant_22 = Path{1,1,1,13};
static const Space constant_23 = literal_text("8 4 1 1 1 9 4 1 1 1 11 4 1 1 1 14 4 1 1 1 15 4 1 1 1 17 4 1 1 1 22 4 1 1 1 23 4 1 1 1 24");
static const Path constant_24 = Path{1,1,1,14};
static const Space constant_25 = literal_text("5 4 1 1 1 5 4 1 1 1 15 4 1 1 1 18 4 1 1 1 19 4 1 1 1 24");
static const Path constant_26 = Path{1,1,1,15};
static const Space constant_27 = literal_text("5 4 1 1 1 3 4 1 1 1 9 4 1 1 1 10 4 1 1 1 17 4 1 1 1 24");
static const Path constant_28 = Path{1,1,1,16};
static const Space constant_29 = literal_text("1 4 1 1 1 2");
static const Path constant_30 = Path{1,1,1,17};
static const Space constant_31 = literal_text("3 4 1 1 1 10 4 1 1 1 14 4 1 1 1 19");
static const Path constant_32 = Path{1,1,1,18};
static const Space constant_33 = literal_text("3 4 1 1 1 3 4 1 1 1 6 4 1 1 1 19");
static const Path constant_34 = Path{1,1,1,19};
static const Space constant_35 = literal_text("5 4 1 1 1 6 4 1 1 1 13 4 1 1 1 20 4 1 1 1 21 4 1 1 1 23");
static const Path constant_36 = Path{1,1,1,20};
static const Space constant_37 = literal_text("6 4 1 1 1 4 4 1 1 1 12 4 1 1 1 13 4 1 1 1 15 4 1 1 1 17 4 1 1 1 19");
static const Path constant_38 = Path{1,1,1,21};
static const Space constant_39 = literal_text("8 4 1 1 1 5 4 1 1 1 8 4 1 1 1 12 4 1 1 1 14 4 1 1 1 15 4 1 1 1 16 4 1 1 1 17 4 1 1 1 22");
static const Path constant_40 = Path{1,1,1,22};
static const Space constant_41 = literal_text("9 4 1 1 1 9 4 1 1 1 10 4 1 1 1 12 4 1 1 1 13 4 1 1 1 14 4 1 1 1 16 4 1 1 1 18 4 1 1 1 23 4 1 1 1 24");
static const Path constant_42 = Path{1,1,1,23};
static const Space constant_43 = literal_text("7 4 1 1 1 4 4 1 1 1 8 4 1 1 1 11 4 1 1 1 16 4 1 1 1 17 4 1 1 1 20 4 1 1 1 21");
static const Path constant_44 = Path{1,1,1,24};
static const Space constant_45 = literal_text("7 4 1 1 1 3 4 1 1 1 5 4 1 1 1 7 4 1 1 1 8 4 1 1 1 15 4 1 1 1 17 4 1 1 1 23");
static const Path constant_46 = Path{1,1,1,25};
static const Space constant_47 = literal_text("3 4 1 1 1 16 4 1 1 1 18 4 1 1 1 25");
static const Space constant_48 = literal_text("120 12 1 1 1 1 1 1 1 2 1 1 1 3 12 1 1 1 1 1 1 1 2 1 1 1 4 12 1 1 1 1 1 1 1 3 1 1 1 9 12 1 1 1 1 1 1 1 3 1 1 1 10 12 1 1 1 1 1 1 1 3 1 1 1 11 12 1 1 1 1 1 1 1 3 1 1 1 12 12 1 1 1 1 1 1 1 3 1 1 1 13 12 1 1 1 1 1 1 1 4 1 1 1 4 12 1 1 1 1 1 1 1 4 1 1 1 9 12 1 1 1 1 1 1 1 4 1 1 1 11 12 1 1 1 1 1 1 1 4 1 1 1 14 12 1 1 1 1 1 1 1 4 1 1 1 15 12 1 1 1 1 1 1 1 5 1 1 1 6 12 1 1 1 1 1 1 1 5 1 1 1 7 12 1 1 1 1 1 1 1 5 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 7 12 1 1 1 1 1 1 1 6 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 13 12 1 1 1 1 1 1 1 6 1 1 1 19 12 1 1 1 1 1 1 1 7 1 1 1 2 12 1 1 1 1 1 1 1 7 1 1 1 10 12 1 1 1 1 1 1 1 7 1 1 1 12 12 1 1 1 1 1 1 1 7 1 1 1 13 12 1 1 1 1 1 1 1 7 1 1 1 20 12 1 1 1 1 1 1 1 8 1 1 1 13 12 1 1 1 1 1 1 1 8 1 1 1 15 12 1 1 1 1 1 1 1 8 1 1 1 18 12 1 1 1 1 1 1 1 8 1 1 1 21 12 1 1 1 1 1 1 1 8 1 1 1 24 12 1 1 1 1 1 1 1 9 1 1 1 16 12 1 1 1 1 1 1 1 9 1 1 1 17 12 1 1 1 1 1 1 1 9 1 1 1 18 12 1 1 1 1 1 1 1 10 1 1 1 3 12 1 1 1 1 1 1 1 10 1 1 1 6 12 1 1 1 1 1 1 1 10 1 1 1 9 12 1 1 1 1 1 1 1 10 1 1 1 15 12 1 1 1 1 1 1 1 10 1 1 1 21 12 1 1 1 1 1 1 1 10 1 1 1 22 12 1 1 1 1 1 1 1 10 1 1 1 25 12 1 1 1 1 1 1 1 11 1 1 1 5 12 1 1 1 1 1 1 1 11 1 1 1 13 12 1 1 1 1 1 1 1 11 1 1 1 15 12 1 1 1 1 1 1 1 11 1 1 1 18 12 1 1 1 1 1 1 1 11 1 1 1 24 12 1 1 1 1 1 1 1 12 1 1 1 5 12 1 1 1 1 1 1 1 12 1 1 1 7 12 1 1 1 1 1 1 1 12 1 1 1 8 12 1 1 1 1 1 1 1 12 1 1 1 12 12 1 1 1 1 1 1 1 12 1 1 1 18 12 1 1 1 1 1 1 1 12 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 9 12 1 1 1 1 1 1 1 13 1 1 1 11 12 1 1 1 1 1 1 1 13 1 1 1 14 12 1 1 1 1 1 1 1 13 1 1 1 15 12 1 1 1 1 1 1 1 13 1 1 1 17 12 1 1 1 1 1 1 1 13 1 1 1 22 12 1 1 1 1 1 1 1 13 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 24 12 1 1 1 1 1 1 1 14 1 1 1 5 12 1 1 1 1 1 1 1 14 1 1 1 15 12 1 1 1 1 1 1 1 14 1 1 1 18 12 1 1 1 1 1 1 1 14 1 1 1 19 12 1 1 1 1 1 1 1 14 1 1 1 24 12 1 1 1 1 1 1 1 15 1 1 1 3 12 1 1 1 1 1 1 1 15 1 1 1 9 12 1 1 1 1 1 1 1 15 1 1 1 10 12 1 1 1 1 1 1 1 15 1 1 1 17 12 1 1 1 1 1 1 1 15 1 1 1 24 12 1 1 1 1 1 1 1 16 1 1 1 2 12 1 1 1 1 1 1 1 17 1 1 1 10 12 1 1 1 1 1 1 1 17 1 1 1 14 12 1 1 1 1 1 1 1 17 1 1 1 19 12 1 1 1 1 1 1 1 18 1 1 1 3 12 1 1 1 1 1 1 1 18 1 1 1 6 12 1 1 1 1 1 1 1 18 1 1 1 19 12 1 1 1 1 1 1 1 19 1 1 1 6 12 1 1 1 1 1 1 1 19 1 1 1 13 12 1 1 1 1 1 1 1 19 1 1 1 20 12 1 1 1 1 1 1 1 19 1 1 1 21 12 1 1 1 1 1 1 1 19 1 1 1 23 12 1 1 1 1 1 1 1 20 1 1 1 4 12 1 1 1 1 1 1 1 20 1 1 1 12 12 1 1 1 1 1 1 1 20 1 1 1 13 12 1 1 1 1 1 1 1 20 1 1 1 15 12 1 1 1 1 1 1 1 20 1 1 1 17 12 1 1 1 1 1 1 1 20 1 1 1 19 12 1 1 1 1 1 1 1 21 1 1 1 5 12 1 1 1 1 1 1 1 21 1 1 1 8 12 1 1 1 1 1 1 1 21 1 1 1 12 12 1 1 1 1 1 1 1 21 1 1 1 14 12 1 1 1 1 1 1 1 21 1 1 1 15 12 1 1 1 1 1 1 1 21 1 1 1 16 12 1 1 1 1 1 1 1 21 1 1 1 17 12 1 1 1 1 1 1 1 21 1 1 1 22 12 1 1 1 1 1 1 1 22 1 1 1 9 12 1 1 1 1 1 1 1 22 1 1 1 10 12 1 1 1 1 1 1 1 22 1 1 1 12 12 1 1 1 1 1 1 1 22 1 1 1 13 12 1 1 1 1 1 1 1 22 1 1 1 14 12 1 1 1 1 1 1 1 22 1 1 1 16 12 1 1 1 1 1 1 1 22 1 1 1 18 12 1 1 1 1 1 1 1 22 1 1 1 23 12 1 1 1 1 1 1 1 22 1 1 1 24 12 1 1 1 1 1 1 1 23 1 1 1 4 12 1 1 1 1 1 1 1 23 1 1 1 8 12 1 1 1 1 1 1 1 23 1 1 1 11 12 1 1 1 1 1 1 1 23 1 1 1 16 12 1 1 1 1 1 1 1 23 1 1 1 17 12 1 1 1 1 1 1 1 23 1 1 1 20 12 1 1 1 1 1 1 1 23 1 1 1 21 12 1 1 1 1 1 1 1 24 1 1 1 3 12 1 1 1 1 1 1 1 24 1 1 1 5 12 1 1 1 1 1 1 1 24 1 1 1 7 12 1 1 1 1 1 1 1 24 1 1 1 8 12 1 1 1 1 1 1 1 24 1 1 1 15 12 1 1 1 1 1 1 1 24 1 1 1 17 12 1 1 1 1 1 1 1 24 1 1 1 23 12 1 1 1 1 1 1 1 25 1 1 1 16 12 1 1 1 1 1 1 1 25 1 1 1 18 12 1 1 1 1 1 1 1 25 1 1 1 25");
static const Path constant_49 = Path{1,1,1,1};
static const Space constant_50 = literal_text("387 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 8 8 1 1 1 8 1 1 1 17 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 4 8 1 1 1 9 1 1 1 6 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 10 1 1 1 17 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 11 8 1 1 1 11 1 1 1 25 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 12 8 1 1 1 12 1 1 1 15 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 13 1 1 1 13 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 14 8 1 1 1 14 1 1 1 18 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 15 1 1 1 15 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 16 8 1 1 1 16 1 1 1 21 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 17 1 1 1 10 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 5 8 1 1 1 18 1 1 1 14 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 8 8 1 1 1 19 1 1 1 19 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 20 1 1 1 20 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 21 1 1 1 16 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 10 8 1 1 1 22 1 1 1 16 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 14 8 1 1 1 23 1 1 1 15 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 12 8 1 1 1 24 1 1 1 20 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 11 8 1 1 1 25 1 1 1 19 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 2 8 1 1 1 26 1 1 1 26 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 27 1 1 1 40 8 1 1 1 28 1 1 1 28 8 1 1 1 28 1 1 1 29 8 1 1 1 28 1 1 1 30 8 1 1 1 29 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 29 1 1 1 31 8 1 1 1 30 1 1 1 28 8 1 1 1 30 1 1 1 30 8 1 1 1 30 1 1 1 90 8 1 1 1 31 1 1 1 29 8 1 1 1 31 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 38 1 1 1 39 8 1 1 1 39 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 39 1 1 1 41 8 1 1 1 40 1 1 1 27 8 1 1 1 40 1 1 1 40 8 1 1 1 40 1 1 1 51 8 1 1 1 41 1 1 1 39 8 1 1 1 41 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 49 1 1 1 50 8 1 1 1 50 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 50 1 1 1 52 8 1 1 1 51 1 1 1 40 8 1 1 1 51 1 1 1 51 8 1 1 1 51 1 1 1 62 8 1 1 1 52 1 1 1 50 8 1 1 1 52 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 60 1 1 1 61 8 1 1 1 61 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 61 1 1 1 63 8 1 1 1 62 1 1 1 51 8 1 1 1 62 1 1 1 62 8 1 1 1 62 1 1 1 73 8 1 1 1 63 1 1 1 61 8 1 1 1 63 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 71 1 1 1 72 8 1 1 1 72 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 72 1 1 1 74 8 1 1 1 73 1 1 1 62 8 1 1 1 73 1 1 1 73 8 1 1 1 73 1 1 1 84 8 1 1 1 74 1 1 1 72 8 1 1 1 74 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 82 1 1 1 83 8 1 1 1 83 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 83 1 1 1 85 8 1 1 1 84 1 1 1 73 8 1 1 1 84 1 1 1 84 8 1 1 1 84 1 1 1 90 8 1 1 1 85 1 1 1 83 8 1 1 1 85 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 88 1 1 1 87 8 1 1 1 88 1 1 1 88 8 1 1 1 88 1 1 1 89 8 1 1 1 90 1 1 1 30 8 1 1 1 90 1 1 1 84 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 11 8 1 1 1 91 1 1 1 91 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 130 8 1 1 1 131 1 1 1 131 8 1 1 1 131 1 1 1 132");
static const Space constant_51 = singleton(Path{});
static const Space constant_52 = literal_text("1 0 ");
static const Space constant_53 = literal_text("1 4 1 1 1 133");
static const Path constant_54 = Path{};
static const std::vector<Path> constant_55 = paths_text("133 4 1 1 1 26 4 1 1 1 28 4 1 1 1 29 4 1 1 1 31 4 1 1 1 32 4 1 1 1 33 4 1 1 1 34 4 1 1 1 35 4 1 1 1 36 4 1 1 1 37 4 1 1 1 38 4 1 1 1 27 4 1 1 1 39 4 1 1 1 41 4 1 1 1 42 4 1 1 1 43 4 1 1 1 44 4 1 1 1 45 4 1 1 1 46 4 1 1 1 47 4 1 1 1 48 4 1 1 1 49 4 1 1 1 40 4 1 1 1 50 4 1 1 1 52 4 1 1 1 53 4 1 1 1 54 4 1 1 1 55 4 1 1 1 56 4 1 1 1 57 4 1 1 1 58 4 1 1 1 59 4 1 1 1 60 4 1 1 1 51 4 1 1 1 61 4 1 1 1 63 4 1 1 1 64 4 1 1 1 65 4 1 1 1 66 4 1 1 1 67 4 1 1 1 68 4 1 1 1 69 4 1 1 1 70 4 1 1 1 71 4 1 1 1 62 4 1 1 1 72 4 1 1 1 74 4 1 1 1 75 4 1 1 1 76 4 1 1 1 77 4 1 1 1 78 4 1 1 1 79 4 1 1 1 80 4 1 1 1 81 4 1 1 1 82 4 1 1 1 73 4 1 1 1 83 4 1 1 1 85 4 1 1 1 86 4 1 1 1 87 4 1 1 1 88 4 1 1 1 89 4 1 1 1 84 4 1 1 1 90 4 1 1 1 30 4 1 1 1 2 4 1 1 1 5 4 1 1 1 3 4 1 1 1 4 4 1 1 1 9 4 1 1 1 6 4 1 1 1 7 4 1 1 1 21 4 1 1 1 16 4 1 1 1 22 4 1 1 1 10 4 1 1 1 17 4 1 1 1 18 4 1 1 1 8 4 1 1 1 19 4 1 1 1 25 4 1 1 1 11 4 1 1 1 91 4 1 1 1 92 4 1 1 1 93 4 1 1 1 94 4 1 1 1 95 4 1 1 1 96 4 1 1 1 14 4 1 1 1 97 4 1 1 1 98 4 1 1 1 99 4 1 1 1 100 4 1 1 1 101 4 1 1 1 102 4 1 1 1 103 4 1 1 1 104 4 1 1 1 105 4 1 1 1 106 4 1 1 1 23 4 1 1 1 107 4 1 1 1 108 4 1 1 1 109 4 1 1 1 110 4 1 1 1 111 4 1 1 1 112 4 1 1 1 113 4 1 1 1 114 4 1 1 1 115 4 1 1 1 116 4 1 1 1 15 4 1 1 1 117 4 1 1 1 118 4 1 1 1 119 4 1 1 1 120 4 1 1 1 121 4 1 1 1 122 4 1 1 1 123 4 1 1 1 124 4 1 1 1 125 4 1 1 1 126 4 1 1 1 12 4 1 1 1 127 4 1 1 1 128 4 1 1 1 129 4 1 1 1 130 4 1 1 1 131 4 1 1 1 132 4 1 1 1 24 4 1 1 1 20 4 1 1 1 13 4 1 1 1 1 4 1 1 1 133");
static Space routine_0(Context& c);
static Space routine_16(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Space& s0);
static Space routine_15(Context& c, const Space& s0);
static Space routine_14(Context& c, const Space& s0);
static Space routine_4(Context& c, const Space& s0);
static Space routine_6(Context& c, const Space& s0);
static Space routine_9(Context& c, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_0(Context& c) {
  const Space v0_2 = routine_1(c, constant_0, constant_1);
  const Space v0_5 = routine_1(c, constant_2, constant_3);
  const Space v0_6 = unite(v0_2,v0_5);
  const Space v0_9 = routine_1(c, constant_4, constant_5);
  const Space v0_10 = unite(v0_6,v0_9);
  const Space v0_13 = routine_1(c, constant_6, constant_7);
  const Space v0_14 = unite(v0_10,v0_13);
  const Space v0_17 = routine_1(c, constant_8, constant_9);
  const Space v0_18 = unite(v0_14,v0_17);
  const Space v0_21 = routine_1(c, constant_10, constant_11);
  const Space v0_22 = unite(v0_18,v0_21);
  const Space v0_25 = routine_1(c, constant_12, constant_13);
  const Space v0_26 = unite(v0_22,v0_25);
  const Space v0_29 = routine_1(c, constant_14, constant_15);
  const Space v0_30 = unite(v0_26,v0_29);
  const Space v0_33 = routine_1(c, constant_16, constant_17);
  const Space v0_34 = unite(v0_30,v0_33);
  const Space v0_37 = routine_1(c, constant_18, constant_19);
  const Space v0_38 = unite(v0_34,v0_37);
  const Space v0_41 = routine_1(c, constant_20, constant_21);
  const Space v0_42 = unite(v0_38,v0_41);
  const Space v0_45 = routine_1(c, constant_22, constant_23);
  const Space v0_46 = unite(v0_42,v0_45);
  const Space v0_49 = routine_1(c, constant_24, constant_25);
  const Space v0_50 = unite(v0_46,v0_49);
  const Space v0_53 = routine_1(c, constant_26, constant_27);
  const Space v0_54 = unite(v0_50,v0_53);
  const Space v0_57 = routine_1(c, constant_28, constant_29);
  const Space v0_58 = unite(v0_54,v0_57);
  const Space v0_61 = routine_1(c, constant_30, constant_31);
  const Space v0_62 = unite(v0_58,v0_61);
  const Space v0_65 = routine_1(c, constant_32, constant_33);
  const Space v0_66 = unite(v0_62,v0_65);
  const Space v0_69 = routine_1(c, constant_34, constant_35);
  const Space v0_70 = unite(v0_66,v0_69);
  const Space v0_73 = routine_1(c, constant_36, constant_37);
  const Space v0_74 = unite(v0_70,v0_73);
  const Space v0_77 = routine_1(c, constant_38, constant_39);
  const Space v0_78 = unite(v0_74,v0_77);
  const Space v0_81 = routine_1(c, constant_40, constant_41);
  const Space v0_82 = unite(v0_78,v0_81);
  const Space v0_85 = routine_1(c, constant_42, constant_43);
  const Space v0_86 = unite(v0_82,v0_85);
  const Space v0_89 = routine_1(c, constant_44, constant_45);
  const Space v0_90 = unite(v0_86,v0_89);
  const Space v0_93 = routine_1(c, constant_46, constant_47);
  const Space v0_94 = unite(v0_90,v0_93);
  const auto v0_96_branches = branches(c,v0_94);
  std::vector<Space> v0_96_outputs;
  v0_96_outputs.reserve(v0_96_branches.size());
  for (const auto& v0_96_branch : v0_96_branches) {
    const Path v0_96_head{v0_96_branch.first};
    const Space& v0_96_tail = v0_96_branch.second;
    const auto v1_2_branches = branches(c,v0_96_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_96_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const Space v4_3 = routine_2(c, v4_2, v3_3_tail, constant_48);
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_96_outputs.push_back(v1_2);
  }
  const Space v0_96 = join_outputs(std::move(v0_96_outputs));
  const Space v0_99 = routine_3(c, constant_0, constant_1, constant_48);
  const Space v0_100 = unite(v0_96,v0_99);
  const Space v0_103 = routine_3(c, constant_2, constant_3, constant_48);
  const Space v0_104 = unite(v0_100,v0_103);
  const Space v0_107 = routine_3(c, constant_4, constant_5, constant_48);
  const Space v0_108 = unite(v0_104,v0_107);
  const Space v0_111 = routine_3(c, constant_6, constant_7, constant_48);
  const Space v0_112 = unite(v0_108,v0_111);
  const Space v0_115 = routine_3(c, constant_8, constant_9, constant_48);
  const Space v0_116 = unite(v0_112,v0_115);
  const Space v0_119 = routine_3(c, constant_10, constant_11, constant_48);
  const Space v0_120 = unite(v0_116,v0_119);
  const Space v0_123 = routine_3(c, constant_12, constant_13, constant_48);
  const Space v0_124 = unite(v0_120,v0_123);
  const Space v0_127 = routine_3(c, constant_14, constant_15, constant_48);
  const Space v0_128 = unite(v0_124,v0_127);
  const Space v0_131 = routine_3(c, constant_16, constant_17, constant_48);
  const Space v0_132 = unite(v0_128,v0_131);
  const Space v0_135 = routine_3(c, constant_18, constant_19, constant_48);
  const Space v0_136 = unite(v0_132,v0_135);
  const Space v0_139 = routine_3(c, constant_20, constant_21, constant_48);
  const Space v0_140 = unite(v0_136,v0_139);
  const Space v0_143 = routine_3(c, constant_22, constant_23, constant_48);
  const Space v0_144 = unite(v0_140,v0_143);
  const Space v0_147 = routine_3(c, constant_24, constant_25, constant_48);
  const Space v0_148 = unite(v0_144,v0_147);
  const Space v0_151 = routine_3(c, constant_26, constant_27, constant_48);
  const Space v0_152 = unite(v0_148,v0_151);
  const Space v0_155 = routine_3(c, constant_28, constant_29, constant_48);
  const Space v0_156 = unite(v0_152,v0_155);
  const Space v0_159 = routine_3(c, constant_30, constant_31, constant_48);
  const Space v0_160 = unite(v0_156,v0_159);
  const Space v0_163 = routine_3(c, constant_32, constant_33, constant_48);
  const Space v0_164 = unite(v0_160,v0_163);
  const Space v0_167 = routine_3(c, constant_34, constant_35, constant_48);
  const Space v0_168 = unite(v0_164,v0_167);
  const Space v0_171 = routine_3(c, constant_36, constant_37, constant_48);
  const Space v0_172 = unite(v0_168,v0_171);
  const Space v0_175 = routine_3(c, constant_38, constant_39, constant_48);
  const Space v0_176 = unite(v0_172,v0_175);
  const Space v0_179 = routine_3(c, constant_40, constant_41, constant_48);
  const Space v0_180 = unite(v0_176,v0_179);
  const Space v0_183 = routine_3(c, constant_42, constant_43, constant_48);
  const Space v0_184 = unite(v0_180,v0_183);
  const Space v0_187 = routine_3(c, constant_44, constant_45, constant_48);
  const Space v0_188 = unite(v0_184,v0_187);
  const Space v0_191 = routine_3(c, constant_46, constant_47, constant_48);
  const Space v0_192 = unite(v0_188,v0_191);
  const Space v0_194 = wrap(v0_192,constant_49);
  return v0_194;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  const Space v5_4 = unwrap(constant_50,p0);
  const auto v5_5_branches = branches(c,s0);
  std::vector<Space> v5_5_outputs;
  v5_5_outputs.reserve(v5_5_branches.size());
  for (const auto& v5_5_branch : v5_5_branches) {
    const Path v5_5_head{v5_5_branch.first};
    const Space& v5_5_tail = v5_5_branch.second;
    const Space v6_2 = unwrap(constant_50,v5_5_head);
    const auto v6_3_branches = branches(c,v5_5_tail);
    std::vector<Space> v6_3_outputs;
    v6_3_outputs.reserve(v6_3_branches.size());
    for (const auto& v6_3_branch : v6_3_branches) {
      const Path v6_3_head{v6_3_branch.first};
      const Space& v6_3_tail = v6_3_branch.second;
      const Path v7_2 = concat_path(v5_5_head,v6_3_head);
      const Space v7_3 = unwrap(v6_2,v6_3_head);
      const auto v7_4_branches = branches(c,v6_3_tail);
      std::vector<Space> v7_4_outputs;
      v7_4_outputs.reserve(v7_4_branches.size());
      for (const auto& v7_4_branch : v7_4_branches) {
        const Path v7_4_head{v7_4_branch.first};
        const Space& v7_4_tail = v7_4_branch.second;
        const Space v8_2 = unwrap(v7_3,v7_4_head);
        const Path v8_3 = concat_path(v7_2,v7_4_head);
        const auto v8_4_branches = branches(c,v7_4_tail);
        std::vector<Space> v8_4_outputs;
        v8_4_outputs.reserve(v8_4_branches.size());
        for (const auto& v8_4_branch : v8_4_branches) {
          const Path v8_4_head{v8_4_branch.first};
          const Space& v8_4_tail = v8_4_branch.second;
          const Space v9_2 = unwrap(v8_2,v8_4_head);
          const Space v9_3 = compose(v5_4,v9_2);
          const Path v9_4 = concat_path(v8_3,v8_4_head);
          const Path v9_5 = concat_path(p0,v9_4);
          const Space v9_6 = singleton(v9_5);
          const Space v9_7 = subtract(v9_3,v9_6);
          v8_4_outputs.push_back(v9_7);
        }
        const Space v8_4 = join_outputs(std::move(v8_4_outputs));
        v7_4_outputs.push_back(v8_4);
      }
      const Space v7_4 = join_outputs(std::move(v7_4_outputs));
      v6_3_outputs.push_back(v7_4);
    }
    const Space v6_3 = join_outputs(std::move(v6_3_outputs));
    v5_5_outputs.push_back(v6_3);
  }
  const Space v5_5 = join_outputs(std::move(v5_5_outputs));
  return v5_5;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v10_8 = unwrap(constant_50,p0);
  const Space v10_9 = unwrap(s1,constant_49);
  const Space v10_10 = unwrap(constant_50,p0);
  const auto v10_11_branches = branches(c,s0);
  std::vector<Space> v10_11_outputs;
  v10_11_outputs.reserve(v10_11_branches.size());
  for (const auto& v10_11_branch : v10_11_branches) {
    const Path v10_11_head{v10_11_branch.first};
    const Space& v10_11_tail = v10_11_branch.second;
    const Space v11_2 = unwrap(constant_50,v10_11_head);
    const Space v11_3 = unwrap(constant_50,v10_11_head);
    const auto v11_4_branches = branches(c,v10_11_tail);
    std::vector<Space> v11_4_outputs;
    v11_4_outputs.reserve(v11_4_branches.size());
    for (const auto& v11_4_branch : v11_4_branches) {
      const Path v11_4_head{v11_4_branch.first};
      const Space& v11_4_tail = v11_4_branch.second;
      const Path v12_2 = concat_path(v10_11_head,v11_4_head);
      const Space v12_3 = unwrap(v11_2,v11_4_head);
      const Space v12_4 = unwrap(v11_3,v11_4_head);
      const auto v12_5_branches = branches(c,v11_4_tail);
      std::vector<Space> v12_5_outputs;
      v12_5_outputs.reserve(v12_5_branches.size());
      for (const auto& v12_5_branch : v12_5_branches) {
        const Path v12_5_head{v12_5_branch.first};
        const Space& v12_5_tail = v12_5_branch.second;
        const Space v13_2 = unwrap(v12_3,v12_5_head);
        const Path v13_3 = concat_path(v12_2,v12_5_head);
        const Space v13_4 = unwrap(v12_4,v12_5_head);
        const auto v13_5_branches = branches(c,v12_5_tail);
        std::vector<Space> v13_5_outputs;
        v13_5_outputs.reserve(v13_5_branches.size());
        for (const auto& v13_5_branch : v13_5_branches) {
          const Path v13_5_head{v13_5_branch.first};
          const Space& v13_5_tail = v13_5_branch.second;
          const Space v14_2 = unwrap(v13_2,v13_5_head);
          const Space v14_3 = compose(v10_8,v14_2);
          const Path v14_4 = concat_path(v13_3,v13_5_head);
          const Path v14_5 = concat_path(p0,v14_4);
          const Space v14_6 = singleton(v14_5);
          const Space v14_7 = subtract(v14_3,v14_6);
          const Space v14_8 = intersect(v14_7,v10_9);
          const Space v14_9 = routine_4(c, v14_8);
          const auto v14_10_branches = branches(c,v14_9);
          std::vector<Space> v14_10_outputs;
          v14_10_outputs.reserve(v14_10_branches.size());
          for (const auto& v14_10_branch : v14_10_branches) {
            const Path v14_10_head{v14_10_branch.first};
            const Space& v14_10_tail = v14_10_branch.second;
            const auto v15_2_branches = branches(c,v14_10_tail);
            std::vector<Space> v15_2_outputs;
            v15_2_outputs.reserve(v15_2_branches.size());
            for (const auto& v15_2_branch : v15_2_branches) {
              const Path v15_2_head{v15_2_branch.first};
              const Space& v15_2_tail = v15_2_branch.second;
              const Path v16_2 = concat_path(v14_10_head,v15_2_head);
              const auto v16_3_branches = branches(c,v15_2_tail);
              std::vector<Space> v16_3_outputs;
              v16_3_outputs.reserve(v16_3_branches.size());
              for (const auto& v16_3_branch : v16_3_branches) {
                const Path v16_3_head{v16_3_branch.first};
                const Space& v16_3_tail = v16_3_branch.second;
                const Path v17_2 = concat_path(v16_2,v16_3_head);
                const auto v17_3_branches = branches(c,v16_3_tail);
                std::vector<Space> v17_3_outputs;
                v17_3_outputs.reserve(v17_3_branches.size());
                for (const auto& v17_3_branch : v17_3_branches) {
                  const Path v17_3_head{v17_3_branch.first};
                  const Space& v17_3_tail = v17_3_branch.second;
                  const Path v18_2 = concat_path(v17_2,v17_3_head);
                  const Space v18_3 = routine_5(c, v18_2, v17_3_tail);
                  v17_3_outputs.push_back(v18_3);
                }
                const Space v17_3 = join_outputs(std::move(v17_3_outputs));
                v16_3_outputs.push_back(v17_3);
              }
              const Space v16_3 = join_outputs(std::move(v16_3_outputs));
              v15_2_outputs.push_back(v16_3);
            }
            const Space v15_2 = join_outputs(std::move(v15_2_outputs));
            v14_10_outputs.push_back(v15_2);
          }
          const Space v14_10 = join_outputs(std::move(v14_10_outputs));
          const Space v14_11 = unwrap(v13_4,v13_5_head);
          const Space v14_12 = compose(v10_10,v14_11);
          const Space v14_13 = subtract(v14_12,v14_6);
          const Space v14_14 = intersect(v14_13,v10_9);
          const Space v14_15 = routine_6(c, v14_14);
          const auto v14_16_branches = branches(c,v14_15);
          std::vector<Space> v14_16_outputs;
          v14_16_outputs.reserve(v14_16_branches.size());
          for (const auto& v14_16_branch : v14_16_branches) {
            const Path v14_16_head{v14_16_branch.first};
            const Space& v14_16_tail = v14_16_branch.second;
            const auto v19_2_branches = branches(c,v14_16_tail);
            std::vector<Space> v19_2_outputs;
            v19_2_outputs.reserve(v19_2_branches.size());
            for (const auto& v19_2_branch : v19_2_branches) {
              const Path v19_2_head{v19_2_branch.first};
              const Space& v19_2_tail = v19_2_branch.second;
              const Path v20_2 = concat_path(v14_16_head,v19_2_head);
              const auto v20_3_branches = branches(c,v19_2_tail);
              std::vector<Space> v20_3_outputs;
              v20_3_outputs.reserve(v20_3_branches.size());
              for (const auto& v20_3_branch : v20_3_branches) {
                const Path v20_3_head{v20_3_branch.first};
                const Space& v20_3_tail = v20_3_branch.second;
                const Path v21_2 = concat_path(v20_2,v20_3_head);
                const auto v21_3_branches = branches(c,v20_3_tail);
                std::vector<Space> v21_3_outputs;
                v21_3_outputs.reserve(v21_3_branches.size());
                for (const auto& v21_3_branch : v21_3_branches) {
                  const Path v21_3_head{v21_3_branch.first};
                  const Space& v21_3_tail = v21_3_branch.second;
                  const Path v22_2 = concat_path(v21_2,v21_3_head);
                  const Space v22_3 = routine_7(c, v22_2, v21_3_tail);
                  v21_3_outputs.push_back(v22_3);
                }
                const Space v21_3 = join_outputs(std::move(v21_3_outputs));
                v20_3_outputs.push_back(v21_3);
              }
              const Space v20_3 = join_outputs(std::move(v20_3_outputs));
              v19_2_outputs.push_back(v20_3);
            }
            const Space v19_2 = join_outputs(std::move(v19_2_outputs));
            v14_16_outputs.push_back(v19_2);
          }
          const Space v14_16 = join_outputs(std::move(v14_16_outputs));
          const Space v14_17 = subtract(v14_10,v14_16);
          const Space v14_18 = compose(v14_17,v14_6);
          const auto v14_19_branches = branches(c,v14_18);
          std::vector<Space> v14_19_outputs;
          v14_19_outputs.reserve(v14_19_branches.size());
          for (const auto& v14_19_branch : v14_19_branches) {
            const Path v14_19_head{v14_19_branch.first};
            const Space& v14_19_tail = v14_19_branch.second;
            const auto v23_2_branches = branches(c,v14_19_tail);
            std::vector<Space> v23_2_outputs;
            v23_2_outputs.reserve(v23_2_branches.size());
            for (const auto& v23_2_branch : v23_2_branches) {
              const Path v23_2_head{v23_2_branch.first};
              const Space& v23_2_tail = v23_2_branch.second;
              const Path v24_2 = concat_path(v14_19_head,v23_2_head);
              const auto v24_3_branches = branches(c,v23_2_tail);
              std::vector<Space> v24_3_outputs;
              v24_3_outputs.reserve(v24_3_branches.size());
              for (const auto& v24_3_branch : v24_3_branches) {
                const Path v24_3_head{v24_3_branch.first};
                const Space& v24_3_tail = v24_3_branch.second;
                const Path v25_2 = concat_path(v24_2,v24_3_head);
                const auto v25_3_branches = branches(c,v24_3_tail);
                std::vector<Space> v25_3_outputs;
                v25_3_outputs.reserve(v25_3_branches.size());
                for (const auto& v25_3_branch : v25_3_branches) {
                  const Path v25_3_head{v25_3_branch.first};
                  const Space& v25_3_tail = v25_3_branch.second;
                  const Path v26_2 = concat_path(v25_2,v25_3_head);
                  const Space v26_3 = routine_8(c, v26_2, v25_3_tail);
                  v25_3_outputs.push_back(v26_3);
                }
                const Space v25_3 = join_outputs(std::move(v25_3_outputs));
                v24_3_outputs.push_back(v25_3);
              }
              const Space v24_3 = join_outputs(std::move(v24_3_outputs));
              v23_2_outputs.push_back(v24_3);
            }
            const Space v23_2 = join_outputs(std::move(v23_2_outputs));
            v14_19_outputs.push_back(v23_2);
          }
          const Space v14_19 = join_outputs(std::move(v14_19_outputs));
          v13_5_outputs.push_back(v14_19);
        }
        const Space v13_5 = join_outputs(std::move(v13_5_outputs));
        v12_5_outputs.push_back(v13_5);
      }
      const Space v12_5 = join_outputs(std::move(v12_5_outputs));
      v11_4_outputs.push_back(v12_5);
    }
    const Space v11_4 = join_outputs(std::move(v11_4_outputs));
    v10_11_outputs.push_back(v11_4);
  }
  const Space v10_11 = join_outputs(std::move(v10_11_outputs));
  return v10_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v27_8 = unwrap(constant_50,p0);
  const Space v27_9 = unwrap(s1,constant_49);
  const Space v27_10 = unwrap(constant_50,p0);
  const auto v27_11_branches = branches(c,s0);
  std::vector<Space> v27_11_outputs;
  v27_11_outputs.reserve(v27_11_branches.size());
  for (const auto& v27_11_branch : v27_11_branches) {
    const Path v27_11_head{v27_11_branch.first};
    const Space& v27_11_tail = v27_11_branch.second;
    const Space v28_2 = unwrap(constant_50,v27_11_head);
    const Space v28_3 = unwrap(constant_50,v27_11_head);
    const auto v28_4_branches = branches(c,v27_11_tail);
    std::vector<Space> v28_4_outputs;
    v28_4_outputs.reserve(v28_4_branches.size());
    for (const auto& v28_4_branch : v28_4_branches) {
      const Path v28_4_head{v28_4_branch.first};
      const Space& v28_4_tail = v28_4_branch.second;
      const Path v29_2 = concat_path(v27_11_head,v28_4_head);
      const Space v29_3 = unwrap(v28_2,v28_4_head);
      const Space v29_4 = unwrap(v28_3,v28_4_head);
      const auto v29_5_branches = branches(c,v28_4_tail);
      std::vector<Space> v29_5_outputs;
      v29_5_outputs.reserve(v29_5_branches.size());
      for (const auto& v29_5_branch : v29_5_branches) {
        const Path v29_5_head{v29_5_branch.first};
        const Space& v29_5_tail = v29_5_branch.second;
        const Space v30_2 = unwrap(v29_3,v29_5_head);
        const Path v30_3 = concat_path(v29_2,v29_5_head);
        const Space v30_4 = unwrap(v29_4,v29_5_head);
        const auto v30_5_branches = branches(c,v29_5_tail);
        std::vector<Space> v30_5_outputs;
        v30_5_outputs.reserve(v30_5_branches.size());
        for (const auto& v30_5_branch : v30_5_branches) {
          const Path v30_5_head{v30_5_branch.first};
          const Space& v30_5_tail = v30_5_branch.second;
          const Space v31_2 = unwrap(v30_2,v30_5_head);
          const Space v31_3 = compose(v27_8,v31_2);
          const Path v31_4 = concat_path(v30_3,v30_5_head);
          const Path v31_5 = concat_path(p0,v31_4);
          const Space v31_6 = singleton(v31_5);
          const Space v31_7 = subtract(v31_3,v31_6);
          const Space v31_8 = intersect(v31_7,v27_9);
          const Space v31_9 = routine_9(c, v31_8);
          const auto v31_10_branches = branches(c,v31_9);
          std::vector<Space> v31_10_outputs;
          v31_10_outputs.reserve(v31_10_branches.size());
          for (const auto& v31_10_branch : v31_10_branches) {
            const Path v31_10_head{v31_10_branch.first};
            const Space& v31_10_tail = v31_10_branch.second;
            const auto v32_2_branches = branches(c,v31_10_tail);
            std::vector<Space> v32_2_outputs;
            v32_2_outputs.reserve(v32_2_branches.size());
            for (const auto& v32_2_branch : v32_2_branches) {
              const Path v32_2_head{v32_2_branch.first};
              const Space& v32_2_tail = v32_2_branch.second;
              const Path v33_2 = concat_path(v31_10_head,v32_2_head);
              const auto v33_3_branches = branches(c,v32_2_tail);
              std::vector<Space> v33_3_outputs;
              v33_3_outputs.reserve(v33_3_branches.size());
              for (const auto& v33_3_branch : v33_3_branches) {
                const Path v33_3_head{v33_3_branch.first};
                const Space& v33_3_tail = v33_3_branch.second;
                const Path v34_2 = concat_path(v33_2,v33_3_head);
                const auto v34_3_branches = branches(c,v33_3_tail);
                std::vector<Space> v34_3_outputs;
                v34_3_outputs.reserve(v34_3_branches.size());
                for (const auto& v34_3_branch : v34_3_branches) {
                  const Path v34_3_head{v34_3_branch.first};
                  const Space& v34_3_tail = v34_3_branch.second;
                  const Path v35_2 = concat_path(v34_2,v34_3_head);
                  const Space v35_3 = routine_10(c, v35_2, v34_3_tail);
                  v34_3_outputs.push_back(v35_3);
                }
                const Space v34_3 = join_outputs(std::move(v34_3_outputs));
                v33_3_outputs.push_back(v34_3);
              }
              const Space v33_3 = join_outputs(std::move(v33_3_outputs));
              v32_2_outputs.push_back(v33_3);
            }
            const Space v32_2 = join_outputs(std::move(v32_2_outputs));
            v31_10_outputs.push_back(v32_2);
          }
          const Space v31_10 = join_outputs(std::move(v31_10_outputs));
          const Space v31_11 = unwrap(v30_4,v30_5_head);
          const Space v31_12 = compose(v27_10,v31_11);
          const Space v31_13 = subtract(v31_12,v31_6);
          const Space v31_14 = intersect(v31_13,v27_9);
          const Space v31_15 = routine_4(c, v31_14);
          const auto v31_16_branches = branches(c,v31_15);
          std::vector<Space> v31_16_outputs;
          v31_16_outputs.reserve(v31_16_branches.size());
          for (const auto& v31_16_branch : v31_16_branches) {
            const Path v31_16_head{v31_16_branch.first};
            const Space& v31_16_tail = v31_16_branch.second;
            const auto v36_2_branches = branches(c,v31_16_tail);
            std::vector<Space> v36_2_outputs;
            v36_2_outputs.reserve(v36_2_branches.size());
            for (const auto& v36_2_branch : v36_2_branches) {
              const Path v36_2_head{v36_2_branch.first};
              const Space& v36_2_tail = v36_2_branch.second;
              const Path v37_2 = concat_path(v31_16_head,v36_2_head);
              const auto v37_3_branches = branches(c,v36_2_tail);
              std::vector<Space> v37_3_outputs;
              v37_3_outputs.reserve(v37_3_branches.size());
              for (const auto& v37_3_branch : v37_3_branches) {
                const Path v37_3_head{v37_3_branch.first};
                const Space& v37_3_tail = v37_3_branch.second;
                const Path v38_2 = concat_path(v37_2,v37_3_head);
                const auto v38_3_branches = branches(c,v37_3_tail);
                std::vector<Space> v38_3_outputs;
                v38_3_outputs.reserve(v38_3_branches.size());
                for (const auto& v38_3_branch : v38_3_branches) {
                  const Path v38_3_head{v38_3_branch.first};
                  const Space& v38_3_tail = v38_3_branch.second;
                  const Path v39_2 = concat_path(v38_2,v38_3_head);
                  const Space v39_3 = routine_11(c, v39_2, v38_3_tail);
                  v38_3_outputs.push_back(v39_3);
                }
                const Space v38_3 = join_outputs(std::move(v38_3_outputs));
                v37_3_outputs.push_back(v38_3);
              }
              const Space v37_3 = join_outputs(std::move(v37_3_outputs));
              v36_2_outputs.push_back(v37_3);
            }
            const Space v36_2 = join_outputs(std::move(v36_2_outputs));
            v31_16_outputs.push_back(v36_2);
          }
          const Space v31_16 = join_outputs(std::move(v31_16_outputs));
          const Space v31_17 = subtract(v31_10,v31_16);
          const Space v31_18 = compose(v31_17,v31_6);
          const auto v31_19_branches = branches(c,v31_18);
          std::vector<Space> v31_19_outputs;
          v31_19_outputs.reserve(v31_19_branches.size());
          for (const auto& v31_19_branch : v31_19_branches) {
            const Path v31_19_head{v31_19_branch.first};
            const Space& v31_19_tail = v31_19_branch.second;
            const auto v40_2_branches = branches(c,v31_19_tail);
            std::vector<Space> v40_2_outputs;
            v40_2_outputs.reserve(v40_2_branches.size());
            for (const auto& v40_2_branch : v40_2_branches) {
              const Path v40_2_head{v40_2_branch.first};
              const Space& v40_2_tail = v40_2_branch.second;
              const Path v41_2 = concat_path(v31_19_head,v40_2_head);
              const auto v41_3_branches = branches(c,v40_2_tail);
              std::vector<Space> v41_3_outputs;
              v41_3_outputs.reserve(v41_3_branches.size());
              for (const auto& v41_3_branch : v41_3_branches) {
                const Path v41_3_head{v41_3_branch.first};
                const Space& v41_3_tail = v41_3_branch.second;
                const Path v42_2 = concat_path(v41_2,v41_3_head);
                const auto v42_3_branches = branches(c,v41_3_tail);
                std::vector<Space> v42_3_outputs;
                v42_3_outputs.reserve(v42_3_branches.size());
                for (const auto& v42_3_branch : v42_3_branches) {
                  const Path v42_3_head{v42_3_branch.first};
                  const Space& v42_3_tail = v42_3_branch.second;
                  const Path v43_2 = concat_path(v42_2,v42_3_head);
                  const Space v43_3 = routine_12(c, v43_2, v42_3_tail);
                  v42_3_outputs.push_back(v43_3);
                }
                const Space v42_3 = join_outputs(std::move(v42_3_outputs));
                v41_3_outputs.push_back(v42_3);
              }
              const Space v41_3 = join_outputs(std::move(v41_3_outputs));
              v40_2_outputs.push_back(v41_3);
            }
            const Space v40_2 = join_outputs(std::move(v40_2_outputs));
            v31_19_outputs.push_back(v40_2);
          }
          const Space v31_19 = join_outputs(std::move(v31_19_outputs));
          v30_5_outputs.push_back(v31_19);
        }
        const Space v30_5 = join_outputs(std::move(v30_5_outputs));
        v29_5_outputs.push_back(v30_5);
      }
      const Space v29_5 = join_outputs(std::move(v29_5_outputs));
      v28_4_outputs.push_back(v29_5);
    }
    const Space v28_4 = join_outputs(std::move(v28_4_outputs));
    v27_11_outputs.push_back(v28_4);
  }
  const Space v27_11 = join_outputs(std::move(v27_11_outputs));
  return v27_11;
}

static Space routine_4(Context& c, const Space& s0) {
  const Space v44_1 = (has_head(s0) ? constant_51 : Space{});
  const Space v44_2 = first_matching(s0,constant_52,false);
  const Space v44_3 = unite(v44_1,v44_2);
  Space v44_6;
  if (!v44_3.empty()) {
    const Space v45_4 = routine_13(c, s0);
    const Space v45_5 = routine_13(c, v45_4);
    v44_6 = compose(v44_3,v45_5);
  }
  Space v44_9;
  if (!v44_3.empty()) {
    const Space v46_7 = routine_14(c, s0);
    const Space v46_8 = subtract(s0,v46_7);
    v44_9 = compose(v44_3,v46_8);
  }
  const Space v44_10 = (has_head(v44_9) ? constant_51 : Space{});
  const Space v44_11 = first_matching(v44_9,constant_52,false);
  const Space v44_12 = unite(v44_10,v44_11);
  Space v44_15;
  if (!v44_12.empty()) {
    const Space v47_13 = routine_13(c, v44_9);
    const Space v47_14 = routine_13(c, v47_13);
    v44_15 = compose(v44_12,v47_14);
  }
  const Space v44_16 = subtract(s0,v44_15);
  const Space v44_17 = intersect(v44_6,v44_16);
  return v44_17;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  return constant_53;
}

static Space routine_6(Context& c, const Space& s0) {
  const Space v49_1 = (has_head(s0) ? constant_51 : Space{});
  const Space v49_2 = first_matching(s0,constant_52,false);
  const Space v49_3 = unite(v49_1,v49_2);
  Space v49_6;
  if (!v49_3.empty()) {
    const Space v50_4 = routine_14(c, s0);
    const Space v50_5 = subtract(s0,v50_4);
    v49_6 = compose(v49_3,v50_5);
  }
  const Space v49_7 = (has_head(v49_6) ? constant_51 : Space{});
  const Space v49_8 = first_matching(v49_6,constant_52,false);
  const Space v49_9 = unite(v49_7,v49_8);
  Space v49_12;
  if (!v49_9.empty()) {
    const Space v51_10 = routine_13(c, v49_6);
    const Space v51_11 = routine_13(c, v51_10);
    v49_12 = compose(v49_9,v51_11);
  }
  Space v49_15;
  if (!v49_3.empty()) {
    const Space v52_13 = routine_15(c, s0);
    const Space v52_14 = routine_15(c, v52_13);
    v49_15 = compose(v49_3,v52_14);
  }
  const Space v49_16 = subtract(s0,v49_15);
  const Space v49_17 = intersect(v49_12,v49_16);
  return v49_17;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  return constant_53;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_9(Context& c, const Space& s0) {
  const Space v55_1 = (has_head(s0) ? constant_51 : Space{});
  const Space v55_2 = first_matching(s0,constant_52,false);
  const Space v55_3 = unite(v55_1,v55_2);
  Space v55_6;
  if (!v55_3.empty()) {
    const Space v56_4 = routine_14(c, s0);
    const Space v56_5 = subtract(s0,v56_4);
    v55_6 = compose(v55_3,v56_5);
  }
  Space v55_9;
  if (!v55_3.empty()) {
    const Space v57_7 = routine_13(c, s0);
    const Space v57_8 = routine_13(c, v57_7);
    v55_9 = compose(v55_3,v57_8);
  }
  const Space v55_10 = subtract(s0,v55_9);
  const Space v55_11 = intersect(v55_6,v55_10);
  return v55_11;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  return constant_53;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  return constant_53;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_13(Context& c, const Space& s0) {
  const Space v61_1 = (has_head(s0) ? constant_51 : Space{});
  const Space v61_2 = first_matching(s0,constant_52,false);
  const Space v61_3 = unite(v61_1,v61_2);
  Space v61_19;
  if (!v61_3.empty()) {
    const Space v62_5 = intersect(constant_52,v61_2);
    const Space v62_6 = (has_head(v61_2) ? constant_51 : Space{});
    const Space v62_7 = unite(v62_5,v62_6);
    const Space v62_9 = compose(v62_7,constant_52);
    const Space v62_10 = subtract(s0,v62_9);
    const Space v62_12 = subtract(constant_52,v61_2);
    const Space v62_13 = subtract(v62_12,v62_6);
    Space v62_17;
    if (!v62_13.empty()) {
      const Space v63_15 = first_listed(s0,constant_55,true);
      const Space v63_16 = routine_16(c, constant_54, v63_15, s0);
      v62_17 = compose(v62_13,v63_16);
    }
    const Space v62_18 = subtract(v62_10,v62_17);
    v61_19 = compose(v61_3,v62_18);
  }
  return v61_19;
}

static Space routine_14(Context& c, const Space& s0) {
  const Space v64_2 = first_matching(s0,constant_52,false);
  const Space v64_3 = intersect(constant_52,v64_2);
  const Space v64_4 = (has_head(v64_2) ? constant_51 : Space{});
  const Space v64_5 = unite(v64_3,v64_4);
  const Space v64_7 = compose(v64_5,constant_52);
  const Space v64_9 = subtract(constant_52,v64_2);
  const Space v64_10 = subtract(v64_9,v64_4);
  Space v64_18;
  if (!v64_10.empty()) {
    const Space v65_11 = first_listed(s0,constant_55,true);
    const Space v65_12 = first_matching(v65_11,constant_52,false);
    Space v65_15;
    if (!v65_12.empty()) {
      const Space v66_14 = routine_17(c, constant_54, s0);
      v65_15 = compose(v65_12,v66_14);
    }
    const auto v65_16_branches = branches(c,v65_11);
    std::vector<Space> v65_16_outputs;
    v65_16_outputs.reserve(v65_16_branches.size());
    for (const auto& v65_16_branch : v65_16_branches) {
      const Path v65_16_head{v65_16_branch.first};
      const Space& v65_16_tail = v65_16_branch.second;
      const Space v67_2 = routine_16(c, v65_16_head, v65_16_tail, s0);
      v65_16_outputs.push_back(v67_2);
    }
    const Space v65_16 = join_outputs(std::move(v65_16_outputs));
    const Space v65_17 = unite(v65_15,v65_16);
    v64_18 = compose(v64_10,v65_17);
  }
  const Space v64_19 = unite(v64_7,v64_18);
  return v64_19;
}

static Space routine_15(Context& c, const Space& s0) {
  const Space v68_1 = (has_head(s0) ? constant_51 : Space{});
  const Space v68_2 = first_matching(s0,constant_52,false);
  const Space v68_3 = unite(v68_1,v68_2);
  Space v68_13;
  if (!v68_3.empty()) {
    Space v69_6;
    if (!v68_3.empty()) {
      const Space v70_4 = routine_14(c, s0);
      const Space v70_5 = subtract(s0,v70_4);
      v69_6 = compose(v68_3,v70_5);
    }
    const Space v69_7 = (has_head(v69_6) ? constant_51 : Space{});
    const Space v69_8 = first_matching(v69_6,constant_52,false);
    const Space v69_9 = unite(v69_7,v69_8);
    Space v69_12;
    if (!v69_9.empty()) {
      const Space v71_10 = routine_14(c, v69_6);
      const Space v71_11 = subtract(v69_6,v71_10);
      v69_12 = compose(v69_9,v71_11);
    }
    v68_13 = compose(v68_3,v69_12);
  }
  return v68_13;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v72_3 = first_matching(s0,constant_52,false);
  Space v72_7;
  if (!v72_3.empty()) {
    const Space v73_4 = unwrap(s1,p0);
    const Space v73_5 = routine_14(c, v73_4);
    const Space v73_6 = wrap(v73_5,p0);
    v72_7 = compose(v72_3,v73_6);
  }
  const auto v72_8_branches = branches(c,s0);
  std::vector<Space> v72_8_outputs;
  v72_8_outputs.reserve(v72_8_branches.size());
  for (const auto& v72_8_branch : v72_8_branches) {
    const Path v72_8_head{v72_8_branch.first};
    const Space& v72_8_tail = v72_8_branch.second;
    const Path v74_2 = concat_path(p0,v72_8_head);
    const Space v74_3 = routine_16(c, v74_2, v72_8_tail, s1);
    v72_8_outputs.push_back(v74_3);
  }
  const Space v72_8 = join_outputs(std::move(v72_8_outputs));
  const Space v72_9 = unite(v72_7,v72_8);
  return v72_9;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  const Space v75_3 = unwrap(s0,p0);
  const Space v75_4 = first_matching(v75_3,constant_52,false);
  const Space v75_5 = intersect(constant_52,v75_4);
  const Space v75_6 = (has_head(v75_4) ? constant_51 : Space{});
  const Space v75_7 = unite(v75_5,v75_6);
  const Space v75_9 = compose(v75_7,constant_52);
  const Space v75_11 = subtract(constant_52,v75_4);
  const Space v75_12 = subtract(v75_11,v75_6);
  Space v75_16;
  if (!v75_12.empty()) {
    const Space v76_14 = first_listed(v75_3,constant_55,true);
    const Space v76_15 = routine_16(c, constant_54, v76_14, v75_3);
    v75_16 = compose(v75_12,v76_15);
  }
  const Space v75_17 = unite(v75_9,v75_16);
  const Space v75_18 = wrap(v75_17,p0);
  return v75_18;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
