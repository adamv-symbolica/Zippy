#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{1,1,1,1,2,2};
static const Space constant_4 = literal_text("6 8 1 1 1 2 2 1 2 2 8 1 2 1 2 2 1 2 2 9 1 2 1 2 2 2 1 2 2 8 1 2 2 2 1 1 2 2 5 1 2 2 2 2 9 2 1 1 2 2 1 1 2 2");
static const Space constant_5 = literal_text("6 9 1 1 2 2 2 1 1 2 2 8 1 2 2 1 1 1 2 2 8 1 2 2 1 2 1 2 2 8 2 1 1 2 2 1 2 2 9 2 1 2 2 1 2 1 2 2 5 2 2 1 2 2");
static const Space constant_6 = literal_text("4 5 1 1 1 2 2 5 2 1 1 2 2 4 2 1 2 2 2 2 2");
static Space routine_0(Context& c, const Space* s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  Space v0_4_result;
  for (int v0_4_label = 1; v0_4_label <= 2; ++v0_4_label) {
    const Space v0_4_tail = child(bound_space(s0),v0_4_label);
    if (v0_4_tail.empty()) continue;
    const Path v0_4_head{v0_4_label};
    const Space v1_2 = singleton(v0_4_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_4_head, v0_4_tail);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_4_head, v0_4_tail);
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_4_result = unite(v0_4_result,v1_12);
  }
  const Space v0_4 = std::move(v0_4_result);
  const Space v0_6 = wrap(v0_4,constant_3);
  return v0_6;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v4_11_result;
  for (int v4_11_label = 1; v4_11_label <= 2; ++v4_11_label) {
    const Space v4_11_tail = child(s0,v4_11_label);
    if (v4_11_tail.empty()) continue;
    const Path v4_11_head{v4_11_label};
    const Space v5_2 = singleton(v4_11_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_11_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_11_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_11_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_11_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_11_result = unite(v4_11_result,v5_13);
  }
  const Space v4_11 = std::move(v4_11_result);
  return v4_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  const Space v14_8 = unwrap(constant_5,p0);
  const Space v14_10 = unwrap(constant_5,p0);
  Space v14_21_result;
  for (int v14_21_label = 1; v14_21_label <= 2; ++v14_21_label) {
    const Space v14_21_tail = child(s0,v14_21_label);
    if (v14_21_tail.empty()) continue;
    const Path v14_21_head{v14_21_label};
    const Space v15_2 = singleton(v14_21_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_21_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_21_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_19;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_8,v14_21_head);
      const Space v20_12 = restrict_to(constant_5,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(constant_4,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = unwrap(v14_10,v14_21_head);
      const Space v20_17 = subtract(v20_15,v20_16);
      const Space v20_18 = intersect(v20_17,constant_6);
      v15_19 = compose(v15_10,v20_18);
    }
    const Path v27_6 = concat_path(p0,v14_21_head);
    const Space v15_20 = wrap(v15_19,v27_6);
    const Space v15_21 = unite(v15_8,v15_20);
    v14_21_result = unite(v14_21_result,v15_21);
  }
  const Space v14_21 = std::move(v14_21_result);
  return v14_21;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v28_11_result;
  for (int v28_11_label = 1; v28_11_label <= 2; ++v28_11_label) {
    const Space v28_11_tail = child(s0,v28_11_label);
    if (v28_11_tail.empty()) continue;
    const Path v28_11_head{v28_11_label};
    const Space v29_2 = singleton(v28_11_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_11_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_11_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_11_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_11_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_11_result = unite(v28_11_result,v29_13);
  }
  const Space v28_11 = std::move(v28_11_result);
  return v28_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  const Space v38_8 = unwrap(constant_5,p0);
  const Space v38_10 = unwrap(constant_5,p0);
  Space v38_21_result;
  for (int v38_21_label = 1; v38_21_label <= 2; ++v38_21_label) {
    const Space v38_21_tail = child(s0,v38_21_label);
    if (v38_21_tail.empty()) continue;
    const Path v38_21_head{v38_21_label};
    const Space v39_2 = singleton(v38_21_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_21_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_21_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_19;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_8,v38_21_head);
      const Space v44_12 = restrict_to(constant_5,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(constant_4,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = unwrap(v38_10,v38_21_head);
      const Space v44_17 = subtract(v44_15,v44_16);
      const Space v44_18 = intersect(v44_17,constant_6);
      v39_19 = compose(v39_10,v44_18);
    }
    const Path v51_6 = concat_path(p0,v38_21_head);
    const Space v39_20 = wrap(v39_19,v51_6);
    const Space v39_21 = unite(v39_8,v39_20);
    v38_21_result = unite(v38_21_result,v39_21);
  }
  const Space v38_21 = std::move(v38_21_result);
  return v38_21;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  const Space v52_5 = unwrap(constant_5,p0);
  const Space v52_6 = restrict_to(constant_5,v52_5);
  Space v52_16_result;
  for (int v52_16_label = 1; v52_16_label <= 2; ++v52_16_label) {
    const Space v52_16_tail = child(v52_6,v52_16_label);
    if (v52_16_tail.empty()) continue;
    const Path v52_16_head{v52_16_label};
    const Space v53_2 = singleton(v52_16_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_16_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_16_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_16_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_16_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_16_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_16_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_16_result = unite(v52_16_result,v53_12);
  }
  const Space v52_16 = std::move(v52_16_result);
  const Space v52_17 = restrict_to(constant_4,v52_16);
  Space v52_27_result;
  for (int v52_27_label = 1; v52_27_label <= 2; ++v52_27_label) {
    const Space v52_27_tail = child(v52_17,v52_27_label);
    if (v52_27_tail.empty()) continue;
    const Path v52_27_head{v52_27_label};
    const Space v62_2 = singleton(v52_27_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_27_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_27_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_27_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_27_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_27_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_27_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_27_result = unite(v52_27_result,v62_12);
  }
  const Space v52_27 = std::move(v52_27_result);
  const Space v52_29 = unwrap(constant_5,p0);
  const Space v52_30 = subtract(v52_27,v52_29);
  const Space v52_32 = intersect(v52_30,constant_6);
  const Space v52_33 = wrap(v52_32,p0);
  return v52_33;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  const Space v103_2 = Space{};
  return v103_2;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  const Space v104_6 = unwrap(constant_5,p0);
  const Space v104_8 = unwrap(constant_5,p0);
  Space v104_16_result;
  for (int v104_16_label = 1; v104_16_label <= 2; ++v104_16_label) {
    const Space v104_16_tail = child(s0,v104_16_label);
    if (v104_16_tail.empty()) continue;
    const Path v104_16_head{v104_16_label};
    const Space v105_2 = singleton(v104_16_head);
    const Space v105_3 = intersect(constant_1,v105_2);
    const Space v105_4 = (has_head(v105_3) ? constant_2 : Space{});
    Space v105_13;
    if (!v105_4.empty()) {
      const Space v106_5 = unwrap(v104_6,v104_16_head);
      const Space v106_6 = restrict_to(constant_5,v106_5);
      Space v106_7_result;
      for (int v106_7_label = 1; v106_7_label <= 2; ++v106_7_label) {
        const Space v106_7_tail = child(v106_6,v106_7_label);
        if (v106_7_tail.empty()) continue;
        const Path v106_7_head{v106_7_label};
        const Space v107_2 = singleton(v106_7_head);
        const Space v107_3 = intersect(constant_1,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_2 : Space{});
        const Space v107_5 = subtract(constant_0,v107_4);
        Space v107_7;
        if (!v107_5.empty()) {
          const Space v108_6 = routine_6(c, v106_7_head, v106_7_tail);
          v107_7 = compose(v107_5,v108_6);
        }
        const Space v107_8 = intersect(constant_1,v107_2);
        const Space v107_9 = (has_head(v107_8) ? constant_2 : Space{});
        Space v107_11;
        if (!v107_9.empty()) {
          const Space v109_10 = routine_7(c, v106_7_head, v106_7_tail);
          v107_11 = compose(v107_9,v109_10);
        }
        const Space v107_12 = unite(v107_7,v107_11);
        v106_7_result = unite(v106_7_result,v107_12);
      }
      const Space v106_7 = std::move(v106_7_result);
      const Space v106_8 = restrict_to(constant_4,v106_7);
      Space v106_9_result;
      for (int v106_9_label = 1; v106_9_label <= 2; ++v106_9_label) {
        const Space v106_9_tail = child(v106_8,v106_9_label);
        if (v106_9_tail.empty()) continue;
        const Path v106_9_head{v106_9_label};
        const Space v110_2 = singleton(v106_9_head);
        const Space v110_3 = intersect(constant_1,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_2 : Space{});
        const Space v110_5 = subtract(constant_0,v110_4);
        Space v110_7;
        if (!v110_5.empty()) {
          const Space v111_6 = routine_8(c, v106_9_head, v106_9_tail);
          v110_7 = compose(v110_5,v111_6);
        }
        const Space v110_8 = intersect(constant_1,v110_2);
        const Space v110_9 = (has_head(v110_8) ? constant_2 : Space{});
        Space v110_11;
        if (!v110_9.empty()) {
          const Space v112_10 = routine_9(c, v106_9_head, v106_9_tail);
          v110_11 = compose(v110_9,v112_10);
        }
        const Space v110_12 = unite(v110_7,v110_11);
        v106_9_result = unite(v106_9_result,v110_12);
      }
      const Space v106_9 = std::move(v106_9_result);
      const Space v106_10 = unwrap(v104_8,v104_16_head);
      const Space v106_11 = subtract(v106_9,v106_10);
      const Space v106_12 = intersect(v106_11,constant_6);
      v105_13 = compose(v105_4,v106_12);
    }
    const Path v105_14 = concat_path(p0,v104_16_head);
    const Space v105_15 = wrap(v105_13,v105_14);
    v104_16_result = unite(v104_16_result,v105_15);
  }
  const Space v104_16 = std::move(v104_16_result);
  return v104_16;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v113_11_result;
  for (int v113_11_label = 1; v113_11_label <= 2; ++v113_11_label) {
    const Space v113_11_tail = child(s0,v113_11_label);
    if (v113_11_tail.empty()) continue;
    const Path v113_11_head{v113_11_label};
    const Space v114_2 = singleton(v113_11_head);
    const Space v114_3 = intersect(constant_1,v114_2);
    const Space v114_4 = (has_head(v114_3) ? constant_2 : Space{});
    const Space v114_5 = subtract(constant_0,v114_4);
    Space v114_8;
    if (!v114_5.empty()) {
      const Path v115_6 = concat_path(p0,v113_11_head);
      Space v115_7_result;
      for (int v115_7_label = 1; v115_7_label <= 2; ++v115_7_label) {
        const Space v115_7_tail = child(v113_11_tail,v115_7_label);
        if (v115_7_tail.empty()) continue;
        const Path v115_7_head{v115_7_label};
        const Space v116_2 = singleton(v115_7_head);
        const Space v116_3 = intersect(constant_1,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_2 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_8;
        if (!v116_5.empty()) {
          const Path v117_6 = concat_path(v115_6,v115_7_head);
          const Space v117_7 = routine_22(c, v117_6, v115_7_tail);
          v116_8 = compose(v116_5,v117_7);
        }
        const Space v116_9 = intersect(constant_1,v116_2);
        const Space v116_10 = (has_head(v116_9) ? constant_2 : Space{});
        Space v116_12;
        if (!v116_10.empty()) {
          const Path v118_6 = concat_path(v115_6,v115_7_head);
          const Space v118_11 = routine_23(c, v118_6, v115_7_tail);
          v116_12 = compose(v116_10,v118_11);
        }
        const Space v116_13 = unite(v116_8,v116_12);
        v115_7_result = unite(v115_7_result,v116_13);
      }
      const Space v115_7 = std::move(v115_7_result);
      v114_8 = compose(v114_5,v115_7);
    }
    const Space v114_9 = intersect(constant_1,v114_2);
    const Space v114_10 = (has_head(v114_9) ? constant_2 : Space{});
    Space v114_12;
    if (!v114_10.empty()) {
      const Path v119_6 = concat_path(p0,v113_11_head);
      Space v119_11_result;
      for (int v119_11_label = 1; v119_11_label <= 2; ++v119_11_label) {
        const Space v119_11_tail = child(v113_11_tail,v119_11_label);
        if (v119_11_tail.empty()) continue;
        const Path v119_11_head{v119_11_label};
        const Space v120_2 = singleton(v119_11_head);
        const Space v120_3 = intersect(constant_1,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_11_head);
          const Space v121_7 = routine_22(c, v121_6, v119_11_tail);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_1,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_2 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_11_head);
          const Space v122_11 = routine_14(c, v122_6, v119_11_tail);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_11_result = unite(v119_11_result,v120_13);
      }
      const Space v119_11 = std::move(v119_11_result);
      v114_12 = compose(v114_10,v119_11);
    }
    const Space v114_13 = unite(v114_8,v114_12);
    v113_11_result = unite(v113_11_result,v114_13);
  }
  const Space v113_11 = std::move(v113_11_result);
  return v113_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v123_8_result;
  for (int v123_8_label = 1; v123_8_label <= 2; ++v123_8_label) {
    const Space v123_8_tail = child(s0,v123_8_label);
    if (v123_8_tail.empty()) continue;
    const Path v123_8_head{v123_8_label};
    const Space v124_2 = singleton(v123_8_head);
    const Space v124_3 = intersect(constant_1,v124_2);
    const Space v124_4 = (has_head(v124_3) ? constant_2 : Space{});
    const Space v124_5 = subtract(constant_0,v124_4);
    Space v124_8;
    if (!v124_5.empty()) {
      const Path v125_6 = concat_path(p0,v123_8_head);
      Space v125_7_result;
      for (int v125_7_label = 1; v125_7_label <= 2; ++v125_7_label) {
        const Space v125_7_tail = child(v123_8_tail,v125_7_label);
        if (v125_7_tail.empty()) continue;
        const Path v125_7_head{v125_7_label};
        const Space v126_2 = singleton(v125_7_head);
        const Space v126_3 = intersect(constant_1,v126_2);
        const Space v126_4 = (has_head(v126_3) ? constant_2 : Space{});
        const Space v126_5 = subtract(constant_0,v126_4);
        Space v126_8;
        if (!v126_5.empty()) {
          const Path v127_6 = concat_path(v125_6,v125_7_head);
          const Space v127_7 = routine_22(c, v127_6, v125_7_tail);
          v126_8 = compose(v126_5,v127_7);
        }
        const Space v126_9 = intersect(constant_1,v126_2);
        const Space v126_10 = (has_head(v126_9) ? constant_2 : Space{});
        Space v126_12;
        if (!v126_10.empty()) {
          const Path v128_6 = concat_path(v125_6,v125_7_head);
          const Space v128_11 = routine_23(c, v128_6, v125_7_tail);
          v126_12 = compose(v126_10,v128_11);
        }
        const Space v126_13 = unite(v126_8,v126_12);
        v125_7_result = unite(v125_7_result,v126_13);
      }
      const Space v125_7 = std::move(v125_7_result);
      v124_8 = compose(v124_5,v125_7);
    }
    const Space v124_9 = intersect(constant_1,v124_2);
    const Space v124_10 = (has_head(v124_9) ? constant_2 : Space{});
    const Space v124_11 = compose(v124_10,v123_8_tail);
    const Space v124_12 = unite(v124_8,v124_11);
    v123_8_result = unite(v123_8_result,v124_12);
  }
  const Space v123_8 = std::move(v123_8_result);
  return v123_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v130_11_result;
  for (int v130_11_label = 1; v130_11_label <= 2; ++v130_11_label) {
    const Space v130_11_tail = child(s0,v130_11_label);
    if (v130_11_tail.empty()) continue;
    const Path v130_11_head{v130_11_label};
    const Space v131_2 = singleton(v130_11_head);
    const Space v131_3 = intersect(constant_1,v131_2);
    const Space v131_4 = (has_head(v131_3) ? constant_2 : Space{});
    const Space v131_5 = subtract(constant_0,v131_4);
    Space v131_8;
    if (!v131_5.empty()) {
      const Path v132_6 = concat_path(p0,v130_11_head);
      Space v132_7_result;
      for (int v132_7_label = 1; v132_7_label <= 2; ++v132_7_label) {
        const Space v132_7_tail = child(v130_11_tail,v132_7_label);
        if (v132_7_tail.empty()) continue;
        const Path v132_7_head{v132_7_label};
        const Space v133_2 = singleton(v132_7_head);
        const Space v133_3 = intersect(constant_1,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_2 : Space{});
        const Space v133_5 = subtract(constant_0,v133_4);
        Space v133_8;
        if (!v133_5.empty()) {
          const Path v134_6 = concat_path(v132_6,v132_7_head);
          const Space v134_7 = routine_24(c, v134_6, v132_7_tail);
          v133_8 = compose(v133_5,v134_7);
        }
        const Space v133_9 = intersect(constant_1,v133_2);
        const Space v133_10 = (has_head(v133_9) ? constant_2 : Space{});
        Space v133_12;
        if (!v133_10.empty()) {
          const Path v135_6 = concat_path(v132_6,v132_7_head);
          const Space v135_11 = routine_25(c, v135_6, v132_7_tail);
          v133_12 = compose(v133_10,v135_11);
        }
        const Space v133_13 = unite(v133_8,v133_12);
        v132_7_result = unite(v132_7_result,v133_13);
      }
      const Space v132_7 = std::move(v132_7_result);
      v131_8 = compose(v131_5,v132_7);
    }
    const Space v131_9 = intersect(constant_1,v131_2);
    const Space v131_10 = (has_head(v131_9) ? constant_2 : Space{});
    Space v131_12;
    if (!v131_10.empty()) {
      const Path v136_6 = concat_path(p0,v130_11_head);
      Space v136_11_result;
      for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
        const Space v136_11_tail = child(v130_11_tail,v136_11_label);
        if (v136_11_tail.empty()) continue;
        const Path v136_11_head{v136_11_label};
        const Space v137_2 = singleton(v136_11_head);
        const Space v137_3 = intersect(constant_1,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_2 : Space{});
        const Space v137_5 = subtract(constant_0,v137_4);
        Space v137_8;
        if (!v137_5.empty()) {
          const Path v138_6 = concat_path(v136_6,v136_11_head);
          const Space v138_7 = routine_24(c, v138_6, v136_11_tail);
          v137_8 = compose(v137_5,v138_7);
        }
        const Space v137_9 = intersect(constant_1,v137_2);
        const Space v137_10 = (has_head(v137_9) ? constant_2 : Space{});
        Space v137_12;
        if (!v137_10.empty()) {
          const Path v139_6 = concat_path(v136_6,v136_11_head);
          const Space v139_11 = routine_17(c, v139_6, v136_11_tail);
          v137_12 = compose(v137_10,v139_11);
        }
        const Space v137_13 = unite(v137_8,v137_12);
        v136_11_result = unite(v136_11_result,v137_13);
      }
      const Space v136_11 = std::move(v136_11_result);
      v131_12 = compose(v131_10,v136_11);
    }
    const Space v131_13 = unite(v131_8,v131_12);
    v130_11_result = unite(v130_11_result,v131_13);
  }
  const Space v130_11 = std::move(v130_11_result);
  return v130_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v140_8_result;
  for (int v140_8_label = 1; v140_8_label <= 2; ++v140_8_label) {
    const Space v140_8_tail = child(s0,v140_8_label);
    if (v140_8_tail.empty()) continue;
    const Path v140_8_head{v140_8_label};
    const Space v141_2 = singleton(v140_8_head);
    const Space v141_3 = intersect(constant_1,v141_2);
    const Space v141_4 = (has_head(v141_3) ? constant_2 : Space{});
    const Space v141_5 = subtract(constant_0,v141_4);
    Space v141_8;
    if (!v141_5.empty()) {
      const Path v142_6 = concat_path(p0,v140_8_head);
      Space v142_7_result;
      for (int v142_7_label = 1; v142_7_label <= 2; ++v142_7_label) {
        const Space v142_7_tail = child(v140_8_tail,v142_7_label);
        if (v142_7_tail.empty()) continue;
        const Path v142_7_head{v142_7_label};
        const Space v143_2 = singleton(v142_7_head);
        const Space v143_3 = intersect(constant_1,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_2 : Space{});
        const Space v143_5 = subtract(constant_0,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v142_6,v142_7_head);
          const Space v144_7 = routine_24(c, v144_6, v142_7_tail);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_1,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_2 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v142_6,v142_7_head);
          const Space v145_11 = routine_25(c, v145_6, v142_7_tail);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_7_result = unite(v142_7_result,v143_13);
      }
      const Space v142_7 = std::move(v142_7_result);
      v141_8 = compose(v141_5,v142_7);
    }
    const Space v141_9 = intersect(constant_1,v141_2);
    const Space v141_10 = (has_head(v141_9) ? constant_2 : Space{});
    const Space v141_11 = compose(v141_10,v140_8_tail);
    const Space v141_12 = unite(v141_8,v141_11);
    v140_8_result = unite(v140_8_result,v141_12);
  }
  const Space v140_8 = std::move(v140_8_result);
  return v140_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v147_11_result;
  for (int v147_11_label = 1; v147_11_label <= 2; ++v147_11_label) {
    const Space v147_11_tail = child(s0,v147_11_label);
    if (v147_11_tail.empty()) continue;
    const Path v147_11_head{v147_11_label};
    const Space v148_2 = singleton(v147_11_head);
    const Space v148_3 = intersect(constant_1,v148_2);
    const Space v148_4 = (has_head(v148_3) ? constant_2 : Space{});
    const Space v148_5 = subtract(constant_0,v148_4);
    Space v148_8;
    if (!v148_5.empty()) {
      const Path v149_6 = concat_path(p0,v147_11_head);
      Space v149_7_result;
      for (int v149_7_label = 1; v149_7_label <= 2; ++v149_7_label) {
        const Space v149_7_tail = child(v147_11_tail,v149_7_label);
        if (v149_7_tail.empty()) continue;
        const Path v149_7_head{v149_7_label};
        const Space v150_2 = singleton(v149_7_head);
        const Space v150_3 = intersect(constant_1,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_2 : Space{});
        const Space v150_5 = subtract(constant_0,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_7_head);
          const Space v151_7 = routine_26(c, v151_6, v149_7_tail);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_1,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_2 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_7_head);
          const Space v152_11 = routine_27(c, v152_6, v149_7_tail);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_7_result = unite(v149_7_result,v150_13);
      }
      const Space v149_7 = std::move(v149_7_result);
      v148_8 = compose(v148_5,v149_7);
    }
    const Space v148_9 = intersect(constant_1,v148_2);
    const Space v148_10 = (has_head(v148_9) ? constant_2 : Space{});
    Space v148_12;
    if (!v148_10.empty()) {
      const Path v153_6 = concat_path(p0,v147_11_head);
      Space v153_11_result;
      for (int v153_11_label = 1; v153_11_label <= 2; ++v153_11_label) {
        const Space v153_11_tail = child(v147_11_tail,v153_11_label);
        if (v153_11_tail.empty()) continue;
        const Path v153_11_head{v153_11_label};
        const Space v154_2 = singleton(v153_11_head);
        const Space v154_3 = intersect(constant_1,v154_2);
        const Space v154_4 = (has_head(v154_3) ? constant_2 : Space{});
        const Space v154_5 = subtract(constant_0,v154_4);
        Space v154_8;
        if (!v154_5.empty()) {
          const Path v155_6 = concat_path(v153_6,v153_11_head);
          const Space v155_7 = routine_26(c, v155_6, v153_11_tail);
          v154_8 = compose(v154_5,v155_7);
        }
        const Space v154_9 = intersect(constant_1,v154_2);
        const Space v154_10 = (has_head(v154_9) ? constant_2 : Space{});
        Space v154_12;
        if (!v154_10.empty()) {
          const Path v156_6 = concat_path(v153_6,v153_11_head);
          const Space v156_11 = routine_14(c, v156_6, v153_11_tail);
          v154_12 = compose(v154_10,v156_11);
        }
        const Space v154_13 = unite(v154_8,v154_12);
        v153_11_result = unite(v153_11_result,v154_13);
      }
      const Space v153_11 = std::move(v153_11_result);
      v148_12 = compose(v148_10,v153_11);
    }
    const Space v148_13 = unite(v148_8,v148_12);
    v147_11_result = unite(v147_11_result,v148_13);
  }
  const Space v147_11 = std::move(v147_11_result);
  return v147_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v157_8_result;
  for (int v157_8_label = 1; v157_8_label <= 2; ++v157_8_label) {
    const Space v157_8_tail = child(s0,v157_8_label);
    if (v157_8_tail.empty()) continue;
    const Path v157_8_head{v157_8_label};
    const Space v158_2 = singleton(v157_8_head);
    const Space v158_3 = intersect(constant_1,v158_2);
    const Space v158_4 = (has_head(v158_3) ? constant_2 : Space{});
    const Space v158_5 = subtract(constant_0,v158_4);
    Space v158_8;
    if (!v158_5.empty()) {
      const Path v159_6 = concat_path(p0,v157_8_head);
      Space v159_7_result;
      for (int v159_7_label = 1; v159_7_label <= 2; ++v159_7_label) {
        const Space v159_7_tail = child(v157_8_tail,v159_7_label);
        if (v159_7_tail.empty()) continue;
        const Path v159_7_head{v159_7_label};
        const Space v160_2 = singleton(v159_7_head);
        const Space v160_3 = intersect(constant_1,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_2 : Space{});
        const Space v160_5 = subtract(constant_0,v160_4);
        Space v160_8;
        if (!v160_5.empty()) {
          const Path v161_6 = concat_path(v159_6,v159_7_head);
          const Space v161_7 = routine_26(c, v161_6, v159_7_tail);
          v160_8 = compose(v160_5,v161_7);
        }
        const Space v160_9 = intersect(constant_1,v160_2);
        const Space v160_10 = (has_head(v160_9) ? constant_2 : Space{});
        Space v160_12;
        if (!v160_10.empty()) {
          const Path v162_6 = concat_path(v159_6,v159_7_head);
          const Space v162_11 = routine_27(c, v162_6, v159_7_tail);
          v160_12 = compose(v160_10,v162_11);
        }
        const Space v160_13 = unite(v160_8,v160_12);
        v159_7_result = unite(v159_7_result,v160_13);
      }
      const Space v159_7 = std::move(v159_7_result);
      v158_8 = compose(v158_5,v159_7);
    }
    const Space v158_9 = intersect(constant_1,v158_2);
    const Space v158_10 = (has_head(v158_9) ? constant_2 : Space{});
    const Space v158_11 = compose(v158_10,v157_8_tail);
    const Space v158_12 = unite(v158_8,v158_11);
    v157_8_result = unite(v157_8_result,v158_12);
  }
  const Space v157_8 = std::move(v157_8_result);
  return v157_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v163_11_result;
  for (int v163_11_label = 1; v163_11_label <= 2; ++v163_11_label) {
    const Space v163_11_tail = child(s0,v163_11_label);
    if (v163_11_tail.empty()) continue;
    const Path v163_11_head{v163_11_label};
    const Space v164_2 = singleton(v163_11_head);
    const Space v164_3 = intersect(constant_1,v164_2);
    const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
    const Space v164_5 = subtract(constant_0,v164_4);
    Space v164_8;
    if (!v164_5.empty()) {
      const Path v165_6 = concat_path(p0,v163_11_head);
      Space v165_7_result;
      for (int v165_7_label = 1; v165_7_label <= 2; ++v165_7_label) {
        const Space v165_7_tail = child(v163_11_tail,v165_7_label);
        if (v165_7_tail.empty()) continue;
        const Path v165_7_head{v165_7_label};
        const Space v166_2 = singleton(v165_7_head);
        const Space v166_3 = intersect(constant_1,v166_2);
        const Space v166_4 = (has_head(v166_3) ? constant_2 : Space{});
        const Space v166_5 = subtract(constant_0,v166_4);
        Space v166_8;
        if (!v166_5.empty()) {
          const Path v167_6 = concat_path(v165_6,v165_7_head);
          const Space v167_7 = routine_28(c, v167_6, v165_7_tail);
          v166_8 = compose(v166_5,v167_7);
        }
        const Space v166_9 = intersect(constant_1,v166_2);
        const Space v166_10 = (has_head(v166_9) ? constant_2 : Space{});
        Space v166_12;
        if (!v166_10.empty()) {
          const Path v168_6 = concat_path(v165_6,v165_7_head);
          const Space v168_11 = routine_29(c, v168_6, v165_7_tail);
          v166_12 = compose(v166_10,v168_11);
        }
        const Space v166_13 = unite(v166_8,v166_12);
        v165_7_result = unite(v165_7_result,v166_13);
      }
      const Space v165_7 = std::move(v165_7_result);
      v164_8 = compose(v164_5,v165_7);
    }
    const Space v164_9 = intersect(constant_1,v164_2);
    const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
    Space v164_12;
    if (!v164_10.empty()) {
      const Path v169_6 = concat_path(p0,v163_11_head);
      Space v169_11_result;
      for (int v169_11_label = 1; v169_11_label <= 2; ++v169_11_label) {
        const Space v169_11_tail = child(v163_11_tail,v169_11_label);
        if (v169_11_tail.empty()) continue;
        const Path v169_11_head{v169_11_label};
        const Space v170_2 = singleton(v169_11_head);
        const Space v170_3 = intersect(constant_1,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_2 : Space{});
        const Space v170_5 = subtract(constant_0,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_11_head);
          const Space v171_7 = routine_28(c, v171_6, v169_11_tail);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_1,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_2 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_11_head);
          const Space v172_11 = routine_17(c, v172_6, v169_11_tail);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_11_result = unite(v169_11_result,v170_13);
      }
      const Space v169_11 = std::move(v169_11_result);
      v164_12 = compose(v164_10,v169_11);
    }
    const Space v164_13 = unite(v164_8,v164_12);
    v163_11_result = unite(v163_11_result,v164_13);
  }
  const Space v163_11 = std::move(v163_11_result);
  return v163_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v173_8_result;
  for (int v173_8_label = 1; v173_8_label <= 2; ++v173_8_label) {
    const Space v173_8_tail = child(s0,v173_8_label);
    if (v173_8_tail.empty()) continue;
    const Path v173_8_head{v173_8_label};
    const Space v174_2 = singleton(v173_8_head);
    const Space v174_3 = intersect(constant_1,v174_2);
    const Space v174_4 = (has_head(v174_3) ? constant_2 : Space{});
    const Space v174_5 = subtract(constant_0,v174_4);
    Space v174_8;
    if (!v174_5.empty()) {
      const Path v175_6 = concat_path(p0,v173_8_head);
      Space v175_7_result;
      for (int v175_7_label = 1; v175_7_label <= 2; ++v175_7_label) {
        const Space v175_7_tail = child(v173_8_tail,v175_7_label);
        if (v175_7_tail.empty()) continue;
        const Path v175_7_head{v175_7_label};
        const Space v176_2 = singleton(v175_7_head);
        const Space v176_3 = intersect(constant_1,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_2 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_7_head);
          const Space v177_7 = routine_28(c, v177_6, v175_7_tail);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_1,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_2 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_7_head);
          const Space v178_11 = routine_29(c, v178_6, v175_7_tail);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_7_result = unite(v175_7_result,v176_13);
      }
      const Space v175_7 = std::move(v175_7_result);
      v174_8 = compose(v174_5,v175_7);
    }
    const Space v174_9 = intersect(constant_1,v174_2);
    const Space v174_10 = (has_head(v174_9) ? constant_2 : Space{});
    const Space v174_11 = compose(v174_10,v173_8_tail);
    const Space v174_12 = unite(v174_8,v174_11);
    v173_8_result = unite(v173_8_result,v174_12);
  }
  const Space v173_8 = std::move(v173_8_result);
  return v173_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  Space v179_4_result;
  for (int v179_4_label = 1; v179_4_label <= 2; ++v179_4_label) {
    const Space v179_4_tail = child(s0,v179_4_label);
    if (v179_4_tail.empty()) continue;
    const Path v179_4_head{v179_4_label};
    const Space v180_2 = singleton(v179_4_head);
    const Space v180_3 = intersect(constant_1,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
    Space v180_7;
    if (!v180_4.empty()) {
      const Path v181_5 = concat_path(p0,v179_4_head);
      Space v181_6_result;
      for (int v181_6_label = 1; v181_6_label <= 2; ++v181_6_label) {
        const Space v181_6_tail = child(v179_4_tail,v181_6_label);
        if (v181_6_tail.empty()) continue;
        const Path v181_6_head{v181_6_label};
        const Space v182_2 = singleton(v181_6_head);
        const Space v182_3 = intersect(constant_1,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_2 : Space{});
        Space v182_7;
        if (!v182_4.empty()) {
          const Path v183_5 = concat_path(v181_5,v181_6_head);
          const Space v183_6 = routine_14(c, v183_5, v181_6_tail);
          v182_7 = compose(v182_4,v183_6);
        }
        v181_6_result = unite(v181_6_result,v182_7);
      }
      const Space v181_6 = std::move(v181_6_result);
      v180_7 = compose(v180_4,v181_6);
    }
    v179_4_result = unite(v179_4_result,v180_7);
  }
  const Space v179_4 = std::move(v179_4_result);
  return v179_4;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  Space v184_3_result;
  for (int v184_3_label = 1; v184_3_label <= 2; ++v184_3_label) {
    const Space v184_3_tail = child(s0,v184_3_label);
    if (v184_3_tail.empty()) continue;
    const Path v184_3_head{v184_3_label};
    const Space v185_2 = singleton(v184_3_head);
    const Space v185_3 = intersect(constant_1,v185_2);
    const Space v185_4 = (has_head(v185_3) ? constant_2 : Space{});
    const Space v185_5 = compose(v185_4,v184_3_tail);
    v184_3_result = unite(v184_3_result,v185_5);
  }
  const Space v184_3 = std::move(v184_3_result);
  return v184_3;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v186_4_result;
  for (int v186_4_label = 1; v186_4_label <= 2; ++v186_4_label) {
    const Space v186_4_tail = child(s0,v186_4_label);
    if (v186_4_tail.empty()) continue;
    const Path v186_4_head{v186_4_label};
    const Space v187_2 = singleton(v186_4_head);
    const Space v187_3 = intersect(constant_1,v187_2);
    const Space v187_4 = (has_head(v187_3) ? constant_2 : Space{});
    Space v187_7;
    if (!v187_4.empty()) {
      const Path v188_5 = concat_path(p0,v186_4_head);
      Space v188_6_result;
      for (int v188_6_label = 1; v188_6_label <= 2; ++v188_6_label) {
        const Space v188_6_tail = child(v186_4_tail,v188_6_label);
        if (v188_6_tail.empty()) continue;
        const Path v188_6_head{v188_6_label};
        const Space v189_2 = singleton(v188_6_head);
        const Space v189_3 = intersect(constant_1,v189_2);
        const Space v189_4 = (has_head(v189_3) ? constant_2 : Space{});
        Space v189_7;
        if (!v189_4.empty()) {
          const Path v190_5 = concat_path(v188_5,v188_6_head);
          const Space v190_6 = routine_17(c, v190_5, v188_6_tail);
          v189_7 = compose(v189_4,v190_6);
        }
        v188_6_result = unite(v188_6_result,v189_7);
      }
      const Space v188_6 = std::move(v188_6_result);
      v187_7 = compose(v187_4,v188_6);
    }
    v186_4_result = unite(v186_4_result,v187_7);
  }
  const Space v186_4 = std::move(v186_4_result);
  return v186_4;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v191_3_result;
  for (int v191_3_label = 1; v191_3_label <= 2; ++v191_3_label) {
    const Space v191_3_tail = child(s0,v191_3_label);
    if (v191_3_tail.empty()) continue;
    const Path v191_3_head{v191_3_label};
    const Space v192_2 = singleton(v191_3_head);
    const Space v192_3 = intersect(constant_1,v192_2);
    const Space v192_4 = (has_head(v192_3) ? constant_2 : Space{});
    const Space v192_5 = compose(v192_4,v191_3_tail);
    v191_3_result = unite(v191_3_result,v192_5);
  }
  const Space v191_3 = std::move(v191_3_result);
  return v191_3;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  const Space v193_2 = Space{};
  return v193_2;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v194_3_result;
  for (int v194_3_label = 1; v194_3_label <= 2; ++v194_3_label) {
    const Space v194_3_tail = child(s0,v194_3_label);
    if (v194_3_tail.empty()) continue;
    const Path v194_3_head{v194_3_label};
    const Space v195_2 = singleton(v194_3_head);
    const Space v195_3 = intersect(constant_1,v195_2);
    const Space v195_4 = (has_head(v195_3) ? constant_2 : Space{});
    const Space v195_5 = compose(v195_4,v194_3_tail);
    v194_3_result = unite(v194_3_result,v195_5);
  }
  const Space v194_3 = std::move(v194_3_result);
  return v194_3;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  const Space v196_2 = Space{};
  return v196_2;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v197_3_result;
  for (int v197_3_label = 1; v197_3_label <= 2; ++v197_3_label) {
    const Space v197_3_tail = child(s0,v197_3_label);
    if (v197_3_tail.empty()) continue;
    const Path v197_3_head{v197_3_label};
    const Space v198_2 = singleton(v197_3_head);
    const Space v198_3 = intersect(constant_1,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_2 : Space{});
    const Space v198_5 = compose(v198_4,v197_3_tail);
    v197_3_result = unite(v197_3_result,v198_5);
  }
  const Space v197_3 = std::move(v197_3_result);
  return v197_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
