#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("6 2 1 2 2 1 7 2 2 6 2 3 1 2 3 4 2 5 1");
static const Space constant_1 = literal_text("6 2 1 3 2 1 5 2 2 1 2 4 3 2 6 2 2 7 1");
static const Space constant_2 = literal_text("4 1 2 1 4 1 5 1 7");
static const Path constant_3 = Path{8};
static Space routine_0(Context& c, const Space* s0);
static Space routine_0(Context& c, const Space* s0) {
  const auto v0_6_branches = branches(c,bound_space(s0));
  std::vector<Space> v0_6_outputs;
  v0_6_outputs.reserve(v0_6_branches.size());
  for (const auto& v0_6_branch : v0_6_branches) {
    const Path v0_6_head{v0_6_branch.first};
    const Space& v0_6_tail = v0_6_branch.second;
    const Space v1_2 = unwrap(constant_1,v0_6_head);
    const Space v1_3 = restrict_to(constant_1,v1_2);
    const Space v1_4 = tails_union(v1_3);
    const Space v1_5 = restrict_to(constant_0,v1_4);
    const Space v1_6 = tails_union(v1_5);
    const Space v1_7 = unwrap(constant_1,v0_6_head);
    const Space v1_8 = subtract(v1_6,v1_7);
    const Space v1_9 = intersect(v1_8,constant_2);
    const Space v1_10 = wrap(v1_9,v0_6_head);
    v0_6_outputs.push_back(v1_10);
  }
  const Space v0_6 = join_outputs(std::move(v0_6_outputs));
  const Space v0_8 = wrap(v0_6,constant_3);
  return v0_8;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"8 1 3 66 111 98 2 3 80 97 116 3 3 84 111 109 4 3 76 105 122 5 3 80 97 109 6 3 74 105 109 7 3 65 110 110 8 4 65 117 110 116"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
