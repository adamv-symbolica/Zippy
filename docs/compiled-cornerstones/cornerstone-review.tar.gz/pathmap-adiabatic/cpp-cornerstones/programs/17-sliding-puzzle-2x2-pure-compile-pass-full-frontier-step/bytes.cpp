#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("12 16 1 1 1 1 1 1 1 2 1 1 1 3 1 1 1 4 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 2 16 1 1 1 1 1 1 1 4 1 1 1 2 1 1 1 3 16 1 1 1 5 1 1 1 2 1 1 1 3 1 1 1 4 16 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 2 16 1 1 1 5 1 1 1 4 1 1 1 2 1 1 1 3 16 1 1 1 6 1 1 1 2 1 1 1 4 1 1 1 3 16 1 1 1 6 1 1 1 3 1 1 1 2 1 1 1 4 16 1 1 1 6 1 1 1 4 1 1 1 3 1 1 1 2 16 1 1 1 7 1 1 1 2 1 1 1 4 1 1 1 3 16 1 1 1 7 1 1 1 3 1 1 1 2 1 1 1 4 16 1 1 1 7 1 1 1 4 1 1 1 3 1 1 1 2");
static Space routine_0(Context& c);
static Space routine_0(Context& c) {
  return constant_0;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
