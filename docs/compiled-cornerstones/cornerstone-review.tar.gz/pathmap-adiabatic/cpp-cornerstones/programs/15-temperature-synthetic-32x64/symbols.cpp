#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("24 8 1 2 2 3 2 2 2 3 7 1 2 2 3 2 2 3 8 1 2 2 3 2 3 2 2 9 1 2 2 3 2 3 2 3 2 11 1 2 2 3 2 3 2 3 3 2 2 13 1 2 2 3 2 3 2 3 3 2 3 2 2 7 1 2 3 2 2 2 3 6 1 2 3 2 2 3 7 1 2 3 2 3 2 2 8 1 2 3 2 3 2 3 2 10 1 2 3 2 3 2 3 3 2 2 12 1 2 3 2 3 2 3 3 2 3 2 2 8 1 3 2 2 2 2 2 3 7 1 3 2 2 2 2 3 8 1 3 2 2 2 3 2 2 9 1 3 2 2 2 3 2 3 2 11 1 3 2 2 2 3 2 3 3 2 2 13 1 3 2 2 2 3 2 3 3 2 3 2 2 11 1 3 2 3 2 2 2 2 2 2 3 10 1 3 2 3 2 2 2 2 2 3 11 1 3 2 3 2 2 2 2 3 2 2 12 1 3 2 3 2 2 2 2 3 2 3 2 14 1 3 2 3 2 2 2 2 3 2 3 3 2 2 16 1 3 2 3 2 2 2 2 3 2 3 3 2 3 2 2");
static Space routine_0(Context& c, const Space* s0);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = restrict_to(bound_space(s0),constant_0);
  return v0_2;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"3 1 4 99 101 108 108 2 1 48 3 1 49"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
