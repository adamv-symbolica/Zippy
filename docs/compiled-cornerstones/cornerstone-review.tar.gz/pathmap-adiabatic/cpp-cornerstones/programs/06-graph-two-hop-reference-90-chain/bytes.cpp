#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,1};
static const Path constant_1 = Path{1,1,1,93};
static const Space constant_2 = literal_text("1 0 ");
static Space routine_0(Context& c, const Space* s0);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  const auto v0_3_branches = branches(c,v0_2);
  std::vector<Space> v0_3_outputs;
  v0_3_outputs.reserve(v0_3_branches.size());
  for (const auto& v0_3_branch : v0_3_branches) {
    const Path v0_3_head{v0_3_branch.first};
    const Space& v0_3_tail = v0_3_branch.second;
    const auto v1_2_branches = branches(c,v0_3_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_3_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const auto v4_3_branches = branches(c,v3_3_tail);
          std::vector<Space> v4_3_outputs;
          v4_3_outputs.reserve(v4_3_branches.size());
          for (const auto& v4_3_branch : v4_3_branches) {
            const Path v4_3_head{v4_3_branch.first};
            const Space& v4_3_tail = v4_3_branch.second;
            const auto v5_2_branches = branches(c,v4_3_tail);
            std::vector<Space> v5_2_outputs;
            v5_2_outputs.reserve(v5_2_branches.size());
            for (const auto& v5_2_branch : v5_2_branches) {
              const Path v5_2_head{v5_2_branch.first};
              const Space& v5_2_tail = v5_2_branch.second;
              const Path v6_2 = concat_path(v4_3_head,v5_2_head);
              const auto v6_3_branches = branches(c,v5_2_tail);
              std::vector<Space> v6_3_outputs;
              v6_3_outputs.reserve(v6_3_branches.size());
              for (const auto& v6_3_branch : v6_3_branches) {
                const Path v6_3_head{v6_3_branch.first};
                const Space& v6_3_tail = v6_3_branch.second;
                const Path v7_2 = concat_path(v6_2,v6_3_head);
                const auto v7_3_branches = branches(c,v6_3_tail);
                std::vector<Space> v7_3_outputs;
                v7_3_outputs.reserve(v7_3_branches.size());
                for (const auto& v7_3_branch : v7_3_branches) {
                  const Path v7_3_head{v7_3_branch.first};
                  const Space& v7_3_tail = v7_3_branch.second;
                  const Path v8_2 = concat_path(v7_2,v7_3_head);
                  const Space v8_3 = routine_1(c, v8_2, v4_2, v7_3_tail, bound_space(s0));
                  v7_3_outputs.push_back(v8_3);
                }
                const Space v7_3 = join_outputs(std::move(v7_3_outputs));
                v6_3_outputs.push_back(v7_3);
              }
              const Space v6_3 = join_outputs(std::move(v6_3_outputs));
              v5_2_outputs.push_back(v6_3);
            }
            const Space v5_2 = join_outputs(std::move(v5_2_outputs));
            v4_3_outputs.push_back(v5_2);
          }
          const Space v4_3 = join_outputs(std::move(v4_3_outputs));
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_3_outputs.push_back(v1_2);
  }
  const Space v0_3 = join_outputs(std::move(v0_3_outputs));
  const Space v0_5 = wrap(v0_3,constant_1);
  return v0_5;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v9_5 = unwrap(s1,constant_0);
  const Space v9_6 = unwrap(v9_5,p0);
  const auto v9_8_branches = branches(c,v9_6);
  std::vector<Space> v9_8_outputs;
  v9_8_outputs.reserve(v9_8_branches.size());
  for (const auto& v9_8_branch : v9_8_branches) {
    const Path v9_8_head{v9_8_branch.first};
    const Space& v9_8_tail = v9_8_branch.second;
    const auto v10_2_branches = branches(c,v9_8_tail);
    std::vector<Space> v10_2_outputs;
    v10_2_outputs.reserve(v10_2_branches.size());
    for (const auto& v10_2_branch : v10_2_branches) {
      const Path v10_2_head{v10_2_branch.first};
      const Space& v10_2_tail = v10_2_branch.second;
      const Path v11_2 = concat_path(v9_8_head,v10_2_head);
      const auto v11_3_branches = branches(c,v10_2_tail);
      std::vector<Space> v11_3_outputs;
      v11_3_outputs.reserve(v11_3_branches.size());
      for (const auto& v11_3_branch : v11_3_branches) {
        const Path v11_3_head{v11_3_branch.first};
        const Space& v11_3_tail = v11_3_branch.second;
        const Space v12_2 = subtract(v11_3_tail,constant_2);
        const Path v12_3 = concat_path(v11_2,v11_3_head);
        const Space v12_4 = wrap(v12_2,v12_3);
        v11_3_outputs.push_back(v12_4);
      }
      const Space v11_3 = join_outputs(std::move(v11_3_outputs));
      v10_2_outputs.push_back(v11_3);
    }
    const Space v10_2 = join_outputs(std::move(v10_2_outputs));
    v9_8_outputs.push_back(v10_2);
  }
  const Space v9_8 = join_outputs(std::move(v9_8_outputs));
  const Space v9_9 = wrap(v9_8,p1);
  return v9_9;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
