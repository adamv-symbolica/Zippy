# temperature — NOAA committed slice

Family: `programs`. The entry expression and reachable symbolic routines are in [symbolic.zippy](symbolic.zippy).

| Generated source | Encoding | Source bytes | Host callbacks | Standalone |
|---|---|---:|---:|---|
| [symbols.cpp](symbols.cpp) | symbol labels | 885 | 0 | true |
 [bits.cpp](bits.cpp) | Fibonacci-coded intern IDs | 982 | 0 | true |
 [bytes.cpp](bytes.cpp) | four-byte big-endian intern IDs | 1034 | 0 | true |

Each translation unit contains `main`, typed graph locals, inline control-flow loops, and all reachable routines.
[encodings.json](encodings.json) maps every interned symbol to its actual bit and byte codewords.
The corresponding `*.input.txt` contains the numeric protocol request for this exact fixture;
`*.bindings.json` identifies environment slots and symbolic labels. Digit labels are offset by one (OpenFst reserves zero).
The graph dumps beside each source show the optimized executor graph used for emission.
A callback count above zero requires the JVM callback bridge or explicit native function bindings;
its input file alone cannot supply those callbacks. See the bundle README for compilation.
