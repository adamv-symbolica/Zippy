#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("94 4 1 2 3 4 4 1 2 7 8 4 1 2 7 13 4 1 2 8 14 4 1 2 8 26 4 1 2 9 10 4 1 2 9 19 4 1 2 10 17 4 1 2 10 20 4 1 2 11 12 4 1 2 11 23 4 1 2 12 23 4 1 2 12 27 4 1 2 13 8 4 1 2 13 14 4 1 2 14 18 4 1 2 14 26 4 1 2 15 9 4 1 2 15 25 4 1 2 16 7 4 1 2 16 22 4 1 2 17 16 4 1 2 17 21 4 1 2 18 11 4 1 2 18 28 4 1 2 19 10 4 1 2 19 20 4 1 2 20 17 4 1 2 20 21 4 1 2 21 16 4 1 2 21 22 4 1 2 22 7 4 1 2 22 13 4 1 2 23 24 4 1 2 23 27 4 1 2 24 3 4 1 2 24 29 4 1 2 25 9 4 1 2 25 19 4 1 2 26 18 4 1 2 26 28 4 1 2 27 24 4 1 2 27 29 4 1 2 28 11 4 1 2 28 12 4 1 2 29 3 4 1 2 29 4 4 5 6 3 4 4 5 6 7 8 4 5 6 7 13 4 5 6 8 14 4 5 6 8 26 4 5 6 9 10 4 5 6 9 19 4 5 6 10 17 4 5 6 10 20 4 5 6 11 12 4 5 6 11 23 4 5 6 12 23 4 5 6 12 27 4 5 6 13 8 4 5 6 13 14 4 5 6 14 18 4 5 6 14 26 4 5 6 15 9 4 5 6 15 25 4 5 6 16 7 4 5 6 16 22 4 5 6 17 16 4 5 6 17 21 4 5 6 18 11 4 5 6 18 28 4 5 6 19 10 4 5 6 19 20 4 5 6 20 17 4 5 6 20 21 4 5 6 21 16 4 5 6 21 22 4 5 6 22 7 4 5 6 22 13 4 5 6 23 24 4 5 6 23 27 4 5 6 24 3 4 5 6 24 29 4 5 6 25 9 4 5 6 25 19 4 5 6 26 18 4 5 6 26 28 4 5 6 27 24 4 5 6 27 29 4 5 6 28 11 4 5 6 28 12 4 5 6 29 3 4 5 6 29 4");
static const Space constant_1 = literal_text("184 4 1 2 3 4 4 1 2 7 8 4 1 2 7 13 4 1 2 8 14 4 1 2 8 26 4 1 2 9 10 4 1 2 9 19 4 1 2 10 17 4 1 2 10 20 4 1 2 11 12 4 1 2 11 23 4 1 2 12 23 4 1 2 12 27 4 1 2 13 8 4 1 2 13 14 4 1 2 14 18 4 1 2 14 26 4 1 2 15 9 4 1 2 15 25 4 1 2 16 7 4 1 2 16 22 4 1 2 17 16 4 1 2 17 21 4 1 2 18 11 4 1 2 18 28 4 1 2 19 10 4 1 2 19 20 4 1 2 20 17 4 1 2 20 21 4 1 2 21 16 4 1 2 21 22 4 1 2 22 7 4 1 2 22 13 4 1 2 23 24 4 1 2 23 27 4 1 2 24 3 4 1 2 24 29 4 1 2 25 9 4 1 2 25 19 4 1 2 26 18 4 1 2 26 28 4 1 2 27 24 4 1 2 27 29 4 1 2 28 11 4 1 2 28 12 4 1 2 29 3 4 1 2 29 4 4 1 6 3 4 4 1 6 7 8 4 1 6 7 13 4 1 6 8 14 4 1 6 8 26 4 1 6 9 10 4 1 6 9 19 4 1 6 10 17 4 1 6 10 20 4 1 6 11 12 4 1 6 11 23 4 1 6 12 23 4 1 6 12 27 4 1 6 13 8 4 1 6 13 14 4 1 6 14 18 4 1 6 14 26 4 1 6 15 9 4 1 6 15 25 4 1 6 16 7 4 1 6 16 22 4 1 6 17 16 4 1 6 17 21 4 1 6 18 11 4 1 6 18 28 4 1 6 19 10 4 1 6 19 20 4 1 6 20 17 4 1 6 20 21 4 1 6 21 16 4 1 6 21 22 4 1 6 22 7 4 1 6 22 13 4 1 6 23 24 4 1 6 23 27 4 1 6 24 3 4 1 6 24 29 4 1 6 25 9 4 1 6 25 19 4 1 6 26 18 4 1 6 26 28 4 1 6 27 24 4 1 6 27 29 4 1 6 28 11 4 1 6 28 12 4 1 6 29 3 4 1 6 29 4 4 5 6 3 4 4 5 6 7 8 4 5 6 7 13 4 5 6 7 14 4 5 6 7 26 4 5 6 8 14 4 5 6 8 18 4 5 6 8 26 4 5 6 8 28 4 5 6 9 10 4 5 6 9 17 4 5 6 9 19 4 5 6 9 20 4 5 6 10 16 4 5 6 10 17 4 5 6 10 20 4 5 6 10 21 4 5 6 11 12 4 5 6 11 23 4 5 6 11 24 4 5 6 11 27 4 5 6 12 23 4 5 6 12 24 4 5 6 12 27 4 5 6 12 29 4 5 6 13 8 4 5 6 13 14 4 5 6 13 18 4 5 6 13 26 4 5 6 14 11 4 5 6 14 18 4 5 6 14 26 4 5 6 14 28 4 5 6 15 9 4 5 6 15 10 4 5 6 15 19 4 5 6 15 25 4 5 6 16 7 4 5 6 16 8 4 5 6 16 13 4 5 6 16 22 4 5 6 17 7 4 5 6 17 16 4 5 6 17 21 4 5 6 17 22 4 5 6 18 11 4 5 6 18 12 4 5 6 18 23 4 5 6 18 28 4 5 6 19 10 4 5 6 19 17 4 5 6 19 20 4 5 6 19 21 4 5 6 20 16 4 5 6 20 17 4 5 6 20 21 4 5 6 20 22 4 5 6 21 7 4 5 6 21 13 4 5 6 21 16 4 5 6 21 22 4 5 6 22 7 4 5 6 22 8 4 5 6 22 13 4 5 6 22 14 4 5 6 23 3 4 5 6 23 24 4 5 6 23 27 4 5 6 23 29 4 5 6 24 3 4 5 6 24 4 4 5 6 24 29 4 5 6 25 9 4 5 6 25 10 4 5 6 25 19 4 5 6 25 20 4 5 6 26 11 4 5 6 26 12 4 5 6 26 18 4 5 6 26 28 4 5 6 27 3 4 5 6 27 4 4 5 6 27 24 4 5 6 27 29 4 5 6 28 11 4 5 6 28 12 4 5 6 28 23 4 5 6 28 27 4 5 6 29 3 4 5 6 29 4");
static const Path constant_2 = Path{1,6};
static const Path constant_3 = Path{1};
static const Path constant_4 = Path{5};
static const Path constant_5 = Path{2};
static const Space constant_6 = literal_text("1 0 ");
static const Path constant_7 = Path{6};
static const Path constant_8 = Path{5,6};
static Space routine_0(Context& c);
static Space routine_1(Context& c, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_2 = routine_1(c, constant_1);
  const Space v0_3 = unite(constant_0,v0_2);
  const Space v0_5 = unwrap(v0_3,constant_2);
  return v0_5;
}

static Space routine_1(Context& c, const Space& s0) {
  const Space v1_2 = unwrap(s0,constant_3);
  const Space v1_4 = unwrap(s0,constant_4);
  const Space v1_5 = unite(v1_2,v1_4);
  const Space v1_6 = wrap(v1_5,constant_3);
  const Space v1_8 = unwrap(v1_2,constant_5);
  const auto v1_10_branches = branches(c,v1_8);
  std::vector<Space> v1_10_outputs;
  v1_10_outputs.reserve(v1_10_branches.size());
  for (const auto& v1_10_branch : v1_10_branches) {
    const Path v1_10_head{v1_10_branch.first};
    const Space& v1_10_tail = v1_10_branch.second;
    const Space v2_2 = subtract(v1_10_tail,constant_6);
    const Space v2_3 = wrap(v2_2,v1_10_head);
    v1_10_outputs.push_back(v2_3);
  }
  const Space v1_10 = join_outputs(std::move(v1_10_outputs));
  const Space v1_12 = unwrap(v1_2,constant_7);
  const Space v1_14 = unwrap(v1_4,constant_7);
  const auto v1_15_branches = branches(c,v1_12);
  std::vector<Space> v1_15_outputs;
  v1_15_outputs.reserve(v1_15_branches.size());
  for (const auto& v1_15_branch : v1_15_branches) {
    const Path v1_15_head{v1_15_branch.first};
    const Space& v1_15_tail = v1_15_branch.second;
    const auto v3_2_branches = branches(c,v1_15_tail);
    std::vector<Space> v3_2_outputs;
    v3_2_outputs.reserve(v3_2_branches.size());
    for (const auto& v3_2_branch : v3_2_branches) {
      const Path v3_2_head{v3_2_branch.first};
      const Space& v3_2_tail = v3_2_branch.second;
      const Space v4_2 = unwrap(v1_14,v3_2_head);
      const Space v4_3 = subtract(v4_2,constant_6);
      v3_2_outputs.push_back(v4_3);
    }
    const Space v3_2 = join_outputs(std::move(v3_2_outputs));
    const Space v3_3 = wrap(v3_2,v1_15_head);
    v1_15_outputs.push_back(v3_3);
  }
  const Space v1_15 = join_outputs(std::move(v1_15_outputs));
  const Space v1_16 = unite(v1_10,v1_15);
  const auto v1_18_branches = branches(c,v1_14);
  std::vector<Space> v1_18_outputs;
  v1_18_outputs.reserve(v1_18_branches.size());
  for (const auto& v1_18_branch : v1_18_branches) {
    const Path v1_18_head{v1_18_branch.first};
    const Space& v1_18_tail = v1_18_branch.second;
    const auto v5_2_branches = branches(c,v1_18_tail);
    std::vector<Space> v5_2_outputs;
    v5_2_outputs.reserve(v5_2_branches.size());
    for (const auto& v5_2_branch : v5_2_branches) {
      const Path v5_2_head{v5_2_branch.first};
      const Space& v5_2_tail = v5_2_branch.second;
      const Space v6_2 = unwrap(v1_12,v5_2_head);
      const Space v6_3 = subtract(v6_2,constant_6);
      v5_2_outputs.push_back(v6_3);
    }
    const Space v5_2 = join_outputs(std::move(v5_2_outputs));
    const Space v5_3 = wrap(v5_2,v1_18_head);
    v1_18_outputs.push_back(v5_3);
  }
  const Space v1_18 = join_outputs(std::move(v1_18_outputs));
  const Space v1_19 = unite(v1_16,v1_18);
  const auto v1_21_branches = branches(c,v1_14);
  std::vector<Space> v1_21_outputs;
  v1_21_outputs.reserve(v1_21_branches.size());
  for (const auto& v1_21_branch : v1_21_branches) {
    const Path v1_21_head{v1_21_branch.first};
    const Space& v1_21_tail = v1_21_branch.second;
    const auto v7_2_branches = branches(c,v1_21_tail);
    std::vector<Space> v7_2_outputs;
    v7_2_outputs.reserve(v7_2_branches.size());
    for (const auto& v7_2_branch : v7_2_branches) {
      const Path v7_2_head{v7_2_branch.first};
      const Space& v7_2_tail = v7_2_branch.second;
      const Space v8_2 = unwrap(v1_14,v7_2_head);
      const Space v8_3 = subtract(v8_2,constant_6);
      v7_2_outputs.push_back(v8_3);
    }
    const Space v7_2 = join_outputs(std::move(v7_2_outputs));
    const Space v7_3 = wrap(v7_2,v1_21_head);
    v1_21_outputs.push_back(v7_3);
  }
  const Space v1_21 = join_outputs(std::move(v1_21_outputs));
  const Space v1_22 = unite(v1_19,v1_21);
  const Space v1_24 = unwrap(s0,constant_2);
  const Space v1_25 = subtract(v1_22,v1_24);
  const Space v1_27 = unwrap(s0,constant_8);
  const Space v1_28 = subtract(v1_25,v1_27);
  const Space v1_29 = wrap(v1_28,constant_8);
  const Space v1_30 = unite(v1_6,v1_29);
  const Space v1_31 = unite(v1_30,s0);
  Space v1_36 = v1_31;
  for (;;) {
    const Space v9_1 = unwrap(v1_36,constant_3);
    const Space v9_2 = unwrap(v1_36,constant_4);
    const Space v9_3 = unite(v9_1,v9_2);
    const Space v9_4 = wrap(v9_3,constant_3);
    const Space v9_5 = unwrap(v9_1,constant_5);
    const auto v9_6_branches = branches(c,v9_5);
    std::vector<Space> v9_6_outputs;
    v9_6_outputs.reserve(v9_6_branches.size());
    for (const auto& v9_6_branch : v9_6_branches) {
      const Path v9_6_head{v9_6_branch.first};
      const Space& v9_6_tail = v9_6_branch.second;
      const Space v10_2 = subtract(v9_6_tail,constant_6);
      const Space v10_3 = wrap(v10_2,v9_6_head);
      v9_6_outputs.push_back(v10_3);
    }
    const Space v9_6 = join_outputs(std::move(v9_6_outputs));
    const Space v9_7 = unwrap(v9_1,constant_7);
    const Space v9_8 = unwrap(v9_2,constant_7);
    const auto v9_9_branches = branches(c,v9_7);
    std::vector<Space> v9_9_outputs;
    v9_9_outputs.reserve(v9_9_branches.size());
    for (const auto& v9_9_branch : v9_9_branches) {
      const Path v9_9_head{v9_9_branch.first};
      const Space& v9_9_tail = v9_9_branch.second;
      const auto v11_2_branches = branches(c,v9_9_tail);
      std::vector<Space> v11_2_outputs;
      v11_2_outputs.reserve(v11_2_branches.size());
      for (const auto& v11_2_branch : v11_2_branches) {
        const Path v11_2_head{v11_2_branch.first};
        const Space& v11_2_tail = v11_2_branch.second;
        const Space v12_2 = unwrap(v9_8,v11_2_head);
        const Space v12_3 = subtract(v12_2,constant_6);
        v11_2_outputs.push_back(v12_3);
      }
      const Space v11_2 = join_outputs(std::move(v11_2_outputs));
      const Space v11_3 = wrap(v11_2,v9_9_head);
      v9_9_outputs.push_back(v11_3);
    }
    const Space v9_9 = join_outputs(std::move(v9_9_outputs));
    const Space v9_10 = unite(v9_6,v9_9);
    const auto v9_11_branches = branches(c,v9_8);
    std::vector<Space> v9_11_outputs;
    v9_11_outputs.reserve(v9_11_branches.size());
    for (const auto& v9_11_branch : v9_11_branches) {
      const Path v9_11_head{v9_11_branch.first};
      const Space& v9_11_tail = v9_11_branch.second;
      const auto v13_2_branches = branches(c,v9_11_tail);
      std::vector<Space> v13_2_outputs;
      v13_2_outputs.reserve(v13_2_branches.size());
      for (const auto& v13_2_branch : v13_2_branches) {
        const Path v13_2_head{v13_2_branch.first};
        const Space& v13_2_tail = v13_2_branch.second;
        const Space v14_2 = unwrap(v9_7,v13_2_head);
        const Space v14_3 = subtract(v14_2,constant_6);
        v13_2_outputs.push_back(v14_3);
      }
      const Space v13_2 = join_outputs(std::move(v13_2_outputs));
      const Space v13_3 = wrap(v13_2,v9_11_head);
      v9_11_outputs.push_back(v13_3);
    }
    const Space v9_11 = join_outputs(std::move(v9_11_outputs));
    const Space v9_12 = unite(v9_10,v9_11);
    const auto v9_13_branches = branches(c,v9_8);
    std::vector<Space> v9_13_outputs;
    v9_13_outputs.reserve(v9_13_branches.size());
    for (const auto& v9_13_branch : v9_13_branches) {
      const Path v9_13_head{v9_13_branch.first};
      const Space& v9_13_tail = v9_13_branch.second;
      const auto v15_2_branches = branches(c,v9_13_tail);
      std::vector<Space> v15_2_outputs;
      v15_2_outputs.reserve(v15_2_branches.size());
      for (const auto& v15_2_branch : v15_2_branches) {
        const Path v15_2_head{v15_2_branch.first};
        const Space& v15_2_tail = v15_2_branch.second;
        const Space v16_2 = unwrap(v9_8,v15_2_head);
        const Space v16_3 = subtract(v16_2,constant_6);
        v15_2_outputs.push_back(v16_3);
      }
      const Space v15_2 = join_outputs(std::move(v15_2_outputs));
      const Space v15_3 = wrap(v15_2,v9_13_head);
      v9_13_outputs.push_back(v15_3);
    }
    const Space v9_13 = join_outputs(std::move(v9_13_outputs));
    const Space v9_14 = unite(v9_12,v9_13);
    const Space v9_15 = unwrap(v1_36,constant_2);
    const Space v9_16 = subtract(v9_14,v9_15);
    const Space v9_17 = unwrap(v1_36,constant_8);
    const Space v9_18 = subtract(v9_16,v9_17);
    const Space v9_19 = wrap(v9_18,constant_8);
    const Space v9_20 = unite(v9_4,v9_19);
    const Space v9_21 = unite(v9_20,v1_36);
    Space v1_36_next = unite(v1_36,v9_21);
    if (equal(v1_36_next,v1_36)) break;
    v1_36 = std::move(v1_36_next);
  }
  const Space v1_37 = unite(s0,v1_36);
  return v1_37;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"29 1 8 99 111 109 112 108 101 116 101 2 4 101 100 103 101 3 3 110 50 51 4 3 110 50 52 5 5 100 101 108 116 97 6 4 112 97 116 104 7 3 110 49 48 8 3 110 49 50 9 2 110 50 10 2 110 52 11 3 110 49 55 12 3 110 49 56 13 3 110 49 49 14 3 110 49 51 15 2 110 48 16 2 110 56 17 2 110 54 18 3 110 49 53 19 2 110 51 20 2 110 53 21 2 110 55 22 2 110 57 23 3 110 49 57 24 3 110 50 49 25 2 110 49 26 3 110 49 52 27 3 110 50 48 28 3 110 49 54 29 3 110 50 50"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
