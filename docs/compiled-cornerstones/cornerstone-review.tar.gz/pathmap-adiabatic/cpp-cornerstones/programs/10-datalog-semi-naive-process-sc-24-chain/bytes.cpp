#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("94 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 9");
static const Space constant_1 = literal_text("184 16 1 1 1 1 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 2 1 1 1 28 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 5 16 1 1 1 1 1 1 1 3 1 1 1 4 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 6 16 1 1 1 1 1 1 1 3 1 1 1 5 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 7 16 1 1 1 1 1 1 1 3 1 1 1 6 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 20 16 1 1 1 1 1 1 1 3 1 1 1 7 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 9 16 1 1 1 1 1 1 1 3 1 1 1 8 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 10 16 1 1 1 1 1 1 1 3 1 1 1 9 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 11 16 1 1 1 1 1 1 1 3 1 1 1 10 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 12 16 1 1 1 1 1 1 1 3 1 1 1 11 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 13 16 1 1 1 1 1 1 1 3 1 1 1 12 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 14 16 1 1 1 1 1 1 1 3 1 1 1 13 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 15 16 1 1 1 1 1 1 1 3 1 1 1 14 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 16 16 1 1 1 1 1 1 1 3 1 1 1 15 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 17 16 1 1 1 1 1 1 1 3 1 1 1 16 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 18 16 1 1 1 1 1 1 1 3 1 1 1 17 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 19 16 1 1 1 1 1 1 1 3 1 1 1 18 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 21 16 1 1 1 1 1 1 1 3 1 1 1 19 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 24 16 1 1 1 1 1 1 1 3 1 1 1 20 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 22 16 1 1 1 1 1 1 1 3 1 1 1 21 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 22 1 1 1 23 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 25 16 1 1 1 1 1 1 1 3 1 1 1 24 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 26 16 1 1 1 1 1 1 1 3 1 1 1 25 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 27 16 1 1 1 1 1 1 1 3 1 1 1 26 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 27 1 1 1 28 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 8 16 1 1 1 1 1 1 1 3 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 5 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 4 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 6 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 5 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 7 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 6 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 20 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 7 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 8 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 9 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 11 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 10 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 12 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 11 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 13 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 12 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 14 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 13 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 15 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 14 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 16 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 15 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 17 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 16 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 18 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 17 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 19 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 18 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 21 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 19 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 24 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 20 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 22 16 1 1 1 29 1 1 1 2 1 1 1 21 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 22 1 1 1 23 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 25 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 24 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 26 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 25 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 27 16 1 1 1 29 1 1 1 2 1 1 1 26 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 27 1 1 1 28 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 8 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 9 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 10 16 1 1 1 29 1 1 1 2 1 1 1 28 1 1 1 11");
static const Path constant_2 = Path{1,1,1,1,1,1,1,2};
static const Path constant_3 = Path{1,1,1,1};
static const Path constant_4 = Path{1,1,1,29};
static const Path constant_5 = Path{1,1,1,2};
static const Path constant_6 = Path{1,1,1,3};
static const Space constant_7 = literal_text("1 0 ");
static const Path constant_8 = Path{1,1,1,29,1,1,1,2};
static Space routine_0(Context& c);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_2 = routine_1(c, constant_1);
  const Space v0_3 = unite(constant_0,v0_2);
  const Space v0_5 = unwrap(v0_3,constant_2);
  return v0_5;
}

static Space routine_1(Context& c, const Space& s0) {
  const Space v1_2 = unwrap(s0,constant_3);
  const Space v1_4 = unwrap(s0,constant_4);
  const Space v1_5 = unite(v1_2,v1_4);
  const Space v1_6 = wrap(v1_5,constant_3);
  const Space v1_8 = unwrap(v1_2,constant_5);
  const auto v1_9_branches = branches(c,v1_8);
  std::vector<Space> v1_9_outputs;
  v1_9_outputs.reserve(v1_9_branches.size());
  for (const auto& v1_9_branch : v1_9_branches) {
    const Path v1_9_head{v1_9_branch.first};
    const Space& v1_9_tail = v1_9_branch.second;
    const auto v2_2_branches = branches(c,v1_9_tail);
    std::vector<Space> v2_2_outputs;
    v2_2_outputs.reserve(v2_2_branches.size());
    for (const auto& v2_2_branch : v2_2_branches) {
      const Path v2_2_head{v2_2_branch.first};
      const Space& v2_2_tail = v2_2_branch.second;
      const Path v3_2 = concat_path(v1_9_head,v2_2_head);
      const auto v3_3_branches = branches(c,v2_2_tail);
      std::vector<Space> v3_3_outputs;
      v3_3_outputs.reserve(v3_3_branches.size());
      for (const auto& v3_3_branch : v3_3_branches) {
        const Path v3_3_head{v3_3_branch.first};
        const Space& v3_3_tail = v3_3_branch.second;
        const Path v4_2 = concat_path(v3_2,v3_3_head);
        const auto v4_3_branches = branches(c,v3_3_tail);
        std::vector<Space> v4_3_outputs;
        v4_3_outputs.reserve(v4_3_branches.size());
        for (const auto& v4_3_branch : v4_3_branches) {
          const Path v4_3_head{v4_3_branch.first};
          const Space& v4_3_tail = v4_3_branch.second;
          const auto v5_2_branches = branches(c,v4_3_tail);
          std::vector<Space> v5_2_outputs;
          v5_2_outputs.reserve(v5_2_branches.size());
          for (const auto& v5_2_branch : v5_2_branches) {
            const Path v5_2_head{v5_2_branch.first};
            const Space& v5_2_tail = v5_2_branch.second;
            const auto v6_2_branches = branches(c,v5_2_tail);
            std::vector<Space> v6_2_outputs;
            v6_2_outputs.reserve(v6_2_branches.size());
            for (const auto& v6_2_branch : v6_2_branches) {
              const Path v6_2_head{v6_2_branch.first};
              const Space& v6_2_tail = v6_2_branch.second;
              const Path v7_2 = concat_path(v5_2_head,v6_2_head);
              const auto v7_3_branches = branches(c,v6_2_tail);
              std::vector<Space> v7_3_outputs;
              v7_3_outputs.reserve(v7_3_branches.size());
              for (const auto& v7_3_branch : v7_3_branches) {
                const Path v7_3_head{v7_3_branch.first};
                const Space& v7_3_tail = v7_3_branch.second;
                const Path v8_2 = concat_path(v7_2,v7_3_head);
                const auto v8_3_branches = branches(c,v7_3_tail);
                std::vector<Space> v8_3_outputs;
                v8_3_outputs.reserve(v8_3_branches.size());
                for (const auto& v8_3_branch : v8_3_branches) {
                  const Path v8_3_head{v8_3_branch.first};
                  const Space& v8_3_tail = v8_3_branch.second;
                  const Path v9_2 = concat_path(v8_2,v8_3_head);
                  const Space v9_3 = routine_2(c, v9_2, v8_3_tail, s0);
                  v8_3_outputs.push_back(v9_3);
                }
                const Space v8_3 = join_outputs(std::move(v8_3_outputs));
                v7_3_outputs.push_back(v8_3);
              }
              const Space v7_3 = join_outputs(std::move(v7_3_outputs));
              v6_2_outputs.push_back(v7_3);
            }
            const Space v6_2 = join_outputs(std::move(v6_2_outputs));
            v5_2_outputs.push_back(v6_2);
          }
          const Space v5_2 = join_outputs(std::move(v5_2_outputs));
          const Path v5_3 = concat_path(v4_2,v4_3_head);
          const Space v5_4 = wrap(v5_2,v5_3);
          v4_3_outputs.push_back(v5_4);
        }
        const Space v4_3 = join_outputs(std::move(v4_3_outputs));
        v3_3_outputs.push_back(v4_3);
      }
      const Space v3_3 = join_outputs(std::move(v3_3_outputs));
      v2_2_outputs.push_back(v3_3);
    }
    const Space v2_2 = join_outputs(std::move(v2_2_outputs));
    v1_9_outputs.push_back(v2_2);
  }
  const Space v1_9 = join_outputs(std::move(v1_9_outputs));
  const Space v1_11 = unwrap(v1_2,constant_6);
  const auto v1_13_branches = branches(c,v1_11);
  std::vector<Space> v1_13_outputs;
  v1_13_outputs.reserve(v1_13_branches.size());
  for (const auto& v1_13_branch : v1_13_branches) {
    const Path v1_13_head{v1_13_branch.first};
    const Space& v1_13_tail = v1_13_branch.second;
    const auto v10_2_branches = branches(c,v1_13_tail);
    std::vector<Space> v10_2_outputs;
    v10_2_outputs.reserve(v10_2_branches.size());
    for (const auto& v10_2_branch : v10_2_branches) {
      const Path v10_2_head{v10_2_branch.first};
      const Space& v10_2_tail = v10_2_branch.second;
      const Path v11_2 = concat_path(v1_13_head,v10_2_head);
      const auto v11_3_branches = branches(c,v10_2_tail);
      std::vector<Space> v11_3_outputs;
      v11_3_outputs.reserve(v11_3_branches.size());
      for (const auto& v11_3_branch : v11_3_branches) {
        const Path v11_3_head{v11_3_branch.first};
        const Space& v11_3_tail = v11_3_branch.second;
        const Path v12_2 = concat_path(v11_2,v11_3_head);
        const auto v12_3_branches = branches(c,v11_3_tail);
        std::vector<Space> v12_3_outputs;
        v12_3_outputs.reserve(v12_3_branches.size());
        for (const auto& v12_3_branch : v12_3_branches) {
          const Path v12_3_head{v12_3_branch.first};
          const Space& v12_3_tail = v12_3_branch.second;
          const Space v13_2 = subtract(v12_3_tail,constant_7);
          const Path v13_3 = concat_path(v12_2,v12_3_head);
          const Space v13_4 = wrap(v13_2,v13_3);
          v12_3_outputs.push_back(v13_4);
        }
        const Space v12_3 = join_outputs(std::move(v12_3_outputs));
        v11_3_outputs.push_back(v12_3);
      }
      const Space v11_3 = join_outputs(std::move(v11_3_outputs));
      v10_2_outputs.push_back(v11_3);
    }
    const Space v10_2 = join_outputs(std::move(v10_2_outputs));
    v1_13_outputs.push_back(v10_2);
  }
  const Space v1_13 = join_outputs(std::move(v1_13_outputs));
  const Space v1_14 = unite(v1_9,v1_13);
  const Space v1_15 = unwrap(v1_4,constant_5);
  const auto v1_16_branches = branches(c,v1_15);
  std::vector<Space> v1_16_outputs;
  v1_16_outputs.reserve(v1_16_branches.size());
  for (const auto& v1_16_branch : v1_16_branches) {
    const Path v1_16_head{v1_16_branch.first};
    const Space& v1_16_tail = v1_16_branch.second;
    const auto v14_2_branches = branches(c,v1_16_tail);
    std::vector<Space> v14_2_outputs;
    v14_2_outputs.reserve(v14_2_branches.size());
    for (const auto& v14_2_branch : v14_2_branches) {
      const Path v14_2_head{v14_2_branch.first};
      const Space& v14_2_tail = v14_2_branch.second;
      const Path v15_2 = concat_path(v1_16_head,v14_2_head);
      const auto v15_3_branches = branches(c,v14_2_tail);
      std::vector<Space> v15_3_outputs;
      v15_3_outputs.reserve(v15_3_branches.size());
      for (const auto& v15_3_branch : v15_3_branches) {
        const Path v15_3_head{v15_3_branch.first};
        const Space& v15_3_tail = v15_3_branch.second;
        const Path v16_2 = concat_path(v15_2,v15_3_head);
        const auto v16_3_branches = branches(c,v15_3_tail);
        std::vector<Space> v16_3_outputs;
        v16_3_outputs.reserve(v16_3_branches.size());
        for (const auto& v16_3_branch : v16_3_branches) {
          const Path v16_3_head{v16_3_branch.first};
          const Space& v16_3_tail = v16_3_branch.second;
          const auto v17_2_branches = branches(c,v16_3_tail);
          std::vector<Space> v17_2_outputs;
          v17_2_outputs.reserve(v17_2_branches.size());
          for (const auto& v17_2_branch : v17_2_branches) {
            const Path v17_2_head{v17_2_branch.first};
            const Space& v17_2_tail = v17_2_branch.second;
            const auto v18_2_branches = branches(c,v17_2_tail);
            std::vector<Space> v18_2_outputs;
            v18_2_outputs.reserve(v18_2_branches.size());
            for (const auto& v18_2_branch : v18_2_branches) {
              const Path v18_2_head{v18_2_branch.first};
              const Space& v18_2_tail = v18_2_branch.second;
              const Path v19_2 = concat_path(v17_2_head,v18_2_head);
              const auto v19_3_branches = branches(c,v18_2_tail);
              std::vector<Space> v19_3_outputs;
              v19_3_outputs.reserve(v19_3_branches.size());
              for (const auto& v19_3_branch : v19_3_branches) {
                const Path v19_3_head{v19_3_branch.first};
                const Space& v19_3_tail = v19_3_branch.second;
                const Path v20_2 = concat_path(v19_2,v19_3_head);
                const auto v20_3_branches = branches(c,v19_3_tail);
                std::vector<Space> v20_3_outputs;
                v20_3_outputs.reserve(v20_3_branches.size());
                for (const auto& v20_3_branch : v20_3_branches) {
                  const Path v20_3_head{v20_3_branch.first};
                  const Space& v20_3_tail = v20_3_branch.second;
                  const Path v21_2 = concat_path(v20_2,v20_3_head);
                  const Space v21_3 = routine_3(c, v21_2, v20_3_tail, s0);
                  v20_3_outputs.push_back(v21_3);
                }
                const Space v20_3 = join_outputs(std::move(v20_3_outputs));
                v19_3_outputs.push_back(v20_3);
              }
              const Space v19_3 = join_outputs(std::move(v19_3_outputs));
              v18_2_outputs.push_back(v19_3);
            }
            const Space v18_2 = join_outputs(std::move(v18_2_outputs));
            v17_2_outputs.push_back(v18_2);
          }
          const Space v17_2 = join_outputs(std::move(v17_2_outputs));
          const Path v17_3 = concat_path(v16_2,v16_3_head);
          const Space v17_4 = wrap(v17_2,v17_3);
          v16_3_outputs.push_back(v17_4);
        }
        const Space v16_3 = join_outputs(std::move(v16_3_outputs));
        v15_3_outputs.push_back(v16_3);
      }
      const Space v15_3 = join_outputs(std::move(v15_3_outputs));
      v14_2_outputs.push_back(v15_3);
    }
    const Space v14_2 = join_outputs(std::move(v14_2_outputs));
    v1_16_outputs.push_back(v14_2);
  }
  const Space v1_16 = join_outputs(std::move(v1_16_outputs));
  const Space v1_17 = unite(v1_14,v1_16);
  const auto v1_18_branches = branches(c,v1_15);
  std::vector<Space> v1_18_outputs;
  v1_18_outputs.reserve(v1_18_branches.size());
  for (const auto& v1_18_branch : v1_18_branches) {
    const Path v1_18_head{v1_18_branch.first};
    const Space& v1_18_tail = v1_18_branch.second;
    const auto v22_2_branches = branches(c,v1_18_tail);
    std::vector<Space> v22_2_outputs;
    v22_2_outputs.reserve(v22_2_branches.size());
    for (const auto& v22_2_branch : v22_2_branches) {
      const Path v22_2_head{v22_2_branch.first};
      const Space& v22_2_tail = v22_2_branch.second;
      const Path v23_2 = concat_path(v1_18_head,v22_2_head);
      const auto v23_3_branches = branches(c,v22_2_tail);
      std::vector<Space> v23_3_outputs;
      v23_3_outputs.reserve(v23_3_branches.size());
      for (const auto& v23_3_branch : v23_3_branches) {
        const Path v23_3_head{v23_3_branch.first};
        const Space& v23_3_tail = v23_3_branch.second;
        const Path v24_2 = concat_path(v23_2,v23_3_head);
        const auto v24_3_branches = branches(c,v23_3_tail);
        std::vector<Space> v24_3_outputs;
        v24_3_outputs.reserve(v24_3_branches.size());
        for (const auto& v24_3_branch : v24_3_branches) {
          const Path v24_3_head{v24_3_branch.first};
          const Space& v24_3_tail = v24_3_branch.second;
          const auto v25_2_branches = branches(c,v24_3_tail);
          std::vector<Space> v25_2_outputs;
          v25_2_outputs.reserve(v25_2_branches.size());
          for (const auto& v25_2_branch : v25_2_branches) {
            const Path v25_2_head{v25_2_branch.first};
            const Space& v25_2_tail = v25_2_branch.second;
            const auto v26_2_branches = branches(c,v25_2_tail);
            std::vector<Space> v26_2_outputs;
            v26_2_outputs.reserve(v26_2_branches.size());
            for (const auto& v26_2_branch : v26_2_branches) {
              const Path v26_2_head{v26_2_branch.first};
              const Space& v26_2_tail = v26_2_branch.second;
              const Path v27_2 = concat_path(v25_2_head,v26_2_head);
              const auto v27_3_branches = branches(c,v26_2_tail);
              std::vector<Space> v27_3_outputs;
              v27_3_outputs.reserve(v27_3_branches.size());
              for (const auto& v27_3_branch : v27_3_branches) {
                const Path v27_3_head{v27_3_branch.first};
                const Space& v27_3_tail = v27_3_branch.second;
                const Path v28_2 = concat_path(v27_2,v27_3_head);
                const auto v28_3_branches = branches(c,v27_3_tail);
                std::vector<Space> v28_3_outputs;
                v28_3_outputs.reserve(v28_3_branches.size());
                for (const auto& v28_3_branch : v28_3_branches) {
                  const Path v28_3_head{v28_3_branch.first};
                  const Space& v28_3_tail = v28_3_branch.second;
                  const Path v29_2 = concat_path(v28_2,v28_3_head);
                  const Space v29_3 = routine_4(c, v29_2, v28_3_tail, s0);
                  v28_3_outputs.push_back(v29_3);
                }
                const Space v28_3 = join_outputs(std::move(v28_3_outputs));
                v27_3_outputs.push_back(v28_3);
              }
              const Space v27_3 = join_outputs(std::move(v27_3_outputs));
              v26_2_outputs.push_back(v27_3);
            }
            const Space v26_2 = join_outputs(std::move(v26_2_outputs));
            v25_2_outputs.push_back(v26_2);
          }
          const Space v25_2 = join_outputs(std::move(v25_2_outputs));
          const Path v25_3 = concat_path(v24_2,v24_3_head);
          const Space v25_4 = wrap(v25_2,v25_3);
          v24_3_outputs.push_back(v25_4);
        }
        const Space v24_3 = join_outputs(std::move(v24_3_outputs));
        v23_3_outputs.push_back(v24_3);
      }
      const Space v23_3 = join_outputs(std::move(v23_3_outputs));
      v22_2_outputs.push_back(v23_3);
    }
    const Space v22_2 = join_outputs(std::move(v22_2_outputs));
    v1_18_outputs.push_back(v22_2);
  }
  const Space v1_18 = join_outputs(std::move(v1_18_outputs));
  const Space v1_19 = unite(v1_17,v1_18);
  const Space v1_21 = unwrap(s0,constant_2);
  const Space v1_22 = subtract(v1_19,v1_21);
  const Space v1_24 = unwrap(s0,constant_8);
  const Space v1_25 = subtract(v1_22,v1_24);
  const Space v1_26 = wrap(v1_25,constant_8);
  const Space v1_27 = unite(v1_6,v1_26);
  const Space v1_28 = unite(v1_27,s0);
  Space v1_30 = v1_28;
  for (;;) {
    const Space v30_1 = unwrap(v1_30,constant_3);
    const Space v30_2 = unwrap(v1_30,constant_4);
    const Space v30_3 = unite(v30_1,v30_2);
    const Space v30_4 = wrap(v30_3,constant_3);
    const Space v30_5 = unwrap(v30_1,constant_5);
    const auto v30_6_branches = branches(c,v30_5);
    std::vector<Space> v30_6_outputs;
    v30_6_outputs.reserve(v30_6_branches.size());
    for (const auto& v30_6_branch : v30_6_branches) {
      const Path v30_6_head{v30_6_branch.first};
      const Space& v30_6_tail = v30_6_branch.second;
      const auto v31_2_branches = branches(c,v30_6_tail);
      std::vector<Space> v31_2_outputs;
      v31_2_outputs.reserve(v31_2_branches.size());
      for (const auto& v31_2_branch : v31_2_branches) {
        const Path v31_2_head{v31_2_branch.first};
        const Space& v31_2_tail = v31_2_branch.second;
        const Path v32_2 = concat_path(v30_6_head,v31_2_head);
        const auto v32_3_branches = branches(c,v31_2_tail);
        std::vector<Space> v32_3_outputs;
        v32_3_outputs.reserve(v32_3_branches.size());
        for (const auto& v32_3_branch : v32_3_branches) {
          const Path v32_3_head{v32_3_branch.first};
          const Space& v32_3_tail = v32_3_branch.second;
          const Path v33_2 = concat_path(v32_2,v32_3_head);
          const auto v33_3_branches = branches(c,v32_3_tail);
          std::vector<Space> v33_3_outputs;
          v33_3_outputs.reserve(v33_3_branches.size());
          for (const auto& v33_3_branch : v33_3_branches) {
            const Path v33_3_head{v33_3_branch.first};
            const Space& v33_3_tail = v33_3_branch.second;
            const auto v34_2_branches = branches(c,v33_3_tail);
            std::vector<Space> v34_2_outputs;
            v34_2_outputs.reserve(v34_2_branches.size());
            for (const auto& v34_2_branch : v34_2_branches) {
              const Path v34_2_head{v34_2_branch.first};
              const Space& v34_2_tail = v34_2_branch.second;
              const auto v35_2_branches = branches(c,v34_2_tail);
              std::vector<Space> v35_2_outputs;
              v35_2_outputs.reserve(v35_2_branches.size());
              for (const auto& v35_2_branch : v35_2_branches) {
                const Path v35_2_head{v35_2_branch.first};
                const Space& v35_2_tail = v35_2_branch.second;
                const Path v36_2 = concat_path(v34_2_head,v35_2_head);
                const auto v36_3_branches = branches(c,v35_2_tail);
                std::vector<Space> v36_3_outputs;
                v36_3_outputs.reserve(v36_3_branches.size());
                for (const auto& v36_3_branch : v36_3_branches) {
                  const Path v36_3_head{v36_3_branch.first};
                  const Space& v36_3_tail = v36_3_branch.second;
                  const Path v37_2 = concat_path(v36_2,v36_3_head);
                  const auto v37_3_branches = branches(c,v36_3_tail);
                  std::vector<Space> v37_3_outputs;
                  v37_3_outputs.reserve(v37_3_branches.size());
                  for (const auto& v37_3_branch : v37_3_branches) {
                    const Path v37_3_head{v37_3_branch.first};
                    const Space& v37_3_tail = v37_3_branch.second;
                    const Path v38_2 = concat_path(v37_2,v37_3_head);
                    const Space v38_3 = routine_2(c, v38_2, v37_3_tail, v1_30);
                    v37_3_outputs.push_back(v38_3);
                  }
                  const Space v37_3 = join_outputs(std::move(v37_3_outputs));
                  v36_3_outputs.push_back(v37_3);
                }
                const Space v36_3 = join_outputs(std::move(v36_3_outputs));
                v35_2_outputs.push_back(v36_3);
              }
              const Space v35_2 = join_outputs(std::move(v35_2_outputs));
              v34_2_outputs.push_back(v35_2);
            }
            const Space v34_2 = join_outputs(std::move(v34_2_outputs));
            const Path v34_3 = concat_path(v33_2,v33_3_head);
            const Space v34_4 = wrap(v34_2,v34_3);
            v33_3_outputs.push_back(v34_4);
          }
          const Space v33_3 = join_outputs(std::move(v33_3_outputs));
          v32_3_outputs.push_back(v33_3);
        }
        const Space v32_3 = join_outputs(std::move(v32_3_outputs));
        v31_2_outputs.push_back(v32_3);
      }
      const Space v31_2 = join_outputs(std::move(v31_2_outputs));
      v30_6_outputs.push_back(v31_2);
    }
    const Space v30_6 = join_outputs(std::move(v30_6_outputs));
    const Space v30_7 = unwrap(v30_1,constant_6);
    const auto v30_8_branches = branches(c,v30_7);
    std::vector<Space> v30_8_outputs;
    v30_8_outputs.reserve(v30_8_branches.size());
    for (const auto& v30_8_branch : v30_8_branches) {
      const Path v30_8_head{v30_8_branch.first};
      const Space& v30_8_tail = v30_8_branch.second;
      const auto v39_2_branches = branches(c,v30_8_tail);
      std::vector<Space> v39_2_outputs;
      v39_2_outputs.reserve(v39_2_branches.size());
      for (const auto& v39_2_branch : v39_2_branches) {
        const Path v39_2_head{v39_2_branch.first};
        const Space& v39_2_tail = v39_2_branch.second;
        const Path v40_2 = concat_path(v30_8_head,v39_2_head);
        const auto v40_3_branches = branches(c,v39_2_tail);
        std::vector<Space> v40_3_outputs;
        v40_3_outputs.reserve(v40_3_branches.size());
        for (const auto& v40_3_branch : v40_3_branches) {
          const Path v40_3_head{v40_3_branch.first};
          const Space& v40_3_tail = v40_3_branch.second;
          const Path v41_2 = concat_path(v40_2,v40_3_head);
          const auto v41_3_branches = branches(c,v40_3_tail);
          std::vector<Space> v41_3_outputs;
          v41_3_outputs.reserve(v41_3_branches.size());
          for (const auto& v41_3_branch : v41_3_branches) {
            const Path v41_3_head{v41_3_branch.first};
            const Space& v41_3_tail = v41_3_branch.second;
            const Space v42_2 = subtract(v41_3_tail,constant_7);
            const Path v42_3 = concat_path(v41_2,v41_3_head);
            const Space v42_4 = wrap(v42_2,v42_3);
            v41_3_outputs.push_back(v42_4);
          }
          const Space v41_3 = join_outputs(std::move(v41_3_outputs));
          v40_3_outputs.push_back(v41_3);
        }
        const Space v40_3 = join_outputs(std::move(v40_3_outputs));
        v39_2_outputs.push_back(v40_3);
      }
      const Space v39_2 = join_outputs(std::move(v39_2_outputs));
      v30_8_outputs.push_back(v39_2);
    }
    const Space v30_8 = join_outputs(std::move(v30_8_outputs));
    const Space v30_9 = unite(v30_6,v30_8);
    const Space v30_10 = unwrap(v30_2,constant_5);
    const auto v30_11_branches = branches(c,v30_10);
    std::vector<Space> v30_11_outputs;
    v30_11_outputs.reserve(v30_11_branches.size());
    for (const auto& v30_11_branch : v30_11_branches) {
      const Path v30_11_head{v30_11_branch.first};
      const Space& v30_11_tail = v30_11_branch.second;
      const auto v43_2_branches = branches(c,v30_11_tail);
      std::vector<Space> v43_2_outputs;
      v43_2_outputs.reserve(v43_2_branches.size());
      for (const auto& v43_2_branch : v43_2_branches) {
        const Path v43_2_head{v43_2_branch.first};
        const Space& v43_2_tail = v43_2_branch.second;
        const Path v44_2 = concat_path(v30_11_head,v43_2_head);
        const auto v44_3_branches = branches(c,v43_2_tail);
        std::vector<Space> v44_3_outputs;
        v44_3_outputs.reserve(v44_3_branches.size());
        for (const auto& v44_3_branch : v44_3_branches) {
          const Path v44_3_head{v44_3_branch.first};
          const Space& v44_3_tail = v44_3_branch.second;
          const Path v45_2 = concat_path(v44_2,v44_3_head);
          const auto v45_3_branches = branches(c,v44_3_tail);
          std::vector<Space> v45_3_outputs;
          v45_3_outputs.reserve(v45_3_branches.size());
          for (const auto& v45_3_branch : v45_3_branches) {
            const Path v45_3_head{v45_3_branch.first};
            const Space& v45_3_tail = v45_3_branch.second;
            const auto v46_2_branches = branches(c,v45_3_tail);
            std::vector<Space> v46_2_outputs;
            v46_2_outputs.reserve(v46_2_branches.size());
            for (const auto& v46_2_branch : v46_2_branches) {
              const Path v46_2_head{v46_2_branch.first};
              const Space& v46_2_tail = v46_2_branch.second;
              const auto v47_2_branches = branches(c,v46_2_tail);
              std::vector<Space> v47_2_outputs;
              v47_2_outputs.reserve(v47_2_branches.size());
              for (const auto& v47_2_branch : v47_2_branches) {
                const Path v47_2_head{v47_2_branch.first};
                const Space& v47_2_tail = v47_2_branch.second;
                const Path v48_2 = concat_path(v46_2_head,v47_2_head);
                const auto v48_3_branches = branches(c,v47_2_tail);
                std::vector<Space> v48_3_outputs;
                v48_3_outputs.reserve(v48_3_branches.size());
                for (const auto& v48_3_branch : v48_3_branches) {
                  const Path v48_3_head{v48_3_branch.first};
                  const Space& v48_3_tail = v48_3_branch.second;
                  const Path v49_2 = concat_path(v48_2,v48_3_head);
                  const auto v49_3_branches = branches(c,v48_3_tail);
                  std::vector<Space> v49_3_outputs;
                  v49_3_outputs.reserve(v49_3_branches.size());
                  for (const auto& v49_3_branch : v49_3_branches) {
                    const Path v49_3_head{v49_3_branch.first};
                    const Space& v49_3_tail = v49_3_branch.second;
                    const Path v50_2 = concat_path(v49_2,v49_3_head);
                    const Space v50_3 = routine_3(c, v50_2, v49_3_tail, v1_30);
                    v49_3_outputs.push_back(v50_3);
                  }
                  const Space v49_3 = join_outputs(std::move(v49_3_outputs));
                  v48_3_outputs.push_back(v49_3);
                }
                const Space v48_3 = join_outputs(std::move(v48_3_outputs));
                v47_2_outputs.push_back(v48_3);
              }
              const Space v47_2 = join_outputs(std::move(v47_2_outputs));
              v46_2_outputs.push_back(v47_2);
            }
            const Space v46_2 = join_outputs(std::move(v46_2_outputs));
            const Path v46_3 = concat_path(v45_2,v45_3_head);
            const Space v46_4 = wrap(v46_2,v46_3);
            v45_3_outputs.push_back(v46_4);
          }
          const Space v45_3 = join_outputs(std::move(v45_3_outputs));
          v44_3_outputs.push_back(v45_3);
        }
        const Space v44_3 = join_outputs(std::move(v44_3_outputs));
        v43_2_outputs.push_back(v44_3);
      }
      const Space v43_2 = join_outputs(std::move(v43_2_outputs));
      v30_11_outputs.push_back(v43_2);
    }
    const Space v30_11 = join_outputs(std::move(v30_11_outputs));
    const Space v30_12 = unite(v30_9,v30_11);
    const auto v30_13_branches = branches(c,v30_10);
    std::vector<Space> v30_13_outputs;
    v30_13_outputs.reserve(v30_13_branches.size());
    for (const auto& v30_13_branch : v30_13_branches) {
      const Path v30_13_head{v30_13_branch.first};
      const Space& v30_13_tail = v30_13_branch.second;
      const auto v51_2_branches = branches(c,v30_13_tail);
      std::vector<Space> v51_2_outputs;
      v51_2_outputs.reserve(v51_2_branches.size());
      for (const auto& v51_2_branch : v51_2_branches) {
        const Path v51_2_head{v51_2_branch.first};
        const Space& v51_2_tail = v51_2_branch.second;
        const Path v52_2 = concat_path(v30_13_head,v51_2_head);
        const auto v52_3_branches = branches(c,v51_2_tail);
        std::vector<Space> v52_3_outputs;
        v52_3_outputs.reserve(v52_3_branches.size());
        for (const auto& v52_3_branch : v52_3_branches) {
          const Path v52_3_head{v52_3_branch.first};
          const Space& v52_3_tail = v52_3_branch.second;
          const Path v53_2 = concat_path(v52_2,v52_3_head);
          const auto v53_3_branches = branches(c,v52_3_tail);
          std::vector<Space> v53_3_outputs;
          v53_3_outputs.reserve(v53_3_branches.size());
          for (const auto& v53_3_branch : v53_3_branches) {
            const Path v53_3_head{v53_3_branch.first};
            const Space& v53_3_tail = v53_3_branch.second;
            const auto v54_2_branches = branches(c,v53_3_tail);
            std::vector<Space> v54_2_outputs;
            v54_2_outputs.reserve(v54_2_branches.size());
            for (const auto& v54_2_branch : v54_2_branches) {
              const Path v54_2_head{v54_2_branch.first};
              const Space& v54_2_tail = v54_2_branch.second;
              const auto v55_2_branches = branches(c,v54_2_tail);
              std::vector<Space> v55_2_outputs;
              v55_2_outputs.reserve(v55_2_branches.size());
              for (const auto& v55_2_branch : v55_2_branches) {
                const Path v55_2_head{v55_2_branch.first};
                const Space& v55_2_tail = v55_2_branch.second;
                const Path v56_2 = concat_path(v54_2_head,v55_2_head);
                const auto v56_3_branches = branches(c,v55_2_tail);
                std::vector<Space> v56_3_outputs;
                v56_3_outputs.reserve(v56_3_branches.size());
                for (const auto& v56_3_branch : v56_3_branches) {
                  const Path v56_3_head{v56_3_branch.first};
                  const Space& v56_3_tail = v56_3_branch.second;
                  const Path v57_2 = concat_path(v56_2,v56_3_head);
                  const auto v57_3_branches = branches(c,v56_3_tail);
                  std::vector<Space> v57_3_outputs;
                  v57_3_outputs.reserve(v57_3_branches.size());
                  for (const auto& v57_3_branch : v57_3_branches) {
                    const Path v57_3_head{v57_3_branch.first};
                    const Space& v57_3_tail = v57_3_branch.second;
                    const Path v58_2 = concat_path(v57_2,v57_3_head);
                    const Space v58_3 = routine_4(c, v58_2, v57_3_tail, v1_30);
                    v57_3_outputs.push_back(v58_3);
                  }
                  const Space v57_3 = join_outputs(std::move(v57_3_outputs));
                  v56_3_outputs.push_back(v57_3);
                }
                const Space v56_3 = join_outputs(std::move(v56_3_outputs));
                v55_2_outputs.push_back(v56_3);
              }
              const Space v55_2 = join_outputs(std::move(v55_2_outputs));
              v54_2_outputs.push_back(v55_2);
            }
            const Space v54_2 = join_outputs(std::move(v54_2_outputs));
            const Path v54_3 = concat_path(v53_2,v53_3_head);
            const Space v54_4 = wrap(v54_2,v54_3);
            v53_3_outputs.push_back(v54_4);
          }
          const Space v53_3 = join_outputs(std::move(v53_3_outputs));
          v52_3_outputs.push_back(v53_3);
        }
        const Space v52_3 = join_outputs(std::move(v52_3_outputs));
        v51_2_outputs.push_back(v52_3);
      }
      const Space v51_2 = join_outputs(std::move(v51_2_outputs));
      v30_13_outputs.push_back(v51_2);
    }
    const Space v30_13 = join_outputs(std::move(v30_13_outputs));
    const Space v30_14 = unite(v30_12,v30_13);
    const Space v30_15 = unwrap(v1_30,constant_2);
    const Space v30_16 = subtract(v30_14,v30_15);
    const Space v30_17 = unwrap(v1_30,constant_8);
    const Space v30_18 = subtract(v30_16,v30_17);
    const Space v30_19 = wrap(v30_18,constant_8);
    const Space v30_20 = unite(v30_4,v30_19);
    const Space v30_21 = unite(v30_20,v1_30);
    Space v1_30_next = unite(v1_30,v30_21);
    if (equal(v1_30_next,v1_30)) break;
    v1_30 = std::move(v1_30_next);
  }
  const Space v1_31 = unite(s0,v1_30);
  return v1_31;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v59_4 = unwrap(s1,constant_4);
  const Space v59_6 = unwrap(v59_4,constant_5);
  const Space v59_7 = unwrap(v59_6,p0);
  const Space v59_9 = subtract(v59_7,constant_7);
  return v59_9;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v60_4 = unwrap(s1,constant_3);
  const Space v60_6 = unwrap(v60_4,constant_5);
  const Space v60_7 = unwrap(v60_6,p0);
  const Space v60_9 = subtract(v60_7,constant_7);
  return v60_9;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v61_4 = unwrap(s1,constant_4);
  const Space v61_6 = unwrap(v61_4,constant_5);
  const Space v61_7 = unwrap(v61_6,p0);
  const Space v61_9 = subtract(v61_7,constant_7);
  return v61_9;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
