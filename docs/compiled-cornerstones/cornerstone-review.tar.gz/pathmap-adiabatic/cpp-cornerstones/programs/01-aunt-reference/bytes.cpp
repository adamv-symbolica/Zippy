#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,13};
static const Path constant_1 = Path{1,1,1,11};
static const Path constant_2 = Path{1,1,1,8};
static const Path constant_3 = Path{1,1,1,9};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  const auto v0_2_branches = branches(c,bound_space(s1));
  std::vector<Space> v0_2_outputs;
  v0_2_outputs.reserve(v0_2_branches.size());
  for (const auto& v0_2_branch : v0_2_branches) {
    const Path v0_2_head{v0_2_branch.first};
    const Space& v0_2_tail = v0_2_branch.second;
    const auto v1_2_branches = branches(c,v0_2_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_2_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const Space v4_3 = routine_1(c, v4_2, v3_3_tail, bound_space(s0));
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_2_outputs.push_back(v1_2);
  }
  const Space v0_2 = join_outputs(std::move(v0_2_outputs));
  const Space v0_4 = wrap(v0_2,constant_0);
  return v0_4;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v5_4 = unwrap(s1,constant_1);
  const Space v5_6 = unwrap(s1,constant_2);
  const Space v5_7 = unwrap(v5_6,p0);
  const Space v5_8 = restrict_to(v5_6,v5_7);
  const auto v5_9_branches = branches(c,v5_8);
  std::vector<Space> v5_9_outputs;
  v5_9_outputs.reserve(v5_9_branches.size());
  for (const auto& v5_9_branch : v5_9_branches) {
    const Path v5_9_head{v5_9_branch.first};
    const Space& v5_9_tail = v5_9_branch.second;
    const auto v6_2_branches = branches(c,v5_9_tail);
    std::vector<Space> v6_2_outputs;
    v6_2_outputs.reserve(v6_2_branches.size());
    for (const auto& v6_2_branch : v6_2_branches) {
      const Path v6_2_head{v6_2_branch.first};
      const Space& v6_2_tail = v6_2_branch.second;
      const auto v7_2_branches = branches(c,v6_2_tail);
      std::vector<Space> v7_2_outputs;
      v7_2_outputs.reserve(v7_2_branches.size());
      for (const auto& v7_2_branch : v7_2_branches) {
        const Path v7_2_head{v7_2_branch.first};
        const Space& v7_2_tail = v7_2_branch.second;
        const Space v8_2 = tails_union(v7_2_tail);
        v7_2_outputs.push_back(v8_2);
      }
      const Space v7_2 = join_outputs(std::move(v7_2_outputs));
      v6_2_outputs.push_back(v7_2);
    }
    const Space v6_2 = join_outputs(std::move(v6_2_outputs));
    v5_9_outputs.push_back(v6_2);
  }
  const Space v5_9 = join_outputs(std::move(v5_9_outputs));
  const Space v5_10 = restrict_to(v5_4,v5_9);
  const auto v5_11_branches = branches(c,v5_10);
  std::vector<Space> v5_11_outputs;
  v5_11_outputs.reserve(v5_11_branches.size());
  for (const auto& v5_11_branch : v5_11_branches) {
    const Path v5_11_head{v5_11_branch.first};
    const Space& v5_11_tail = v5_11_branch.second;
    const auto v9_2_branches = branches(c,v5_11_tail);
    std::vector<Space> v9_2_outputs;
    v9_2_outputs.reserve(v9_2_branches.size());
    for (const auto& v9_2_branch : v9_2_branches) {
      const Path v9_2_head{v9_2_branch.first};
      const Space& v9_2_tail = v9_2_branch.second;
      const auto v10_2_branches = branches(c,v9_2_tail);
      std::vector<Space> v10_2_outputs;
      v10_2_outputs.reserve(v10_2_branches.size());
      for (const auto& v10_2_branch : v10_2_branches) {
        const Path v10_2_head{v10_2_branch.first};
        const Space& v10_2_tail = v10_2_branch.second;
        const Space v11_2 = tails_union(v10_2_tail);
        v10_2_outputs.push_back(v11_2);
      }
      const Space v10_2 = join_outputs(std::move(v10_2_outputs));
      v9_2_outputs.push_back(v10_2);
    }
    const Space v9_2 = join_outputs(std::move(v9_2_outputs));
    v5_11_outputs.push_back(v9_2);
  }
  const Space v5_11 = join_outputs(std::move(v5_11_outputs));
  const Space v5_12 = subtract(v5_11,v5_7);
  const Space v5_14 = unwrap(s1,constant_3);
  const Space v5_15 = intersect(v5_12,v5_14);
  const Space v5_16 = wrap(v5_15,p0);
  return v5_16;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
