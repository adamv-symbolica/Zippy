#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{1,1,1,1,1,2,2};
static const Path constant_4 = Path{1,1,2,1,2,2};
static const Path constant_5 = Path{1,1,1,1,2,2};
static const Path constant_6 = Path{2,1,1,1,2,2};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  Space v0_5_result;
  for (int v0_5_label = 1; v0_5_label <= 2; ++v0_5_label) {
    const Space v0_5_tail = child(bound_space(s1),v0_5_label);
    if (v0_5_tail.empty()) continue;
    const Path v0_5_head{v0_5_label};
    const Space v1_2 = singleton(v0_5_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_5_result = unite(v0_5_result,v1_12);
  }
  const Space v0_5 = std::move(v0_5_result);
  const Space v0_7 = wrap(v0_5,constant_3);
  return v0_7;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v4_12_result;
  for (int v4_12_label = 1; v4_12_label <= 2; ++v4_12_label) {
    const Space v4_12_tail = child(s0,v4_12_label);
    if (v4_12_tail.empty()) continue;
    const Path v4_12_head{v4_12_label};
    const Space v5_2 = singleton(v4_12_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_12_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_12_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail, s1);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail, s1);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_12_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_12_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail, s1);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail, s1);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_12_result = unite(v4_12_result,v5_13);
  }
  const Space v4_12 = std::move(v4_12_result);
  return v4_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v14_7 = unwrap(s1,constant_4);
  const Space v14_9 = unwrap(s1,constant_5);
  const Space v14_10 = unwrap(v14_9,p0);
  const Space v14_12 = unwrap(s1,constant_6);
  Space v14_22_result;
  for (int v14_22_label = 1; v14_22_label <= 2; ++v14_22_label) {
    const Space v14_22_tail = child(s0,v14_22_label);
    if (v14_22_tail.empty()) continue;
    const Path v14_22_head{v14_22_label};
    const Space v15_2 = singleton(v14_22_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_22_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_22_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_18;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_10,v14_22_head);
      const Space v20_12 = restrict_to(v14_9,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(v14_7,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = subtract(v20_15,v20_11);
      const Space v20_17 = intersect(v20_16,v14_12);
      v15_18 = compose(v15_10,v20_17);
    }
    const Path v27_6 = concat_path(p0,v14_22_head);
    const Space v15_19 = wrap(v15_18,v27_6);
    const Space v15_20 = unite(v15_8,v15_19);
    v14_22_result = unite(v14_22_result,v15_20);
  }
  const Space v14_22 = std::move(v14_22_result);
  return v14_22;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v28_12_result;
  for (int v28_12_label = 1; v28_12_label <= 2; ++v28_12_label) {
    const Space v28_12_tail = child(s0,v28_12_label);
    if (v28_12_tail.empty()) continue;
    const Path v28_12_head{v28_12_label};
    const Space v29_2 = singleton(v28_12_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_12_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_12_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail, s1);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail, s1);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_12_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_12_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail, s1);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail, s1);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_12_result = unite(v28_12_result,v29_13);
  }
  const Space v28_12 = std::move(v28_12_result);
  return v28_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v38_7 = unwrap(s1,constant_4);
  const Space v38_9 = unwrap(s1,constant_5);
  const Space v38_10 = unwrap(v38_9,p0);
  const Space v38_12 = unwrap(s1,constant_6);
  Space v38_22_result;
  for (int v38_22_label = 1; v38_22_label <= 2; ++v38_22_label) {
    const Space v38_22_tail = child(s0,v38_22_label);
    if (v38_22_tail.empty()) continue;
    const Path v38_22_head{v38_22_label};
    const Space v39_2 = singleton(v38_22_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_22_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_22_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail, s1);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail, s1);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_18;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_10,v38_22_head);
      const Space v44_12 = restrict_to(v38_9,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(v38_7,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = subtract(v44_15,v44_11);
      const Space v44_17 = intersect(v44_16,v38_12);
      v39_18 = compose(v39_10,v44_17);
    }
    const Path v51_6 = concat_path(p0,v38_22_head);
    const Space v39_19 = wrap(v39_18,v51_6);
    const Space v39_20 = unite(v39_8,v39_19);
    v38_22_result = unite(v38_22_result,v39_20);
  }
  const Space v38_22 = std::move(v38_22_result);
  return v38_22;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v52_4 = unwrap(s1,constant_4);
  const Space v52_6 = unwrap(s1,constant_5);
  const Space v52_7 = unwrap(v52_6,p0);
  const Space v52_8 = restrict_to(v52_6,v52_7);
  Space v52_18_result;
  for (int v52_18_label = 1; v52_18_label <= 2; ++v52_18_label) {
    const Space v52_18_tail = child(v52_8,v52_18_label);
    if (v52_18_tail.empty()) continue;
    const Path v52_18_head{v52_18_label};
    const Space v53_2 = singleton(v52_18_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_18_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_18_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_18_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_18_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_18_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_18_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_18_result = unite(v52_18_result,v53_12);
  }
  const Space v52_18 = std::move(v52_18_result);
  const Space v52_19 = restrict_to(v52_4,v52_18);
  Space v52_29_result;
  for (int v52_29_label = 1; v52_29_label <= 2; ++v52_29_label) {
    const Space v52_29_tail = child(v52_19,v52_29_label);
    if (v52_29_tail.empty()) continue;
    const Path v52_29_head{v52_29_label};
    const Space v62_2 = singleton(v52_29_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_29_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_29_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_29_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_29_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_29_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_29_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_29_result = unite(v52_29_result,v62_12);
  }
  const Space v52_29 = std::move(v52_29_result);
  const Space v52_30 = subtract(v52_29,v52_7);
  const Space v52_32 = unwrap(s1,constant_6);
  const Space v52_33 = intersect(v52_30,v52_32);
  const Space v52_34 = wrap(v52_33,p0);
  return v52_34;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v103_5_result;
  for (int v103_5_label = 1; v103_5_label <= 2; ++v103_5_label) {
    const Space v103_5_tail = child(s0,v103_5_label);
    if (v103_5_tail.empty()) continue;
    const Path v103_5_head{v103_5_label};
    const Space v104_2 = singleton(v103_5_head);
    const Space v104_3 = intersect(constant_1,v104_2);
    const Space v104_4 = (has_head(v104_3) ? constant_2 : Space{});
    Space v104_7;
    if (!v104_4.empty()) {
      const Path v105_5 = concat_path(p0,v103_5_head);
      Space v105_6_result;
      for (int v105_6_label = 1; v105_6_label <= 2; ++v105_6_label) {
        const Space v105_6_tail = child(v103_5_tail,v105_6_label);
        if (v105_6_tail.empty()) continue;
        const Path v105_6_head{v105_6_label};
        const Space v106_2 = singleton(v105_6_head);
        const Space v106_3 = intersect(constant_1,v106_2);
        const Space v106_4 = (has_head(v106_3) ? constant_2 : Space{});
        Space v106_7;
        if (!v106_4.empty()) {
          const Path v107_5 = concat_path(v105_5,v105_6_head);
          const Space v107_6 = routine_5(c, v107_5, v105_6_tail, s1);
          v106_7 = compose(v106_4,v107_6);
        }
        v105_6_result = unite(v105_6_result,v106_7);
      }
      const Space v105_6 = std::move(v105_6_result);
      v104_7 = compose(v104_4,v105_6);
    }
    v103_5_result = unite(v103_5_result,v104_7);
  }
  const Space v103_5 = std::move(v103_5_result);
  return v103_5;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v108_5 = unwrap(s1,constant_4);
  const Space v108_7 = unwrap(s1,constant_5);
  const Space v108_8 = unwrap(v108_7,p0);
  const Space v108_10 = unwrap(s1,constant_6);
  Space v108_17_result;
  for (int v108_17_label = 1; v108_17_label <= 2; ++v108_17_label) {
    const Space v108_17_tail = child(s0,v108_17_label);
    if (v108_17_tail.empty()) continue;
    const Path v108_17_head{v108_17_label};
    const Space v109_2 = singleton(v108_17_head);
    const Space v109_3 = intersect(constant_1,v109_2);
    const Space v109_4 = (has_head(v109_3) ? constant_2 : Space{});
    Space v109_12;
    if (!v109_4.empty()) {
      const Space v110_5 = unwrap(v108_8,v108_17_head);
      const Space v110_6 = restrict_to(v108_7,v110_5);
      Space v110_7_result;
      for (int v110_7_label = 1; v110_7_label <= 2; ++v110_7_label) {
        const Space v110_7_tail = child(v110_6,v110_7_label);
        if (v110_7_tail.empty()) continue;
        const Path v110_7_head{v110_7_label};
        const Space v111_2 = singleton(v110_7_head);
        const Space v111_3 = intersect(constant_1,v111_2);
        const Space v111_4 = (has_head(v111_3) ? constant_2 : Space{});
        const Space v111_5 = subtract(constant_0,v111_4);
        Space v111_7;
        if (!v111_5.empty()) {
          const Space v112_6 = routine_6(c, v110_7_head, v110_7_tail);
          v111_7 = compose(v111_5,v112_6);
        }
        const Space v111_8 = intersect(constant_1,v111_2);
        const Space v111_9 = (has_head(v111_8) ? constant_2 : Space{});
        Space v111_11;
        if (!v111_9.empty()) {
          const Space v113_10 = routine_7(c, v110_7_head, v110_7_tail);
          v111_11 = compose(v111_9,v113_10);
        }
        const Space v111_12 = unite(v111_7,v111_11);
        v110_7_result = unite(v110_7_result,v111_12);
      }
      const Space v110_7 = std::move(v110_7_result);
      const Space v110_8 = restrict_to(v108_5,v110_7);
      Space v110_9_result;
      for (int v110_9_label = 1; v110_9_label <= 2; ++v110_9_label) {
        const Space v110_9_tail = child(v110_8,v110_9_label);
        if (v110_9_tail.empty()) continue;
        const Path v110_9_head{v110_9_label};
        const Space v114_2 = singleton(v110_9_head);
        const Space v114_3 = intersect(constant_1,v114_2);
        const Space v114_4 = (has_head(v114_3) ? constant_2 : Space{});
        const Space v114_5 = subtract(constant_0,v114_4);
        Space v114_7;
        if (!v114_5.empty()) {
          const Space v115_6 = routine_8(c, v110_9_head, v110_9_tail);
          v114_7 = compose(v114_5,v115_6);
        }
        const Space v114_8 = intersect(constant_1,v114_2);
        const Space v114_9 = (has_head(v114_8) ? constant_2 : Space{});
        Space v114_11;
        if (!v114_9.empty()) {
          const Space v116_10 = routine_9(c, v110_9_head, v110_9_tail);
          v114_11 = compose(v114_9,v116_10);
        }
        const Space v114_12 = unite(v114_7,v114_11);
        v110_9_result = unite(v110_9_result,v114_12);
      }
      const Space v110_9 = std::move(v110_9_result);
      const Space v110_10 = subtract(v110_9,v110_5);
      const Space v110_11 = intersect(v110_10,v108_10);
      v109_12 = compose(v109_4,v110_11);
    }
    const Path v109_13 = concat_path(p0,v108_17_head);
    const Space v109_14 = wrap(v109_12,v109_13);
    v108_17_result = unite(v108_17_result,v109_14);
  }
  const Space v108_17 = std::move(v108_17_result);
  return v108_17;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v117_11_result;
  for (int v117_11_label = 1; v117_11_label <= 2; ++v117_11_label) {
    const Space v117_11_tail = child(s0,v117_11_label);
    if (v117_11_tail.empty()) continue;
    const Path v117_11_head{v117_11_label};
    const Space v118_2 = singleton(v117_11_head);
    const Space v118_3 = intersect(constant_1,v118_2);
    const Space v118_4 = (has_head(v118_3) ? constant_2 : Space{});
    const Space v118_5 = subtract(constant_0,v118_4);
    Space v118_8;
    if (!v118_5.empty()) {
      const Path v119_6 = concat_path(p0,v117_11_head);
      Space v119_7_result;
      for (int v119_7_label = 1; v119_7_label <= 2; ++v119_7_label) {
        const Space v119_7_tail = child(v117_11_tail,v119_7_label);
        if (v119_7_tail.empty()) continue;
        const Path v119_7_head{v119_7_label};
        const Space v120_2 = singleton(v119_7_head);
        const Space v120_3 = intersect(constant_1,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_7_head);
          const Space v121_7 = routine_22(c, v121_6, v119_7_tail);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_1,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_2 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_7_head);
          const Space v122_11 = routine_23(c, v122_6, v119_7_tail);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_7_result = unite(v119_7_result,v120_13);
      }
      const Space v119_7 = std::move(v119_7_result);
      v118_8 = compose(v118_5,v119_7);
    }
    const Space v118_9 = intersect(constant_1,v118_2);
    const Space v118_10 = (has_head(v118_9) ? constant_2 : Space{});
    Space v118_12;
    if (!v118_10.empty()) {
      const Path v123_6 = concat_path(p0,v117_11_head);
      Space v123_11_result;
      for (int v123_11_label = 1; v123_11_label <= 2; ++v123_11_label) {
        const Space v123_11_tail = child(v117_11_tail,v123_11_label);
        if (v123_11_tail.empty()) continue;
        const Path v123_11_head{v123_11_label};
        const Space v124_2 = singleton(v123_11_head);
        const Space v124_3 = intersect(constant_1,v124_2);
        const Space v124_4 = (has_head(v124_3) ? constant_2 : Space{});
        const Space v124_5 = subtract(constant_0,v124_4);
        Space v124_8;
        if (!v124_5.empty()) {
          const Path v125_6 = concat_path(v123_6,v123_11_head);
          const Space v125_7 = routine_22(c, v125_6, v123_11_tail);
          v124_8 = compose(v124_5,v125_7);
        }
        const Space v124_9 = intersect(constant_1,v124_2);
        const Space v124_10 = (has_head(v124_9) ? constant_2 : Space{});
        Space v124_12;
        if (!v124_10.empty()) {
          const Path v126_6 = concat_path(v123_6,v123_11_head);
          const Space v126_11 = routine_14(c, v126_6, v123_11_tail);
          v124_12 = compose(v124_10,v126_11);
        }
        const Space v124_13 = unite(v124_8,v124_12);
        v123_11_result = unite(v123_11_result,v124_13);
      }
      const Space v123_11 = std::move(v123_11_result);
      v118_12 = compose(v118_10,v123_11);
    }
    const Space v118_13 = unite(v118_8,v118_12);
    v117_11_result = unite(v117_11_result,v118_13);
  }
  const Space v117_11 = std::move(v117_11_result);
  return v117_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v127_8_result;
  for (int v127_8_label = 1; v127_8_label <= 2; ++v127_8_label) {
    const Space v127_8_tail = child(s0,v127_8_label);
    if (v127_8_tail.empty()) continue;
    const Path v127_8_head{v127_8_label};
    const Space v128_2 = singleton(v127_8_head);
    const Space v128_3 = intersect(constant_1,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_2 : Space{});
    const Space v128_5 = subtract(constant_0,v128_4);
    Space v128_8;
    if (!v128_5.empty()) {
      const Path v129_6 = concat_path(p0,v127_8_head);
      Space v129_7_result;
      for (int v129_7_label = 1; v129_7_label <= 2; ++v129_7_label) {
        const Space v129_7_tail = child(v127_8_tail,v129_7_label);
        if (v129_7_tail.empty()) continue;
        const Path v129_7_head{v129_7_label};
        const Space v130_2 = singleton(v129_7_head);
        const Space v130_3 = intersect(constant_1,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_2 : Space{});
        const Space v130_5 = subtract(constant_0,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v129_6,v129_7_head);
          const Space v131_7 = routine_22(c, v131_6, v129_7_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_1,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_2 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v129_6,v129_7_head);
          const Space v132_11 = routine_23(c, v132_6, v129_7_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_7_result = unite(v129_7_result,v130_13);
      }
      const Space v129_7 = std::move(v129_7_result);
      v128_8 = compose(v128_5,v129_7);
    }
    const Space v128_9 = intersect(constant_1,v128_2);
    const Space v128_10 = (has_head(v128_9) ? constant_2 : Space{});
    const Space v128_11 = compose(v128_10,v127_8_tail);
    const Space v128_12 = unite(v128_8,v128_11);
    v127_8_result = unite(v127_8_result,v128_12);
  }
  const Space v127_8 = std::move(v127_8_result);
  return v127_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v134_11_result;
  for (int v134_11_label = 1; v134_11_label <= 2; ++v134_11_label) {
    const Space v134_11_tail = child(s0,v134_11_label);
    if (v134_11_tail.empty()) continue;
    const Path v134_11_head{v134_11_label};
    const Space v135_2 = singleton(v134_11_head);
    const Space v135_3 = intersect(constant_1,v135_2);
    const Space v135_4 = (has_head(v135_3) ? constant_2 : Space{});
    const Space v135_5 = subtract(constant_0,v135_4);
    Space v135_8;
    if (!v135_5.empty()) {
      const Path v136_6 = concat_path(p0,v134_11_head);
      Space v136_7_result;
      for (int v136_7_label = 1; v136_7_label <= 2; ++v136_7_label) {
        const Space v136_7_tail = child(v134_11_tail,v136_7_label);
        if (v136_7_tail.empty()) continue;
        const Path v136_7_head{v136_7_label};
        const Space v137_2 = singleton(v136_7_head);
        const Space v137_3 = intersect(constant_1,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_2 : Space{});
        const Space v137_5 = subtract(constant_0,v137_4);
        Space v137_8;
        if (!v137_5.empty()) {
          const Path v138_6 = concat_path(v136_6,v136_7_head);
          const Space v138_7 = routine_24(c, v138_6, v136_7_tail);
          v137_8 = compose(v137_5,v138_7);
        }
        const Space v137_9 = intersect(constant_1,v137_2);
        const Space v137_10 = (has_head(v137_9) ? constant_2 : Space{});
        Space v137_12;
        if (!v137_10.empty()) {
          const Path v139_6 = concat_path(v136_6,v136_7_head);
          const Space v139_11 = routine_25(c, v139_6, v136_7_tail);
          v137_12 = compose(v137_10,v139_11);
        }
        const Space v137_13 = unite(v137_8,v137_12);
        v136_7_result = unite(v136_7_result,v137_13);
      }
      const Space v136_7 = std::move(v136_7_result);
      v135_8 = compose(v135_5,v136_7);
    }
    const Space v135_9 = intersect(constant_1,v135_2);
    const Space v135_10 = (has_head(v135_9) ? constant_2 : Space{});
    Space v135_12;
    if (!v135_10.empty()) {
      const Path v140_6 = concat_path(p0,v134_11_head);
      Space v140_11_result;
      for (int v140_11_label = 1; v140_11_label <= 2; ++v140_11_label) {
        const Space v140_11_tail = child(v134_11_tail,v140_11_label);
        if (v140_11_tail.empty()) continue;
        const Path v140_11_head{v140_11_label};
        const Space v141_2 = singleton(v140_11_head);
        const Space v141_3 = intersect(constant_1,v141_2);
        const Space v141_4 = (has_head(v141_3) ? constant_2 : Space{});
        const Space v141_5 = subtract(constant_0,v141_4);
        Space v141_8;
        if (!v141_5.empty()) {
          const Path v142_6 = concat_path(v140_6,v140_11_head);
          const Space v142_7 = routine_24(c, v142_6, v140_11_tail);
          v141_8 = compose(v141_5,v142_7);
        }
        const Space v141_9 = intersect(constant_1,v141_2);
        const Space v141_10 = (has_head(v141_9) ? constant_2 : Space{});
        Space v141_12;
        if (!v141_10.empty()) {
          const Path v143_6 = concat_path(v140_6,v140_11_head);
          const Space v143_11 = routine_17(c, v143_6, v140_11_tail);
          v141_12 = compose(v141_10,v143_11);
        }
        const Space v141_13 = unite(v141_8,v141_12);
        v140_11_result = unite(v140_11_result,v141_13);
      }
      const Space v140_11 = std::move(v140_11_result);
      v135_12 = compose(v135_10,v140_11);
    }
    const Space v135_13 = unite(v135_8,v135_12);
    v134_11_result = unite(v134_11_result,v135_13);
  }
  const Space v134_11 = std::move(v134_11_result);
  return v134_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v144_8_result;
  for (int v144_8_label = 1; v144_8_label <= 2; ++v144_8_label) {
    const Space v144_8_tail = child(s0,v144_8_label);
    if (v144_8_tail.empty()) continue;
    const Path v144_8_head{v144_8_label};
    const Space v145_2 = singleton(v144_8_head);
    const Space v145_3 = intersect(constant_1,v145_2);
    const Space v145_4 = (has_head(v145_3) ? constant_2 : Space{});
    const Space v145_5 = subtract(constant_0,v145_4);
    Space v145_8;
    if (!v145_5.empty()) {
      const Path v146_6 = concat_path(p0,v144_8_head);
      Space v146_7_result;
      for (int v146_7_label = 1; v146_7_label <= 2; ++v146_7_label) {
        const Space v146_7_tail = child(v144_8_tail,v146_7_label);
        if (v146_7_tail.empty()) continue;
        const Path v146_7_head{v146_7_label};
        const Space v147_2 = singleton(v146_7_head);
        const Space v147_3 = intersect(constant_1,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_2 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v146_6,v146_7_head);
          const Space v148_7 = routine_24(c, v148_6, v146_7_tail);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_1,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_2 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v146_6,v146_7_head);
          const Space v149_11 = routine_25(c, v149_6, v146_7_tail);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_7_result = unite(v146_7_result,v147_13);
      }
      const Space v146_7 = std::move(v146_7_result);
      v145_8 = compose(v145_5,v146_7);
    }
    const Space v145_9 = intersect(constant_1,v145_2);
    const Space v145_10 = (has_head(v145_9) ? constant_2 : Space{});
    const Space v145_11 = compose(v145_10,v144_8_tail);
    const Space v145_12 = unite(v145_8,v145_11);
    v144_8_result = unite(v144_8_result,v145_12);
  }
  const Space v144_8 = std::move(v144_8_result);
  return v144_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v151_11_result;
  for (int v151_11_label = 1; v151_11_label <= 2; ++v151_11_label) {
    const Space v151_11_tail = child(s0,v151_11_label);
    if (v151_11_tail.empty()) continue;
    const Path v151_11_head{v151_11_label};
    const Space v152_2 = singleton(v151_11_head);
    const Space v152_3 = intersect(constant_1,v152_2);
    const Space v152_4 = (has_head(v152_3) ? constant_2 : Space{});
    const Space v152_5 = subtract(constant_0,v152_4);
    Space v152_8;
    if (!v152_5.empty()) {
      const Path v153_6 = concat_path(p0,v151_11_head);
      Space v153_7_result;
      for (int v153_7_label = 1; v153_7_label <= 2; ++v153_7_label) {
        const Space v153_7_tail = child(v151_11_tail,v153_7_label);
        if (v153_7_tail.empty()) continue;
        const Path v153_7_head{v153_7_label};
        const Space v154_2 = singleton(v153_7_head);
        const Space v154_3 = intersect(constant_1,v154_2);
        const Space v154_4 = (has_head(v154_3) ? constant_2 : Space{});
        const Space v154_5 = subtract(constant_0,v154_4);
        Space v154_8;
        if (!v154_5.empty()) {
          const Path v155_6 = concat_path(v153_6,v153_7_head);
          const Space v155_7 = routine_26(c, v155_6, v153_7_tail);
          v154_8 = compose(v154_5,v155_7);
        }
        const Space v154_9 = intersect(constant_1,v154_2);
        const Space v154_10 = (has_head(v154_9) ? constant_2 : Space{});
        Space v154_12;
        if (!v154_10.empty()) {
          const Path v156_6 = concat_path(v153_6,v153_7_head);
          const Space v156_11 = routine_27(c, v156_6, v153_7_tail);
          v154_12 = compose(v154_10,v156_11);
        }
        const Space v154_13 = unite(v154_8,v154_12);
        v153_7_result = unite(v153_7_result,v154_13);
      }
      const Space v153_7 = std::move(v153_7_result);
      v152_8 = compose(v152_5,v153_7);
    }
    const Space v152_9 = intersect(constant_1,v152_2);
    const Space v152_10 = (has_head(v152_9) ? constant_2 : Space{});
    Space v152_12;
    if (!v152_10.empty()) {
      const Path v157_6 = concat_path(p0,v151_11_head);
      Space v157_11_result;
      for (int v157_11_label = 1; v157_11_label <= 2; ++v157_11_label) {
        const Space v157_11_tail = child(v151_11_tail,v157_11_label);
        if (v157_11_tail.empty()) continue;
        const Path v157_11_head{v157_11_label};
        const Space v158_2 = singleton(v157_11_head);
        const Space v158_3 = intersect(constant_1,v158_2);
        const Space v158_4 = (has_head(v158_3) ? constant_2 : Space{});
        const Space v158_5 = subtract(constant_0,v158_4);
        Space v158_8;
        if (!v158_5.empty()) {
          const Path v159_6 = concat_path(v157_6,v157_11_head);
          const Space v159_7 = routine_26(c, v159_6, v157_11_tail);
          v158_8 = compose(v158_5,v159_7);
        }
        const Space v158_9 = intersect(constant_1,v158_2);
        const Space v158_10 = (has_head(v158_9) ? constant_2 : Space{});
        Space v158_12;
        if (!v158_10.empty()) {
          const Path v160_6 = concat_path(v157_6,v157_11_head);
          const Space v160_11 = routine_14(c, v160_6, v157_11_tail);
          v158_12 = compose(v158_10,v160_11);
        }
        const Space v158_13 = unite(v158_8,v158_12);
        v157_11_result = unite(v157_11_result,v158_13);
      }
      const Space v157_11 = std::move(v157_11_result);
      v152_12 = compose(v152_10,v157_11);
    }
    const Space v152_13 = unite(v152_8,v152_12);
    v151_11_result = unite(v151_11_result,v152_13);
  }
  const Space v151_11 = std::move(v151_11_result);
  return v151_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v161_8_result;
  for (int v161_8_label = 1; v161_8_label <= 2; ++v161_8_label) {
    const Space v161_8_tail = child(s0,v161_8_label);
    if (v161_8_tail.empty()) continue;
    const Path v161_8_head{v161_8_label};
    const Space v162_2 = singleton(v161_8_head);
    const Space v162_3 = intersect(constant_1,v162_2);
    const Space v162_4 = (has_head(v162_3) ? constant_2 : Space{});
    const Space v162_5 = subtract(constant_0,v162_4);
    Space v162_8;
    if (!v162_5.empty()) {
      const Path v163_6 = concat_path(p0,v161_8_head);
      Space v163_7_result;
      for (int v163_7_label = 1; v163_7_label <= 2; ++v163_7_label) {
        const Space v163_7_tail = child(v161_8_tail,v163_7_label);
        if (v163_7_tail.empty()) continue;
        const Path v163_7_head{v163_7_label};
        const Space v164_2 = singleton(v163_7_head);
        const Space v164_3 = intersect(constant_1,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
        const Space v164_5 = subtract(constant_0,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v163_6,v163_7_head);
          const Space v165_7 = routine_26(c, v165_6, v163_7_tail);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_1,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v163_6,v163_7_head);
          const Space v166_11 = routine_27(c, v166_6, v163_7_tail);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_7_result = unite(v163_7_result,v164_13);
      }
      const Space v163_7 = std::move(v163_7_result);
      v162_8 = compose(v162_5,v163_7);
    }
    const Space v162_9 = intersect(constant_1,v162_2);
    const Space v162_10 = (has_head(v162_9) ? constant_2 : Space{});
    const Space v162_11 = compose(v162_10,v161_8_tail);
    const Space v162_12 = unite(v162_8,v162_11);
    v161_8_result = unite(v161_8_result,v162_12);
  }
  const Space v161_8 = std::move(v161_8_result);
  return v161_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v167_11_result;
  for (int v167_11_label = 1; v167_11_label <= 2; ++v167_11_label) {
    const Space v167_11_tail = child(s0,v167_11_label);
    if (v167_11_tail.empty()) continue;
    const Path v167_11_head{v167_11_label};
    const Space v168_2 = singleton(v167_11_head);
    const Space v168_3 = intersect(constant_1,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_2 : Space{});
    const Space v168_5 = subtract(constant_0,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_11_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_11_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_1,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_2 : Space{});
        const Space v170_5 = subtract(constant_0,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_28(c, v171_6, v169_7_tail);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_1,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_2 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_29(c, v172_6, v169_7_tail);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_1,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_2 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_11_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_11_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_1,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_2 : Space{});
        const Space v174_5 = subtract(constant_0,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_28(c, v175_6, v173_11_tail);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_1,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_2 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_17(c, v176_6, v173_11_tail);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_11_result = unite(v167_11_result,v168_13);
  }
  const Space v167_11 = std::move(v167_11_result);
  return v167_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v177_8_result;
  for (int v177_8_label = 1; v177_8_label <= 2; ++v177_8_label) {
    const Space v177_8_tail = child(s0,v177_8_label);
    if (v177_8_tail.empty()) continue;
    const Path v177_8_head{v177_8_label};
    const Space v178_2 = singleton(v177_8_head);
    const Space v178_3 = intersect(constant_1,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_2 : Space{});
    const Space v178_5 = subtract(constant_0,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_8_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_8_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_1,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
        const Space v180_5 = subtract(constant_0,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_28(c, v181_6, v179_7_tail);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_1,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_2 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_29(c, v182_6, v179_7_tail);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_1,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_2 : Space{});
    const Space v178_11 = compose(v178_10,v177_8_tail);
    const Space v178_12 = unite(v178_8,v178_11);
    v177_8_result = unite(v177_8_result,v178_12);
  }
  const Space v177_8 = std::move(v177_8_result);
  return v177_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  Space v183_11_result;
  for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
    const Space v183_11_tail = child(s0,v183_11_label);
    if (v183_11_tail.empty()) continue;
    const Path v183_11_head{v183_11_label};
    const Space v184_2 = singleton(v183_11_head);
    const Space v184_3 = intersect(constant_1,v184_2);
    const Space v184_4 = (has_head(v184_3) ? constant_2 : Space{});
    const Space v184_5 = subtract(constant_0,v184_4);
    Space v184_8;
    if (!v184_5.empty()) {
      const Path v185_6 = concat_path(p0,v183_11_head);
      Space v185_7_result;
      for (int v185_7_label = 1; v185_7_label <= 2; ++v185_7_label) {
        const Space v185_7_tail = child(v183_11_tail,v185_7_label);
        if (v185_7_tail.empty()) continue;
        const Path v185_7_head{v185_7_label};
        const Space v186_2 = singleton(v185_7_head);
        const Space v186_3 = intersect(constant_1,v186_2);
        const Space v186_4 = (has_head(v186_3) ? constant_2 : Space{});
        const Space v186_5 = subtract(constant_0,v186_4);
        Space v186_8;
        if (!v186_5.empty()) {
          const Path v187_6 = concat_path(v185_6,v185_7_head);
          const Space v187_7 = routine_30(c, v187_6, v185_7_tail);
          v186_8 = compose(v186_5,v187_7);
        }
        const Space v186_9 = intersect(constant_1,v186_2);
        const Space v186_10 = (has_head(v186_9) ? constant_2 : Space{});
        Space v186_12;
        if (!v186_10.empty()) {
          const Path v188_6 = concat_path(v185_6,v185_7_head);
          const Space v188_11 = routine_31(c, v188_6, v185_7_tail);
          v186_12 = compose(v186_10,v188_11);
        }
        const Space v186_13 = unite(v186_8,v186_12);
        v185_7_result = unite(v185_7_result,v186_13);
      }
      const Space v185_7 = std::move(v185_7_result);
      v184_8 = compose(v184_5,v185_7);
    }
    const Space v184_9 = intersect(constant_1,v184_2);
    const Space v184_10 = (has_head(v184_9) ? constant_2 : Space{});
    Space v184_12;
    if (!v184_10.empty()) {
      const Path v189_6 = concat_path(p0,v183_11_head);
      Space v189_11_result;
      for (int v189_11_label = 1; v189_11_label <= 2; ++v189_11_label) {
        const Space v189_11_tail = child(v183_11_tail,v189_11_label);
        if (v189_11_tail.empty()) continue;
        const Path v189_11_head{v189_11_label};
        const Space v190_2 = singleton(v189_11_head);
        const Space v190_3 = intersect(constant_1,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_2 : Space{});
        const Space v190_5 = subtract(constant_0,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_11_head);
          const Space v191_7 = routine_30(c, v191_6, v189_11_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_1,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_2 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_11_head);
          const Space v192_11 = routine_14(c, v192_6, v189_11_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_11_result = unite(v189_11_result,v190_13);
      }
      const Space v189_11 = std::move(v189_11_result);
      v184_12 = compose(v184_10,v189_11);
    }
    const Space v184_13 = unite(v184_8,v184_12);
    v183_11_result = unite(v183_11_result,v184_13);
  }
  const Space v183_11 = std::move(v183_11_result);
  return v183_11;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  Space v193_8_result;
  for (int v193_8_label = 1; v193_8_label <= 2; ++v193_8_label) {
    const Space v193_8_tail = child(s0,v193_8_label);
    if (v193_8_tail.empty()) continue;
    const Path v193_8_head{v193_8_label};
    const Space v194_2 = singleton(v193_8_head);
    const Space v194_3 = intersect(constant_1,v194_2);
    const Space v194_4 = (has_head(v194_3) ? constant_2 : Space{});
    const Space v194_5 = subtract(constant_0,v194_4);
    Space v194_8;
    if (!v194_5.empty()) {
      const Path v195_6 = concat_path(p0,v193_8_head);
      Space v195_7_result;
      for (int v195_7_label = 1; v195_7_label <= 2; ++v195_7_label) {
        const Space v195_7_tail = child(v193_8_tail,v195_7_label);
        if (v195_7_tail.empty()) continue;
        const Path v195_7_head{v195_7_label};
        const Space v196_2 = singleton(v195_7_head);
        const Space v196_3 = intersect(constant_1,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_2 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v195_6,v195_7_head);
          const Space v197_7 = routine_30(c, v197_6, v195_7_tail);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_1,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_2 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v195_6,v195_7_head);
          const Space v198_11 = routine_31(c, v198_6, v195_7_tail);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_7_result = unite(v195_7_result,v196_13);
      }
      const Space v195_7 = std::move(v195_7_result);
      v194_8 = compose(v194_5,v195_7);
    }
    const Space v194_9 = intersect(constant_1,v194_2);
    const Space v194_10 = (has_head(v194_9) ? constant_2 : Space{});
    const Space v194_11 = compose(v194_10,v193_8_tail);
    const Space v194_12 = unite(v194_8,v194_11);
    v193_8_result = unite(v193_8_result,v194_12);
  }
  const Space v193_8 = std::move(v193_8_result);
  return v193_8;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v199_11_result;
  for (int v199_11_label = 1; v199_11_label <= 2; ++v199_11_label) {
    const Space v199_11_tail = child(s0,v199_11_label);
    if (v199_11_tail.empty()) continue;
    const Path v199_11_head{v199_11_label};
    const Space v200_2 = singleton(v199_11_head);
    const Space v200_3 = intersect(constant_1,v200_2);
    const Space v200_4 = (has_head(v200_3) ? constant_2 : Space{});
    const Space v200_5 = subtract(constant_0,v200_4);
    Space v200_8;
    if (!v200_5.empty()) {
      const Path v201_6 = concat_path(p0,v199_11_head);
      Space v201_7_result;
      for (int v201_7_label = 1; v201_7_label <= 2; ++v201_7_label) {
        const Space v201_7_tail = child(v199_11_tail,v201_7_label);
        if (v201_7_tail.empty()) continue;
        const Path v201_7_head{v201_7_label};
        const Space v202_2 = singleton(v201_7_head);
        const Space v202_3 = intersect(constant_1,v202_2);
        const Space v202_4 = (has_head(v202_3) ? constant_2 : Space{});
        const Space v202_5 = subtract(constant_0,v202_4);
        Space v202_8;
        if (!v202_5.empty()) {
          const Path v203_6 = concat_path(v201_6,v201_7_head);
          const Space v203_7 = routine_32(c, v203_6, v201_7_tail);
          v202_8 = compose(v202_5,v203_7);
        }
        const Space v202_9 = intersect(constant_1,v202_2);
        const Space v202_10 = (has_head(v202_9) ? constant_2 : Space{});
        Space v202_12;
        if (!v202_10.empty()) {
          const Path v204_6 = concat_path(v201_6,v201_7_head);
          const Space v204_11 = routine_33(c, v204_6, v201_7_tail);
          v202_12 = compose(v202_10,v204_11);
        }
        const Space v202_13 = unite(v202_8,v202_12);
        v201_7_result = unite(v201_7_result,v202_13);
      }
      const Space v201_7 = std::move(v201_7_result);
      v200_8 = compose(v200_5,v201_7);
    }
    const Space v200_9 = intersect(constant_1,v200_2);
    const Space v200_10 = (has_head(v200_9) ? constant_2 : Space{});
    Space v200_12;
    if (!v200_10.empty()) {
      const Path v205_6 = concat_path(p0,v199_11_head);
      Space v205_11_result;
      for (int v205_11_label = 1; v205_11_label <= 2; ++v205_11_label) {
        const Space v205_11_tail = child(v199_11_tail,v205_11_label);
        if (v205_11_tail.empty()) continue;
        const Path v205_11_head{v205_11_label};
        const Space v206_2 = singleton(v205_11_head);
        const Space v206_3 = intersect(constant_1,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_2 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_11_head);
          const Space v207_7 = routine_32(c, v207_6, v205_11_tail);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_1,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_2 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_11_head);
          const Space v208_11 = routine_17(c, v208_6, v205_11_tail);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_11_result = unite(v205_11_result,v206_13);
      }
      const Space v205_11 = std::move(v205_11_result);
      v200_12 = compose(v200_10,v205_11);
    }
    const Space v200_13 = unite(v200_8,v200_12);
    v199_11_result = unite(v199_11_result,v200_13);
  }
  const Space v199_11 = std::move(v199_11_result);
  return v199_11;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v209_8_result;
  for (int v209_8_label = 1; v209_8_label <= 2; ++v209_8_label) {
    const Space v209_8_tail = child(s0,v209_8_label);
    if (v209_8_tail.empty()) continue;
    const Path v209_8_head{v209_8_label};
    const Space v210_2 = singleton(v209_8_head);
    const Space v210_3 = intersect(constant_1,v210_2);
    const Space v210_4 = (has_head(v210_3) ? constant_2 : Space{});
    const Space v210_5 = subtract(constant_0,v210_4);
    Space v210_8;
    if (!v210_5.empty()) {
      const Path v211_6 = concat_path(p0,v209_8_head);
      Space v211_7_result;
      for (int v211_7_label = 1; v211_7_label <= 2; ++v211_7_label) {
        const Space v211_7_tail = child(v209_8_tail,v211_7_label);
        if (v211_7_tail.empty()) continue;
        const Path v211_7_head{v211_7_label};
        const Space v212_2 = singleton(v211_7_head);
        const Space v212_3 = intersect(constant_1,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_2 : Space{});
        const Space v212_5 = subtract(constant_0,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_7_head);
          const Space v213_7 = routine_32(c, v213_6, v211_7_tail);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_1,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_2 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_7_head);
          const Space v214_11 = routine_33(c, v214_6, v211_7_tail);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_7_result = unite(v211_7_result,v212_13);
      }
      const Space v211_7 = std::move(v211_7_result);
      v210_8 = compose(v210_5,v211_7);
    }
    const Space v210_9 = intersect(constant_1,v210_2);
    const Space v210_10 = (has_head(v210_9) ? constant_2 : Space{});
    const Space v210_11 = compose(v210_10,v209_8_tail);
    const Space v210_12 = unite(v210_8,v210_11);
    v209_8_result = unite(v209_8_result,v210_12);
  }
  const Space v209_8 = std::move(v209_8_result);
  return v209_8;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v215_4_result;
  for (int v215_4_label = 1; v215_4_label <= 2; ++v215_4_label) {
    const Space v215_4_tail = child(s0,v215_4_label);
    if (v215_4_tail.empty()) continue;
    const Path v215_4_head{v215_4_label};
    const Space v216_2 = singleton(v215_4_head);
    const Space v216_3 = intersect(constant_1,v216_2);
    const Space v216_4 = (has_head(v216_3) ? constant_2 : Space{});
    Space v216_7;
    if (!v216_4.empty()) {
      const Path v217_5 = concat_path(p0,v215_4_head);
      Space v217_6_result;
      for (int v217_6_label = 1; v217_6_label <= 2; ++v217_6_label) {
        const Space v217_6_tail = child(v215_4_tail,v217_6_label);
        if (v217_6_tail.empty()) continue;
        const Path v217_6_head{v217_6_label};
        const Space v218_2 = singleton(v217_6_head);
        const Space v218_3 = intersect(constant_1,v218_2);
        const Space v218_4 = (has_head(v218_3) ? constant_2 : Space{});
        Space v218_7;
        if (!v218_4.empty()) {
          const Path v219_5 = concat_path(v217_5,v217_6_head);
          const Space v219_6 = routine_14(c, v219_5, v217_6_tail);
          v218_7 = compose(v218_4,v219_6);
        }
        v217_6_result = unite(v217_6_result,v218_7);
      }
      const Space v217_6 = std::move(v217_6_result);
      v216_7 = compose(v216_4,v217_6);
    }
    v215_4_result = unite(v215_4_result,v216_7);
  }
  const Space v215_4 = std::move(v215_4_result);
  return v215_4;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v220_3_result;
  for (int v220_3_label = 1; v220_3_label <= 2; ++v220_3_label) {
    const Space v220_3_tail = child(s0,v220_3_label);
    if (v220_3_tail.empty()) continue;
    const Path v220_3_head{v220_3_label};
    const Space v221_2 = singleton(v220_3_head);
    const Space v221_3 = intersect(constant_1,v221_2);
    const Space v221_4 = (has_head(v221_3) ? constant_2 : Space{});
    const Space v221_5 = compose(v221_4,v220_3_tail);
    v220_3_result = unite(v220_3_result,v221_5);
  }
  const Space v220_3 = std::move(v220_3_result);
  return v220_3;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v222_4_result;
  for (int v222_4_label = 1; v222_4_label <= 2; ++v222_4_label) {
    const Space v222_4_tail = child(s0,v222_4_label);
    if (v222_4_tail.empty()) continue;
    const Path v222_4_head{v222_4_label};
    const Space v223_2 = singleton(v222_4_head);
    const Space v223_3 = intersect(constant_1,v223_2);
    const Space v223_4 = (has_head(v223_3) ? constant_2 : Space{});
    Space v223_7;
    if (!v223_4.empty()) {
      const Path v224_5 = concat_path(p0,v222_4_head);
      Space v224_6_result;
      for (int v224_6_label = 1; v224_6_label <= 2; ++v224_6_label) {
        const Space v224_6_tail = child(v222_4_tail,v224_6_label);
        if (v224_6_tail.empty()) continue;
        const Path v224_6_head{v224_6_label};
        const Space v225_2 = singleton(v224_6_head);
        const Space v225_3 = intersect(constant_1,v225_2);
        const Space v225_4 = (has_head(v225_3) ? constant_2 : Space{});
        Space v225_7;
        if (!v225_4.empty()) {
          const Path v226_5 = concat_path(v224_5,v224_6_head);
          const Space v226_6 = routine_17(c, v226_5, v224_6_tail);
          v225_7 = compose(v225_4,v226_6);
        }
        v224_6_result = unite(v224_6_result,v225_7);
      }
      const Space v224_6 = std::move(v224_6_result);
      v223_7 = compose(v223_4,v224_6);
    }
    v222_4_result = unite(v222_4_result,v223_7);
  }
  const Space v222_4 = std::move(v222_4_result);
  return v222_4;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v227_3_result;
  for (int v227_3_label = 1; v227_3_label <= 2; ++v227_3_label) {
    const Space v227_3_tail = child(s0,v227_3_label);
    if (v227_3_tail.empty()) continue;
    const Path v227_3_head{v227_3_label};
    const Space v228_2 = singleton(v227_3_head);
    const Space v228_3 = intersect(constant_1,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_2 : Space{});
    const Space v228_5 = compose(v228_4,v227_3_tail);
    v227_3_result = unite(v227_3_result,v228_5);
  }
  const Space v227_3 = std::move(v227_3_result);
  return v227_3;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  const Space v229_2 = Space{};
  return v229_2;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v230_3_result;
  for (int v230_3_label = 1; v230_3_label <= 2; ++v230_3_label) {
    const Space v230_3_tail = child(s0,v230_3_label);
    if (v230_3_tail.empty()) continue;
    const Path v230_3_head{v230_3_label};
    const Space v231_2 = singleton(v230_3_head);
    const Space v231_3 = intersect(constant_1,v231_2);
    const Space v231_4 = (has_head(v231_3) ? constant_2 : Space{});
    const Space v231_5 = compose(v231_4,v230_3_tail);
    v230_3_result = unite(v230_3_result,v231_5);
  }
  const Space v230_3 = std::move(v230_3_result);
  return v230_3;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  const Space v232_2 = Space{};
  return v232_2;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0) {
  Space v233_3_result;
  for (int v233_3_label = 1; v233_3_label <= 2; ++v233_3_label) {
    const Space v233_3_tail = child(s0,v233_3_label);
    if (v233_3_tail.empty()) continue;
    const Path v233_3_head{v233_3_label};
    const Space v234_2 = singleton(v233_3_head);
    const Space v234_3 = intersect(constant_1,v234_2);
    const Space v234_4 = (has_head(v234_3) ? constant_2 : Space{});
    const Space v234_5 = compose(v234_4,v233_3_tail);
    v233_3_result = unite(v233_3_result,v234_5);
  }
  const Space v233_3 = std::move(v233_3_result);
  return v233_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
