#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("2 8 1 2 2 2 1 1 2 2 6 2 2 2 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("1 6 2 2 1 1 2 2");
static const Path constant_5 = Path{1,2};
static const Space constant_6 = literal_text("2 5 2 1 1 2 2 3 2 2 2");
static const Path constant_7 = Path{2,2};
static const Space constant_8 = literal_text("1 3 1 2 2");
static const Space constant_9 = literal_text("1 1 2");
static const Space constant_10 = singleton(Path{});
static const Space constant_11 = literal_text("6 10 1 1 1 2 2 2 1 1 2 2 8 1 1 2 2 2 1 2 2 7 1 2 2 1 1 2 2 5 1 2 2 2 2 8 2 1 2 2 1 1 2 2 5 2 2 1 2 2");
static const Path constant_12 = Path{};
static Space routine_0(Context& c);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Space& s0);
static Space routine_10(Context& c, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_39(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_0(Context& c) {
  Space v0_18;
  if (!constant_0.empty()) {
    Space v1_17;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_6);
      const Space v2_12 = unite(v2_8,v2_11);
      const Space v2_15 = routine_3(c, constant_7, constant_8);
      const Space v2_16 = unite(v2_12,v2_15);
      v1_17 = compose(constant_0,v2_16);
    }
    v0_18 = compose(constant_0,v1_17);
  }
  Space v0_33;
  if (!constant_0.empty()) {
    Space v3_32;
    if (!constant_0.empty()) {
      const Space v4_22 = routine_4(c, constant_1, constant_2);
      const Space v4_24 = routine_4(c, constant_3, constant_4);
      const Space v4_25 = unite(v4_22,v4_24);
      const Space v4_27 = routine_5(c, constant_5, constant_6);
      const Space v4_28 = unite(v4_25,v4_27);
      const Space v4_30 = routine_6(c, constant_7, constant_8);
      const Space v4_31 = unite(v4_28,v4_30);
      v3_32 = compose(constant_0,v4_31);
    }
    v0_33 = compose(constant_0,v3_32);
  }
  Space v0_43_result;
  for (int v0_43_label = 1; v0_43_label <= 2; ++v0_43_label) {
    const Space v0_43_tail = child(v0_33,v0_43_label);
    if (v0_43_tail.empty()) continue;
    const Path v0_43_head{v0_43_label};
    const Space v5_2 = singleton(v0_43_head);
    const Space v5_3 = intersect(constant_9,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_10 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_7;
    if (!v5_5.empty()) {
      Space v6_6_result;
      for (int v6_6_label = 1; v6_6_label <= 2; ++v6_6_label) {
        const Space v6_6_tail = child(v0_43_tail,v6_6_label);
        if (v6_6_tail.empty()) continue;
        const Path v6_6_head{v6_6_label};
        const Space v7_2 = singleton(v6_6_head);
        const Space v7_3 = intersect(constant_9,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_10 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_43_head,v6_6_head);
          const Space v8_7 = routine_7(c, v8_6, v6_6_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_9,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_10 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_43_head,v6_6_head);
          const Space v9_11 = routine_8(c, v9_6, v6_6_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_6_result = unite(v6_6_result,v7_13);
      }
      const Space v6_6 = std::move(v6_6_result);
      v5_7 = compose(v5_5,v6_6);
    }
    const Space v5_8 = intersect(constant_9,v5_2);
    const Space v5_9 = (has_head(v5_8) ? constant_10 : Space{});
    Space v5_11;
    if (!v5_9.empty()) {
      Space v10_10_result;
      for (int v10_10_label = 1; v10_10_label <= 2; ++v10_10_label) {
        const Space v10_10_tail = child(v0_43_tail,v10_10_label);
        if (v10_10_tail.empty()) continue;
        const Path v10_10_head{v10_10_label};
        const Space v11_2 = singleton(v10_10_head);
        const Space v11_3 = intersect(constant_9,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_10 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v0_43_head,v10_10_head);
          const Space v12_7 = routine_7(c, v12_6, v10_10_tail);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_9,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_10 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v0_43_head,v10_10_head);
          const Space v13_11 = routine_9(c, v13_6, v10_10_tail);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_10_result = unite(v10_10_result,v11_13);
      }
      const Space v10_10 = std::move(v10_10_result);
      v5_11 = compose(v5_9,v10_10);
    }
    const Space v5_12 = unite(v5_7,v5_11);
    v0_43_result = unite(v0_43_result,v5_12);
  }
  const Space v0_43 = std::move(v0_43_result);
  const Space v0_44 = unite(v0_18,v0_43);
  const Space v0_45 = routine_10(c, v0_44);
  Space v0_105_result;
  for (int v0_105_label = 1; v0_105_label <= 2; ++v0_105_label) {
    const Space v0_105_tail = child(v0_45,v0_105_label);
    if (v0_105_tail.empty()) continue;
    const Path v0_105_head{v0_105_label};
    const Space v14_2 = singleton(v0_105_head);
    const Space v14_3 = intersect(constant_9,v14_2);
    const Space v14_4 = (has_head(v14_3) ? constant_10 : Space{});
    const Space v14_5 = subtract(constant_0,v14_4);
    Space v14_36;
    if (!v14_5.empty()) {
      Space v15_14;
      if (!constant_0.empty()) {
        Space v16_13;
        if (!constant_0.empty()) {
          const Space v17_6 = routine_11(c, constant_1, constant_2);
          const Space v17_7 = routine_11(c, constant_3, constant_4);
          const Space v17_8 = unite(v17_6,v17_7);
          const Space v17_9 = routine_12(c, constant_5, constant_6);
          const Space v17_10 = unite(v17_8,v17_9);
          const Space v17_11 = routine_13(c, constant_7, constant_8);
          const Space v17_12 = unite(v17_10,v17_11);
          v16_13 = compose(constant_0,v17_12);
        }
        v15_14 = compose(constant_0,v16_13);
      }
      Space v15_23;
      if (!constant_0.empty()) {
        Space v18_22;
        if (!constant_0.empty()) {
          const Space v19_15 = routine_1(c, constant_1, constant_2);
          const Space v19_16 = routine_1(c, constant_3, constant_4);
          const Space v19_17 = unite(v19_15,v19_16);
          const Space v19_18 = routine_2(c, constant_5, constant_6);
          const Space v19_19 = unite(v19_17,v19_18);
          const Space v19_20 = routine_3(c, constant_7, constant_8);
          const Space v19_21 = unite(v19_19,v19_20);
          v18_22 = compose(constant_0,v19_21);
        }
        v15_23 = compose(constant_0,v18_22);
      }
      Space v15_32;
      if (!constant_0.empty()) {
        Space v20_31;
        if (!constant_0.empty()) {
          const Space v21_24 = routine_4(c, constant_1, constant_2);
          const Space v21_25 = routine_4(c, constant_3, constant_4);
          const Space v21_26 = unite(v21_24,v21_25);
          const Space v21_27 = routine_5(c, constant_5, constant_6);
          const Space v21_28 = unite(v21_26,v21_27);
          const Space v21_29 = routine_6(c, constant_7, constant_8);
          const Space v21_30 = unite(v21_28,v21_29);
          v20_31 = compose(constant_0,v21_30);
        }
        v15_32 = compose(constant_0,v20_31);
      }
      Space v15_33_result;
      for (int v15_33_label = 1; v15_33_label <= 2; ++v15_33_label) {
        const Space v15_33_tail = child(v15_32,v15_33_label);
        if (v15_33_tail.empty()) continue;
        const Path v15_33_head{v15_33_label};
        const Space v22_2 = singleton(v15_33_head);
        const Space v22_3 = intersect(constant_9,v22_2);
        const Space v22_4 = (has_head(v22_3) ? constant_10 : Space{});
        const Space v22_5 = subtract(constant_0,v22_4);
        Space v22_7;
        if (!v22_5.empty()) {
          Space v23_6_result;
          for (int v23_6_label = 1; v23_6_label <= 2; ++v23_6_label) {
            const Space v23_6_tail = child(v15_33_tail,v23_6_label);
            if (v23_6_tail.empty()) continue;
            const Path v23_6_head{v23_6_label};
            const Space v24_2 = singleton(v23_6_head);
            const Space v24_3 = intersect(constant_9,v24_2);
            const Space v24_4 = (has_head(v24_3) ? constant_10 : Space{});
            const Space v24_5 = subtract(constant_0,v24_4);
            Space v24_8;
            if (!v24_5.empty()) {
              const Path v25_6 = concat_path(v15_33_head,v23_6_head);
              const Space v25_7 = routine_7(c, v25_6, v23_6_tail);
              v24_8 = compose(v24_5,v25_7);
            }
            const Space v24_9 = intersect(constant_9,v24_2);
            const Space v24_10 = (has_head(v24_9) ? constant_10 : Space{});
            Space v24_12;
            if (!v24_10.empty()) {
              const Path v26_6 = concat_path(v15_33_head,v23_6_head);
              const Space v26_11 = routine_8(c, v26_6, v23_6_tail);
              v24_12 = compose(v24_10,v26_11);
            }
            const Space v24_13 = unite(v24_8,v24_12);
            v23_6_result = unite(v23_6_result,v24_13);
          }
          const Space v23_6 = std::move(v23_6_result);
          v22_7 = compose(v22_5,v23_6);
        }
        const Space v22_8 = intersect(constant_9,v22_2);
        const Space v22_9 = (has_head(v22_8) ? constant_10 : Space{});
        Space v22_11;
        if (!v22_9.empty()) {
          Space v27_10_result;
          for (int v27_10_label = 1; v27_10_label <= 2; ++v27_10_label) {
            const Space v27_10_tail = child(v15_33_tail,v27_10_label);
            if (v27_10_tail.empty()) continue;
            const Path v27_10_head{v27_10_label};
            const Space v28_2 = singleton(v27_10_head);
            const Space v28_3 = intersect(constant_9,v28_2);
            const Space v28_4 = (has_head(v28_3) ? constant_10 : Space{});
            const Space v28_5 = subtract(constant_0,v28_4);
            Space v28_8;
            if (!v28_5.empty()) {
              const Path v29_6 = concat_path(v15_33_head,v27_10_head);
              const Space v29_7 = routine_7(c, v29_6, v27_10_tail);
              v28_8 = compose(v28_5,v29_7);
            }
            const Space v28_9 = intersect(constant_9,v28_2);
            const Space v28_10 = (has_head(v28_9) ? constant_10 : Space{});
            Space v28_12;
            if (!v28_10.empty()) {
              const Path v30_6 = concat_path(v15_33_head,v27_10_head);
              const Space v30_11 = routine_9(c, v30_6, v27_10_tail);
              v28_12 = compose(v28_10,v30_11);
            }
            const Space v28_13 = unite(v28_8,v28_12);
            v27_10_result = unite(v27_10_result,v28_13);
          }
          const Space v27_10 = std::move(v27_10_result);
          v22_11 = compose(v22_9,v27_10);
        }
        const Space v22_12 = unite(v22_7,v22_11);
        v15_33_result = unite(v15_33_result,v22_12);
      }
      const Space v15_33 = std::move(v15_33_result);
      const Space v15_34 = unite(v15_23,v15_33);
      const Space v15_35 = routine_14(c, v0_105_head, v0_105_tail, v15_14, constant_11, v15_34);
      v14_36 = compose(v14_5,v15_35);
    }
    const Space v14_37 = intersect(constant_9,v14_2);
    const Space v14_38 = (has_head(v14_37) ? constant_10 : Space{});
    Space v14_69;
    if (!v14_38.empty()) {
      Space v31_47;
      if (!constant_0.empty()) {
        Space v32_46;
        if (!constant_0.empty()) {
          const Space v33_39 = routine_11(c, constant_1, constant_2);
          const Space v33_40 = routine_11(c, constant_3, constant_4);
          const Space v33_41 = unite(v33_39,v33_40);
          const Space v33_42 = routine_12(c, constant_5, constant_6);
          const Space v33_43 = unite(v33_41,v33_42);
          const Space v33_44 = routine_13(c, constant_7, constant_8);
          const Space v33_45 = unite(v33_43,v33_44);
          v32_46 = compose(constant_0,v33_45);
        }
        v31_47 = compose(constant_0,v32_46);
      }
      Space v31_56;
      if (!constant_0.empty()) {
        Space v34_55;
        if (!constant_0.empty()) {
          const Space v35_48 = routine_1(c, constant_1, constant_2);
          const Space v35_49 = routine_1(c, constant_3, constant_4);
          const Space v35_50 = unite(v35_48,v35_49);
          const Space v35_51 = routine_2(c, constant_5, constant_6);
          const Space v35_52 = unite(v35_50,v35_51);
          const Space v35_53 = routine_3(c, constant_7, constant_8);
          const Space v35_54 = unite(v35_52,v35_53);
          v34_55 = compose(constant_0,v35_54);
        }
        v31_56 = compose(constant_0,v34_55);
      }
      Space v31_65;
      if (!constant_0.empty()) {
        Space v36_64;
        if (!constant_0.empty()) {
          const Space v37_57 = routine_4(c, constant_1, constant_2);
          const Space v37_58 = routine_4(c, constant_3, constant_4);
          const Space v37_59 = unite(v37_57,v37_58);
          const Space v37_60 = routine_5(c, constant_5, constant_6);
          const Space v37_61 = unite(v37_59,v37_60);
          const Space v37_62 = routine_6(c, constant_7, constant_8);
          const Space v37_63 = unite(v37_61,v37_62);
          v36_64 = compose(constant_0,v37_63);
        }
        v31_65 = compose(constant_0,v36_64);
      }
      Space v31_66_result;
      for (int v31_66_label = 1; v31_66_label <= 2; ++v31_66_label) {
        const Space v31_66_tail = child(v31_65,v31_66_label);
        if (v31_66_tail.empty()) continue;
        const Path v31_66_head{v31_66_label};
        const Space v38_2 = singleton(v31_66_head);
        const Space v38_3 = intersect(constant_9,v38_2);
        const Space v38_4 = (has_head(v38_3) ? constant_10 : Space{});
        const Space v38_5 = subtract(constant_0,v38_4);
        Space v38_7;
        if (!v38_5.empty()) {
          Space v39_6_result;
          for (int v39_6_label = 1; v39_6_label <= 2; ++v39_6_label) {
            const Space v39_6_tail = child(v31_66_tail,v39_6_label);
            if (v39_6_tail.empty()) continue;
            const Path v39_6_head{v39_6_label};
            const Space v40_2 = singleton(v39_6_head);
            const Space v40_3 = intersect(constant_9,v40_2);
            const Space v40_4 = (has_head(v40_3) ? constant_10 : Space{});
            const Space v40_5 = subtract(constant_0,v40_4);
            Space v40_8;
            if (!v40_5.empty()) {
              const Path v41_6 = concat_path(v31_66_head,v39_6_head);
              const Space v41_7 = routine_7(c, v41_6, v39_6_tail);
              v40_8 = compose(v40_5,v41_7);
            }
            const Space v40_9 = intersect(constant_9,v40_2);
            const Space v40_10 = (has_head(v40_9) ? constant_10 : Space{});
            Space v40_12;
            if (!v40_10.empty()) {
              const Path v42_6 = concat_path(v31_66_head,v39_6_head);
              const Space v42_11 = routine_8(c, v42_6, v39_6_tail);
              v40_12 = compose(v40_10,v42_11);
            }
            const Space v40_13 = unite(v40_8,v40_12);
            v39_6_result = unite(v39_6_result,v40_13);
          }
          const Space v39_6 = std::move(v39_6_result);
          v38_7 = compose(v38_5,v39_6);
        }
        const Space v38_8 = intersect(constant_9,v38_2);
        const Space v38_9 = (has_head(v38_8) ? constant_10 : Space{});
        Space v38_11;
        if (!v38_9.empty()) {
          Space v43_10_result;
          for (int v43_10_label = 1; v43_10_label <= 2; ++v43_10_label) {
            const Space v43_10_tail = child(v31_66_tail,v43_10_label);
            if (v43_10_tail.empty()) continue;
            const Path v43_10_head{v43_10_label};
            const Space v44_2 = singleton(v43_10_head);
            const Space v44_3 = intersect(constant_9,v44_2);
            const Space v44_4 = (has_head(v44_3) ? constant_10 : Space{});
            const Space v44_5 = subtract(constant_0,v44_4);
            Space v44_8;
            if (!v44_5.empty()) {
              const Path v45_6 = concat_path(v31_66_head,v43_10_head);
              const Space v45_7 = routine_7(c, v45_6, v43_10_tail);
              v44_8 = compose(v44_5,v45_7);
            }
            const Space v44_9 = intersect(constant_9,v44_2);
            const Space v44_10 = (has_head(v44_9) ? constant_10 : Space{});
            Space v44_12;
            if (!v44_10.empty()) {
              const Path v46_6 = concat_path(v31_66_head,v43_10_head);
              const Space v46_11 = routine_9(c, v46_6, v43_10_tail);
              v44_12 = compose(v44_10,v46_11);
            }
            const Space v44_13 = unite(v44_8,v44_12);
            v43_10_result = unite(v43_10_result,v44_13);
          }
          const Space v43_10 = std::move(v43_10_result);
          v38_11 = compose(v38_9,v43_10);
        }
        const Space v38_12 = unite(v38_7,v38_11);
        v31_66_result = unite(v31_66_result,v38_12);
      }
      const Space v31_66 = std::move(v31_66_result);
      const Space v31_67 = unite(v31_56,v31_66);
      const Space v31_68 = routine_15(c, v0_105_head, v0_105_tail, v31_47, constant_11, v31_67);
      v14_69 = compose(v14_38,v31_68);
    }
    const Space v14_70 = unite(v14_36,v14_69);
    v0_105_result = unite(v0_105_result,v14_70);
  }
  const Space v0_105 = std::move(v0_105_result);
  return v0_105;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v47_11_result;
  for (int v47_11_label = 1; v47_11_label <= 2; ++v47_11_label) {
    const Space v47_11_tail = child(s0,v47_11_label);
    if (v47_11_tail.empty()) continue;
    const Path v47_11_head{v47_11_label};
    const Space v48_2 = singleton(v47_11_head);
    const Space v48_3 = intersect(constant_9,v48_2);
    const Space v48_4 = (has_head(v48_3) ? constant_10 : Space{});
    const Space v48_5 = subtract(constant_0,v48_4);
    Space v48_8;
    if (!v48_5.empty()) {
      const Path v49_6 = concat_path(p0,v47_11_head);
      Space v49_7_result;
      for (int v49_7_label = 1; v49_7_label <= 2; ++v49_7_label) {
        const Space v49_7_tail = child(v47_11_tail,v49_7_label);
        if (v49_7_tail.empty()) continue;
        const Path v49_7_head{v49_7_label};
        const Space v50_2 = singleton(v49_7_head);
        const Space v50_3 = intersect(constant_9,v50_2);
        const Space v50_4 = (has_head(v50_3) ? constant_10 : Space{});
        const Space v50_5 = subtract(constant_0,v50_4);
        Space v50_8;
        if (!v50_5.empty()) {
          const Path v51_6 = concat_path(v49_6,v49_7_head);
          const Space v51_7 = routine_16(c, v51_6, v49_7_tail);
          v50_8 = compose(v50_5,v51_7);
        }
        const Space v50_9 = intersect(constant_9,v50_2);
        const Space v50_10 = (has_head(v50_9) ? constant_10 : Space{});
        Space v50_12;
        if (!v50_10.empty()) {
          const Path v52_6 = concat_path(v49_6,v49_7_head);
          const Space v52_11 = routine_17(c, v52_6, v49_7_tail);
          v50_12 = compose(v50_10,v52_11);
        }
        const Space v50_13 = unite(v50_8,v50_12);
        v49_7_result = unite(v49_7_result,v50_13);
      }
      const Space v49_7 = std::move(v49_7_result);
      v48_8 = compose(v48_5,v49_7);
    }
    const Space v48_9 = intersect(constant_9,v48_2);
    const Space v48_10 = (has_head(v48_9) ? constant_10 : Space{});
    Space v48_12;
    if (!v48_10.empty()) {
      const Path v53_6 = concat_path(p0,v47_11_head);
      Space v53_11_result;
      for (int v53_11_label = 1; v53_11_label <= 2; ++v53_11_label) {
        const Space v53_11_tail = child(v47_11_tail,v53_11_label);
        if (v53_11_tail.empty()) continue;
        const Path v53_11_head{v53_11_label};
        const Space v54_2 = singleton(v53_11_head);
        const Space v54_3 = intersect(constant_9,v54_2);
        const Space v54_4 = (has_head(v54_3) ? constant_10 : Space{});
        const Space v54_5 = subtract(constant_0,v54_4);
        Space v54_8;
        if (!v54_5.empty()) {
          const Path v55_6 = concat_path(v53_6,v53_11_head);
          const Space v55_7 = routine_16(c, v55_6, v53_11_tail);
          v54_8 = compose(v54_5,v55_7);
        }
        const Space v54_9 = intersect(constant_9,v54_2);
        const Space v54_10 = (has_head(v54_9) ? constant_10 : Space{});
        Space v54_12;
        if (!v54_10.empty()) {
          const Path v56_6 = concat_path(v53_6,v53_11_head);
          const Space v56_11 = routine_3(c, v56_6, v53_11_tail);
          v54_12 = compose(v54_10,v56_11);
        }
        const Space v54_13 = unite(v54_8,v54_12);
        v53_11_result = unite(v53_11_result,v54_13);
      }
      const Space v53_11 = std::move(v53_11_result);
      v48_12 = compose(v48_10,v53_11);
    }
    const Space v48_13 = unite(v48_8,v48_12);
    v47_11_result = unite(v47_11_result,v48_13);
  }
  const Space v47_11 = std::move(v47_11_result);
  return v47_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v57_8_result;
  for (int v57_8_label = 1; v57_8_label <= 2; ++v57_8_label) {
    const Space v57_8_tail = child(s0,v57_8_label);
    if (v57_8_tail.empty()) continue;
    const Path v57_8_head{v57_8_label};
    const Space v58_2 = singleton(v57_8_head);
    const Space v58_3 = intersect(constant_9,v58_2);
    const Space v58_4 = (has_head(v58_3) ? constant_10 : Space{});
    const Space v58_5 = subtract(constant_0,v58_4);
    Space v58_8;
    if (!v58_5.empty()) {
      const Path v59_6 = concat_path(p0,v57_8_head);
      Space v59_7_result;
      for (int v59_7_label = 1; v59_7_label <= 2; ++v59_7_label) {
        const Space v59_7_tail = child(v57_8_tail,v59_7_label);
        if (v59_7_tail.empty()) continue;
        const Path v59_7_head{v59_7_label};
        const Space v60_2 = singleton(v59_7_head);
        const Space v60_3 = intersect(constant_9,v60_2);
        const Space v60_4 = (has_head(v60_3) ? constant_10 : Space{});
        const Space v60_5 = subtract(constant_0,v60_4);
        Space v60_8;
        if (!v60_5.empty()) {
          const Path v61_6 = concat_path(v59_6,v59_7_head);
          const Space v61_7 = routine_16(c, v61_6, v59_7_tail);
          v60_8 = compose(v60_5,v61_7);
        }
        const Space v60_9 = intersect(constant_9,v60_2);
        const Space v60_10 = (has_head(v60_9) ? constant_10 : Space{});
        Space v60_12;
        if (!v60_10.empty()) {
          const Path v62_6 = concat_path(v59_6,v59_7_head);
          const Space v62_11 = routine_17(c, v62_6, v59_7_tail);
          v60_12 = compose(v60_10,v62_11);
        }
        const Space v60_13 = unite(v60_8,v60_12);
        v59_7_result = unite(v59_7_result,v60_13);
      }
      const Space v59_7 = std::move(v59_7_result);
      v58_8 = compose(v58_5,v59_7);
    }
    const Space v58_9 = intersect(constant_9,v58_2);
    const Space v58_10 = (has_head(v58_9) ? constant_10 : Space{});
    const Path v63_6 = concat_path(p0,v57_8_head);
    const Space v58_11 = singleton(v63_6);
    const Space v58_12 = compose(v58_10,v58_11);
    const Space v58_13 = unite(v58_8,v58_12);
    v57_8_result = unite(v57_8_result,v58_13);
  }
  const Space v57_8 = std::move(v57_8_result);
  return v57_8;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  const Space v64_2 = singleton(p0);
  return v64_2;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v65_11_result;
  for (int v65_11_label = 1; v65_11_label <= 2; ++v65_11_label) {
    const Space v65_11_tail = child(s0,v65_11_label);
    if (v65_11_tail.empty()) continue;
    const Path v65_11_head{v65_11_label};
    const Space v66_2 = singleton(v65_11_head);
    const Space v66_3 = intersect(constant_9,v66_2);
    const Space v66_4 = (has_head(v66_3) ? constant_10 : Space{});
    const Space v66_5 = subtract(constant_0,v66_4);
    Space v66_8;
    if (!v66_5.empty()) {
      const Path v67_6 = concat_path(p0,v65_11_head);
      Space v67_7_result;
      for (int v67_7_label = 1; v67_7_label <= 2; ++v67_7_label) {
        const Space v67_7_tail = child(v65_11_tail,v67_7_label);
        if (v67_7_tail.empty()) continue;
        const Path v67_7_head{v67_7_label};
        const Space v68_2 = singleton(v67_7_head);
        const Space v68_3 = intersect(constant_9,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_10 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v67_6,v67_7_head);
          const Space v69_7 = routine_18(c, v69_6, v67_7_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_9,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_10 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v67_6,v67_7_head);
          const Space v70_11 = routine_19(c, v70_6, v67_7_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_7_result = unite(v67_7_result,v68_13);
      }
      const Space v67_7 = std::move(v67_7_result);
      v66_8 = compose(v66_5,v67_7);
    }
    const Space v66_9 = intersect(constant_9,v66_2);
    const Space v66_10 = (has_head(v66_9) ? constant_10 : Space{});
    Space v66_12;
    if (!v66_10.empty()) {
      const Path v71_6 = concat_path(p0,v65_11_head);
      Space v71_11_result;
      for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
        const Space v71_11_tail = child(v65_11_tail,v71_11_label);
        if (v71_11_tail.empty()) continue;
        const Path v71_11_head{v71_11_label};
        const Space v72_2 = singleton(v71_11_head);
        const Space v72_3 = intersect(constant_9,v72_2);
        const Space v72_4 = (has_head(v72_3) ? constant_10 : Space{});
        const Space v72_5 = subtract(constant_0,v72_4);
        Space v72_8;
        if (!v72_5.empty()) {
          const Path v73_6 = concat_path(v71_6,v71_11_head);
          const Space v73_7 = routine_18(c, v73_6, v71_11_tail);
          v72_8 = compose(v72_5,v73_7);
        }
        const Space v72_9 = intersect(constant_9,v72_2);
        const Space v72_10 = (has_head(v72_9) ? constant_10 : Space{});
        Space v72_12;
        if (!v72_10.empty()) {
          const Path v74_6 = concat_path(v71_6,v71_11_head);
          const Space v74_11 = routine_6(c, v74_6, v71_11_tail);
          v72_12 = compose(v72_10,v74_11);
        }
        const Space v72_13 = unite(v72_8,v72_12);
        v71_11_result = unite(v71_11_result,v72_13);
      }
      const Space v71_11 = std::move(v71_11_result);
      v66_12 = compose(v66_10,v71_11);
    }
    const Space v66_13 = unite(v66_8,v66_12);
    v65_11_result = unite(v65_11_result,v66_13);
  }
  const Space v65_11 = std::move(v65_11_result);
  return v65_11;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  Space v75_11_result;
  for (int v75_11_label = 1; v75_11_label <= 2; ++v75_11_label) {
    const Space v75_11_tail = child(s0,v75_11_label);
    if (v75_11_tail.empty()) continue;
    const Path v75_11_head{v75_11_label};
    const Space v76_2 = singleton(v75_11_head);
    const Space v76_3 = intersect(constant_9,v76_2);
    const Space v76_4 = (has_head(v76_3) ? constant_10 : Space{});
    const Space v76_5 = subtract(constant_0,v76_4);
    Space v76_8;
    if (!v76_5.empty()) {
      const Path v77_6 = concat_path(p0,v75_11_head);
      Space v77_7_result;
      for (int v77_7_label = 1; v77_7_label <= 2; ++v77_7_label) {
        const Space v77_7_tail = child(v75_11_tail,v77_7_label);
        if (v77_7_tail.empty()) continue;
        const Path v77_7_head{v77_7_label};
        const Space v78_2 = singleton(v77_7_head);
        const Space v78_3 = intersect(constant_9,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_10 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_7_head);
          const Space v79_7 = routine_18(c, v79_6, v77_7_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_9,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_10 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_7_head);
          const Space v80_11 = routine_19(c, v80_6, v77_7_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_7_result = unite(v77_7_result,v78_13);
      }
      const Space v77_7 = std::move(v77_7_result);
      v76_8 = compose(v76_5,v77_7);
    }
    const Space v76_9 = intersect(constant_9,v76_2);
    const Space v76_10 = (has_head(v76_9) ? constant_10 : Space{});
    Space v76_12;
    if (!v76_10.empty()) {
      const Path v81_6 = concat_path(p0,v75_11_head);
      Space v81_11_result;
      for (int v81_11_label = 1; v81_11_label <= 2; ++v81_11_label) {
        const Space v81_11_tail = child(v75_11_tail,v81_11_label);
        if (v81_11_tail.empty()) continue;
        const Path v81_11_head{v81_11_label};
        const Space v82_2 = singleton(v81_11_head);
        const Space v82_3 = intersect(constant_9,v82_2);
        const Space v82_4 = (has_head(v82_3) ? constant_10 : Space{});
        const Space v82_5 = subtract(constant_0,v82_4);
        Space v82_7;
        if (!v82_5.empty()) {
          const Space v83_6 = routine_20(c, v81_11_head, v81_6, v81_11_tail);
          v82_7 = compose(v82_5,v83_6);
        }
        const Space v82_8 = intersect(constant_9,v82_2);
        const Space v82_9 = (has_head(v82_8) ? constant_10 : Space{});
        Space v82_11;
        if (!v82_9.empty()) {
          const Space v84_10 = routine_21(c, v81_11_head, v81_6, v81_11_tail);
          v82_11 = compose(v82_9,v84_10);
        }
        const Space v82_12 = unite(v82_7,v82_11);
        v81_11_result = unite(v81_11_result,v82_12);
      }
      const Space v81_11 = std::move(v81_11_result);
      v76_12 = compose(v76_10,v81_11);
    }
    const Space v76_13 = unite(v76_8,v76_12);
    v75_11_result = unite(v75_11_result,v76_13);
  }
  const Space v75_11 = std::move(v75_11_result);
  return v75_11;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v85_11_result;
  for (int v85_11_label = 1; v85_11_label <= 2; ++v85_11_label) {
    const Space v85_11_tail = child(s0,v85_11_label);
    if (v85_11_tail.empty()) continue;
    const Path v85_11_head{v85_11_label};
    const Space v86_2 = singleton(v85_11_head);
    const Space v86_3 = intersect(constant_9,v86_2);
    const Space v86_4 = (has_head(v86_3) ? constant_10 : Space{});
    const Space v86_5 = subtract(constant_0,v86_4);
    Space v86_7;
    if (!v86_5.empty()) {
      Space v87_6_result;
      for (int v87_6_label = 1; v87_6_label <= 2; ++v87_6_label) {
        const Space v87_6_tail = child(v85_11_tail,v87_6_label);
        if (v87_6_tail.empty()) continue;
        const Path v87_6_head{v87_6_label};
        const Space v88_2 = singleton(v87_6_head);
        const Space v88_3 = intersect(constant_9,v88_2);
        const Space v88_4 = (has_head(v88_3) ? constant_10 : Space{});
        const Space v88_5 = subtract(constant_0,v88_4);
        Space v88_8;
        if (!v88_5.empty()) {
          const Path v89_6 = concat_path(v85_11_head,v87_6_head);
          const Space v89_7 = routine_22(c, v89_6, p0, v87_6_tail);
          v88_8 = compose(v88_5,v89_7);
        }
        const Space v88_9 = intersect(constant_9,v88_2);
        const Space v88_10 = (has_head(v88_9) ? constant_10 : Space{});
        Space v88_12;
        if (!v88_10.empty()) {
          const Path v90_6 = concat_path(v85_11_head,v87_6_head);
          const Space v90_11 = routine_23(c, v90_6, p0, v87_6_tail);
          v88_12 = compose(v88_10,v90_11);
        }
        const Space v88_13 = unite(v88_8,v88_12);
        v87_6_result = unite(v87_6_result,v88_13);
      }
      const Space v87_6 = std::move(v87_6_result);
      v86_7 = compose(v86_5,v87_6);
    }
    const Space v86_8 = intersect(constant_9,v86_2);
    const Space v86_9 = (has_head(v86_8) ? constant_10 : Space{});
    Space v86_11;
    if (!v86_9.empty()) {
      Space v91_10_result;
      for (int v91_10_label = 1; v91_10_label <= 2; ++v91_10_label) {
        const Space v91_10_tail = child(v85_11_tail,v91_10_label);
        if (v91_10_tail.empty()) continue;
        const Path v91_10_head{v91_10_label};
        const Space v92_2 = singleton(v91_10_head);
        const Space v92_3 = intersect(constant_9,v92_2);
        const Space v92_4 = (has_head(v92_3) ? constant_10 : Space{});
        const Space v92_5 = subtract(constant_0,v92_4);
        Space v92_8;
        if (!v92_5.empty()) {
          const Path v93_6 = concat_path(v85_11_head,v91_10_head);
          const Space v93_7 = routine_22(c, v93_6, p0, v91_10_tail);
          v92_8 = compose(v92_5,v93_7);
        }
        const Space v92_9 = intersect(constant_9,v92_2);
        const Space v92_10 = (has_head(v92_9) ? constant_10 : Space{});
        Space v92_12;
        if (!v92_10.empty()) {
          const Path v94_6 = concat_path(v85_11_head,v91_10_head);
          const Space v94_11 = routine_24(c, v94_6, p0, v91_10_tail);
          v92_12 = compose(v92_10,v94_11);
        }
        const Space v92_13 = unite(v92_8,v92_12);
        v91_10_result = unite(v91_10_result,v92_13);
      }
      const Space v91_10 = std::move(v91_10_result);
      v86_11 = compose(v86_9,v91_10);
    }
    const Space v86_12 = unite(v86_7,v86_11);
    v85_11_result = unite(v85_11_result,v86_12);
  }
  const Space v85_11 = std::move(v85_11_result);
  return v85_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v95_11_result;
  for (int v95_11_label = 1; v95_11_label <= 2; ++v95_11_label) {
    const Space v95_11_tail = child(s0,v95_11_label);
    if (v95_11_tail.empty()) continue;
    const Path v95_11_head{v95_11_label};
    const Space v96_2 = singleton(v95_11_head);
    const Space v96_3 = intersect(constant_9,v96_2);
    const Space v96_4 = (has_head(v96_3) ? constant_10 : Space{});
    const Space v96_5 = subtract(constant_0,v96_4);
    Space v96_8;
    if (!v96_5.empty()) {
      const Path v97_6 = concat_path(p0,v95_11_head);
      Space v97_7_result;
      for (int v97_7_label = 1; v97_7_label <= 2; ++v97_7_label) {
        const Space v97_7_tail = child(v95_11_tail,v97_7_label);
        if (v97_7_tail.empty()) continue;
        const Path v97_7_head{v97_7_label};
        const Space v98_2 = singleton(v97_7_head);
        const Space v98_3 = intersect(constant_9,v98_2);
        const Space v98_4 = (has_head(v98_3) ? constant_10 : Space{});
        const Space v98_5 = subtract(constant_0,v98_4);
        Space v98_8;
        if (!v98_5.empty()) {
          const Path v99_6 = concat_path(v97_6,v97_7_head);
          const Space v99_7 = routine_25(c, v99_6, v97_7_tail);
          v98_8 = compose(v98_5,v99_7);
        }
        const Space v98_9 = intersect(constant_9,v98_2);
        const Space v98_10 = (has_head(v98_9) ? constant_10 : Space{});
        Space v98_12;
        if (!v98_10.empty()) {
          const Path v100_6 = concat_path(v97_6,v97_7_head);
          const Space v100_11 = routine_26(c, v100_6, v97_7_tail);
          v98_12 = compose(v98_10,v100_11);
        }
        const Space v98_13 = unite(v98_8,v98_12);
        v97_7_result = unite(v97_7_result,v98_13);
      }
      const Space v97_7 = std::move(v97_7_result);
      v96_8 = compose(v96_5,v97_7);
    }
    const Space v96_9 = intersect(constant_9,v96_2);
    const Space v96_10 = (has_head(v96_9) ? constant_10 : Space{});
    Space v96_12;
    if (!v96_10.empty()) {
      const Path v101_6 = concat_path(p0,v95_11_head);
      Space v101_11_result;
      for (int v101_11_label = 1; v101_11_label <= 2; ++v101_11_label) {
        const Space v101_11_tail = child(v95_11_tail,v101_11_label);
        if (v101_11_tail.empty()) continue;
        const Path v101_11_head{v101_11_label};
        const Space v102_2 = singleton(v101_11_head);
        const Space v102_3 = intersect(constant_9,v102_2);
        const Space v102_4 = (has_head(v102_3) ? constant_10 : Space{});
        const Space v102_5 = subtract(constant_0,v102_4);
        Space v102_8;
        if (!v102_5.empty()) {
          const Path v103_6 = concat_path(v101_6,v101_11_head);
          const Space v103_7 = routine_25(c, v103_6, v101_11_tail);
          v102_8 = compose(v102_5,v103_7);
        }
        const Space v102_9 = intersect(constant_9,v102_2);
        const Space v102_10 = (has_head(v102_9) ? constant_10 : Space{});
        Space v102_12;
        if (!v102_10.empty()) {
          const Path v104_6 = concat_path(v101_6,v101_11_head);
          const Space v104_11 = routine_9(c, v104_6, v101_11_tail);
          v102_12 = compose(v102_10,v104_11);
        }
        const Space v102_13 = unite(v102_8,v102_12);
        v101_11_result = unite(v101_11_result,v102_13);
      }
      const Space v101_11 = std::move(v101_11_result);
      v96_12 = compose(v96_10,v101_11);
    }
    const Space v96_13 = unite(v96_8,v96_12);
    v95_11_result = unite(v95_11_result,v96_13);
  }
  const Space v95_11 = std::move(v95_11_result);
  return v95_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v105_8_result;
  for (int v105_8_label = 1; v105_8_label <= 2; ++v105_8_label) {
    const Space v105_8_tail = child(s0,v105_8_label);
    if (v105_8_tail.empty()) continue;
    const Path v105_8_head{v105_8_label};
    const Space v106_2 = singleton(v105_8_head);
    const Space v106_3 = intersect(constant_9,v106_2);
    const Space v106_4 = (has_head(v106_3) ? constant_10 : Space{});
    const Space v106_5 = subtract(constant_0,v106_4);
    Space v106_8;
    if (!v106_5.empty()) {
      const Path v107_6 = concat_path(p0,v105_8_head);
      Space v107_7_result;
      for (int v107_7_label = 1; v107_7_label <= 2; ++v107_7_label) {
        const Space v107_7_tail = child(v105_8_tail,v107_7_label);
        if (v107_7_tail.empty()) continue;
        const Path v107_7_head{v107_7_label};
        const Space v108_2 = singleton(v107_7_head);
        const Space v108_3 = intersect(constant_9,v108_2);
        const Space v108_4 = (has_head(v108_3) ? constant_10 : Space{});
        const Space v108_5 = subtract(constant_0,v108_4);
        Space v108_8;
        if (!v108_5.empty()) {
          const Path v109_6 = concat_path(v107_6,v107_7_head);
          const Space v109_7 = routine_25(c, v109_6, v107_7_tail);
          v108_8 = compose(v108_5,v109_7);
        }
        const Space v108_9 = intersect(constant_9,v108_2);
        const Space v108_10 = (has_head(v108_9) ? constant_10 : Space{});
        Space v108_12;
        if (!v108_10.empty()) {
          const Path v110_6 = concat_path(v107_6,v107_7_head);
          const Space v110_11 = routine_26(c, v110_6, v107_7_tail);
          v108_12 = compose(v108_10,v110_11);
        }
        const Space v108_13 = unite(v108_8,v108_12);
        v107_7_result = unite(v107_7_result,v108_13);
      }
      const Space v107_7 = std::move(v107_7_result);
      v106_8 = compose(v106_5,v107_7);
    }
    const Space v106_9 = intersect(constant_9,v106_2);
    const Space v106_10 = (has_head(v106_9) ? constant_10 : Space{});
    const Path v111_6 = concat_path(p0,v105_8_head);
    const Space v106_11 = singleton(v111_6);
    const Space v106_12 = compose(v106_10,v106_11);
    const Space v106_13 = unite(v106_8,v106_12);
    v105_8_result = unite(v105_8_result,v106_13);
  }
  const Space v105_8 = std::move(v105_8_result);
  return v105_8;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  const Space v112_2 = singleton(p0);
  return v112_2;
}

static Space routine_10(Context& c, const Space& s0) {
  const Space v113_1 = (has_head(s0) ? constant_10 : Space{});
  const Space v113_2 = first_matching(s0,constant_0,false);
  const Space v113_3 = unite(v113_1,v113_2);
  Space v113_6;
  if (!v113_3.empty()) {
    const Space v114_4 = routine_27(c, s0);
    const Space v114_5 = subtract(s0,v114_4);
    v113_6 = compose(v113_3,v114_5);
  }
  const Space v113_7 = subtract(s0,v113_6);
  return v113_7;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  Space v115_11_result;
  for (int v115_11_label = 1; v115_11_label <= 2; ++v115_11_label) {
    const Space v115_11_tail = child(s0,v115_11_label);
    if (v115_11_tail.empty()) continue;
    const Path v115_11_head{v115_11_label};
    const Space v116_2 = singleton(v115_11_head);
    const Space v116_3 = intersect(constant_9,v116_2);
    const Space v116_4 = (has_head(v116_3) ? constant_10 : Space{});
    const Space v116_5 = subtract(constant_0,v116_4);
    Space v116_8;
    if (!v116_5.empty()) {
      const Path v117_6 = concat_path(p0,v115_11_head);
      Space v117_7_result;
      for (int v117_7_label = 1; v117_7_label <= 2; ++v117_7_label) {
        const Space v117_7_tail = child(v115_11_tail,v117_7_label);
        if (v117_7_tail.empty()) continue;
        const Path v117_7_head{v117_7_label};
        const Space v118_2 = singleton(v117_7_head);
        const Space v118_3 = intersect(constant_9,v118_2);
        const Space v118_4 = (has_head(v118_3) ? constant_10 : Space{});
        const Space v118_5 = subtract(constant_0,v118_4);
        Space v118_8;
        if (!v118_5.empty()) {
          const Path v119_6 = concat_path(v117_6,v117_7_head);
          const Space v119_7 = routine_28(c, v119_6, v117_7_tail);
          v118_8 = compose(v118_5,v119_7);
        }
        const Space v118_9 = intersect(constant_9,v118_2);
        const Space v118_10 = (has_head(v118_9) ? constant_10 : Space{});
        Space v118_12;
        if (!v118_10.empty()) {
          const Path v120_6 = concat_path(v117_6,v117_7_head);
          const Space v120_11 = routine_29(c, v120_6, v117_7_tail);
          v118_12 = compose(v118_10,v120_11);
        }
        const Space v118_13 = unite(v118_8,v118_12);
        v117_7_result = unite(v117_7_result,v118_13);
      }
      const Space v117_7 = std::move(v117_7_result);
      v116_8 = compose(v116_5,v117_7);
    }
    const Space v116_9 = intersect(constant_9,v116_2);
    const Space v116_10 = (has_head(v116_9) ? constant_10 : Space{});
    Space v116_12;
    if (!v116_10.empty()) {
      const Path v121_6 = concat_path(p0,v115_11_head);
      Space v121_11_result;
      for (int v121_11_label = 1; v121_11_label <= 2; ++v121_11_label) {
        const Space v121_11_tail = child(v115_11_tail,v121_11_label);
        if (v121_11_tail.empty()) continue;
        const Path v121_11_head{v121_11_label};
        const Space v122_2 = singleton(v121_11_head);
        const Space v122_3 = intersect(constant_9,v122_2);
        const Space v122_4 = (has_head(v122_3) ? constant_10 : Space{});
        const Space v122_5 = subtract(constant_0,v122_4);
        Space v122_8;
        if (!v122_5.empty()) {
          const Path v123_6 = concat_path(v121_6,v121_11_head);
          const Space v123_7 = routine_28(c, v123_6, v121_11_tail);
          v122_8 = compose(v122_5,v123_7);
        }
        const Space v122_9 = intersect(constant_9,v122_2);
        const Space v122_10 = (has_head(v122_9) ? constant_10 : Space{});
        Space v122_12;
        if (!v122_10.empty()) {
          const Path v124_6 = concat_path(v121_6,v121_11_head);
          const Space v124_11 = routine_13(c, v124_6, v121_11_tail);
          v122_12 = compose(v122_10,v124_11);
        }
        const Space v122_13 = unite(v122_8,v122_12);
        v121_11_result = unite(v121_11_result,v122_13);
      }
      const Space v121_11 = std::move(v121_11_result);
      v116_12 = compose(v116_10,v121_11);
    }
    const Space v116_13 = unite(v116_8,v116_12);
    v115_11_result = unite(v115_11_result,v116_13);
  }
  const Space v115_11 = std::move(v115_11_result);
  return v115_11;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v125_11_result;
  for (int v125_11_label = 1; v125_11_label <= 2; ++v125_11_label) {
    const Space v125_11_tail = child(s0,v125_11_label);
    if (v125_11_tail.empty()) continue;
    const Path v125_11_head{v125_11_label};
    const Space v126_2 = singleton(v125_11_head);
    const Space v126_3 = intersect(constant_9,v126_2);
    const Space v126_4 = (has_head(v126_3) ? constant_10 : Space{});
    const Space v126_5 = subtract(constant_0,v126_4);
    Space v126_8;
    if (!v126_5.empty()) {
      const Path v127_6 = concat_path(p0,v125_11_head);
      Space v127_7_result;
      for (int v127_7_label = 1; v127_7_label <= 2; ++v127_7_label) {
        const Space v127_7_tail = child(v125_11_tail,v127_7_label);
        if (v127_7_tail.empty()) continue;
        const Path v127_7_head{v127_7_label};
        const Space v128_2 = singleton(v127_7_head);
        const Space v128_3 = intersect(constant_9,v128_2);
        const Space v128_4 = (has_head(v128_3) ? constant_10 : Space{});
        const Space v128_5 = subtract(constant_0,v128_4);
        Space v128_8;
        if (!v128_5.empty()) {
          const Path v129_6 = concat_path(v127_6,v127_7_head);
          const Space v129_7 = routine_28(c, v129_6, v127_7_tail);
          v128_8 = compose(v128_5,v129_7);
        }
        const Space v128_9 = intersect(constant_9,v128_2);
        const Space v128_10 = (has_head(v128_9) ? constant_10 : Space{});
        Space v128_12;
        if (!v128_10.empty()) {
          const Path v130_6 = concat_path(v127_6,v127_7_head);
          const Space v130_11 = routine_29(c, v130_6, v127_7_tail);
          v128_12 = compose(v128_10,v130_11);
        }
        const Space v128_13 = unite(v128_8,v128_12);
        v127_7_result = unite(v127_7_result,v128_13);
      }
      const Space v127_7 = std::move(v127_7_result);
      v126_8 = compose(v126_5,v127_7);
    }
    const Space v126_9 = intersect(constant_9,v126_2);
    const Space v126_10 = (has_head(v126_9) ? constant_10 : Space{});
    Space v126_12;
    if (!v126_10.empty()) {
      const Path v131_6 = concat_path(p0,v125_11_head);
      Space v131_11_result;
      for (int v131_11_label = 1; v131_11_label <= 2; ++v131_11_label) {
        const Space v131_11_tail = child(v125_11_tail,v131_11_label);
        if (v131_11_tail.empty()) continue;
        const Path v131_11_head{v131_11_label};
        const Space v132_2 = singleton(v131_11_head);
        const Space v132_3 = intersect(constant_9,v132_2);
        const Space v132_4 = (has_head(v132_3) ? constant_10 : Space{});
        const Space v132_5 = subtract(constant_0,v132_4);
        Space v132_7;
        if (!v132_5.empty()) {
          const Space v133_6 = routine_30(c, v131_11_head, v131_6, v131_11_tail);
          v132_7 = compose(v132_5,v133_6);
        }
        const Space v132_8 = intersect(constant_9,v132_2);
        const Space v132_9 = (has_head(v132_8) ? constant_10 : Space{});
        Space v132_11;
        if (!v132_9.empty()) {
          const Space v134_10 = routine_31(c, v131_11_head, v131_6, v131_11_tail);
          v132_11 = compose(v132_9,v134_10);
        }
        const Space v132_12 = unite(v132_7,v132_11);
        v131_11_result = unite(v131_11_result,v132_12);
      }
      const Space v131_11 = std::move(v131_11_result);
      v126_12 = compose(v126_10,v131_11);
    }
    const Space v126_13 = unite(v126_8,v126_12);
    v125_11_result = unite(v125_11_result,v126_13);
  }
  const Space v125_11 = std::move(v125_11_result);
  return v125_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v135_11_result;
  for (int v135_11_label = 1; v135_11_label <= 2; ++v135_11_label) {
    const Space v135_11_tail = child(s0,v135_11_label);
    if (v135_11_tail.empty()) continue;
    const Path v135_11_head{v135_11_label};
    const Space v136_2 = singleton(v135_11_head);
    const Space v136_3 = intersect(constant_9,v136_2);
    const Space v136_4 = (has_head(v136_3) ? constant_10 : Space{});
    const Space v136_5 = subtract(constant_0,v136_4);
    Space v136_7;
    if (!v136_5.empty()) {
      Space v137_6_result;
      for (int v137_6_label = 1; v137_6_label <= 2; ++v137_6_label) {
        const Space v137_6_tail = child(v135_11_tail,v137_6_label);
        if (v137_6_tail.empty()) continue;
        const Path v137_6_head{v137_6_label};
        const Space v138_2 = singleton(v137_6_head);
        const Space v138_3 = intersect(constant_9,v138_2);
        const Space v138_4 = (has_head(v138_3) ? constant_10 : Space{});
        const Space v138_5 = subtract(constant_0,v138_4);
        Space v138_8;
        if (!v138_5.empty()) {
          const Path v139_6 = concat_path(v135_11_head,v137_6_head);
          const Space v139_7 = routine_32(c, v139_6, p0, v137_6_tail);
          v138_8 = compose(v138_5,v139_7);
        }
        const Space v138_9 = intersect(constant_9,v138_2);
        const Space v138_10 = (has_head(v138_9) ? constant_10 : Space{});
        Space v138_12;
        if (!v138_10.empty()) {
          const Path v140_6 = concat_path(v135_11_head,v137_6_head);
          const Space v140_11 = routine_33(c, v140_6, p0, v137_6_tail);
          v138_12 = compose(v138_10,v140_11);
        }
        const Space v138_13 = unite(v138_8,v138_12);
        v137_6_result = unite(v137_6_result,v138_13);
      }
      const Space v137_6 = std::move(v137_6_result);
      v136_7 = compose(v136_5,v137_6);
    }
    const Space v136_8 = intersect(constant_9,v136_2);
    const Space v136_9 = (has_head(v136_8) ? constant_10 : Space{});
    Space v136_11;
    if (!v136_9.empty()) {
      Space v141_10_result;
      for (int v141_10_label = 1; v141_10_label <= 2; ++v141_10_label) {
        const Space v141_10_tail = child(v135_11_tail,v141_10_label);
        if (v141_10_tail.empty()) continue;
        const Path v141_10_head{v141_10_label};
        const Space v142_2 = singleton(v141_10_head);
        const Space v142_3 = intersect(constant_9,v142_2);
        const Space v142_4 = (has_head(v142_3) ? constant_10 : Space{});
        const Space v142_5 = subtract(constant_0,v142_4);
        Space v142_8;
        if (!v142_5.empty()) {
          const Path v143_6 = concat_path(v135_11_head,v141_10_head);
          const Space v143_7 = routine_32(c, v143_6, p0, v141_10_tail);
          v142_8 = compose(v142_5,v143_7);
        }
        const Space v142_9 = intersect(constant_9,v142_2);
        const Space v142_10 = (has_head(v142_9) ? constant_10 : Space{});
        Space v142_12;
        if (!v142_10.empty()) {
          const Path v144_6 = concat_path(v135_11_head,v141_10_head);
          const Space v144_11 = routine_34(c, v144_6, p0, v141_10_tail);
          v142_12 = compose(v142_10,v144_11);
        }
        const Space v142_13 = unite(v142_8,v142_12);
        v141_10_result = unite(v141_10_result,v142_13);
      }
      const Space v141_10 = std::move(v141_10_result);
      v136_11 = compose(v136_9,v141_10);
    }
    const Space v136_12 = unite(v136_7,v136_11);
    v135_11_result = unite(v135_11_result,v136_12);
  }
  const Space v135_11 = std::move(v135_11_result);
  return v135_11;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v145_14_result;
  for (int v145_14_label = 1; v145_14_label <= 2; ++v145_14_label) {
    const Space v145_14_tail = child(s0,v145_14_label);
    if (v145_14_tail.empty()) continue;
    const Path v145_14_head{v145_14_label};
    const Space v146_2 = singleton(v145_14_head);
    const Space v146_3 = intersect(constant_9,v146_2);
    const Space v146_4 = (has_head(v146_3) ? constant_10 : Space{});
    const Space v146_5 = subtract(constant_0,v146_4);
    Space v146_8;
    if (!v146_5.empty()) {
      const Path v147_6 = concat_path(p0,v145_14_head);
      Space v147_7_result;
      for (int v147_7_label = 1; v147_7_label <= 2; ++v147_7_label) {
        const Space v147_7_tail = child(v145_14_tail,v147_7_label);
        if (v147_7_tail.empty()) continue;
        const Path v147_7_head{v147_7_label};
        const Space v148_2 = singleton(v147_7_head);
        const Space v148_3 = intersect(constant_9,v148_2);
        const Space v148_4 = (has_head(v148_3) ? constant_10 : Space{});
        const Space v148_5 = subtract(constant_0,v148_4);
        Space v148_8;
        if (!v148_5.empty()) {
          const Path v149_6 = concat_path(v147_6,v147_7_head);
          const Space v149_7 = routine_35(c, v149_6, v147_7_tail, s1, s2, s3);
          v148_8 = compose(v148_5,v149_7);
        }
        const Space v148_9 = intersect(constant_9,v148_2);
        const Space v148_10 = (has_head(v148_9) ? constant_10 : Space{});
        Space v148_12;
        if (!v148_10.empty()) {
          const Path v150_6 = concat_path(v147_6,v147_7_head);
          const Space v150_11 = routine_36(c, v150_6, v147_7_tail, s1, s2, s3);
          v148_12 = compose(v148_10,v150_11);
        }
        const Space v148_13 = unite(v148_8,v148_12);
        v147_7_result = unite(v147_7_result,v148_13);
      }
      const Space v147_7 = std::move(v147_7_result);
      v146_8 = compose(v146_5,v147_7);
    }
    const Space v146_9 = intersect(constant_9,v146_2);
    const Space v146_10 = (has_head(v146_9) ? constant_10 : Space{});
    Space v146_12;
    if (!v146_10.empty()) {
      const Path v151_6 = concat_path(p0,v145_14_head);
      Space v151_11_result;
      for (int v151_11_label = 1; v151_11_label <= 2; ++v151_11_label) {
        const Space v151_11_tail = child(v145_14_tail,v151_11_label);
        if (v151_11_tail.empty()) continue;
        const Path v151_11_head{v151_11_label};
        const Space v152_2 = singleton(v151_11_head);
        const Space v152_3 = intersect(constant_9,v152_2);
        const Space v152_4 = (has_head(v152_3) ? constant_10 : Space{});
        const Space v152_5 = subtract(constant_0,v152_4);
        Space v152_8;
        if (!v152_5.empty()) {
          const Path v153_6 = concat_path(v151_6,v151_11_head);
          const Space v153_7 = routine_35(c, v153_6, v151_11_tail, s1, s2, s3);
          v152_8 = compose(v152_5,v153_7);
        }
        const Space v152_9 = intersect(constant_9,v152_2);
        const Space v152_10 = (has_head(v152_9) ? constant_10 : Space{});
        Space v152_12;
        if (!v152_10.empty()) {
          const Path v154_6 = concat_path(v151_6,v151_11_head);
          const Space v154_11 = routine_37(c, v154_6, v151_11_tail, s1, s2, s3);
          v152_12 = compose(v152_10,v154_11);
        }
        const Space v152_13 = unite(v152_8,v152_12);
        v151_11_result = unite(v151_11_result,v152_13);
      }
      const Space v151_11 = std::move(v151_11_result);
      v146_12 = compose(v146_10,v151_11);
    }
    const Space v146_13 = unite(v146_8,v146_12);
    v145_14_result = unite(v145_14_result,v146_13);
  }
  const Space v145_14 = std::move(v145_14_result);
  return v145_14;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v155_11_result;
  for (int v155_11_label = 1; v155_11_label <= 2; ++v155_11_label) {
    const Space v155_11_tail = child(s0,v155_11_label);
    if (v155_11_tail.empty()) continue;
    const Path v155_11_head{v155_11_label};
    const Space v156_2 = singleton(v155_11_head);
    const Space v156_3 = intersect(constant_9,v156_2);
    const Space v156_4 = (has_head(v156_3) ? constant_10 : Space{});
    const Space v156_5 = subtract(constant_0,v156_4);
    Space v156_8;
    if (!v156_5.empty()) {
      const Path v157_6 = concat_path(p0,v155_11_head);
      Space v157_7_result;
      for (int v157_7_label = 1; v157_7_label <= 2; ++v157_7_label) {
        const Space v157_7_tail = child(v155_11_tail,v157_7_label);
        if (v157_7_tail.empty()) continue;
        const Path v157_7_head{v157_7_label};
        const Space v158_2 = singleton(v157_7_head);
        const Space v158_3 = intersect(constant_9,v158_2);
        const Space v158_4 = (has_head(v158_3) ? constant_10 : Space{});
        const Space v158_5 = subtract(constant_0,v158_4);
        Space v158_8;
        if (!v158_5.empty()) {
          const Path v159_6 = concat_path(v157_6,v157_7_head);
          const Space v159_7 = routine_35(c, v159_6, v157_7_tail, s1, s2, s3);
          v158_8 = compose(v158_5,v159_7);
        }
        const Space v158_9 = intersect(constant_9,v158_2);
        const Space v158_10 = (has_head(v158_9) ? constant_10 : Space{});
        Space v158_12;
        if (!v158_10.empty()) {
          const Path v160_6 = concat_path(v157_6,v157_7_head);
          const Space v160_11 = routine_36(c, v160_6, v157_7_tail, s1, s2, s3);
          v158_12 = compose(v158_10,v160_11);
        }
        const Space v158_13 = unite(v158_8,v158_12);
        v157_7_result = unite(v157_7_result,v158_13);
      }
      const Space v157_7 = std::move(v157_7_result);
      v156_8 = compose(v156_5,v157_7);
    }
    const Space v156_9 = intersect(constant_9,v156_2);
    const Space v156_10 = (has_head(v156_9) ? constant_10 : Space{});
    Space v156_27;
    if (!v156_10.empty()) {
      const Path v161_6 = concat_path(p0,v155_11_head);
      const Space v161_11 = singleton(v161_6);
      const Space v161_12 = routine_38(c, s1, s3, v161_11);
      const Space v161_13 = routine_38(c, s2, s3, v161_11);
      const Space v161_14 = intersect(v161_12,v161_13);
      const Space v161_15 = subtract(v161_14,v161_11);
      const Space v161_16 = wrap(v161_15,v161_6);
      const Space v161_17 = subtract(s3,v161_13);
      const Space v161_18 = subtract(v161_17,v161_12);
      const Space v161_19 = routine_39(c, s2, s1, v161_18);
      const Space v161_20 = unite(v161_16,v161_19);
      const Space v161_21 = subtract(v161_12,v161_13);
      const Space v161_22 = routine_39(c, s2, s1, v161_21);
      const Space v161_23 = unite(v161_20,v161_22);
      const Space v161_24 = subtract(v161_13,v161_12);
      const Space v161_25 = routine_39(c, s2, s1, v161_24);
      const Space v161_26 = unite(v161_23,v161_25);
      v156_27 = compose(v156_10,v161_26);
    }
    const Space v156_28 = unite(v156_8,v156_27);
    v155_11_result = unite(v155_11_result,v156_28);
  }
  const Space v155_11 = std::move(v155_11_result);
  return v155_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  const Space v162_2 = Space{};
  return v162_2;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v163_3_result;
  for (int v163_3_label = 1; v163_3_label <= 2; ++v163_3_label) {
    const Space v163_3_tail = child(s0,v163_3_label);
    if (v163_3_tail.empty()) continue;
    const Path v163_3_head{v163_3_label};
    const Space v164_2 = singleton(v163_3_head);
    const Space v164_3 = intersect(constant_9,v164_2);
    const Space v164_4 = (has_head(v164_3) ? constant_10 : Space{});
    const Path v164_5 = concat_path(p0,v163_3_head);
    const Space v164_6 = singleton(v164_5);
    const Space v164_7 = compose(v164_4,v164_6);
    v163_3_result = unite(v163_3_result,v164_7);
  }
  const Space v163_3 = std::move(v163_3_result);
  return v163_3;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  const Space v165_2 = Space{};
  return v165_2;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v166_6_result;
  for (int v166_6_label = 1; v166_6_label <= 2; ++v166_6_label) {
    const Space v166_6_tail = child(s0,v166_6_label);
    if (v166_6_tail.empty()) continue;
    const Path v166_6_head{v166_6_label};
    const Space v167_2 = singleton(v166_6_head);
    const Space v167_3 = intersect(constant_9,v167_2);
    const Space v167_4 = (has_head(v167_3) ? constant_10 : Space{});
    Space v167_7;
    if (!v167_4.empty()) {
      const Path v168_5 = concat_path(p0,v166_6_head);
      Space v168_6_result;
      for (int v168_6_label = 1; v168_6_label <= 2; ++v168_6_label) {
        const Space v168_6_tail = child(v166_6_tail,v168_6_label);
        if (v168_6_tail.empty()) continue;
        const Path v168_6_head{v168_6_label};
        const Space v169_2 = singleton(v168_6_head);
        const Space v169_3 = intersect(constant_9,v169_2);
        const Space v169_4 = (has_head(v169_3) ? constant_10 : Space{});
        const Space v169_5 = subtract(constant_0,v169_4);
        Space v169_7;
        if (!v169_5.empty()) {
          const Space v170_6 = routine_20(c, v168_6_head, v168_5, v168_6_tail);
          v169_7 = compose(v169_5,v170_6);
        }
        const Space v169_8 = intersect(constant_9,v169_2);
        const Space v169_9 = (has_head(v169_8) ? constant_10 : Space{});
        Space v169_11;
        if (!v169_9.empty()) {
          const Space v171_10 = routine_21(c, v168_6_head, v168_5, v168_6_tail);
          v169_11 = compose(v169_9,v171_10);
        }
        const Space v169_12 = unite(v169_7,v169_11);
        v168_6_result = unite(v168_6_result,v169_12);
      }
      const Space v168_6 = std::move(v168_6_result);
      v167_7 = compose(v167_4,v168_6);
    }
    v166_6_result = unite(v166_6_result,v167_7);
  }
  const Space v166_6 = std::move(v166_6_result);
  return v166_6;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v172_12_result;
  for (int v172_12_label = 1; v172_12_label <= 2; ++v172_12_label) {
    const Space v172_12_tail = child(s0,v172_12_label);
    if (v172_12_tail.empty()) continue;
    const Path v172_12_head{v172_12_label};
    const Space v173_2 = singleton(v172_12_head);
    const Space v173_3 = intersect(constant_9,v173_2);
    const Space v173_4 = (has_head(v173_3) ? constant_10 : Space{});
    const Space v173_5 = subtract(constant_0,v173_4);
    Space v173_8;
    if (!v173_5.empty()) {
      const Path v174_6 = concat_path(p0,v172_12_head);
      Space v174_7_result;
      for (int v174_7_label = 1; v174_7_label <= 2; ++v174_7_label) {
        const Space v174_7_tail = child(v172_12_tail,v174_7_label);
        if (v174_7_tail.empty()) continue;
        const Path v174_7_head{v174_7_label};
        const Space v175_2 = singleton(v174_7_head);
        const Space v175_3 = intersect(constant_9,v175_2);
        const Space v175_4 = (has_head(v175_3) ? constant_10 : Space{});
        const Space v175_5 = subtract(constant_0,v175_4);
        Space v175_8;
        if (!v175_5.empty()) {
          const Path v176_6 = concat_path(v174_6,v174_7_head);
          const Space v176_7 = routine_40(c, v176_6, p1, v174_7_tail);
          v175_8 = compose(v175_5,v176_7);
        }
        const Space v175_9 = intersect(constant_9,v175_2);
        const Space v175_10 = (has_head(v175_9) ? constant_10 : Space{});
        Space v175_12;
        if (!v175_10.empty()) {
          const Path v177_6 = concat_path(v174_6,v174_7_head);
          const Space v177_11 = routine_41(c, v177_6, p1, v174_7_tail);
          v175_12 = compose(v175_10,v177_11);
        }
        const Space v175_13 = unite(v175_8,v175_12);
        v174_7_result = unite(v174_7_result,v175_13);
      }
      const Space v174_7 = std::move(v174_7_result);
      v173_8 = compose(v173_5,v174_7);
    }
    const Space v173_9 = intersect(constant_9,v173_2);
    const Space v173_10 = (has_head(v173_9) ? constant_10 : Space{});
    Space v173_12;
    if (!v173_10.empty()) {
      const Path v178_6 = concat_path(p0,v172_12_head);
      Space v178_11_result;
      for (int v178_11_label = 1; v178_11_label <= 2; ++v178_11_label) {
        const Space v178_11_tail = child(v172_12_tail,v178_11_label);
        if (v178_11_tail.empty()) continue;
        const Path v178_11_head{v178_11_label};
        const Space v179_2 = singleton(v178_11_head);
        const Space v179_3 = intersect(constant_9,v179_2);
        const Space v179_4 = (has_head(v179_3) ? constant_10 : Space{});
        const Space v179_5 = subtract(constant_0,v179_4);
        Space v179_8;
        if (!v179_5.empty()) {
          const Path v180_6 = concat_path(v178_6,v178_11_head);
          const Space v180_7 = routine_40(c, v180_6, p1, v178_11_tail);
          v179_8 = compose(v179_5,v180_7);
        }
        const Space v179_9 = intersect(constant_9,v179_2);
        const Space v179_10 = (has_head(v179_9) ? constant_10 : Space{});
        Space v179_12;
        if (!v179_10.empty()) {
          const Path v181_6 = concat_path(v178_6,v178_11_head);
          const Space v181_11 = routine_24(c, v181_6, p1, v178_11_tail);
          v179_12 = compose(v179_10,v181_11);
        }
        const Space v179_13 = unite(v179_8,v179_12);
        v178_11_result = unite(v178_11_result,v179_13);
      }
      const Space v178_11 = std::move(v178_11_result);
      v173_12 = compose(v173_10,v178_11);
    }
    const Space v173_13 = unite(v173_8,v173_12);
    v172_12_result = unite(v172_12_result,v173_13);
  }
  const Space v172_12 = std::move(v172_12_result);
  return v172_12;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v182_9_result;
  for (int v182_9_label = 1; v182_9_label <= 2; ++v182_9_label) {
    const Space v182_9_tail = child(s0,v182_9_label);
    if (v182_9_tail.empty()) continue;
    const Path v182_9_head{v182_9_label};
    const Space v183_2 = singleton(v182_9_head);
    const Space v183_3 = intersect(constant_9,v183_2);
    const Space v183_4 = (has_head(v183_3) ? constant_10 : Space{});
    const Space v183_5 = subtract(constant_0,v183_4);
    Space v183_8;
    if (!v183_5.empty()) {
      const Path v184_6 = concat_path(p0,v182_9_head);
      Space v184_7_result;
      for (int v184_7_label = 1; v184_7_label <= 2; ++v184_7_label) {
        const Space v184_7_tail = child(v182_9_tail,v184_7_label);
        if (v184_7_tail.empty()) continue;
        const Path v184_7_head{v184_7_label};
        const Space v185_2 = singleton(v184_7_head);
        const Space v185_3 = intersect(constant_9,v185_2);
        const Space v185_4 = (has_head(v185_3) ? constant_10 : Space{});
        const Space v185_5 = subtract(constant_0,v185_4);
        Space v185_8;
        if (!v185_5.empty()) {
          const Path v186_6 = concat_path(v184_6,v184_7_head);
          const Space v186_7 = routine_40(c, v186_6, p1, v184_7_tail);
          v185_8 = compose(v185_5,v186_7);
        }
        const Space v185_9 = intersect(constant_9,v185_2);
        const Space v185_10 = (has_head(v185_9) ? constant_10 : Space{});
        Space v185_12;
        if (!v185_10.empty()) {
          const Path v187_6 = concat_path(v184_6,v184_7_head);
          const Space v187_11 = routine_41(c, v187_6, p1, v184_7_tail);
          v185_12 = compose(v185_10,v187_11);
        }
        const Space v185_13 = unite(v185_8,v185_12);
        v184_7_result = unite(v184_7_result,v185_13);
      }
      const Space v184_7 = std::move(v184_7_result);
      v183_8 = compose(v183_5,v184_7);
    }
    const Space v183_9 = intersect(constant_9,v183_2);
    const Space v183_10 = (has_head(v183_9) ? constant_10 : Space{});
    const Path v188_6 = concat_path(p0,v182_9_head);
    const Path v183_11 = concat_path(v188_6,p1);
    const Space v183_12 = singleton(v183_11);
    const Space v183_13 = compose(v183_10,v183_12);
    const Space v183_14 = unite(v183_8,v183_13);
    v182_9_result = unite(v182_9_result,v183_14);
  }
  const Space v182_9 = std::move(v182_9_result);
  return v182_9;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v189_12_result;
  for (int v189_12_label = 1; v189_12_label <= 2; ++v189_12_label) {
    const Space v189_12_tail = child(s0,v189_12_label);
    if (v189_12_tail.empty()) continue;
    const Path v189_12_head{v189_12_label};
    const Space v190_2 = singleton(v189_12_head);
    const Space v190_3 = intersect(constant_9,v190_2);
    const Space v190_4 = (has_head(v190_3) ? constant_10 : Space{});
    const Space v190_5 = subtract(constant_0,v190_4);
    Space v190_8;
    if (!v190_5.empty()) {
      const Path v191_6 = concat_path(p0,v189_12_head);
      Space v191_7_result;
      for (int v191_7_label = 1; v191_7_label <= 2; ++v191_7_label) {
        const Space v191_7_tail = child(v189_12_tail,v191_7_label);
        if (v191_7_tail.empty()) continue;
        const Path v191_7_head{v191_7_label};
        const Space v192_2 = singleton(v191_7_head);
        const Space v192_3 = intersect(constant_9,v192_2);
        const Space v192_4 = (has_head(v192_3) ? constant_10 : Space{});
        const Space v192_5 = subtract(constant_0,v192_4);
        Space v192_8;
        if (!v192_5.empty()) {
          const Path v193_6 = concat_path(v191_6,v191_7_head);
          const Space v193_7 = routine_42(c, v193_6, p1, v191_7_tail);
          v192_8 = compose(v192_5,v193_7);
        }
        const Space v192_9 = intersect(constant_9,v192_2);
        const Space v192_10 = (has_head(v192_9) ? constant_10 : Space{});
        Space v192_12;
        if (!v192_10.empty()) {
          const Path v194_6 = concat_path(v191_6,v191_7_head);
          const Space v194_11 = routine_43(c, v194_6, p1, v191_7_tail);
          v192_12 = compose(v192_10,v194_11);
        }
        const Space v192_13 = unite(v192_8,v192_12);
        v191_7_result = unite(v191_7_result,v192_13);
      }
      const Space v191_7 = std::move(v191_7_result);
      v190_8 = compose(v190_5,v191_7);
    }
    const Space v190_9 = intersect(constant_9,v190_2);
    const Space v190_10 = (has_head(v190_9) ? constant_10 : Space{});
    Space v190_12;
    if (!v190_10.empty()) {
      const Path v195_6 = concat_path(p0,v189_12_head);
      Space v195_11_result;
      for (int v195_11_label = 1; v195_11_label <= 2; ++v195_11_label) {
        const Space v195_11_tail = child(v189_12_tail,v195_11_label);
        if (v195_11_tail.empty()) continue;
        const Path v195_11_head{v195_11_label};
        const Space v196_2 = singleton(v195_11_head);
        const Space v196_3 = intersect(constant_9,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_10 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v195_6,v195_11_head);
          const Space v197_7 = routine_42(c, v197_6, p1, v195_11_tail);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_9,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_10 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v195_6,v195_11_head);
          const Space v198_11 = routine_24(c, v198_6, p1, v195_11_tail);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_11_result = unite(v195_11_result,v196_13);
      }
      const Space v195_11 = std::move(v195_11_result);
      v190_12 = compose(v190_10,v195_11);
    }
    const Space v190_13 = unite(v190_8,v190_12);
    v189_12_result = unite(v189_12_result,v190_13);
  }
  const Space v189_12 = std::move(v189_12_result);
  return v189_12;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v199_9_result;
  for (int v199_9_label = 1; v199_9_label <= 2; ++v199_9_label) {
    const Space v199_9_tail = child(s0,v199_9_label);
    if (v199_9_tail.empty()) continue;
    const Path v199_9_head{v199_9_label};
    const Space v200_2 = singleton(v199_9_head);
    const Space v200_3 = intersect(constant_9,v200_2);
    const Space v200_4 = (has_head(v200_3) ? constant_10 : Space{});
    const Space v200_5 = subtract(constant_0,v200_4);
    Space v200_8;
    if (!v200_5.empty()) {
      const Path v201_6 = concat_path(p0,v199_9_head);
      Space v201_7_result;
      for (int v201_7_label = 1; v201_7_label <= 2; ++v201_7_label) {
        const Space v201_7_tail = child(v199_9_tail,v201_7_label);
        if (v201_7_tail.empty()) continue;
        const Path v201_7_head{v201_7_label};
        const Space v202_2 = singleton(v201_7_head);
        const Space v202_3 = intersect(constant_9,v202_2);
        const Space v202_4 = (has_head(v202_3) ? constant_10 : Space{});
        const Space v202_5 = subtract(constant_0,v202_4);
        Space v202_8;
        if (!v202_5.empty()) {
          const Path v203_6 = concat_path(v201_6,v201_7_head);
          const Space v203_7 = routine_42(c, v203_6, p1, v201_7_tail);
          v202_8 = compose(v202_5,v203_7);
        }
        const Space v202_9 = intersect(constant_9,v202_2);
        const Space v202_10 = (has_head(v202_9) ? constant_10 : Space{});
        Space v202_12;
        if (!v202_10.empty()) {
          const Path v204_6 = concat_path(v201_6,v201_7_head);
          const Space v204_11 = routine_43(c, v204_6, p1, v201_7_tail);
          v202_12 = compose(v202_10,v204_11);
        }
        const Space v202_13 = unite(v202_8,v202_12);
        v201_7_result = unite(v201_7_result,v202_13);
      }
      const Space v201_7 = std::move(v201_7_result);
      v200_8 = compose(v200_5,v201_7);
    }
    const Space v200_9 = intersect(constant_9,v200_2);
    const Space v200_10 = (has_head(v200_9) ? constant_10 : Space{});
    const Path v205_6 = concat_path(p0,v199_9_head);
    const Path v200_11 = concat_path(v205_6,p1);
    const Space v200_12 = singleton(v200_11);
    const Space v200_13 = compose(v200_10,v200_12);
    const Space v200_14 = unite(v200_8,v200_13);
    v199_9_result = unite(v199_9_result,v200_14);
  }
  const Space v199_9 = std::move(v199_9_result);
  return v199_9;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v206_3 = concat_path(p0,p1);
  const Space v206_4 = singleton(v206_3);
  return v206_4;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  const Space v207_2 = Space{};
  return v207_2;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v208_3_result;
  for (int v208_3_label = 1; v208_3_label <= 2; ++v208_3_label) {
    const Space v208_3_tail = child(s0,v208_3_label);
    if (v208_3_tail.empty()) continue;
    const Path v208_3_head{v208_3_label};
    const Space v209_2 = singleton(v208_3_head);
    const Space v209_3 = intersect(constant_9,v209_2);
    const Space v209_4 = (has_head(v209_3) ? constant_10 : Space{});
    const Path v209_5 = concat_path(p0,v208_3_head);
    const Space v209_6 = singleton(v209_5);
    const Space v209_7 = compose(v209_4,v209_6);
    v208_3_result = unite(v208_3_result,v209_7);
  }
  const Space v208_3 = std::move(v208_3_result);
  return v208_3;
}

static Space routine_27(Context& c, const Space& s0) {
  const Space v210_2 = first_matching(s0,constant_0,false);
  const Space v210_3 = intersect(constant_0,v210_2);
  const Space v210_4 = (has_head(v210_2) ? constant_10 : Space{});
  const Space v210_5 = unite(v210_3,v210_4);
  const Space v210_7 = compose(v210_5,constant_0);
  const Space v210_9 = subtract(constant_0,v210_2);
  const Space v210_10 = subtract(v210_9,v210_4);
  Space v210_18;
  if (!v210_10.empty()) {
    const Space v211_11 = first_fibonacci(s0,6,5,true);
    const Space v211_12 = first_matching(v211_11,constant_0,false);
    Space v211_15;
    if (!v211_12.empty()) {
      const Space v212_14 = routine_44(c, constant_12, s0);
      v211_15 = compose(v211_12,v212_14);
    }
    Space v211_16_result;
    for (int v211_16_label = 1; v211_16_label <= 2; ++v211_16_label) {
      const Space v211_16_tail = child(v211_11,v211_16_label);
      if (v211_16_tail.empty()) continue;
      const Path v211_16_head{v211_16_label};
      const Space v213_2 = routine_45(c, v211_16_head, v211_16_tail, s0);
      v211_16_result = unite(v211_16_result,v213_2);
    }
    const Space v211_16 = std::move(v211_16_result);
    const Space v211_17 = unite(v211_15,v211_16);
    v210_18 = compose(v210_10,v211_17);
  }
  const Space v210_19 = unite(v210_7,v210_18);
  return v210_19;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  const Space v214_2 = Space{};
  return v214_2;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v215_6_result;
  for (int v215_6_label = 1; v215_6_label <= 2; ++v215_6_label) {
    const Space v215_6_tail = child(s0,v215_6_label);
    if (v215_6_tail.empty()) continue;
    const Path v215_6_head{v215_6_label};
    const Space v216_2 = singleton(v215_6_head);
    const Space v216_3 = intersect(constant_9,v216_2);
    const Space v216_4 = (has_head(v216_3) ? constant_10 : Space{});
    Space v216_7;
    if (!v216_4.empty()) {
      const Path v217_5 = concat_path(p0,v215_6_head);
      Space v217_6_result;
      for (int v217_6_label = 1; v217_6_label <= 2; ++v217_6_label) {
        const Space v217_6_tail = child(v215_6_tail,v217_6_label);
        if (v217_6_tail.empty()) continue;
        const Path v217_6_head{v217_6_label};
        const Space v218_2 = singleton(v217_6_head);
        const Space v218_3 = intersect(constant_9,v218_2);
        const Space v218_4 = (has_head(v218_3) ? constant_10 : Space{});
        const Space v218_5 = subtract(constant_0,v218_4);
        Space v218_7;
        if (!v218_5.empty()) {
          const Space v219_6 = routine_30(c, v217_6_head, v217_5, v217_6_tail);
          v218_7 = compose(v218_5,v219_6);
        }
        const Space v218_8 = intersect(constant_9,v218_2);
        const Space v218_9 = (has_head(v218_8) ? constant_10 : Space{});
        Space v218_11;
        if (!v218_9.empty()) {
          const Space v220_10 = routine_31(c, v217_6_head, v217_5, v217_6_tail);
          v218_11 = compose(v218_9,v220_10);
        }
        const Space v218_12 = unite(v218_7,v218_11);
        v217_6_result = unite(v217_6_result,v218_12);
      }
      const Space v217_6 = std::move(v217_6_result);
      v216_7 = compose(v216_4,v217_6);
    }
    v215_6_result = unite(v215_6_result,v216_7);
  }
  const Space v215_6 = std::move(v215_6_result);
  return v215_6;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v221_12_result;
  for (int v221_12_label = 1; v221_12_label <= 2; ++v221_12_label) {
    const Space v221_12_tail = child(s0,v221_12_label);
    if (v221_12_tail.empty()) continue;
    const Path v221_12_head{v221_12_label};
    const Space v222_2 = singleton(v221_12_head);
    const Space v222_3 = intersect(constant_9,v222_2);
    const Space v222_4 = (has_head(v222_3) ? constant_10 : Space{});
    const Space v222_5 = subtract(constant_0,v222_4);
    Space v222_8;
    if (!v222_5.empty()) {
      const Path v223_6 = concat_path(p0,v221_12_head);
      Space v223_7_result;
      for (int v223_7_label = 1; v223_7_label <= 2; ++v223_7_label) {
        const Space v223_7_tail = child(v221_12_tail,v223_7_label);
        if (v223_7_tail.empty()) continue;
        const Path v223_7_head{v223_7_label};
        const Space v224_2 = singleton(v223_7_head);
        const Space v224_3 = intersect(constant_9,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_10 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_7_head);
          const Space v225_7 = routine_46(c, v225_6, p1, v223_7_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_9,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_10 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_7_head);
          const Space v226_11 = routine_47(c, v226_6, p1, v223_7_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_7_result = unite(v223_7_result,v224_13);
      }
      const Space v223_7 = std::move(v223_7_result);
      v222_8 = compose(v222_5,v223_7);
    }
    const Space v222_9 = intersect(constant_9,v222_2);
    const Space v222_10 = (has_head(v222_9) ? constant_10 : Space{});
    Space v222_12;
    if (!v222_10.empty()) {
      const Path v227_6 = concat_path(p0,v221_12_head);
      Space v227_11_result;
      for (int v227_11_label = 1; v227_11_label <= 2; ++v227_11_label) {
        const Space v227_11_tail = child(v221_12_tail,v227_11_label);
        if (v227_11_tail.empty()) continue;
        const Path v227_11_head{v227_11_label};
        const Space v228_2 = singleton(v227_11_head);
        const Space v228_3 = intersect(constant_9,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_10 : Space{});
        const Space v228_5 = subtract(constant_0,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_11_head);
          const Space v229_7 = routine_46(c, v229_6, p1, v227_11_tail);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_9,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_10 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_11_head);
          const Space v230_11 = routine_34(c, v230_6, p1, v227_11_tail);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_11_result = unite(v227_11_result,v228_13);
      }
      const Space v227_11 = std::move(v227_11_result);
      v222_12 = compose(v222_10,v227_11);
    }
    const Space v222_13 = unite(v222_8,v222_12);
    v221_12_result = unite(v221_12_result,v222_13);
  }
  const Space v221_12 = std::move(v221_12_result);
  return v221_12;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v231_9_result;
  for (int v231_9_label = 1; v231_9_label <= 2; ++v231_9_label) {
    const Space v231_9_tail = child(s0,v231_9_label);
    if (v231_9_tail.empty()) continue;
    const Path v231_9_head{v231_9_label};
    const Space v232_2 = singleton(v231_9_head);
    const Space v232_3 = intersect(constant_9,v232_2);
    const Space v232_4 = (has_head(v232_3) ? constant_10 : Space{});
    const Space v232_5 = subtract(constant_0,v232_4);
    Space v232_8;
    if (!v232_5.empty()) {
      const Path v233_6 = concat_path(p0,v231_9_head);
      Space v233_7_result;
      for (int v233_7_label = 1; v233_7_label <= 2; ++v233_7_label) {
        const Space v233_7_tail = child(v231_9_tail,v233_7_label);
        if (v233_7_tail.empty()) continue;
        const Path v233_7_head{v233_7_label};
        const Space v234_2 = singleton(v233_7_head);
        const Space v234_3 = intersect(constant_9,v234_2);
        const Space v234_4 = (has_head(v234_3) ? constant_10 : Space{});
        const Space v234_5 = subtract(constant_0,v234_4);
        Space v234_8;
        if (!v234_5.empty()) {
          const Path v235_6 = concat_path(v233_6,v233_7_head);
          const Space v235_7 = routine_46(c, v235_6, p1, v233_7_tail);
          v234_8 = compose(v234_5,v235_7);
        }
        const Space v234_9 = intersect(constant_9,v234_2);
        const Space v234_10 = (has_head(v234_9) ? constant_10 : Space{});
        Space v234_12;
        if (!v234_10.empty()) {
          const Path v236_6 = concat_path(v233_6,v233_7_head);
          const Space v236_11 = routine_47(c, v236_6, p1, v233_7_tail);
          v234_12 = compose(v234_10,v236_11);
        }
        const Space v234_13 = unite(v234_8,v234_12);
        v233_7_result = unite(v233_7_result,v234_13);
      }
      const Space v233_7 = std::move(v233_7_result);
      v232_8 = compose(v232_5,v233_7);
    }
    const Space v232_9 = intersect(constant_9,v232_2);
    const Space v232_10 = (has_head(v232_9) ? constant_10 : Space{});
    const Path v237_6 = concat_path(p0,v231_9_head);
    const Path v232_11 = concat_path(v237_6,p1);
    const Space v232_12 = singleton(v232_11);
    const Space v232_13 = compose(v232_10,v232_12);
    const Space v232_14 = unite(v232_8,v232_13);
    v231_9_result = unite(v231_9_result,v232_14);
  }
  const Space v231_9 = std::move(v231_9_result);
  return v231_9;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v238_12_result;
  for (int v238_12_label = 1; v238_12_label <= 2; ++v238_12_label) {
    const Space v238_12_tail = child(s0,v238_12_label);
    if (v238_12_tail.empty()) continue;
    const Path v238_12_head{v238_12_label};
    const Space v239_2 = singleton(v238_12_head);
    const Space v239_3 = intersect(constant_9,v239_2);
    const Space v239_4 = (has_head(v239_3) ? constant_10 : Space{});
    const Space v239_5 = subtract(constant_0,v239_4);
    Space v239_8;
    if (!v239_5.empty()) {
      const Path v240_6 = concat_path(p0,v238_12_head);
      Space v240_7_result;
      for (int v240_7_label = 1; v240_7_label <= 2; ++v240_7_label) {
        const Space v240_7_tail = child(v238_12_tail,v240_7_label);
        if (v240_7_tail.empty()) continue;
        const Path v240_7_head{v240_7_label};
        const Space v241_2 = singleton(v240_7_head);
        const Space v241_3 = intersect(constant_9,v241_2);
        const Space v241_4 = (has_head(v241_3) ? constant_10 : Space{});
        const Space v241_5 = subtract(constant_0,v241_4);
        Space v241_8;
        if (!v241_5.empty()) {
          const Path v242_6 = concat_path(v240_6,v240_7_head);
          const Space v242_7 = routine_48(c, v242_6, p1, v240_7_tail);
          v241_8 = compose(v241_5,v242_7);
        }
        const Space v241_9 = intersect(constant_9,v241_2);
        const Space v241_10 = (has_head(v241_9) ? constant_10 : Space{});
        Space v241_12;
        if (!v241_10.empty()) {
          const Path v243_6 = concat_path(v240_6,v240_7_head);
          const Space v243_11 = routine_49(c, v243_6, p1, v240_7_tail);
          v241_12 = compose(v241_10,v243_11);
        }
        const Space v241_13 = unite(v241_8,v241_12);
        v240_7_result = unite(v240_7_result,v241_13);
      }
      const Space v240_7 = std::move(v240_7_result);
      v239_8 = compose(v239_5,v240_7);
    }
    const Space v239_9 = intersect(constant_9,v239_2);
    const Space v239_10 = (has_head(v239_9) ? constant_10 : Space{});
    Space v239_12;
    if (!v239_10.empty()) {
      const Path v244_6 = concat_path(p0,v238_12_head);
      Space v244_11_result;
      for (int v244_11_label = 1; v244_11_label <= 2; ++v244_11_label) {
        const Space v244_11_tail = child(v238_12_tail,v244_11_label);
        if (v244_11_tail.empty()) continue;
        const Path v244_11_head{v244_11_label};
        const Space v245_2 = singleton(v244_11_head);
        const Space v245_3 = intersect(constant_9,v245_2);
        const Space v245_4 = (has_head(v245_3) ? constant_10 : Space{});
        const Space v245_5 = subtract(constant_0,v245_4);
        Space v245_8;
        if (!v245_5.empty()) {
          const Path v246_6 = concat_path(v244_6,v244_11_head);
          const Space v246_7 = routine_48(c, v246_6, p1, v244_11_tail);
          v245_8 = compose(v245_5,v246_7);
        }
        const Space v245_9 = intersect(constant_9,v245_2);
        const Space v245_10 = (has_head(v245_9) ? constant_10 : Space{});
        Space v245_12;
        if (!v245_10.empty()) {
          const Path v247_6 = concat_path(v244_6,v244_11_head);
          const Space v247_11 = routine_34(c, v247_6, p1, v244_11_tail);
          v245_12 = compose(v245_10,v247_11);
        }
        const Space v245_13 = unite(v245_8,v245_12);
        v244_11_result = unite(v244_11_result,v245_13);
      }
      const Space v244_11 = std::move(v244_11_result);
      v239_12 = compose(v239_10,v244_11);
    }
    const Space v239_13 = unite(v239_8,v239_12);
    v238_12_result = unite(v238_12_result,v239_13);
  }
  const Space v238_12 = std::move(v238_12_result);
  return v238_12;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v248_9_result;
  for (int v248_9_label = 1; v248_9_label <= 2; ++v248_9_label) {
    const Space v248_9_tail = child(s0,v248_9_label);
    if (v248_9_tail.empty()) continue;
    const Path v248_9_head{v248_9_label};
    const Space v249_2 = singleton(v248_9_head);
    const Space v249_3 = intersect(constant_9,v249_2);
    const Space v249_4 = (has_head(v249_3) ? constant_10 : Space{});
    const Space v249_5 = subtract(constant_0,v249_4);
    Space v249_8;
    if (!v249_5.empty()) {
      const Path v250_6 = concat_path(p0,v248_9_head);
      Space v250_7_result;
      for (int v250_7_label = 1; v250_7_label <= 2; ++v250_7_label) {
        const Space v250_7_tail = child(v248_9_tail,v250_7_label);
        if (v250_7_tail.empty()) continue;
        const Path v250_7_head{v250_7_label};
        const Space v251_2 = singleton(v250_7_head);
        const Space v251_3 = intersect(constant_9,v251_2);
        const Space v251_4 = (has_head(v251_3) ? constant_10 : Space{});
        const Space v251_5 = subtract(constant_0,v251_4);
        Space v251_8;
        if (!v251_5.empty()) {
          const Path v252_6 = concat_path(v250_6,v250_7_head);
          const Space v252_7 = routine_48(c, v252_6, p1, v250_7_tail);
          v251_8 = compose(v251_5,v252_7);
        }
        const Space v251_9 = intersect(constant_9,v251_2);
        const Space v251_10 = (has_head(v251_9) ? constant_10 : Space{});
        Space v251_12;
        if (!v251_10.empty()) {
          const Path v253_6 = concat_path(v250_6,v250_7_head);
          const Space v253_11 = routine_49(c, v253_6, p1, v250_7_tail);
          v251_12 = compose(v251_10,v253_11);
        }
        const Space v251_13 = unite(v251_8,v251_12);
        v250_7_result = unite(v250_7_result,v251_13);
      }
      const Space v250_7 = std::move(v250_7_result);
      v249_8 = compose(v249_5,v250_7);
    }
    const Space v249_9 = intersect(constant_9,v249_2);
    const Space v249_10 = (has_head(v249_9) ? constant_10 : Space{});
    const Path v254_6 = concat_path(p0,v248_9_head);
    const Path v249_11 = concat_path(v254_6,p1);
    const Space v249_12 = singleton(v249_11);
    const Space v249_13 = compose(v249_10,v249_12);
    const Space v249_14 = unite(v249_8,v249_13);
    v248_9_result = unite(v248_9_result,v249_14);
  }
  const Space v248_9 = std::move(v248_9_result);
  return v248_9;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v255_3 = concat_path(p0,p1);
  const Space v255_4 = singleton(v255_3);
  return v255_4;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v256_7_result;
  for (int v256_7_label = 1; v256_7_label <= 2; ++v256_7_label) {
    const Space v256_7_tail = child(s0,v256_7_label);
    if (v256_7_tail.empty()) continue;
    const Path v256_7_head{v256_7_label};
    const Space v257_2 = singleton(v256_7_head);
    const Space v257_3 = intersect(constant_9,v257_2);
    const Space v257_4 = (has_head(v257_3) ? constant_10 : Space{});
    Space v257_7;
    if (!v257_4.empty()) {
      const Path v258_5 = concat_path(p0,v256_7_head);
      Space v258_6_result;
      for (int v258_6_label = 1; v258_6_label <= 2; ++v258_6_label) {
        const Space v258_6_tail = child(v256_7_tail,v258_6_label);
        if (v258_6_tail.empty()) continue;
        const Path v258_6_head{v258_6_label};
        const Space v259_2 = singleton(v258_6_head);
        const Space v259_3 = intersect(constant_9,v259_2);
        const Space v259_4 = (has_head(v259_3) ? constant_10 : Space{});
        Space v259_7;
        if (!v259_4.empty()) {
          const Path v260_5 = concat_path(v258_5,v258_6_head);
          const Space v260_6 = routine_37(c, v260_5, v258_6_tail, s1, s2, s3);
          v259_7 = compose(v259_4,v260_6);
        }
        v258_6_result = unite(v258_6_result,v259_7);
      }
      const Space v258_6 = std::move(v258_6_result);
      v257_7 = compose(v257_4,v258_6);
    }
    v256_7_result = unite(v256_7_result,v257_7);
  }
  const Space v256_7 = std::move(v256_7_result);
  return v256_7;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v261_6_result;
  for (int v261_6_label = 1; v261_6_label <= 2; ++v261_6_label) {
    const Space v261_6_tail = child(s0,v261_6_label);
    if (v261_6_tail.empty()) continue;
    const Path v261_6_head{v261_6_label};
    const Space v262_2 = singleton(v261_6_head);
    const Space v262_3 = intersect(constant_9,v262_2);
    const Space v262_4 = (has_head(v262_3) ? constant_10 : Space{});
    Space v262_22;
    if (!v262_4.empty()) {
      const Path v263_5 = concat_path(p0,v261_6_head);
      const Space v263_6 = singleton(v263_5);
      const Space v263_7 = routine_38(c, s1, s3, v263_6);
      const Space v263_8 = routine_38(c, s2, s3, v263_6);
      const Space v263_9 = intersect(v263_7,v263_8);
      const Space v263_10 = subtract(v263_9,v263_6);
      const Space v263_11 = wrap(v263_10,v263_5);
      const Space v263_12 = subtract(s3,v263_8);
      const Space v263_13 = subtract(v263_12,v263_7);
      const Space v263_14 = routine_39(c, s2, s1, v263_13);
      const Space v263_15 = unite(v263_11,v263_14);
      const Space v263_16 = subtract(v263_7,v263_8);
      const Space v263_17 = routine_39(c, s2, s1, v263_16);
      const Space v263_18 = unite(v263_15,v263_17);
      const Space v263_19 = subtract(v263_8,v263_7);
      const Space v263_20 = routine_39(c, s2, s1, v263_19);
      const Space v263_21 = unite(v263_18,v263_20);
      v262_22 = compose(v262_4,v263_21);
    }
    v261_6_result = unite(v261_6_result,v262_22);
  }
  const Space v261_6 = std::move(v261_6_result);
  return v261_6;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  const Space v264_5 = singleton(p0);
  Space v264_15 = v264_5;
  for (;;) {
    const Space v265_1 = intersect(v264_15,s3);
    const Space v265_2 = restrict_to(s1,v265_1);
    Space v265_3_result;
    for (int v265_3_label = 1; v265_3_label <= 2; ++v265_3_label) {
      const Space v265_3_tail = child(v265_2,v265_3_label);
      if (v265_3_tail.empty()) continue;
      const Path v265_3_head{v265_3_label};
      const Space v266_2 = singleton(v265_3_head);
      const Space v266_3 = intersect(constant_9,v266_2);
      const Space v266_4 = (has_head(v266_3) ? constant_10 : Space{});
      const Space v266_5 = subtract(constant_0,v266_4);
      Space v266_7;
      if (!v266_5.empty()) {
        Space v267_6_result;
        for (int v267_6_label = 1; v267_6_label <= 2; ++v267_6_label) {
          const Space v267_6_tail = child(v265_3_tail,v267_6_label);
          if (v267_6_tail.empty()) continue;
          const Path v267_6_head{v267_6_label};
          const Space v268_2 = singleton(v267_6_head);
          const Space v268_3 = intersect(constant_9,v268_2);
          const Space v268_4 = (has_head(v268_3) ? constant_10 : Space{});
          const Space v268_5 = subtract(constant_0,v268_4);
          Space v268_8;
          if (!v268_5.empty()) {
            const Path v269_6 = concat_path(v265_3_head,v267_6_head);
            const Space v269_7 = routine_50(c, v269_6, v267_6_tail);
            v268_8 = compose(v268_5,v269_7);
          }
          const Space v268_9 = intersect(constant_9,v268_2);
          const Space v268_10 = (has_head(v268_9) ? constant_10 : Space{});
          Space v268_12;
          if (!v268_10.empty()) {
            const Path v270_6 = concat_path(v265_3_head,v267_6_head);
            const Space v270_11 = routine_51(c, v270_6, v267_6_tail);
            v268_12 = compose(v268_10,v270_11);
          }
          const Space v268_13 = unite(v268_8,v268_12);
          v267_6_result = unite(v267_6_result,v268_13);
        }
        const Space v267_6 = std::move(v267_6_result);
        v266_7 = compose(v266_5,v267_6);
      }
      const Space v266_8 = intersect(constant_9,v266_2);
      const Space v266_9 = (has_head(v266_8) ? constant_10 : Space{});
      Space v266_11;
      if (!v266_9.empty()) {
        Space v271_10_result;
        for (int v271_10_label = 1; v271_10_label <= 2; ++v271_10_label) {
          const Space v271_10_tail = child(v265_3_tail,v271_10_label);
          if (v271_10_tail.empty()) continue;
          const Path v271_10_head{v271_10_label};
          const Space v272_2 = singleton(v271_10_head);
          const Space v272_3 = intersect(constant_9,v272_2);
          const Space v272_4 = (has_head(v272_3) ? constant_10 : Space{});
          const Space v272_5 = subtract(constant_0,v272_4);
          Space v272_8;
          if (!v272_5.empty()) {
            const Path v273_6 = concat_path(v265_3_head,v271_10_head);
            const Space v273_7 = routine_50(c, v273_6, v271_10_tail);
            v272_8 = compose(v272_5,v273_7);
          }
          const Space v272_9 = intersect(constant_9,v272_2);
          const Space v272_10 = (has_head(v272_9) ? constant_10 : Space{});
          Space v272_12;
          if (!v272_10.empty()) {
            const Path v274_6 = concat_path(v265_3_head,v271_10_head);
            const Space v274_11 = routine_52(c, v274_6, v271_10_tail);
            v272_12 = compose(v272_10,v274_11);
          }
          const Space v272_13 = unite(v272_8,v272_12);
          v271_10_result = unite(v271_10_result,v272_13);
        }
        const Space v271_10 = std::move(v271_10_result);
        v266_11 = compose(v266_9,v271_10);
      }
      const Space v266_12 = unite(v266_7,v266_11);
      v265_3_result = unite(v265_3_result,v266_12);
    }
    const Space v265_3 = std::move(v265_3_result);
    const Space v265_4 = unite(v265_3,v264_15);
    const Space v265_5 = intersect(v265_4,s3);
    Space v264_15_next = unite(v264_15,v265_5);
    if (equal(v264_15_next,v264_15)) break;
    v264_15 = std::move(v264_15_next);
  }
  Space v264_25 = v264_5;
  for (;;) {
    const Space v275_1 = intersect(v264_25,s3);
    const Space v275_2 = restrict_to(s2,v275_1);
    Space v275_3_result;
    for (int v275_3_label = 1; v275_3_label <= 2; ++v275_3_label) {
      const Space v275_3_tail = child(v275_2,v275_3_label);
      if (v275_3_tail.empty()) continue;
      const Path v275_3_head{v275_3_label};
      const Space v276_2 = singleton(v275_3_head);
      const Space v276_3 = intersect(constant_9,v276_2);
      const Space v276_4 = (has_head(v276_3) ? constant_10 : Space{});
      const Space v276_5 = subtract(constant_0,v276_4);
      Space v276_7;
      if (!v276_5.empty()) {
        Space v277_6_result;
        for (int v277_6_label = 1; v277_6_label <= 2; ++v277_6_label) {
          const Space v277_6_tail = child(v275_3_tail,v277_6_label);
          if (v277_6_tail.empty()) continue;
          const Path v277_6_head{v277_6_label};
          const Space v278_2 = singleton(v277_6_head);
          const Space v278_3 = intersect(constant_9,v278_2);
          const Space v278_4 = (has_head(v278_3) ? constant_10 : Space{});
          const Space v278_5 = subtract(constant_0,v278_4);
          Space v278_8;
          if (!v278_5.empty()) {
            const Path v279_6 = concat_path(v275_3_head,v277_6_head);
            const Space v279_7 = routine_50(c, v279_6, v277_6_tail);
            v278_8 = compose(v278_5,v279_7);
          }
          const Space v278_9 = intersect(constant_9,v278_2);
          const Space v278_10 = (has_head(v278_9) ? constant_10 : Space{});
          Space v278_12;
          if (!v278_10.empty()) {
            const Path v280_6 = concat_path(v275_3_head,v277_6_head);
            const Space v280_11 = routine_51(c, v280_6, v277_6_tail);
            v278_12 = compose(v278_10,v280_11);
          }
          const Space v278_13 = unite(v278_8,v278_12);
          v277_6_result = unite(v277_6_result,v278_13);
        }
        const Space v277_6 = std::move(v277_6_result);
        v276_7 = compose(v276_5,v277_6);
      }
      const Space v276_8 = intersect(constant_9,v276_2);
      const Space v276_9 = (has_head(v276_8) ? constant_10 : Space{});
      Space v276_11;
      if (!v276_9.empty()) {
        Space v281_10_result;
        for (int v281_10_label = 1; v281_10_label <= 2; ++v281_10_label) {
          const Space v281_10_tail = child(v275_3_tail,v281_10_label);
          if (v281_10_tail.empty()) continue;
          const Path v281_10_head{v281_10_label};
          const Space v282_2 = singleton(v281_10_head);
          const Space v282_3 = intersect(constant_9,v282_2);
          const Space v282_4 = (has_head(v282_3) ? constant_10 : Space{});
          const Space v282_5 = subtract(constant_0,v282_4);
          Space v282_8;
          if (!v282_5.empty()) {
            const Path v283_6 = concat_path(v275_3_head,v281_10_head);
            const Space v283_7 = routine_50(c, v283_6, v281_10_tail);
            v282_8 = compose(v282_5,v283_7);
          }
          const Space v282_9 = intersect(constant_9,v282_2);
          const Space v282_10 = (has_head(v282_9) ? constant_10 : Space{});
          Space v282_12;
          if (!v282_10.empty()) {
            const Path v284_6 = concat_path(v275_3_head,v281_10_head);
            const Space v284_11 = routine_52(c, v284_6, v281_10_tail);
            v282_12 = compose(v282_10,v284_11);
          }
          const Space v282_13 = unite(v282_8,v282_12);
          v281_10_result = unite(v281_10_result,v282_13);
        }
        const Space v281_10 = std::move(v281_10_result);
        v276_11 = compose(v276_9,v281_10);
      }
      const Space v276_12 = unite(v276_7,v276_11);
      v275_3_result = unite(v275_3_result,v276_12);
    }
    const Space v275_3 = std::move(v275_3_result);
    const Space v275_4 = unite(v275_3,v264_25);
    const Space v275_5 = intersect(v275_4,s3);
    Space v264_25_next = unite(v264_25,v275_5);
    if (equal(v264_25_next,v264_25)) break;
    v264_25 = std::move(v264_25_next);
  }
  const Space v264_26 = intersect(v264_15,v264_25);
  const Space v264_27 = subtract(v264_26,v264_5);
  const Space v264_28 = wrap(v264_27,p0);
  Space v264_38 = v264_5;
  for (;;) {
    const Space v285_1 = intersect(v264_38,s3);
    const Space v285_2 = restrict_to(s2,v285_1);
    Space v285_3_result;
    for (int v285_3_label = 1; v285_3_label <= 2; ++v285_3_label) {
      const Space v285_3_tail = child(v285_2,v285_3_label);
      if (v285_3_tail.empty()) continue;
      const Path v285_3_head{v285_3_label};
      const Space v286_2 = singleton(v285_3_head);
      const Space v286_3 = intersect(constant_9,v286_2);
      const Space v286_4 = (has_head(v286_3) ? constant_10 : Space{});
      const Space v286_5 = subtract(constant_0,v286_4);
      Space v286_7;
      if (!v286_5.empty()) {
        Space v287_6_result;
        for (int v287_6_label = 1; v287_6_label <= 2; ++v287_6_label) {
          const Space v287_6_tail = child(v285_3_tail,v287_6_label);
          if (v287_6_tail.empty()) continue;
          const Path v287_6_head{v287_6_label};
          const Space v288_2 = singleton(v287_6_head);
          const Space v288_3 = intersect(constant_9,v288_2);
          const Space v288_4 = (has_head(v288_3) ? constant_10 : Space{});
          const Space v288_5 = subtract(constant_0,v288_4);
          Space v288_8;
          if (!v288_5.empty()) {
            const Path v289_6 = concat_path(v285_3_head,v287_6_head);
            const Space v289_7 = routine_50(c, v289_6, v287_6_tail);
            v288_8 = compose(v288_5,v289_7);
          }
          const Space v288_9 = intersect(constant_9,v288_2);
          const Space v288_10 = (has_head(v288_9) ? constant_10 : Space{});
          Space v288_12;
          if (!v288_10.empty()) {
            const Path v290_6 = concat_path(v285_3_head,v287_6_head);
            const Space v290_11 = routine_51(c, v290_6, v287_6_tail);
            v288_12 = compose(v288_10,v290_11);
          }
          const Space v288_13 = unite(v288_8,v288_12);
          v287_6_result = unite(v287_6_result,v288_13);
        }
        const Space v287_6 = std::move(v287_6_result);
        v286_7 = compose(v286_5,v287_6);
      }
      const Space v286_8 = intersect(constant_9,v286_2);
      const Space v286_9 = (has_head(v286_8) ? constant_10 : Space{});
      Space v286_11;
      if (!v286_9.empty()) {
        Space v291_10_result;
        for (int v291_10_label = 1; v291_10_label <= 2; ++v291_10_label) {
          const Space v291_10_tail = child(v285_3_tail,v291_10_label);
          if (v291_10_tail.empty()) continue;
          const Path v291_10_head{v291_10_label};
          const Space v292_2 = singleton(v291_10_head);
          const Space v292_3 = intersect(constant_9,v292_2);
          const Space v292_4 = (has_head(v292_3) ? constant_10 : Space{});
          const Space v292_5 = subtract(constant_0,v292_4);
          Space v292_8;
          if (!v292_5.empty()) {
            const Path v293_6 = concat_path(v285_3_head,v291_10_head);
            const Space v293_7 = routine_50(c, v293_6, v291_10_tail);
            v292_8 = compose(v292_5,v293_7);
          }
          const Space v292_9 = intersect(constant_9,v292_2);
          const Space v292_10 = (has_head(v292_9) ? constant_10 : Space{});
          Space v292_12;
          if (!v292_10.empty()) {
            const Path v294_6 = concat_path(v285_3_head,v291_10_head);
            const Space v294_11 = routine_52(c, v294_6, v291_10_tail);
            v292_12 = compose(v292_10,v294_11);
          }
          const Space v292_13 = unite(v292_8,v292_12);
          v291_10_result = unite(v291_10_result,v292_13);
        }
        const Space v291_10 = std::move(v291_10_result);
        v286_11 = compose(v286_9,v291_10);
      }
      const Space v286_12 = unite(v286_7,v286_11);
      v285_3_result = unite(v285_3_result,v286_12);
    }
    const Space v285_3 = std::move(v285_3_result);
    const Space v285_4 = unite(v285_3,v264_38);
    const Space v285_5 = intersect(v285_4,s3);
    Space v264_38_next = unite(v264_38,v285_5);
    if (equal(v264_38_next,v264_38)) break;
    v264_38 = std::move(v264_38_next);
  }
  const Space v264_39 = subtract(s3,v264_38);
  Space v264_49 = v264_5;
  for (;;) {
    const Space v295_1 = intersect(v264_49,s3);
    const Space v295_2 = restrict_to(s1,v295_1);
    Space v295_3_result;
    for (int v295_3_label = 1; v295_3_label <= 2; ++v295_3_label) {
      const Space v295_3_tail = child(v295_2,v295_3_label);
      if (v295_3_tail.empty()) continue;
      const Path v295_3_head{v295_3_label};
      const Space v296_2 = singleton(v295_3_head);
      const Space v296_3 = intersect(constant_9,v296_2);
      const Space v296_4 = (has_head(v296_3) ? constant_10 : Space{});
      const Space v296_5 = subtract(constant_0,v296_4);
      Space v296_7;
      if (!v296_5.empty()) {
        Space v297_6_result;
        for (int v297_6_label = 1; v297_6_label <= 2; ++v297_6_label) {
          const Space v297_6_tail = child(v295_3_tail,v297_6_label);
          if (v297_6_tail.empty()) continue;
          const Path v297_6_head{v297_6_label};
          const Space v298_2 = singleton(v297_6_head);
          const Space v298_3 = intersect(constant_9,v298_2);
          const Space v298_4 = (has_head(v298_3) ? constant_10 : Space{});
          const Space v298_5 = subtract(constant_0,v298_4);
          Space v298_8;
          if (!v298_5.empty()) {
            const Path v299_6 = concat_path(v295_3_head,v297_6_head);
            const Space v299_7 = routine_50(c, v299_6, v297_6_tail);
            v298_8 = compose(v298_5,v299_7);
          }
          const Space v298_9 = intersect(constant_9,v298_2);
          const Space v298_10 = (has_head(v298_9) ? constant_10 : Space{});
          Space v298_12;
          if (!v298_10.empty()) {
            const Path v300_6 = concat_path(v295_3_head,v297_6_head);
            const Space v300_11 = routine_51(c, v300_6, v297_6_tail);
            v298_12 = compose(v298_10,v300_11);
          }
          const Space v298_13 = unite(v298_8,v298_12);
          v297_6_result = unite(v297_6_result,v298_13);
        }
        const Space v297_6 = std::move(v297_6_result);
        v296_7 = compose(v296_5,v297_6);
      }
      const Space v296_8 = intersect(constant_9,v296_2);
      const Space v296_9 = (has_head(v296_8) ? constant_10 : Space{});
      Space v296_11;
      if (!v296_9.empty()) {
        Space v301_10_result;
        for (int v301_10_label = 1; v301_10_label <= 2; ++v301_10_label) {
          const Space v301_10_tail = child(v295_3_tail,v301_10_label);
          if (v301_10_tail.empty()) continue;
          const Path v301_10_head{v301_10_label};
          const Space v302_2 = singleton(v301_10_head);
          const Space v302_3 = intersect(constant_9,v302_2);
          const Space v302_4 = (has_head(v302_3) ? constant_10 : Space{});
          const Space v302_5 = subtract(constant_0,v302_4);
          Space v302_8;
          if (!v302_5.empty()) {
            const Path v303_6 = concat_path(v295_3_head,v301_10_head);
            const Space v303_7 = routine_50(c, v303_6, v301_10_tail);
            v302_8 = compose(v302_5,v303_7);
          }
          const Space v302_9 = intersect(constant_9,v302_2);
          const Space v302_10 = (has_head(v302_9) ? constant_10 : Space{});
          Space v302_12;
          if (!v302_10.empty()) {
            const Path v304_6 = concat_path(v295_3_head,v301_10_head);
            const Space v304_11 = routine_52(c, v304_6, v301_10_tail);
            v302_12 = compose(v302_10,v304_11);
          }
          const Space v302_13 = unite(v302_8,v302_12);
          v301_10_result = unite(v301_10_result,v302_13);
        }
        const Space v301_10 = std::move(v301_10_result);
        v296_11 = compose(v296_9,v301_10);
      }
      const Space v296_12 = unite(v296_7,v296_11);
      v295_3_result = unite(v295_3_result,v296_12);
    }
    const Space v295_3 = std::move(v295_3_result);
    const Space v295_4 = unite(v295_3,v264_49);
    const Space v295_5 = intersect(v295_4,s3);
    Space v264_49_next = unite(v264_49,v295_5);
    if (equal(v264_49_next,v264_49)) break;
    v264_49 = std::move(v264_49_next);
  }
  const Space v264_50 = subtract(v264_39,v264_49);
  const Space v264_51 = routine_10(c, v264_50);
  Space v264_91_result;
  for (int v264_91_label = 1; v264_91_label <= 2; ++v264_91_label) {
    const Space v264_91_tail = child(v264_51,v264_91_label);
    if (v264_91_tail.empty()) continue;
    const Path v264_91_head{v264_91_label};
    const Space v305_2 = singleton(v264_91_head);
    const Space v305_3 = intersect(constant_9,v305_2);
    const Space v305_4 = (has_head(v305_3) ? constant_10 : Space{});
    const Space v305_5 = subtract(constant_0,v305_4);
    Space v305_11;
    if (!v305_5.empty()) {
      Space v306_6 = v264_5;
      for (;;) {
        const Space v307_1 = intersect(v306_6,s3);
        const Space v307_2 = restrict_to(s2,v307_1);
        Space v307_3_result;
        for (int v307_3_label = 1; v307_3_label <= 2; ++v307_3_label) {
          const Space v307_3_tail = child(v307_2,v307_3_label);
          if (v307_3_tail.empty()) continue;
          const Path v307_3_head{v307_3_label};
          const Space v308_2 = singleton(v307_3_head);
          const Space v308_3 = intersect(constant_9,v308_2);
          const Space v308_4 = (has_head(v308_3) ? constant_10 : Space{});
          const Space v308_5 = subtract(constant_0,v308_4);
          Space v308_7;
          if (!v308_5.empty()) {
            Space v309_6_result;
            for (int v309_6_label = 1; v309_6_label <= 2; ++v309_6_label) {
              const Space v309_6_tail = child(v307_3_tail,v309_6_label);
              if (v309_6_tail.empty()) continue;
              const Path v309_6_head{v309_6_label};
              const Space v310_2 = singleton(v309_6_head);
              const Space v310_3 = intersect(constant_9,v310_2);
              const Space v310_4 = (has_head(v310_3) ? constant_10 : Space{});
              const Space v310_5 = subtract(constant_0,v310_4);
              Space v310_8;
              if (!v310_5.empty()) {
                const Path v311_6 = concat_path(v307_3_head,v309_6_head);
                const Space v311_7 = routine_50(c, v311_6, v309_6_tail);
                v310_8 = compose(v310_5,v311_7);
              }
              const Space v310_9 = intersect(constant_9,v310_2);
              const Space v310_10 = (has_head(v310_9) ? constant_10 : Space{});
              Space v310_12;
              if (!v310_10.empty()) {
                const Path v312_6 = concat_path(v307_3_head,v309_6_head);
                const Space v312_11 = routine_51(c, v312_6, v309_6_tail);
                v310_12 = compose(v310_10,v312_11);
              }
              const Space v310_13 = unite(v310_8,v310_12);
              v309_6_result = unite(v309_6_result,v310_13);
            }
            const Space v309_6 = std::move(v309_6_result);
            v308_7 = compose(v308_5,v309_6);
          }
          const Space v308_8 = intersect(constant_9,v308_2);
          const Space v308_9 = (has_head(v308_8) ? constant_10 : Space{});
          Space v308_11;
          if (!v308_9.empty()) {
            Space v313_10_result;
            for (int v313_10_label = 1; v313_10_label <= 2; ++v313_10_label) {
              const Space v313_10_tail = child(v307_3_tail,v313_10_label);
              if (v313_10_tail.empty()) continue;
              const Path v313_10_head{v313_10_label};
              const Space v314_2 = singleton(v313_10_head);
              const Space v314_3 = intersect(constant_9,v314_2);
              const Space v314_4 = (has_head(v314_3) ? constant_10 : Space{});
              const Space v314_5 = subtract(constant_0,v314_4);
              Space v314_8;
              if (!v314_5.empty()) {
                const Path v315_6 = concat_path(v307_3_head,v313_10_head);
                const Space v315_7 = routine_50(c, v315_6, v313_10_tail);
                v314_8 = compose(v314_5,v315_7);
              }
              const Space v314_9 = intersect(constant_9,v314_2);
              const Space v314_10 = (has_head(v314_9) ? constant_10 : Space{});
              Space v314_12;
              if (!v314_10.empty()) {
                const Path v316_6 = concat_path(v307_3_head,v313_10_head);
                const Space v316_11 = routine_52(c, v316_6, v313_10_tail);
                v314_12 = compose(v314_10,v316_11);
              }
              const Space v314_13 = unite(v314_8,v314_12);
              v313_10_result = unite(v313_10_result,v314_13);
            }
            const Space v313_10 = std::move(v313_10_result);
            v308_11 = compose(v308_9,v313_10);
          }
          const Space v308_12 = unite(v308_7,v308_11);
          v307_3_result = unite(v307_3_result,v308_12);
        }
        const Space v307_3 = std::move(v307_3_result);
        const Space v307_4 = unite(v307_3,v306_6);
        const Space v307_5 = intersect(v307_4,s3);
        Space v306_6_next = unite(v306_6,v307_5);
        if (equal(v306_6_next,v306_6)) break;
        v306_6 = std::move(v306_6_next);
      }
      const Space v306_7 = subtract(s3,v306_6);
      Space v306_8 = v264_5;
      for (;;) {
        const Space v317_1 = intersect(v306_8,s3);
        const Space v317_2 = restrict_to(s1,v317_1);
        Space v317_3_result;
        for (int v317_3_label = 1; v317_3_label <= 2; ++v317_3_label) {
          const Space v317_3_tail = child(v317_2,v317_3_label);
          if (v317_3_tail.empty()) continue;
          const Path v317_3_head{v317_3_label};
          const Space v318_2 = singleton(v317_3_head);
          const Space v318_3 = intersect(constant_9,v318_2);
          const Space v318_4 = (has_head(v318_3) ? constant_10 : Space{});
          const Space v318_5 = subtract(constant_0,v318_4);
          Space v318_7;
          if (!v318_5.empty()) {
            Space v319_6_result;
            for (int v319_6_label = 1; v319_6_label <= 2; ++v319_6_label) {
              const Space v319_6_tail = child(v317_3_tail,v319_6_label);
              if (v319_6_tail.empty()) continue;
              const Path v319_6_head{v319_6_label};
              const Space v320_2 = singleton(v319_6_head);
              const Space v320_3 = intersect(constant_9,v320_2);
              const Space v320_4 = (has_head(v320_3) ? constant_10 : Space{});
              const Space v320_5 = subtract(constant_0,v320_4);
              Space v320_8;
              if (!v320_5.empty()) {
                const Path v321_6 = concat_path(v317_3_head,v319_6_head);
                const Space v321_7 = routine_50(c, v321_6, v319_6_tail);
                v320_8 = compose(v320_5,v321_7);
              }
              const Space v320_9 = intersect(constant_9,v320_2);
              const Space v320_10 = (has_head(v320_9) ? constant_10 : Space{});
              Space v320_12;
              if (!v320_10.empty()) {
                const Path v322_6 = concat_path(v317_3_head,v319_6_head);
                const Space v322_11 = routine_51(c, v322_6, v319_6_tail);
                v320_12 = compose(v320_10,v322_11);
              }
              const Space v320_13 = unite(v320_8,v320_12);
              v319_6_result = unite(v319_6_result,v320_13);
            }
            const Space v319_6 = std::move(v319_6_result);
            v318_7 = compose(v318_5,v319_6);
          }
          const Space v318_8 = intersect(constant_9,v318_2);
          const Space v318_9 = (has_head(v318_8) ? constant_10 : Space{});
          Space v318_11;
          if (!v318_9.empty()) {
            Space v323_10_result;
            for (int v323_10_label = 1; v323_10_label <= 2; ++v323_10_label) {
              const Space v323_10_tail = child(v317_3_tail,v323_10_label);
              if (v323_10_tail.empty()) continue;
              const Path v323_10_head{v323_10_label};
              const Space v324_2 = singleton(v323_10_head);
              const Space v324_3 = intersect(constant_9,v324_2);
              const Space v324_4 = (has_head(v324_3) ? constant_10 : Space{});
              const Space v324_5 = subtract(constant_0,v324_4);
              Space v324_8;
              if (!v324_5.empty()) {
                const Path v325_6 = concat_path(v317_3_head,v323_10_head);
                const Space v325_7 = routine_50(c, v325_6, v323_10_tail);
                v324_8 = compose(v324_5,v325_7);
              }
              const Space v324_9 = intersect(constant_9,v324_2);
              const Space v324_10 = (has_head(v324_9) ? constant_10 : Space{});
              Space v324_12;
              if (!v324_10.empty()) {
                const Path v326_6 = concat_path(v317_3_head,v323_10_head);
                const Space v326_11 = routine_52(c, v326_6, v323_10_tail);
                v324_12 = compose(v324_10,v326_11);
              }
              const Space v324_13 = unite(v324_8,v324_12);
              v323_10_result = unite(v323_10_result,v324_13);
            }
            const Space v323_10 = std::move(v323_10_result);
            v318_11 = compose(v318_9,v323_10);
          }
          const Space v318_12 = unite(v318_7,v318_11);
          v317_3_result = unite(v317_3_result,v318_12);
        }
        const Space v317_3 = std::move(v317_3_result);
        const Space v317_4 = unite(v317_3,v306_8);
        const Space v317_5 = intersect(v317_4,s3);
        Space v306_8_next = unite(v306_8,v317_5);
        if (equal(v306_8_next,v306_8)) break;
        v306_8 = std::move(v306_8_next);
      }
      const Space v306_9 = subtract(v306_7,v306_8);
      const Space v306_10 = routine_14(c, v264_91_head, v264_91_tail, s1, s2, v306_9);
      v305_11 = compose(v305_5,v306_10);
    }
    const Space v305_12 = intersect(constant_9,v305_2);
    const Space v305_13 = (has_head(v305_12) ? constant_10 : Space{});
    Space v305_19;
    if (!v305_13.empty()) {
      Space v327_14 = v264_5;
      for (;;) {
        const Space v328_1 = intersect(v327_14,s3);
        const Space v328_2 = restrict_to(s2,v328_1);
        Space v328_3_result;
        for (int v328_3_label = 1; v328_3_label <= 2; ++v328_3_label) {
          const Space v328_3_tail = child(v328_2,v328_3_label);
          if (v328_3_tail.empty()) continue;
          const Path v328_3_head{v328_3_label};
          const Space v329_2 = singleton(v328_3_head);
          const Space v329_3 = intersect(constant_9,v329_2);
          const Space v329_4 = (has_head(v329_3) ? constant_10 : Space{});
          const Space v329_5 = subtract(constant_0,v329_4);
          Space v329_7;
          if (!v329_5.empty()) {
            Space v330_6_result;
            for (int v330_6_label = 1; v330_6_label <= 2; ++v330_6_label) {
              const Space v330_6_tail = child(v328_3_tail,v330_6_label);
              if (v330_6_tail.empty()) continue;
              const Path v330_6_head{v330_6_label};
              const Space v331_2 = singleton(v330_6_head);
              const Space v331_3 = intersect(constant_9,v331_2);
              const Space v331_4 = (has_head(v331_3) ? constant_10 : Space{});
              const Space v331_5 = subtract(constant_0,v331_4);
              Space v331_8;
              if (!v331_5.empty()) {
                const Path v332_6 = concat_path(v328_3_head,v330_6_head);
                const Space v332_7 = routine_50(c, v332_6, v330_6_tail);
                v331_8 = compose(v331_5,v332_7);
              }
              const Space v331_9 = intersect(constant_9,v331_2);
              const Space v331_10 = (has_head(v331_9) ? constant_10 : Space{});
              Space v331_12;
              if (!v331_10.empty()) {
                const Path v333_6 = concat_path(v328_3_head,v330_6_head);
                const Space v333_11 = routine_51(c, v333_6, v330_6_tail);
                v331_12 = compose(v331_10,v333_11);
              }
              const Space v331_13 = unite(v331_8,v331_12);
              v330_6_result = unite(v330_6_result,v331_13);
            }
            const Space v330_6 = std::move(v330_6_result);
            v329_7 = compose(v329_5,v330_6);
          }
          const Space v329_8 = intersect(constant_9,v329_2);
          const Space v329_9 = (has_head(v329_8) ? constant_10 : Space{});
          Space v329_11;
          if (!v329_9.empty()) {
            Space v334_10_result;
            for (int v334_10_label = 1; v334_10_label <= 2; ++v334_10_label) {
              const Space v334_10_tail = child(v328_3_tail,v334_10_label);
              if (v334_10_tail.empty()) continue;
              const Path v334_10_head{v334_10_label};
              const Space v335_2 = singleton(v334_10_head);
              const Space v335_3 = intersect(constant_9,v335_2);
              const Space v335_4 = (has_head(v335_3) ? constant_10 : Space{});
              const Space v335_5 = subtract(constant_0,v335_4);
              Space v335_8;
              if (!v335_5.empty()) {
                const Path v336_6 = concat_path(v328_3_head,v334_10_head);
                const Space v336_7 = routine_50(c, v336_6, v334_10_tail);
                v335_8 = compose(v335_5,v336_7);
              }
              const Space v335_9 = intersect(constant_9,v335_2);
              const Space v335_10 = (has_head(v335_9) ? constant_10 : Space{});
              Space v335_12;
              if (!v335_10.empty()) {
                const Path v337_6 = concat_path(v328_3_head,v334_10_head);
                const Space v337_11 = routine_52(c, v337_6, v334_10_tail);
                v335_12 = compose(v335_10,v337_11);
              }
              const Space v335_13 = unite(v335_8,v335_12);
              v334_10_result = unite(v334_10_result,v335_13);
            }
            const Space v334_10 = std::move(v334_10_result);
            v329_11 = compose(v329_9,v334_10);
          }
          const Space v329_12 = unite(v329_7,v329_11);
          v328_3_result = unite(v328_3_result,v329_12);
        }
        const Space v328_3 = std::move(v328_3_result);
        const Space v328_4 = unite(v328_3,v327_14);
        const Space v328_5 = intersect(v328_4,s3);
        Space v327_14_next = unite(v327_14,v328_5);
        if (equal(v327_14_next,v327_14)) break;
        v327_14 = std::move(v327_14_next);
      }
      const Space v327_15 = subtract(s3,v327_14);
      Space v327_16 = v264_5;
      for (;;) {
        const Space v338_1 = intersect(v327_16,s3);
        const Space v338_2 = restrict_to(s1,v338_1);
        Space v338_3_result;
        for (int v338_3_label = 1; v338_3_label <= 2; ++v338_3_label) {
          const Space v338_3_tail = child(v338_2,v338_3_label);
          if (v338_3_tail.empty()) continue;
          const Path v338_3_head{v338_3_label};
          const Space v339_2 = singleton(v338_3_head);
          const Space v339_3 = intersect(constant_9,v339_2);
          const Space v339_4 = (has_head(v339_3) ? constant_10 : Space{});
          const Space v339_5 = subtract(constant_0,v339_4);
          Space v339_7;
          if (!v339_5.empty()) {
            Space v340_6_result;
            for (int v340_6_label = 1; v340_6_label <= 2; ++v340_6_label) {
              const Space v340_6_tail = child(v338_3_tail,v340_6_label);
              if (v340_6_tail.empty()) continue;
              const Path v340_6_head{v340_6_label};
              const Space v341_2 = singleton(v340_6_head);
              const Space v341_3 = intersect(constant_9,v341_2);
              const Space v341_4 = (has_head(v341_3) ? constant_10 : Space{});
              const Space v341_5 = subtract(constant_0,v341_4);
              Space v341_8;
              if (!v341_5.empty()) {
                const Path v342_6 = concat_path(v338_3_head,v340_6_head);
                const Space v342_7 = routine_50(c, v342_6, v340_6_tail);
                v341_8 = compose(v341_5,v342_7);
              }
              const Space v341_9 = intersect(constant_9,v341_2);
              const Space v341_10 = (has_head(v341_9) ? constant_10 : Space{});
              Space v341_12;
              if (!v341_10.empty()) {
                const Path v343_6 = concat_path(v338_3_head,v340_6_head);
                const Space v343_11 = routine_51(c, v343_6, v340_6_tail);
                v341_12 = compose(v341_10,v343_11);
              }
              const Space v341_13 = unite(v341_8,v341_12);
              v340_6_result = unite(v340_6_result,v341_13);
            }
            const Space v340_6 = std::move(v340_6_result);
            v339_7 = compose(v339_5,v340_6);
          }
          const Space v339_8 = intersect(constant_9,v339_2);
          const Space v339_9 = (has_head(v339_8) ? constant_10 : Space{});
          Space v339_11;
          if (!v339_9.empty()) {
            Space v344_10_result;
            for (int v344_10_label = 1; v344_10_label <= 2; ++v344_10_label) {
              const Space v344_10_tail = child(v338_3_tail,v344_10_label);
              if (v344_10_tail.empty()) continue;
              const Path v344_10_head{v344_10_label};
              const Space v345_2 = singleton(v344_10_head);
              const Space v345_3 = intersect(constant_9,v345_2);
              const Space v345_4 = (has_head(v345_3) ? constant_10 : Space{});
              const Space v345_5 = subtract(constant_0,v345_4);
              Space v345_8;
              if (!v345_5.empty()) {
                const Path v346_6 = concat_path(v338_3_head,v344_10_head);
                const Space v346_7 = routine_50(c, v346_6, v344_10_tail);
                v345_8 = compose(v345_5,v346_7);
              }
              const Space v345_9 = intersect(constant_9,v345_2);
              const Space v345_10 = (has_head(v345_9) ? constant_10 : Space{});
              Space v345_12;
              if (!v345_10.empty()) {
                const Path v347_6 = concat_path(v338_3_head,v344_10_head);
                const Space v347_11 = routine_52(c, v347_6, v344_10_tail);
                v345_12 = compose(v345_10,v347_11);
              }
              const Space v345_13 = unite(v345_8,v345_12);
              v344_10_result = unite(v344_10_result,v345_13);
            }
            const Space v344_10 = std::move(v344_10_result);
            v339_11 = compose(v339_9,v344_10);
          }
          const Space v339_12 = unite(v339_7,v339_11);
          v338_3_result = unite(v338_3_result,v339_12);
        }
        const Space v338_3 = std::move(v338_3_result);
        const Space v338_4 = unite(v338_3,v327_16);
        const Space v338_5 = intersect(v338_4,s3);
        Space v327_16_next = unite(v327_16,v338_5);
        if (equal(v327_16_next,v327_16)) break;
        v327_16 = std::move(v327_16_next);
      }
      const Space v327_17 = subtract(v327_15,v327_16);
      const Space v327_18 = routine_15(c, v264_91_head, v264_91_tail, s1, s2, v327_17);
      v305_19 = compose(v305_13,v327_18);
    }
    const Space v305_20 = unite(v305_11,v305_19);
    v264_91_result = unite(v264_91_result,v305_20);
  }
  const Space v264_91 = std::move(v264_91_result);
  const Space v264_92 = unite(v264_28,v264_91);
  Space v264_102 = v264_5;
  for (;;) {
    const Space v348_1 = intersect(v264_102,s3);
    const Space v348_2 = restrict_to(s2,v348_1);
    Space v348_3_result;
    for (int v348_3_label = 1; v348_3_label <= 2; ++v348_3_label) {
      const Space v348_3_tail = child(v348_2,v348_3_label);
      if (v348_3_tail.empty()) continue;
      const Path v348_3_head{v348_3_label};
      const Space v349_2 = singleton(v348_3_head);
      const Space v349_3 = intersect(constant_9,v349_2);
      const Space v349_4 = (has_head(v349_3) ? constant_10 : Space{});
      const Space v349_5 = subtract(constant_0,v349_4);
      Space v349_7;
      if (!v349_5.empty()) {
        Space v350_6_result;
        for (int v350_6_label = 1; v350_6_label <= 2; ++v350_6_label) {
          const Space v350_6_tail = child(v348_3_tail,v350_6_label);
          if (v350_6_tail.empty()) continue;
          const Path v350_6_head{v350_6_label};
          const Space v351_2 = singleton(v350_6_head);
          const Space v351_3 = intersect(constant_9,v351_2);
          const Space v351_4 = (has_head(v351_3) ? constant_10 : Space{});
          const Space v351_5 = subtract(constant_0,v351_4);
          Space v351_8;
          if (!v351_5.empty()) {
            const Path v352_6 = concat_path(v348_3_head,v350_6_head);
            const Space v352_7 = routine_50(c, v352_6, v350_6_tail);
            v351_8 = compose(v351_5,v352_7);
          }
          const Space v351_9 = intersect(constant_9,v351_2);
          const Space v351_10 = (has_head(v351_9) ? constant_10 : Space{});
          Space v351_12;
          if (!v351_10.empty()) {
            const Path v353_6 = concat_path(v348_3_head,v350_6_head);
            const Space v353_11 = routine_51(c, v353_6, v350_6_tail);
            v351_12 = compose(v351_10,v353_11);
          }
          const Space v351_13 = unite(v351_8,v351_12);
          v350_6_result = unite(v350_6_result,v351_13);
        }
        const Space v350_6 = std::move(v350_6_result);
        v349_7 = compose(v349_5,v350_6);
      }
      const Space v349_8 = intersect(constant_9,v349_2);
      const Space v349_9 = (has_head(v349_8) ? constant_10 : Space{});
      Space v349_11;
      if (!v349_9.empty()) {
        Space v354_10_result;
        for (int v354_10_label = 1; v354_10_label <= 2; ++v354_10_label) {
          const Space v354_10_tail = child(v348_3_tail,v354_10_label);
          if (v354_10_tail.empty()) continue;
          const Path v354_10_head{v354_10_label};
          const Space v355_2 = singleton(v354_10_head);
          const Space v355_3 = intersect(constant_9,v355_2);
          const Space v355_4 = (has_head(v355_3) ? constant_10 : Space{});
          const Space v355_5 = subtract(constant_0,v355_4);
          Space v355_8;
          if (!v355_5.empty()) {
            const Path v356_6 = concat_path(v348_3_head,v354_10_head);
            const Space v356_7 = routine_50(c, v356_6, v354_10_tail);
            v355_8 = compose(v355_5,v356_7);
          }
          const Space v355_9 = intersect(constant_9,v355_2);
          const Space v355_10 = (has_head(v355_9) ? constant_10 : Space{});
          Space v355_12;
          if (!v355_10.empty()) {
            const Path v357_6 = concat_path(v348_3_head,v354_10_head);
            const Space v357_11 = routine_52(c, v357_6, v354_10_tail);
            v355_12 = compose(v355_10,v357_11);
          }
          const Space v355_13 = unite(v355_8,v355_12);
          v354_10_result = unite(v354_10_result,v355_13);
        }
        const Space v354_10 = std::move(v354_10_result);
        v349_11 = compose(v349_9,v354_10);
      }
      const Space v349_12 = unite(v349_7,v349_11);
      v348_3_result = unite(v348_3_result,v349_12);
    }
    const Space v348_3 = std::move(v348_3_result);
    const Space v348_4 = unite(v348_3,v264_102);
    const Space v348_5 = intersect(v348_4,s3);
    Space v264_102_next = unite(v264_102,v348_5);
    if (equal(v264_102_next,v264_102)) break;
    v264_102 = std::move(v264_102_next);
  }
  Space v264_112 = v264_5;
  for (;;) {
    const Space v358_1 = intersect(v264_112,s3);
    const Space v358_2 = restrict_to(s1,v358_1);
    Space v358_3_result;
    for (int v358_3_label = 1; v358_3_label <= 2; ++v358_3_label) {
      const Space v358_3_tail = child(v358_2,v358_3_label);
      if (v358_3_tail.empty()) continue;
      const Path v358_3_head{v358_3_label};
      const Space v359_2 = singleton(v358_3_head);
      const Space v359_3 = intersect(constant_9,v359_2);
      const Space v359_4 = (has_head(v359_3) ? constant_10 : Space{});
      const Space v359_5 = subtract(constant_0,v359_4);
      Space v359_7;
      if (!v359_5.empty()) {
        Space v360_6_result;
        for (int v360_6_label = 1; v360_6_label <= 2; ++v360_6_label) {
          const Space v360_6_tail = child(v358_3_tail,v360_6_label);
          if (v360_6_tail.empty()) continue;
          const Path v360_6_head{v360_6_label};
          const Space v361_2 = singleton(v360_6_head);
          const Space v361_3 = intersect(constant_9,v361_2);
          const Space v361_4 = (has_head(v361_3) ? constant_10 : Space{});
          const Space v361_5 = subtract(constant_0,v361_4);
          Space v361_8;
          if (!v361_5.empty()) {
            const Path v362_6 = concat_path(v358_3_head,v360_6_head);
            const Space v362_7 = routine_50(c, v362_6, v360_6_tail);
            v361_8 = compose(v361_5,v362_7);
          }
          const Space v361_9 = intersect(constant_9,v361_2);
          const Space v361_10 = (has_head(v361_9) ? constant_10 : Space{});
          Space v361_12;
          if (!v361_10.empty()) {
            const Path v363_6 = concat_path(v358_3_head,v360_6_head);
            const Space v363_11 = routine_51(c, v363_6, v360_6_tail);
            v361_12 = compose(v361_10,v363_11);
          }
          const Space v361_13 = unite(v361_8,v361_12);
          v360_6_result = unite(v360_6_result,v361_13);
        }
        const Space v360_6 = std::move(v360_6_result);
        v359_7 = compose(v359_5,v360_6);
      }
      const Space v359_8 = intersect(constant_9,v359_2);
      const Space v359_9 = (has_head(v359_8) ? constant_10 : Space{});
      Space v359_11;
      if (!v359_9.empty()) {
        Space v364_10_result;
        for (int v364_10_label = 1; v364_10_label <= 2; ++v364_10_label) {
          const Space v364_10_tail = child(v358_3_tail,v364_10_label);
          if (v364_10_tail.empty()) continue;
          const Path v364_10_head{v364_10_label};
          const Space v365_2 = singleton(v364_10_head);
          const Space v365_3 = intersect(constant_9,v365_2);
          const Space v365_4 = (has_head(v365_3) ? constant_10 : Space{});
          const Space v365_5 = subtract(constant_0,v365_4);
          Space v365_8;
          if (!v365_5.empty()) {
            const Path v366_6 = concat_path(v358_3_head,v364_10_head);
            const Space v366_7 = routine_50(c, v366_6, v364_10_tail);
            v365_8 = compose(v365_5,v366_7);
          }
          const Space v365_9 = intersect(constant_9,v365_2);
          const Space v365_10 = (has_head(v365_9) ? constant_10 : Space{});
          Space v365_12;
          if (!v365_10.empty()) {
            const Path v367_6 = concat_path(v358_3_head,v364_10_head);
            const Space v367_11 = routine_52(c, v367_6, v364_10_tail);
            v365_12 = compose(v365_10,v367_11);
          }
          const Space v365_13 = unite(v365_8,v365_12);
          v364_10_result = unite(v364_10_result,v365_13);
        }
        const Space v364_10 = std::move(v364_10_result);
        v359_11 = compose(v359_9,v364_10);
      }
      const Space v359_12 = unite(v359_7,v359_11);
      v358_3_result = unite(v358_3_result,v359_12);
    }
    const Space v358_3 = std::move(v358_3_result);
    const Space v358_4 = unite(v358_3,v264_112);
    const Space v358_5 = intersect(v358_4,s3);
    Space v264_112_next = unite(v264_112,v358_5);
    if (equal(v264_112_next,v264_112)) break;
    v264_112 = std::move(v264_112_next);
  }
  const Space v264_113 = subtract(v264_102,v264_112);
  const Space v264_114 = routine_10(c, v264_113);
  Space v264_154_result;
  for (int v264_154_label = 1; v264_154_label <= 2; ++v264_154_label) {
    const Space v264_154_tail = child(v264_114,v264_154_label);
    if (v264_154_tail.empty()) continue;
    const Path v264_154_head{v264_154_label};
    const Space v368_2 = singleton(v264_154_head);
    const Space v368_3 = intersect(constant_9,v368_2);
    const Space v368_4 = (has_head(v368_3) ? constant_10 : Space{});
    const Space v368_5 = subtract(constant_0,v368_4);
    Space v368_10;
    if (!v368_5.empty()) {
      Space v369_6 = v264_5;
      for (;;) {
        const Space v370_1 = intersect(v369_6,s3);
        const Space v370_2 = restrict_to(s2,v370_1);
        Space v370_3_result;
        for (int v370_3_label = 1; v370_3_label <= 2; ++v370_3_label) {
          const Space v370_3_tail = child(v370_2,v370_3_label);
          if (v370_3_tail.empty()) continue;
          const Path v370_3_head{v370_3_label};
          const Space v371_2 = singleton(v370_3_head);
          const Space v371_3 = intersect(constant_9,v371_2);
          const Space v371_4 = (has_head(v371_3) ? constant_10 : Space{});
          const Space v371_5 = subtract(constant_0,v371_4);
          Space v371_7;
          if (!v371_5.empty()) {
            Space v372_6_result;
            for (int v372_6_label = 1; v372_6_label <= 2; ++v372_6_label) {
              const Space v372_6_tail = child(v370_3_tail,v372_6_label);
              if (v372_6_tail.empty()) continue;
              const Path v372_6_head{v372_6_label};
              const Space v373_2 = singleton(v372_6_head);
              const Space v373_3 = intersect(constant_9,v373_2);
              const Space v373_4 = (has_head(v373_3) ? constant_10 : Space{});
              const Space v373_5 = subtract(constant_0,v373_4);
              Space v373_8;
              if (!v373_5.empty()) {
                const Path v374_6 = concat_path(v370_3_head,v372_6_head);
                const Space v374_7 = routine_50(c, v374_6, v372_6_tail);
                v373_8 = compose(v373_5,v374_7);
              }
              const Space v373_9 = intersect(constant_9,v373_2);
              const Space v373_10 = (has_head(v373_9) ? constant_10 : Space{});
              Space v373_12;
              if (!v373_10.empty()) {
                const Path v375_6 = concat_path(v370_3_head,v372_6_head);
                const Space v375_11 = routine_51(c, v375_6, v372_6_tail);
                v373_12 = compose(v373_10,v375_11);
              }
              const Space v373_13 = unite(v373_8,v373_12);
              v372_6_result = unite(v372_6_result,v373_13);
            }
            const Space v372_6 = std::move(v372_6_result);
            v371_7 = compose(v371_5,v372_6);
          }
          const Space v371_8 = intersect(constant_9,v371_2);
          const Space v371_9 = (has_head(v371_8) ? constant_10 : Space{});
          Space v371_11;
          if (!v371_9.empty()) {
            Space v376_10_result;
            for (int v376_10_label = 1; v376_10_label <= 2; ++v376_10_label) {
              const Space v376_10_tail = child(v370_3_tail,v376_10_label);
              if (v376_10_tail.empty()) continue;
              const Path v376_10_head{v376_10_label};
              const Space v377_2 = singleton(v376_10_head);
              const Space v377_3 = intersect(constant_9,v377_2);
              const Space v377_4 = (has_head(v377_3) ? constant_10 : Space{});
              const Space v377_5 = subtract(constant_0,v377_4);
              Space v377_8;
              if (!v377_5.empty()) {
                const Path v378_6 = concat_path(v370_3_head,v376_10_head);
                const Space v378_7 = routine_50(c, v378_6, v376_10_tail);
                v377_8 = compose(v377_5,v378_7);
              }
              const Space v377_9 = intersect(constant_9,v377_2);
              const Space v377_10 = (has_head(v377_9) ? constant_10 : Space{});
              Space v377_12;
              if (!v377_10.empty()) {
                const Path v379_6 = concat_path(v370_3_head,v376_10_head);
                const Space v379_11 = routine_52(c, v379_6, v376_10_tail);
                v377_12 = compose(v377_10,v379_11);
              }
              const Space v377_13 = unite(v377_8,v377_12);
              v376_10_result = unite(v376_10_result,v377_13);
            }
            const Space v376_10 = std::move(v376_10_result);
            v371_11 = compose(v371_9,v376_10);
          }
          const Space v371_12 = unite(v371_7,v371_11);
          v370_3_result = unite(v370_3_result,v371_12);
        }
        const Space v370_3 = std::move(v370_3_result);
        const Space v370_4 = unite(v370_3,v369_6);
        const Space v370_5 = intersect(v370_4,s3);
        Space v369_6_next = unite(v369_6,v370_5);
        if (equal(v369_6_next,v369_6)) break;
        v369_6 = std::move(v369_6_next);
      }
      Space v369_7 = v264_5;
      for (;;) {
        const Space v380_1 = intersect(v369_7,s3);
        const Space v380_2 = restrict_to(s1,v380_1);
        Space v380_3_result;
        for (int v380_3_label = 1; v380_3_label <= 2; ++v380_3_label) {
          const Space v380_3_tail = child(v380_2,v380_3_label);
          if (v380_3_tail.empty()) continue;
          const Path v380_3_head{v380_3_label};
          const Space v381_2 = singleton(v380_3_head);
          const Space v381_3 = intersect(constant_9,v381_2);
          const Space v381_4 = (has_head(v381_3) ? constant_10 : Space{});
          const Space v381_5 = subtract(constant_0,v381_4);
          Space v381_7;
          if (!v381_5.empty()) {
            Space v382_6_result;
            for (int v382_6_label = 1; v382_6_label <= 2; ++v382_6_label) {
              const Space v382_6_tail = child(v380_3_tail,v382_6_label);
              if (v382_6_tail.empty()) continue;
              const Path v382_6_head{v382_6_label};
              const Space v383_2 = singleton(v382_6_head);
              const Space v383_3 = intersect(constant_9,v383_2);
              const Space v383_4 = (has_head(v383_3) ? constant_10 : Space{});
              const Space v383_5 = subtract(constant_0,v383_4);
              Space v383_8;
              if (!v383_5.empty()) {
                const Path v384_6 = concat_path(v380_3_head,v382_6_head);
                const Space v384_7 = routine_50(c, v384_6, v382_6_tail);
                v383_8 = compose(v383_5,v384_7);
              }
              const Space v383_9 = intersect(constant_9,v383_2);
              const Space v383_10 = (has_head(v383_9) ? constant_10 : Space{});
              Space v383_12;
              if (!v383_10.empty()) {
                const Path v385_6 = concat_path(v380_3_head,v382_6_head);
                const Space v385_11 = routine_51(c, v385_6, v382_6_tail);
                v383_12 = compose(v383_10,v385_11);
              }
              const Space v383_13 = unite(v383_8,v383_12);
              v382_6_result = unite(v382_6_result,v383_13);
            }
            const Space v382_6 = std::move(v382_6_result);
            v381_7 = compose(v381_5,v382_6);
          }
          const Space v381_8 = intersect(constant_9,v381_2);
          const Space v381_9 = (has_head(v381_8) ? constant_10 : Space{});
          Space v381_11;
          if (!v381_9.empty()) {
            Space v386_10_result;
            for (int v386_10_label = 1; v386_10_label <= 2; ++v386_10_label) {
              const Space v386_10_tail = child(v380_3_tail,v386_10_label);
              if (v386_10_tail.empty()) continue;
              const Path v386_10_head{v386_10_label};
              const Space v387_2 = singleton(v386_10_head);
              const Space v387_3 = intersect(constant_9,v387_2);
              const Space v387_4 = (has_head(v387_3) ? constant_10 : Space{});
              const Space v387_5 = subtract(constant_0,v387_4);
              Space v387_8;
              if (!v387_5.empty()) {
                const Path v388_6 = concat_path(v380_3_head,v386_10_head);
                const Space v388_7 = routine_50(c, v388_6, v386_10_tail);
                v387_8 = compose(v387_5,v388_7);
              }
              const Space v387_9 = intersect(constant_9,v387_2);
              const Space v387_10 = (has_head(v387_9) ? constant_10 : Space{});
              Space v387_12;
              if (!v387_10.empty()) {
                const Path v389_6 = concat_path(v380_3_head,v386_10_head);
                const Space v389_11 = routine_52(c, v389_6, v386_10_tail);
                v387_12 = compose(v387_10,v389_11);
              }
              const Space v387_13 = unite(v387_8,v387_12);
              v386_10_result = unite(v386_10_result,v387_13);
            }
            const Space v386_10 = std::move(v386_10_result);
            v381_11 = compose(v381_9,v386_10);
          }
          const Space v381_12 = unite(v381_7,v381_11);
          v380_3_result = unite(v380_3_result,v381_12);
        }
        const Space v380_3 = std::move(v380_3_result);
        const Space v380_4 = unite(v380_3,v369_7);
        const Space v380_5 = intersect(v380_4,s3);
        Space v369_7_next = unite(v369_7,v380_5);
        if (equal(v369_7_next,v369_7)) break;
        v369_7 = std::move(v369_7_next);
      }
      const Space v369_8 = subtract(v369_6,v369_7);
      const Space v369_9 = routine_14(c, v264_154_head, v264_154_tail, s1, s2, v369_8);
      v368_10 = compose(v368_5,v369_9);
    }
    const Space v368_11 = intersect(constant_9,v368_2);
    const Space v368_12 = (has_head(v368_11) ? constant_10 : Space{});
    Space v368_17;
    if (!v368_12.empty()) {
      Space v390_13 = v264_5;
      for (;;) {
        const Space v391_1 = intersect(v390_13,s3);
        const Space v391_2 = restrict_to(s2,v391_1);
        Space v391_3_result;
        for (int v391_3_label = 1; v391_3_label <= 2; ++v391_3_label) {
          const Space v391_3_tail = child(v391_2,v391_3_label);
          if (v391_3_tail.empty()) continue;
          const Path v391_3_head{v391_3_label};
          const Space v392_2 = singleton(v391_3_head);
          const Space v392_3 = intersect(constant_9,v392_2);
          const Space v392_4 = (has_head(v392_3) ? constant_10 : Space{});
          const Space v392_5 = subtract(constant_0,v392_4);
          Space v392_7;
          if (!v392_5.empty()) {
            Space v393_6_result;
            for (int v393_6_label = 1; v393_6_label <= 2; ++v393_6_label) {
              const Space v393_6_tail = child(v391_3_tail,v393_6_label);
              if (v393_6_tail.empty()) continue;
              const Path v393_6_head{v393_6_label};
              const Space v394_2 = singleton(v393_6_head);
              const Space v394_3 = intersect(constant_9,v394_2);
              const Space v394_4 = (has_head(v394_3) ? constant_10 : Space{});
              const Space v394_5 = subtract(constant_0,v394_4);
              Space v394_8;
              if (!v394_5.empty()) {
                const Path v395_6 = concat_path(v391_3_head,v393_6_head);
                const Space v395_7 = routine_50(c, v395_6, v393_6_tail);
                v394_8 = compose(v394_5,v395_7);
              }
              const Space v394_9 = intersect(constant_9,v394_2);
              const Space v394_10 = (has_head(v394_9) ? constant_10 : Space{});
              Space v394_12;
              if (!v394_10.empty()) {
                const Path v396_6 = concat_path(v391_3_head,v393_6_head);
                const Space v396_11 = routine_51(c, v396_6, v393_6_tail);
                v394_12 = compose(v394_10,v396_11);
              }
              const Space v394_13 = unite(v394_8,v394_12);
              v393_6_result = unite(v393_6_result,v394_13);
            }
            const Space v393_6 = std::move(v393_6_result);
            v392_7 = compose(v392_5,v393_6);
          }
          const Space v392_8 = intersect(constant_9,v392_2);
          const Space v392_9 = (has_head(v392_8) ? constant_10 : Space{});
          Space v392_11;
          if (!v392_9.empty()) {
            Space v397_10_result;
            for (int v397_10_label = 1; v397_10_label <= 2; ++v397_10_label) {
              const Space v397_10_tail = child(v391_3_tail,v397_10_label);
              if (v397_10_tail.empty()) continue;
              const Path v397_10_head{v397_10_label};
              const Space v398_2 = singleton(v397_10_head);
              const Space v398_3 = intersect(constant_9,v398_2);
              const Space v398_4 = (has_head(v398_3) ? constant_10 : Space{});
              const Space v398_5 = subtract(constant_0,v398_4);
              Space v398_8;
              if (!v398_5.empty()) {
                const Path v399_6 = concat_path(v391_3_head,v397_10_head);
                const Space v399_7 = routine_50(c, v399_6, v397_10_tail);
                v398_8 = compose(v398_5,v399_7);
              }
              const Space v398_9 = intersect(constant_9,v398_2);
              const Space v398_10 = (has_head(v398_9) ? constant_10 : Space{});
              Space v398_12;
              if (!v398_10.empty()) {
                const Path v400_6 = concat_path(v391_3_head,v397_10_head);
                const Space v400_11 = routine_52(c, v400_6, v397_10_tail);
                v398_12 = compose(v398_10,v400_11);
              }
              const Space v398_13 = unite(v398_8,v398_12);
              v397_10_result = unite(v397_10_result,v398_13);
            }
            const Space v397_10 = std::move(v397_10_result);
            v392_11 = compose(v392_9,v397_10);
          }
          const Space v392_12 = unite(v392_7,v392_11);
          v391_3_result = unite(v391_3_result,v392_12);
        }
        const Space v391_3 = std::move(v391_3_result);
        const Space v391_4 = unite(v391_3,v390_13);
        const Space v391_5 = intersect(v391_4,s3);
        Space v390_13_next = unite(v390_13,v391_5);
        if (equal(v390_13_next,v390_13)) break;
        v390_13 = std::move(v390_13_next);
      }
      Space v390_14 = v264_5;
      for (;;) {
        const Space v401_1 = intersect(v390_14,s3);
        const Space v401_2 = restrict_to(s1,v401_1);
        Space v401_3_result;
        for (int v401_3_label = 1; v401_3_label <= 2; ++v401_3_label) {
          const Space v401_3_tail = child(v401_2,v401_3_label);
          if (v401_3_tail.empty()) continue;
          const Path v401_3_head{v401_3_label};
          const Space v402_2 = singleton(v401_3_head);
          const Space v402_3 = intersect(constant_9,v402_2);
          const Space v402_4 = (has_head(v402_3) ? constant_10 : Space{});
          const Space v402_5 = subtract(constant_0,v402_4);
          Space v402_7;
          if (!v402_5.empty()) {
            Space v403_6_result;
            for (int v403_6_label = 1; v403_6_label <= 2; ++v403_6_label) {
              const Space v403_6_tail = child(v401_3_tail,v403_6_label);
              if (v403_6_tail.empty()) continue;
              const Path v403_6_head{v403_6_label};
              const Space v404_2 = singleton(v403_6_head);
              const Space v404_3 = intersect(constant_9,v404_2);
              const Space v404_4 = (has_head(v404_3) ? constant_10 : Space{});
              const Space v404_5 = subtract(constant_0,v404_4);
              Space v404_8;
              if (!v404_5.empty()) {
                const Path v405_6 = concat_path(v401_3_head,v403_6_head);
                const Space v405_7 = routine_50(c, v405_6, v403_6_tail);
                v404_8 = compose(v404_5,v405_7);
              }
              const Space v404_9 = intersect(constant_9,v404_2);
              const Space v404_10 = (has_head(v404_9) ? constant_10 : Space{});
              Space v404_12;
              if (!v404_10.empty()) {
                const Path v406_6 = concat_path(v401_3_head,v403_6_head);
                const Space v406_11 = routine_51(c, v406_6, v403_6_tail);
                v404_12 = compose(v404_10,v406_11);
              }
              const Space v404_13 = unite(v404_8,v404_12);
              v403_6_result = unite(v403_6_result,v404_13);
            }
            const Space v403_6 = std::move(v403_6_result);
            v402_7 = compose(v402_5,v403_6);
          }
          const Space v402_8 = intersect(constant_9,v402_2);
          const Space v402_9 = (has_head(v402_8) ? constant_10 : Space{});
          Space v402_11;
          if (!v402_9.empty()) {
            Space v407_10_result;
            for (int v407_10_label = 1; v407_10_label <= 2; ++v407_10_label) {
              const Space v407_10_tail = child(v401_3_tail,v407_10_label);
              if (v407_10_tail.empty()) continue;
              const Path v407_10_head{v407_10_label};
              const Space v408_2 = singleton(v407_10_head);
              const Space v408_3 = intersect(constant_9,v408_2);
              const Space v408_4 = (has_head(v408_3) ? constant_10 : Space{});
              const Space v408_5 = subtract(constant_0,v408_4);
              Space v408_8;
              if (!v408_5.empty()) {
                const Path v409_6 = concat_path(v401_3_head,v407_10_head);
                const Space v409_7 = routine_50(c, v409_6, v407_10_tail);
                v408_8 = compose(v408_5,v409_7);
              }
              const Space v408_9 = intersect(constant_9,v408_2);
              const Space v408_10 = (has_head(v408_9) ? constant_10 : Space{});
              Space v408_12;
              if (!v408_10.empty()) {
                const Path v410_6 = concat_path(v401_3_head,v407_10_head);
                const Space v410_11 = routine_52(c, v410_6, v407_10_tail);
                v408_12 = compose(v408_10,v410_11);
              }
              const Space v408_13 = unite(v408_8,v408_12);
              v407_10_result = unite(v407_10_result,v408_13);
            }
            const Space v407_10 = std::move(v407_10_result);
            v402_11 = compose(v402_9,v407_10);
          }
          const Space v402_12 = unite(v402_7,v402_11);
          v401_3_result = unite(v401_3_result,v402_12);
        }
        const Space v401_3 = std::move(v401_3_result);
        const Space v401_4 = unite(v401_3,v390_14);
        const Space v401_5 = intersect(v401_4,s3);
        Space v390_14_next = unite(v390_14,v401_5);
        if (equal(v390_14_next,v390_14)) break;
        v390_14 = std::move(v390_14_next);
      }
      const Space v390_15 = subtract(v390_13,v390_14);
      const Space v390_16 = routine_15(c, v264_154_head, v264_154_tail, s1, s2, v390_15);
      v368_17 = compose(v368_12,v390_16);
    }
    const Space v368_18 = unite(v368_10,v368_17);
    v264_154_result = unite(v264_154_result,v368_18);
  }
  const Space v264_154 = std::move(v264_154_result);
  const Space v264_155 = unite(v264_92,v264_154);
  Space v264_165 = v264_5;
  for (;;) {
    const Space v411_1 = intersect(v264_165,s3);
    const Space v411_2 = restrict_to(s1,v411_1);
    Space v411_3_result;
    for (int v411_3_label = 1; v411_3_label <= 2; ++v411_3_label) {
      const Space v411_3_tail = child(v411_2,v411_3_label);
      if (v411_3_tail.empty()) continue;
      const Path v411_3_head{v411_3_label};
      const Space v412_2 = singleton(v411_3_head);
      const Space v412_3 = intersect(constant_9,v412_2);
      const Space v412_4 = (has_head(v412_3) ? constant_10 : Space{});
      const Space v412_5 = subtract(constant_0,v412_4);
      Space v412_7;
      if (!v412_5.empty()) {
        Space v413_6_result;
        for (int v413_6_label = 1; v413_6_label <= 2; ++v413_6_label) {
          const Space v413_6_tail = child(v411_3_tail,v413_6_label);
          if (v413_6_tail.empty()) continue;
          const Path v413_6_head{v413_6_label};
          const Space v414_2 = singleton(v413_6_head);
          const Space v414_3 = intersect(constant_9,v414_2);
          const Space v414_4 = (has_head(v414_3) ? constant_10 : Space{});
          const Space v414_5 = subtract(constant_0,v414_4);
          Space v414_8;
          if (!v414_5.empty()) {
            const Path v415_6 = concat_path(v411_3_head,v413_6_head);
            const Space v415_7 = routine_50(c, v415_6, v413_6_tail);
            v414_8 = compose(v414_5,v415_7);
          }
          const Space v414_9 = intersect(constant_9,v414_2);
          const Space v414_10 = (has_head(v414_9) ? constant_10 : Space{});
          Space v414_12;
          if (!v414_10.empty()) {
            const Path v416_6 = concat_path(v411_3_head,v413_6_head);
            const Space v416_11 = routine_51(c, v416_6, v413_6_tail);
            v414_12 = compose(v414_10,v416_11);
          }
          const Space v414_13 = unite(v414_8,v414_12);
          v413_6_result = unite(v413_6_result,v414_13);
        }
        const Space v413_6 = std::move(v413_6_result);
        v412_7 = compose(v412_5,v413_6);
      }
      const Space v412_8 = intersect(constant_9,v412_2);
      const Space v412_9 = (has_head(v412_8) ? constant_10 : Space{});
      Space v412_11;
      if (!v412_9.empty()) {
        Space v417_10_result;
        for (int v417_10_label = 1; v417_10_label <= 2; ++v417_10_label) {
          const Space v417_10_tail = child(v411_3_tail,v417_10_label);
          if (v417_10_tail.empty()) continue;
          const Path v417_10_head{v417_10_label};
          const Space v418_2 = singleton(v417_10_head);
          const Space v418_3 = intersect(constant_9,v418_2);
          const Space v418_4 = (has_head(v418_3) ? constant_10 : Space{});
          const Space v418_5 = subtract(constant_0,v418_4);
          Space v418_8;
          if (!v418_5.empty()) {
            const Path v419_6 = concat_path(v411_3_head,v417_10_head);
            const Space v419_7 = routine_50(c, v419_6, v417_10_tail);
            v418_8 = compose(v418_5,v419_7);
          }
          const Space v418_9 = intersect(constant_9,v418_2);
          const Space v418_10 = (has_head(v418_9) ? constant_10 : Space{});
          Space v418_12;
          if (!v418_10.empty()) {
            const Path v420_6 = concat_path(v411_3_head,v417_10_head);
            const Space v420_11 = routine_52(c, v420_6, v417_10_tail);
            v418_12 = compose(v418_10,v420_11);
          }
          const Space v418_13 = unite(v418_8,v418_12);
          v417_10_result = unite(v417_10_result,v418_13);
        }
        const Space v417_10 = std::move(v417_10_result);
        v412_11 = compose(v412_9,v417_10);
      }
      const Space v412_12 = unite(v412_7,v412_11);
      v411_3_result = unite(v411_3_result,v412_12);
    }
    const Space v411_3 = std::move(v411_3_result);
    const Space v411_4 = unite(v411_3,v264_165);
    const Space v411_5 = intersect(v411_4,s3);
    Space v264_165_next = unite(v264_165,v411_5);
    if (equal(v264_165_next,v264_165)) break;
    v264_165 = std::move(v264_165_next);
  }
  Space v264_175 = v264_5;
  for (;;) {
    const Space v421_1 = intersect(v264_175,s3);
    const Space v421_2 = restrict_to(s2,v421_1);
    Space v421_3_result;
    for (int v421_3_label = 1; v421_3_label <= 2; ++v421_3_label) {
      const Space v421_3_tail = child(v421_2,v421_3_label);
      if (v421_3_tail.empty()) continue;
      const Path v421_3_head{v421_3_label};
      const Space v422_2 = singleton(v421_3_head);
      const Space v422_3 = intersect(constant_9,v422_2);
      const Space v422_4 = (has_head(v422_3) ? constant_10 : Space{});
      const Space v422_5 = subtract(constant_0,v422_4);
      Space v422_7;
      if (!v422_5.empty()) {
        Space v423_6_result;
        for (int v423_6_label = 1; v423_6_label <= 2; ++v423_6_label) {
          const Space v423_6_tail = child(v421_3_tail,v423_6_label);
          if (v423_6_tail.empty()) continue;
          const Path v423_6_head{v423_6_label};
          const Space v424_2 = singleton(v423_6_head);
          const Space v424_3 = intersect(constant_9,v424_2);
          const Space v424_4 = (has_head(v424_3) ? constant_10 : Space{});
          const Space v424_5 = subtract(constant_0,v424_4);
          Space v424_8;
          if (!v424_5.empty()) {
            const Path v425_6 = concat_path(v421_3_head,v423_6_head);
            const Space v425_7 = routine_50(c, v425_6, v423_6_tail);
            v424_8 = compose(v424_5,v425_7);
          }
          const Space v424_9 = intersect(constant_9,v424_2);
          const Space v424_10 = (has_head(v424_9) ? constant_10 : Space{});
          Space v424_12;
          if (!v424_10.empty()) {
            const Path v426_6 = concat_path(v421_3_head,v423_6_head);
            const Space v426_11 = routine_51(c, v426_6, v423_6_tail);
            v424_12 = compose(v424_10,v426_11);
          }
          const Space v424_13 = unite(v424_8,v424_12);
          v423_6_result = unite(v423_6_result,v424_13);
        }
        const Space v423_6 = std::move(v423_6_result);
        v422_7 = compose(v422_5,v423_6);
      }
      const Space v422_8 = intersect(constant_9,v422_2);
      const Space v422_9 = (has_head(v422_8) ? constant_10 : Space{});
      Space v422_11;
      if (!v422_9.empty()) {
        Space v427_10_result;
        for (int v427_10_label = 1; v427_10_label <= 2; ++v427_10_label) {
          const Space v427_10_tail = child(v421_3_tail,v427_10_label);
          if (v427_10_tail.empty()) continue;
          const Path v427_10_head{v427_10_label};
          const Space v428_2 = singleton(v427_10_head);
          const Space v428_3 = intersect(constant_9,v428_2);
          const Space v428_4 = (has_head(v428_3) ? constant_10 : Space{});
          const Space v428_5 = subtract(constant_0,v428_4);
          Space v428_8;
          if (!v428_5.empty()) {
            const Path v429_6 = concat_path(v421_3_head,v427_10_head);
            const Space v429_7 = routine_50(c, v429_6, v427_10_tail);
            v428_8 = compose(v428_5,v429_7);
          }
          const Space v428_9 = intersect(constant_9,v428_2);
          const Space v428_10 = (has_head(v428_9) ? constant_10 : Space{});
          Space v428_12;
          if (!v428_10.empty()) {
            const Path v430_6 = concat_path(v421_3_head,v427_10_head);
            const Space v430_11 = routine_52(c, v430_6, v427_10_tail);
            v428_12 = compose(v428_10,v430_11);
          }
          const Space v428_13 = unite(v428_8,v428_12);
          v427_10_result = unite(v427_10_result,v428_13);
        }
        const Space v427_10 = std::move(v427_10_result);
        v422_11 = compose(v422_9,v427_10);
      }
      const Space v422_12 = unite(v422_7,v422_11);
      v421_3_result = unite(v421_3_result,v422_12);
    }
    const Space v421_3 = std::move(v421_3_result);
    const Space v421_4 = unite(v421_3,v264_175);
    const Space v421_5 = intersect(v421_4,s3);
    Space v264_175_next = unite(v264_175,v421_5);
    if (equal(v264_175_next,v264_175)) break;
    v264_175 = std::move(v264_175_next);
  }
  const Space v264_176 = subtract(v264_165,v264_175);
  const Space v264_177 = routine_10(c, v264_176);
  Space v264_217_result;
  for (int v264_217_label = 1; v264_217_label <= 2; ++v264_217_label) {
    const Space v264_217_tail = child(v264_177,v264_217_label);
    if (v264_217_tail.empty()) continue;
    const Path v264_217_head{v264_217_label};
    const Space v431_2 = singleton(v264_217_head);
    const Space v431_3 = intersect(constant_9,v431_2);
    const Space v431_4 = (has_head(v431_3) ? constant_10 : Space{});
    const Space v431_5 = subtract(constant_0,v431_4);
    Space v431_10;
    if (!v431_5.empty()) {
      Space v432_6 = v264_5;
      for (;;) {
        const Space v433_1 = intersect(v432_6,s3);
        const Space v433_2 = restrict_to(s1,v433_1);
        Space v433_3_result;
        for (int v433_3_label = 1; v433_3_label <= 2; ++v433_3_label) {
          const Space v433_3_tail = child(v433_2,v433_3_label);
          if (v433_3_tail.empty()) continue;
          const Path v433_3_head{v433_3_label};
          const Space v434_2 = singleton(v433_3_head);
          const Space v434_3 = intersect(constant_9,v434_2);
          const Space v434_4 = (has_head(v434_3) ? constant_10 : Space{});
          const Space v434_5 = subtract(constant_0,v434_4);
          Space v434_7;
          if (!v434_5.empty()) {
            Space v435_6_result;
            for (int v435_6_label = 1; v435_6_label <= 2; ++v435_6_label) {
              const Space v435_6_tail = child(v433_3_tail,v435_6_label);
              if (v435_6_tail.empty()) continue;
              const Path v435_6_head{v435_6_label};
              const Space v436_2 = singleton(v435_6_head);
              const Space v436_3 = intersect(constant_9,v436_2);
              const Space v436_4 = (has_head(v436_3) ? constant_10 : Space{});
              const Space v436_5 = subtract(constant_0,v436_4);
              Space v436_8;
              if (!v436_5.empty()) {
                const Path v437_6 = concat_path(v433_3_head,v435_6_head);
                const Space v437_7 = routine_50(c, v437_6, v435_6_tail);
                v436_8 = compose(v436_5,v437_7);
              }
              const Space v436_9 = intersect(constant_9,v436_2);
              const Space v436_10 = (has_head(v436_9) ? constant_10 : Space{});
              Space v436_12;
              if (!v436_10.empty()) {
                const Path v438_6 = concat_path(v433_3_head,v435_6_head);
                const Space v438_11 = routine_51(c, v438_6, v435_6_tail);
                v436_12 = compose(v436_10,v438_11);
              }
              const Space v436_13 = unite(v436_8,v436_12);
              v435_6_result = unite(v435_6_result,v436_13);
            }
            const Space v435_6 = std::move(v435_6_result);
            v434_7 = compose(v434_5,v435_6);
          }
          const Space v434_8 = intersect(constant_9,v434_2);
          const Space v434_9 = (has_head(v434_8) ? constant_10 : Space{});
          Space v434_11;
          if (!v434_9.empty()) {
            Space v439_10_result;
            for (int v439_10_label = 1; v439_10_label <= 2; ++v439_10_label) {
              const Space v439_10_tail = child(v433_3_tail,v439_10_label);
              if (v439_10_tail.empty()) continue;
              const Path v439_10_head{v439_10_label};
              const Space v440_2 = singleton(v439_10_head);
              const Space v440_3 = intersect(constant_9,v440_2);
              const Space v440_4 = (has_head(v440_3) ? constant_10 : Space{});
              const Space v440_5 = subtract(constant_0,v440_4);
              Space v440_8;
              if (!v440_5.empty()) {
                const Path v441_6 = concat_path(v433_3_head,v439_10_head);
                const Space v441_7 = routine_50(c, v441_6, v439_10_tail);
                v440_8 = compose(v440_5,v441_7);
              }
              const Space v440_9 = intersect(constant_9,v440_2);
              const Space v440_10 = (has_head(v440_9) ? constant_10 : Space{});
              Space v440_12;
              if (!v440_10.empty()) {
                const Path v442_6 = concat_path(v433_3_head,v439_10_head);
                const Space v442_11 = routine_52(c, v442_6, v439_10_tail);
                v440_12 = compose(v440_10,v442_11);
              }
              const Space v440_13 = unite(v440_8,v440_12);
              v439_10_result = unite(v439_10_result,v440_13);
            }
            const Space v439_10 = std::move(v439_10_result);
            v434_11 = compose(v434_9,v439_10);
          }
          const Space v434_12 = unite(v434_7,v434_11);
          v433_3_result = unite(v433_3_result,v434_12);
        }
        const Space v433_3 = std::move(v433_3_result);
        const Space v433_4 = unite(v433_3,v432_6);
        const Space v433_5 = intersect(v433_4,s3);
        Space v432_6_next = unite(v432_6,v433_5);
        if (equal(v432_6_next,v432_6)) break;
        v432_6 = std::move(v432_6_next);
      }
      Space v432_7 = v264_5;
      for (;;) {
        const Space v443_1 = intersect(v432_7,s3);
        const Space v443_2 = restrict_to(s2,v443_1);
        Space v443_3_result;
        for (int v443_3_label = 1; v443_3_label <= 2; ++v443_3_label) {
          const Space v443_3_tail = child(v443_2,v443_3_label);
          if (v443_3_tail.empty()) continue;
          const Path v443_3_head{v443_3_label};
          const Space v444_2 = singleton(v443_3_head);
          const Space v444_3 = intersect(constant_9,v444_2);
          const Space v444_4 = (has_head(v444_3) ? constant_10 : Space{});
          const Space v444_5 = subtract(constant_0,v444_4);
          Space v444_7;
          if (!v444_5.empty()) {
            Space v445_6_result;
            for (int v445_6_label = 1; v445_6_label <= 2; ++v445_6_label) {
              const Space v445_6_tail = child(v443_3_tail,v445_6_label);
              if (v445_6_tail.empty()) continue;
              const Path v445_6_head{v445_6_label};
              const Space v446_2 = singleton(v445_6_head);
              const Space v446_3 = intersect(constant_9,v446_2);
              const Space v446_4 = (has_head(v446_3) ? constant_10 : Space{});
              const Space v446_5 = subtract(constant_0,v446_4);
              Space v446_8;
              if (!v446_5.empty()) {
                const Path v447_6 = concat_path(v443_3_head,v445_6_head);
                const Space v447_7 = routine_50(c, v447_6, v445_6_tail);
                v446_8 = compose(v446_5,v447_7);
              }
              const Space v446_9 = intersect(constant_9,v446_2);
              const Space v446_10 = (has_head(v446_9) ? constant_10 : Space{});
              Space v446_12;
              if (!v446_10.empty()) {
                const Path v448_6 = concat_path(v443_3_head,v445_6_head);
                const Space v448_11 = routine_51(c, v448_6, v445_6_tail);
                v446_12 = compose(v446_10,v448_11);
              }
              const Space v446_13 = unite(v446_8,v446_12);
              v445_6_result = unite(v445_6_result,v446_13);
            }
            const Space v445_6 = std::move(v445_6_result);
            v444_7 = compose(v444_5,v445_6);
          }
          const Space v444_8 = intersect(constant_9,v444_2);
          const Space v444_9 = (has_head(v444_8) ? constant_10 : Space{});
          Space v444_11;
          if (!v444_9.empty()) {
            Space v449_10_result;
            for (int v449_10_label = 1; v449_10_label <= 2; ++v449_10_label) {
              const Space v449_10_tail = child(v443_3_tail,v449_10_label);
              if (v449_10_tail.empty()) continue;
              const Path v449_10_head{v449_10_label};
              const Space v450_2 = singleton(v449_10_head);
              const Space v450_3 = intersect(constant_9,v450_2);
              const Space v450_4 = (has_head(v450_3) ? constant_10 : Space{});
              const Space v450_5 = subtract(constant_0,v450_4);
              Space v450_8;
              if (!v450_5.empty()) {
                const Path v451_6 = concat_path(v443_3_head,v449_10_head);
                const Space v451_7 = routine_50(c, v451_6, v449_10_tail);
                v450_8 = compose(v450_5,v451_7);
              }
              const Space v450_9 = intersect(constant_9,v450_2);
              const Space v450_10 = (has_head(v450_9) ? constant_10 : Space{});
              Space v450_12;
              if (!v450_10.empty()) {
                const Path v452_6 = concat_path(v443_3_head,v449_10_head);
                const Space v452_11 = routine_52(c, v452_6, v449_10_tail);
                v450_12 = compose(v450_10,v452_11);
              }
              const Space v450_13 = unite(v450_8,v450_12);
              v449_10_result = unite(v449_10_result,v450_13);
            }
            const Space v449_10 = std::move(v449_10_result);
            v444_11 = compose(v444_9,v449_10);
          }
          const Space v444_12 = unite(v444_7,v444_11);
          v443_3_result = unite(v443_3_result,v444_12);
        }
        const Space v443_3 = std::move(v443_3_result);
        const Space v443_4 = unite(v443_3,v432_7);
        const Space v443_5 = intersect(v443_4,s3);
        Space v432_7_next = unite(v432_7,v443_5);
        if (equal(v432_7_next,v432_7)) break;
        v432_7 = std::move(v432_7_next);
      }
      const Space v432_8 = subtract(v432_6,v432_7);
      const Space v432_9 = routine_14(c, v264_217_head, v264_217_tail, s1, s2, v432_8);
      v431_10 = compose(v431_5,v432_9);
    }
    const Space v431_11 = intersect(constant_9,v431_2);
    const Space v431_12 = (has_head(v431_11) ? constant_10 : Space{});
    Space v431_17;
    if (!v431_12.empty()) {
      Space v453_13 = v264_5;
      for (;;) {
        const Space v454_1 = intersect(v453_13,s3);
        const Space v454_2 = restrict_to(s1,v454_1);
        Space v454_3_result;
        for (int v454_3_label = 1; v454_3_label <= 2; ++v454_3_label) {
          const Space v454_3_tail = child(v454_2,v454_3_label);
          if (v454_3_tail.empty()) continue;
          const Path v454_3_head{v454_3_label};
          const Space v455_2 = singleton(v454_3_head);
          const Space v455_3 = intersect(constant_9,v455_2);
          const Space v455_4 = (has_head(v455_3) ? constant_10 : Space{});
          const Space v455_5 = subtract(constant_0,v455_4);
          Space v455_7;
          if (!v455_5.empty()) {
            Space v456_6_result;
            for (int v456_6_label = 1; v456_6_label <= 2; ++v456_6_label) {
              const Space v456_6_tail = child(v454_3_tail,v456_6_label);
              if (v456_6_tail.empty()) continue;
              const Path v456_6_head{v456_6_label};
              const Space v457_2 = singleton(v456_6_head);
              const Space v457_3 = intersect(constant_9,v457_2);
              const Space v457_4 = (has_head(v457_3) ? constant_10 : Space{});
              const Space v457_5 = subtract(constant_0,v457_4);
              Space v457_8;
              if (!v457_5.empty()) {
                const Path v458_6 = concat_path(v454_3_head,v456_6_head);
                const Space v458_7 = routine_50(c, v458_6, v456_6_tail);
                v457_8 = compose(v457_5,v458_7);
              }
              const Space v457_9 = intersect(constant_9,v457_2);
              const Space v457_10 = (has_head(v457_9) ? constant_10 : Space{});
              Space v457_12;
              if (!v457_10.empty()) {
                const Path v459_6 = concat_path(v454_3_head,v456_6_head);
                const Space v459_11 = routine_51(c, v459_6, v456_6_tail);
                v457_12 = compose(v457_10,v459_11);
              }
              const Space v457_13 = unite(v457_8,v457_12);
              v456_6_result = unite(v456_6_result,v457_13);
            }
            const Space v456_6 = std::move(v456_6_result);
            v455_7 = compose(v455_5,v456_6);
          }
          const Space v455_8 = intersect(constant_9,v455_2);
          const Space v455_9 = (has_head(v455_8) ? constant_10 : Space{});
          Space v455_11;
          if (!v455_9.empty()) {
            Space v460_10_result;
            for (int v460_10_label = 1; v460_10_label <= 2; ++v460_10_label) {
              const Space v460_10_tail = child(v454_3_tail,v460_10_label);
              if (v460_10_tail.empty()) continue;
              const Path v460_10_head{v460_10_label};
              const Space v461_2 = singleton(v460_10_head);
              const Space v461_3 = intersect(constant_9,v461_2);
              const Space v461_4 = (has_head(v461_3) ? constant_10 : Space{});
              const Space v461_5 = subtract(constant_0,v461_4);
              Space v461_8;
              if (!v461_5.empty()) {
                const Path v462_6 = concat_path(v454_3_head,v460_10_head);
                const Space v462_7 = routine_50(c, v462_6, v460_10_tail);
                v461_8 = compose(v461_5,v462_7);
              }
              const Space v461_9 = intersect(constant_9,v461_2);
              const Space v461_10 = (has_head(v461_9) ? constant_10 : Space{});
              Space v461_12;
              if (!v461_10.empty()) {
                const Path v463_6 = concat_path(v454_3_head,v460_10_head);
                const Space v463_11 = routine_52(c, v463_6, v460_10_tail);
                v461_12 = compose(v461_10,v463_11);
              }
              const Space v461_13 = unite(v461_8,v461_12);
              v460_10_result = unite(v460_10_result,v461_13);
            }
            const Space v460_10 = std::move(v460_10_result);
            v455_11 = compose(v455_9,v460_10);
          }
          const Space v455_12 = unite(v455_7,v455_11);
          v454_3_result = unite(v454_3_result,v455_12);
        }
        const Space v454_3 = std::move(v454_3_result);
        const Space v454_4 = unite(v454_3,v453_13);
        const Space v454_5 = intersect(v454_4,s3);
        Space v453_13_next = unite(v453_13,v454_5);
        if (equal(v453_13_next,v453_13)) break;
        v453_13 = std::move(v453_13_next);
      }
      Space v453_14 = v264_5;
      for (;;) {
        const Space v464_1 = intersect(v453_14,s3);
        const Space v464_2 = restrict_to(s2,v464_1);
        Space v464_3_result;
        for (int v464_3_label = 1; v464_3_label <= 2; ++v464_3_label) {
          const Space v464_3_tail = child(v464_2,v464_3_label);
          if (v464_3_tail.empty()) continue;
          const Path v464_3_head{v464_3_label};
          const Space v465_2 = singleton(v464_3_head);
          const Space v465_3 = intersect(constant_9,v465_2);
          const Space v465_4 = (has_head(v465_3) ? constant_10 : Space{});
          const Space v465_5 = subtract(constant_0,v465_4);
          Space v465_7;
          if (!v465_5.empty()) {
            Space v466_6_result;
            for (int v466_6_label = 1; v466_6_label <= 2; ++v466_6_label) {
              const Space v466_6_tail = child(v464_3_tail,v466_6_label);
              if (v466_6_tail.empty()) continue;
              const Path v466_6_head{v466_6_label};
              const Space v467_2 = singleton(v466_6_head);
              const Space v467_3 = intersect(constant_9,v467_2);
              const Space v467_4 = (has_head(v467_3) ? constant_10 : Space{});
              const Space v467_5 = subtract(constant_0,v467_4);
              Space v467_8;
              if (!v467_5.empty()) {
                const Path v468_6 = concat_path(v464_3_head,v466_6_head);
                const Space v468_7 = routine_50(c, v468_6, v466_6_tail);
                v467_8 = compose(v467_5,v468_7);
              }
              const Space v467_9 = intersect(constant_9,v467_2);
              const Space v467_10 = (has_head(v467_9) ? constant_10 : Space{});
              Space v467_12;
              if (!v467_10.empty()) {
                const Path v469_6 = concat_path(v464_3_head,v466_6_head);
                const Space v469_11 = routine_51(c, v469_6, v466_6_tail);
                v467_12 = compose(v467_10,v469_11);
              }
              const Space v467_13 = unite(v467_8,v467_12);
              v466_6_result = unite(v466_6_result,v467_13);
            }
            const Space v466_6 = std::move(v466_6_result);
            v465_7 = compose(v465_5,v466_6);
          }
          const Space v465_8 = intersect(constant_9,v465_2);
          const Space v465_9 = (has_head(v465_8) ? constant_10 : Space{});
          Space v465_11;
          if (!v465_9.empty()) {
            Space v470_10_result;
            for (int v470_10_label = 1; v470_10_label <= 2; ++v470_10_label) {
              const Space v470_10_tail = child(v464_3_tail,v470_10_label);
              if (v470_10_tail.empty()) continue;
              const Path v470_10_head{v470_10_label};
              const Space v471_2 = singleton(v470_10_head);
              const Space v471_3 = intersect(constant_9,v471_2);
              const Space v471_4 = (has_head(v471_3) ? constant_10 : Space{});
              const Space v471_5 = subtract(constant_0,v471_4);
              Space v471_8;
              if (!v471_5.empty()) {
                const Path v472_6 = concat_path(v464_3_head,v470_10_head);
                const Space v472_7 = routine_50(c, v472_6, v470_10_tail);
                v471_8 = compose(v471_5,v472_7);
              }
              const Space v471_9 = intersect(constant_9,v471_2);
              const Space v471_10 = (has_head(v471_9) ? constant_10 : Space{});
              Space v471_12;
              if (!v471_10.empty()) {
                const Path v473_6 = concat_path(v464_3_head,v470_10_head);
                const Space v473_11 = routine_52(c, v473_6, v470_10_tail);
                v471_12 = compose(v471_10,v473_11);
              }
              const Space v471_13 = unite(v471_8,v471_12);
              v470_10_result = unite(v470_10_result,v471_13);
            }
            const Space v470_10 = std::move(v470_10_result);
            v465_11 = compose(v465_9,v470_10);
          }
          const Space v465_12 = unite(v465_7,v465_11);
          v464_3_result = unite(v464_3_result,v465_12);
        }
        const Space v464_3 = std::move(v464_3_result);
        const Space v464_4 = unite(v464_3,v453_14);
        const Space v464_5 = intersect(v464_4,s3);
        Space v453_14_next = unite(v453_14,v464_5);
        if (equal(v453_14_next,v453_14)) break;
        v453_14 = std::move(v453_14_next);
      }
      const Space v453_15 = subtract(v453_13,v453_14);
      const Space v453_16 = routine_15(c, v264_217_head, v264_217_tail, s1, s2, v453_15);
      v431_17 = compose(v431_12,v453_16);
    }
    const Space v431_18 = unite(v431_10,v431_17);
    v264_217_result = unite(v264_217_result,v431_18);
  }
  const Space v264_217 = std::move(v264_217_result);
  const Space v264_218 = unite(v264_155,v264_217);
  return v264_218;
}

static Space routine_38(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v474_3 = intersect(s1,s2);
  const Space v474_4 = restrict_to(s0,v474_3);
  Space v474_14_result;
  for (int v474_14_label = 1; v474_14_label <= 2; ++v474_14_label) {
    const Space v474_14_tail = child(v474_4,v474_14_label);
    if (v474_14_tail.empty()) continue;
    const Path v474_14_head{v474_14_label};
    const Space v475_2 = singleton(v474_14_head);
    const Space v475_3 = intersect(constant_9,v475_2);
    const Space v475_4 = (has_head(v475_3) ? constant_10 : Space{});
    const Space v475_5 = subtract(constant_0,v475_4);
    Space v475_7;
    if (!v475_5.empty()) {
      Space v476_6_result;
      for (int v476_6_label = 1; v476_6_label <= 2; ++v476_6_label) {
        const Space v476_6_tail = child(v474_14_tail,v476_6_label);
        if (v476_6_tail.empty()) continue;
        const Path v476_6_head{v476_6_label};
        const Space v477_2 = singleton(v476_6_head);
        const Space v477_3 = intersect(constant_9,v477_2);
        const Space v477_4 = (has_head(v477_3) ? constant_10 : Space{});
        const Space v477_5 = subtract(constant_0,v477_4);
        Space v477_8;
        if (!v477_5.empty()) {
          const Path v478_6 = concat_path(v474_14_head,v476_6_head);
          const Space v478_7 = routine_50(c, v478_6, v476_6_tail);
          v477_8 = compose(v477_5,v478_7);
        }
        const Space v477_9 = intersect(constant_9,v477_2);
        const Space v477_10 = (has_head(v477_9) ? constant_10 : Space{});
        Space v477_12;
        if (!v477_10.empty()) {
          const Path v479_6 = concat_path(v474_14_head,v476_6_head);
          const Space v479_11 = routine_51(c, v479_6, v476_6_tail);
          v477_12 = compose(v477_10,v479_11);
        }
        const Space v477_13 = unite(v477_8,v477_12);
        v476_6_result = unite(v476_6_result,v477_13);
      }
      const Space v476_6 = std::move(v476_6_result);
      v475_7 = compose(v475_5,v476_6);
    }
    const Space v475_8 = intersect(constant_9,v475_2);
    const Space v475_9 = (has_head(v475_8) ? constant_10 : Space{});
    Space v475_11;
    if (!v475_9.empty()) {
      Space v480_10_result;
      for (int v480_10_label = 1; v480_10_label <= 2; ++v480_10_label) {
        const Space v480_10_tail = child(v474_14_tail,v480_10_label);
        if (v480_10_tail.empty()) continue;
        const Path v480_10_head{v480_10_label};
        const Space v481_2 = singleton(v480_10_head);
        const Space v481_3 = intersect(constant_9,v481_2);
        const Space v481_4 = (has_head(v481_3) ? constant_10 : Space{});
        const Space v481_5 = subtract(constant_0,v481_4);
        Space v481_8;
        if (!v481_5.empty()) {
          const Path v482_6 = concat_path(v474_14_head,v480_10_head);
          const Space v482_7 = routine_50(c, v482_6, v480_10_tail);
          v481_8 = compose(v481_5,v482_7);
        }
        const Space v481_9 = intersect(constant_9,v481_2);
        const Space v481_10 = (has_head(v481_9) ? constant_10 : Space{});
        Space v481_12;
        if (!v481_10.empty()) {
          const Path v483_6 = concat_path(v474_14_head,v480_10_head);
          const Space v483_11 = routine_52(c, v483_6, v480_10_tail);
          v481_12 = compose(v481_10,v483_11);
        }
        const Space v481_13 = unite(v481_8,v481_12);
        v480_10_result = unite(v480_10_result,v481_13);
      }
      const Space v480_10 = std::move(v480_10_result);
      v475_11 = compose(v475_9,v480_10);
    }
    const Space v475_12 = unite(v475_7,v475_11);
    v474_14_result = unite(v474_14_result,v475_12);
  }
  const Space v474_14 = std::move(v474_14_result);
  const Space v474_15 = unite(v474_14,s2);
  const Space v474_16 = intersect(v474_15,s1);
  Space v474_26 = v474_16;
  for (;;) {
    const Space v484_1 = intersect(v474_26,s1);
    const Space v484_2 = restrict_to(s0,v484_1);
    Space v484_3_result;
    for (int v484_3_label = 1; v484_3_label <= 2; ++v484_3_label) {
      const Space v484_3_tail = child(v484_2,v484_3_label);
      if (v484_3_tail.empty()) continue;
      const Path v484_3_head{v484_3_label};
      const Space v485_2 = singleton(v484_3_head);
      const Space v485_3 = intersect(constant_9,v485_2);
      const Space v485_4 = (has_head(v485_3) ? constant_10 : Space{});
      const Space v485_5 = subtract(constant_0,v485_4);
      Space v485_7;
      if (!v485_5.empty()) {
        Space v486_6_result;
        for (int v486_6_label = 1; v486_6_label <= 2; ++v486_6_label) {
          const Space v486_6_tail = child(v484_3_tail,v486_6_label);
          if (v486_6_tail.empty()) continue;
          const Path v486_6_head{v486_6_label};
          const Space v487_2 = singleton(v486_6_head);
          const Space v487_3 = intersect(constant_9,v487_2);
          const Space v487_4 = (has_head(v487_3) ? constant_10 : Space{});
          const Space v487_5 = subtract(constant_0,v487_4);
          Space v487_8;
          if (!v487_5.empty()) {
            const Path v488_6 = concat_path(v484_3_head,v486_6_head);
            const Space v488_7 = routine_50(c, v488_6, v486_6_tail);
            v487_8 = compose(v487_5,v488_7);
          }
          const Space v487_9 = intersect(constant_9,v487_2);
          const Space v487_10 = (has_head(v487_9) ? constant_10 : Space{});
          Space v487_12;
          if (!v487_10.empty()) {
            const Path v489_6 = concat_path(v484_3_head,v486_6_head);
            const Space v489_11 = routine_51(c, v489_6, v486_6_tail);
            v487_12 = compose(v487_10,v489_11);
          }
          const Space v487_13 = unite(v487_8,v487_12);
          v486_6_result = unite(v486_6_result,v487_13);
        }
        const Space v486_6 = std::move(v486_6_result);
        v485_7 = compose(v485_5,v486_6);
      }
      const Space v485_8 = intersect(constant_9,v485_2);
      const Space v485_9 = (has_head(v485_8) ? constant_10 : Space{});
      Space v485_11;
      if (!v485_9.empty()) {
        Space v490_10_result;
        for (int v490_10_label = 1; v490_10_label <= 2; ++v490_10_label) {
          const Space v490_10_tail = child(v484_3_tail,v490_10_label);
          if (v490_10_tail.empty()) continue;
          const Path v490_10_head{v490_10_label};
          const Space v491_2 = singleton(v490_10_head);
          const Space v491_3 = intersect(constant_9,v491_2);
          const Space v491_4 = (has_head(v491_3) ? constant_10 : Space{});
          const Space v491_5 = subtract(constant_0,v491_4);
          Space v491_8;
          if (!v491_5.empty()) {
            const Path v492_6 = concat_path(v484_3_head,v490_10_head);
            const Space v492_7 = routine_50(c, v492_6, v490_10_tail);
            v491_8 = compose(v491_5,v492_7);
          }
          const Space v491_9 = intersect(constant_9,v491_2);
          const Space v491_10 = (has_head(v491_9) ? constant_10 : Space{});
          Space v491_12;
          if (!v491_10.empty()) {
            const Path v493_6 = concat_path(v484_3_head,v490_10_head);
            const Space v493_11 = routine_52(c, v493_6, v490_10_tail);
            v491_12 = compose(v491_10,v493_11);
          }
          const Space v491_13 = unite(v491_8,v491_12);
          v490_10_result = unite(v490_10_result,v491_13);
        }
        const Space v490_10 = std::move(v490_10_result);
        v485_11 = compose(v485_9,v490_10);
      }
      const Space v485_12 = unite(v485_7,v485_11);
      v484_3_result = unite(v484_3_result,v485_12);
    }
    const Space v484_3 = std::move(v484_3_result);
    const Space v484_4 = unite(v484_3,v474_26);
    const Space v484_5 = intersect(v484_4,s1);
    Space v474_26_next = unite(v474_26,v484_5);
    if (equal(v474_26_next,v474_26)) break;
    v474_26 = std::move(v474_26_next);
  }
  const Space v474_27 = unite(s2,v474_26);
  return v474_27;
}

static Space routine_39(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v494_3 = routine_53(c, s2);
  const Space v494_4 = subtract(s2,v494_3);
  Space v494_14_result;
  for (int v494_14_label = 1; v494_14_label <= 2; ++v494_14_label) {
    const Space v494_14_tail = child(v494_4,v494_14_label);
    if (v494_14_tail.empty()) continue;
    const Path v494_14_head{v494_14_label};
    const Space v495_2 = singleton(v494_14_head);
    const Space v495_3 = intersect(constant_9,v495_2);
    const Space v495_4 = (has_head(v495_3) ? constant_10 : Space{});
    const Space v495_5 = subtract(constant_0,v495_4);
    Space v495_7;
    if (!v495_5.empty()) {
      Space v496_6_result;
      for (int v496_6_label = 1; v496_6_label <= 2; ++v496_6_label) {
        const Space v496_6_tail = child(v494_14_tail,v496_6_label);
        if (v496_6_tail.empty()) continue;
        const Path v496_6_head{v496_6_label};
        const Space v497_2 = singleton(v496_6_head);
        const Space v497_3 = intersect(constant_9,v497_2);
        const Space v497_4 = (has_head(v497_3) ? constant_10 : Space{});
        const Space v497_5 = subtract(constant_0,v497_4);
        Space v497_8;
        if (!v497_5.empty()) {
          const Path v498_6 = concat_path(v494_14_head,v496_6_head);
          const Space v498_7 = routine_54(c, v498_6, v496_6_tail, s1, s0, s2);
          v497_8 = compose(v497_5,v498_7);
        }
        const Space v497_9 = intersect(constant_9,v497_2);
        const Space v497_10 = (has_head(v497_9) ? constant_10 : Space{});
        Space v497_12;
        if (!v497_10.empty()) {
          const Path v499_6 = concat_path(v494_14_head,v496_6_head);
          const Space v499_11 = routine_55(c, v499_6, v496_6_tail, s1, s0, s2);
          v497_12 = compose(v497_10,v499_11);
        }
        const Space v497_13 = unite(v497_8,v497_12);
        v496_6_result = unite(v496_6_result,v497_13);
      }
      const Space v496_6 = std::move(v496_6_result);
      v495_7 = compose(v495_5,v496_6);
    }
    const Space v495_8 = intersect(constant_9,v495_2);
    const Space v495_9 = (has_head(v495_8) ? constant_10 : Space{});
    Space v495_11;
    if (!v495_9.empty()) {
      Space v500_10_result;
      for (int v500_10_label = 1; v500_10_label <= 2; ++v500_10_label) {
        const Space v500_10_tail = child(v494_14_tail,v500_10_label);
        if (v500_10_tail.empty()) continue;
        const Path v500_10_head{v500_10_label};
        const Space v501_2 = singleton(v500_10_head);
        const Space v501_3 = intersect(constant_9,v501_2);
        const Space v501_4 = (has_head(v501_3) ? constant_10 : Space{});
        const Space v501_5 = subtract(constant_0,v501_4);
        Space v501_8;
        if (!v501_5.empty()) {
          const Path v502_6 = concat_path(v494_14_head,v500_10_head);
          const Space v502_7 = routine_54(c, v502_6, v500_10_tail, s1, s0, s2);
          v501_8 = compose(v501_5,v502_7);
        }
        const Space v501_9 = intersect(constant_9,v501_2);
        const Space v501_10 = (has_head(v501_9) ? constant_10 : Space{});
        Space v501_12;
        if (!v501_10.empty()) {
          const Path v503_6 = concat_path(v494_14_head,v500_10_head);
          const Space v503_11 = routine_37(c, v503_6, v500_10_tail, s1, s0, s2);
          v501_12 = compose(v501_10,v503_11);
        }
        const Space v501_13 = unite(v501_8,v501_12);
        v500_10_result = unite(v500_10_result,v501_13);
      }
      const Space v500_10 = std::move(v500_10_result);
      v495_11 = compose(v495_9,v500_10);
    }
    const Space v495_12 = unite(v495_7,v495_11);
    v494_14_result = unite(v494_14_result,v495_12);
  }
  const Space v494_14 = std::move(v494_14_result);
  return v494_14;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v504_5_result;
  for (int v504_5_label = 1; v504_5_label <= 2; ++v504_5_label) {
    const Space v504_5_tail = child(s0,v504_5_label);
    if (v504_5_tail.empty()) continue;
    const Path v504_5_head{v504_5_label};
    const Space v505_2 = singleton(v504_5_head);
    const Space v505_3 = intersect(constant_9,v505_2);
    const Space v505_4 = (has_head(v505_3) ? constant_10 : Space{});
    Space v505_7;
    if (!v505_4.empty()) {
      const Path v506_5 = concat_path(p0,v504_5_head);
      Space v506_6_result;
      for (int v506_6_label = 1; v506_6_label <= 2; ++v506_6_label) {
        const Space v506_6_tail = child(v504_5_tail,v506_6_label);
        if (v506_6_tail.empty()) continue;
        const Path v506_6_head{v506_6_label};
        const Space v507_2 = singleton(v506_6_head);
        const Space v507_3 = intersect(constant_9,v507_2);
        const Space v507_4 = (has_head(v507_3) ? constant_10 : Space{});
        Space v507_7;
        if (!v507_4.empty()) {
          const Path v508_5 = concat_path(v506_5,v506_6_head);
          const Space v508_6 = routine_24(c, v508_5, p1, v506_6_tail);
          v507_7 = compose(v507_4,v508_6);
        }
        v506_6_result = unite(v506_6_result,v507_7);
      }
      const Space v506_6 = std::move(v506_6_result);
      v505_7 = compose(v505_4,v506_6);
    }
    v504_5_result = unite(v504_5_result,v505_7);
  }
  const Space v504_5 = std::move(v504_5_result);
  return v504_5;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v509_4_result;
  for (int v509_4_label = 1; v509_4_label <= 2; ++v509_4_label) {
    const Space v509_4_tail = child(s0,v509_4_label);
    if (v509_4_tail.empty()) continue;
    const Path v509_4_head{v509_4_label};
    const Space v510_2 = singleton(v509_4_head);
    const Space v510_3 = intersect(constant_9,v510_2);
    const Space v510_4 = (has_head(v510_3) ? constant_10 : Space{});
    const Path v510_5 = concat_path(p0,v509_4_head);
    const Path v510_6 = concat_path(v510_5,p1);
    const Space v510_7 = singleton(v510_6);
    const Space v510_8 = compose(v510_4,v510_7);
    v509_4_result = unite(v509_4_result,v510_8);
  }
  const Space v509_4 = std::move(v509_4_result);
  return v509_4;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v511_3 = Space{};
  return v511_3;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v512_4_result;
  for (int v512_4_label = 1; v512_4_label <= 2; ++v512_4_label) {
    const Space v512_4_tail = child(s0,v512_4_label);
    if (v512_4_tail.empty()) continue;
    const Path v512_4_head{v512_4_label};
    const Space v513_2 = singleton(v512_4_head);
    const Space v513_3 = intersect(constant_9,v513_2);
    const Space v513_4 = (has_head(v513_3) ? constant_10 : Space{});
    const Path v513_5 = concat_path(p0,v512_4_head);
    const Path v513_6 = concat_path(v513_5,p1);
    const Space v513_7 = singleton(v513_6);
    const Space v513_8 = compose(v513_4,v513_7);
    v512_4_result = unite(v512_4_result,v513_8);
  }
  const Space v512_4 = std::move(v512_4_result);
  return v512_4;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  const Space v514_3 = unwrap(s0,p0);
  const Space v514_4 = first_matching(v514_3,constant_0,false);
  const Space v514_5 = intersect(constant_0,v514_4);
  const Space v514_6 = (has_head(v514_4) ? constant_10 : Space{});
  const Space v514_7 = unite(v514_5,v514_6);
  const Space v514_9 = compose(v514_7,constant_0);
  const Space v514_11 = subtract(constant_0,v514_4);
  const Space v514_12 = subtract(v514_11,v514_6);
  Space v514_16;
  if (!v514_12.empty()) {
    const Space v515_14 = first_fibonacci(v514_3,6,5,true);
    const Space v515_15 = routine_45(c, constant_12, v515_14, v514_3);
    v514_16 = compose(v514_12,v515_15);
  }
  const Space v514_17 = unite(v514_9,v514_16);
  const Space v514_18 = wrap(v514_17,p0);
  return v514_18;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v516_3 = first_matching(s0,constant_0,false);
  Space v516_7;
  if (!v516_3.empty()) {
    const Space v517_4 = unwrap(s1,p0);
    const Space v517_5 = routine_27(c, v517_4);
    const Space v517_6 = wrap(v517_5,p0);
    v516_7 = compose(v516_3,v517_6);
  }
  Space v516_8_result;
  for (int v516_8_label = 1; v516_8_label <= 2; ++v516_8_label) {
    const Space v516_8_tail = child(s0,v516_8_label);
    if (v516_8_tail.empty()) continue;
    const Path v516_8_head{v516_8_label};
    const Path v518_2 = concat_path(p0,v516_8_head);
    const Space v518_3 = routine_45(c, v518_2, v516_8_tail, s1);
    v516_8_result = unite(v516_8_result,v518_3);
  }
  const Space v516_8 = std::move(v516_8_result);
  const Space v516_9 = unite(v516_7,v516_8);
  return v516_9;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v519_5_result;
  for (int v519_5_label = 1; v519_5_label <= 2; ++v519_5_label) {
    const Space v519_5_tail = child(s0,v519_5_label);
    if (v519_5_tail.empty()) continue;
    const Path v519_5_head{v519_5_label};
    const Space v520_2 = singleton(v519_5_head);
    const Space v520_3 = intersect(constant_9,v520_2);
    const Space v520_4 = (has_head(v520_3) ? constant_10 : Space{});
    Space v520_7;
    if (!v520_4.empty()) {
      const Path v521_5 = concat_path(p0,v519_5_head);
      Space v521_6_result;
      for (int v521_6_label = 1; v521_6_label <= 2; ++v521_6_label) {
        const Space v521_6_tail = child(v519_5_tail,v521_6_label);
        if (v521_6_tail.empty()) continue;
        const Path v521_6_head{v521_6_label};
        const Space v522_2 = singleton(v521_6_head);
        const Space v522_3 = intersect(constant_9,v522_2);
        const Space v522_4 = (has_head(v522_3) ? constant_10 : Space{});
        Space v522_7;
        if (!v522_4.empty()) {
          const Path v523_5 = concat_path(v521_5,v521_6_head);
          const Space v523_6 = routine_34(c, v523_5, p1, v521_6_tail);
          v522_7 = compose(v522_4,v523_6);
        }
        v521_6_result = unite(v521_6_result,v522_7);
      }
      const Space v521_6 = std::move(v521_6_result);
      v520_7 = compose(v520_4,v521_6);
    }
    v519_5_result = unite(v519_5_result,v520_7);
  }
  const Space v519_5 = std::move(v519_5_result);
  return v519_5;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v524_4_result;
  for (int v524_4_label = 1; v524_4_label <= 2; ++v524_4_label) {
    const Space v524_4_tail = child(s0,v524_4_label);
    if (v524_4_tail.empty()) continue;
    const Path v524_4_head{v524_4_label};
    const Space v525_2 = singleton(v524_4_head);
    const Space v525_3 = intersect(constant_9,v525_2);
    const Space v525_4 = (has_head(v525_3) ? constant_10 : Space{});
    const Path v525_5 = concat_path(p0,v524_4_head);
    const Path v525_6 = concat_path(v525_5,p1);
    const Space v525_7 = singleton(v525_6);
    const Space v525_8 = compose(v525_4,v525_7);
    v524_4_result = unite(v524_4_result,v525_8);
  }
  const Space v524_4 = std::move(v524_4_result);
  return v524_4;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v526_3 = Space{};
  return v526_3;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v527_4_result;
  for (int v527_4_label = 1; v527_4_label <= 2; ++v527_4_label) {
    const Space v527_4_tail = child(s0,v527_4_label);
    if (v527_4_tail.empty()) continue;
    const Path v527_4_head{v527_4_label};
    const Space v528_2 = singleton(v527_4_head);
    const Space v528_3 = intersect(constant_9,v528_2);
    const Space v528_4 = (has_head(v528_3) ? constant_10 : Space{});
    const Path v528_5 = concat_path(p0,v527_4_head);
    const Path v528_6 = concat_path(v528_5,p1);
    const Space v528_7 = singleton(v528_6);
    const Space v528_8 = compose(v528_4,v528_7);
    v527_4_result = unite(v527_4_result,v528_8);
  }
  const Space v527_4 = std::move(v527_4_result);
  return v527_4;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v529_11_result;
  for (int v529_11_label = 1; v529_11_label <= 2; ++v529_11_label) {
    const Space v529_11_tail = child(s0,v529_11_label);
    if (v529_11_tail.empty()) continue;
    const Path v529_11_head{v529_11_label};
    const Space v530_2 = singleton(v529_11_head);
    const Space v530_3 = intersect(constant_9,v530_2);
    const Space v530_4 = (has_head(v530_3) ? constant_10 : Space{});
    const Space v530_5 = subtract(constant_0,v530_4);
    Space v530_8;
    if (!v530_5.empty()) {
      const Path v531_6 = concat_path(p0,v529_11_head);
      Space v531_7_result;
      for (int v531_7_label = 1; v531_7_label <= 2; ++v531_7_label) {
        const Space v531_7_tail = child(v529_11_tail,v531_7_label);
        if (v531_7_tail.empty()) continue;
        const Path v531_7_head{v531_7_label};
        const Space v532_2 = singleton(v531_7_head);
        const Space v532_3 = intersect(constant_9,v532_2);
        const Space v532_4 = (has_head(v532_3) ? constant_10 : Space{});
        const Space v532_5 = subtract(constant_0,v532_4);
        Space v532_8;
        if (!v532_5.empty()) {
          const Path v533_6 = concat_path(v531_6,v531_7_head);
          const Space v533_7 = routine_56(c, v533_6, v531_7_tail);
          v532_8 = compose(v532_5,v533_7);
        }
        const Space v532_9 = intersect(constant_9,v532_2);
        const Space v532_10 = (has_head(v532_9) ? constant_10 : Space{});
        Space v532_12;
        if (!v532_10.empty()) {
          const Path v534_6 = concat_path(v531_6,v531_7_head);
          const Space v534_11 = routine_57(c, v534_6, v531_7_tail);
          v532_12 = compose(v532_10,v534_11);
        }
        const Space v532_13 = unite(v532_8,v532_12);
        v531_7_result = unite(v531_7_result,v532_13);
      }
      const Space v531_7 = std::move(v531_7_result);
      v530_8 = compose(v530_5,v531_7);
    }
    const Space v530_9 = intersect(constant_9,v530_2);
    const Space v530_10 = (has_head(v530_9) ? constant_10 : Space{});
    Space v530_12;
    if (!v530_10.empty()) {
      const Path v535_6 = concat_path(p0,v529_11_head);
      Space v535_11_result;
      for (int v535_11_label = 1; v535_11_label <= 2; ++v535_11_label) {
        const Space v535_11_tail = child(v529_11_tail,v535_11_label);
        if (v535_11_tail.empty()) continue;
        const Path v535_11_head{v535_11_label};
        const Space v536_2 = singleton(v535_11_head);
        const Space v536_3 = intersect(constant_9,v536_2);
        const Space v536_4 = (has_head(v536_3) ? constant_10 : Space{});
        const Space v536_5 = subtract(constant_0,v536_4);
        Space v536_8;
        if (!v536_5.empty()) {
          const Path v537_6 = concat_path(v535_6,v535_11_head);
          const Space v537_7 = routine_56(c, v537_6, v535_11_tail);
          v536_8 = compose(v536_5,v537_7);
        }
        const Space v536_9 = intersect(constant_9,v536_2);
        const Space v536_10 = (has_head(v536_9) ? constant_10 : Space{});
        Space v536_12;
        if (!v536_10.empty()) {
          const Path v538_6 = concat_path(v535_6,v535_11_head);
          const Space v538_11 = routine_52(c, v538_6, v535_11_tail);
          v536_12 = compose(v536_10,v538_11);
        }
        const Space v536_13 = unite(v536_8,v536_12);
        v535_11_result = unite(v535_11_result,v536_13);
      }
      const Space v535_11 = std::move(v535_11_result);
      v530_12 = compose(v530_10,v535_11);
    }
    const Space v530_13 = unite(v530_8,v530_12);
    v529_11_result = unite(v529_11_result,v530_13);
  }
  const Space v529_11 = std::move(v529_11_result);
  return v529_11;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v539_8_result;
  for (int v539_8_label = 1; v539_8_label <= 2; ++v539_8_label) {
    const Space v539_8_tail = child(s0,v539_8_label);
    if (v539_8_tail.empty()) continue;
    const Path v539_8_head{v539_8_label};
    const Space v540_2 = singleton(v539_8_head);
    const Space v540_3 = intersect(constant_9,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_10 : Space{});
    const Space v540_5 = subtract(constant_0,v540_4);
    Space v540_8;
    if (!v540_5.empty()) {
      const Path v541_6 = concat_path(p0,v539_8_head);
      Space v541_7_result;
      for (int v541_7_label = 1; v541_7_label <= 2; ++v541_7_label) {
        const Space v541_7_tail = child(v539_8_tail,v541_7_label);
        if (v541_7_tail.empty()) continue;
        const Path v541_7_head{v541_7_label};
        const Space v542_2 = singleton(v541_7_head);
        const Space v542_3 = intersect(constant_9,v542_2);
        const Space v542_4 = (has_head(v542_3) ? constant_10 : Space{});
        const Space v542_5 = subtract(constant_0,v542_4);
        Space v542_8;
        if (!v542_5.empty()) {
          const Path v543_6 = concat_path(v541_6,v541_7_head);
          const Space v543_7 = routine_56(c, v543_6, v541_7_tail);
          v542_8 = compose(v542_5,v543_7);
        }
        const Space v542_9 = intersect(constant_9,v542_2);
        const Space v542_10 = (has_head(v542_9) ? constant_10 : Space{});
        Space v542_12;
        if (!v542_10.empty()) {
          const Path v544_6 = concat_path(v541_6,v541_7_head);
          const Space v544_11 = routine_57(c, v544_6, v541_7_tail);
          v542_12 = compose(v542_10,v544_11);
        }
        const Space v542_13 = unite(v542_8,v542_12);
        v541_7_result = unite(v541_7_result,v542_13);
      }
      const Space v541_7 = std::move(v541_7_result);
      v540_8 = compose(v540_5,v541_7);
    }
    const Space v540_9 = intersect(constant_9,v540_2);
    const Space v540_10 = (has_head(v540_9) ? constant_10 : Space{});
    const Space v540_11 = compose(v540_10,v539_8_tail);
    const Space v540_12 = unite(v540_8,v540_11);
    v539_8_result = unite(v539_8_result,v540_12);
  }
  const Space v539_8 = std::move(v539_8_result);
  return v539_8;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_53(Context& c, const Space& s0) {
  const Space v546_1 = (has_head(s0) ? constant_10 : Space{});
  const Space v546_2 = first_matching(s0,constant_0,false);
  const Space v546_3 = unite(v546_1,v546_2);
  Space v546_19;
  if (!v546_3.empty()) {
    const Space v547_5 = intersect(constant_0,v546_2);
    const Space v547_6 = (has_head(v546_2) ? constant_10 : Space{});
    const Space v547_7 = unite(v547_5,v547_6);
    const Space v547_9 = compose(v547_7,constant_0);
    const Space v547_10 = subtract(s0,v547_9);
    const Space v547_12 = subtract(constant_0,v546_2);
    const Space v547_13 = subtract(v547_12,v547_6);
    Space v547_17;
    if (!v547_13.empty()) {
      const Space v548_15 = first_fibonacci(s0,6,5,true);
      const Space v548_16 = routine_45(c, constant_12, v548_15, s0);
      v547_17 = compose(v547_13,v548_16);
    }
    const Space v547_18 = subtract(v547_10,v547_17);
    v546_19 = compose(v546_3,v547_18);
  }
  return v546_19;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v549_14_result;
  for (int v549_14_label = 1; v549_14_label <= 2; ++v549_14_label) {
    const Space v549_14_tail = child(s0,v549_14_label);
    if (v549_14_tail.empty()) continue;
    const Path v549_14_head{v549_14_label};
    const Space v550_2 = singleton(v549_14_head);
    const Space v550_3 = intersect(constant_9,v550_2);
    const Space v550_4 = (has_head(v550_3) ? constant_10 : Space{});
    const Space v550_5 = subtract(constant_0,v550_4);
    Space v550_8;
    if (!v550_5.empty()) {
      const Path v551_6 = concat_path(p0,v549_14_head);
      Space v551_7_result;
      for (int v551_7_label = 1; v551_7_label <= 2; ++v551_7_label) {
        const Space v551_7_tail = child(v549_14_tail,v551_7_label);
        if (v551_7_tail.empty()) continue;
        const Path v551_7_head{v551_7_label};
        const Space v552_2 = singleton(v551_7_head);
        const Space v552_3 = intersect(constant_9,v552_2);
        const Space v552_4 = (has_head(v552_3) ? constant_10 : Space{});
        const Space v552_5 = subtract(constant_0,v552_4);
        Space v552_8;
        if (!v552_5.empty()) {
          const Path v553_6 = concat_path(v551_6,v551_7_head);
          const Space v553_7 = routine_58(c, v553_6, v551_7_tail, s1, s2, s3);
          v552_8 = compose(v552_5,v553_7);
        }
        const Space v552_9 = intersect(constant_9,v552_2);
        const Space v552_10 = (has_head(v552_9) ? constant_10 : Space{});
        Space v552_12;
        if (!v552_10.empty()) {
          const Path v554_6 = concat_path(v551_6,v551_7_head);
          const Space v554_11 = routine_59(c, v554_6, v551_7_tail, s1, s2, s3);
          v552_12 = compose(v552_10,v554_11);
        }
        const Space v552_13 = unite(v552_8,v552_12);
        v551_7_result = unite(v551_7_result,v552_13);
      }
      const Space v551_7 = std::move(v551_7_result);
      v550_8 = compose(v550_5,v551_7);
    }
    const Space v550_9 = intersect(constant_9,v550_2);
    const Space v550_10 = (has_head(v550_9) ? constant_10 : Space{});
    Space v550_12;
    if (!v550_10.empty()) {
      const Path v555_6 = concat_path(p0,v549_14_head);
      Space v555_11_result;
      for (int v555_11_label = 1; v555_11_label <= 2; ++v555_11_label) {
        const Space v555_11_tail = child(v549_14_tail,v555_11_label);
        if (v555_11_tail.empty()) continue;
        const Path v555_11_head{v555_11_label};
        const Space v556_2 = singleton(v555_11_head);
        const Space v556_3 = intersect(constant_9,v556_2);
        const Space v556_4 = (has_head(v556_3) ? constant_10 : Space{});
        const Space v556_5 = subtract(constant_0,v556_4);
        Space v556_8;
        if (!v556_5.empty()) {
          const Path v557_6 = concat_path(v555_6,v555_11_head);
          const Space v557_7 = routine_58(c, v557_6, v555_11_tail, s1, s2, s3);
          v556_8 = compose(v556_5,v557_7);
        }
        const Space v556_9 = intersect(constant_9,v556_2);
        const Space v556_10 = (has_head(v556_9) ? constant_10 : Space{});
        Space v556_12;
        if (!v556_10.empty()) {
          const Path v558_6 = concat_path(v555_6,v555_11_head);
          const Space v558_11 = routine_37(c, v558_6, v555_11_tail, s1, s2, s3);
          v556_12 = compose(v556_10,v558_11);
        }
        const Space v556_13 = unite(v556_8,v556_12);
        v555_11_result = unite(v555_11_result,v556_13);
      }
      const Space v555_11 = std::move(v555_11_result);
      v550_12 = compose(v550_10,v555_11);
    }
    const Space v550_13 = unite(v550_8,v550_12);
    v549_14_result = unite(v549_14_result,v550_13);
  }
  const Space v549_14 = std::move(v549_14_result);
  return v549_14;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v559_11_result;
  for (int v559_11_label = 1; v559_11_label <= 2; ++v559_11_label) {
    const Space v559_11_tail = child(s0,v559_11_label);
    if (v559_11_tail.empty()) continue;
    const Path v559_11_head{v559_11_label};
    const Space v560_2 = singleton(v559_11_head);
    const Space v560_3 = intersect(constant_9,v560_2);
    const Space v560_4 = (has_head(v560_3) ? constant_10 : Space{});
    const Space v560_5 = subtract(constant_0,v560_4);
    Space v560_8;
    if (!v560_5.empty()) {
      const Path v561_6 = concat_path(p0,v559_11_head);
      Space v561_7_result;
      for (int v561_7_label = 1; v561_7_label <= 2; ++v561_7_label) {
        const Space v561_7_tail = child(v559_11_tail,v561_7_label);
        if (v561_7_tail.empty()) continue;
        const Path v561_7_head{v561_7_label};
        const Space v562_2 = singleton(v561_7_head);
        const Space v562_3 = intersect(constant_9,v562_2);
        const Space v562_4 = (has_head(v562_3) ? constant_10 : Space{});
        const Space v562_5 = subtract(constant_0,v562_4);
        Space v562_8;
        if (!v562_5.empty()) {
          const Path v563_6 = concat_path(v561_6,v561_7_head);
          const Space v563_7 = routine_58(c, v563_6, v561_7_tail, s1, s2, s3);
          v562_8 = compose(v562_5,v563_7);
        }
        const Space v562_9 = intersect(constant_9,v562_2);
        const Space v562_10 = (has_head(v562_9) ? constant_10 : Space{});
        Space v562_12;
        if (!v562_10.empty()) {
          const Path v564_6 = concat_path(v561_6,v561_7_head);
          const Space v564_11 = routine_59(c, v564_6, v561_7_tail, s1, s2, s3);
          v562_12 = compose(v562_10,v564_11);
        }
        const Space v562_13 = unite(v562_8,v562_12);
        v561_7_result = unite(v561_7_result,v562_13);
      }
      const Space v561_7 = std::move(v561_7_result);
      v560_8 = compose(v560_5,v561_7);
    }
    const Space v560_9 = intersect(constant_9,v560_2);
    const Space v560_10 = (has_head(v560_9) ? constant_10 : Space{});
    Space v560_27;
    if (!v560_10.empty()) {
      const Path v565_6 = concat_path(p0,v559_11_head);
      const Space v565_11 = singleton(v565_6);
      const Space v565_12 = routine_38(c, s1, s3, v565_11);
      const Space v565_13 = routine_38(c, s2, s3, v565_11);
      const Space v565_14 = intersect(v565_12,v565_13);
      const Space v565_15 = subtract(v565_14,v565_11);
      const Space v565_16 = wrap(v565_15,v565_6);
      const Space v565_17 = subtract(s3,v565_13);
      const Space v565_18 = subtract(v565_17,v565_12);
      const Space v565_19 = routine_39(c, s2, s1, v565_18);
      const Space v565_20 = unite(v565_16,v565_19);
      const Space v565_21 = subtract(v565_12,v565_13);
      const Space v565_22 = routine_39(c, s2, s1, v565_21);
      const Space v565_23 = unite(v565_20,v565_22);
      const Space v565_24 = subtract(v565_13,v565_12);
      const Space v565_25 = routine_39(c, s2, s1, v565_24);
      const Space v565_26 = unite(v565_23,v565_25);
      v560_27 = compose(v560_10,v565_26);
    }
    const Space v560_28 = unite(v560_8,v560_27);
    v559_11_result = unite(v559_11_result,v560_28);
  }
  const Space v559_11 = std::move(v559_11_result);
  return v559_11;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  const Space v566_2 = Space{};
  return v566_2;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v567_3_result;
  for (int v567_3_label = 1; v567_3_label <= 2; ++v567_3_label) {
    const Space v567_3_tail = child(s0,v567_3_label);
    if (v567_3_tail.empty()) continue;
    const Path v567_3_head{v567_3_label};
    const Space v568_2 = singleton(v567_3_head);
    const Space v568_3 = intersect(constant_9,v568_2);
    const Space v568_4 = (has_head(v568_3) ? constant_10 : Space{});
    const Space v568_5 = compose(v568_4,v567_3_tail);
    v567_3_result = unite(v567_3_result,v568_5);
  }
  const Space v567_3 = std::move(v567_3_result);
  return v567_3;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  const Space v569_5 = Space{};
  return v569_5;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v570_6_result;
  for (int v570_6_label = 1; v570_6_label <= 2; ++v570_6_label) {
    const Space v570_6_tail = child(s0,v570_6_label);
    if (v570_6_tail.empty()) continue;
    const Path v570_6_head{v570_6_label};
    const Space v571_2 = singleton(v570_6_head);
    const Space v571_3 = intersect(constant_9,v571_2);
    const Space v571_4 = (has_head(v571_3) ? constant_10 : Space{});
    Space v571_22;
    if (!v571_4.empty()) {
      const Path v572_5 = concat_path(p0,v570_6_head);
      const Space v572_6 = singleton(v572_5);
      const Space v572_7 = routine_38(c, s1, s3, v572_6);
      const Space v572_8 = routine_38(c, s2, s3, v572_6);
      const Space v572_9 = intersect(v572_7,v572_8);
      const Space v572_10 = subtract(v572_9,v572_6);
      const Space v572_11 = wrap(v572_10,v572_5);
      const Space v572_12 = subtract(s3,v572_8);
      const Space v572_13 = subtract(v572_12,v572_7);
      const Space v572_14 = routine_39(c, s2, s1, v572_13);
      const Space v572_15 = unite(v572_11,v572_14);
      const Space v572_16 = subtract(v572_7,v572_8);
      const Space v572_17 = routine_39(c, s2, s1, v572_16);
      const Space v572_18 = unite(v572_15,v572_17);
      const Space v572_19 = subtract(v572_8,v572_7);
      const Space v572_20 = routine_39(c, s2, s1, v572_19);
      const Space v572_21 = unite(v572_18,v572_20);
      v571_22 = compose(v571_4,v572_21);
    }
    v570_6_result = unite(v570_6_result,v571_22);
  }
  const Space v570_6 = std::move(v570_6_result);
  return v570_6;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
