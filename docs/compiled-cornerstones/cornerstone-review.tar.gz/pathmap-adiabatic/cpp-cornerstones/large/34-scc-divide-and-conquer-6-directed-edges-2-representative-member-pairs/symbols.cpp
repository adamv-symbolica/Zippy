#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("6 2 1 2 2 2 1 2 3 2 2 3 4 2 4 3 2 5 6");
static const Space constant_1 = literal_text("6 1 1 1 2 1 3 1 4 1 5 1 6");
static const Space constant_2 = literal_text("1 1 4");
static const Space constant_3 = literal_text("6 2 1 2 2 2 1 2 2 3 2 3 4 2 4 3 2 6 5");
static const Path constant_4 = Path{4};
static Space routine_0(Context& c);
static Space routine_1(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_2(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_7 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_8 = intersect(v0_3,v0_7);
  const Space v0_10 = subtract(v0_8,constant_2);
  const Space v0_12 = wrap(v0_10,constant_4);
  const Space v0_19 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_20 = subtract(constant_1,v0_19);
  const Space v0_24 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_25 = subtract(v0_20,v0_24);
  const Space v0_26 = routine_2(c, constant_0, constant_3, v0_25);
  const Space v0_27 = unite(v0_12,v0_26);
  const Space v0_33 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_37 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_38 = subtract(v0_33,v0_37);
  const Space v0_39 = routine_2(c, constant_0, constant_3, v0_38);
  const Space v0_40 = unite(v0_27,v0_39);
  const Space v0_46 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_50 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_51 = subtract(v0_46,v0_50);
  const Space v0_52 = routine_2(c, constant_0, constant_3, v0_51);
  const Space v0_53 = unite(v0_40,v0_52);
  return v0_53;
}

static Space routine_1(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v1_3 = intersect(s1,s2);
  const Space v1_4 = restrict_to(s0,v1_3);
  const Space v1_5 = tails_union(v1_4);
  const Space v1_6 = unite(s2,v1_5);
  const Space v1_7 = intersect(v1_6,s1);
  Space v1_8 = v1_7;
  for (;;) {
    const Space v2_1 = intersect(v1_8,s1);
    const Space v2_2 = restrict_to(s0,v2_1);
    const Space v2_3 = tails_union(v2_2);
    const Space v2_4 = unite(v1_8,v2_3);
    const Space v2_5 = intersect(v2_4,s1);
    Space v1_8_next = unite(v1_8,v2_5);
    if (equal(v1_8_next,v1_8)) break;
    v1_8 = std::move(v1_8_next);
  }
  const Space v1_9 = unite(s2,v1_8);
  return v1_9;
}

static Space routine_2(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v3_3 = range(c,s2,0,1);
  const auto v3_4_branches = branches(c,v3_3);
  std::vector<Space> v3_4_outputs;
  v3_4_outputs.reserve(v3_4_branches.size());
  for (const auto& v3_4_branch : v3_4_branches) {
    const Path v3_4_head{v3_4_branch.first};
    const Space& v3_4_tail = v3_4_branch.second;
    const Space v4_2 = singleton(v3_4_head);
    Space v4_3 = v4_2;
    for (;;) {
      const Space v5_1 = intersect(v4_3,s2);
      const Space v5_2 = restrict_to(s0,v5_1);
      const Space v5_3 = tails_union(v5_2);
      const Space v5_4 = unite(v4_3,v5_3);
      const Space v5_5 = intersect(v5_4,s2);
      Space v4_3_next = unite(v4_3,v5_5);
      if (equal(v4_3_next,v4_3)) break;
      v4_3 = std::move(v4_3_next);
    }
    Space v4_4 = v4_2;
    for (;;) {
      const Space v6_1 = intersect(v4_4,s2);
      const Space v6_2 = restrict_to(s1,v6_1);
      const Space v6_3 = tails_union(v6_2);
      const Space v6_4 = unite(v4_4,v6_3);
      const Space v6_5 = intersect(v6_4,s2);
      Space v4_4_next = unite(v4_4,v6_5);
      if (equal(v4_4_next,v4_4)) break;
      v4_4 = std::move(v4_4_next);
    }
    const Space v4_5 = intersect(v4_3,v4_4);
    const Space v4_6 = subtract(v4_5,v4_2);
    const Space v4_7 = wrap(v4_6,v3_4_head);
    const Space v4_8 = subtract(s2,v4_3);
    const Space v4_9 = subtract(v4_8,v4_4);
    const Space v4_10 = routine_2(c, s0, s1, v4_9);
    const Space v4_11 = unite(v4_7,v4_10);
    const Space v4_12 = subtract(v4_3,v4_4);
    const Space v4_13 = routine_2(c, s0, s1, v4_12);
    const Space v4_14 = unite(v4_11,v4_13);
    const Space v4_15 = subtract(v4_4,v4_3);
    const Space v4_16 = routine_2(c, s0, s1, v4_15);
    const Space v4_17 = unite(v4_14,v4_16);
    v3_4_outputs.push_back(v4_17);
  }
  const Space v3_4 = join_outputs(std::move(v3_4_outputs));
  return v3_4;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"6 1 1 100 2 1 99 3 1 98 4 1 97 5 1 101 6 1 102"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
