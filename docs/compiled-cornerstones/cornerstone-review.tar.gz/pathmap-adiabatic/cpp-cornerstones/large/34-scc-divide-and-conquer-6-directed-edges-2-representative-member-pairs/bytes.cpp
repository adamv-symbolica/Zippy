#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,1};
static const Path constant_1 = Path{1,1,1,2};
static const Space constant_2 = literal_text("1 0 ");
static const Path constant_3 = Path{1,1,1,3};
static const Path constant_4 = Path{1,1,1,4};
static const Path constant_5 = Path{1,1,1,6};
static const Path constant_6 = Path{1,1,1,5};
static const Space constant_7 = literal_text("5 4 1 1 1 1 4 1 1 1 2 4 1 1 1 3 4 1 1 1 4 4 1 1 1 5");
static const Space constant_8 = literal_text("6 8 1 1 1 1 1 1 1 2 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 6");
static const Space constant_9 = singleton(Path{});
static const Path constant_10 = Path{};
static const Space constant_11 = literal_text("6 4 1 1 1 1 4 1 1 1 2 4 1 1 1 3 4 1 1 1 4 4 1 1 1 5 4 1 1 1 6");
static Space routine_0(Context& c);
static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Space& s0);
static Space routine_2(Context& c, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_5 = routine_1(c, constant_1, constant_0, constant_2);
  const Space v0_6 = unite(v0_3,v0_5);
  const Space v0_9 = routine_1(c, constant_3, constant_1, constant_2);
  const Space v0_10 = unite(v0_6,v0_9);
  const Space v0_13 = routine_1(c, constant_3, constant_4, constant_2);
  const Space v0_14 = unite(v0_10,v0_13);
  const Space v0_16 = routine_1(c, constant_4, constant_3, constant_2);
  const Space v0_17 = unite(v0_14,v0_16);
  const Space v0_21 = routine_1(c, constant_5, constant_6, constant_2);
  const Space v0_22 = unite(v0_17,v0_21);
  const auto v0_23_branches = branches(c,v0_22);
  std::vector<Space> v0_23_outputs;
  v0_23_outputs.reserve(v0_23_branches.size());
  for (const auto& v0_23_branch : v0_23_branches) {
    const Path v0_23_head{v0_23_branch.first};
    const Space& v0_23_tail = v0_23_branch.second;
    const auto v1_2_branches = branches(c,v0_23_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_23_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Space v3_2 = head_space(v2_3_tail,256);
        const Path v3_3 = concat_path(v2_2,v2_3_head);
        const Space v3_4 = wrap(v3_2,v3_3);
        v2_3_outputs.push_back(v3_4);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_23_outputs.push_back(v1_2);
  }
  const Space v0_23 = join_outputs(std::move(v0_23_outputs));
  const Space v0_25 = unite(v0_23,constant_7);
  const Space v0_26 = routine_2(c, v0_25);
  const auto v0_41_branches = branches(c,v0_26);
  std::vector<Space> v0_41_outputs;
  v0_41_outputs.reserve(v0_41_branches.size());
  for (const auto& v0_41_branch : v0_41_branches) {
    const Path v0_41_head{v0_41_branch.first};
    const Space& v0_41_tail = v0_41_branch.second;
    const auto v4_2_branches = branches(c,v0_41_tail);
    std::vector<Space> v4_2_outputs;
    v4_2_outputs.reserve(v4_2_branches.size());
    for (const auto& v4_2_branch : v4_2_branches) {
      const Path v4_2_head{v4_2_branch.first};
      const Space& v4_2_tail = v4_2_branch.second;
      const Path v5_2 = concat_path(v0_41_head,v4_2_head);
      const auto v5_3_branches = branches(c,v4_2_tail);
      std::vector<Space> v5_3_outputs;
      v5_3_outputs.reserve(v5_3_branches.size());
      for (const auto& v5_3_branch : v5_3_branches) {
        const Path v5_3_head{v5_3_branch.first};
        const Space& v5_3_tail = v5_3_branch.second;
        const Path v6_2 = concat_path(v5_2,v5_3_head);
        const auto v6_3_branches = branches(c,v5_3_tail);
        std::vector<Space> v6_3_outputs;
        v6_3_outputs.reserve(v6_3_branches.size());
        for (const auto& v6_3_branch : v6_3_branches) {
          const Path v6_3_head{v6_3_branch.first};
          const Space& v6_3_tail = v6_3_branch.second;
          const Path v7_2 = concat_path(v6_2,v6_3_head);
          const Space v7_3 = routine_3(c, constant_0, constant_1, constant_2);
          const Space v7_4 = routine_3(c, constant_1, constant_0, constant_2);
          const Space v7_5 = unite(v7_3,v7_4);
          const Space v7_6 = routine_3(c, constant_3, constant_1, constant_2);
          const Space v7_7 = unite(v7_5,v7_6);
          const Space v7_8 = routine_3(c, constant_3, constant_4, constant_2);
          const Space v7_9 = unite(v7_7,v7_8);
          const Space v7_10 = routine_3(c, constant_4, constant_3, constant_2);
          const Space v7_11 = unite(v7_9,v7_10);
          const Space v7_12 = routine_3(c, constant_5, constant_6, constant_2);
          const Space v7_13 = unite(v7_11,v7_12);
          const Space v7_14 = routine_1(c, constant_0, constant_1, constant_2);
          const Space v7_15 = routine_1(c, constant_1, constant_0, constant_2);
          const Space v7_16 = unite(v7_14,v7_15);
          const Space v7_17 = routine_1(c, constant_3, constant_1, constant_2);
          const Space v7_18 = unite(v7_16,v7_17);
          const Space v7_19 = routine_1(c, constant_3, constant_4, constant_2);
          const Space v7_20 = unite(v7_18,v7_19);
          const Space v7_21 = routine_1(c, constant_4, constant_3, constant_2);
          const Space v7_22 = unite(v7_20,v7_21);
          const Space v7_23 = routine_1(c, constant_5, constant_6, constant_2);
          const Space v7_24 = unite(v7_22,v7_23);
          const auto v7_25_branches = branches(c,v7_24);
          std::vector<Space> v7_25_outputs;
          v7_25_outputs.reserve(v7_25_branches.size());
          for (const auto& v7_25_branch : v7_25_branches) {
            const Path v7_25_head{v7_25_branch.first};
            const Space& v7_25_tail = v7_25_branch.second;
            const auto v8_2_branches = branches(c,v7_25_tail);
            std::vector<Space> v8_2_outputs;
            v8_2_outputs.reserve(v8_2_branches.size());
            for (const auto& v8_2_branch : v8_2_branches) {
              const Path v8_2_head{v8_2_branch.first};
              const Space& v8_2_tail = v8_2_branch.second;
              const Path v9_2 = concat_path(v7_25_head,v8_2_head);
              const auto v9_3_branches = branches(c,v8_2_tail);
              std::vector<Space> v9_3_outputs;
              v9_3_outputs.reserve(v9_3_branches.size());
              for (const auto& v9_3_branch : v9_3_branches) {
                const Path v9_3_head{v9_3_branch.first};
                const Space& v9_3_tail = v9_3_branch.second;
                const Space v10_2 = head_space(v9_3_tail,256);
                const Path v10_3 = concat_path(v9_2,v9_3_head);
                const Space v10_4 = wrap(v10_2,v10_3);
                v9_3_outputs.push_back(v10_4);
              }
              const Space v9_3 = join_outputs(std::move(v9_3_outputs));
              v8_2_outputs.push_back(v9_3);
            }
            const Space v8_2 = join_outputs(std::move(v8_2_outputs));
            v7_25_outputs.push_back(v8_2);
          }
          const Space v7_25 = join_outputs(std::move(v7_25_outputs));
          const Space v7_26 = unite(v7_25,constant_7);
          const Space v7_27 = routine_4(c, v7_2, v6_3_tail, v7_13, constant_8, v7_26);
          v6_3_outputs.push_back(v7_27);
        }
        const Space v6_3 = join_outputs(std::move(v6_3_outputs));
        v5_3_outputs.push_back(v6_3);
      }
      const Space v5_3 = join_outputs(std::move(v5_3_outputs));
      v4_2_outputs.push_back(v5_3);
    }
    const Space v4_2 = join_outputs(std::move(v4_2_outputs));
    v0_41_outputs.push_back(v4_2);
  }
  const Space v0_41 = join_outputs(std::move(v0_41_outputs));
  return v0_41;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v11_3 = concat_path(p0,p1);
  const Space v11_4 = singleton(v11_3);
  return v11_4;
}

static Space routine_2(Context& c, const Space& s0) {
  const Space v12_1 = (has_head(s0) ? constant_9 : Space{});
  const Space v12_2 = first_matching(s0,constant_2,false);
  const Space v12_3 = unite(v12_1,v12_2);
  Space v12_6;
  if (!v12_3.empty()) {
    const Space v13_4 = routine_5(c, s0);
    const Space v13_5 = subtract(s0,v13_4);
    v12_6 = compose(v12_3,v13_5);
  }
  const Space v12_7 = subtract(s0,v12_6);
  return v12_7;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v14_3 = concat_path(p0,p1);
  const Space v14_4 = singleton(v14_3);
  return v14_4;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  const Space v15_5 = singleton(p0);
  Space v15_6 = v15_5;
  for (;;) {
    const Space v16_1 = intersect(v15_6,s3);
    const Space v16_2 = restrict_to(s2,v16_1);
    const auto v16_3_branches = branches(c,v16_2);
    std::vector<Space> v16_3_outputs;
    v16_3_outputs.reserve(v16_3_branches.size());
    for (const auto& v16_3_branch : v16_3_branches) {
      const Path v16_3_head{v16_3_branch.first};
      const Space& v16_3_tail = v16_3_branch.second;
      const auto v17_2_branches = branches(c,v16_3_tail);
      std::vector<Space> v17_2_outputs;
      v17_2_outputs.reserve(v17_2_branches.size());
      for (const auto& v17_2_branch : v17_2_branches) {
        const Path v17_2_head{v17_2_branch.first};
        const Space& v17_2_tail = v17_2_branch.second;
        const auto v18_2_branches = branches(c,v17_2_tail);
        std::vector<Space> v18_2_outputs;
        v18_2_outputs.reserve(v18_2_branches.size());
        for (const auto& v18_2_branch : v18_2_branches) {
          const Path v18_2_head{v18_2_branch.first};
          const Space& v18_2_tail = v18_2_branch.second;
          const Space v19_2 = tails_union(v18_2_tail);
          v18_2_outputs.push_back(v19_2);
        }
        const Space v18_2 = join_outputs(std::move(v18_2_outputs));
        v17_2_outputs.push_back(v18_2);
      }
      const Space v17_2 = join_outputs(std::move(v17_2_outputs));
      v16_3_outputs.push_back(v17_2);
    }
    const Space v16_3 = join_outputs(std::move(v16_3_outputs));
    const Space v16_4 = unite(v16_3,v15_6);
    const Space v16_5 = intersect(v16_4,s3);
    Space v15_6_next = unite(v15_6,v16_5);
    if (equal(v15_6_next,v15_6)) break;
    v15_6 = std::move(v15_6_next);
  }
  Space v15_7 = v15_5;
  for (;;) {
    const Space v20_1 = intersect(v15_7,s3);
    const Space v20_2 = restrict_to(s1,v20_1);
    const auto v20_3_branches = branches(c,v20_2);
    std::vector<Space> v20_3_outputs;
    v20_3_outputs.reserve(v20_3_branches.size());
    for (const auto& v20_3_branch : v20_3_branches) {
      const Path v20_3_head{v20_3_branch.first};
      const Space& v20_3_tail = v20_3_branch.second;
      const auto v21_2_branches = branches(c,v20_3_tail);
      std::vector<Space> v21_2_outputs;
      v21_2_outputs.reserve(v21_2_branches.size());
      for (const auto& v21_2_branch : v21_2_branches) {
        const Path v21_2_head{v21_2_branch.first};
        const Space& v21_2_tail = v21_2_branch.second;
        const auto v22_2_branches = branches(c,v21_2_tail);
        std::vector<Space> v22_2_outputs;
        v22_2_outputs.reserve(v22_2_branches.size());
        for (const auto& v22_2_branch : v22_2_branches) {
          const Path v22_2_head{v22_2_branch.first};
          const Space& v22_2_tail = v22_2_branch.second;
          const Space v23_2 = tails_union(v22_2_tail);
          v22_2_outputs.push_back(v23_2);
        }
        const Space v22_2 = join_outputs(std::move(v22_2_outputs));
        v21_2_outputs.push_back(v22_2);
      }
      const Space v21_2 = join_outputs(std::move(v21_2_outputs));
      v20_3_outputs.push_back(v21_2);
    }
    const Space v20_3 = join_outputs(std::move(v20_3_outputs));
    const Space v20_4 = unite(v20_3,v15_7);
    const Space v20_5 = intersect(v20_4,s3);
    Space v15_7_next = unite(v15_7,v20_5);
    if (equal(v15_7_next,v15_7)) break;
    v15_7 = std::move(v15_7_next);
  }
  const Space v15_8 = intersect(v15_6,v15_7);
  const Space v15_9 = subtract(v15_8,v15_5);
  const Space v15_10 = wrap(v15_9,p0);
  const Space v15_11 = subtract(s3,v15_6);
  const Space v15_12 = subtract(v15_11,v15_7);
  const Space v15_13 = routine_2(c, v15_12);
  const auto v15_14_branches = branches(c,v15_13);
  std::vector<Space> v15_14_outputs;
  v15_14_outputs.reserve(v15_14_branches.size());
  for (const auto& v15_14_branch : v15_14_branches) {
    const Path v15_14_head{v15_14_branch.first};
    const Space& v15_14_tail = v15_14_branch.second;
    const auto v24_2_branches = branches(c,v15_14_tail);
    std::vector<Space> v24_2_outputs;
    v24_2_outputs.reserve(v24_2_branches.size());
    for (const auto& v24_2_branch : v24_2_branches) {
      const Path v24_2_head{v24_2_branch.first};
      const Space& v24_2_tail = v24_2_branch.second;
      const Path v25_2 = concat_path(v15_14_head,v24_2_head);
      const auto v25_3_branches = branches(c,v24_2_tail);
      std::vector<Space> v25_3_outputs;
      v25_3_outputs.reserve(v25_3_branches.size());
      for (const auto& v25_3_branch : v25_3_branches) {
        const Path v25_3_head{v25_3_branch.first};
        const Space& v25_3_tail = v25_3_branch.second;
        const Path v26_2 = concat_path(v25_2,v25_3_head);
        const auto v26_3_branches = branches(c,v25_3_tail);
        std::vector<Space> v26_3_outputs;
        v26_3_outputs.reserve(v26_3_branches.size());
        for (const auto& v26_3_branch : v26_3_branches) {
          const Path v26_3_head{v26_3_branch.first};
          const Space& v26_3_tail = v26_3_branch.second;
          const Path v27_2 = concat_path(v26_2,v26_3_head);
          Space v27_3 = v15_5;
          for (;;) {
            const Space v28_1 = intersect(v27_3,s3);
            const Space v28_2 = restrict_to(s2,v28_1);
            const auto v28_3_branches = branches(c,v28_2);
            std::vector<Space> v28_3_outputs;
            v28_3_outputs.reserve(v28_3_branches.size());
            for (const auto& v28_3_branch : v28_3_branches) {
              const Path v28_3_head{v28_3_branch.first};
              const Space& v28_3_tail = v28_3_branch.second;
              const auto v29_2_branches = branches(c,v28_3_tail);
              std::vector<Space> v29_2_outputs;
              v29_2_outputs.reserve(v29_2_branches.size());
              for (const auto& v29_2_branch : v29_2_branches) {
                const Path v29_2_head{v29_2_branch.first};
                const Space& v29_2_tail = v29_2_branch.second;
                const auto v30_2_branches = branches(c,v29_2_tail);
                std::vector<Space> v30_2_outputs;
                v30_2_outputs.reserve(v30_2_branches.size());
                for (const auto& v30_2_branch : v30_2_branches) {
                  const Path v30_2_head{v30_2_branch.first};
                  const Space& v30_2_tail = v30_2_branch.second;
                  const Space v31_2 = tails_union(v30_2_tail);
                  v30_2_outputs.push_back(v31_2);
                }
                const Space v30_2 = join_outputs(std::move(v30_2_outputs));
                v29_2_outputs.push_back(v30_2);
              }
              const Space v29_2 = join_outputs(std::move(v29_2_outputs));
              v28_3_outputs.push_back(v29_2);
            }
            const Space v28_3 = join_outputs(std::move(v28_3_outputs));
            const Space v28_4 = unite(v28_3,v27_3);
            const Space v28_5 = intersect(v28_4,s3);
            Space v27_3_next = unite(v27_3,v28_5);
            if (equal(v27_3_next,v27_3)) break;
            v27_3 = std::move(v27_3_next);
          }
          const Space v27_4 = subtract(s3,v27_3);
          Space v27_5 = v15_5;
          for (;;) {
            const Space v32_1 = intersect(v27_5,s3);
            const Space v32_2 = restrict_to(s1,v32_1);
            const auto v32_3_branches = branches(c,v32_2);
            std::vector<Space> v32_3_outputs;
            v32_3_outputs.reserve(v32_3_branches.size());
            for (const auto& v32_3_branch : v32_3_branches) {
              const Path v32_3_head{v32_3_branch.first};
              const Space& v32_3_tail = v32_3_branch.second;
              const auto v33_2_branches = branches(c,v32_3_tail);
              std::vector<Space> v33_2_outputs;
              v33_2_outputs.reserve(v33_2_branches.size());
              for (const auto& v33_2_branch : v33_2_branches) {
                const Path v33_2_head{v33_2_branch.first};
                const Space& v33_2_tail = v33_2_branch.second;
                const auto v34_2_branches = branches(c,v33_2_tail);
                std::vector<Space> v34_2_outputs;
                v34_2_outputs.reserve(v34_2_branches.size());
                for (const auto& v34_2_branch : v34_2_branches) {
                  const Path v34_2_head{v34_2_branch.first};
                  const Space& v34_2_tail = v34_2_branch.second;
                  const Space v35_2 = tails_union(v34_2_tail);
                  v34_2_outputs.push_back(v35_2);
                }
                const Space v34_2 = join_outputs(std::move(v34_2_outputs));
                v33_2_outputs.push_back(v34_2);
              }
              const Space v33_2 = join_outputs(std::move(v33_2_outputs));
              v32_3_outputs.push_back(v33_2);
            }
            const Space v32_3 = join_outputs(std::move(v32_3_outputs));
            const Space v32_4 = unite(v32_3,v27_5);
            const Space v32_5 = intersect(v32_4,s3);
            Space v27_5_next = unite(v27_5,v32_5);
            if (equal(v27_5_next,v27_5)) break;
            v27_5 = std::move(v27_5_next);
          }
          const Space v27_6 = subtract(v27_4,v27_5);
          const Space v27_7 = routine_4(c, v27_2, v26_3_tail, s1, s2, v27_6);
          v26_3_outputs.push_back(v27_7);
        }
        const Space v26_3 = join_outputs(std::move(v26_3_outputs));
        v25_3_outputs.push_back(v26_3);
      }
      const Space v25_3 = join_outputs(std::move(v25_3_outputs));
      v24_2_outputs.push_back(v25_3);
    }
    const Space v24_2 = join_outputs(std::move(v24_2_outputs));
    v15_14_outputs.push_back(v24_2);
  }
  const Space v15_14 = join_outputs(std::move(v15_14_outputs));
  const Space v15_15 = unite(v15_10,v15_14);
  const Space v15_16 = subtract(v15_6,v15_7);
  const Space v15_17 = routine_2(c, v15_16);
  const auto v15_18_branches = branches(c,v15_17);
  std::vector<Space> v15_18_outputs;
  v15_18_outputs.reserve(v15_18_branches.size());
  for (const auto& v15_18_branch : v15_18_branches) {
    const Path v15_18_head{v15_18_branch.first};
    const Space& v15_18_tail = v15_18_branch.second;
    const auto v36_2_branches = branches(c,v15_18_tail);
    std::vector<Space> v36_2_outputs;
    v36_2_outputs.reserve(v36_2_branches.size());
    for (const auto& v36_2_branch : v36_2_branches) {
      const Path v36_2_head{v36_2_branch.first};
      const Space& v36_2_tail = v36_2_branch.second;
      const Path v37_2 = concat_path(v15_18_head,v36_2_head);
      const auto v37_3_branches = branches(c,v36_2_tail);
      std::vector<Space> v37_3_outputs;
      v37_3_outputs.reserve(v37_3_branches.size());
      for (const auto& v37_3_branch : v37_3_branches) {
        const Path v37_3_head{v37_3_branch.first};
        const Space& v37_3_tail = v37_3_branch.second;
        const Path v38_2 = concat_path(v37_2,v37_3_head);
        const auto v38_3_branches = branches(c,v37_3_tail);
        std::vector<Space> v38_3_outputs;
        v38_3_outputs.reserve(v38_3_branches.size());
        for (const auto& v38_3_branch : v38_3_branches) {
          const Path v38_3_head{v38_3_branch.first};
          const Space& v38_3_tail = v38_3_branch.second;
          const Path v39_2 = concat_path(v38_2,v38_3_head);
          Space v39_3 = v15_5;
          for (;;) {
            const Space v40_1 = intersect(v39_3,s3);
            const Space v40_2 = restrict_to(s2,v40_1);
            const auto v40_3_branches = branches(c,v40_2);
            std::vector<Space> v40_3_outputs;
            v40_3_outputs.reserve(v40_3_branches.size());
            for (const auto& v40_3_branch : v40_3_branches) {
              const Path v40_3_head{v40_3_branch.first};
              const Space& v40_3_tail = v40_3_branch.second;
              const auto v41_2_branches = branches(c,v40_3_tail);
              std::vector<Space> v41_2_outputs;
              v41_2_outputs.reserve(v41_2_branches.size());
              for (const auto& v41_2_branch : v41_2_branches) {
                const Path v41_2_head{v41_2_branch.first};
                const Space& v41_2_tail = v41_2_branch.second;
                const auto v42_2_branches = branches(c,v41_2_tail);
                std::vector<Space> v42_2_outputs;
                v42_2_outputs.reserve(v42_2_branches.size());
                for (const auto& v42_2_branch : v42_2_branches) {
                  const Path v42_2_head{v42_2_branch.first};
                  const Space& v42_2_tail = v42_2_branch.second;
                  const Space v43_2 = tails_union(v42_2_tail);
                  v42_2_outputs.push_back(v43_2);
                }
                const Space v42_2 = join_outputs(std::move(v42_2_outputs));
                v41_2_outputs.push_back(v42_2);
              }
              const Space v41_2 = join_outputs(std::move(v41_2_outputs));
              v40_3_outputs.push_back(v41_2);
            }
            const Space v40_3 = join_outputs(std::move(v40_3_outputs));
            const Space v40_4 = unite(v40_3,v39_3);
            const Space v40_5 = intersect(v40_4,s3);
            Space v39_3_next = unite(v39_3,v40_5);
            if (equal(v39_3_next,v39_3)) break;
            v39_3 = std::move(v39_3_next);
          }
          Space v39_4 = v15_5;
          for (;;) {
            const Space v44_1 = intersect(v39_4,s3);
            const Space v44_2 = restrict_to(s1,v44_1);
            const auto v44_3_branches = branches(c,v44_2);
            std::vector<Space> v44_3_outputs;
            v44_3_outputs.reserve(v44_3_branches.size());
            for (const auto& v44_3_branch : v44_3_branches) {
              const Path v44_3_head{v44_3_branch.first};
              const Space& v44_3_tail = v44_3_branch.second;
              const auto v45_2_branches = branches(c,v44_3_tail);
              std::vector<Space> v45_2_outputs;
              v45_2_outputs.reserve(v45_2_branches.size());
              for (const auto& v45_2_branch : v45_2_branches) {
                const Path v45_2_head{v45_2_branch.first};
                const Space& v45_2_tail = v45_2_branch.second;
                const auto v46_2_branches = branches(c,v45_2_tail);
                std::vector<Space> v46_2_outputs;
                v46_2_outputs.reserve(v46_2_branches.size());
                for (const auto& v46_2_branch : v46_2_branches) {
                  const Path v46_2_head{v46_2_branch.first};
                  const Space& v46_2_tail = v46_2_branch.second;
                  const Space v47_2 = tails_union(v46_2_tail);
                  v46_2_outputs.push_back(v47_2);
                }
                const Space v46_2 = join_outputs(std::move(v46_2_outputs));
                v45_2_outputs.push_back(v46_2);
              }
              const Space v45_2 = join_outputs(std::move(v45_2_outputs));
              v44_3_outputs.push_back(v45_2);
            }
            const Space v44_3 = join_outputs(std::move(v44_3_outputs));
            const Space v44_4 = unite(v44_3,v39_4);
            const Space v44_5 = intersect(v44_4,s3);
            Space v39_4_next = unite(v39_4,v44_5);
            if (equal(v39_4_next,v39_4)) break;
            v39_4 = std::move(v39_4_next);
          }
          const Space v39_5 = subtract(v39_3,v39_4);
          const Space v39_6 = routine_4(c, v39_2, v38_3_tail, s1, s2, v39_5);
          v38_3_outputs.push_back(v39_6);
        }
        const Space v38_3 = join_outputs(std::move(v38_3_outputs));
        v37_3_outputs.push_back(v38_3);
      }
      const Space v37_3 = join_outputs(std::move(v37_3_outputs));
      v36_2_outputs.push_back(v37_3);
    }
    const Space v36_2 = join_outputs(std::move(v36_2_outputs));
    v15_18_outputs.push_back(v36_2);
  }
  const Space v15_18 = join_outputs(std::move(v15_18_outputs));
  const Space v15_19 = unite(v15_15,v15_18);
  const Space v15_20 = subtract(v15_7,v15_6);
  const Space v15_21 = routine_2(c, v15_20);
  const auto v15_22_branches = branches(c,v15_21);
  std::vector<Space> v15_22_outputs;
  v15_22_outputs.reserve(v15_22_branches.size());
  for (const auto& v15_22_branch : v15_22_branches) {
    const Path v15_22_head{v15_22_branch.first};
    const Space& v15_22_tail = v15_22_branch.second;
    const auto v48_2_branches = branches(c,v15_22_tail);
    std::vector<Space> v48_2_outputs;
    v48_2_outputs.reserve(v48_2_branches.size());
    for (const auto& v48_2_branch : v48_2_branches) {
      const Path v48_2_head{v48_2_branch.first};
      const Space& v48_2_tail = v48_2_branch.second;
      const Path v49_2 = concat_path(v15_22_head,v48_2_head);
      const auto v49_3_branches = branches(c,v48_2_tail);
      std::vector<Space> v49_3_outputs;
      v49_3_outputs.reserve(v49_3_branches.size());
      for (const auto& v49_3_branch : v49_3_branches) {
        const Path v49_3_head{v49_3_branch.first};
        const Space& v49_3_tail = v49_3_branch.second;
        const Path v50_2 = concat_path(v49_2,v49_3_head);
        const auto v50_3_branches = branches(c,v49_3_tail);
        std::vector<Space> v50_3_outputs;
        v50_3_outputs.reserve(v50_3_branches.size());
        for (const auto& v50_3_branch : v50_3_branches) {
          const Path v50_3_head{v50_3_branch.first};
          const Space& v50_3_tail = v50_3_branch.second;
          const Path v51_2 = concat_path(v50_2,v50_3_head);
          Space v51_3 = v15_5;
          for (;;) {
            const Space v52_1 = intersect(v51_3,s3);
            const Space v52_2 = restrict_to(s1,v52_1);
            const auto v52_3_branches = branches(c,v52_2);
            std::vector<Space> v52_3_outputs;
            v52_3_outputs.reserve(v52_3_branches.size());
            for (const auto& v52_3_branch : v52_3_branches) {
              const Path v52_3_head{v52_3_branch.first};
              const Space& v52_3_tail = v52_3_branch.second;
              const auto v53_2_branches = branches(c,v52_3_tail);
              std::vector<Space> v53_2_outputs;
              v53_2_outputs.reserve(v53_2_branches.size());
              for (const auto& v53_2_branch : v53_2_branches) {
                const Path v53_2_head{v53_2_branch.first};
                const Space& v53_2_tail = v53_2_branch.second;
                const auto v54_2_branches = branches(c,v53_2_tail);
                std::vector<Space> v54_2_outputs;
                v54_2_outputs.reserve(v54_2_branches.size());
                for (const auto& v54_2_branch : v54_2_branches) {
                  const Path v54_2_head{v54_2_branch.first};
                  const Space& v54_2_tail = v54_2_branch.second;
                  const Space v55_2 = tails_union(v54_2_tail);
                  v54_2_outputs.push_back(v55_2);
                }
                const Space v54_2 = join_outputs(std::move(v54_2_outputs));
                v53_2_outputs.push_back(v54_2);
              }
              const Space v53_2 = join_outputs(std::move(v53_2_outputs));
              v52_3_outputs.push_back(v53_2);
            }
            const Space v52_3 = join_outputs(std::move(v52_3_outputs));
            const Space v52_4 = unite(v52_3,v51_3);
            const Space v52_5 = intersect(v52_4,s3);
            Space v51_3_next = unite(v51_3,v52_5);
            if (equal(v51_3_next,v51_3)) break;
            v51_3 = std::move(v51_3_next);
          }
          Space v51_4 = v15_5;
          for (;;) {
            const Space v56_1 = intersect(v51_4,s3);
            const Space v56_2 = restrict_to(s2,v56_1);
            const auto v56_3_branches = branches(c,v56_2);
            std::vector<Space> v56_3_outputs;
            v56_3_outputs.reserve(v56_3_branches.size());
            for (const auto& v56_3_branch : v56_3_branches) {
              const Path v56_3_head{v56_3_branch.first};
              const Space& v56_3_tail = v56_3_branch.second;
              const auto v57_2_branches = branches(c,v56_3_tail);
              std::vector<Space> v57_2_outputs;
              v57_2_outputs.reserve(v57_2_branches.size());
              for (const auto& v57_2_branch : v57_2_branches) {
                const Path v57_2_head{v57_2_branch.first};
                const Space& v57_2_tail = v57_2_branch.second;
                const auto v58_2_branches = branches(c,v57_2_tail);
                std::vector<Space> v58_2_outputs;
                v58_2_outputs.reserve(v58_2_branches.size());
                for (const auto& v58_2_branch : v58_2_branches) {
                  const Path v58_2_head{v58_2_branch.first};
                  const Space& v58_2_tail = v58_2_branch.second;
                  const Space v59_2 = tails_union(v58_2_tail);
                  v58_2_outputs.push_back(v59_2);
                }
                const Space v58_2 = join_outputs(std::move(v58_2_outputs));
                v57_2_outputs.push_back(v58_2);
              }
              const Space v57_2 = join_outputs(std::move(v57_2_outputs));
              v56_3_outputs.push_back(v57_2);
            }
            const Space v56_3 = join_outputs(std::move(v56_3_outputs));
            const Space v56_4 = unite(v56_3,v51_4);
            const Space v56_5 = intersect(v56_4,s3);
            Space v51_4_next = unite(v51_4,v56_5);
            if (equal(v51_4_next,v51_4)) break;
            v51_4 = std::move(v51_4_next);
          }
          const Space v51_5 = subtract(v51_3,v51_4);
          const Space v51_6 = routine_4(c, v51_2, v50_3_tail, s1, s2, v51_5);
          v50_3_outputs.push_back(v51_6);
        }
        const Space v50_3 = join_outputs(std::move(v50_3_outputs));
        v49_3_outputs.push_back(v50_3);
      }
      const Space v49_3 = join_outputs(std::move(v49_3_outputs));
      v48_2_outputs.push_back(v49_3);
    }
    const Space v48_2 = join_outputs(std::move(v48_2_outputs));
    v15_22_outputs.push_back(v48_2);
  }
  const Space v15_22 = join_outputs(std::move(v15_22_outputs));
  const Space v15_23 = unite(v15_19,v15_22);
  return v15_23;
}

static Space routine_5(Context& c, const Space& s0) {
  const Space v60_2 = first_matching(s0,constant_2,false);
  const Space v60_3 = intersect(constant_2,v60_2);
  const Space v60_4 = (has_head(v60_2) ? constant_9 : Space{});
  const Space v60_5 = unite(v60_3,v60_4);
  const Space v60_7 = compose(v60_5,constant_2);
  const Space v60_9 = subtract(constant_2,v60_2);
  const Space v60_10 = subtract(v60_9,v60_4);
  Space v60_18;
  if (!v60_10.empty()) {
    const Space v61_11 = first_matching(s0,constant_11,true);
    const Space v61_12 = first_matching(v61_11,constant_2,false);
    Space v61_15;
    if (!v61_12.empty()) {
      const Space v62_14 = routine_6(c, constant_10, s0);
      v61_15 = compose(v61_12,v62_14);
    }
    const auto v61_16_branches = branches(c,v61_11);
    std::vector<Space> v61_16_outputs;
    v61_16_outputs.reserve(v61_16_branches.size());
    for (const auto& v61_16_branch : v61_16_branches) {
      const Path v61_16_head{v61_16_branch.first};
      const Space& v61_16_tail = v61_16_branch.second;
      const Space v63_2 = routine_7(c, v61_16_head, v61_16_tail, s0);
      v61_16_outputs.push_back(v63_2);
    }
    const Space v61_16 = join_outputs(std::move(v61_16_outputs));
    const Space v61_17 = unite(v61_15,v61_16);
    v60_18 = compose(v60_10,v61_17);
  }
  const Space v60_19 = unite(v60_7,v60_18);
  return v60_19;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  const Space v64_3 = unwrap(s0,p0);
  const Space v64_4 = first_matching(v64_3,constant_2,false);
  const Space v64_5 = intersect(constant_2,v64_4);
  const Space v64_6 = (has_head(v64_4) ? constant_9 : Space{});
  const Space v64_7 = unite(v64_5,v64_6);
  const Space v64_9 = compose(v64_7,constant_2);
  const Space v64_11 = subtract(constant_2,v64_4);
  const Space v64_12 = subtract(v64_11,v64_6);
  Space v64_16;
  if (!v64_12.empty()) {
    const Space v65_14 = first_matching(v64_3,constant_11,true);
    const Space v65_15 = routine_7(c, constant_10, v65_14, v64_3);
    v64_16 = compose(v64_12,v65_15);
  }
  const Space v64_17 = unite(v64_9,v64_16);
  const Space v64_18 = wrap(v64_17,p0);
  return v64_18;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v66_3 = first_matching(s0,constant_2,false);
  Space v66_7;
  if (!v66_3.empty()) {
    const Space v67_4 = unwrap(s1,p0);
    const Space v67_5 = routine_5(c, v67_4);
    const Space v67_6 = wrap(v67_5,p0);
    v66_7 = compose(v66_3,v67_6);
  }
  const auto v66_8_branches = branches(c,s0);
  std::vector<Space> v66_8_outputs;
  v66_8_outputs.reserve(v66_8_branches.size());
  for (const auto& v66_8_branch : v66_8_branches) {
    const Path v66_8_head{v66_8_branch.first};
    const Space& v66_8_tail = v66_8_branch.second;
    const Path v68_2 = concat_path(p0,v66_8_head);
    const Space v68_3 = routine_7(c, v68_2, v66_8_tail, s1);
    v66_8_outputs.push_back(v68_3);
  }
  const Space v66_8 = join_outputs(std::move(v66_8_outputs));
  const Space v66_9 = unite(v66_7,v66_8);
  return v66_9;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
