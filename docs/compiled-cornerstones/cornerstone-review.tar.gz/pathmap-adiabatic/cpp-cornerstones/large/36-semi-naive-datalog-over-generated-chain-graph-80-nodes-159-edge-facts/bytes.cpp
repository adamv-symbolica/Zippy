#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,1};
static const Path constant_1 = Path{1,1,1,84};
static const Path constant_2 = Path{1,1,1,85};
static const Path constant_3 = Path{1,1,1,83};
static const Path constant_4 = Path{1,1,1,84,1,1,1,83};
static const Path constant_5 = Path{1,1,1,85,1,1,1,83};
static const Space constant_6 = literal_text("1 0 ");
static Space routine_0(Context& c, const Space* s0);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  const auto v0_3_branches = branches(c,v0_2);
  std::vector<Space> v0_3_outputs;
  v0_3_outputs.reserve(v0_3_branches.size());
  for (const auto& v0_3_branch : v0_3_branches) {
    const Path v0_3_head{v0_3_branch.first};
    const Space& v0_3_tail = v0_3_branch.second;
    const auto v1_2_branches = branches(c,v0_3_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_3_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Path v4_2 = concat_path(v3_2,v3_3_head);
          const auto v4_3_branches = branches(c,v3_3_tail);
          std::vector<Space> v4_3_outputs;
          v4_3_outputs.reserve(v4_3_branches.size());
          for (const auto& v4_3_branch : v4_3_branches) {
            const Path v4_3_head{v4_3_branch.first};
            const Space& v4_3_tail = v4_3_branch.second;
            const auto v5_2_branches = branches(c,v4_3_tail);
            std::vector<Space> v5_2_outputs;
            v5_2_outputs.reserve(v5_2_branches.size());
            for (const auto& v5_2_branch : v5_2_branches) {
              const Path v5_2_head{v5_2_branch.first};
              const Space& v5_2_tail = v5_2_branch.second;
              const Path v6_2 = concat_path(v4_3_head,v5_2_head);
              const auto v6_3_branches = branches(c,v5_2_tail);
              std::vector<Space> v6_3_outputs;
              v6_3_outputs.reserve(v6_3_branches.size());
              for (const auto& v6_3_branch : v6_3_branches) {
                const Path v6_3_head{v6_3_branch.first};
                const Space& v6_3_tail = v6_3_branch.second;
                const Path v7_2 = concat_path(v6_2,v6_3_head);
                const auto v7_3_branches = branches(c,v6_3_tail);
                std::vector<Space> v7_3_outputs;
                v7_3_outputs.reserve(v7_3_branches.size());
                for (const auto& v7_3_branch : v7_3_branches) {
                  const Path v7_3_head{v7_3_branch.first};
                  const Space& v7_3_tail = v7_3_branch.second;
                  const Path v8_2 = concat_path(v7_2,v7_3_head);
                  const Space v8_3 = routine_1(c, v8_2, v4_2, v7_3_tail);
                  v7_3_outputs.push_back(v8_3);
                }
                const Space v7_3 = join_outputs(std::move(v7_3_outputs));
                v6_3_outputs.push_back(v7_3);
              }
              const Space v6_3 = join_outputs(std::move(v6_3_outputs));
              v5_2_outputs.push_back(v6_3);
            }
            const Space v5_2 = join_outputs(std::move(v5_2_outputs));
            v4_3_outputs.push_back(v5_2);
          }
          const Space v4_3 = join_outputs(std::move(v4_3_outputs));
          v3_3_outputs.push_back(v4_3);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_3_outputs.push_back(v1_2);
  }
  const Space v0_3 = join_outputs(std::move(v0_3_outputs));
  const Space v0_5 = wrap(v0_3,constant_1);
  const Space v0_7 = wrap(bound_space(s0),constant_2);
  const Space v0_8 = unite(v0_5,v0_7);
  Space v0_12 = v0_8;
  for (;;) {
    const Space v9_1 = unwrap(v0_12,constant_1);
    const Space v9_2 = unwrap(v9_1,constant_3);
    const auto v9_3_branches = branches(c,v9_2);
    std::vector<Space> v9_3_outputs;
    v9_3_outputs.reserve(v9_3_branches.size());
    for (const auto& v9_3_branch : v9_3_branches) {
      const Path v9_3_head{v9_3_branch.first};
      const Space& v9_3_tail = v9_3_branch.second;
      const auto v10_2_branches = branches(c,v9_3_tail);
      std::vector<Space> v10_2_outputs;
      v10_2_outputs.reserve(v10_2_branches.size());
      for (const auto& v10_2_branch : v10_2_branches) {
        const Path v10_2_head{v10_2_branch.first};
        const Space& v10_2_tail = v10_2_branch.second;
        const Path v11_2 = concat_path(v9_3_head,v10_2_head);
        const auto v11_3_branches = branches(c,v10_2_tail);
        std::vector<Space> v11_3_outputs;
        v11_3_outputs.reserve(v11_3_branches.size());
        for (const auto& v11_3_branch : v11_3_branches) {
          const Path v11_3_head{v11_3_branch.first};
          const Space& v11_3_tail = v11_3_branch.second;
          const Path v12_2 = concat_path(v11_2,v11_3_head);
          const auto v12_3_branches = branches(c,v11_3_tail);
          std::vector<Space> v12_3_outputs;
          v12_3_outputs.reserve(v12_3_branches.size());
          for (const auto& v12_3_branch : v12_3_branches) {
            const Path v12_3_head{v12_3_branch.first};
            const Space& v12_3_tail = v12_3_branch.second;
            const Path v13_2 = concat_path(v12_2,v12_3_head);
            const auto v13_3_branches = branches(c,v12_3_tail);
            std::vector<Space> v13_3_outputs;
            v13_3_outputs.reserve(v13_3_branches.size());
            for (const auto& v13_3_branch : v13_3_branches) {
              const Path v13_3_head{v13_3_branch.first};
              const Space& v13_3_tail = v13_3_branch.second;
              const auto v14_2_branches = branches(c,v13_3_tail);
              std::vector<Space> v14_2_outputs;
              v14_2_outputs.reserve(v14_2_branches.size());
              for (const auto& v14_2_branch : v14_2_branches) {
                const Path v14_2_head{v14_2_branch.first};
                const Space& v14_2_tail = v14_2_branch.second;
                const Path v15_2 = concat_path(v13_3_head,v14_2_head);
                const auto v15_3_branches = branches(c,v14_2_tail);
                std::vector<Space> v15_3_outputs;
                v15_3_outputs.reserve(v15_3_branches.size());
                for (const auto& v15_3_branch : v15_3_branches) {
                  const Path v15_3_head{v15_3_branch.first};
                  const Space& v15_3_tail = v15_3_branch.second;
                  const Path v16_2 = concat_path(v15_2,v15_3_head);
                  const auto v16_3_branches = branches(c,v15_3_tail);
                  std::vector<Space> v16_3_outputs;
                  v16_3_outputs.reserve(v16_3_branches.size());
                  for (const auto& v16_3_branch : v16_3_branches) {
                    const Path v16_3_head{v16_3_branch.first};
                    const Space& v16_3_tail = v16_3_branch.second;
                    const Path v17_2 = concat_path(v16_2,v16_3_head);
                    const Space v17_3 = routine_2(c, v17_2, v13_2, v16_3_tail, v0_12);
                    v16_3_outputs.push_back(v17_3);
                  }
                  const Space v16_3 = join_outputs(std::move(v16_3_outputs));
                  v15_3_outputs.push_back(v16_3);
                }
                const Space v15_3 = join_outputs(std::move(v15_3_outputs));
                v14_2_outputs.push_back(v15_3);
              }
              const Space v14_2 = join_outputs(std::move(v14_2_outputs));
              v13_3_outputs.push_back(v14_2);
            }
            const Space v13_3 = join_outputs(std::move(v13_3_outputs));
            v12_3_outputs.push_back(v13_3);
          }
          const Space v12_3 = join_outputs(std::move(v12_3_outputs));
          v11_3_outputs.push_back(v12_3);
        }
        const Space v11_3 = join_outputs(std::move(v11_3_outputs));
        v10_2_outputs.push_back(v11_3);
      }
      const Space v10_2 = join_outputs(std::move(v10_2_outputs));
      v9_3_outputs.push_back(v10_2);
    }
    const Space v9_3 = join_outputs(std::move(v9_3_outputs));
    const auto v9_4_branches = branches(c,v9_2);
    std::vector<Space> v9_4_outputs;
    v9_4_outputs.reserve(v9_4_branches.size());
    for (const auto& v9_4_branch : v9_4_branches) {
      const Path v9_4_head{v9_4_branch.first};
      const Space& v9_4_tail = v9_4_branch.second;
      const auto v18_2_branches = branches(c,v9_4_tail);
      std::vector<Space> v18_2_outputs;
      v18_2_outputs.reserve(v18_2_branches.size());
      for (const auto& v18_2_branch : v18_2_branches) {
        const Path v18_2_head{v18_2_branch.first};
        const Space& v18_2_tail = v18_2_branch.second;
        const Path v19_2 = concat_path(v9_4_head,v18_2_head);
        const auto v19_3_branches = branches(c,v18_2_tail);
        std::vector<Space> v19_3_outputs;
        v19_3_outputs.reserve(v19_3_branches.size());
        for (const auto& v19_3_branch : v19_3_branches) {
          const Path v19_3_head{v19_3_branch.first};
          const Space& v19_3_tail = v19_3_branch.second;
          const Path v20_2 = concat_path(v19_2,v19_3_head);
          const auto v20_3_branches = branches(c,v19_3_tail);
          std::vector<Space> v20_3_outputs;
          v20_3_outputs.reserve(v20_3_branches.size());
          for (const auto& v20_3_branch : v20_3_branches) {
            const Path v20_3_head{v20_3_branch.first};
            const Space& v20_3_tail = v20_3_branch.second;
            const Path v21_2 = concat_path(v20_2,v20_3_head);
            const auto v21_3_branches = branches(c,v20_3_tail);
            std::vector<Space> v21_3_outputs;
            v21_3_outputs.reserve(v21_3_branches.size());
            for (const auto& v21_3_branch : v21_3_branches) {
              const Path v21_3_head{v21_3_branch.first};
              const Space& v21_3_tail = v21_3_branch.second;
              const auto v22_2_branches = branches(c,v21_3_tail);
              std::vector<Space> v22_2_outputs;
              v22_2_outputs.reserve(v22_2_branches.size());
              for (const auto& v22_2_branch : v22_2_branches) {
                const Path v22_2_head{v22_2_branch.first};
                const Space& v22_2_tail = v22_2_branch.second;
                const Path v23_2 = concat_path(v21_3_head,v22_2_head);
                const auto v23_3_branches = branches(c,v22_2_tail);
                std::vector<Space> v23_3_outputs;
                v23_3_outputs.reserve(v23_3_branches.size());
                for (const auto& v23_3_branch : v23_3_branches) {
                  const Path v23_3_head{v23_3_branch.first};
                  const Space& v23_3_tail = v23_3_branch.second;
                  const Path v24_2 = concat_path(v23_2,v23_3_head);
                  const auto v24_3_branches = branches(c,v23_3_tail);
                  std::vector<Space> v24_3_outputs;
                  v24_3_outputs.reserve(v24_3_branches.size());
                  for (const auto& v24_3_branch : v24_3_branches) {
                    const Path v24_3_head{v24_3_branch.first};
                    const Space& v24_3_tail = v24_3_branch.second;
                    const Path v25_2 = concat_path(v24_2,v24_3_head);
                    const Space v25_3 = routine_3(c, v25_2, v21_2, v24_3_tail, v0_12);
                    v24_3_outputs.push_back(v25_3);
                  }
                  const Space v24_3 = join_outputs(std::move(v24_3_outputs));
                  v23_3_outputs.push_back(v24_3);
                }
                const Space v23_3 = join_outputs(std::move(v23_3_outputs));
                v22_2_outputs.push_back(v23_3);
              }
              const Space v22_2 = join_outputs(std::move(v22_2_outputs));
              v21_3_outputs.push_back(v22_2);
            }
            const Space v21_3 = join_outputs(std::move(v21_3_outputs));
            v20_3_outputs.push_back(v21_3);
          }
          const Space v20_3 = join_outputs(std::move(v20_3_outputs));
          v19_3_outputs.push_back(v20_3);
        }
        const Space v19_3 = join_outputs(std::move(v19_3_outputs));
        v18_2_outputs.push_back(v19_3);
      }
      const Space v18_2 = join_outputs(std::move(v18_2_outputs));
      v9_4_outputs.push_back(v18_2);
    }
    const Space v9_4 = join_outputs(std::move(v9_4_outputs));
    const Space v9_5 = unite(v9_3,v9_4);
    const Space v9_6 = unwrap(v0_12,constant_2);
    const Space v9_7 = unwrap(v9_6,constant_0);
    const auto v9_8_branches = branches(c,v9_7);
    std::vector<Space> v9_8_outputs;
    v9_8_outputs.reserve(v9_8_branches.size());
    for (const auto& v9_8_branch : v9_8_branches) {
      const Path v9_8_head{v9_8_branch.first};
      const Space& v9_8_tail = v9_8_branch.second;
      const auto v26_2_branches = branches(c,v9_8_tail);
      std::vector<Space> v26_2_outputs;
      v26_2_outputs.reserve(v26_2_branches.size());
      for (const auto& v26_2_branch : v26_2_branches) {
        const Path v26_2_head{v26_2_branch.first};
        const Space& v26_2_tail = v26_2_branch.second;
        const Path v27_2 = concat_path(v9_8_head,v26_2_head);
        const auto v27_3_branches = branches(c,v26_2_tail);
        std::vector<Space> v27_3_outputs;
        v27_3_outputs.reserve(v27_3_branches.size());
        for (const auto& v27_3_branch : v27_3_branches) {
          const Path v27_3_head{v27_3_branch.first};
          const Space& v27_3_tail = v27_3_branch.second;
          const Path v28_2 = concat_path(v27_2,v27_3_head);
          const auto v28_3_branches = branches(c,v27_3_tail);
          std::vector<Space> v28_3_outputs;
          v28_3_outputs.reserve(v28_3_branches.size());
          for (const auto& v28_3_branch : v28_3_branches) {
            const Path v28_3_head{v28_3_branch.first};
            const Space& v28_3_tail = v28_3_branch.second;
            const Path v29_2 = concat_path(v28_2,v28_3_head);
            const auto v29_3_branches = branches(c,v28_3_tail);
            std::vector<Space> v29_3_outputs;
            v29_3_outputs.reserve(v29_3_branches.size());
            for (const auto& v29_3_branch : v29_3_branches) {
              const Path v29_3_head{v29_3_branch.first};
              const Space& v29_3_tail = v29_3_branch.second;
              const auto v30_2_branches = branches(c,v29_3_tail);
              std::vector<Space> v30_2_outputs;
              v30_2_outputs.reserve(v30_2_branches.size());
              for (const auto& v30_2_branch : v30_2_branches) {
                const Path v30_2_head{v30_2_branch.first};
                const Space& v30_2_tail = v30_2_branch.second;
                const Path v31_2 = concat_path(v29_3_head,v30_2_head);
                const auto v31_3_branches = branches(c,v30_2_tail);
                std::vector<Space> v31_3_outputs;
                v31_3_outputs.reserve(v31_3_branches.size());
                for (const auto& v31_3_branch : v31_3_branches) {
                  const Path v31_3_head{v31_3_branch.first};
                  const Space& v31_3_tail = v31_3_branch.second;
                  const Path v32_2 = concat_path(v31_2,v31_3_head);
                  const auto v32_3_branches = branches(c,v31_3_tail);
                  std::vector<Space> v32_3_outputs;
                  v32_3_outputs.reserve(v32_3_branches.size());
                  for (const auto& v32_3_branch : v32_3_branches) {
                    const Path v32_3_head{v32_3_branch.first};
                    const Space& v32_3_tail = v32_3_branch.second;
                    const Path v33_2 = concat_path(v32_2,v32_3_head);
                    const Space v33_3 = routine_4(c, v33_2, v29_2, v32_3_tail);
                    v32_3_outputs.push_back(v33_3);
                  }
                  const Space v32_3 = join_outputs(std::move(v32_3_outputs));
                  v31_3_outputs.push_back(v32_3);
                }
                const Space v31_3 = join_outputs(std::move(v31_3_outputs));
                v30_2_outputs.push_back(v31_3);
              }
              const Space v30_2 = join_outputs(std::move(v30_2_outputs));
              v29_3_outputs.push_back(v30_2);
            }
            const Space v29_3 = join_outputs(std::move(v29_3_outputs));
            v28_3_outputs.push_back(v29_3);
          }
          const Space v28_3 = join_outputs(std::move(v28_3_outputs));
          v27_3_outputs.push_back(v28_3);
        }
        const Space v27_3 = join_outputs(std::move(v27_3_outputs));
        v26_2_outputs.push_back(v27_3);
      }
      const Space v26_2 = join_outputs(std::move(v26_2_outputs));
      v9_8_outputs.push_back(v26_2);
    }
    const Space v9_8 = join_outputs(std::move(v9_8_outputs));
    const Space v9_9 = unite(v9_5,v9_8);
    const Space v9_10 = unwrap(v9_6,constant_3);
    const auto v9_11_branches = branches(c,v9_10);
    std::vector<Space> v9_11_outputs;
    v9_11_outputs.reserve(v9_11_branches.size());
    for (const auto& v9_11_branch : v9_11_branches) {
      const Path v9_11_head{v9_11_branch.first};
      const Space& v9_11_tail = v9_11_branch.second;
      const auto v34_2_branches = branches(c,v9_11_tail);
      std::vector<Space> v34_2_outputs;
      v34_2_outputs.reserve(v34_2_branches.size());
      for (const auto& v34_2_branch : v34_2_branches) {
        const Path v34_2_head{v34_2_branch.first};
        const Space& v34_2_tail = v34_2_branch.second;
        const Path v35_2 = concat_path(v9_11_head,v34_2_head);
        const auto v35_3_branches = branches(c,v34_2_tail);
        std::vector<Space> v35_3_outputs;
        v35_3_outputs.reserve(v35_3_branches.size());
        for (const auto& v35_3_branch : v35_3_branches) {
          const Path v35_3_head{v35_3_branch.first};
          const Space& v35_3_tail = v35_3_branch.second;
          const Path v36_2 = concat_path(v35_2,v35_3_head);
          const auto v36_3_branches = branches(c,v35_3_tail);
          std::vector<Space> v36_3_outputs;
          v36_3_outputs.reserve(v36_3_branches.size());
          for (const auto& v36_3_branch : v36_3_branches) {
            const Path v36_3_head{v36_3_branch.first};
            const Space& v36_3_tail = v36_3_branch.second;
            const Path v37_2 = concat_path(v36_2,v36_3_head);
            const auto v37_3_branches = branches(c,v36_3_tail);
            std::vector<Space> v37_3_outputs;
            v37_3_outputs.reserve(v37_3_branches.size());
            for (const auto& v37_3_branch : v37_3_branches) {
              const Path v37_3_head{v37_3_branch.first};
              const Space& v37_3_tail = v37_3_branch.second;
              const auto v38_2_branches = branches(c,v37_3_tail);
              std::vector<Space> v38_2_outputs;
              v38_2_outputs.reserve(v38_2_branches.size());
              for (const auto& v38_2_branch : v38_2_branches) {
                const Path v38_2_head{v38_2_branch.first};
                const Space& v38_2_tail = v38_2_branch.second;
                const Path v39_2 = concat_path(v37_3_head,v38_2_head);
                const auto v39_3_branches = branches(c,v38_2_tail);
                std::vector<Space> v39_3_outputs;
                v39_3_outputs.reserve(v39_3_branches.size());
                for (const auto& v39_3_branch : v39_3_branches) {
                  const Path v39_3_head{v39_3_branch.first};
                  const Space& v39_3_tail = v39_3_branch.second;
                  const Path v40_2 = concat_path(v39_2,v39_3_head);
                  const auto v40_3_branches = branches(c,v39_3_tail);
                  std::vector<Space> v40_3_outputs;
                  v40_3_outputs.reserve(v40_3_branches.size());
                  for (const auto& v40_3_branch : v40_3_branches) {
                    const Path v40_3_head{v40_3_branch.first};
                    const Space& v40_3_tail = v40_3_branch.second;
                    const Path v41_2 = concat_path(v40_2,v40_3_head);
                    const Space v41_3 = routine_5(c, v41_2, v37_2, v40_3_tail, v0_12);
                    v40_3_outputs.push_back(v41_3);
                  }
                  const Space v40_3 = join_outputs(std::move(v40_3_outputs));
                  v39_3_outputs.push_back(v40_3);
                }
                const Space v39_3 = join_outputs(std::move(v39_3_outputs));
                v38_2_outputs.push_back(v39_3);
              }
              const Space v38_2 = join_outputs(std::move(v38_2_outputs));
              v37_3_outputs.push_back(v38_2);
            }
            const Space v37_3 = join_outputs(std::move(v37_3_outputs));
            v36_3_outputs.push_back(v37_3);
          }
          const Space v36_3 = join_outputs(std::move(v36_3_outputs));
          v35_3_outputs.push_back(v36_3);
        }
        const Space v35_3 = join_outputs(std::move(v35_3_outputs));
        v34_2_outputs.push_back(v35_3);
      }
      const Space v34_2 = join_outputs(std::move(v34_2_outputs));
      v9_11_outputs.push_back(v34_2);
    }
    const Space v9_11 = join_outputs(std::move(v9_11_outputs));
    const Space v9_12 = unite(v9_9,v9_11);
    const Space v9_13 = unwrap(v0_12,constant_4);
    const Space v9_14 = subtract(v9_12,v9_13);
    const Space v9_15 = unwrap(v0_12,constant_5);
    const Space v9_16 = subtract(v9_14,v9_15);
    const Space v9_17 = wrap(v9_16,constant_4);
    const Space v9_18 = unite(v9_1,v9_6);
    const Space v9_19 = wrap(v9_18,constant_2);
    const Space v9_20 = unite(v9_17,v9_19);
    const Space v9_21 = unite(v9_20,v0_12);
    Space v0_12_next = unite(v0_12,v9_21);
    if (equal(v0_12_next,v0_12)) break;
    v0_12 = std::move(v0_12_next);
  }
  const Space v0_13 = unwrap(v0_12,constant_5);
  return v0_13;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v42_3 = wrap(s0,p0);
  const Space v42_4 = wrap(v42_3,p1);
  const Space v42_6 = wrap(v42_4,constant_3);
  return v42_6;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v43_5 = unwrap(s1,constant_2);
  const Space v43_7 = unwrap(v43_5,constant_3);
  const Space v43_8 = unwrap(v43_7,p0);
  const auto v43_10_branches = branches(c,v43_8);
  std::vector<Space> v43_10_outputs;
  v43_10_outputs.reserve(v43_10_branches.size());
  for (const auto& v43_10_branch : v43_10_branches) {
    const Path v43_10_head{v43_10_branch.first};
    const Space& v43_10_tail = v43_10_branch.second;
    const auto v44_2_branches = branches(c,v43_10_tail);
    std::vector<Space> v44_2_outputs;
    v44_2_outputs.reserve(v44_2_branches.size());
    for (const auto& v44_2_branch : v44_2_branches) {
      const Path v44_2_head{v44_2_branch.first};
      const Space& v44_2_tail = v44_2_branch.second;
      const Path v45_2 = concat_path(v43_10_head,v44_2_head);
      const auto v45_3_branches = branches(c,v44_2_tail);
      std::vector<Space> v45_3_outputs;
      v45_3_outputs.reserve(v45_3_branches.size());
      for (const auto& v45_3_branch : v45_3_branches) {
        const Path v45_3_head{v45_3_branch.first};
        const Space& v45_3_tail = v45_3_branch.second;
        const Space v46_2 = subtract(v45_3_tail,constant_6);
        const Path v46_3 = concat_path(v45_2,v45_3_head);
        const Space v46_4 = wrap(v46_2,v46_3);
        v45_3_outputs.push_back(v46_4);
      }
      const Space v45_3 = join_outputs(std::move(v45_3_outputs));
      v44_2_outputs.push_back(v45_3);
    }
    const Space v44_2 = join_outputs(std::move(v44_2_outputs));
    v43_10_outputs.push_back(v44_2);
  }
  const Space v43_10 = join_outputs(std::move(v43_10_outputs));
  const Space v43_11 = wrap(v43_10,p1);
  return v43_11;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v47_5 = unwrap(s1,constant_1);
  const Space v47_7 = unwrap(v47_5,constant_3);
  const Space v47_8 = unwrap(v47_7,p0);
  const auto v47_10_branches = branches(c,v47_8);
  std::vector<Space> v47_10_outputs;
  v47_10_outputs.reserve(v47_10_branches.size());
  for (const auto& v47_10_branch : v47_10_branches) {
    const Path v47_10_head{v47_10_branch.first};
    const Space& v47_10_tail = v47_10_branch.second;
    const auto v48_2_branches = branches(c,v47_10_tail);
    std::vector<Space> v48_2_outputs;
    v48_2_outputs.reserve(v48_2_branches.size());
    for (const auto& v48_2_branch : v48_2_branches) {
      const Path v48_2_head{v48_2_branch.first};
      const Space& v48_2_tail = v48_2_branch.second;
      const Path v49_2 = concat_path(v47_10_head,v48_2_head);
      const auto v49_3_branches = branches(c,v48_2_tail);
      std::vector<Space> v49_3_outputs;
      v49_3_outputs.reserve(v49_3_branches.size());
      for (const auto& v49_3_branch : v49_3_branches) {
        const Path v49_3_head{v49_3_branch.first};
        const Space& v49_3_tail = v49_3_branch.second;
        const Space v50_2 = subtract(v49_3_tail,constant_6);
        const Path v50_3 = concat_path(v49_2,v49_3_head);
        const Space v50_4 = wrap(v50_2,v50_3);
        v49_3_outputs.push_back(v50_4);
      }
      const Space v49_3 = join_outputs(std::move(v49_3_outputs));
      v48_2_outputs.push_back(v49_3);
    }
    const Space v48_2 = join_outputs(std::move(v48_2_outputs));
    v47_10_outputs.push_back(v48_2);
  }
  const Space v47_10 = join_outputs(std::move(v47_10_outputs));
  const Space v47_11 = wrap(v47_10,p1);
  return v47_11;
}

static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v51_3 = wrap(s0,p0);
  const Space v51_4 = wrap(v51_3,p1);
  return v51_4;
}

static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v52_5 = unwrap(s1,constant_1);
  const Space v52_7 = unwrap(v52_5,constant_3);
  const Space v52_8 = unwrap(v52_7,p0);
  const auto v52_10_branches = branches(c,v52_8);
  std::vector<Space> v52_10_outputs;
  v52_10_outputs.reserve(v52_10_branches.size());
  for (const auto& v52_10_branch : v52_10_branches) {
    const Path v52_10_head{v52_10_branch.first};
    const Space& v52_10_tail = v52_10_branch.second;
    const auto v53_2_branches = branches(c,v52_10_tail);
    std::vector<Space> v53_2_outputs;
    v53_2_outputs.reserve(v53_2_branches.size());
    for (const auto& v53_2_branch : v53_2_branches) {
      const Path v53_2_head{v53_2_branch.first};
      const Space& v53_2_tail = v53_2_branch.second;
      const Path v54_2 = concat_path(v52_10_head,v53_2_head);
      const auto v54_3_branches = branches(c,v53_2_tail);
      std::vector<Space> v54_3_outputs;
      v54_3_outputs.reserve(v54_3_branches.size());
      for (const auto& v54_3_branch : v54_3_branches) {
        const Path v54_3_head{v54_3_branch.first};
        const Space& v54_3_tail = v54_3_branch.second;
        const Space v55_2 = subtract(v54_3_tail,constant_6);
        const Path v55_3 = concat_path(v54_2,v54_3_head);
        const Space v55_4 = wrap(v55_2,v55_3);
        v54_3_outputs.push_back(v55_4);
      }
      const Space v54_3 = join_outputs(std::move(v54_3_outputs));
      v53_2_outputs.push_back(v54_3);
    }
    const Space v53_2 = join_outputs(std::move(v53_2_outputs));
    v52_10_outputs.push_back(v53_2);
  }
  const Space v52_10 = join_outputs(std::move(v52_10_outputs));
  const Space v52_11 = wrap(v52_10,p1);
  return v52_11;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
