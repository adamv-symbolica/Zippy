#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,2,1,2,1,1,2,2};
static const Path constant_1 = Path{2,2};
static const Space constant_2 = literal_text("1 0 ");
static const Space constant_3 = literal_text("1 1 2");
static const Space constant_4 = singleton(Path{});
static const Path constant_5 = Path{1,2,1,1,2,1,1,2,2};
static const Path constant_6 = Path{2,1,1,1,2,1,1,2,2};
static const Path constant_7 = Path{1,1,2,1,2,1,1,2,2,2,1,1,1,2,1,1,2,2};
static const Path constant_8 = Path{1,2,1,1,2,1,1,2,2,2,1,1,1,2,1,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_85(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_86(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_75(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_128(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_118(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_129(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_119(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = wrap(bound_space(s0),constant_0);
  const Space v0_4 = unwrap(bound_space(s0),constant_1);
  Space v0_14_result;
  for (int v0_14_label = 1; v0_14_label <= 2; ++v0_14_label) {
    const Space v0_14_tail = child(v0_4,v0_14_label);
    if (v0_14_tail.empty()) continue;
    const Path v0_14_head{v0_14_label};
    const Space v1_2 = singleton(v0_14_head);
    const Space v1_3 = intersect(constant_3,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_4 : Space{});
    const Space v1_5 = subtract(constant_2,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_14_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_3,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_4 : Space{});
        const Space v3_5 = subtract(constant_2,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_14_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail);
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_3,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_4 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_14_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail);
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_3,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_4 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_14_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_3,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_4 : Space{});
        const Space v7_5 = subtract(constant_2,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_14_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_3,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_4 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_14_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_14_result = unite(v0_14_result,v1_12);
  }
  const Space v0_14 = std::move(v0_14_result);
  const Space v0_16 = wrap(v0_14,constant_5);
  const Space v0_17 = unite(v0_2,v0_16);
  Space v0_57 = v0_17;
  for (;;) {
    const Space v10_1 = unwrap(v0_57,constant_0);
    const Space v10_2 = unwrap(v0_57,constant_5);
    const Space v10_3 = unite(v10_1,v10_2);
    const Space v10_4 = wrap(v10_3,constant_0);
    const Space v10_5 = unwrap(v10_1,constant_6);
    Space v10_6_result;
    for (int v10_6_label = 1; v10_6_label <= 2; ++v10_6_label) {
      const Space v10_6_tail = child(v10_5,v10_6_label);
      if (v10_6_tail.empty()) continue;
      const Path v10_6_head{v10_6_label};
      const Space v11_2 = singleton(v10_6_head);
      const Space v11_3 = intersect(constant_3,v11_2);
      const Space v11_4 = (has_head(v11_3) ? constant_4 : Space{});
      const Space v11_5 = subtract(constant_2,v11_4);
      Space v11_7;
      if (!v11_5.empty()) {
        Space v12_6_result;
        for (int v12_6_label = 1; v12_6_label <= 2; ++v12_6_label) {
          const Space v12_6_tail = child(v10_6_tail,v12_6_label);
          if (v12_6_tail.empty()) continue;
          const Path v12_6_head{v12_6_label};
          const Space v13_2 = singleton(v12_6_head);
          const Space v13_3 = intersect(constant_3,v13_2);
          const Space v13_4 = (has_head(v13_3) ? constant_4 : Space{});
          const Space v13_5 = subtract(constant_2,v13_4);
          Space v13_8;
          if (!v13_5.empty()) {
            const Path v14_6 = concat_path(v10_6_head,v12_6_head);
            const Space v14_7 = routine_4(c, v14_6, v12_6_tail, v0_57);
            v13_8 = compose(v13_5,v14_7);
          }
          const Space v13_9 = intersect(constant_3,v13_2);
          const Space v13_10 = (has_head(v13_9) ? constant_4 : Space{});
          Space v13_12;
          if (!v13_10.empty()) {
            const Path v15_6 = concat_path(v10_6_head,v12_6_head);
            const Space v15_11 = routine_5(c, v15_6, v12_6_tail, v0_57);
            v13_12 = compose(v13_10,v15_11);
          }
          const Space v13_13 = unite(v13_8,v13_12);
          v12_6_result = unite(v12_6_result,v13_13);
        }
        const Space v12_6 = std::move(v12_6_result);
        v11_7 = compose(v11_5,v12_6);
      }
      const Space v11_8 = intersect(constant_3,v11_2);
      const Space v11_9 = (has_head(v11_8) ? constant_4 : Space{});
      Space v11_11;
      if (!v11_9.empty()) {
        Space v16_10_result;
        for (int v16_10_label = 1; v16_10_label <= 2; ++v16_10_label) {
          const Space v16_10_tail = child(v10_6_tail,v16_10_label);
          if (v16_10_tail.empty()) continue;
          const Path v16_10_head{v16_10_label};
          const Space v17_2 = singleton(v16_10_head);
          const Space v17_3 = intersect(constant_3,v17_2);
          const Space v17_4 = (has_head(v17_3) ? constant_4 : Space{});
          const Space v17_5 = subtract(constant_2,v17_4);
          Space v17_8;
          if (!v17_5.empty()) {
            const Path v18_6 = concat_path(v10_6_head,v16_10_head);
            const Space v18_7 = routine_4(c, v18_6, v16_10_tail, v0_57);
            v17_8 = compose(v17_5,v18_7);
          }
          const Space v17_9 = intersect(constant_3,v17_2);
          const Space v17_10 = (has_head(v17_9) ? constant_4 : Space{});
          Space v17_12;
          if (!v17_10.empty()) {
            const Path v19_6 = concat_path(v10_6_head,v16_10_head);
            const Space v19_11 = routine_6(c, v19_6, v16_10_tail, v0_57);
            v17_12 = compose(v17_10,v19_11);
          }
          const Space v17_13 = unite(v17_8,v17_12);
          v16_10_result = unite(v16_10_result,v17_13);
        }
        const Space v16_10 = std::move(v16_10_result);
        v11_11 = compose(v11_9,v16_10);
      }
      const Space v11_12 = unite(v11_7,v11_11);
      v10_6_result = unite(v10_6_result,v11_12);
    }
    const Space v10_6 = std::move(v10_6_result);
    const Space v10_7 = unwrap(v10_1,constant_1);
    Space v10_8_result;
    for (int v10_8_label = 1; v10_8_label <= 2; ++v10_8_label) {
      const Space v10_8_tail = child(v10_7,v10_8_label);
      if (v10_8_tail.empty()) continue;
      const Path v10_8_head{v10_8_label};
      const Space v20_2 = singleton(v10_8_head);
      const Space v20_3 = intersect(constant_3,v20_2);
      const Space v20_4 = (has_head(v20_3) ? constant_4 : Space{});
      const Space v20_5 = subtract(constant_2,v20_4);
      Space v20_7;
      if (!v20_5.empty()) {
        Space v21_6_result;
        for (int v21_6_label = 1; v21_6_label <= 2; ++v21_6_label) {
          const Space v21_6_tail = child(v10_8_tail,v21_6_label);
          if (v21_6_tail.empty()) continue;
          const Path v21_6_head{v21_6_label};
          const Space v22_2 = singleton(v21_6_head);
          const Space v22_3 = intersect(constant_3,v22_2);
          const Space v22_4 = (has_head(v22_3) ? constant_4 : Space{});
          const Space v22_5 = subtract(constant_2,v22_4);
          Space v22_8;
          if (!v22_5.empty()) {
            const Path v23_6 = concat_path(v10_8_head,v21_6_head);
            const Space v23_7 = routine_7(c, v23_6, v21_6_tail);
            v22_8 = compose(v22_5,v23_7);
          }
          const Space v22_9 = intersect(constant_3,v22_2);
          const Space v22_10 = (has_head(v22_9) ? constant_4 : Space{});
          Space v22_12;
          if (!v22_10.empty()) {
            const Path v24_6 = concat_path(v10_8_head,v21_6_head);
            const Space v24_11 = routine_8(c, v24_6, v21_6_tail);
            v22_12 = compose(v22_10,v24_11);
          }
          const Space v22_13 = unite(v22_8,v22_12);
          v21_6_result = unite(v21_6_result,v22_13);
        }
        const Space v21_6 = std::move(v21_6_result);
        v20_7 = compose(v20_5,v21_6);
      }
      const Space v20_8 = intersect(constant_3,v20_2);
      const Space v20_9 = (has_head(v20_8) ? constant_4 : Space{});
      Space v20_11;
      if (!v20_9.empty()) {
        Space v25_10_result;
        for (int v25_10_label = 1; v25_10_label <= 2; ++v25_10_label) {
          const Space v25_10_tail = child(v10_8_tail,v25_10_label);
          if (v25_10_tail.empty()) continue;
          const Path v25_10_head{v25_10_label};
          const Space v26_2 = singleton(v25_10_head);
          const Space v26_3 = intersect(constant_3,v26_2);
          const Space v26_4 = (has_head(v26_3) ? constant_4 : Space{});
          const Space v26_5 = subtract(constant_2,v26_4);
          Space v26_8;
          if (!v26_5.empty()) {
            const Path v27_6 = concat_path(v10_8_head,v25_10_head);
            const Space v27_7 = routine_7(c, v27_6, v25_10_tail);
            v26_8 = compose(v26_5,v27_7);
          }
          const Space v26_9 = intersect(constant_3,v26_2);
          const Space v26_10 = (has_head(v26_9) ? constant_4 : Space{});
          Space v26_12;
          if (!v26_10.empty()) {
            const Path v28_6 = concat_path(v10_8_head,v25_10_head);
            const Space v28_11 = routine_9(c, v28_6, v25_10_tail);
            v26_12 = compose(v26_10,v28_11);
          }
          const Space v26_13 = unite(v26_8,v26_12);
          v25_10_result = unite(v25_10_result,v26_13);
        }
        const Space v25_10 = std::move(v25_10_result);
        v20_11 = compose(v20_9,v25_10);
      }
      const Space v20_12 = unite(v20_7,v20_11);
      v10_8_result = unite(v10_8_result,v20_12);
    }
    const Space v10_8 = std::move(v10_8_result);
    const Space v10_9 = unite(v10_6,v10_8);
    const Space v10_10 = unwrap(v10_2,constant_6);
    Space v10_11_result;
    for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
      const Space v10_11_tail = child(v10_10,v10_11_label);
      if (v10_11_tail.empty()) continue;
      const Path v10_11_head{v10_11_label};
      const Space v29_2 = singleton(v10_11_head);
      const Space v29_3 = intersect(constant_3,v29_2);
      const Space v29_4 = (has_head(v29_3) ? constant_4 : Space{});
      const Space v29_5 = subtract(constant_2,v29_4);
      Space v29_7;
      if (!v29_5.empty()) {
        Space v30_6_result;
        for (int v30_6_label = 1; v30_6_label <= 2; ++v30_6_label) {
          const Space v30_6_tail = child(v10_11_tail,v30_6_label);
          if (v30_6_tail.empty()) continue;
          const Path v30_6_head{v30_6_label};
          const Space v31_2 = singleton(v30_6_head);
          const Space v31_3 = intersect(constant_3,v31_2);
          const Space v31_4 = (has_head(v31_3) ? constant_4 : Space{});
          const Space v31_5 = subtract(constant_2,v31_4);
          Space v31_8;
          if (!v31_5.empty()) {
            const Path v32_6 = concat_path(v10_11_head,v30_6_head);
            const Space v32_7 = routine_10(c, v32_6, v30_6_tail, v0_57);
            v31_8 = compose(v31_5,v32_7);
          }
          const Space v31_9 = intersect(constant_3,v31_2);
          const Space v31_10 = (has_head(v31_9) ? constant_4 : Space{});
          Space v31_12;
          if (!v31_10.empty()) {
            const Path v33_6 = concat_path(v10_11_head,v30_6_head);
            const Space v33_11 = routine_11(c, v33_6, v30_6_tail, v0_57);
            v31_12 = compose(v31_10,v33_11);
          }
          const Space v31_13 = unite(v31_8,v31_12);
          v30_6_result = unite(v30_6_result,v31_13);
        }
        const Space v30_6 = std::move(v30_6_result);
        v29_7 = compose(v29_5,v30_6);
      }
      const Space v29_8 = intersect(constant_3,v29_2);
      const Space v29_9 = (has_head(v29_8) ? constant_4 : Space{});
      Space v29_11;
      if (!v29_9.empty()) {
        Space v34_10_result;
        for (int v34_10_label = 1; v34_10_label <= 2; ++v34_10_label) {
          const Space v34_10_tail = child(v10_11_tail,v34_10_label);
          if (v34_10_tail.empty()) continue;
          const Path v34_10_head{v34_10_label};
          const Space v35_2 = singleton(v34_10_head);
          const Space v35_3 = intersect(constant_3,v35_2);
          const Space v35_4 = (has_head(v35_3) ? constant_4 : Space{});
          const Space v35_5 = subtract(constant_2,v35_4);
          Space v35_8;
          if (!v35_5.empty()) {
            const Path v36_6 = concat_path(v10_11_head,v34_10_head);
            const Space v36_7 = routine_10(c, v36_6, v34_10_tail, v0_57);
            v35_8 = compose(v35_5,v36_7);
          }
          const Space v35_9 = intersect(constant_3,v35_2);
          const Space v35_10 = (has_head(v35_9) ? constant_4 : Space{});
          Space v35_12;
          if (!v35_10.empty()) {
            const Path v37_6 = concat_path(v10_11_head,v34_10_head);
            const Space v37_11 = routine_12(c, v37_6, v34_10_tail, v0_57);
            v35_12 = compose(v35_10,v37_11);
          }
          const Space v35_13 = unite(v35_8,v35_12);
          v34_10_result = unite(v34_10_result,v35_13);
        }
        const Space v34_10 = std::move(v34_10_result);
        v29_11 = compose(v29_9,v34_10);
      }
      const Space v29_12 = unite(v29_7,v29_11);
      v10_11_result = unite(v10_11_result,v29_12);
    }
    const Space v10_11 = std::move(v10_11_result);
    const Space v10_12 = unite(v10_9,v10_11);
    Space v10_13_result;
    for (int v10_13_label = 1; v10_13_label <= 2; ++v10_13_label) {
      const Space v10_13_tail = child(v10_10,v10_13_label);
      if (v10_13_tail.empty()) continue;
      const Path v10_13_head{v10_13_label};
      const Space v38_2 = singleton(v10_13_head);
      const Space v38_3 = intersect(constant_3,v38_2);
      const Space v38_4 = (has_head(v38_3) ? constant_4 : Space{});
      const Space v38_5 = subtract(constant_2,v38_4);
      Space v38_7;
      if (!v38_5.empty()) {
        Space v39_6_result;
        for (int v39_6_label = 1; v39_6_label <= 2; ++v39_6_label) {
          const Space v39_6_tail = child(v10_13_tail,v39_6_label);
          if (v39_6_tail.empty()) continue;
          const Path v39_6_head{v39_6_label};
          const Space v40_2 = singleton(v39_6_head);
          const Space v40_3 = intersect(constant_3,v40_2);
          const Space v40_4 = (has_head(v40_3) ? constant_4 : Space{});
          const Space v40_5 = subtract(constant_2,v40_4);
          Space v40_8;
          if (!v40_5.empty()) {
            const Path v41_6 = concat_path(v10_13_head,v39_6_head);
            const Space v41_7 = routine_13(c, v41_6, v39_6_tail, v0_57);
            v40_8 = compose(v40_5,v41_7);
          }
          const Space v40_9 = intersect(constant_3,v40_2);
          const Space v40_10 = (has_head(v40_9) ? constant_4 : Space{});
          Space v40_12;
          if (!v40_10.empty()) {
            const Path v42_6 = concat_path(v10_13_head,v39_6_head);
            const Space v42_11 = routine_14(c, v42_6, v39_6_tail, v0_57);
            v40_12 = compose(v40_10,v42_11);
          }
          const Space v40_13 = unite(v40_8,v40_12);
          v39_6_result = unite(v39_6_result,v40_13);
        }
        const Space v39_6 = std::move(v39_6_result);
        v38_7 = compose(v38_5,v39_6);
      }
      const Space v38_8 = intersect(constant_3,v38_2);
      const Space v38_9 = (has_head(v38_8) ? constant_4 : Space{});
      Space v38_11;
      if (!v38_9.empty()) {
        Space v43_10_result;
        for (int v43_10_label = 1; v43_10_label <= 2; ++v43_10_label) {
          const Space v43_10_tail = child(v10_13_tail,v43_10_label);
          if (v43_10_tail.empty()) continue;
          const Path v43_10_head{v43_10_label};
          const Space v44_2 = singleton(v43_10_head);
          const Space v44_3 = intersect(constant_3,v44_2);
          const Space v44_4 = (has_head(v44_3) ? constant_4 : Space{});
          const Space v44_5 = subtract(constant_2,v44_4);
          Space v44_8;
          if (!v44_5.empty()) {
            const Path v45_6 = concat_path(v10_13_head,v43_10_head);
            const Space v45_7 = routine_13(c, v45_6, v43_10_tail, v0_57);
            v44_8 = compose(v44_5,v45_7);
          }
          const Space v44_9 = intersect(constant_3,v44_2);
          const Space v44_10 = (has_head(v44_9) ? constant_4 : Space{});
          Space v44_12;
          if (!v44_10.empty()) {
            const Path v46_6 = concat_path(v10_13_head,v43_10_head);
            const Space v46_11 = routine_15(c, v46_6, v43_10_tail, v0_57);
            v44_12 = compose(v44_10,v46_11);
          }
          const Space v44_13 = unite(v44_8,v44_12);
          v43_10_result = unite(v43_10_result,v44_13);
        }
        const Space v43_10 = std::move(v43_10_result);
        v38_11 = compose(v38_9,v43_10);
      }
      const Space v38_12 = unite(v38_7,v38_11);
      v10_13_result = unite(v10_13_result,v38_12);
    }
    const Space v10_13 = std::move(v10_13_result);
    const Space v10_14 = unite(v10_12,v10_13);
    const Space v10_15 = unwrap(v0_57,constant_7);
    const Space v10_16 = subtract(v10_14,v10_15);
    const Space v10_17 = unwrap(v0_57,constant_8);
    const Space v10_18 = subtract(v10_16,v10_17);
    const Space v10_19 = wrap(v10_18,constant_8);
    const Space v10_20 = unite(v10_4,v10_19);
    const Space v10_21 = unite(v10_20,v0_57);
    Space v0_57_next = unite(v0_57,v10_21);
    if (equal(v0_57_next,v0_57)) break;
    v0_57 = std::move(v0_57_next);
  }
  const Space v0_58 = unwrap(v0_57,constant_7);
  return v0_58;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v47_11_result;
  for (int v47_11_label = 1; v47_11_label <= 2; ++v47_11_label) {
    const Space v47_11_tail = child(s0,v47_11_label);
    if (v47_11_tail.empty()) continue;
    const Path v47_11_head{v47_11_label};
    const Space v48_2 = singleton(v47_11_head);
    const Space v48_3 = intersect(constant_3,v48_2);
    const Space v48_4 = (has_head(v48_3) ? constant_4 : Space{});
    const Space v48_5 = subtract(constant_2,v48_4);
    Space v48_8;
    if (!v48_5.empty()) {
      const Path v49_6 = concat_path(p0,v47_11_head);
      Space v49_7_result;
      for (int v49_7_label = 1; v49_7_label <= 2; ++v49_7_label) {
        const Space v49_7_tail = child(v47_11_tail,v49_7_label);
        if (v49_7_tail.empty()) continue;
        const Path v49_7_head{v49_7_label};
        const Space v50_2 = singleton(v49_7_head);
        const Space v50_3 = intersect(constant_3,v50_2);
        const Space v50_4 = (has_head(v50_3) ? constant_4 : Space{});
        const Space v50_5 = subtract(constant_2,v50_4);
        Space v50_8;
        if (!v50_5.empty()) {
          const Path v51_6 = concat_path(v49_6,v49_7_head);
          const Space v51_7 = routine_16(c, v51_6, v49_7_tail);
          v50_8 = compose(v50_5,v51_7);
        }
        const Space v50_9 = intersect(constant_3,v50_2);
        const Space v50_10 = (has_head(v50_9) ? constant_4 : Space{});
        Space v50_12;
        if (!v50_10.empty()) {
          const Path v52_6 = concat_path(v49_6,v49_7_head);
          const Space v52_11 = routine_17(c, v52_6, v49_7_tail);
          v50_12 = compose(v50_10,v52_11);
        }
        const Space v50_13 = unite(v50_8,v50_12);
        v49_7_result = unite(v49_7_result,v50_13);
      }
      const Space v49_7 = std::move(v49_7_result);
      v48_8 = compose(v48_5,v49_7);
    }
    const Space v48_9 = intersect(constant_3,v48_2);
    const Space v48_10 = (has_head(v48_9) ? constant_4 : Space{});
    Space v48_12;
    if (!v48_10.empty()) {
      const Path v53_6 = concat_path(p0,v47_11_head);
      Space v53_11_result;
      for (int v53_11_label = 1; v53_11_label <= 2; ++v53_11_label) {
        const Space v53_11_tail = child(v47_11_tail,v53_11_label);
        if (v53_11_tail.empty()) continue;
        const Path v53_11_head{v53_11_label};
        const Space v54_2 = singleton(v53_11_head);
        const Space v54_3 = intersect(constant_3,v54_2);
        const Space v54_4 = (has_head(v54_3) ? constant_4 : Space{});
        const Space v54_5 = subtract(constant_2,v54_4);
        Space v54_8;
        if (!v54_5.empty()) {
          const Path v55_6 = concat_path(v53_6,v53_11_head);
          const Space v55_7 = routine_16(c, v55_6, v53_11_tail);
          v54_8 = compose(v54_5,v55_7);
        }
        const Space v54_9 = intersect(constant_3,v54_2);
        const Space v54_10 = (has_head(v54_9) ? constant_4 : Space{});
        Space v54_12;
        if (!v54_10.empty()) {
          const Path v56_6 = concat_path(v53_6,v53_11_head);
          const Space v56_11 = routine_3(c, v56_6, v53_11_tail);
          v54_12 = compose(v54_10,v56_11);
        }
        const Space v54_13 = unite(v54_8,v54_12);
        v53_11_result = unite(v53_11_result,v54_13);
      }
      const Space v53_11 = std::move(v53_11_result);
      v48_12 = compose(v48_10,v53_11);
    }
    const Space v48_13 = unite(v48_8,v48_12);
    v47_11_result = unite(v47_11_result,v48_13);
  }
  const Space v47_11 = std::move(v47_11_result);
  return v47_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v57_11_result;
  for (int v57_11_label = 1; v57_11_label <= 2; ++v57_11_label) {
    const Space v57_11_tail = child(s0,v57_11_label);
    if (v57_11_tail.empty()) continue;
    const Path v57_11_head{v57_11_label};
    const Space v58_2 = singleton(v57_11_head);
    const Space v58_3 = intersect(constant_3,v58_2);
    const Space v58_4 = (has_head(v58_3) ? constant_4 : Space{});
    const Space v58_5 = subtract(constant_2,v58_4);
    Space v58_8;
    if (!v58_5.empty()) {
      const Path v59_6 = concat_path(p0,v57_11_head);
      Space v59_7_result;
      for (int v59_7_label = 1; v59_7_label <= 2; ++v59_7_label) {
        const Space v59_7_tail = child(v57_11_tail,v59_7_label);
        if (v59_7_tail.empty()) continue;
        const Path v59_7_head{v59_7_label};
        const Space v60_2 = singleton(v59_7_head);
        const Space v60_3 = intersect(constant_3,v60_2);
        const Space v60_4 = (has_head(v60_3) ? constant_4 : Space{});
        const Space v60_5 = subtract(constant_2,v60_4);
        Space v60_8;
        if (!v60_5.empty()) {
          const Path v61_6 = concat_path(v59_6,v59_7_head);
          const Space v61_7 = routine_16(c, v61_6, v59_7_tail);
          v60_8 = compose(v60_5,v61_7);
        }
        const Space v60_9 = intersect(constant_3,v60_2);
        const Space v60_10 = (has_head(v60_9) ? constant_4 : Space{});
        Space v60_12;
        if (!v60_10.empty()) {
          const Path v62_6 = concat_path(v59_6,v59_7_head);
          const Space v62_11 = routine_17(c, v62_6, v59_7_tail);
          v60_12 = compose(v60_10,v62_11);
        }
        const Space v60_13 = unite(v60_8,v60_12);
        v59_7_result = unite(v59_7_result,v60_13);
      }
      const Space v59_7 = std::move(v59_7_result);
      v58_8 = compose(v58_5,v59_7);
    }
    const Space v58_9 = intersect(constant_3,v58_2);
    const Space v58_10 = (has_head(v58_9) ? constant_4 : Space{});
    Space v58_12;
    if (!v58_10.empty()) {
      const Path v63_6 = concat_path(p0,v57_11_head);
      Space v63_11_result;
      for (int v63_11_label = 1; v63_11_label <= 2; ++v63_11_label) {
        const Space v63_11_tail = child(v57_11_tail,v63_11_label);
        if (v63_11_tail.empty()) continue;
        const Path v63_11_head{v63_11_label};
        const Space v64_2 = singleton(v63_11_head);
        const Space v64_3 = intersect(constant_3,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_4 : Space{});
        const Space v64_5 = subtract(constant_2,v64_4);
        Space v64_7;
        if (!v64_5.empty()) {
          const Space v65_6 = routine_18(c, v63_11_head, v63_6, v63_11_tail);
          v64_7 = compose(v64_5,v65_6);
        }
        const Space v64_8 = intersect(constant_3,v64_2);
        const Space v64_9 = (has_head(v64_8) ? constant_4 : Space{});
        Space v64_11;
        if (!v64_9.empty()) {
          const Space v66_10 = routine_19(c, v63_11_head, v63_6, v63_11_tail);
          v64_11 = compose(v64_9,v66_10);
        }
        const Space v64_12 = unite(v64_7,v64_11);
        v63_11_result = unite(v63_11_result,v64_12);
      }
      const Space v63_11 = std::move(v63_11_result);
      v58_12 = compose(v58_10,v63_11);
    }
    const Space v58_13 = unite(v58_8,v58_12);
    v57_11_result = unite(v57_11_result,v58_13);
  }
  const Space v57_11 = std::move(v57_11_result);
  return v57_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v67_11_result;
  for (int v67_11_label = 1; v67_11_label <= 2; ++v67_11_label) {
    const Space v67_11_tail = child(s0,v67_11_label);
    if (v67_11_tail.empty()) continue;
    const Path v67_11_head{v67_11_label};
    const Space v68_2 = singleton(v67_11_head);
    const Space v68_3 = intersect(constant_3,v68_2);
    const Space v68_4 = (has_head(v68_3) ? constant_4 : Space{});
    const Space v68_5 = subtract(constant_2,v68_4);
    Space v68_7;
    if (!v68_5.empty()) {
      Space v69_6_result;
      for (int v69_6_label = 1; v69_6_label <= 2; ++v69_6_label) {
        const Space v69_6_tail = child(v67_11_tail,v69_6_label);
        if (v69_6_tail.empty()) continue;
        const Path v69_6_head{v69_6_label};
        const Space v70_2 = singleton(v69_6_head);
        const Space v70_3 = intersect(constant_3,v70_2);
        const Space v70_4 = (has_head(v70_3) ? constant_4 : Space{});
        const Space v70_5 = subtract(constant_2,v70_4);
        Space v70_8;
        if (!v70_5.empty()) {
          const Path v71_6 = concat_path(v67_11_head,v69_6_head);
          const Space v71_7 = routine_20(c, v71_6, p0, v69_6_tail);
          v70_8 = compose(v70_5,v71_7);
        }
        const Space v70_9 = intersect(constant_3,v70_2);
        const Space v70_10 = (has_head(v70_9) ? constant_4 : Space{});
        Space v70_12;
        if (!v70_10.empty()) {
          const Path v72_6 = concat_path(v67_11_head,v69_6_head);
          const Space v72_11 = routine_21(c, v72_6, p0, v69_6_tail);
          v70_12 = compose(v70_10,v72_11);
        }
        const Space v70_13 = unite(v70_8,v70_12);
        v69_6_result = unite(v69_6_result,v70_13);
      }
      const Space v69_6 = std::move(v69_6_result);
      v68_7 = compose(v68_5,v69_6);
    }
    const Space v68_8 = intersect(constant_3,v68_2);
    const Space v68_9 = (has_head(v68_8) ? constant_4 : Space{});
    Space v68_11;
    if (!v68_9.empty()) {
      Space v73_10_result;
      for (int v73_10_label = 1; v73_10_label <= 2; ++v73_10_label) {
        const Space v73_10_tail = child(v67_11_tail,v73_10_label);
        if (v73_10_tail.empty()) continue;
        const Path v73_10_head{v73_10_label};
        const Space v74_2 = singleton(v73_10_head);
        const Space v74_3 = intersect(constant_3,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_4 : Space{});
        const Space v74_5 = subtract(constant_2,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v67_11_head,v73_10_head);
          const Space v75_7 = routine_20(c, v75_6, p0, v73_10_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_3,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_4 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v67_11_head,v73_10_head);
          const Space v76_11 = routine_22(c, v76_6, p0, v73_10_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_10_result = unite(v73_10_result,v74_13);
      }
      const Space v73_10 = std::move(v73_10_result);
      v68_11 = compose(v68_9,v73_10);
    }
    const Space v68_12 = unite(v68_7,v68_11);
    v67_11_result = unite(v67_11_result,v68_12);
  }
  const Space v67_11 = std::move(v67_11_result);
  return v67_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v77_12_result;
  for (int v77_12_label = 1; v77_12_label <= 2; ++v77_12_label) {
    const Space v77_12_tail = child(s0,v77_12_label);
    if (v77_12_tail.empty()) continue;
    const Path v77_12_head{v77_12_label};
    const Space v78_2 = singleton(v77_12_head);
    const Space v78_3 = intersect(constant_3,v78_2);
    const Space v78_4 = (has_head(v78_3) ? constant_4 : Space{});
    const Space v78_5 = subtract(constant_2,v78_4);
    Space v78_8;
    if (!v78_5.empty()) {
      const Path v79_6 = concat_path(p0,v77_12_head);
      Space v79_7_result;
      for (int v79_7_label = 1; v79_7_label <= 2; ++v79_7_label) {
        const Space v79_7_tail = child(v77_12_tail,v79_7_label);
        if (v79_7_tail.empty()) continue;
        const Path v79_7_head{v79_7_label};
        const Space v80_2 = singleton(v79_7_head);
        const Space v80_3 = intersect(constant_3,v80_2);
        const Space v80_4 = (has_head(v80_3) ? constant_4 : Space{});
        const Space v80_5 = subtract(constant_2,v80_4);
        Space v80_8;
        if (!v80_5.empty()) {
          const Path v81_6 = concat_path(v79_6,v79_7_head);
          const Space v81_7 = routine_23(c, v81_6, v79_7_tail, s1);
          v80_8 = compose(v80_5,v81_7);
        }
        const Space v80_9 = intersect(constant_3,v80_2);
        const Space v80_10 = (has_head(v80_9) ? constant_4 : Space{});
        Space v80_12;
        if (!v80_10.empty()) {
          const Path v82_6 = concat_path(v79_6,v79_7_head);
          const Space v82_11 = routine_24(c, v82_6, v79_7_tail, s1);
          v80_12 = compose(v80_10,v82_11);
        }
        const Space v80_13 = unite(v80_8,v80_12);
        v79_7_result = unite(v79_7_result,v80_13);
      }
      const Space v79_7 = std::move(v79_7_result);
      v78_8 = compose(v78_5,v79_7);
    }
    const Space v78_9 = intersect(constant_3,v78_2);
    const Space v78_10 = (has_head(v78_9) ? constant_4 : Space{});
    Space v78_12;
    if (!v78_10.empty()) {
      const Path v83_6 = concat_path(p0,v77_12_head);
      Space v83_11_result;
      for (int v83_11_label = 1; v83_11_label <= 2; ++v83_11_label) {
        const Space v83_11_tail = child(v77_12_tail,v83_11_label);
        if (v83_11_tail.empty()) continue;
        const Path v83_11_head{v83_11_label};
        const Space v84_2 = singleton(v83_11_head);
        const Space v84_3 = intersect(constant_3,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_4 : Space{});
        const Space v84_5 = subtract(constant_2,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_11_head);
          const Space v85_7 = routine_23(c, v85_6, v83_11_tail, s1);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_3,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_4 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_11_head);
          const Space v86_11 = routine_6(c, v86_6, v83_11_tail, s1);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_11_result = unite(v83_11_result,v84_13);
      }
      const Space v83_11 = std::move(v83_11_result);
      v78_12 = compose(v78_10,v83_11);
    }
    const Space v78_13 = unite(v78_8,v78_12);
    v77_12_result = unite(v77_12_result,v78_13);
  }
  const Space v77_12 = std::move(v77_12_result);
  return v77_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v87_12_result;
  for (int v87_12_label = 1; v87_12_label <= 2; ++v87_12_label) {
    const Space v87_12_tail = child(s0,v87_12_label);
    if (v87_12_tail.empty()) continue;
    const Path v87_12_head{v87_12_label};
    const Space v88_2 = singleton(v87_12_head);
    const Space v88_3 = intersect(constant_3,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_4 : Space{});
    const Space v88_5 = subtract(constant_2,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_12_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_12_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_3,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_4 : Space{});
        const Space v90_5 = subtract(constant_2,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_23(c, v91_6, v89_7_tail, s1);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_3,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_4 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_24(c, v92_6, v89_7_tail, s1);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_3,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_4 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_12_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_12_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_3,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_4 : Space{});
        const Space v94_5 = subtract(constant_2,v94_4);
        Space v94_7;
        if (!v94_5.empty()) {
          const Space v95_6 = routine_25(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_7 = compose(v94_5,v95_6);
        }
        const Space v94_8 = intersect(constant_3,v94_2);
        const Space v94_9 = (has_head(v94_8) ? constant_4 : Space{});
        Space v94_11;
        if (!v94_9.empty()) {
          const Space v96_10 = routine_26(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_11 = compose(v94_9,v96_10);
        }
        const Space v94_12 = unite(v94_7,v94_11);
        v93_11_result = unite(v93_11_result,v94_12);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_12_result = unite(v87_12_result,v88_13);
  }
  const Space v87_12 = std::move(v87_12_result);
  return v87_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v97_12_result;
  for (int v97_12_label = 1; v97_12_label <= 2; ++v97_12_label) {
    const Space v97_12_tail = child(s0,v97_12_label);
    if (v97_12_tail.empty()) continue;
    const Path v97_12_head{v97_12_label};
    const Space v98_2 = singleton(v97_12_head);
    const Space v98_3 = intersect(constant_3,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_4 : Space{});
    const Space v98_5 = subtract(constant_2,v98_4);
    Space v98_7;
    if (!v98_5.empty()) {
      Space v99_6_result;
      for (int v99_6_label = 1; v99_6_label <= 2; ++v99_6_label) {
        const Space v99_6_tail = child(v97_12_tail,v99_6_label);
        if (v99_6_tail.empty()) continue;
        const Path v99_6_head{v99_6_label};
        const Space v100_2 = singleton(v99_6_head);
        const Space v100_3 = intersect(constant_3,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_4 : Space{});
        const Space v100_5 = subtract(constant_2,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v97_12_head,v99_6_head);
          const Space v101_7 = routine_27(c, v101_6, p0, v99_6_tail, s1);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_3,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_4 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v97_12_head,v99_6_head);
          const Space v102_11 = routine_28(c, v102_6, p0, v99_6_tail, s1);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_6_result = unite(v99_6_result,v100_13);
      }
      const Space v99_6 = std::move(v99_6_result);
      v98_7 = compose(v98_5,v99_6);
    }
    const Space v98_8 = intersect(constant_3,v98_2);
    const Space v98_9 = (has_head(v98_8) ? constant_4 : Space{});
    Space v98_11;
    if (!v98_9.empty()) {
      Space v103_10_result;
      for (int v103_10_label = 1; v103_10_label <= 2; ++v103_10_label) {
        const Space v103_10_tail = child(v97_12_tail,v103_10_label);
        if (v103_10_tail.empty()) continue;
        const Path v103_10_head{v103_10_label};
        const Space v104_2 = singleton(v103_10_head);
        const Space v104_3 = intersect(constant_3,v104_2);
        const Space v104_4 = (has_head(v104_3) ? constant_4 : Space{});
        const Space v104_5 = subtract(constant_2,v104_4);
        Space v104_8;
        if (!v104_5.empty()) {
          const Path v105_6 = concat_path(v97_12_head,v103_10_head);
          const Space v105_7 = routine_27(c, v105_6, p0, v103_10_tail, s1);
          v104_8 = compose(v104_5,v105_7);
        }
        const Space v104_9 = intersect(constant_3,v104_2);
        const Space v104_10 = (has_head(v104_9) ? constant_4 : Space{});
        Space v104_12;
        if (!v104_10.empty()) {
          const Path v106_6 = concat_path(v97_12_head,v103_10_head);
          const Space v106_11 = routine_29(c, v106_6, p0, v103_10_tail, s1);
          v104_12 = compose(v104_10,v106_11);
        }
        const Space v104_13 = unite(v104_8,v104_12);
        v103_10_result = unite(v103_10_result,v104_13);
      }
      const Space v103_10 = std::move(v103_10_result);
      v98_11 = compose(v98_9,v103_10);
    }
    const Space v98_12 = unite(v98_7,v98_11);
    v97_12_result = unite(v97_12_result,v98_12);
  }
  const Space v97_12 = std::move(v97_12_result);
  return v97_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v107_11_result;
  for (int v107_11_label = 1; v107_11_label <= 2; ++v107_11_label) {
    const Space v107_11_tail = child(s0,v107_11_label);
    if (v107_11_tail.empty()) continue;
    const Path v107_11_head{v107_11_label};
    const Space v108_2 = singleton(v107_11_head);
    const Space v108_3 = intersect(constant_3,v108_2);
    const Space v108_4 = (has_head(v108_3) ? constant_4 : Space{});
    const Space v108_5 = subtract(constant_2,v108_4);
    Space v108_8;
    if (!v108_5.empty()) {
      const Path v109_6 = concat_path(p0,v107_11_head);
      Space v109_7_result;
      for (int v109_7_label = 1; v109_7_label <= 2; ++v109_7_label) {
        const Space v109_7_tail = child(v107_11_tail,v109_7_label);
        if (v109_7_tail.empty()) continue;
        const Path v109_7_head{v109_7_label};
        const Space v110_2 = singleton(v109_7_head);
        const Space v110_3 = intersect(constant_3,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_4 : Space{});
        const Space v110_5 = subtract(constant_2,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_7_head);
          const Space v111_7 = routine_30(c, v111_6, v109_7_tail);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_3,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_4 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_7_head);
          const Space v112_11 = routine_31(c, v112_6, v109_7_tail);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_7_result = unite(v109_7_result,v110_13);
      }
      const Space v109_7 = std::move(v109_7_result);
      v108_8 = compose(v108_5,v109_7);
    }
    const Space v108_9 = intersect(constant_3,v108_2);
    const Space v108_10 = (has_head(v108_9) ? constant_4 : Space{});
    Space v108_12;
    if (!v108_10.empty()) {
      const Path v113_6 = concat_path(p0,v107_11_head);
      Space v113_11_result;
      for (int v113_11_label = 1; v113_11_label <= 2; ++v113_11_label) {
        const Space v113_11_tail = child(v107_11_tail,v113_11_label);
        if (v113_11_tail.empty()) continue;
        const Path v113_11_head{v113_11_label};
        const Space v114_2 = singleton(v113_11_head);
        const Space v114_3 = intersect(constant_3,v114_2);
        const Space v114_4 = (has_head(v114_3) ? constant_4 : Space{});
        const Space v114_5 = subtract(constant_2,v114_4);
        Space v114_8;
        if (!v114_5.empty()) {
          const Path v115_6 = concat_path(v113_6,v113_11_head);
          const Space v115_7 = routine_30(c, v115_6, v113_11_tail);
          v114_8 = compose(v114_5,v115_7);
        }
        const Space v114_9 = intersect(constant_3,v114_2);
        const Space v114_10 = (has_head(v114_9) ? constant_4 : Space{});
        Space v114_12;
        if (!v114_10.empty()) {
          const Path v116_6 = concat_path(v113_6,v113_11_head);
          const Space v116_11 = routine_9(c, v116_6, v113_11_tail);
          v114_12 = compose(v114_10,v116_11);
        }
        const Space v114_13 = unite(v114_8,v114_12);
        v113_11_result = unite(v113_11_result,v114_13);
      }
      const Space v113_11 = std::move(v113_11_result);
      v108_12 = compose(v108_10,v113_11);
    }
    const Space v108_13 = unite(v108_8,v108_12);
    v107_11_result = unite(v107_11_result,v108_13);
  }
  const Space v107_11 = std::move(v107_11_result);
  return v107_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v117_11_result;
  for (int v117_11_label = 1; v117_11_label <= 2; ++v117_11_label) {
    const Space v117_11_tail = child(s0,v117_11_label);
    if (v117_11_tail.empty()) continue;
    const Path v117_11_head{v117_11_label};
    const Space v118_2 = singleton(v117_11_head);
    const Space v118_3 = intersect(constant_3,v118_2);
    const Space v118_4 = (has_head(v118_3) ? constant_4 : Space{});
    const Space v118_5 = subtract(constant_2,v118_4);
    Space v118_8;
    if (!v118_5.empty()) {
      const Path v119_6 = concat_path(p0,v117_11_head);
      Space v119_7_result;
      for (int v119_7_label = 1; v119_7_label <= 2; ++v119_7_label) {
        const Space v119_7_tail = child(v117_11_tail,v119_7_label);
        if (v119_7_tail.empty()) continue;
        const Path v119_7_head{v119_7_label};
        const Space v120_2 = singleton(v119_7_head);
        const Space v120_3 = intersect(constant_3,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_4 : Space{});
        const Space v120_5 = subtract(constant_2,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_7_head);
          const Space v121_7 = routine_30(c, v121_6, v119_7_tail);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_3,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_4 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_7_head);
          const Space v122_11 = routine_31(c, v122_6, v119_7_tail);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_7_result = unite(v119_7_result,v120_13);
      }
      const Space v119_7 = std::move(v119_7_result);
      v118_8 = compose(v118_5,v119_7);
    }
    const Space v118_9 = intersect(constant_3,v118_2);
    const Space v118_10 = (has_head(v118_9) ? constant_4 : Space{});
    Space v118_12;
    if (!v118_10.empty()) {
      const Path v123_6 = concat_path(p0,v117_11_head);
      Space v123_11_result;
      for (int v123_11_label = 1; v123_11_label <= 2; ++v123_11_label) {
        const Space v123_11_tail = child(v117_11_tail,v123_11_label);
        if (v123_11_tail.empty()) continue;
        const Path v123_11_head{v123_11_label};
        const Space v124_2 = singleton(v123_11_head);
        const Space v124_3 = intersect(constant_3,v124_2);
        const Space v124_4 = (has_head(v124_3) ? constant_4 : Space{});
        const Space v124_5 = subtract(constant_2,v124_4);
        Space v124_7;
        if (!v124_5.empty()) {
          const Space v125_6 = routine_32(c, v123_11_head, v123_6, v123_11_tail);
          v124_7 = compose(v124_5,v125_6);
        }
        const Space v124_8 = intersect(constant_3,v124_2);
        const Space v124_9 = (has_head(v124_8) ? constant_4 : Space{});
        Space v124_11;
        if (!v124_9.empty()) {
          const Space v126_10 = routine_33(c, v123_11_head, v123_6, v123_11_tail);
          v124_11 = compose(v124_9,v126_10);
        }
        const Space v124_12 = unite(v124_7,v124_11);
        v123_11_result = unite(v123_11_result,v124_12);
      }
      const Space v123_11 = std::move(v123_11_result);
      v118_12 = compose(v118_10,v123_11);
    }
    const Space v118_13 = unite(v118_8,v118_12);
    v117_11_result = unite(v117_11_result,v118_13);
  }
  const Space v117_11 = std::move(v117_11_result);
  return v117_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v127_11_result;
  for (int v127_11_label = 1; v127_11_label <= 2; ++v127_11_label) {
    const Space v127_11_tail = child(s0,v127_11_label);
    if (v127_11_tail.empty()) continue;
    const Path v127_11_head{v127_11_label};
    const Space v128_2 = singleton(v127_11_head);
    const Space v128_3 = intersect(constant_3,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_4 : Space{});
    const Space v128_5 = subtract(constant_2,v128_4);
    Space v128_7;
    if (!v128_5.empty()) {
      Space v129_6_result;
      for (int v129_6_label = 1; v129_6_label <= 2; ++v129_6_label) {
        const Space v129_6_tail = child(v127_11_tail,v129_6_label);
        if (v129_6_tail.empty()) continue;
        const Path v129_6_head{v129_6_label};
        const Space v130_2 = singleton(v129_6_head);
        const Space v130_3 = intersect(constant_3,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_4 : Space{});
        const Space v130_5 = subtract(constant_2,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v127_11_head,v129_6_head);
          const Space v131_7 = routine_34(c, v131_6, p0, v129_6_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_3,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_4 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v127_11_head,v129_6_head);
          const Space v132_11 = routine_35(c, v132_6, p0, v129_6_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_6_result = unite(v129_6_result,v130_13);
      }
      const Space v129_6 = std::move(v129_6_result);
      v128_7 = compose(v128_5,v129_6);
    }
    const Space v128_8 = intersect(constant_3,v128_2);
    const Space v128_9 = (has_head(v128_8) ? constant_4 : Space{});
    Space v128_11;
    if (!v128_9.empty()) {
      Space v133_10_result;
      for (int v133_10_label = 1; v133_10_label <= 2; ++v133_10_label) {
        const Space v133_10_tail = child(v127_11_tail,v133_10_label);
        if (v133_10_tail.empty()) continue;
        const Path v133_10_head{v133_10_label};
        const Space v134_2 = singleton(v133_10_head);
        const Space v134_3 = intersect(constant_3,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_4 : Space{});
        const Space v134_5 = subtract(constant_2,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v127_11_head,v133_10_head);
          const Space v135_7 = routine_34(c, v135_6, p0, v133_10_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_3,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_4 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v127_11_head,v133_10_head);
          const Space v136_11 = routine_36(c, v136_6, p0, v133_10_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_10_result = unite(v133_10_result,v134_13);
      }
      const Space v133_10 = std::move(v133_10_result);
      v128_11 = compose(v128_9,v133_10);
    }
    const Space v128_12 = unite(v128_7,v128_11);
    v127_11_result = unite(v127_11_result,v128_12);
  }
  const Space v127_11 = std::move(v127_11_result);
  return v127_11;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v137_12_result;
  for (int v137_12_label = 1; v137_12_label <= 2; ++v137_12_label) {
    const Space v137_12_tail = child(s0,v137_12_label);
    if (v137_12_tail.empty()) continue;
    const Path v137_12_head{v137_12_label};
    const Space v138_2 = singleton(v137_12_head);
    const Space v138_3 = intersect(constant_3,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_4 : Space{});
    const Space v138_5 = subtract(constant_2,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_12_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_12_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_3,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_4 : Space{});
        const Space v140_5 = subtract(constant_2,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_37(c, v141_6, v139_7_tail, s1);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_3,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_4 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_38(c, v142_6, v139_7_tail, s1);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_3,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_4 : Space{});
    Space v138_12;
    if (!v138_10.empty()) {
      const Path v143_6 = concat_path(p0,v137_12_head);
      Space v143_11_result;
      for (int v143_11_label = 1; v143_11_label <= 2; ++v143_11_label) {
        const Space v143_11_tail = child(v137_12_tail,v143_11_label);
        if (v143_11_tail.empty()) continue;
        const Path v143_11_head{v143_11_label};
        const Space v144_2 = singleton(v143_11_head);
        const Space v144_3 = intersect(constant_3,v144_2);
        const Space v144_4 = (has_head(v144_3) ? constant_4 : Space{});
        const Space v144_5 = subtract(constant_2,v144_4);
        Space v144_8;
        if (!v144_5.empty()) {
          const Path v145_6 = concat_path(v143_6,v143_11_head);
          const Space v145_7 = routine_37(c, v145_6, v143_11_tail, s1);
          v144_8 = compose(v144_5,v145_7);
        }
        const Space v144_9 = intersect(constant_3,v144_2);
        const Space v144_10 = (has_head(v144_9) ? constant_4 : Space{});
        Space v144_12;
        if (!v144_10.empty()) {
          const Path v146_6 = concat_path(v143_6,v143_11_head);
          const Space v146_11 = routine_12(c, v146_6, v143_11_tail, s1);
          v144_12 = compose(v144_10,v146_11);
        }
        const Space v144_13 = unite(v144_8,v144_12);
        v143_11_result = unite(v143_11_result,v144_13);
      }
      const Space v143_11 = std::move(v143_11_result);
      v138_12 = compose(v138_10,v143_11);
    }
    const Space v138_13 = unite(v138_8,v138_12);
    v137_12_result = unite(v137_12_result,v138_13);
  }
  const Space v137_12 = std::move(v137_12_result);
  return v137_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v147_12_result;
  for (int v147_12_label = 1; v147_12_label <= 2; ++v147_12_label) {
    const Space v147_12_tail = child(s0,v147_12_label);
    if (v147_12_tail.empty()) continue;
    const Path v147_12_head{v147_12_label};
    const Space v148_2 = singleton(v147_12_head);
    const Space v148_3 = intersect(constant_3,v148_2);
    const Space v148_4 = (has_head(v148_3) ? constant_4 : Space{});
    const Space v148_5 = subtract(constant_2,v148_4);
    Space v148_8;
    if (!v148_5.empty()) {
      const Path v149_6 = concat_path(p0,v147_12_head);
      Space v149_7_result;
      for (int v149_7_label = 1; v149_7_label <= 2; ++v149_7_label) {
        const Space v149_7_tail = child(v147_12_tail,v149_7_label);
        if (v149_7_tail.empty()) continue;
        const Path v149_7_head{v149_7_label};
        const Space v150_2 = singleton(v149_7_head);
        const Space v150_3 = intersect(constant_3,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_4 : Space{});
        const Space v150_5 = subtract(constant_2,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_7_head);
          const Space v151_7 = routine_37(c, v151_6, v149_7_tail, s1);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_3,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_4 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_7_head);
          const Space v152_11 = routine_38(c, v152_6, v149_7_tail, s1);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_7_result = unite(v149_7_result,v150_13);
      }
      const Space v149_7 = std::move(v149_7_result);
      v148_8 = compose(v148_5,v149_7);
    }
    const Space v148_9 = intersect(constant_3,v148_2);
    const Space v148_10 = (has_head(v148_9) ? constant_4 : Space{});
    Space v148_12;
    if (!v148_10.empty()) {
      const Path v153_6 = concat_path(p0,v147_12_head);
      Space v153_11_result;
      for (int v153_11_label = 1; v153_11_label <= 2; ++v153_11_label) {
        const Space v153_11_tail = child(v147_12_tail,v153_11_label);
        if (v153_11_tail.empty()) continue;
        const Path v153_11_head{v153_11_label};
        const Space v154_2 = singleton(v153_11_head);
        const Space v154_3 = intersect(constant_3,v154_2);
        const Space v154_4 = (has_head(v154_3) ? constant_4 : Space{});
        const Space v154_5 = subtract(constant_2,v154_4);
        Space v154_7;
        if (!v154_5.empty()) {
          const Space v155_6 = routine_39(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_7 = compose(v154_5,v155_6);
        }
        const Space v154_8 = intersect(constant_3,v154_2);
        const Space v154_9 = (has_head(v154_8) ? constant_4 : Space{});
        Space v154_11;
        if (!v154_9.empty()) {
          const Space v156_10 = routine_40(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_11 = compose(v154_9,v156_10);
        }
        const Space v154_12 = unite(v154_7,v154_11);
        v153_11_result = unite(v153_11_result,v154_12);
      }
      const Space v153_11 = std::move(v153_11_result);
      v148_12 = compose(v148_10,v153_11);
    }
    const Space v148_13 = unite(v148_8,v148_12);
    v147_12_result = unite(v147_12_result,v148_13);
  }
  const Space v147_12 = std::move(v147_12_result);
  return v147_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v157_12_result;
  for (int v157_12_label = 1; v157_12_label <= 2; ++v157_12_label) {
    const Space v157_12_tail = child(s0,v157_12_label);
    if (v157_12_tail.empty()) continue;
    const Path v157_12_head{v157_12_label};
    const Space v158_2 = singleton(v157_12_head);
    const Space v158_3 = intersect(constant_3,v158_2);
    const Space v158_4 = (has_head(v158_3) ? constant_4 : Space{});
    const Space v158_5 = subtract(constant_2,v158_4);
    Space v158_7;
    if (!v158_5.empty()) {
      Space v159_6_result;
      for (int v159_6_label = 1; v159_6_label <= 2; ++v159_6_label) {
        const Space v159_6_tail = child(v157_12_tail,v159_6_label);
        if (v159_6_tail.empty()) continue;
        const Path v159_6_head{v159_6_label};
        const Space v160_2 = singleton(v159_6_head);
        const Space v160_3 = intersect(constant_3,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_4 : Space{});
        const Space v160_5 = subtract(constant_2,v160_4);
        Space v160_8;
        if (!v160_5.empty()) {
          const Path v161_6 = concat_path(v157_12_head,v159_6_head);
          const Space v161_7 = routine_41(c, v161_6, p0, v159_6_tail, s1);
          v160_8 = compose(v160_5,v161_7);
        }
        const Space v160_9 = intersect(constant_3,v160_2);
        const Space v160_10 = (has_head(v160_9) ? constant_4 : Space{});
        Space v160_12;
        if (!v160_10.empty()) {
          const Path v162_6 = concat_path(v157_12_head,v159_6_head);
          const Space v162_11 = routine_42(c, v162_6, p0, v159_6_tail, s1);
          v160_12 = compose(v160_10,v162_11);
        }
        const Space v160_13 = unite(v160_8,v160_12);
        v159_6_result = unite(v159_6_result,v160_13);
      }
      const Space v159_6 = std::move(v159_6_result);
      v158_7 = compose(v158_5,v159_6);
    }
    const Space v158_8 = intersect(constant_3,v158_2);
    const Space v158_9 = (has_head(v158_8) ? constant_4 : Space{});
    Space v158_11;
    if (!v158_9.empty()) {
      Space v163_10_result;
      for (int v163_10_label = 1; v163_10_label <= 2; ++v163_10_label) {
        const Space v163_10_tail = child(v157_12_tail,v163_10_label);
        if (v163_10_tail.empty()) continue;
        const Path v163_10_head{v163_10_label};
        const Space v164_2 = singleton(v163_10_head);
        const Space v164_3 = intersect(constant_3,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_4 : Space{});
        const Space v164_5 = subtract(constant_2,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v157_12_head,v163_10_head);
          const Space v165_7 = routine_41(c, v165_6, p0, v163_10_tail, s1);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_3,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_4 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v157_12_head,v163_10_head);
          const Space v166_11 = routine_43(c, v166_6, p0, v163_10_tail, s1);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_10_result = unite(v163_10_result,v164_13);
      }
      const Space v163_10 = std::move(v163_10_result);
      v158_11 = compose(v158_9,v163_10);
    }
    const Space v158_12 = unite(v158_7,v158_11);
    v157_12_result = unite(v157_12_result,v158_12);
  }
  const Space v157_12 = std::move(v157_12_result);
  return v157_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v167_12_result;
  for (int v167_12_label = 1; v167_12_label <= 2; ++v167_12_label) {
    const Space v167_12_tail = child(s0,v167_12_label);
    if (v167_12_tail.empty()) continue;
    const Path v167_12_head{v167_12_label};
    const Space v168_2 = singleton(v167_12_head);
    const Space v168_3 = intersect(constant_3,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_4 : Space{});
    const Space v168_5 = subtract(constant_2,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_12_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_12_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_3,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_4 : Space{});
        const Space v170_5 = subtract(constant_2,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_44(c, v171_6, v169_7_tail, s1);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_3,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_4 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_45(c, v172_6, v169_7_tail, s1);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_3,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_4 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_12_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_12_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_3,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_4 : Space{});
        const Space v174_5 = subtract(constant_2,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_44(c, v175_6, v173_11_tail, s1);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_3,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_4 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_15(c, v176_6, v173_11_tail, s1);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_12_result = unite(v167_12_result,v168_13);
  }
  const Space v167_12 = std::move(v167_12_result);
  return v167_12;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v177_12_result;
  for (int v177_12_label = 1; v177_12_label <= 2; ++v177_12_label) {
    const Space v177_12_tail = child(s0,v177_12_label);
    if (v177_12_tail.empty()) continue;
    const Path v177_12_head{v177_12_label};
    const Space v178_2 = singleton(v177_12_head);
    const Space v178_3 = intersect(constant_3,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_4 : Space{});
    const Space v178_5 = subtract(constant_2,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_12_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_12_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_3,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_4 : Space{});
        const Space v180_5 = subtract(constant_2,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_44(c, v181_6, v179_7_tail, s1);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_3,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_4 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_45(c, v182_6, v179_7_tail, s1);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_3,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_4 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_12_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_12_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_3,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_4 : Space{});
        const Space v184_5 = subtract(constant_2,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_46(c, v183_11_head, v183_6, v183_11_tail, s1);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_3,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_4 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_47(c, v183_11_head, v183_6, v183_11_tail, s1);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_11_result = unite(v183_11_result,v184_12);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_12_result = unite(v177_12_result,v178_13);
  }
  const Space v177_12 = std::move(v177_12_result);
  return v177_12;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v187_12_result;
  for (int v187_12_label = 1; v187_12_label <= 2; ++v187_12_label) {
    const Space v187_12_tail = child(s0,v187_12_label);
    if (v187_12_tail.empty()) continue;
    const Path v187_12_head{v187_12_label};
    const Space v188_2 = singleton(v187_12_head);
    const Space v188_3 = intersect(constant_3,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_4 : Space{});
    const Space v188_5 = subtract(constant_2,v188_4);
    Space v188_7;
    if (!v188_5.empty()) {
      Space v189_6_result;
      for (int v189_6_label = 1; v189_6_label <= 2; ++v189_6_label) {
        const Space v189_6_tail = child(v187_12_tail,v189_6_label);
        if (v189_6_tail.empty()) continue;
        const Path v189_6_head{v189_6_label};
        const Space v190_2 = singleton(v189_6_head);
        const Space v190_3 = intersect(constant_3,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_4 : Space{});
        const Space v190_5 = subtract(constant_2,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v187_12_head,v189_6_head);
          const Space v191_7 = routine_48(c, v191_6, p0, v189_6_tail, s1);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_3,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_4 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v187_12_head,v189_6_head);
          const Space v192_11 = routine_49(c, v192_6, p0, v189_6_tail, s1);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_6_result = unite(v189_6_result,v190_13);
      }
      const Space v189_6 = std::move(v189_6_result);
      v188_7 = compose(v188_5,v189_6);
    }
    const Space v188_8 = intersect(constant_3,v188_2);
    const Space v188_9 = (has_head(v188_8) ? constant_4 : Space{});
    Space v188_11;
    if (!v188_9.empty()) {
      Space v193_10_result;
      for (int v193_10_label = 1; v193_10_label <= 2; ++v193_10_label) {
        const Space v193_10_tail = child(v187_12_tail,v193_10_label);
        if (v193_10_tail.empty()) continue;
        const Path v193_10_head{v193_10_label};
        const Space v194_2 = singleton(v193_10_head);
        const Space v194_3 = intersect(constant_3,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_4 : Space{});
        const Space v194_5 = subtract(constant_2,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v187_12_head,v193_10_head);
          const Space v195_7 = routine_48(c, v195_6, p0, v193_10_tail, s1);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_3,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_4 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v187_12_head,v193_10_head);
          const Space v196_11 = routine_50(c, v196_6, p0, v193_10_tail, s1);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_10_result = unite(v193_10_result,v194_13);
      }
      const Space v193_10 = std::move(v193_10_result);
      v188_11 = compose(v188_9,v193_10);
    }
    const Space v188_12 = unite(v188_7,v188_11);
    v187_12_result = unite(v187_12_result,v188_12);
  }
  const Space v187_12 = std::move(v187_12_result);
  return v187_12;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v197_11_result;
  for (int v197_11_label = 1; v197_11_label <= 2; ++v197_11_label) {
    const Space v197_11_tail = child(s0,v197_11_label);
    if (v197_11_tail.empty()) continue;
    const Path v197_11_head{v197_11_label};
    const Space v198_2 = singleton(v197_11_head);
    const Space v198_3 = intersect(constant_3,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_4 : Space{});
    const Space v198_5 = subtract(constant_2,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_11_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_11_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_3,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_4 : Space{});
        const Space v200_5 = subtract(constant_2,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_51(c, v201_6, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_3,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_4 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_52(c, v202_6, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_3,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_4 : Space{});
    Space v198_12;
    if (!v198_10.empty()) {
      const Path v203_6 = concat_path(p0,v197_11_head);
      Space v203_11_result;
      for (int v203_11_label = 1; v203_11_label <= 2; ++v203_11_label) {
        const Space v203_11_tail = child(v197_11_tail,v203_11_label);
        if (v203_11_tail.empty()) continue;
        const Path v203_11_head{v203_11_label};
        const Space v204_2 = singleton(v203_11_head);
        const Space v204_3 = intersect(constant_3,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_4 : Space{});
        const Space v204_5 = subtract(constant_2,v204_4);
        Space v204_8;
        if (!v204_5.empty()) {
          const Path v205_6 = concat_path(v203_6,v203_11_head);
          const Space v205_7 = routine_51(c, v205_6, v203_11_tail);
          v204_8 = compose(v204_5,v205_7);
        }
        const Space v204_9 = intersect(constant_3,v204_2);
        const Space v204_10 = (has_head(v204_9) ? constant_4 : Space{});
        Space v204_12;
        if (!v204_10.empty()) {
          const Path v206_6 = concat_path(v203_6,v203_11_head);
          const Space v206_11 = routine_3(c, v206_6, v203_11_tail);
          v204_12 = compose(v204_10,v206_11);
        }
        const Space v204_13 = unite(v204_8,v204_12);
        v203_11_result = unite(v203_11_result,v204_13);
      }
      const Space v203_11 = std::move(v203_11_result);
      v198_12 = compose(v198_10,v203_11);
    }
    const Space v198_13 = unite(v198_8,v198_12);
    v197_11_result = unite(v197_11_result,v198_13);
  }
  const Space v197_11 = std::move(v197_11_result);
  return v197_11;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v207_11_result;
  for (int v207_11_label = 1; v207_11_label <= 2; ++v207_11_label) {
    const Space v207_11_tail = child(s0,v207_11_label);
    if (v207_11_tail.empty()) continue;
    const Path v207_11_head{v207_11_label};
    const Space v208_2 = singleton(v207_11_head);
    const Space v208_3 = intersect(constant_3,v208_2);
    const Space v208_4 = (has_head(v208_3) ? constant_4 : Space{});
    const Space v208_5 = subtract(constant_2,v208_4);
    Space v208_8;
    if (!v208_5.empty()) {
      const Path v209_6 = concat_path(p0,v207_11_head);
      Space v209_7_result;
      for (int v209_7_label = 1; v209_7_label <= 2; ++v209_7_label) {
        const Space v209_7_tail = child(v207_11_tail,v209_7_label);
        if (v209_7_tail.empty()) continue;
        const Path v209_7_head{v209_7_label};
        const Space v210_2 = singleton(v209_7_head);
        const Space v210_3 = intersect(constant_3,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_4 : Space{});
        const Space v210_5 = subtract(constant_2,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_7_head);
          const Space v211_7 = routine_51(c, v211_6, v209_7_tail);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_3,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_4 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_7_head);
          const Space v212_11 = routine_52(c, v212_6, v209_7_tail);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_7_result = unite(v209_7_result,v210_13);
      }
      const Space v209_7 = std::move(v209_7_result);
      v208_8 = compose(v208_5,v209_7);
    }
    const Space v208_9 = intersect(constant_3,v208_2);
    const Space v208_10 = (has_head(v208_9) ? constant_4 : Space{});
    Space v208_12;
    if (!v208_10.empty()) {
      const Path v213_6 = concat_path(p0,v207_11_head);
      Space v213_11_result;
      for (int v213_11_label = 1; v213_11_label <= 2; ++v213_11_label) {
        const Space v213_11_tail = child(v207_11_tail,v213_11_label);
        if (v213_11_tail.empty()) continue;
        const Path v213_11_head{v213_11_label};
        const Space v214_2 = singleton(v213_11_head);
        const Space v214_3 = intersect(constant_3,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_4 : Space{});
        const Space v214_5 = subtract(constant_2,v214_4);
        Space v214_7;
        if (!v214_5.empty()) {
          const Space v215_6 = routine_18(c, v213_11_head, v213_6, v213_11_tail);
          v214_7 = compose(v214_5,v215_6);
        }
        const Space v214_8 = intersect(constant_3,v214_2);
        const Space v214_9 = (has_head(v214_8) ? constant_4 : Space{});
        Space v214_11;
        if (!v214_9.empty()) {
          const Space v216_10 = routine_19(c, v213_11_head, v213_6, v213_11_tail);
          v214_11 = compose(v214_9,v216_10);
        }
        const Space v214_12 = unite(v214_7,v214_11);
        v213_11_result = unite(v213_11_result,v214_12);
      }
      const Space v213_11 = std::move(v213_11_result);
      v208_12 = compose(v208_10,v213_11);
    }
    const Space v208_13 = unite(v208_8,v208_12);
    v207_11_result = unite(v207_11_result,v208_13);
  }
  const Space v207_11 = std::move(v207_11_result);
  return v207_11;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v217_12_result;
  for (int v217_12_label = 1; v217_12_label <= 2; ++v217_12_label) {
    const Space v217_12_tail = child(s0,v217_12_label);
    if (v217_12_tail.empty()) continue;
    const Path v217_12_head{v217_12_label};
    const Space v218_2 = singleton(v217_12_head);
    const Space v218_3 = intersect(constant_3,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_4 : Space{});
    const Space v218_5 = subtract(constant_2,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_12_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_12_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_3,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_4 : Space{});
        const Space v220_5 = subtract(constant_2,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_53(c, v221_6, p1, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_3,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_4 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_54(c, v222_6, p1, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_3,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_4 : Space{});
    Space v218_12;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_12_head);
      Space v223_11_result;
      for (int v223_11_label = 1; v223_11_label <= 2; ++v223_11_label) {
        const Space v223_11_tail = child(v217_12_tail,v223_11_label);
        if (v223_11_tail.empty()) continue;
        const Path v223_11_head{v223_11_label};
        const Space v224_2 = singleton(v223_11_head);
        const Space v224_3 = intersect(constant_3,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_4 : Space{});
        const Space v224_5 = subtract(constant_2,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_11_head);
          const Space v225_7 = routine_53(c, v225_6, p1, v223_11_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_3,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_4 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_11_head);
          const Space v226_11 = routine_22(c, v226_6, p1, v223_11_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_11_result = unite(v223_11_result,v224_13);
      }
      const Space v223_11 = std::move(v223_11_result);
      v218_12 = compose(v218_10,v223_11);
    }
    const Space v218_13 = unite(v218_8,v218_12);
    v217_12_result = unite(v217_12_result,v218_13);
  }
  const Space v217_12 = std::move(v217_12_result);
  return v217_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v227_10_result;
  for (int v227_10_label = 1; v227_10_label <= 2; ++v227_10_label) {
    const Space v227_10_tail = child(s0,v227_10_label);
    if (v227_10_tail.empty()) continue;
    const Path v227_10_head{v227_10_label};
    const Space v228_2 = singleton(v227_10_head);
    const Space v228_3 = intersect(constant_3,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_4 : Space{});
    const Space v228_5 = compose(v228_4,v227_10_tail);
    const Path v229_6 = concat_path(p0,v227_10_head);
    const Space v228_7 = wrap(v228_5,v229_6);
    const Space v228_8 = wrap(v228_7,p1);
    const Space v228_9 = wrap(v228_8,constant_6);
    const Space v228_10 = intersect(constant_3,v228_2);
    const Space v228_11 = (has_head(v228_10) ? constant_4 : Space{});
    const Space v228_12 = subtract(constant_2,v228_11);
    Space v228_14;
    if (!v228_12.empty()) {
      Space v230_13_result;
      for (int v230_13_label = 1; v230_13_label <= 2; ++v230_13_label) {
        const Space v230_13_tail = child(v227_10_tail,v230_13_label);
        if (v230_13_tail.empty()) continue;
        const Path v230_13_head{v230_13_label};
        const Space v231_2 = singleton(v230_13_head);
        const Space v231_3 = intersect(constant_3,v231_2);
        const Space v231_4 = (has_head(v231_3) ? constant_4 : Space{});
        const Space v231_5 = subtract(constant_2,v231_4);
        Space v231_8;
        if (!v231_5.empty()) {
          const Path v232_6 = concat_path(v229_6,v230_13_head);
          const Space v232_7 = routine_53(c, v232_6, p1, v230_13_tail);
          v231_8 = compose(v231_5,v232_7);
        }
        const Space v231_9 = intersect(constant_3,v231_2);
        const Space v231_10 = (has_head(v231_9) ? constant_4 : Space{});
        Space v231_12;
        if (!v231_10.empty()) {
          const Path v233_6 = concat_path(v229_6,v230_13_head);
          const Space v233_11 = routine_54(c, v233_6, p1, v230_13_tail);
          v231_12 = compose(v231_10,v233_11);
        }
        const Space v231_13 = unite(v231_8,v231_12);
        v230_13_result = unite(v230_13_result,v231_13);
      }
      const Space v230_13 = std::move(v230_13_result);
      v228_14 = compose(v228_12,v230_13);
    }
    const Space v228_15 = unite(v228_9,v228_14);
    v227_10_result = unite(v227_10_result,v228_15);
  }
  const Space v227_10 = std::move(v227_10_result);
  return v227_10;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v234_12_result;
  for (int v234_12_label = 1; v234_12_label <= 2; ++v234_12_label) {
    const Space v234_12_tail = child(s0,v234_12_label);
    if (v234_12_tail.empty()) continue;
    const Path v234_12_head{v234_12_label};
    const Space v235_2 = singleton(v234_12_head);
    const Space v235_3 = intersect(constant_3,v235_2);
    const Space v235_4 = (has_head(v235_3) ? constant_4 : Space{});
    const Space v235_5 = subtract(constant_2,v235_4);
    Space v235_8;
    if (!v235_5.empty()) {
      const Path v236_6 = concat_path(p0,v234_12_head);
      Space v236_7_result;
      for (int v236_7_label = 1; v236_7_label <= 2; ++v236_7_label) {
        const Space v236_7_tail = child(v234_12_tail,v236_7_label);
        if (v236_7_tail.empty()) continue;
        const Path v236_7_head{v236_7_label};
        const Space v237_2 = singleton(v236_7_head);
        const Space v237_3 = intersect(constant_3,v237_2);
        const Space v237_4 = (has_head(v237_3) ? constant_4 : Space{});
        const Space v237_5 = subtract(constant_2,v237_4);
        Space v237_8;
        if (!v237_5.empty()) {
          const Path v238_6 = concat_path(v236_6,v236_7_head);
          const Space v238_7 = routine_55(c, v238_6, p1, v236_7_tail);
          v237_8 = compose(v237_5,v238_7);
        }
        const Space v237_9 = intersect(constant_3,v237_2);
        const Space v237_10 = (has_head(v237_9) ? constant_4 : Space{});
        Space v237_12;
        if (!v237_10.empty()) {
          const Path v239_6 = concat_path(v236_6,v236_7_head);
          const Space v239_11 = routine_56(c, v239_6, p1, v236_7_tail);
          v237_12 = compose(v237_10,v239_11);
        }
        const Space v237_13 = unite(v237_8,v237_12);
        v236_7_result = unite(v236_7_result,v237_13);
      }
      const Space v236_7 = std::move(v236_7_result);
      v235_8 = compose(v235_5,v236_7);
    }
    const Space v235_9 = intersect(constant_3,v235_2);
    const Space v235_10 = (has_head(v235_9) ? constant_4 : Space{});
    Space v235_12;
    if (!v235_10.empty()) {
      const Path v240_6 = concat_path(p0,v234_12_head);
      Space v240_11_result;
      for (int v240_11_label = 1; v240_11_label <= 2; ++v240_11_label) {
        const Space v240_11_tail = child(v234_12_tail,v240_11_label);
        if (v240_11_tail.empty()) continue;
        const Path v240_11_head{v240_11_label};
        const Space v241_2 = singleton(v240_11_head);
        const Space v241_3 = intersect(constant_3,v241_2);
        const Space v241_4 = (has_head(v241_3) ? constant_4 : Space{});
        const Space v241_5 = subtract(constant_2,v241_4);
        Space v241_8;
        if (!v241_5.empty()) {
          const Path v242_6 = concat_path(v240_6,v240_11_head);
          const Space v242_7 = routine_55(c, v242_6, p1, v240_11_tail);
          v241_8 = compose(v241_5,v242_7);
        }
        const Space v241_9 = intersect(constant_3,v241_2);
        const Space v241_10 = (has_head(v241_9) ? constant_4 : Space{});
        Space v241_12;
        if (!v241_10.empty()) {
          const Path v243_6 = concat_path(v240_6,v240_11_head);
          const Space v243_11 = routine_22(c, v243_6, p1, v240_11_tail);
          v241_12 = compose(v241_10,v243_11);
        }
        const Space v241_13 = unite(v241_8,v241_12);
        v240_11_result = unite(v240_11_result,v241_13);
      }
      const Space v240_11 = std::move(v240_11_result);
      v235_12 = compose(v235_10,v240_11);
    }
    const Space v235_13 = unite(v235_8,v235_12);
    v234_12_result = unite(v234_12_result,v235_13);
  }
  const Space v234_12 = std::move(v234_12_result);
  return v234_12;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v244_10_result;
  for (int v244_10_label = 1; v244_10_label <= 2; ++v244_10_label) {
    const Space v244_10_tail = child(s0,v244_10_label);
    if (v244_10_tail.empty()) continue;
    const Path v244_10_head{v244_10_label};
    const Space v245_2 = singleton(v244_10_head);
    const Space v245_3 = intersect(constant_3,v245_2);
    const Space v245_4 = (has_head(v245_3) ? constant_4 : Space{});
    const Space v245_5 = compose(v245_4,v244_10_tail);
    const Path v246_6 = concat_path(p0,v244_10_head);
    const Space v245_7 = wrap(v245_5,v246_6);
    const Space v245_8 = wrap(v245_7,p1);
    const Space v245_9 = wrap(v245_8,constant_6);
    const Space v245_10 = intersect(constant_3,v245_2);
    const Space v245_11 = (has_head(v245_10) ? constant_4 : Space{});
    const Space v245_12 = subtract(constant_2,v245_11);
    Space v245_14;
    if (!v245_12.empty()) {
      Space v247_13_result;
      for (int v247_13_label = 1; v247_13_label <= 2; ++v247_13_label) {
        const Space v247_13_tail = child(v244_10_tail,v247_13_label);
        if (v247_13_tail.empty()) continue;
        const Path v247_13_head{v247_13_label};
        const Space v248_2 = singleton(v247_13_head);
        const Space v248_3 = intersect(constant_3,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_4 : Space{});
        const Space v248_5 = subtract(constant_2,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v246_6,v247_13_head);
          const Space v249_7 = routine_55(c, v249_6, p1, v247_13_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_3,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_4 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v246_6,v247_13_head);
          const Space v250_11 = routine_56(c, v250_6, p1, v247_13_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_13_result = unite(v247_13_result,v248_13);
      }
      const Space v247_13 = std::move(v247_13_result);
      v245_14 = compose(v245_12,v247_13);
    }
    const Space v245_15 = unite(v245_9,v245_14);
    v244_10_result = unite(v244_10_result,v245_15);
  }
  const Space v244_10 = std::move(v244_10_result);
  return v244_10;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v251_3 = wrap(s0,p0);
  const Space v251_4 = wrap(v251_3,p1);
  const Space v251_6 = wrap(v251_4,constant_6);
  return v251_6;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v252_12_result;
  for (int v252_12_label = 1; v252_12_label <= 2; ++v252_12_label) {
    const Space v252_12_tail = child(s0,v252_12_label);
    if (v252_12_tail.empty()) continue;
    const Path v252_12_head{v252_12_label};
    const Space v253_2 = singleton(v252_12_head);
    const Space v253_3 = intersect(constant_3,v253_2);
    const Space v253_4 = (has_head(v253_3) ? constant_4 : Space{});
    const Space v253_5 = subtract(constant_2,v253_4);
    Space v253_8;
    if (!v253_5.empty()) {
      const Path v254_6 = concat_path(p0,v252_12_head);
      Space v254_7_result;
      for (int v254_7_label = 1; v254_7_label <= 2; ++v254_7_label) {
        const Space v254_7_tail = child(v252_12_tail,v254_7_label);
        if (v254_7_tail.empty()) continue;
        const Path v254_7_head{v254_7_label};
        const Space v255_2 = singleton(v254_7_head);
        const Space v255_3 = intersect(constant_3,v255_2);
        const Space v255_4 = (has_head(v255_3) ? constant_4 : Space{});
        const Space v255_5 = subtract(constant_2,v255_4);
        Space v255_8;
        if (!v255_5.empty()) {
          const Path v256_6 = concat_path(v254_6,v254_7_head);
          const Space v256_7 = routine_57(c, v256_6, v254_7_tail, s1);
          v255_8 = compose(v255_5,v256_7);
        }
        const Space v255_9 = intersect(constant_3,v255_2);
        const Space v255_10 = (has_head(v255_9) ? constant_4 : Space{});
        Space v255_12;
        if (!v255_10.empty()) {
          const Path v257_6 = concat_path(v254_6,v254_7_head);
          const Space v257_11 = routine_58(c, v257_6, v254_7_tail, s1);
          v255_12 = compose(v255_10,v257_11);
        }
        const Space v255_13 = unite(v255_8,v255_12);
        v254_7_result = unite(v254_7_result,v255_13);
      }
      const Space v254_7 = std::move(v254_7_result);
      v253_8 = compose(v253_5,v254_7);
    }
    const Space v253_9 = intersect(constant_3,v253_2);
    const Space v253_10 = (has_head(v253_9) ? constant_4 : Space{});
    Space v253_12;
    if (!v253_10.empty()) {
      const Path v258_6 = concat_path(p0,v252_12_head);
      Space v258_11_result;
      for (int v258_11_label = 1; v258_11_label <= 2; ++v258_11_label) {
        const Space v258_11_tail = child(v252_12_tail,v258_11_label);
        if (v258_11_tail.empty()) continue;
        const Path v258_11_head{v258_11_label};
        const Space v259_2 = singleton(v258_11_head);
        const Space v259_3 = intersect(constant_3,v259_2);
        const Space v259_4 = (has_head(v259_3) ? constant_4 : Space{});
        const Space v259_5 = subtract(constant_2,v259_4);
        Space v259_8;
        if (!v259_5.empty()) {
          const Path v260_6 = concat_path(v258_6,v258_11_head);
          const Space v260_7 = routine_57(c, v260_6, v258_11_tail, s1);
          v259_8 = compose(v259_5,v260_7);
        }
        const Space v259_9 = intersect(constant_3,v259_2);
        const Space v259_10 = (has_head(v259_9) ? constant_4 : Space{});
        Space v259_12;
        if (!v259_10.empty()) {
          const Path v261_6 = concat_path(v258_6,v258_11_head);
          const Space v261_11 = routine_6(c, v261_6, v258_11_tail, s1);
          v259_12 = compose(v259_10,v261_11);
        }
        const Space v259_13 = unite(v259_8,v259_12);
        v258_11_result = unite(v258_11_result,v259_13);
      }
      const Space v258_11 = std::move(v258_11_result);
      v253_12 = compose(v253_10,v258_11);
    }
    const Space v253_13 = unite(v253_8,v253_12);
    v252_12_result = unite(v252_12_result,v253_13);
  }
  const Space v252_12 = std::move(v252_12_result);
  return v252_12;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v262_12_result;
  for (int v262_12_label = 1; v262_12_label <= 2; ++v262_12_label) {
    const Space v262_12_tail = child(s0,v262_12_label);
    if (v262_12_tail.empty()) continue;
    const Path v262_12_head{v262_12_label};
    const Space v263_2 = singleton(v262_12_head);
    const Space v263_3 = intersect(constant_3,v263_2);
    const Space v263_4 = (has_head(v263_3) ? constant_4 : Space{});
    const Space v263_5 = subtract(constant_2,v263_4);
    Space v263_8;
    if (!v263_5.empty()) {
      const Path v264_6 = concat_path(p0,v262_12_head);
      Space v264_7_result;
      for (int v264_7_label = 1; v264_7_label <= 2; ++v264_7_label) {
        const Space v264_7_tail = child(v262_12_tail,v264_7_label);
        if (v264_7_tail.empty()) continue;
        const Path v264_7_head{v264_7_label};
        const Space v265_2 = singleton(v264_7_head);
        const Space v265_3 = intersect(constant_3,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_4 : Space{});
        const Space v265_5 = subtract(constant_2,v265_4);
        Space v265_8;
        if (!v265_5.empty()) {
          const Path v266_6 = concat_path(v264_6,v264_7_head);
          const Space v266_7 = routine_57(c, v266_6, v264_7_tail, s1);
          v265_8 = compose(v265_5,v266_7);
        }
        const Space v265_9 = intersect(constant_3,v265_2);
        const Space v265_10 = (has_head(v265_9) ? constant_4 : Space{});
        Space v265_12;
        if (!v265_10.empty()) {
          const Path v267_6 = concat_path(v264_6,v264_7_head);
          const Space v267_11 = routine_58(c, v267_6, v264_7_tail, s1);
          v265_12 = compose(v265_10,v267_11);
        }
        const Space v265_13 = unite(v265_8,v265_12);
        v264_7_result = unite(v264_7_result,v265_13);
      }
      const Space v264_7 = std::move(v264_7_result);
      v263_8 = compose(v263_5,v264_7);
    }
    const Space v263_9 = intersect(constant_3,v263_2);
    const Space v263_10 = (has_head(v263_9) ? constant_4 : Space{});
    Space v263_12;
    if (!v263_10.empty()) {
      const Path v268_6 = concat_path(p0,v262_12_head);
      Space v268_11_result;
      for (int v268_11_label = 1; v268_11_label <= 2; ++v268_11_label) {
        const Space v268_11_tail = child(v262_12_tail,v268_11_label);
        if (v268_11_tail.empty()) continue;
        const Path v268_11_head{v268_11_label};
        const Space v269_2 = singleton(v268_11_head);
        const Space v269_3 = intersect(constant_3,v269_2);
        const Space v269_4 = (has_head(v269_3) ? constant_4 : Space{});
        const Space v269_5 = subtract(constant_2,v269_4);
        Space v269_7;
        if (!v269_5.empty()) {
          const Space v270_6 = routine_25(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_7 = compose(v269_5,v270_6);
        }
        const Space v269_8 = intersect(constant_3,v269_2);
        const Space v269_9 = (has_head(v269_8) ? constant_4 : Space{});
        Space v269_11;
        if (!v269_9.empty()) {
          const Space v271_10 = routine_26(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_11 = compose(v269_9,v271_10);
        }
        const Space v269_12 = unite(v269_7,v269_11);
        v268_11_result = unite(v268_11_result,v269_12);
      }
      const Space v268_11 = std::move(v268_11_result);
      v263_12 = compose(v263_10,v268_11);
    }
    const Space v263_13 = unite(v263_8,v263_12);
    v262_12_result = unite(v262_12_result,v263_13);
  }
  const Space v262_12 = std::move(v262_12_result);
  return v262_12;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v272_13_result;
  for (int v272_13_label = 1; v272_13_label <= 2; ++v272_13_label) {
    const Space v272_13_tail = child(s0,v272_13_label);
    if (v272_13_tail.empty()) continue;
    const Path v272_13_head{v272_13_label};
    const Space v273_2 = singleton(v272_13_head);
    const Space v273_3 = intersect(constant_3,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_4 : Space{});
    const Space v273_5 = subtract(constant_2,v273_4);
    Space v273_8;
    if (!v273_5.empty()) {
      const Path v274_6 = concat_path(p0,v272_13_head);
      Space v274_7_result;
      for (int v274_7_label = 1; v274_7_label <= 2; ++v274_7_label) {
        const Space v274_7_tail = child(v272_13_tail,v274_7_label);
        if (v274_7_tail.empty()) continue;
        const Path v274_7_head{v274_7_label};
        const Space v275_2 = singleton(v274_7_head);
        const Space v275_3 = intersect(constant_3,v275_2);
        const Space v275_4 = (has_head(v275_3) ? constant_4 : Space{});
        const Space v275_5 = subtract(constant_2,v275_4);
        Space v275_8;
        if (!v275_5.empty()) {
          const Path v276_6 = concat_path(v274_6,v274_7_head);
          const Space v276_7 = routine_59(c, v276_6, p1, v274_7_tail, s1);
          v275_8 = compose(v275_5,v276_7);
        }
        const Space v275_9 = intersect(constant_3,v275_2);
        const Space v275_10 = (has_head(v275_9) ? constant_4 : Space{});
        Space v275_12;
        if (!v275_10.empty()) {
          const Path v277_6 = concat_path(v274_6,v274_7_head);
          const Space v277_11 = routine_60(c, v277_6, p1, v274_7_tail, s1);
          v275_12 = compose(v275_10,v277_11);
        }
        const Space v275_13 = unite(v275_8,v275_12);
        v274_7_result = unite(v274_7_result,v275_13);
      }
      const Space v274_7 = std::move(v274_7_result);
      v273_8 = compose(v273_5,v274_7);
    }
    const Space v273_9 = intersect(constant_3,v273_2);
    const Space v273_10 = (has_head(v273_9) ? constant_4 : Space{});
    Space v273_12;
    if (!v273_10.empty()) {
      const Path v278_6 = concat_path(p0,v272_13_head);
      Space v278_11_result;
      for (int v278_11_label = 1; v278_11_label <= 2; ++v278_11_label) {
        const Space v278_11_tail = child(v272_13_tail,v278_11_label);
        if (v278_11_tail.empty()) continue;
        const Path v278_11_head{v278_11_label};
        const Space v279_2 = singleton(v278_11_head);
        const Space v279_3 = intersect(constant_3,v279_2);
        const Space v279_4 = (has_head(v279_3) ? constant_4 : Space{});
        const Space v279_5 = subtract(constant_2,v279_4);
        Space v279_8;
        if (!v279_5.empty()) {
          const Path v280_6 = concat_path(v278_6,v278_11_head);
          const Space v280_7 = routine_59(c, v280_6, p1, v278_11_tail, s1);
          v279_8 = compose(v279_5,v280_7);
        }
        const Space v279_9 = intersect(constant_3,v279_2);
        const Space v279_10 = (has_head(v279_9) ? constant_4 : Space{});
        Space v279_12;
        if (!v279_10.empty()) {
          const Path v281_6 = concat_path(v278_6,v278_11_head);
          const Space v281_11 = routine_29(c, v281_6, p1, v278_11_tail, s1);
          v279_12 = compose(v279_10,v281_11);
        }
        const Space v279_13 = unite(v279_8,v279_12);
        v278_11_result = unite(v278_11_result,v279_13);
      }
      const Space v278_11 = std::move(v278_11_result);
      v273_12 = compose(v273_10,v278_11);
    }
    const Space v273_13 = unite(v273_8,v273_12);
    v272_13_result = unite(v272_13_result,v273_13);
  }
  const Space v272_13 = std::move(v272_13_result);
  return v272_13;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v282_8 = unwrap(s1,constant_5);
  const Space v282_10 = unwrap(v282_8,constant_6);
  const Space v282_11 = unwrap(v282_10,p0);
  Space v282_18_result;
  for (int v282_18_label = 1; v282_18_label <= 2; ++v282_18_label) {
    const Space v282_18_tail = child(s0,v282_18_label);
    if (v282_18_tail.empty()) continue;
    const Path v282_18_head{v282_18_label};
    const Space v283_2 = singleton(v282_18_head);
    const Space v283_3 = intersect(constant_3,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_4 : Space{});
    const Space v283_5 = subtract(constant_2,v283_4);
    Space v283_8;
    if (!v283_5.empty()) {
      const Path v284_6 = concat_path(p0,v282_18_head);
      Space v284_7_result;
      for (int v284_7_label = 1; v284_7_label <= 2; ++v284_7_label) {
        const Space v284_7_tail = child(v282_18_tail,v284_7_label);
        if (v284_7_tail.empty()) continue;
        const Path v284_7_head{v284_7_label};
        const Space v285_2 = singleton(v284_7_head);
        const Space v285_3 = intersect(constant_3,v285_2);
        const Space v285_4 = (has_head(v285_3) ? constant_4 : Space{});
        const Space v285_5 = subtract(constant_2,v285_4);
        Space v285_8;
        if (!v285_5.empty()) {
          const Path v286_6 = concat_path(v284_6,v284_7_head);
          const Space v286_7 = routine_59(c, v286_6, p1, v284_7_tail, s1);
          v285_8 = compose(v285_5,v286_7);
        }
        const Space v285_9 = intersect(constant_3,v285_2);
        const Space v285_10 = (has_head(v285_9) ? constant_4 : Space{});
        Space v285_12;
        if (!v285_10.empty()) {
          const Path v287_6 = concat_path(v284_6,v284_7_head);
          const Space v287_11 = routine_60(c, v287_6, p1, v284_7_tail, s1);
          v285_12 = compose(v285_10,v287_11);
        }
        const Space v285_13 = unite(v285_8,v285_12);
        v284_7_result = unite(v284_7_result,v285_13);
      }
      const Space v284_7 = std::move(v284_7_result);
      v283_8 = compose(v283_5,v284_7);
    }
    const Space v283_9 = intersect(constant_3,v283_2);
    const Space v283_10 = (has_head(v283_9) ? constant_4 : Space{});
    Space v283_13;
    if (!v283_10.empty()) {
      const Space v288_11 = unwrap(v282_11,v282_18_head);
      Space v288_12_result;
      for (int v288_12_label = 1; v288_12_label <= 2; ++v288_12_label) {
        const Space v288_12_tail = child(v288_11,v288_12_label);
        if (v288_12_tail.empty()) continue;
        const Path v288_12_head{v288_12_label};
        const Space v289_2 = singleton(v288_12_head);
        const Space v289_3 = intersect(constant_3,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_4 : Space{});
        const Space v289_5 = subtract(constant_2,v289_4);
        Space v289_7;
        if (!v289_5.empty()) {
          const Space v290_6 = routine_61(c, v288_12_head, p1, v288_12_tail);
          v289_7 = compose(v289_5,v290_6);
        }
        const Space v289_8 = intersect(constant_3,v289_2);
        const Space v289_9 = (has_head(v289_8) ? constant_4 : Space{});
        Space v289_11;
        if (!v289_9.empty()) {
          const Space v291_10 = routine_62(c, v288_12_head, p1, v288_12_tail);
          v289_11 = compose(v289_9,v291_10);
        }
        const Space v289_12 = unite(v289_7,v289_11);
        v288_12_result = unite(v288_12_result,v289_12);
      }
      const Space v288_12 = std::move(v288_12_result);
      v283_13 = compose(v283_10,v288_12);
    }
    const Space v283_14 = unite(v283_8,v283_13);
    v282_18_result = unite(v282_18_result,v283_14);
  }
  const Space v282_18 = std::move(v282_18_result);
  return v282_18;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v292_13_result;
  for (int v292_13_label = 1; v292_13_label <= 2; ++v292_13_label) {
    const Space v292_13_tail = child(s0,v292_13_label);
    if (v292_13_tail.empty()) continue;
    const Path v292_13_head{v292_13_label};
    const Space v293_2 = singleton(v292_13_head);
    const Space v293_3 = intersect(constant_3,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_4 : Space{});
    const Space v293_5 = subtract(constant_2,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_13_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_13_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_3,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_4 : Space{});
        const Space v295_5 = subtract(constant_2,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_63(c, v296_6, p1, v294_7_tail, s1);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_3,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_4 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_64(c, v297_6, p1, v294_7_tail, s1);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_3,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_4 : Space{});
    Space v293_12;
    if (!v293_10.empty()) {
      const Path v298_6 = concat_path(p0,v292_13_head);
      Space v298_11_result;
      for (int v298_11_label = 1; v298_11_label <= 2; ++v298_11_label) {
        const Space v298_11_tail = child(v292_13_tail,v298_11_label);
        if (v298_11_tail.empty()) continue;
        const Path v298_11_head{v298_11_label};
        const Space v299_2 = singleton(v298_11_head);
        const Space v299_3 = intersect(constant_3,v299_2);
        const Space v299_4 = (has_head(v299_3) ? constant_4 : Space{});
        const Space v299_5 = subtract(constant_2,v299_4);
        Space v299_8;
        if (!v299_5.empty()) {
          const Path v300_6 = concat_path(v298_6,v298_11_head);
          const Space v300_7 = routine_63(c, v300_6, p1, v298_11_tail, s1);
          v299_8 = compose(v299_5,v300_7);
        }
        const Space v299_9 = intersect(constant_3,v299_2);
        const Space v299_10 = (has_head(v299_9) ? constant_4 : Space{});
        Space v299_12;
        if (!v299_10.empty()) {
          const Path v301_6 = concat_path(v298_6,v298_11_head);
          const Space v301_11 = routine_29(c, v301_6, p1, v298_11_tail, s1);
          v299_12 = compose(v299_10,v301_11);
        }
        const Space v299_13 = unite(v299_8,v299_12);
        v298_11_result = unite(v298_11_result,v299_13);
      }
      const Space v298_11 = std::move(v298_11_result);
      v293_12 = compose(v293_10,v298_11);
    }
    const Space v293_13 = unite(v293_8,v293_12);
    v292_13_result = unite(v292_13_result,v293_13);
  }
  const Space v292_13 = std::move(v292_13_result);
  return v292_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v302_8 = unwrap(s1,constant_5);
  const Space v302_10 = unwrap(v302_8,constant_6);
  const Space v302_11 = unwrap(v302_10,p0);
  Space v302_18_result;
  for (int v302_18_label = 1; v302_18_label <= 2; ++v302_18_label) {
    const Space v302_18_tail = child(s0,v302_18_label);
    if (v302_18_tail.empty()) continue;
    const Path v302_18_head{v302_18_label};
    const Space v303_2 = singleton(v302_18_head);
    const Space v303_3 = intersect(constant_3,v303_2);
    const Space v303_4 = (has_head(v303_3) ? constant_4 : Space{});
    const Space v303_5 = subtract(constant_2,v303_4);
    Space v303_8;
    if (!v303_5.empty()) {
      const Path v304_6 = concat_path(p0,v302_18_head);
      Space v304_7_result;
      for (int v304_7_label = 1; v304_7_label <= 2; ++v304_7_label) {
        const Space v304_7_tail = child(v302_18_tail,v304_7_label);
        if (v304_7_tail.empty()) continue;
        const Path v304_7_head{v304_7_label};
        const Space v305_2 = singleton(v304_7_head);
        const Space v305_3 = intersect(constant_3,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_4 : Space{});
        const Space v305_5 = subtract(constant_2,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v304_6,v304_7_head);
          const Space v306_7 = routine_63(c, v306_6, p1, v304_7_tail, s1);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_3,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_4 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v304_6,v304_7_head);
          const Space v307_11 = routine_64(c, v307_6, p1, v304_7_tail, s1);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_7_result = unite(v304_7_result,v305_13);
      }
      const Space v304_7 = std::move(v304_7_result);
      v303_8 = compose(v303_5,v304_7);
    }
    const Space v303_9 = intersect(constant_3,v303_2);
    const Space v303_10 = (has_head(v303_9) ? constant_4 : Space{});
    Space v303_13;
    if (!v303_10.empty()) {
      const Space v308_11 = unwrap(v302_11,v302_18_head);
      Space v308_12_result;
      for (int v308_12_label = 1; v308_12_label <= 2; ++v308_12_label) {
        const Space v308_12_tail = child(v308_11,v308_12_label);
        if (v308_12_tail.empty()) continue;
        const Path v308_12_head{v308_12_label};
        const Space v309_2 = singleton(v308_12_head);
        const Space v309_3 = intersect(constant_3,v309_2);
        const Space v309_4 = (has_head(v309_3) ? constant_4 : Space{});
        const Space v309_5 = subtract(constant_2,v309_4);
        Space v309_7;
        if (!v309_5.empty()) {
          const Space v310_6 = routine_61(c, v308_12_head, p1, v308_12_tail);
          v309_7 = compose(v309_5,v310_6);
        }
        const Space v309_8 = intersect(constant_3,v309_2);
        const Space v309_9 = (has_head(v309_8) ? constant_4 : Space{});
        Space v309_11;
        if (!v309_9.empty()) {
          const Space v311_10 = routine_62(c, v308_12_head, p1, v308_12_tail);
          v309_11 = compose(v309_9,v311_10);
        }
        const Space v309_12 = unite(v309_7,v309_11);
        v308_12_result = unite(v308_12_result,v309_12);
      }
      const Space v308_12 = std::move(v308_12_result);
      v303_13 = compose(v303_10,v308_12);
    }
    const Space v303_14 = unite(v303_8,v303_13);
    v302_18_result = unite(v302_18_result,v303_14);
  }
  const Space v302_18 = std::move(v302_18_result);
  return v302_18;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v312_5 = unwrap(s1,constant_5);
  const Space v312_7 = unwrap(v312_5,constant_6);
  const Space v312_8 = unwrap(v312_7,p0);
  Space v312_18_result;
  for (int v312_18_label = 1; v312_18_label <= 2; ++v312_18_label) {
    const Space v312_18_tail = child(v312_8,v312_18_label);
    if (v312_18_tail.empty()) continue;
    const Path v312_18_head{v312_18_label};
    const Space v313_2 = singleton(v312_18_head);
    const Space v313_3 = intersect(constant_3,v313_2);
    const Space v313_4 = (has_head(v313_3) ? constant_4 : Space{});
    const Space v313_5 = subtract(constant_2,v313_4);
    Space v313_7;
    if (!v313_5.empty()) {
      Space v314_6_result;
      for (int v314_6_label = 1; v314_6_label <= 2; ++v314_6_label) {
        const Space v314_6_tail = child(v312_18_tail,v314_6_label);
        if (v314_6_tail.empty()) continue;
        const Path v314_6_head{v314_6_label};
        const Space v315_2 = singleton(v314_6_head);
        const Space v315_3 = intersect(constant_3,v315_2);
        const Space v315_4 = (has_head(v315_3) ? constant_4 : Space{});
        const Space v315_5 = subtract(constant_2,v315_4);
        Space v315_8;
        if (!v315_5.empty()) {
          const Path v316_6 = concat_path(v312_18_head,v314_6_head);
          const Space v316_7 = routine_65(c, v316_6, p1, v314_6_tail);
          v315_8 = compose(v315_5,v316_7);
        }
        const Space v315_9 = intersect(constant_3,v315_2);
        const Space v315_10 = (has_head(v315_9) ? constant_4 : Space{});
        Space v315_12;
        if (!v315_10.empty()) {
          const Path v317_6 = concat_path(v312_18_head,v314_6_head);
          const Space v317_11 = routine_66(c, v317_6, p1, v314_6_tail);
          v315_12 = compose(v315_10,v317_11);
        }
        const Space v315_13 = unite(v315_8,v315_12);
        v314_6_result = unite(v314_6_result,v315_13);
      }
      const Space v314_6 = std::move(v314_6_result);
      v313_7 = compose(v313_5,v314_6);
    }
    const Space v313_8 = intersect(constant_3,v313_2);
    const Space v313_9 = (has_head(v313_8) ? constant_4 : Space{});
    Space v313_11;
    if (!v313_9.empty()) {
      Space v318_10_result;
      for (int v318_10_label = 1; v318_10_label <= 2; ++v318_10_label) {
        const Space v318_10_tail = child(v312_18_tail,v318_10_label);
        if (v318_10_tail.empty()) continue;
        const Path v318_10_head{v318_10_label};
        const Space v319_2 = singleton(v318_10_head);
        const Space v319_3 = intersect(constant_3,v319_2);
        const Space v319_4 = (has_head(v319_3) ? constant_4 : Space{});
        const Space v319_5 = subtract(constant_2,v319_4);
        Space v319_8;
        if (!v319_5.empty()) {
          const Path v320_6 = concat_path(v312_18_head,v318_10_head);
          const Space v320_7 = routine_65(c, v320_6, p1, v318_10_tail);
          v319_8 = compose(v319_5,v320_7);
        }
        const Space v319_9 = intersect(constant_3,v319_2);
        const Space v319_10 = (has_head(v319_9) ? constant_4 : Space{});
        Space v319_12;
        if (!v319_10.empty()) {
          const Path v321_6 = concat_path(v312_18_head,v318_10_head);
          const Space v321_11 = routine_67(c, v321_6, p1, v318_10_tail);
          v319_12 = compose(v319_10,v321_11);
        }
        const Space v319_13 = unite(v319_8,v319_12);
        v318_10_result = unite(v318_10_result,v319_13);
      }
      const Space v318_10 = std::move(v318_10_result);
      v313_11 = compose(v313_9,v318_10);
    }
    const Space v313_12 = unite(v313_7,v313_11);
    v312_18_result = unite(v312_18_result,v313_12);
  }
  const Space v312_18 = std::move(v312_18_result);
  return v312_18;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v322_11_result;
  for (int v322_11_label = 1; v322_11_label <= 2; ++v322_11_label) {
    const Space v322_11_tail = child(s0,v322_11_label);
    if (v322_11_tail.empty()) continue;
    const Path v322_11_head{v322_11_label};
    const Space v323_2 = singleton(v322_11_head);
    const Space v323_3 = intersect(constant_3,v323_2);
    const Space v323_4 = (has_head(v323_3) ? constant_4 : Space{});
    const Space v323_5 = subtract(constant_2,v323_4);
    Space v323_8;
    if (!v323_5.empty()) {
      const Path v324_6 = concat_path(p0,v322_11_head);
      Space v324_7_result;
      for (int v324_7_label = 1; v324_7_label <= 2; ++v324_7_label) {
        const Space v324_7_tail = child(v322_11_tail,v324_7_label);
        if (v324_7_tail.empty()) continue;
        const Path v324_7_head{v324_7_label};
        const Space v325_2 = singleton(v324_7_head);
        const Space v325_3 = intersect(constant_3,v325_2);
        const Space v325_4 = (has_head(v325_3) ? constant_4 : Space{});
        const Space v325_5 = subtract(constant_2,v325_4);
        Space v325_8;
        if (!v325_5.empty()) {
          const Path v326_6 = concat_path(v324_6,v324_7_head);
          const Space v326_7 = routine_68(c, v326_6, v324_7_tail);
          v325_8 = compose(v325_5,v326_7);
        }
        const Space v325_9 = intersect(constant_3,v325_2);
        const Space v325_10 = (has_head(v325_9) ? constant_4 : Space{});
        Space v325_12;
        if (!v325_10.empty()) {
          const Path v327_6 = concat_path(v324_6,v324_7_head);
          const Space v327_11 = routine_69(c, v327_6, v324_7_tail);
          v325_12 = compose(v325_10,v327_11);
        }
        const Space v325_13 = unite(v325_8,v325_12);
        v324_7_result = unite(v324_7_result,v325_13);
      }
      const Space v324_7 = std::move(v324_7_result);
      v323_8 = compose(v323_5,v324_7);
    }
    const Space v323_9 = intersect(constant_3,v323_2);
    const Space v323_10 = (has_head(v323_9) ? constant_4 : Space{});
    Space v323_12;
    if (!v323_10.empty()) {
      const Path v328_6 = concat_path(p0,v322_11_head);
      Space v328_11_result;
      for (int v328_11_label = 1; v328_11_label <= 2; ++v328_11_label) {
        const Space v328_11_tail = child(v322_11_tail,v328_11_label);
        if (v328_11_tail.empty()) continue;
        const Path v328_11_head{v328_11_label};
        const Space v329_2 = singleton(v328_11_head);
        const Space v329_3 = intersect(constant_3,v329_2);
        const Space v329_4 = (has_head(v329_3) ? constant_4 : Space{});
        const Space v329_5 = subtract(constant_2,v329_4);
        Space v329_8;
        if (!v329_5.empty()) {
          const Path v330_6 = concat_path(v328_6,v328_11_head);
          const Space v330_7 = routine_68(c, v330_6, v328_11_tail);
          v329_8 = compose(v329_5,v330_7);
        }
        const Space v329_9 = intersect(constant_3,v329_2);
        const Space v329_10 = (has_head(v329_9) ? constant_4 : Space{});
        Space v329_12;
        if (!v329_10.empty()) {
          const Path v331_6 = concat_path(v328_6,v328_11_head);
          const Space v331_11 = routine_9(c, v331_6, v328_11_tail);
          v329_12 = compose(v329_10,v331_11);
        }
        const Space v329_13 = unite(v329_8,v329_12);
        v328_11_result = unite(v328_11_result,v329_13);
      }
      const Space v328_11 = std::move(v328_11_result);
      v323_12 = compose(v323_10,v328_11);
    }
    const Space v323_13 = unite(v323_8,v323_12);
    v322_11_result = unite(v322_11_result,v323_13);
  }
  const Space v322_11 = std::move(v322_11_result);
  return v322_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v332_11_result;
  for (int v332_11_label = 1; v332_11_label <= 2; ++v332_11_label) {
    const Space v332_11_tail = child(s0,v332_11_label);
    if (v332_11_tail.empty()) continue;
    const Path v332_11_head{v332_11_label};
    const Space v333_2 = singleton(v332_11_head);
    const Space v333_3 = intersect(constant_3,v333_2);
    const Space v333_4 = (has_head(v333_3) ? constant_4 : Space{});
    const Space v333_5 = subtract(constant_2,v333_4);
    Space v333_8;
    if (!v333_5.empty()) {
      const Path v334_6 = concat_path(p0,v332_11_head);
      Space v334_7_result;
      for (int v334_7_label = 1; v334_7_label <= 2; ++v334_7_label) {
        const Space v334_7_tail = child(v332_11_tail,v334_7_label);
        if (v334_7_tail.empty()) continue;
        const Path v334_7_head{v334_7_label};
        const Space v335_2 = singleton(v334_7_head);
        const Space v335_3 = intersect(constant_3,v335_2);
        const Space v335_4 = (has_head(v335_3) ? constant_4 : Space{});
        const Space v335_5 = subtract(constant_2,v335_4);
        Space v335_8;
        if (!v335_5.empty()) {
          const Path v336_6 = concat_path(v334_6,v334_7_head);
          const Space v336_7 = routine_68(c, v336_6, v334_7_tail);
          v335_8 = compose(v335_5,v336_7);
        }
        const Space v335_9 = intersect(constant_3,v335_2);
        const Space v335_10 = (has_head(v335_9) ? constant_4 : Space{});
        Space v335_12;
        if (!v335_10.empty()) {
          const Path v337_6 = concat_path(v334_6,v334_7_head);
          const Space v337_11 = routine_69(c, v337_6, v334_7_tail);
          v335_12 = compose(v335_10,v337_11);
        }
        const Space v335_13 = unite(v335_8,v335_12);
        v334_7_result = unite(v334_7_result,v335_13);
      }
      const Space v334_7 = std::move(v334_7_result);
      v333_8 = compose(v333_5,v334_7);
    }
    const Space v333_9 = intersect(constant_3,v333_2);
    const Space v333_10 = (has_head(v333_9) ? constant_4 : Space{});
    Space v333_12;
    if (!v333_10.empty()) {
      const Path v338_6 = concat_path(p0,v332_11_head);
      Space v338_11_result;
      for (int v338_11_label = 1; v338_11_label <= 2; ++v338_11_label) {
        const Space v338_11_tail = child(v332_11_tail,v338_11_label);
        if (v338_11_tail.empty()) continue;
        const Path v338_11_head{v338_11_label};
        const Space v339_2 = singleton(v338_11_head);
        const Space v339_3 = intersect(constant_3,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_4 : Space{});
        const Space v339_5 = subtract(constant_2,v339_4);
        Space v339_7;
        if (!v339_5.empty()) {
          const Space v340_6 = routine_32(c, v338_11_head, v338_6, v338_11_tail);
          v339_7 = compose(v339_5,v340_6);
        }
        const Space v339_8 = intersect(constant_3,v339_2);
        const Space v339_9 = (has_head(v339_8) ? constant_4 : Space{});
        Space v339_11;
        if (!v339_9.empty()) {
          const Space v341_10 = routine_33(c, v338_11_head, v338_6, v338_11_tail);
          v339_11 = compose(v339_9,v341_10);
        }
        const Space v339_12 = unite(v339_7,v339_11);
        v338_11_result = unite(v338_11_result,v339_12);
      }
      const Space v338_11 = std::move(v338_11_result);
      v333_12 = compose(v333_10,v338_11);
    }
    const Space v333_13 = unite(v333_8,v333_12);
    v332_11_result = unite(v332_11_result,v333_13);
  }
  const Space v332_11 = std::move(v332_11_result);
  return v332_11;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v342_12_result;
  for (int v342_12_label = 1; v342_12_label <= 2; ++v342_12_label) {
    const Space v342_12_tail = child(s0,v342_12_label);
    if (v342_12_tail.empty()) continue;
    const Path v342_12_head{v342_12_label};
    const Space v343_2 = singleton(v342_12_head);
    const Space v343_3 = intersect(constant_3,v343_2);
    const Space v343_4 = (has_head(v343_3) ? constant_4 : Space{});
    const Space v343_5 = subtract(constant_2,v343_4);
    Space v343_8;
    if (!v343_5.empty()) {
      const Path v344_6 = concat_path(p0,v342_12_head);
      Space v344_7_result;
      for (int v344_7_label = 1; v344_7_label <= 2; ++v344_7_label) {
        const Space v344_7_tail = child(v342_12_tail,v344_7_label);
        if (v344_7_tail.empty()) continue;
        const Path v344_7_head{v344_7_label};
        const Space v345_2 = singleton(v344_7_head);
        const Space v345_3 = intersect(constant_3,v345_2);
        const Space v345_4 = (has_head(v345_3) ? constant_4 : Space{});
        const Space v345_5 = subtract(constant_2,v345_4);
        Space v345_8;
        if (!v345_5.empty()) {
          const Path v346_6 = concat_path(v344_6,v344_7_head);
          const Space v346_7 = routine_70(c, v346_6, p1, v344_7_tail);
          v345_8 = compose(v345_5,v346_7);
        }
        const Space v345_9 = intersect(constant_3,v345_2);
        const Space v345_10 = (has_head(v345_9) ? constant_4 : Space{});
        Space v345_12;
        if (!v345_10.empty()) {
          const Path v347_6 = concat_path(v344_6,v344_7_head);
          const Space v347_11 = routine_71(c, v347_6, p1, v344_7_tail);
          v345_12 = compose(v345_10,v347_11);
        }
        const Space v345_13 = unite(v345_8,v345_12);
        v344_7_result = unite(v344_7_result,v345_13);
      }
      const Space v344_7 = std::move(v344_7_result);
      v343_8 = compose(v343_5,v344_7);
    }
    const Space v343_9 = intersect(constant_3,v343_2);
    const Space v343_10 = (has_head(v343_9) ? constant_4 : Space{});
    Space v343_12;
    if (!v343_10.empty()) {
      const Path v348_6 = concat_path(p0,v342_12_head);
      Space v348_11_result;
      for (int v348_11_label = 1; v348_11_label <= 2; ++v348_11_label) {
        const Space v348_11_tail = child(v342_12_tail,v348_11_label);
        if (v348_11_tail.empty()) continue;
        const Path v348_11_head{v348_11_label};
        const Space v349_2 = singleton(v348_11_head);
        const Space v349_3 = intersect(constant_3,v349_2);
        const Space v349_4 = (has_head(v349_3) ? constant_4 : Space{});
        const Space v349_5 = subtract(constant_2,v349_4);
        Space v349_8;
        if (!v349_5.empty()) {
          const Path v350_6 = concat_path(v348_6,v348_11_head);
          const Space v350_7 = routine_70(c, v350_6, p1, v348_11_tail);
          v349_8 = compose(v349_5,v350_7);
        }
        const Space v349_9 = intersect(constant_3,v349_2);
        const Space v349_10 = (has_head(v349_9) ? constant_4 : Space{});
        Space v349_12;
        if (!v349_10.empty()) {
          const Path v351_6 = concat_path(v348_6,v348_11_head);
          const Space v351_11 = routine_36(c, v351_6, p1, v348_11_tail);
          v349_12 = compose(v349_10,v351_11);
        }
        const Space v349_13 = unite(v349_8,v349_12);
        v348_11_result = unite(v348_11_result,v349_13);
      }
      const Space v348_11 = std::move(v348_11_result);
      v343_12 = compose(v343_10,v348_11);
    }
    const Space v343_13 = unite(v343_8,v343_12);
    v342_12_result = unite(v342_12_result,v343_13);
  }
  const Space v342_12 = std::move(v342_12_result);
  return v342_12;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v352_9_result;
  for (int v352_9_label = 1; v352_9_label <= 2; ++v352_9_label) {
    const Space v352_9_tail = child(s0,v352_9_label);
    if (v352_9_tail.empty()) continue;
    const Path v352_9_head{v352_9_label};
    const Space v353_2 = singleton(v352_9_head);
    const Space v353_3 = intersect(constant_3,v353_2);
    const Space v353_4 = (has_head(v353_3) ? constant_4 : Space{});
    const Space v353_5 = subtract(constant_2,v353_4);
    Space v353_8;
    if (!v353_5.empty()) {
      const Path v354_6 = concat_path(p0,v352_9_head);
      Space v354_7_result;
      for (int v354_7_label = 1; v354_7_label <= 2; ++v354_7_label) {
        const Space v354_7_tail = child(v352_9_tail,v354_7_label);
        if (v354_7_tail.empty()) continue;
        const Path v354_7_head{v354_7_label};
        const Space v355_2 = singleton(v354_7_head);
        const Space v355_3 = intersect(constant_3,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_4 : Space{});
        const Space v355_5 = subtract(constant_2,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_7_head);
          const Space v356_7 = routine_70(c, v356_6, p1, v354_7_tail);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_3,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_4 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_7_head);
          const Space v357_11 = routine_71(c, v357_6, p1, v354_7_tail);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_7_result = unite(v354_7_result,v355_13);
      }
      const Space v354_7 = std::move(v354_7_result);
      v353_8 = compose(v353_5,v354_7);
    }
    const Space v353_9 = intersect(constant_3,v353_2);
    const Space v353_10 = (has_head(v353_9) ? constant_4 : Space{});
    const Space v353_11 = compose(v353_10,v352_9_tail);
    const Path v358_6 = concat_path(p0,v352_9_head);
    const Space v353_12 = wrap(v353_11,v358_6);
    const Space v353_13 = wrap(v353_12,p1);
    const Space v353_14 = unite(v353_8,v353_13);
    v352_9_result = unite(v352_9_result,v353_14);
  }
  const Space v352_9 = std::move(v352_9_result);
  return v352_9;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v359_12_result;
  for (int v359_12_label = 1; v359_12_label <= 2; ++v359_12_label) {
    const Space v359_12_tail = child(s0,v359_12_label);
    if (v359_12_tail.empty()) continue;
    const Path v359_12_head{v359_12_label};
    const Space v360_2 = singleton(v359_12_head);
    const Space v360_3 = intersect(constant_3,v360_2);
    const Space v360_4 = (has_head(v360_3) ? constant_4 : Space{});
    const Space v360_5 = subtract(constant_2,v360_4);
    Space v360_8;
    if (!v360_5.empty()) {
      const Path v361_6 = concat_path(p0,v359_12_head);
      Space v361_7_result;
      for (int v361_7_label = 1; v361_7_label <= 2; ++v361_7_label) {
        const Space v361_7_tail = child(v359_12_tail,v361_7_label);
        if (v361_7_tail.empty()) continue;
        const Path v361_7_head{v361_7_label};
        const Space v362_2 = singleton(v361_7_head);
        const Space v362_3 = intersect(constant_3,v362_2);
        const Space v362_4 = (has_head(v362_3) ? constant_4 : Space{});
        const Space v362_5 = subtract(constant_2,v362_4);
        Space v362_8;
        if (!v362_5.empty()) {
          const Path v363_6 = concat_path(v361_6,v361_7_head);
          const Space v363_7 = routine_72(c, v363_6, p1, v361_7_tail);
          v362_8 = compose(v362_5,v363_7);
        }
        const Space v362_9 = intersect(constant_3,v362_2);
        const Space v362_10 = (has_head(v362_9) ? constant_4 : Space{});
        Space v362_12;
        if (!v362_10.empty()) {
          const Path v364_6 = concat_path(v361_6,v361_7_head);
          const Space v364_11 = routine_73(c, v364_6, p1, v361_7_tail);
          v362_12 = compose(v362_10,v364_11);
        }
        const Space v362_13 = unite(v362_8,v362_12);
        v361_7_result = unite(v361_7_result,v362_13);
      }
      const Space v361_7 = std::move(v361_7_result);
      v360_8 = compose(v360_5,v361_7);
    }
    const Space v360_9 = intersect(constant_3,v360_2);
    const Space v360_10 = (has_head(v360_9) ? constant_4 : Space{});
    Space v360_12;
    if (!v360_10.empty()) {
      const Path v365_6 = concat_path(p0,v359_12_head);
      Space v365_11_result;
      for (int v365_11_label = 1; v365_11_label <= 2; ++v365_11_label) {
        const Space v365_11_tail = child(v359_12_tail,v365_11_label);
        if (v365_11_tail.empty()) continue;
        const Path v365_11_head{v365_11_label};
        const Space v366_2 = singleton(v365_11_head);
        const Space v366_3 = intersect(constant_3,v366_2);
        const Space v366_4 = (has_head(v366_3) ? constant_4 : Space{});
        const Space v366_5 = subtract(constant_2,v366_4);
        Space v366_8;
        if (!v366_5.empty()) {
          const Path v367_6 = concat_path(v365_6,v365_11_head);
          const Space v367_7 = routine_72(c, v367_6, p1, v365_11_tail);
          v366_8 = compose(v366_5,v367_7);
        }
        const Space v366_9 = intersect(constant_3,v366_2);
        const Space v366_10 = (has_head(v366_9) ? constant_4 : Space{});
        Space v366_12;
        if (!v366_10.empty()) {
          const Path v368_6 = concat_path(v365_6,v365_11_head);
          const Space v368_11 = routine_36(c, v368_6, p1, v365_11_tail);
          v366_12 = compose(v366_10,v368_11);
        }
        const Space v366_13 = unite(v366_8,v366_12);
        v365_11_result = unite(v365_11_result,v366_13);
      }
      const Space v365_11 = std::move(v365_11_result);
      v360_12 = compose(v360_10,v365_11);
    }
    const Space v360_13 = unite(v360_8,v360_12);
    v359_12_result = unite(v359_12_result,v360_13);
  }
  const Space v359_12 = std::move(v359_12_result);
  return v359_12;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v369_9_result;
  for (int v369_9_label = 1; v369_9_label <= 2; ++v369_9_label) {
    const Space v369_9_tail = child(s0,v369_9_label);
    if (v369_9_tail.empty()) continue;
    const Path v369_9_head{v369_9_label};
    const Space v370_2 = singleton(v369_9_head);
    const Space v370_3 = intersect(constant_3,v370_2);
    const Space v370_4 = (has_head(v370_3) ? constant_4 : Space{});
    const Space v370_5 = subtract(constant_2,v370_4);
    Space v370_8;
    if (!v370_5.empty()) {
      const Path v371_6 = concat_path(p0,v369_9_head);
      Space v371_7_result;
      for (int v371_7_label = 1; v371_7_label <= 2; ++v371_7_label) {
        const Space v371_7_tail = child(v369_9_tail,v371_7_label);
        if (v371_7_tail.empty()) continue;
        const Path v371_7_head{v371_7_label};
        const Space v372_2 = singleton(v371_7_head);
        const Space v372_3 = intersect(constant_3,v372_2);
        const Space v372_4 = (has_head(v372_3) ? constant_4 : Space{});
        const Space v372_5 = subtract(constant_2,v372_4);
        Space v372_8;
        if (!v372_5.empty()) {
          const Path v373_6 = concat_path(v371_6,v371_7_head);
          const Space v373_7 = routine_72(c, v373_6, p1, v371_7_tail);
          v372_8 = compose(v372_5,v373_7);
        }
        const Space v372_9 = intersect(constant_3,v372_2);
        const Space v372_10 = (has_head(v372_9) ? constant_4 : Space{});
        Space v372_12;
        if (!v372_10.empty()) {
          const Path v374_6 = concat_path(v371_6,v371_7_head);
          const Space v374_11 = routine_73(c, v374_6, p1, v371_7_tail);
          v372_12 = compose(v372_10,v374_11);
        }
        const Space v372_13 = unite(v372_8,v372_12);
        v371_7_result = unite(v371_7_result,v372_13);
      }
      const Space v371_7 = std::move(v371_7_result);
      v370_8 = compose(v370_5,v371_7);
    }
    const Space v370_9 = intersect(constant_3,v370_2);
    const Space v370_10 = (has_head(v370_9) ? constant_4 : Space{});
    const Space v370_11 = compose(v370_10,v369_9_tail);
    const Path v375_6 = concat_path(p0,v369_9_head);
    const Space v370_12 = wrap(v370_11,v375_6);
    const Space v370_13 = wrap(v370_12,p1);
    const Space v370_14 = unite(v370_8,v370_13);
    v369_9_result = unite(v369_9_result,v370_14);
  }
  const Space v369_9 = std::move(v369_9_result);
  return v369_9;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v376_3 = wrap(s0,p0);
  const Space v376_4 = wrap(v376_3,p1);
  return v376_4;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v377_12_result;
  for (int v377_12_label = 1; v377_12_label <= 2; ++v377_12_label) {
    const Space v377_12_tail = child(s0,v377_12_label);
    if (v377_12_tail.empty()) continue;
    const Path v377_12_head{v377_12_label};
    const Space v378_2 = singleton(v377_12_head);
    const Space v378_3 = intersect(constant_3,v378_2);
    const Space v378_4 = (has_head(v378_3) ? constant_4 : Space{});
    const Space v378_5 = subtract(constant_2,v378_4);
    Space v378_8;
    if (!v378_5.empty()) {
      const Path v379_6 = concat_path(p0,v377_12_head);
      Space v379_7_result;
      for (int v379_7_label = 1; v379_7_label <= 2; ++v379_7_label) {
        const Space v379_7_tail = child(v377_12_tail,v379_7_label);
        if (v379_7_tail.empty()) continue;
        const Path v379_7_head{v379_7_label};
        const Space v380_2 = singleton(v379_7_head);
        const Space v380_3 = intersect(constant_3,v380_2);
        const Space v380_4 = (has_head(v380_3) ? constant_4 : Space{});
        const Space v380_5 = subtract(constant_2,v380_4);
        Space v380_8;
        if (!v380_5.empty()) {
          const Path v381_6 = concat_path(v379_6,v379_7_head);
          const Space v381_7 = routine_74(c, v381_6, v379_7_tail, s1);
          v380_8 = compose(v380_5,v381_7);
        }
        const Space v380_9 = intersect(constant_3,v380_2);
        const Space v380_10 = (has_head(v380_9) ? constant_4 : Space{});
        Space v380_12;
        if (!v380_10.empty()) {
          const Path v382_6 = concat_path(v379_6,v379_7_head);
          const Space v382_11 = routine_75(c, v382_6, v379_7_tail, s1);
          v380_12 = compose(v380_10,v382_11);
        }
        const Space v380_13 = unite(v380_8,v380_12);
        v379_7_result = unite(v379_7_result,v380_13);
      }
      const Space v379_7 = std::move(v379_7_result);
      v378_8 = compose(v378_5,v379_7);
    }
    const Space v378_9 = intersect(constant_3,v378_2);
    const Space v378_10 = (has_head(v378_9) ? constant_4 : Space{});
    Space v378_12;
    if (!v378_10.empty()) {
      const Path v383_6 = concat_path(p0,v377_12_head);
      Space v383_11_result;
      for (int v383_11_label = 1; v383_11_label <= 2; ++v383_11_label) {
        const Space v383_11_tail = child(v377_12_tail,v383_11_label);
        if (v383_11_tail.empty()) continue;
        const Path v383_11_head{v383_11_label};
        const Space v384_2 = singleton(v383_11_head);
        const Space v384_3 = intersect(constant_3,v384_2);
        const Space v384_4 = (has_head(v384_3) ? constant_4 : Space{});
        const Space v384_5 = subtract(constant_2,v384_4);
        Space v384_8;
        if (!v384_5.empty()) {
          const Path v385_6 = concat_path(v383_6,v383_11_head);
          const Space v385_7 = routine_74(c, v385_6, v383_11_tail, s1);
          v384_8 = compose(v384_5,v385_7);
        }
        const Space v384_9 = intersect(constant_3,v384_2);
        const Space v384_10 = (has_head(v384_9) ? constant_4 : Space{});
        Space v384_12;
        if (!v384_10.empty()) {
          const Path v386_6 = concat_path(v383_6,v383_11_head);
          const Space v386_11 = routine_12(c, v386_6, v383_11_tail, s1);
          v384_12 = compose(v384_10,v386_11);
        }
        const Space v384_13 = unite(v384_8,v384_12);
        v383_11_result = unite(v383_11_result,v384_13);
      }
      const Space v383_11 = std::move(v383_11_result);
      v378_12 = compose(v378_10,v383_11);
    }
    const Space v378_13 = unite(v378_8,v378_12);
    v377_12_result = unite(v377_12_result,v378_13);
  }
  const Space v377_12 = std::move(v377_12_result);
  return v377_12;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v387_12_result;
  for (int v387_12_label = 1; v387_12_label <= 2; ++v387_12_label) {
    const Space v387_12_tail = child(s0,v387_12_label);
    if (v387_12_tail.empty()) continue;
    const Path v387_12_head{v387_12_label};
    const Space v388_2 = singleton(v387_12_head);
    const Space v388_3 = intersect(constant_3,v388_2);
    const Space v388_4 = (has_head(v388_3) ? constant_4 : Space{});
    const Space v388_5 = subtract(constant_2,v388_4);
    Space v388_8;
    if (!v388_5.empty()) {
      const Path v389_6 = concat_path(p0,v387_12_head);
      Space v389_7_result;
      for (int v389_7_label = 1; v389_7_label <= 2; ++v389_7_label) {
        const Space v389_7_tail = child(v387_12_tail,v389_7_label);
        if (v389_7_tail.empty()) continue;
        const Path v389_7_head{v389_7_label};
        const Space v390_2 = singleton(v389_7_head);
        const Space v390_3 = intersect(constant_3,v390_2);
        const Space v390_4 = (has_head(v390_3) ? constant_4 : Space{});
        const Space v390_5 = subtract(constant_2,v390_4);
        Space v390_8;
        if (!v390_5.empty()) {
          const Path v391_6 = concat_path(v389_6,v389_7_head);
          const Space v391_7 = routine_74(c, v391_6, v389_7_tail, s1);
          v390_8 = compose(v390_5,v391_7);
        }
        const Space v390_9 = intersect(constant_3,v390_2);
        const Space v390_10 = (has_head(v390_9) ? constant_4 : Space{});
        Space v390_12;
        if (!v390_10.empty()) {
          const Path v392_6 = concat_path(v389_6,v389_7_head);
          const Space v392_11 = routine_75(c, v392_6, v389_7_tail, s1);
          v390_12 = compose(v390_10,v392_11);
        }
        const Space v390_13 = unite(v390_8,v390_12);
        v389_7_result = unite(v389_7_result,v390_13);
      }
      const Space v389_7 = std::move(v389_7_result);
      v388_8 = compose(v388_5,v389_7);
    }
    const Space v388_9 = intersect(constant_3,v388_2);
    const Space v388_10 = (has_head(v388_9) ? constant_4 : Space{});
    Space v388_12;
    if (!v388_10.empty()) {
      const Path v393_6 = concat_path(p0,v387_12_head);
      Space v393_11_result;
      for (int v393_11_label = 1; v393_11_label <= 2; ++v393_11_label) {
        const Space v393_11_tail = child(v387_12_tail,v393_11_label);
        if (v393_11_tail.empty()) continue;
        const Path v393_11_head{v393_11_label};
        const Space v394_2 = singleton(v393_11_head);
        const Space v394_3 = intersect(constant_3,v394_2);
        const Space v394_4 = (has_head(v394_3) ? constant_4 : Space{});
        const Space v394_5 = subtract(constant_2,v394_4);
        Space v394_7;
        if (!v394_5.empty()) {
          const Space v395_6 = routine_39(c, v393_11_head, v393_6, v393_11_tail, s1);
          v394_7 = compose(v394_5,v395_6);
        }
        const Space v394_8 = intersect(constant_3,v394_2);
        const Space v394_9 = (has_head(v394_8) ? constant_4 : Space{});
        Space v394_11;
        if (!v394_9.empty()) {
          const Space v396_10 = routine_40(c, v393_11_head, v393_6, v393_11_tail, s1);
          v394_11 = compose(v394_9,v396_10);
        }
        const Space v394_12 = unite(v394_7,v394_11);
        v393_11_result = unite(v393_11_result,v394_12);
      }
      const Space v393_11 = std::move(v393_11_result);
      v388_12 = compose(v388_10,v393_11);
    }
    const Space v388_13 = unite(v388_8,v388_12);
    v387_12_result = unite(v387_12_result,v388_13);
  }
  const Space v387_12 = std::move(v387_12_result);
  return v387_12;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v397_13_result;
  for (int v397_13_label = 1; v397_13_label <= 2; ++v397_13_label) {
    const Space v397_13_tail = child(s0,v397_13_label);
    if (v397_13_tail.empty()) continue;
    const Path v397_13_head{v397_13_label};
    const Space v398_2 = singleton(v397_13_head);
    const Space v398_3 = intersect(constant_3,v398_2);
    const Space v398_4 = (has_head(v398_3) ? constant_4 : Space{});
    const Space v398_5 = subtract(constant_2,v398_4);
    Space v398_8;
    if (!v398_5.empty()) {
      const Path v399_6 = concat_path(p0,v397_13_head);
      Space v399_7_result;
      for (int v399_7_label = 1; v399_7_label <= 2; ++v399_7_label) {
        const Space v399_7_tail = child(v397_13_tail,v399_7_label);
        if (v399_7_tail.empty()) continue;
        const Path v399_7_head{v399_7_label};
        const Space v400_2 = singleton(v399_7_head);
        const Space v400_3 = intersect(constant_3,v400_2);
        const Space v400_4 = (has_head(v400_3) ? constant_4 : Space{});
        const Space v400_5 = subtract(constant_2,v400_4);
        Space v400_8;
        if (!v400_5.empty()) {
          const Path v401_6 = concat_path(v399_6,v399_7_head);
          const Space v401_7 = routine_76(c, v401_6, p1, v399_7_tail, s1);
          v400_8 = compose(v400_5,v401_7);
        }
        const Space v400_9 = intersect(constant_3,v400_2);
        const Space v400_10 = (has_head(v400_9) ? constant_4 : Space{});
        Space v400_12;
        if (!v400_10.empty()) {
          const Path v402_6 = concat_path(v399_6,v399_7_head);
          const Space v402_11 = routine_77(c, v402_6, p1, v399_7_tail, s1);
          v400_12 = compose(v400_10,v402_11);
        }
        const Space v400_13 = unite(v400_8,v400_12);
        v399_7_result = unite(v399_7_result,v400_13);
      }
      const Space v399_7 = std::move(v399_7_result);
      v398_8 = compose(v398_5,v399_7);
    }
    const Space v398_9 = intersect(constant_3,v398_2);
    const Space v398_10 = (has_head(v398_9) ? constant_4 : Space{});
    Space v398_12;
    if (!v398_10.empty()) {
      const Path v403_6 = concat_path(p0,v397_13_head);
      Space v403_11_result;
      for (int v403_11_label = 1; v403_11_label <= 2; ++v403_11_label) {
        const Space v403_11_tail = child(v397_13_tail,v403_11_label);
        if (v403_11_tail.empty()) continue;
        const Path v403_11_head{v403_11_label};
        const Space v404_2 = singleton(v403_11_head);
        const Space v404_3 = intersect(constant_3,v404_2);
        const Space v404_4 = (has_head(v404_3) ? constant_4 : Space{});
        const Space v404_5 = subtract(constant_2,v404_4);
        Space v404_8;
        if (!v404_5.empty()) {
          const Path v405_6 = concat_path(v403_6,v403_11_head);
          const Space v405_7 = routine_76(c, v405_6, p1, v403_11_tail, s1);
          v404_8 = compose(v404_5,v405_7);
        }
        const Space v404_9 = intersect(constant_3,v404_2);
        const Space v404_10 = (has_head(v404_9) ? constant_4 : Space{});
        Space v404_12;
        if (!v404_10.empty()) {
          const Path v406_6 = concat_path(v403_6,v403_11_head);
          const Space v406_11 = routine_43(c, v406_6, p1, v403_11_tail, s1);
          v404_12 = compose(v404_10,v406_11);
        }
        const Space v404_13 = unite(v404_8,v404_12);
        v403_11_result = unite(v403_11_result,v404_13);
      }
      const Space v403_11 = std::move(v403_11_result);
      v398_12 = compose(v398_10,v403_11);
    }
    const Space v398_13 = unite(v398_8,v398_12);
    v397_13_result = unite(v397_13_result,v398_13);
  }
  const Space v397_13 = std::move(v397_13_result);
  return v397_13;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v407_8 = unwrap(s1,constant_0);
  const Space v407_10 = unwrap(v407_8,constant_6);
  const Space v407_11 = unwrap(v407_10,p0);
  Space v407_18_result;
  for (int v407_18_label = 1; v407_18_label <= 2; ++v407_18_label) {
    const Space v407_18_tail = child(s0,v407_18_label);
    if (v407_18_tail.empty()) continue;
    const Path v407_18_head{v407_18_label};
    const Space v408_2 = singleton(v407_18_head);
    const Space v408_3 = intersect(constant_3,v408_2);
    const Space v408_4 = (has_head(v408_3) ? constant_4 : Space{});
    const Space v408_5 = subtract(constant_2,v408_4);
    Space v408_8;
    if (!v408_5.empty()) {
      const Path v409_6 = concat_path(p0,v407_18_head);
      Space v409_7_result;
      for (int v409_7_label = 1; v409_7_label <= 2; ++v409_7_label) {
        const Space v409_7_tail = child(v407_18_tail,v409_7_label);
        if (v409_7_tail.empty()) continue;
        const Path v409_7_head{v409_7_label};
        const Space v410_2 = singleton(v409_7_head);
        const Space v410_3 = intersect(constant_3,v410_2);
        const Space v410_4 = (has_head(v410_3) ? constant_4 : Space{});
        const Space v410_5 = subtract(constant_2,v410_4);
        Space v410_8;
        if (!v410_5.empty()) {
          const Path v411_6 = concat_path(v409_6,v409_7_head);
          const Space v411_7 = routine_76(c, v411_6, p1, v409_7_tail, s1);
          v410_8 = compose(v410_5,v411_7);
        }
        const Space v410_9 = intersect(constant_3,v410_2);
        const Space v410_10 = (has_head(v410_9) ? constant_4 : Space{});
        Space v410_12;
        if (!v410_10.empty()) {
          const Path v412_6 = concat_path(v409_6,v409_7_head);
          const Space v412_11 = routine_77(c, v412_6, p1, v409_7_tail, s1);
          v410_12 = compose(v410_10,v412_11);
        }
        const Space v410_13 = unite(v410_8,v410_12);
        v409_7_result = unite(v409_7_result,v410_13);
      }
      const Space v409_7 = std::move(v409_7_result);
      v408_8 = compose(v408_5,v409_7);
    }
    const Space v408_9 = intersect(constant_3,v408_2);
    const Space v408_10 = (has_head(v408_9) ? constant_4 : Space{});
    Space v408_13;
    if (!v408_10.empty()) {
      const Space v413_11 = unwrap(v407_11,v407_18_head);
      Space v413_12_result;
      for (int v413_12_label = 1; v413_12_label <= 2; ++v413_12_label) {
        const Space v413_12_tail = child(v413_11,v413_12_label);
        if (v413_12_tail.empty()) continue;
        const Path v413_12_head{v413_12_label};
        const Space v414_2 = singleton(v413_12_head);
        const Space v414_3 = intersect(constant_3,v414_2);
        const Space v414_4 = (has_head(v414_3) ? constant_4 : Space{});
        const Space v414_5 = subtract(constant_2,v414_4);
        Space v414_7;
        if (!v414_5.empty()) {
          const Space v415_6 = routine_78(c, v413_12_head, p1, v413_12_tail);
          v414_7 = compose(v414_5,v415_6);
        }
        const Space v414_8 = intersect(constant_3,v414_2);
        const Space v414_9 = (has_head(v414_8) ? constant_4 : Space{});
        Space v414_11;
        if (!v414_9.empty()) {
          const Space v416_10 = routine_79(c, v413_12_head, p1, v413_12_tail);
          v414_11 = compose(v414_9,v416_10);
        }
        const Space v414_12 = unite(v414_7,v414_11);
        v413_12_result = unite(v413_12_result,v414_12);
      }
      const Space v413_12 = std::move(v413_12_result);
      v408_13 = compose(v408_10,v413_12);
    }
    const Space v408_14 = unite(v408_8,v408_13);
    v407_18_result = unite(v407_18_result,v408_14);
  }
  const Space v407_18 = std::move(v407_18_result);
  return v407_18;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v417_13_result;
  for (int v417_13_label = 1; v417_13_label <= 2; ++v417_13_label) {
    const Space v417_13_tail = child(s0,v417_13_label);
    if (v417_13_tail.empty()) continue;
    const Path v417_13_head{v417_13_label};
    const Space v418_2 = singleton(v417_13_head);
    const Space v418_3 = intersect(constant_3,v418_2);
    const Space v418_4 = (has_head(v418_3) ? constant_4 : Space{});
    const Space v418_5 = subtract(constant_2,v418_4);
    Space v418_8;
    if (!v418_5.empty()) {
      const Path v419_6 = concat_path(p0,v417_13_head);
      Space v419_7_result;
      for (int v419_7_label = 1; v419_7_label <= 2; ++v419_7_label) {
        const Space v419_7_tail = child(v417_13_tail,v419_7_label);
        if (v419_7_tail.empty()) continue;
        const Path v419_7_head{v419_7_label};
        const Space v420_2 = singleton(v419_7_head);
        const Space v420_3 = intersect(constant_3,v420_2);
        const Space v420_4 = (has_head(v420_3) ? constant_4 : Space{});
        const Space v420_5 = subtract(constant_2,v420_4);
        Space v420_8;
        if (!v420_5.empty()) {
          const Path v421_6 = concat_path(v419_6,v419_7_head);
          const Space v421_7 = routine_80(c, v421_6, p1, v419_7_tail, s1);
          v420_8 = compose(v420_5,v421_7);
        }
        const Space v420_9 = intersect(constant_3,v420_2);
        const Space v420_10 = (has_head(v420_9) ? constant_4 : Space{});
        Space v420_12;
        if (!v420_10.empty()) {
          const Path v422_6 = concat_path(v419_6,v419_7_head);
          const Space v422_11 = routine_81(c, v422_6, p1, v419_7_tail, s1);
          v420_12 = compose(v420_10,v422_11);
        }
        const Space v420_13 = unite(v420_8,v420_12);
        v419_7_result = unite(v419_7_result,v420_13);
      }
      const Space v419_7 = std::move(v419_7_result);
      v418_8 = compose(v418_5,v419_7);
    }
    const Space v418_9 = intersect(constant_3,v418_2);
    const Space v418_10 = (has_head(v418_9) ? constant_4 : Space{});
    Space v418_12;
    if (!v418_10.empty()) {
      const Path v423_6 = concat_path(p0,v417_13_head);
      Space v423_11_result;
      for (int v423_11_label = 1; v423_11_label <= 2; ++v423_11_label) {
        const Space v423_11_tail = child(v417_13_tail,v423_11_label);
        if (v423_11_tail.empty()) continue;
        const Path v423_11_head{v423_11_label};
        const Space v424_2 = singleton(v423_11_head);
        const Space v424_3 = intersect(constant_3,v424_2);
        const Space v424_4 = (has_head(v424_3) ? constant_4 : Space{});
        const Space v424_5 = subtract(constant_2,v424_4);
        Space v424_8;
        if (!v424_5.empty()) {
          const Path v425_6 = concat_path(v423_6,v423_11_head);
          const Space v425_7 = routine_80(c, v425_6, p1, v423_11_tail, s1);
          v424_8 = compose(v424_5,v425_7);
        }
        const Space v424_9 = intersect(constant_3,v424_2);
        const Space v424_10 = (has_head(v424_9) ? constant_4 : Space{});
        Space v424_12;
        if (!v424_10.empty()) {
          const Path v426_6 = concat_path(v423_6,v423_11_head);
          const Space v426_11 = routine_43(c, v426_6, p1, v423_11_tail, s1);
          v424_12 = compose(v424_10,v426_11);
        }
        const Space v424_13 = unite(v424_8,v424_12);
        v423_11_result = unite(v423_11_result,v424_13);
      }
      const Space v423_11 = std::move(v423_11_result);
      v418_12 = compose(v418_10,v423_11);
    }
    const Space v418_13 = unite(v418_8,v418_12);
    v417_13_result = unite(v417_13_result,v418_13);
  }
  const Space v417_13 = std::move(v417_13_result);
  return v417_13;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v427_8 = unwrap(s1,constant_0);
  const Space v427_10 = unwrap(v427_8,constant_6);
  const Space v427_11 = unwrap(v427_10,p0);
  Space v427_18_result;
  for (int v427_18_label = 1; v427_18_label <= 2; ++v427_18_label) {
    const Space v427_18_tail = child(s0,v427_18_label);
    if (v427_18_tail.empty()) continue;
    const Path v427_18_head{v427_18_label};
    const Space v428_2 = singleton(v427_18_head);
    const Space v428_3 = intersect(constant_3,v428_2);
    const Space v428_4 = (has_head(v428_3) ? constant_4 : Space{});
    const Space v428_5 = subtract(constant_2,v428_4);
    Space v428_8;
    if (!v428_5.empty()) {
      const Path v429_6 = concat_path(p0,v427_18_head);
      Space v429_7_result;
      for (int v429_7_label = 1; v429_7_label <= 2; ++v429_7_label) {
        const Space v429_7_tail = child(v427_18_tail,v429_7_label);
        if (v429_7_tail.empty()) continue;
        const Path v429_7_head{v429_7_label};
        const Space v430_2 = singleton(v429_7_head);
        const Space v430_3 = intersect(constant_3,v430_2);
        const Space v430_4 = (has_head(v430_3) ? constant_4 : Space{});
        const Space v430_5 = subtract(constant_2,v430_4);
        Space v430_8;
        if (!v430_5.empty()) {
          const Path v431_6 = concat_path(v429_6,v429_7_head);
          const Space v431_7 = routine_80(c, v431_6, p1, v429_7_tail, s1);
          v430_8 = compose(v430_5,v431_7);
        }
        const Space v430_9 = intersect(constant_3,v430_2);
        const Space v430_10 = (has_head(v430_9) ? constant_4 : Space{});
        Space v430_12;
        if (!v430_10.empty()) {
          const Path v432_6 = concat_path(v429_6,v429_7_head);
          const Space v432_11 = routine_81(c, v432_6, p1, v429_7_tail, s1);
          v430_12 = compose(v430_10,v432_11);
        }
        const Space v430_13 = unite(v430_8,v430_12);
        v429_7_result = unite(v429_7_result,v430_13);
      }
      const Space v429_7 = std::move(v429_7_result);
      v428_8 = compose(v428_5,v429_7);
    }
    const Space v428_9 = intersect(constant_3,v428_2);
    const Space v428_10 = (has_head(v428_9) ? constant_4 : Space{});
    Space v428_13;
    if (!v428_10.empty()) {
      const Space v433_11 = unwrap(v427_11,v427_18_head);
      Space v433_12_result;
      for (int v433_12_label = 1; v433_12_label <= 2; ++v433_12_label) {
        const Space v433_12_tail = child(v433_11,v433_12_label);
        if (v433_12_tail.empty()) continue;
        const Path v433_12_head{v433_12_label};
        const Space v434_2 = singleton(v433_12_head);
        const Space v434_3 = intersect(constant_3,v434_2);
        const Space v434_4 = (has_head(v434_3) ? constant_4 : Space{});
        const Space v434_5 = subtract(constant_2,v434_4);
        Space v434_7;
        if (!v434_5.empty()) {
          const Space v435_6 = routine_78(c, v433_12_head, p1, v433_12_tail);
          v434_7 = compose(v434_5,v435_6);
        }
        const Space v434_8 = intersect(constant_3,v434_2);
        const Space v434_9 = (has_head(v434_8) ? constant_4 : Space{});
        Space v434_11;
        if (!v434_9.empty()) {
          const Space v436_10 = routine_79(c, v433_12_head, p1, v433_12_tail);
          v434_11 = compose(v434_9,v436_10);
        }
        const Space v434_12 = unite(v434_7,v434_11);
        v433_12_result = unite(v433_12_result,v434_12);
      }
      const Space v433_12 = std::move(v433_12_result);
      v428_13 = compose(v428_10,v433_12);
    }
    const Space v428_14 = unite(v428_8,v428_13);
    v427_18_result = unite(v427_18_result,v428_14);
  }
  const Space v427_18 = std::move(v427_18_result);
  return v427_18;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v437_5 = unwrap(s1,constant_0);
  const Space v437_7 = unwrap(v437_5,constant_6);
  const Space v437_8 = unwrap(v437_7,p0);
  Space v437_18_result;
  for (int v437_18_label = 1; v437_18_label <= 2; ++v437_18_label) {
    const Space v437_18_tail = child(v437_8,v437_18_label);
    if (v437_18_tail.empty()) continue;
    const Path v437_18_head{v437_18_label};
    const Space v438_2 = singleton(v437_18_head);
    const Space v438_3 = intersect(constant_3,v438_2);
    const Space v438_4 = (has_head(v438_3) ? constant_4 : Space{});
    const Space v438_5 = subtract(constant_2,v438_4);
    Space v438_7;
    if (!v438_5.empty()) {
      Space v439_6_result;
      for (int v439_6_label = 1; v439_6_label <= 2; ++v439_6_label) {
        const Space v439_6_tail = child(v437_18_tail,v439_6_label);
        if (v439_6_tail.empty()) continue;
        const Path v439_6_head{v439_6_label};
        const Space v440_2 = singleton(v439_6_head);
        const Space v440_3 = intersect(constant_3,v440_2);
        const Space v440_4 = (has_head(v440_3) ? constant_4 : Space{});
        const Space v440_5 = subtract(constant_2,v440_4);
        Space v440_8;
        if (!v440_5.empty()) {
          const Path v441_6 = concat_path(v437_18_head,v439_6_head);
          const Space v441_7 = routine_82(c, v441_6, p1, v439_6_tail);
          v440_8 = compose(v440_5,v441_7);
        }
        const Space v440_9 = intersect(constant_3,v440_2);
        const Space v440_10 = (has_head(v440_9) ? constant_4 : Space{});
        Space v440_12;
        if (!v440_10.empty()) {
          const Path v442_6 = concat_path(v437_18_head,v439_6_head);
          const Space v442_11 = routine_83(c, v442_6, p1, v439_6_tail);
          v440_12 = compose(v440_10,v442_11);
        }
        const Space v440_13 = unite(v440_8,v440_12);
        v439_6_result = unite(v439_6_result,v440_13);
      }
      const Space v439_6 = std::move(v439_6_result);
      v438_7 = compose(v438_5,v439_6);
    }
    const Space v438_8 = intersect(constant_3,v438_2);
    const Space v438_9 = (has_head(v438_8) ? constant_4 : Space{});
    Space v438_11;
    if (!v438_9.empty()) {
      Space v443_10_result;
      for (int v443_10_label = 1; v443_10_label <= 2; ++v443_10_label) {
        const Space v443_10_tail = child(v437_18_tail,v443_10_label);
        if (v443_10_tail.empty()) continue;
        const Path v443_10_head{v443_10_label};
        const Space v444_2 = singleton(v443_10_head);
        const Space v444_3 = intersect(constant_3,v444_2);
        const Space v444_4 = (has_head(v444_3) ? constant_4 : Space{});
        const Space v444_5 = subtract(constant_2,v444_4);
        Space v444_8;
        if (!v444_5.empty()) {
          const Path v445_6 = concat_path(v437_18_head,v443_10_head);
          const Space v445_7 = routine_82(c, v445_6, p1, v443_10_tail);
          v444_8 = compose(v444_5,v445_7);
        }
        const Space v444_9 = intersect(constant_3,v444_2);
        const Space v444_10 = (has_head(v444_9) ? constant_4 : Space{});
        Space v444_12;
        if (!v444_10.empty()) {
          const Path v446_6 = concat_path(v437_18_head,v443_10_head);
          const Space v446_11 = routine_84(c, v446_6, p1, v443_10_tail);
          v444_12 = compose(v444_10,v446_11);
        }
        const Space v444_13 = unite(v444_8,v444_12);
        v443_10_result = unite(v443_10_result,v444_13);
      }
      const Space v443_10 = std::move(v443_10_result);
      v438_11 = compose(v438_9,v443_10);
    }
    const Space v438_12 = unite(v438_7,v438_11);
    v437_18_result = unite(v437_18_result,v438_12);
  }
  const Space v437_18 = std::move(v437_18_result);
  return v437_18;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v447_12_result;
  for (int v447_12_label = 1; v447_12_label <= 2; ++v447_12_label) {
    const Space v447_12_tail = child(s0,v447_12_label);
    if (v447_12_tail.empty()) continue;
    const Path v447_12_head{v447_12_label};
    const Space v448_2 = singleton(v447_12_head);
    const Space v448_3 = intersect(constant_3,v448_2);
    const Space v448_4 = (has_head(v448_3) ? constant_4 : Space{});
    const Space v448_5 = subtract(constant_2,v448_4);
    Space v448_8;
    if (!v448_5.empty()) {
      const Path v449_6 = concat_path(p0,v447_12_head);
      Space v449_7_result;
      for (int v449_7_label = 1; v449_7_label <= 2; ++v449_7_label) {
        const Space v449_7_tail = child(v447_12_tail,v449_7_label);
        if (v449_7_tail.empty()) continue;
        const Path v449_7_head{v449_7_label};
        const Space v450_2 = singleton(v449_7_head);
        const Space v450_3 = intersect(constant_3,v450_2);
        const Space v450_4 = (has_head(v450_3) ? constant_4 : Space{});
        const Space v450_5 = subtract(constant_2,v450_4);
        Space v450_8;
        if (!v450_5.empty()) {
          const Path v451_6 = concat_path(v449_6,v449_7_head);
          const Space v451_7 = routine_85(c, v451_6, v449_7_tail, s1);
          v450_8 = compose(v450_5,v451_7);
        }
        const Space v450_9 = intersect(constant_3,v450_2);
        const Space v450_10 = (has_head(v450_9) ? constant_4 : Space{});
        Space v450_12;
        if (!v450_10.empty()) {
          const Path v452_6 = concat_path(v449_6,v449_7_head);
          const Space v452_11 = routine_86(c, v452_6, v449_7_tail, s1);
          v450_12 = compose(v450_10,v452_11);
        }
        const Space v450_13 = unite(v450_8,v450_12);
        v449_7_result = unite(v449_7_result,v450_13);
      }
      const Space v449_7 = std::move(v449_7_result);
      v448_8 = compose(v448_5,v449_7);
    }
    const Space v448_9 = intersect(constant_3,v448_2);
    const Space v448_10 = (has_head(v448_9) ? constant_4 : Space{});
    Space v448_12;
    if (!v448_10.empty()) {
      const Path v453_6 = concat_path(p0,v447_12_head);
      Space v453_11_result;
      for (int v453_11_label = 1; v453_11_label <= 2; ++v453_11_label) {
        const Space v453_11_tail = child(v447_12_tail,v453_11_label);
        if (v453_11_tail.empty()) continue;
        const Path v453_11_head{v453_11_label};
        const Space v454_2 = singleton(v453_11_head);
        const Space v454_3 = intersect(constant_3,v454_2);
        const Space v454_4 = (has_head(v454_3) ? constant_4 : Space{});
        const Space v454_5 = subtract(constant_2,v454_4);
        Space v454_8;
        if (!v454_5.empty()) {
          const Path v455_6 = concat_path(v453_6,v453_11_head);
          const Space v455_7 = routine_85(c, v455_6, v453_11_tail, s1);
          v454_8 = compose(v454_5,v455_7);
        }
        const Space v454_9 = intersect(constant_3,v454_2);
        const Space v454_10 = (has_head(v454_9) ? constant_4 : Space{});
        Space v454_12;
        if (!v454_10.empty()) {
          const Path v456_6 = concat_path(v453_6,v453_11_head);
          const Space v456_11 = routine_15(c, v456_6, v453_11_tail, s1);
          v454_12 = compose(v454_10,v456_11);
        }
        const Space v454_13 = unite(v454_8,v454_12);
        v453_11_result = unite(v453_11_result,v454_13);
      }
      const Space v453_11 = std::move(v453_11_result);
      v448_12 = compose(v448_10,v453_11);
    }
    const Space v448_13 = unite(v448_8,v448_12);
    v447_12_result = unite(v447_12_result,v448_13);
  }
  const Space v447_12 = std::move(v447_12_result);
  return v447_12;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v457_12_result;
  for (int v457_12_label = 1; v457_12_label <= 2; ++v457_12_label) {
    const Space v457_12_tail = child(s0,v457_12_label);
    if (v457_12_tail.empty()) continue;
    const Path v457_12_head{v457_12_label};
    const Space v458_2 = singleton(v457_12_head);
    const Space v458_3 = intersect(constant_3,v458_2);
    const Space v458_4 = (has_head(v458_3) ? constant_4 : Space{});
    const Space v458_5 = subtract(constant_2,v458_4);
    Space v458_8;
    if (!v458_5.empty()) {
      const Path v459_6 = concat_path(p0,v457_12_head);
      Space v459_7_result;
      for (int v459_7_label = 1; v459_7_label <= 2; ++v459_7_label) {
        const Space v459_7_tail = child(v457_12_tail,v459_7_label);
        if (v459_7_tail.empty()) continue;
        const Path v459_7_head{v459_7_label};
        const Space v460_2 = singleton(v459_7_head);
        const Space v460_3 = intersect(constant_3,v460_2);
        const Space v460_4 = (has_head(v460_3) ? constant_4 : Space{});
        const Space v460_5 = subtract(constant_2,v460_4);
        Space v460_8;
        if (!v460_5.empty()) {
          const Path v461_6 = concat_path(v459_6,v459_7_head);
          const Space v461_7 = routine_85(c, v461_6, v459_7_tail, s1);
          v460_8 = compose(v460_5,v461_7);
        }
        const Space v460_9 = intersect(constant_3,v460_2);
        const Space v460_10 = (has_head(v460_9) ? constant_4 : Space{});
        Space v460_12;
        if (!v460_10.empty()) {
          const Path v462_6 = concat_path(v459_6,v459_7_head);
          const Space v462_11 = routine_86(c, v462_6, v459_7_tail, s1);
          v460_12 = compose(v460_10,v462_11);
        }
        const Space v460_13 = unite(v460_8,v460_12);
        v459_7_result = unite(v459_7_result,v460_13);
      }
      const Space v459_7 = std::move(v459_7_result);
      v458_8 = compose(v458_5,v459_7);
    }
    const Space v458_9 = intersect(constant_3,v458_2);
    const Space v458_10 = (has_head(v458_9) ? constant_4 : Space{});
    Space v458_12;
    if (!v458_10.empty()) {
      const Path v463_6 = concat_path(p0,v457_12_head);
      Space v463_11_result;
      for (int v463_11_label = 1; v463_11_label <= 2; ++v463_11_label) {
        const Space v463_11_tail = child(v457_12_tail,v463_11_label);
        if (v463_11_tail.empty()) continue;
        const Path v463_11_head{v463_11_label};
        const Space v464_2 = singleton(v463_11_head);
        const Space v464_3 = intersect(constant_3,v464_2);
        const Space v464_4 = (has_head(v464_3) ? constant_4 : Space{});
        const Space v464_5 = subtract(constant_2,v464_4);
        Space v464_7;
        if (!v464_5.empty()) {
          const Space v465_6 = routine_46(c, v463_11_head, v463_6, v463_11_tail, s1);
          v464_7 = compose(v464_5,v465_6);
        }
        const Space v464_8 = intersect(constant_3,v464_2);
        const Space v464_9 = (has_head(v464_8) ? constant_4 : Space{});
        Space v464_11;
        if (!v464_9.empty()) {
          const Space v466_10 = routine_47(c, v463_11_head, v463_6, v463_11_tail, s1);
          v464_11 = compose(v464_9,v466_10);
        }
        const Space v464_12 = unite(v464_7,v464_11);
        v463_11_result = unite(v463_11_result,v464_12);
      }
      const Space v463_11 = std::move(v463_11_result);
      v458_12 = compose(v458_10,v463_11);
    }
    const Space v458_13 = unite(v458_8,v458_12);
    v457_12_result = unite(v457_12_result,v458_13);
  }
  const Space v457_12 = std::move(v457_12_result);
  return v457_12;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v467_13_result;
  for (int v467_13_label = 1; v467_13_label <= 2; ++v467_13_label) {
    const Space v467_13_tail = child(s0,v467_13_label);
    if (v467_13_tail.empty()) continue;
    const Path v467_13_head{v467_13_label};
    const Space v468_2 = singleton(v467_13_head);
    const Space v468_3 = intersect(constant_3,v468_2);
    const Space v468_4 = (has_head(v468_3) ? constant_4 : Space{});
    const Space v468_5 = subtract(constant_2,v468_4);
    Space v468_8;
    if (!v468_5.empty()) {
      const Path v469_6 = concat_path(p0,v467_13_head);
      Space v469_7_result;
      for (int v469_7_label = 1; v469_7_label <= 2; ++v469_7_label) {
        const Space v469_7_tail = child(v467_13_tail,v469_7_label);
        if (v469_7_tail.empty()) continue;
        const Path v469_7_head{v469_7_label};
        const Space v470_2 = singleton(v469_7_head);
        const Space v470_3 = intersect(constant_3,v470_2);
        const Space v470_4 = (has_head(v470_3) ? constant_4 : Space{});
        const Space v470_5 = subtract(constant_2,v470_4);
        Space v470_8;
        if (!v470_5.empty()) {
          const Path v471_6 = concat_path(v469_6,v469_7_head);
          const Space v471_7 = routine_87(c, v471_6, p1, v469_7_tail, s1);
          v470_8 = compose(v470_5,v471_7);
        }
        const Space v470_9 = intersect(constant_3,v470_2);
        const Space v470_10 = (has_head(v470_9) ? constant_4 : Space{});
        Space v470_12;
        if (!v470_10.empty()) {
          const Path v472_6 = concat_path(v469_6,v469_7_head);
          const Space v472_11 = routine_88(c, v472_6, p1, v469_7_tail, s1);
          v470_12 = compose(v470_10,v472_11);
        }
        const Space v470_13 = unite(v470_8,v470_12);
        v469_7_result = unite(v469_7_result,v470_13);
      }
      const Space v469_7 = std::move(v469_7_result);
      v468_8 = compose(v468_5,v469_7);
    }
    const Space v468_9 = intersect(constant_3,v468_2);
    const Space v468_10 = (has_head(v468_9) ? constant_4 : Space{});
    Space v468_12;
    if (!v468_10.empty()) {
      const Path v473_6 = concat_path(p0,v467_13_head);
      Space v473_11_result;
      for (int v473_11_label = 1; v473_11_label <= 2; ++v473_11_label) {
        const Space v473_11_tail = child(v467_13_tail,v473_11_label);
        if (v473_11_tail.empty()) continue;
        const Path v473_11_head{v473_11_label};
        const Space v474_2 = singleton(v473_11_head);
        const Space v474_3 = intersect(constant_3,v474_2);
        const Space v474_4 = (has_head(v474_3) ? constant_4 : Space{});
        const Space v474_5 = subtract(constant_2,v474_4);
        Space v474_8;
        if (!v474_5.empty()) {
          const Path v475_6 = concat_path(v473_6,v473_11_head);
          const Space v475_7 = routine_87(c, v475_6, p1, v473_11_tail, s1);
          v474_8 = compose(v474_5,v475_7);
        }
        const Space v474_9 = intersect(constant_3,v474_2);
        const Space v474_10 = (has_head(v474_9) ? constant_4 : Space{});
        Space v474_12;
        if (!v474_10.empty()) {
          const Path v476_6 = concat_path(v473_6,v473_11_head);
          const Space v476_11 = routine_50(c, v476_6, p1, v473_11_tail, s1);
          v474_12 = compose(v474_10,v476_11);
        }
        const Space v474_13 = unite(v474_8,v474_12);
        v473_11_result = unite(v473_11_result,v474_13);
      }
      const Space v473_11 = std::move(v473_11_result);
      v468_12 = compose(v468_10,v473_11);
    }
    const Space v468_13 = unite(v468_8,v468_12);
    v467_13_result = unite(v467_13_result,v468_13);
  }
  const Space v467_13 = std::move(v467_13_result);
  return v467_13;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v477_8 = unwrap(s1,constant_5);
  const Space v477_10 = unwrap(v477_8,constant_6);
  const Space v477_11 = unwrap(v477_10,p0);
  Space v477_18_result;
  for (int v477_18_label = 1; v477_18_label <= 2; ++v477_18_label) {
    const Space v477_18_tail = child(s0,v477_18_label);
    if (v477_18_tail.empty()) continue;
    const Path v477_18_head{v477_18_label};
    const Space v478_2 = singleton(v477_18_head);
    const Space v478_3 = intersect(constant_3,v478_2);
    const Space v478_4 = (has_head(v478_3) ? constant_4 : Space{});
    const Space v478_5 = subtract(constant_2,v478_4);
    Space v478_8;
    if (!v478_5.empty()) {
      const Path v479_6 = concat_path(p0,v477_18_head);
      Space v479_7_result;
      for (int v479_7_label = 1; v479_7_label <= 2; ++v479_7_label) {
        const Space v479_7_tail = child(v477_18_tail,v479_7_label);
        if (v479_7_tail.empty()) continue;
        const Path v479_7_head{v479_7_label};
        const Space v480_2 = singleton(v479_7_head);
        const Space v480_3 = intersect(constant_3,v480_2);
        const Space v480_4 = (has_head(v480_3) ? constant_4 : Space{});
        const Space v480_5 = subtract(constant_2,v480_4);
        Space v480_8;
        if (!v480_5.empty()) {
          const Path v481_6 = concat_path(v479_6,v479_7_head);
          const Space v481_7 = routine_87(c, v481_6, p1, v479_7_tail, s1);
          v480_8 = compose(v480_5,v481_7);
        }
        const Space v480_9 = intersect(constant_3,v480_2);
        const Space v480_10 = (has_head(v480_9) ? constant_4 : Space{});
        Space v480_12;
        if (!v480_10.empty()) {
          const Path v482_6 = concat_path(v479_6,v479_7_head);
          const Space v482_11 = routine_88(c, v482_6, p1, v479_7_tail, s1);
          v480_12 = compose(v480_10,v482_11);
        }
        const Space v480_13 = unite(v480_8,v480_12);
        v479_7_result = unite(v479_7_result,v480_13);
      }
      const Space v479_7 = std::move(v479_7_result);
      v478_8 = compose(v478_5,v479_7);
    }
    const Space v478_9 = intersect(constant_3,v478_2);
    const Space v478_10 = (has_head(v478_9) ? constant_4 : Space{});
    Space v478_13;
    if (!v478_10.empty()) {
      const Space v483_11 = unwrap(v477_11,v477_18_head);
      Space v483_12_result;
      for (int v483_12_label = 1; v483_12_label <= 2; ++v483_12_label) {
        const Space v483_12_tail = child(v483_11,v483_12_label);
        if (v483_12_tail.empty()) continue;
        const Path v483_12_head{v483_12_label};
        const Space v484_2 = singleton(v483_12_head);
        const Space v484_3 = intersect(constant_3,v484_2);
        const Space v484_4 = (has_head(v484_3) ? constant_4 : Space{});
        const Space v484_5 = subtract(constant_2,v484_4);
        Space v484_7;
        if (!v484_5.empty()) {
          const Space v485_6 = routine_89(c, v483_12_head, p1, v483_12_tail);
          v484_7 = compose(v484_5,v485_6);
        }
        const Space v484_8 = intersect(constant_3,v484_2);
        const Space v484_9 = (has_head(v484_8) ? constant_4 : Space{});
        Space v484_11;
        if (!v484_9.empty()) {
          const Space v486_10 = routine_90(c, v483_12_head, p1, v483_12_tail);
          v484_11 = compose(v484_9,v486_10);
        }
        const Space v484_12 = unite(v484_7,v484_11);
        v483_12_result = unite(v483_12_result,v484_12);
      }
      const Space v483_12 = std::move(v483_12_result);
      v478_13 = compose(v478_10,v483_12);
    }
    const Space v478_14 = unite(v478_8,v478_13);
    v477_18_result = unite(v477_18_result,v478_14);
  }
  const Space v477_18 = std::move(v477_18_result);
  return v477_18;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v487_13_result;
  for (int v487_13_label = 1; v487_13_label <= 2; ++v487_13_label) {
    const Space v487_13_tail = child(s0,v487_13_label);
    if (v487_13_tail.empty()) continue;
    const Path v487_13_head{v487_13_label};
    const Space v488_2 = singleton(v487_13_head);
    const Space v488_3 = intersect(constant_3,v488_2);
    const Space v488_4 = (has_head(v488_3) ? constant_4 : Space{});
    const Space v488_5 = subtract(constant_2,v488_4);
    Space v488_8;
    if (!v488_5.empty()) {
      const Path v489_6 = concat_path(p0,v487_13_head);
      Space v489_7_result;
      for (int v489_7_label = 1; v489_7_label <= 2; ++v489_7_label) {
        const Space v489_7_tail = child(v487_13_tail,v489_7_label);
        if (v489_7_tail.empty()) continue;
        const Path v489_7_head{v489_7_label};
        const Space v490_2 = singleton(v489_7_head);
        const Space v490_3 = intersect(constant_3,v490_2);
        const Space v490_4 = (has_head(v490_3) ? constant_4 : Space{});
        const Space v490_5 = subtract(constant_2,v490_4);
        Space v490_8;
        if (!v490_5.empty()) {
          const Path v491_6 = concat_path(v489_6,v489_7_head);
          const Space v491_7 = routine_91(c, v491_6, p1, v489_7_tail, s1);
          v490_8 = compose(v490_5,v491_7);
        }
        const Space v490_9 = intersect(constant_3,v490_2);
        const Space v490_10 = (has_head(v490_9) ? constant_4 : Space{});
        Space v490_12;
        if (!v490_10.empty()) {
          const Path v492_6 = concat_path(v489_6,v489_7_head);
          const Space v492_11 = routine_92(c, v492_6, p1, v489_7_tail, s1);
          v490_12 = compose(v490_10,v492_11);
        }
        const Space v490_13 = unite(v490_8,v490_12);
        v489_7_result = unite(v489_7_result,v490_13);
      }
      const Space v489_7 = std::move(v489_7_result);
      v488_8 = compose(v488_5,v489_7);
    }
    const Space v488_9 = intersect(constant_3,v488_2);
    const Space v488_10 = (has_head(v488_9) ? constant_4 : Space{});
    Space v488_12;
    if (!v488_10.empty()) {
      const Path v493_6 = concat_path(p0,v487_13_head);
      Space v493_11_result;
      for (int v493_11_label = 1; v493_11_label <= 2; ++v493_11_label) {
        const Space v493_11_tail = child(v487_13_tail,v493_11_label);
        if (v493_11_tail.empty()) continue;
        const Path v493_11_head{v493_11_label};
        const Space v494_2 = singleton(v493_11_head);
        const Space v494_3 = intersect(constant_3,v494_2);
        const Space v494_4 = (has_head(v494_3) ? constant_4 : Space{});
        const Space v494_5 = subtract(constant_2,v494_4);
        Space v494_8;
        if (!v494_5.empty()) {
          const Path v495_6 = concat_path(v493_6,v493_11_head);
          const Space v495_7 = routine_91(c, v495_6, p1, v493_11_tail, s1);
          v494_8 = compose(v494_5,v495_7);
        }
        const Space v494_9 = intersect(constant_3,v494_2);
        const Space v494_10 = (has_head(v494_9) ? constant_4 : Space{});
        Space v494_12;
        if (!v494_10.empty()) {
          const Path v496_6 = concat_path(v493_6,v493_11_head);
          const Space v496_11 = routine_50(c, v496_6, p1, v493_11_tail, s1);
          v494_12 = compose(v494_10,v496_11);
        }
        const Space v494_13 = unite(v494_8,v494_12);
        v493_11_result = unite(v493_11_result,v494_13);
      }
      const Space v493_11 = std::move(v493_11_result);
      v488_12 = compose(v488_10,v493_11);
    }
    const Space v488_13 = unite(v488_8,v488_12);
    v487_13_result = unite(v487_13_result,v488_13);
  }
  const Space v487_13 = std::move(v487_13_result);
  return v487_13;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v497_8 = unwrap(s1,constant_5);
  const Space v497_10 = unwrap(v497_8,constant_6);
  const Space v497_11 = unwrap(v497_10,p0);
  Space v497_18_result;
  for (int v497_18_label = 1; v497_18_label <= 2; ++v497_18_label) {
    const Space v497_18_tail = child(s0,v497_18_label);
    if (v497_18_tail.empty()) continue;
    const Path v497_18_head{v497_18_label};
    const Space v498_2 = singleton(v497_18_head);
    const Space v498_3 = intersect(constant_3,v498_2);
    const Space v498_4 = (has_head(v498_3) ? constant_4 : Space{});
    const Space v498_5 = subtract(constant_2,v498_4);
    Space v498_8;
    if (!v498_5.empty()) {
      const Path v499_6 = concat_path(p0,v497_18_head);
      Space v499_7_result;
      for (int v499_7_label = 1; v499_7_label <= 2; ++v499_7_label) {
        const Space v499_7_tail = child(v497_18_tail,v499_7_label);
        if (v499_7_tail.empty()) continue;
        const Path v499_7_head{v499_7_label};
        const Space v500_2 = singleton(v499_7_head);
        const Space v500_3 = intersect(constant_3,v500_2);
        const Space v500_4 = (has_head(v500_3) ? constant_4 : Space{});
        const Space v500_5 = subtract(constant_2,v500_4);
        Space v500_8;
        if (!v500_5.empty()) {
          const Path v501_6 = concat_path(v499_6,v499_7_head);
          const Space v501_7 = routine_91(c, v501_6, p1, v499_7_tail, s1);
          v500_8 = compose(v500_5,v501_7);
        }
        const Space v500_9 = intersect(constant_3,v500_2);
        const Space v500_10 = (has_head(v500_9) ? constant_4 : Space{});
        Space v500_12;
        if (!v500_10.empty()) {
          const Path v502_6 = concat_path(v499_6,v499_7_head);
          const Space v502_11 = routine_92(c, v502_6, p1, v499_7_tail, s1);
          v500_12 = compose(v500_10,v502_11);
        }
        const Space v500_13 = unite(v500_8,v500_12);
        v499_7_result = unite(v499_7_result,v500_13);
      }
      const Space v499_7 = std::move(v499_7_result);
      v498_8 = compose(v498_5,v499_7);
    }
    const Space v498_9 = intersect(constant_3,v498_2);
    const Space v498_10 = (has_head(v498_9) ? constant_4 : Space{});
    Space v498_13;
    if (!v498_10.empty()) {
      const Space v503_11 = unwrap(v497_11,v497_18_head);
      Space v503_12_result;
      for (int v503_12_label = 1; v503_12_label <= 2; ++v503_12_label) {
        const Space v503_12_tail = child(v503_11,v503_12_label);
        if (v503_12_tail.empty()) continue;
        const Path v503_12_head{v503_12_label};
        const Space v504_2 = singleton(v503_12_head);
        const Space v504_3 = intersect(constant_3,v504_2);
        const Space v504_4 = (has_head(v504_3) ? constant_4 : Space{});
        const Space v504_5 = subtract(constant_2,v504_4);
        Space v504_7;
        if (!v504_5.empty()) {
          const Space v505_6 = routine_89(c, v503_12_head, p1, v503_12_tail);
          v504_7 = compose(v504_5,v505_6);
        }
        const Space v504_8 = intersect(constant_3,v504_2);
        const Space v504_9 = (has_head(v504_8) ? constant_4 : Space{});
        Space v504_11;
        if (!v504_9.empty()) {
          const Space v506_10 = routine_90(c, v503_12_head, p1, v503_12_tail);
          v504_11 = compose(v504_9,v506_10);
        }
        const Space v504_12 = unite(v504_7,v504_11);
        v503_12_result = unite(v503_12_result,v504_12);
      }
      const Space v503_12 = std::move(v503_12_result);
      v498_13 = compose(v498_10,v503_12);
    }
    const Space v498_14 = unite(v498_8,v498_13);
    v497_18_result = unite(v497_18_result,v498_14);
  }
  const Space v497_18 = std::move(v497_18_result);
  return v497_18;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v507_5 = unwrap(s1,constant_5);
  const Space v507_7 = unwrap(v507_5,constant_6);
  const Space v507_8 = unwrap(v507_7,p0);
  Space v507_18_result;
  for (int v507_18_label = 1; v507_18_label <= 2; ++v507_18_label) {
    const Space v507_18_tail = child(v507_8,v507_18_label);
    if (v507_18_tail.empty()) continue;
    const Path v507_18_head{v507_18_label};
    const Space v508_2 = singleton(v507_18_head);
    const Space v508_3 = intersect(constant_3,v508_2);
    const Space v508_4 = (has_head(v508_3) ? constant_4 : Space{});
    const Space v508_5 = subtract(constant_2,v508_4);
    Space v508_7;
    if (!v508_5.empty()) {
      Space v509_6_result;
      for (int v509_6_label = 1; v509_6_label <= 2; ++v509_6_label) {
        const Space v509_6_tail = child(v507_18_tail,v509_6_label);
        if (v509_6_tail.empty()) continue;
        const Path v509_6_head{v509_6_label};
        const Space v510_2 = singleton(v509_6_head);
        const Space v510_3 = intersect(constant_3,v510_2);
        const Space v510_4 = (has_head(v510_3) ? constant_4 : Space{});
        const Space v510_5 = subtract(constant_2,v510_4);
        Space v510_8;
        if (!v510_5.empty()) {
          const Path v511_6 = concat_path(v507_18_head,v509_6_head);
          const Space v511_7 = routine_93(c, v511_6, p1, v509_6_tail);
          v510_8 = compose(v510_5,v511_7);
        }
        const Space v510_9 = intersect(constant_3,v510_2);
        const Space v510_10 = (has_head(v510_9) ? constant_4 : Space{});
        Space v510_12;
        if (!v510_10.empty()) {
          const Path v512_6 = concat_path(v507_18_head,v509_6_head);
          const Space v512_11 = routine_94(c, v512_6, p1, v509_6_tail);
          v510_12 = compose(v510_10,v512_11);
        }
        const Space v510_13 = unite(v510_8,v510_12);
        v509_6_result = unite(v509_6_result,v510_13);
      }
      const Space v509_6 = std::move(v509_6_result);
      v508_7 = compose(v508_5,v509_6);
    }
    const Space v508_8 = intersect(constant_3,v508_2);
    const Space v508_9 = (has_head(v508_8) ? constant_4 : Space{});
    Space v508_11;
    if (!v508_9.empty()) {
      Space v513_10_result;
      for (int v513_10_label = 1; v513_10_label <= 2; ++v513_10_label) {
        const Space v513_10_tail = child(v507_18_tail,v513_10_label);
        if (v513_10_tail.empty()) continue;
        const Path v513_10_head{v513_10_label};
        const Space v514_2 = singleton(v513_10_head);
        const Space v514_3 = intersect(constant_3,v514_2);
        const Space v514_4 = (has_head(v514_3) ? constant_4 : Space{});
        const Space v514_5 = subtract(constant_2,v514_4);
        Space v514_8;
        if (!v514_5.empty()) {
          const Path v515_6 = concat_path(v507_18_head,v513_10_head);
          const Space v515_7 = routine_93(c, v515_6, p1, v513_10_tail);
          v514_8 = compose(v514_5,v515_7);
        }
        const Space v514_9 = intersect(constant_3,v514_2);
        const Space v514_10 = (has_head(v514_9) ? constant_4 : Space{});
        Space v514_12;
        if (!v514_10.empty()) {
          const Path v516_6 = concat_path(v507_18_head,v513_10_head);
          const Space v516_11 = routine_95(c, v516_6, p1, v513_10_tail);
          v514_12 = compose(v514_10,v516_11);
        }
        const Space v514_13 = unite(v514_8,v514_12);
        v513_10_result = unite(v513_10_result,v514_13);
      }
      const Space v513_10 = std::move(v513_10_result);
      v508_11 = compose(v508_9,v513_10);
    }
    const Space v508_12 = unite(v508_7,v508_11);
    v507_18_result = unite(v507_18_result,v508_12);
  }
  const Space v507_18 = std::move(v507_18_result);
  return v507_18;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v517_11_result;
  for (int v517_11_label = 1; v517_11_label <= 2; ++v517_11_label) {
    const Space v517_11_tail = child(s0,v517_11_label);
    if (v517_11_tail.empty()) continue;
    const Path v517_11_head{v517_11_label};
    const Space v518_2 = singleton(v517_11_head);
    const Space v518_3 = intersect(constant_3,v518_2);
    const Space v518_4 = (has_head(v518_3) ? constant_4 : Space{});
    const Space v518_5 = subtract(constant_2,v518_4);
    Space v518_8;
    if (!v518_5.empty()) {
      const Path v519_6 = concat_path(p0,v517_11_head);
      Space v519_7_result;
      for (int v519_7_label = 1; v519_7_label <= 2; ++v519_7_label) {
        const Space v519_7_tail = child(v517_11_tail,v519_7_label);
        if (v519_7_tail.empty()) continue;
        const Path v519_7_head{v519_7_label};
        const Space v520_2 = singleton(v519_7_head);
        const Space v520_3 = intersect(constant_3,v520_2);
        const Space v520_4 = (has_head(v520_3) ? constant_4 : Space{});
        const Space v520_5 = subtract(constant_2,v520_4);
        Space v520_8;
        if (!v520_5.empty()) {
          const Path v521_6 = concat_path(v519_6,v519_7_head);
          const Space v521_7 = routine_96(c, v521_6, v519_7_tail);
          v520_8 = compose(v520_5,v521_7);
        }
        const Space v520_9 = intersect(constant_3,v520_2);
        const Space v520_10 = (has_head(v520_9) ? constant_4 : Space{});
        Space v520_12;
        if (!v520_10.empty()) {
          const Path v522_6 = concat_path(v519_6,v519_7_head);
          const Space v522_11 = routine_97(c, v522_6, v519_7_tail);
          v520_12 = compose(v520_10,v522_11);
        }
        const Space v520_13 = unite(v520_8,v520_12);
        v519_7_result = unite(v519_7_result,v520_13);
      }
      const Space v519_7 = std::move(v519_7_result);
      v518_8 = compose(v518_5,v519_7);
    }
    const Space v518_9 = intersect(constant_3,v518_2);
    const Space v518_10 = (has_head(v518_9) ? constant_4 : Space{});
    Space v518_12;
    if (!v518_10.empty()) {
      const Path v523_6 = concat_path(p0,v517_11_head);
      Space v523_11_result;
      for (int v523_11_label = 1; v523_11_label <= 2; ++v523_11_label) {
        const Space v523_11_tail = child(v517_11_tail,v523_11_label);
        if (v523_11_tail.empty()) continue;
        const Path v523_11_head{v523_11_label};
        const Space v524_2 = singleton(v523_11_head);
        const Space v524_3 = intersect(constant_3,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_4 : Space{});
        const Space v524_5 = subtract(constant_2,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v523_6,v523_11_head);
          const Space v525_7 = routine_96(c, v525_6, v523_11_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_3,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_4 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v523_6,v523_11_head);
          const Space v526_11 = routine_3(c, v526_6, v523_11_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_11_result = unite(v523_11_result,v524_13);
      }
      const Space v523_11 = std::move(v523_11_result);
      v518_12 = compose(v518_10,v523_11);
    }
    const Space v518_13 = unite(v518_8,v518_12);
    v517_11_result = unite(v517_11_result,v518_13);
  }
  const Space v517_11 = std::move(v517_11_result);
  return v517_11;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v527_11_result;
  for (int v527_11_label = 1; v527_11_label <= 2; ++v527_11_label) {
    const Space v527_11_tail = child(s0,v527_11_label);
    if (v527_11_tail.empty()) continue;
    const Path v527_11_head{v527_11_label};
    const Space v528_2 = singleton(v527_11_head);
    const Space v528_3 = intersect(constant_3,v528_2);
    const Space v528_4 = (has_head(v528_3) ? constant_4 : Space{});
    const Space v528_5 = subtract(constant_2,v528_4);
    Space v528_8;
    if (!v528_5.empty()) {
      const Path v529_6 = concat_path(p0,v527_11_head);
      Space v529_7_result;
      for (int v529_7_label = 1; v529_7_label <= 2; ++v529_7_label) {
        const Space v529_7_tail = child(v527_11_tail,v529_7_label);
        if (v529_7_tail.empty()) continue;
        const Path v529_7_head{v529_7_label};
        const Space v530_2 = singleton(v529_7_head);
        const Space v530_3 = intersect(constant_3,v530_2);
        const Space v530_4 = (has_head(v530_3) ? constant_4 : Space{});
        const Space v530_5 = subtract(constant_2,v530_4);
        Space v530_8;
        if (!v530_5.empty()) {
          const Path v531_6 = concat_path(v529_6,v529_7_head);
          const Space v531_7 = routine_96(c, v531_6, v529_7_tail);
          v530_8 = compose(v530_5,v531_7);
        }
        const Space v530_9 = intersect(constant_3,v530_2);
        const Space v530_10 = (has_head(v530_9) ? constant_4 : Space{});
        Space v530_12;
        if (!v530_10.empty()) {
          const Path v532_6 = concat_path(v529_6,v529_7_head);
          const Space v532_11 = routine_97(c, v532_6, v529_7_tail);
          v530_12 = compose(v530_10,v532_11);
        }
        const Space v530_13 = unite(v530_8,v530_12);
        v529_7_result = unite(v529_7_result,v530_13);
      }
      const Space v529_7 = std::move(v529_7_result);
      v528_8 = compose(v528_5,v529_7);
    }
    const Space v528_9 = intersect(constant_3,v528_2);
    const Space v528_10 = (has_head(v528_9) ? constant_4 : Space{});
    Space v528_12;
    if (!v528_10.empty()) {
      const Path v533_6 = concat_path(p0,v527_11_head);
      Space v533_11_result;
      for (int v533_11_label = 1; v533_11_label <= 2; ++v533_11_label) {
        const Space v533_11_tail = child(v527_11_tail,v533_11_label);
        if (v533_11_tail.empty()) continue;
        const Path v533_11_head{v533_11_label};
        const Space v534_2 = singleton(v533_11_head);
        const Space v534_3 = intersect(constant_3,v534_2);
        const Space v534_4 = (has_head(v534_3) ? constant_4 : Space{});
        const Space v534_5 = subtract(constant_2,v534_4);
        Space v534_7;
        if (!v534_5.empty()) {
          const Space v535_6 = routine_18(c, v533_11_head, v533_6, v533_11_tail);
          v534_7 = compose(v534_5,v535_6);
        }
        const Space v534_8 = intersect(constant_3,v534_2);
        const Space v534_9 = (has_head(v534_8) ? constant_4 : Space{});
        Space v534_11;
        if (!v534_9.empty()) {
          const Space v536_10 = routine_19(c, v533_11_head, v533_6, v533_11_tail);
          v534_11 = compose(v534_9,v536_10);
        }
        const Space v534_12 = unite(v534_7,v534_11);
        v533_11_result = unite(v533_11_result,v534_12);
      }
      const Space v533_11 = std::move(v533_11_result);
      v528_12 = compose(v528_10,v533_11);
    }
    const Space v528_13 = unite(v528_8,v528_12);
    v527_11_result = unite(v527_11_result,v528_13);
  }
  const Space v527_11 = std::move(v527_11_result);
  return v527_11;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v537_12_result;
  for (int v537_12_label = 1; v537_12_label <= 2; ++v537_12_label) {
    const Space v537_12_tail = child(s0,v537_12_label);
    if (v537_12_tail.empty()) continue;
    const Path v537_12_head{v537_12_label};
    const Space v538_2 = singleton(v537_12_head);
    const Space v538_3 = intersect(constant_3,v538_2);
    const Space v538_4 = (has_head(v538_3) ? constant_4 : Space{});
    const Space v538_5 = subtract(constant_2,v538_4);
    Space v538_8;
    if (!v538_5.empty()) {
      const Path v539_6 = concat_path(p0,v537_12_head);
      Space v539_7_result;
      for (int v539_7_label = 1; v539_7_label <= 2; ++v539_7_label) {
        const Space v539_7_tail = child(v537_12_tail,v539_7_label);
        if (v539_7_tail.empty()) continue;
        const Path v539_7_head{v539_7_label};
        const Space v540_2 = singleton(v539_7_head);
        const Space v540_3 = intersect(constant_3,v540_2);
        const Space v540_4 = (has_head(v540_3) ? constant_4 : Space{});
        const Space v540_5 = subtract(constant_2,v540_4);
        Space v540_8;
        if (!v540_5.empty()) {
          const Path v541_6 = concat_path(v539_6,v539_7_head);
          const Space v541_7 = routine_98(c, v541_6, p1, v539_7_tail);
          v540_8 = compose(v540_5,v541_7);
        }
        const Space v540_9 = intersect(constant_3,v540_2);
        const Space v540_10 = (has_head(v540_9) ? constant_4 : Space{});
        Space v540_12;
        if (!v540_10.empty()) {
          const Path v542_6 = concat_path(v539_6,v539_7_head);
          const Space v542_11 = routine_99(c, v542_6, p1, v539_7_tail);
          v540_12 = compose(v540_10,v542_11);
        }
        const Space v540_13 = unite(v540_8,v540_12);
        v539_7_result = unite(v539_7_result,v540_13);
      }
      const Space v539_7 = std::move(v539_7_result);
      v538_8 = compose(v538_5,v539_7);
    }
    const Space v538_9 = intersect(constant_3,v538_2);
    const Space v538_10 = (has_head(v538_9) ? constant_4 : Space{});
    Space v538_12;
    if (!v538_10.empty()) {
      const Path v543_6 = concat_path(p0,v537_12_head);
      Space v543_11_result;
      for (int v543_11_label = 1; v543_11_label <= 2; ++v543_11_label) {
        const Space v543_11_tail = child(v537_12_tail,v543_11_label);
        if (v543_11_tail.empty()) continue;
        const Path v543_11_head{v543_11_label};
        const Space v544_2 = singleton(v543_11_head);
        const Space v544_3 = intersect(constant_3,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_4 : Space{});
        const Space v544_5 = subtract(constant_2,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_11_head);
          const Space v545_7 = routine_98(c, v545_6, p1, v543_11_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_3,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_4 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_11_head);
          const Space v546_11 = routine_22(c, v546_6, p1, v543_11_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_11_result = unite(v543_11_result,v544_13);
      }
      const Space v543_11 = std::move(v543_11_result);
      v538_12 = compose(v538_10,v543_11);
    }
    const Space v538_13 = unite(v538_8,v538_12);
    v537_12_result = unite(v537_12_result,v538_13);
  }
  const Space v537_12 = std::move(v537_12_result);
  return v537_12;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v547_10_result;
  for (int v547_10_label = 1; v547_10_label <= 2; ++v547_10_label) {
    const Space v547_10_tail = child(s0,v547_10_label);
    if (v547_10_tail.empty()) continue;
    const Path v547_10_head{v547_10_label};
    const Space v548_2 = singleton(v547_10_head);
    const Space v548_3 = intersect(constant_3,v548_2);
    const Space v548_4 = (has_head(v548_3) ? constant_4 : Space{});
    const Space v548_5 = compose(v548_4,v547_10_tail);
    const Path v549_6 = concat_path(p0,v547_10_head);
    const Space v548_7 = wrap(v548_5,v549_6);
    const Space v548_8 = wrap(v548_7,p1);
    const Space v548_9 = wrap(v548_8,constant_6);
    const Space v548_10 = intersect(constant_3,v548_2);
    const Space v548_11 = (has_head(v548_10) ? constant_4 : Space{});
    const Space v548_12 = subtract(constant_2,v548_11);
    Space v548_14;
    if (!v548_12.empty()) {
      Space v550_13_result;
      for (int v550_13_label = 1; v550_13_label <= 2; ++v550_13_label) {
        const Space v550_13_tail = child(v547_10_tail,v550_13_label);
        if (v550_13_tail.empty()) continue;
        const Path v550_13_head{v550_13_label};
        const Space v551_2 = singleton(v550_13_head);
        const Space v551_3 = intersect(constant_3,v551_2);
        const Space v551_4 = (has_head(v551_3) ? constant_4 : Space{});
        const Space v551_5 = subtract(constant_2,v551_4);
        Space v551_8;
        if (!v551_5.empty()) {
          const Path v552_6 = concat_path(v549_6,v550_13_head);
          const Space v552_7 = routine_98(c, v552_6, p1, v550_13_tail);
          v551_8 = compose(v551_5,v552_7);
        }
        const Space v551_9 = intersect(constant_3,v551_2);
        const Space v551_10 = (has_head(v551_9) ? constant_4 : Space{});
        Space v551_12;
        if (!v551_10.empty()) {
          const Path v553_6 = concat_path(v549_6,v550_13_head);
          const Space v553_11 = routine_99(c, v553_6, p1, v550_13_tail);
          v551_12 = compose(v551_10,v553_11);
        }
        const Space v551_13 = unite(v551_8,v551_12);
        v550_13_result = unite(v550_13_result,v551_13);
      }
      const Space v550_13 = std::move(v550_13_result);
      v548_14 = compose(v548_12,v550_13);
    }
    const Space v548_15 = unite(v548_9,v548_14);
    v547_10_result = unite(v547_10_result,v548_15);
  }
  const Space v547_10 = std::move(v547_10_result);
  return v547_10;
}

static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v554_12_result;
  for (int v554_12_label = 1; v554_12_label <= 2; ++v554_12_label) {
    const Space v554_12_tail = child(s0,v554_12_label);
    if (v554_12_tail.empty()) continue;
    const Path v554_12_head{v554_12_label};
    const Space v555_2 = singleton(v554_12_head);
    const Space v555_3 = intersect(constant_3,v555_2);
    const Space v555_4 = (has_head(v555_3) ? constant_4 : Space{});
    const Space v555_5 = subtract(constant_2,v555_4);
    Space v555_8;
    if (!v555_5.empty()) {
      const Path v556_6 = concat_path(p0,v554_12_head);
      Space v556_7_result;
      for (int v556_7_label = 1; v556_7_label <= 2; ++v556_7_label) {
        const Space v556_7_tail = child(v554_12_tail,v556_7_label);
        if (v556_7_tail.empty()) continue;
        const Path v556_7_head{v556_7_label};
        const Space v557_2 = singleton(v556_7_head);
        const Space v557_3 = intersect(constant_3,v557_2);
        const Space v557_4 = (has_head(v557_3) ? constant_4 : Space{});
        const Space v557_5 = subtract(constant_2,v557_4);
        Space v557_8;
        if (!v557_5.empty()) {
          const Path v558_6 = concat_path(v556_6,v556_7_head);
          const Space v558_7 = routine_100(c, v558_6, p1, v556_7_tail);
          v557_8 = compose(v557_5,v558_7);
        }
        const Space v557_9 = intersect(constant_3,v557_2);
        const Space v557_10 = (has_head(v557_9) ? constant_4 : Space{});
        Space v557_12;
        if (!v557_10.empty()) {
          const Path v559_6 = concat_path(v556_6,v556_7_head);
          const Space v559_11 = routine_101(c, v559_6, p1, v556_7_tail);
          v557_12 = compose(v557_10,v559_11);
        }
        const Space v557_13 = unite(v557_8,v557_12);
        v556_7_result = unite(v556_7_result,v557_13);
      }
      const Space v556_7 = std::move(v556_7_result);
      v555_8 = compose(v555_5,v556_7);
    }
    const Space v555_9 = intersect(constant_3,v555_2);
    const Space v555_10 = (has_head(v555_9) ? constant_4 : Space{});
    Space v555_12;
    if (!v555_10.empty()) {
      const Path v560_6 = concat_path(p0,v554_12_head);
      Space v560_11_result;
      for (int v560_11_label = 1; v560_11_label <= 2; ++v560_11_label) {
        const Space v560_11_tail = child(v554_12_tail,v560_11_label);
        if (v560_11_tail.empty()) continue;
        const Path v560_11_head{v560_11_label};
        const Space v561_2 = singleton(v560_11_head);
        const Space v561_3 = intersect(constant_3,v561_2);
        const Space v561_4 = (has_head(v561_3) ? constant_4 : Space{});
        const Space v561_5 = subtract(constant_2,v561_4);
        Space v561_8;
        if (!v561_5.empty()) {
          const Path v562_6 = concat_path(v560_6,v560_11_head);
          const Space v562_7 = routine_100(c, v562_6, p1, v560_11_tail);
          v561_8 = compose(v561_5,v562_7);
        }
        const Space v561_9 = intersect(constant_3,v561_2);
        const Space v561_10 = (has_head(v561_9) ? constant_4 : Space{});
        Space v561_12;
        if (!v561_10.empty()) {
          const Path v563_6 = concat_path(v560_6,v560_11_head);
          const Space v563_11 = routine_22(c, v563_6, p1, v560_11_tail);
          v561_12 = compose(v561_10,v563_11);
        }
        const Space v561_13 = unite(v561_8,v561_12);
        v560_11_result = unite(v560_11_result,v561_13);
      }
      const Space v560_11 = std::move(v560_11_result);
      v555_12 = compose(v555_10,v560_11);
    }
    const Space v555_13 = unite(v555_8,v555_12);
    v554_12_result = unite(v554_12_result,v555_13);
  }
  const Space v554_12 = std::move(v554_12_result);
  return v554_12;
}

static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v564_10_result;
  for (int v564_10_label = 1; v564_10_label <= 2; ++v564_10_label) {
    const Space v564_10_tail = child(s0,v564_10_label);
    if (v564_10_tail.empty()) continue;
    const Path v564_10_head{v564_10_label};
    const Space v565_2 = singleton(v564_10_head);
    const Space v565_3 = intersect(constant_3,v565_2);
    const Space v565_4 = (has_head(v565_3) ? constant_4 : Space{});
    const Space v565_5 = compose(v565_4,v564_10_tail);
    const Path v566_6 = concat_path(p0,v564_10_head);
    const Space v565_7 = wrap(v565_5,v566_6);
    const Space v565_8 = wrap(v565_7,p1);
    const Space v565_9 = wrap(v565_8,constant_6);
    const Space v565_10 = intersect(constant_3,v565_2);
    const Space v565_11 = (has_head(v565_10) ? constant_4 : Space{});
    const Space v565_12 = subtract(constant_2,v565_11);
    Space v565_14;
    if (!v565_12.empty()) {
      Space v567_13_result;
      for (int v567_13_label = 1; v567_13_label <= 2; ++v567_13_label) {
        const Space v567_13_tail = child(v564_10_tail,v567_13_label);
        if (v567_13_tail.empty()) continue;
        const Path v567_13_head{v567_13_label};
        const Space v568_2 = singleton(v567_13_head);
        const Space v568_3 = intersect(constant_3,v568_2);
        const Space v568_4 = (has_head(v568_3) ? constant_4 : Space{});
        const Space v568_5 = subtract(constant_2,v568_4);
        Space v568_8;
        if (!v568_5.empty()) {
          const Path v569_6 = concat_path(v566_6,v567_13_head);
          const Space v569_7 = routine_100(c, v569_6, p1, v567_13_tail);
          v568_8 = compose(v568_5,v569_7);
        }
        const Space v568_9 = intersect(constant_3,v568_2);
        const Space v568_10 = (has_head(v568_9) ? constant_4 : Space{});
        Space v568_12;
        if (!v568_10.empty()) {
          const Path v570_6 = concat_path(v566_6,v567_13_head);
          const Space v570_11 = routine_101(c, v570_6, p1, v567_13_tail);
          v568_12 = compose(v568_10,v570_11);
        }
        const Space v568_13 = unite(v568_8,v568_12);
        v567_13_result = unite(v567_13_result,v568_13);
      }
      const Space v567_13 = std::move(v567_13_result);
      v565_14 = compose(v565_12,v567_13);
    }
    const Space v565_15 = unite(v565_9,v565_14);
    v564_10_result = unite(v564_10_result,v565_15);
  }
  const Space v564_10 = std::move(v564_10_result);
  return v564_10;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v571_12_result;
  for (int v571_12_label = 1; v571_12_label <= 2; ++v571_12_label) {
    const Space v571_12_tail = child(s0,v571_12_label);
    if (v571_12_tail.empty()) continue;
    const Path v571_12_head{v571_12_label};
    const Space v572_2 = singleton(v571_12_head);
    const Space v572_3 = intersect(constant_3,v572_2);
    const Space v572_4 = (has_head(v572_3) ? constant_4 : Space{});
    const Space v572_5 = subtract(constant_2,v572_4);
    Space v572_8;
    if (!v572_5.empty()) {
      const Path v573_6 = concat_path(p0,v571_12_head);
      Space v573_7_result;
      for (int v573_7_label = 1; v573_7_label <= 2; ++v573_7_label) {
        const Space v573_7_tail = child(v571_12_tail,v573_7_label);
        if (v573_7_tail.empty()) continue;
        const Path v573_7_head{v573_7_label};
        const Space v574_2 = singleton(v573_7_head);
        const Space v574_3 = intersect(constant_3,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_4 : Space{});
        const Space v574_5 = subtract(constant_2,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_7_head);
          const Space v575_7 = routine_102(c, v575_6, v573_7_tail, s1);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_3,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_4 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_7_head);
          const Space v576_11 = routine_103(c, v576_6, v573_7_tail, s1);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_7_result = unite(v573_7_result,v574_13);
      }
      const Space v573_7 = std::move(v573_7_result);
      v572_8 = compose(v572_5,v573_7);
    }
    const Space v572_9 = intersect(constant_3,v572_2);
    const Space v572_10 = (has_head(v572_9) ? constant_4 : Space{});
    Space v572_12;
    if (!v572_10.empty()) {
      const Path v577_6 = concat_path(p0,v571_12_head);
      Space v577_11_result;
      for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
        const Space v577_11_tail = child(v571_12_tail,v577_11_label);
        if (v577_11_tail.empty()) continue;
        const Path v577_11_head{v577_11_label};
        const Space v578_2 = singleton(v577_11_head);
        const Space v578_3 = intersect(constant_3,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_4 : Space{});
        const Space v578_5 = subtract(constant_2,v578_4);
        Space v578_8;
        if (!v578_5.empty()) {
          const Path v579_6 = concat_path(v577_6,v577_11_head);
          const Space v579_7 = routine_102(c, v579_6, v577_11_tail, s1);
          v578_8 = compose(v578_5,v579_7);
        }
        const Space v578_9 = intersect(constant_3,v578_2);
        const Space v578_10 = (has_head(v578_9) ? constant_4 : Space{});
        Space v578_12;
        if (!v578_10.empty()) {
          const Path v580_6 = concat_path(v577_6,v577_11_head);
          const Space v580_11 = routine_6(c, v580_6, v577_11_tail, s1);
          v578_12 = compose(v578_10,v580_11);
        }
        const Space v578_13 = unite(v578_8,v578_12);
        v577_11_result = unite(v577_11_result,v578_13);
      }
      const Space v577_11 = std::move(v577_11_result);
      v572_12 = compose(v572_10,v577_11);
    }
    const Space v572_13 = unite(v572_8,v572_12);
    v571_12_result = unite(v571_12_result,v572_13);
  }
  const Space v571_12 = std::move(v571_12_result);
  return v571_12;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v581_12_result;
  for (int v581_12_label = 1; v581_12_label <= 2; ++v581_12_label) {
    const Space v581_12_tail = child(s0,v581_12_label);
    if (v581_12_tail.empty()) continue;
    const Path v581_12_head{v581_12_label};
    const Space v582_2 = singleton(v581_12_head);
    const Space v582_3 = intersect(constant_3,v582_2);
    const Space v582_4 = (has_head(v582_3) ? constant_4 : Space{});
    const Space v582_5 = subtract(constant_2,v582_4);
    Space v582_8;
    if (!v582_5.empty()) {
      const Path v583_6 = concat_path(p0,v581_12_head);
      Space v583_7_result;
      for (int v583_7_label = 1; v583_7_label <= 2; ++v583_7_label) {
        const Space v583_7_tail = child(v581_12_tail,v583_7_label);
        if (v583_7_tail.empty()) continue;
        const Path v583_7_head{v583_7_label};
        const Space v584_2 = singleton(v583_7_head);
        const Space v584_3 = intersect(constant_3,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_4 : Space{});
        const Space v584_5 = subtract(constant_2,v584_4);
        Space v584_8;
        if (!v584_5.empty()) {
          const Path v585_6 = concat_path(v583_6,v583_7_head);
          const Space v585_7 = routine_102(c, v585_6, v583_7_tail, s1);
          v584_8 = compose(v584_5,v585_7);
        }
        const Space v584_9 = intersect(constant_3,v584_2);
        const Space v584_10 = (has_head(v584_9) ? constant_4 : Space{});
        Space v584_12;
        if (!v584_10.empty()) {
          const Path v586_6 = concat_path(v583_6,v583_7_head);
          const Space v586_11 = routine_103(c, v586_6, v583_7_tail, s1);
          v584_12 = compose(v584_10,v586_11);
        }
        const Space v584_13 = unite(v584_8,v584_12);
        v583_7_result = unite(v583_7_result,v584_13);
      }
      const Space v583_7 = std::move(v583_7_result);
      v582_8 = compose(v582_5,v583_7);
    }
    const Space v582_9 = intersect(constant_3,v582_2);
    const Space v582_10 = (has_head(v582_9) ? constant_4 : Space{});
    Space v582_12;
    if (!v582_10.empty()) {
      const Path v587_6 = concat_path(p0,v581_12_head);
      Space v587_11_result;
      for (int v587_11_label = 1; v587_11_label <= 2; ++v587_11_label) {
        const Space v587_11_tail = child(v581_12_tail,v587_11_label);
        if (v587_11_tail.empty()) continue;
        const Path v587_11_head{v587_11_label};
        const Space v588_2 = singleton(v587_11_head);
        const Space v588_3 = intersect(constant_3,v588_2);
        const Space v588_4 = (has_head(v588_3) ? constant_4 : Space{});
        const Space v588_5 = subtract(constant_2,v588_4);
        Space v588_7;
        if (!v588_5.empty()) {
          const Space v589_6 = routine_25(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_7 = compose(v588_5,v589_6);
        }
        const Space v588_8 = intersect(constant_3,v588_2);
        const Space v588_9 = (has_head(v588_8) ? constant_4 : Space{});
        Space v588_11;
        if (!v588_9.empty()) {
          const Space v590_10 = routine_26(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_11 = compose(v588_9,v590_10);
        }
        const Space v588_12 = unite(v588_7,v588_11);
        v587_11_result = unite(v587_11_result,v588_12);
      }
      const Space v587_11 = std::move(v587_11_result);
      v582_12 = compose(v582_10,v587_11);
    }
    const Space v582_13 = unite(v582_8,v582_12);
    v581_12_result = unite(v581_12_result,v582_13);
  }
  const Space v581_12 = std::move(v581_12_result);
  return v581_12;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v591_13_result;
  for (int v591_13_label = 1; v591_13_label <= 2; ++v591_13_label) {
    const Space v591_13_tail = child(s0,v591_13_label);
    if (v591_13_tail.empty()) continue;
    const Path v591_13_head{v591_13_label};
    const Space v592_2 = singleton(v591_13_head);
    const Space v592_3 = intersect(constant_3,v592_2);
    const Space v592_4 = (has_head(v592_3) ? constant_4 : Space{});
    const Space v592_5 = subtract(constant_2,v592_4);
    Space v592_8;
    if (!v592_5.empty()) {
      const Path v593_6 = concat_path(p0,v591_13_head);
      Space v593_7_result;
      for (int v593_7_label = 1; v593_7_label <= 2; ++v593_7_label) {
        const Space v593_7_tail = child(v591_13_tail,v593_7_label);
        if (v593_7_tail.empty()) continue;
        const Path v593_7_head{v593_7_label};
        const Space v594_2 = singleton(v593_7_head);
        const Space v594_3 = intersect(constant_3,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_4 : Space{});
        const Space v594_5 = subtract(constant_2,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_7_head);
          const Space v595_7 = routine_104(c, v595_6, p1, v593_7_tail, s1);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_3,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_4 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_7_head);
          const Space v596_11 = routine_105(c, v596_6, p1, v593_7_tail, s1);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_7_result = unite(v593_7_result,v594_13);
      }
      const Space v593_7 = std::move(v593_7_result);
      v592_8 = compose(v592_5,v593_7);
    }
    const Space v592_9 = intersect(constant_3,v592_2);
    const Space v592_10 = (has_head(v592_9) ? constant_4 : Space{});
    Space v592_12;
    if (!v592_10.empty()) {
      const Path v597_6 = concat_path(p0,v591_13_head);
      Space v597_11_result;
      for (int v597_11_label = 1; v597_11_label <= 2; ++v597_11_label) {
        const Space v597_11_tail = child(v591_13_tail,v597_11_label);
        if (v597_11_tail.empty()) continue;
        const Path v597_11_head{v597_11_label};
        const Space v598_2 = singleton(v597_11_head);
        const Space v598_3 = intersect(constant_3,v598_2);
        const Space v598_4 = (has_head(v598_3) ? constant_4 : Space{});
        const Space v598_5 = subtract(constant_2,v598_4);
        Space v598_8;
        if (!v598_5.empty()) {
          const Path v599_6 = concat_path(v597_6,v597_11_head);
          const Space v599_7 = routine_104(c, v599_6, p1, v597_11_tail, s1);
          v598_8 = compose(v598_5,v599_7);
        }
        const Space v598_9 = intersect(constant_3,v598_2);
        const Space v598_10 = (has_head(v598_9) ? constant_4 : Space{});
        Space v598_12;
        if (!v598_10.empty()) {
          const Path v600_6 = concat_path(v597_6,v597_11_head);
          const Space v600_11 = routine_29(c, v600_6, p1, v597_11_tail, s1);
          v598_12 = compose(v598_10,v600_11);
        }
        const Space v598_13 = unite(v598_8,v598_12);
        v597_11_result = unite(v597_11_result,v598_13);
      }
      const Space v597_11 = std::move(v597_11_result);
      v592_12 = compose(v592_10,v597_11);
    }
    const Space v592_13 = unite(v592_8,v592_12);
    v591_13_result = unite(v591_13_result,v592_13);
  }
  const Space v591_13 = std::move(v591_13_result);
  return v591_13;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v601_8 = unwrap(s1,constant_5);
  const Space v601_10 = unwrap(v601_8,constant_6);
  const Space v601_11 = unwrap(v601_10,p0);
  Space v601_18_result;
  for (int v601_18_label = 1; v601_18_label <= 2; ++v601_18_label) {
    const Space v601_18_tail = child(s0,v601_18_label);
    if (v601_18_tail.empty()) continue;
    const Path v601_18_head{v601_18_label};
    const Space v602_2 = singleton(v601_18_head);
    const Space v602_3 = intersect(constant_3,v602_2);
    const Space v602_4 = (has_head(v602_3) ? constant_4 : Space{});
    const Space v602_5 = subtract(constant_2,v602_4);
    Space v602_8;
    if (!v602_5.empty()) {
      const Path v603_6 = concat_path(p0,v601_18_head);
      Space v603_7_result;
      for (int v603_7_label = 1; v603_7_label <= 2; ++v603_7_label) {
        const Space v603_7_tail = child(v601_18_tail,v603_7_label);
        if (v603_7_tail.empty()) continue;
        const Path v603_7_head{v603_7_label};
        const Space v604_2 = singleton(v603_7_head);
        const Space v604_3 = intersect(constant_3,v604_2);
        const Space v604_4 = (has_head(v604_3) ? constant_4 : Space{});
        const Space v604_5 = subtract(constant_2,v604_4);
        Space v604_8;
        if (!v604_5.empty()) {
          const Path v605_6 = concat_path(v603_6,v603_7_head);
          const Space v605_7 = routine_104(c, v605_6, p1, v603_7_tail, s1);
          v604_8 = compose(v604_5,v605_7);
        }
        const Space v604_9 = intersect(constant_3,v604_2);
        const Space v604_10 = (has_head(v604_9) ? constant_4 : Space{});
        Space v604_12;
        if (!v604_10.empty()) {
          const Path v606_6 = concat_path(v603_6,v603_7_head);
          const Space v606_11 = routine_105(c, v606_6, p1, v603_7_tail, s1);
          v604_12 = compose(v604_10,v606_11);
        }
        const Space v604_13 = unite(v604_8,v604_12);
        v603_7_result = unite(v603_7_result,v604_13);
      }
      const Space v603_7 = std::move(v603_7_result);
      v602_8 = compose(v602_5,v603_7);
    }
    const Space v602_9 = intersect(constant_3,v602_2);
    const Space v602_10 = (has_head(v602_9) ? constant_4 : Space{});
    Space v602_13;
    if (!v602_10.empty()) {
      const Space v607_11 = unwrap(v601_11,v601_18_head);
      Space v607_12_result;
      for (int v607_12_label = 1; v607_12_label <= 2; ++v607_12_label) {
        const Space v607_12_tail = child(v607_11,v607_12_label);
        if (v607_12_tail.empty()) continue;
        const Path v607_12_head{v607_12_label};
        const Space v608_2 = singleton(v607_12_head);
        const Space v608_3 = intersect(constant_3,v608_2);
        const Space v608_4 = (has_head(v608_3) ? constant_4 : Space{});
        const Space v608_5 = subtract(constant_2,v608_4);
        Space v608_7;
        if (!v608_5.empty()) {
          const Space v609_6 = routine_61(c, v607_12_head, p1, v607_12_tail);
          v608_7 = compose(v608_5,v609_6);
        }
        const Space v608_8 = intersect(constant_3,v608_2);
        const Space v608_9 = (has_head(v608_8) ? constant_4 : Space{});
        Space v608_11;
        if (!v608_9.empty()) {
          const Space v610_10 = routine_62(c, v607_12_head, p1, v607_12_tail);
          v608_11 = compose(v608_9,v610_10);
        }
        const Space v608_12 = unite(v608_7,v608_11);
        v607_12_result = unite(v607_12_result,v608_12);
      }
      const Space v607_12 = std::move(v607_12_result);
      v602_13 = compose(v602_10,v607_12);
    }
    const Space v602_14 = unite(v602_8,v602_13);
    v601_18_result = unite(v601_18_result,v602_14);
  }
  const Space v601_18 = std::move(v601_18_result);
  return v601_18;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v611_12_result;
  for (int v611_12_label = 1; v611_12_label <= 2; ++v611_12_label) {
    const Space v611_12_tail = child(s0,v611_12_label);
    if (v611_12_tail.empty()) continue;
    const Path v611_12_head{v611_12_label};
    const Space v612_2 = singleton(v611_12_head);
    const Space v612_3 = intersect(constant_3,v612_2);
    const Space v612_4 = (has_head(v612_3) ? constant_4 : Space{});
    const Space v612_5 = subtract(constant_2,v612_4);
    Space v612_8;
    if (!v612_5.empty()) {
      const Path v613_6 = concat_path(p0,v611_12_head);
      Space v613_7_result;
      for (int v613_7_label = 1; v613_7_label <= 2; ++v613_7_label) {
        const Space v613_7_tail = child(v611_12_tail,v613_7_label);
        if (v613_7_tail.empty()) continue;
        const Path v613_7_head{v613_7_label};
        const Space v614_2 = singleton(v613_7_head);
        const Space v614_3 = intersect(constant_3,v614_2);
        const Space v614_4 = (has_head(v614_3) ? constant_4 : Space{});
        const Space v614_5 = subtract(constant_2,v614_4);
        Space v614_8;
        if (!v614_5.empty()) {
          const Path v615_6 = concat_path(v613_6,v613_7_head);
          const Space v615_7 = routine_106(c, v615_6, p1, v613_7_tail);
          v614_8 = compose(v614_5,v615_7);
        }
        const Space v614_9 = intersect(constant_3,v614_2);
        const Space v614_10 = (has_head(v614_9) ? constant_4 : Space{});
        Space v614_12;
        if (!v614_10.empty()) {
          const Path v616_6 = concat_path(v613_6,v613_7_head);
          const Space v616_11 = routine_107(c, v616_6, p1, v613_7_tail);
          v614_12 = compose(v614_10,v616_11);
        }
        const Space v614_13 = unite(v614_8,v614_12);
        v613_7_result = unite(v613_7_result,v614_13);
      }
      const Space v613_7 = std::move(v613_7_result);
      v612_8 = compose(v612_5,v613_7);
    }
    const Space v612_9 = intersect(constant_3,v612_2);
    const Space v612_10 = (has_head(v612_9) ? constant_4 : Space{});
    Space v612_12;
    if (!v612_10.empty()) {
      const Path v617_6 = concat_path(p0,v611_12_head);
      Space v617_11_result;
      for (int v617_11_label = 1; v617_11_label <= 2; ++v617_11_label) {
        const Space v617_11_tail = child(v611_12_tail,v617_11_label);
        if (v617_11_tail.empty()) continue;
        const Path v617_11_head{v617_11_label};
        const Space v618_2 = singleton(v617_11_head);
        const Space v618_3 = intersect(constant_3,v618_2);
        const Space v618_4 = (has_head(v618_3) ? constant_4 : Space{});
        const Space v618_5 = subtract(constant_2,v618_4);
        Space v618_8;
        if (!v618_5.empty()) {
          const Path v619_6 = concat_path(v617_6,v617_11_head);
          const Space v619_7 = routine_106(c, v619_6, p1, v617_11_tail);
          v618_8 = compose(v618_5,v619_7);
        }
        const Space v618_9 = intersect(constant_3,v618_2);
        const Space v618_10 = (has_head(v618_9) ? constant_4 : Space{});
        Space v618_12;
        if (!v618_10.empty()) {
          const Path v620_6 = concat_path(v617_6,v617_11_head);
          const Space v620_11 = routine_67(c, v620_6, p1, v617_11_tail);
          v618_12 = compose(v618_10,v620_11);
        }
        const Space v618_13 = unite(v618_8,v618_12);
        v617_11_result = unite(v617_11_result,v618_13);
      }
      const Space v617_11 = std::move(v617_11_result);
      v612_12 = compose(v612_10,v617_11);
    }
    const Space v612_13 = unite(v612_8,v612_12);
    v611_12_result = unite(v611_12_result,v612_13);
  }
  const Space v611_12 = std::move(v611_12_result);
  return v611_12;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v621_9_result;
  for (int v621_9_label = 1; v621_9_label <= 2; ++v621_9_label) {
    const Space v621_9_tail = child(s0,v621_9_label);
    if (v621_9_tail.empty()) continue;
    const Path v621_9_head{v621_9_label};
    const Space v622_2 = singleton(v621_9_head);
    const Space v622_3 = intersect(constant_3,v622_2);
    const Space v622_4 = (has_head(v622_3) ? constant_4 : Space{});
    const Space v622_5 = subtract(constant_2,v622_4);
    Space v622_8;
    if (!v622_5.empty()) {
      const Path v623_6 = concat_path(p0,v621_9_head);
      Space v623_7_result;
      for (int v623_7_label = 1; v623_7_label <= 2; ++v623_7_label) {
        const Space v623_7_tail = child(v621_9_tail,v623_7_label);
        if (v623_7_tail.empty()) continue;
        const Path v623_7_head{v623_7_label};
        const Space v624_2 = singleton(v623_7_head);
        const Space v624_3 = intersect(constant_3,v624_2);
        const Space v624_4 = (has_head(v624_3) ? constant_4 : Space{});
        const Space v624_5 = subtract(constant_2,v624_4);
        Space v624_8;
        if (!v624_5.empty()) {
          const Path v625_6 = concat_path(v623_6,v623_7_head);
          const Space v625_7 = routine_106(c, v625_6, p1, v623_7_tail);
          v624_8 = compose(v624_5,v625_7);
        }
        const Space v624_9 = intersect(constant_3,v624_2);
        const Space v624_10 = (has_head(v624_9) ? constant_4 : Space{});
        Space v624_12;
        if (!v624_10.empty()) {
          const Path v626_6 = concat_path(v623_6,v623_7_head);
          const Space v626_11 = routine_107(c, v626_6, p1, v623_7_tail);
          v624_12 = compose(v624_10,v626_11);
        }
        const Space v624_13 = unite(v624_8,v624_12);
        v623_7_result = unite(v623_7_result,v624_13);
      }
      const Space v623_7 = std::move(v623_7_result);
      v622_8 = compose(v622_5,v623_7);
    }
    const Space v622_9 = intersect(constant_3,v622_2);
    const Space v622_10 = (has_head(v622_9) ? constant_4 : Space{});
    const Space v622_11 = compose(v622_10,v621_9_tail);
    const Path v627_6 = concat_path(p0,v621_9_head);
    const Space v622_12 = wrap(v622_11,v627_6);
    const Space v622_13 = wrap(v622_12,p1);
    const Space v622_14 = unite(v622_8,v622_13);
    v621_9_result = unite(v621_9_result,v622_14);
  }
  const Space v621_9 = std::move(v621_9_result);
  return v621_9;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v628_13_result;
  for (int v628_13_label = 1; v628_13_label <= 2; ++v628_13_label) {
    const Space v628_13_tail = child(s0,v628_13_label);
    if (v628_13_tail.empty()) continue;
    const Path v628_13_head{v628_13_label};
    const Space v629_2 = singleton(v628_13_head);
    const Space v629_3 = intersect(constant_3,v629_2);
    const Space v629_4 = (has_head(v629_3) ? constant_4 : Space{});
    const Space v629_5 = subtract(constant_2,v629_4);
    Space v629_8;
    if (!v629_5.empty()) {
      const Path v630_6 = concat_path(p0,v628_13_head);
      Space v630_7_result;
      for (int v630_7_label = 1; v630_7_label <= 2; ++v630_7_label) {
        const Space v630_7_tail = child(v628_13_tail,v630_7_label);
        if (v630_7_tail.empty()) continue;
        const Path v630_7_head{v630_7_label};
        const Space v631_2 = singleton(v630_7_head);
        const Space v631_3 = intersect(constant_3,v631_2);
        const Space v631_4 = (has_head(v631_3) ? constant_4 : Space{});
        const Space v631_5 = subtract(constant_2,v631_4);
        Space v631_8;
        if (!v631_5.empty()) {
          const Path v632_6 = concat_path(v630_6,v630_7_head);
          const Space v632_7 = routine_108(c, v632_6, p1, v630_7_tail, s1);
          v631_8 = compose(v631_5,v632_7);
        }
        const Space v631_9 = intersect(constant_3,v631_2);
        const Space v631_10 = (has_head(v631_9) ? constant_4 : Space{});
        Space v631_12;
        if (!v631_10.empty()) {
          const Path v633_6 = concat_path(v630_6,v630_7_head);
          const Space v633_11 = routine_109(c, v633_6, p1, v630_7_tail, s1);
          v631_12 = compose(v631_10,v633_11);
        }
        const Space v631_13 = unite(v631_8,v631_12);
        v630_7_result = unite(v630_7_result,v631_13);
      }
      const Space v630_7 = std::move(v630_7_result);
      v629_8 = compose(v629_5,v630_7);
    }
    const Space v629_9 = intersect(constant_3,v629_2);
    const Space v629_10 = (has_head(v629_9) ? constant_4 : Space{});
    Space v629_12;
    if (!v629_10.empty()) {
      const Path v634_6 = concat_path(p0,v628_13_head);
      Space v634_11_result;
      for (int v634_11_label = 1; v634_11_label <= 2; ++v634_11_label) {
        const Space v634_11_tail = child(v628_13_tail,v634_11_label);
        if (v634_11_tail.empty()) continue;
        const Path v634_11_head{v634_11_label};
        const Space v635_2 = singleton(v634_11_head);
        const Space v635_3 = intersect(constant_3,v635_2);
        const Space v635_4 = (has_head(v635_3) ? constant_4 : Space{});
        const Space v635_5 = subtract(constant_2,v635_4);
        Space v635_8;
        if (!v635_5.empty()) {
          const Path v636_6 = concat_path(v634_6,v634_11_head);
          const Space v636_7 = routine_108(c, v636_6, p1, v634_11_tail, s1);
          v635_8 = compose(v635_5,v636_7);
        }
        const Space v635_9 = intersect(constant_3,v635_2);
        const Space v635_10 = (has_head(v635_9) ? constant_4 : Space{});
        Space v635_12;
        if (!v635_10.empty()) {
          const Path v637_6 = concat_path(v634_6,v634_11_head);
          const Space v637_11 = routine_29(c, v637_6, p1, v634_11_tail, s1);
          v635_12 = compose(v635_10,v637_11);
        }
        const Space v635_13 = unite(v635_8,v635_12);
        v634_11_result = unite(v634_11_result,v635_13);
      }
      const Space v634_11 = std::move(v634_11_result);
      v629_12 = compose(v629_10,v634_11);
    }
    const Space v629_13 = unite(v629_8,v629_12);
    v628_13_result = unite(v628_13_result,v629_13);
  }
  const Space v628_13 = std::move(v628_13_result);
  return v628_13;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v638_8 = unwrap(s1,constant_5);
  const Space v638_10 = unwrap(v638_8,constant_6);
  const Space v638_11 = unwrap(v638_10,p0);
  Space v638_18_result;
  for (int v638_18_label = 1; v638_18_label <= 2; ++v638_18_label) {
    const Space v638_18_tail = child(s0,v638_18_label);
    if (v638_18_tail.empty()) continue;
    const Path v638_18_head{v638_18_label};
    const Space v639_2 = singleton(v638_18_head);
    const Space v639_3 = intersect(constant_3,v639_2);
    const Space v639_4 = (has_head(v639_3) ? constant_4 : Space{});
    const Space v639_5 = subtract(constant_2,v639_4);
    Space v639_8;
    if (!v639_5.empty()) {
      const Path v640_6 = concat_path(p0,v638_18_head);
      Space v640_7_result;
      for (int v640_7_label = 1; v640_7_label <= 2; ++v640_7_label) {
        const Space v640_7_tail = child(v638_18_tail,v640_7_label);
        if (v640_7_tail.empty()) continue;
        const Path v640_7_head{v640_7_label};
        const Space v641_2 = singleton(v640_7_head);
        const Space v641_3 = intersect(constant_3,v641_2);
        const Space v641_4 = (has_head(v641_3) ? constant_4 : Space{});
        const Space v641_5 = subtract(constant_2,v641_4);
        Space v641_8;
        if (!v641_5.empty()) {
          const Path v642_6 = concat_path(v640_6,v640_7_head);
          const Space v642_7 = routine_108(c, v642_6, p1, v640_7_tail, s1);
          v641_8 = compose(v641_5,v642_7);
        }
        const Space v641_9 = intersect(constant_3,v641_2);
        const Space v641_10 = (has_head(v641_9) ? constant_4 : Space{});
        Space v641_12;
        if (!v641_10.empty()) {
          const Path v643_6 = concat_path(v640_6,v640_7_head);
          const Space v643_11 = routine_109(c, v643_6, p1, v640_7_tail, s1);
          v641_12 = compose(v641_10,v643_11);
        }
        const Space v641_13 = unite(v641_8,v641_12);
        v640_7_result = unite(v640_7_result,v641_13);
      }
      const Space v640_7 = std::move(v640_7_result);
      v639_8 = compose(v639_5,v640_7);
    }
    const Space v639_9 = intersect(constant_3,v639_2);
    const Space v639_10 = (has_head(v639_9) ? constant_4 : Space{});
    Space v639_13;
    if (!v639_10.empty()) {
      const Space v644_11 = unwrap(v638_11,v638_18_head);
      Space v644_12_result;
      for (int v644_12_label = 1; v644_12_label <= 2; ++v644_12_label) {
        const Space v644_12_tail = child(v644_11,v644_12_label);
        if (v644_12_tail.empty()) continue;
        const Path v644_12_head{v644_12_label};
        const Space v645_2 = singleton(v644_12_head);
        const Space v645_3 = intersect(constant_3,v645_2);
        const Space v645_4 = (has_head(v645_3) ? constant_4 : Space{});
        const Space v645_5 = subtract(constant_2,v645_4);
        Space v645_7;
        if (!v645_5.empty()) {
          const Space v646_6 = routine_61(c, v644_12_head, p1, v644_12_tail);
          v645_7 = compose(v645_5,v646_6);
        }
        const Space v645_8 = intersect(constant_3,v645_2);
        const Space v645_9 = (has_head(v645_8) ? constant_4 : Space{});
        Space v645_11;
        if (!v645_9.empty()) {
          const Space v647_10 = routine_62(c, v644_12_head, p1, v644_12_tail);
          v645_11 = compose(v645_9,v647_10);
        }
        const Space v645_12 = unite(v645_7,v645_11);
        v644_12_result = unite(v644_12_result,v645_12);
      }
      const Space v644_12 = std::move(v644_12_result);
      v639_13 = compose(v639_10,v644_12);
    }
    const Space v639_14 = unite(v639_8,v639_13);
    v638_18_result = unite(v638_18_result,v639_14);
  }
  const Space v638_18 = std::move(v638_18_result);
  return v638_18;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v648_12_result;
  for (int v648_12_label = 1; v648_12_label <= 2; ++v648_12_label) {
    const Space v648_12_tail = child(s0,v648_12_label);
    if (v648_12_tail.empty()) continue;
    const Path v648_12_head{v648_12_label};
    const Space v649_2 = singleton(v648_12_head);
    const Space v649_3 = intersect(constant_3,v649_2);
    const Space v649_4 = (has_head(v649_3) ? constant_4 : Space{});
    const Space v649_5 = subtract(constant_2,v649_4);
    Space v649_8;
    if (!v649_5.empty()) {
      const Path v650_6 = concat_path(p0,v648_12_head);
      Space v650_7_result;
      for (int v650_7_label = 1; v650_7_label <= 2; ++v650_7_label) {
        const Space v650_7_tail = child(v648_12_tail,v650_7_label);
        if (v650_7_tail.empty()) continue;
        const Path v650_7_head{v650_7_label};
        const Space v651_2 = singleton(v650_7_head);
        const Space v651_3 = intersect(constant_3,v651_2);
        const Space v651_4 = (has_head(v651_3) ? constant_4 : Space{});
        const Space v651_5 = subtract(constant_2,v651_4);
        Space v651_8;
        if (!v651_5.empty()) {
          const Path v652_6 = concat_path(v650_6,v650_7_head);
          const Space v652_7 = routine_110(c, v652_6, p1, v650_7_tail);
          v651_8 = compose(v651_5,v652_7);
        }
        const Space v651_9 = intersect(constant_3,v651_2);
        const Space v651_10 = (has_head(v651_9) ? constant_4 : Space{});
        Space v651_12;
        if (!v651_10.empty()) {
          const Path v653_6 = concat_path(v650_6,v650_7_head);
          const Space v653_11 = routine_111(c, v653_6, p1, v650_7_tail);
          v651_12 = compose(v651_10,v653_11);
        }
        const Space v651_13 = unite(v651_8,v651_12);
        v650_7_result = unite(v650_7_result,v651_13);
      }
      const Space v650_7 = std::move(v650_7_result);
      v649_8 = compose(v649_5,v650_7);
    }
    const Space v649_9 = intersect(constant_3,v649_2);
    const Space v649_10 = (has_head(v649_9) ? constant_4 : Space{});
    Space v649_12;
    if (!v649_10.empty()) {
      const Path v654_6 = concat_path(p0,v648_12_head);
      Space v654_11_result;
      for (int v654_11_label = 1; v654_11_label <= 2; ++v654_11_label) {
        const Space v654_11_tail = child(v648_12_tail,v654_11_label);
        if (v654_11_tail.empty()) continue;
        const Path v654_11_head{v654_11_label};
        const Space v655_2 = singleton(v654_11_head);
        const Space v655_3 = intersect(constant_3,v655_2);
        const Space v655_4 = (has_head(v655_3) ? constant_4 : Space{});
        const Space v655_5 = subtract(constant_2,v655_4);
        Space v655_8;
        if (!v655_5.empty()) {
          const Path v656_6 = concat_path(v654_6,v654_11_head);
          const Space v656_7 = routine_110(c, v656_6, p1, v654_11_tail);
          v655_8 = compose(v655_5,v656_7);
        }
        const Space v655_9 = intersect(constant_3,v655_2);
        const Space v655_10 = (has_head(v655_9) ? constant_4 : Space{});
        Space v655_12;
        if (!v655_10.empty()) {
          const Path v657_6 = concat_path(v654_6,v654_11_head);
          const Space v657_11 = routine_67(c, v657_6, p1, v654_11_tail);
          v655_12 = compose(v655_10,v657_11);
        }
        const Space v655_13 = unite(v655_8,v655_12);
        v654_11_result = unite(v654_11_result,v655_13);
      }
      const Space v654_11 = std::move(v654_11_result);
      v649_12 = compose(v649_10,v654_11);
    }
    const Space v649_13 = unite(v649_8,v649_12);
    v648_12_result = unite(v648_12_result,v649_13);
  }
  const Space v648_12 = std::move(v648_12_result);
  return v648_12;
}

static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v658_9_result;
  for (int v658_9_label = 1; v658_9_label <= 2; ++v658_9_label) {
    const Space v658_9_tail = child(s0,v658_9_label);
    if (v658_9_tail.empty()) continue;
    const Path v658_9_head{v658_9_label};
    const Space v659_2 = singleton(v658_9_head);
    const Space v659_3 = intersect(constant_3,v659_2);
    const Space v659_4 = (has_head(v659_3) ? constant_4 : Space{});
    const Space v659_5 = subtract(constant_2,v659_4);
    Space v659_8;
    if (!v659_5.empty()) {
      const Path v660_6 = concat_path(p0,v658_9_head);
      Space v660_7_result;
      for (int v660_7_label = 1; v660_7_label <= 2; ++v660_7_label) {
        const Space v660_7_tail = child(v658_9_tail,v660_7_label);
        if (v660_7_tail.empty()) continue;
        const Path v660_7_head{v660_7_label};
        const Space v661_2 = singleton(v660_7_head);
        const Space v661_3 = intersect(constant_3,v661_2);
        const Space v661_4 = (has_head(v661_3) ? constant_4 : Space{});
        const Space v661_5 = subtract(constant_2,v661_4);
        Space v661_8;
        if (!v661_5.empty()) {
          const Path v662_6 = concat_path(v660_6,v660_7_head);
          const Space v662_7 = routine_110(c, v662_6, p1, v660_7_tail);
          v661_8 = compose(v661_5,v662_7);
        }
        const Space v661_9 = intersect(constant_3,v661_2);
        const Space v661_10 = (has_head(v661_9) ? constant_4 : Space{});
        Space v661_12;
        if (!v661_10.empty()) {
          const Path v663_6 = concat_path(v660_6,v660_7_head);
          const Space v663_11 = routine_111(c, v663_6, p1, v660_7_tail);
          v661_12 = compose(v661_10,v663_11);
        }
        const Space v661_13 = unite(v661_8,v661_12);
        v660_7_result = unite(v660_7_result,v661_13);
      }
      const Space v660_7 = std::move(v660_7_result);
      v659_8 = compose(v659_5,v660_7);
    }
    const Space v659_9 = intersect(constant_3,v659_2);
    const Space v659_10 = (has_head(v659_9) ? constant_4 : Space{});
    const Space v659_11 = compose(v659_10,v658_9_tail);
    const Path v664_6 = concat_path(p0,v658_9_head);
    const Space v659_12 = wrap(v659_11,v664_6);
    const Space v659_13 = wrap(v659_12,p1);
    const Space v659_14 = unite(v659_8,v659_13);
    v658_9_result = unite(v658_9_result,v659_14);
  }
  const Space v658_9 = std::move(v658_9_result);
  return v658_9;
}

static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v665_3 = wrap(s0,p0);
  const Space v665_4 = wrap(v665_3,p1);
  return v665_4;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  Space v666_11_result;
  for (int v666_11_label = 1; v666_11_label <= 2; ++v666_11_label) {
    const Space v666_11_tail = child(s0,v666_11_label);
    if (v666_11_tail.empty()) continue;
    const Path v666_11_head{v666_11_label};
    const Space v667_2 = singleton(v666_11_head);
    const Space v667_3 = intersect(constant_3,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_4 : Space{});
    const Space v667_5 = subtract(constant_2,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_11_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_11_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_3,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_4 : Space{});
        const Space v669_5 = subtract(constant_2,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_112(c, v670_6, v668_7_tail);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_3,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_4 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_113(c, v671_6, v668_7_tail);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_3,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_4 : Space{});
    Space v667_12;
    if (!v667_10.empty()) {
      const Path v672_6 = concat_path(p0,v666_11_head);
      Space v672_11_result;
      for (int v672_11_label = 1; v672_11_label <= 2; ++v672_11_label) {
        const Space v672_11_tail = child(v666_11_tail,v672_11_label);
        if (v672_11_tail.empty()) continue;
        const Path v672_11_head{v672_11_label};
        const Space v673_2 = singleton(v672_11_head);
        const Space v673_3 = intersect(constant_3,v673_2);
        const Space v673_4 = (has_head(v673_3) ? constant_4 : Space{});
        const Space v673_5 = subtract(constant_2,v673_4);
        Space v673_8;
        if (!v673_5.empty()) {
          const Path v674_6 = concat_path(v672_6,v672_11_head);
          const Space v674_7 = routine_112(c, v674_6, v672_11_tail);
          v673_8 = compose(v673_5,v674_7);
        }
        const Space v673_9 = intersect(constant_3,v673_2);
        const Space v673_10 = (has_head(v673_9) ? constant_4 : Space{});
        Space v673_12;
        if (!v673_10.empty()) {
          const Path v675_6 = concat_path(v672_6,v672_11_head);
          const Space v675_11 = routine_9(c, v675_6, v672_11_tail);
          v673_12 = compose(v673_10,v675_11);
        }
        const Space v673_13 = unite(v673_8,v673_12);
        v672_11_result = unite(v672_11_result,v673_13);
      }
      const Space v672_11 = std::move(v672_11_result);
      v667_12 = compose(v667_10,v672_11);
    }
    const Space v667_13 = unite(v667_8,v667_12);
    v666_11_result = unite(v666_11_result,v667_13);
  }
  const Space v666_11 = std::move(v666_11_result);
  return v666_11;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  Space v676_11_result;
  for (int v676_11_label = 1; v676_11_label <= 2; ++v676_11_label) {
    const Space v676_11_tail = child(s0,v676_11_label);
    if (v676_11_tail.empty()) continue;
    const Path v676_11_head{v676_11_label};
    const Space v677_2 = singleton(v676_11_head);
    const Space v677_3 = intersect(constant_3,v677_2);
    const Space v677_4 = (has_head(v677_3) ? constant_4 : Space{});
    const Space v677_5 = subtract(constant_2,v677_4);
    Space v677_8;
    if (!v677_5.empty()) {
      const Path v678_6 = concat_path(p0,v676_11_head);
      Space v678_7_result;
      for (int v678_7_label = 1; v678_7_label <= 2; ++v678_7_label) {
        const Space v678_7_tail = child(v676_11_tail,v678_7_label);
        if (v678_7_tail.empty()) continue;
        const Path v678_7_head{v678_7_label};
        const Space v679_2 = singleton(v678_7_head);
        const Space v679_3 = intersect(constant_3,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_4 : Space{});
        const Space v679_5 = subtract(constant_2,v679_4);
        Space v679_8;
        if (!v679_5.empty()) {
          const Path v680_6 = concat_path(v678_6,v678_7_head);
          const Space v680_7 = routine_112(c, v680_6, v678_7_tail);
          v679_8 = compose(v679_5,v680_7);
        }
        const Space v679_9 = intersect(constant_3,v679_2);
        const Space v679_10 = (has_head(v679_9) ? constant_4 : Space{});
        Space v679_12;
        if (!v679_10.empty()) {
          const Path v681_6 = concat_path(v678_6,v678_7_head);
          const Space v681_11 = routine_113(c, v681_6, v678_7_tail);
          v679_12 = compose(v679_10,v681_11);
        }
        const Space v679_13 = unite(v679_8,v679_12);
        v678_7_result = unite(v678_7_result,v679_13);
      }
      const Space v678_7 = std::move(v678_7_result);
      v677_8 = compose(v677_5,v678_7);
    }
    const Space v677_9 = intersect(constant_3,v677_2);
    const Space v677_10 = (has_head(v677_9) ? constant_4 : Space{});
    Space v677_12;
    if (!v677_10.empty()) {
      const Path v682_6 = concat_path(p0,v676_11_head);
      Space v682_11_result;
      for (int v682_11_label = 1; v682_11_label <= 2; ++v682_11_label) {
        const Space v682_11_tail = child(v676_11_tail,v682_11_label);
        if (v682_11_tail.empty()) continue;
        const Path v682_11_head{v682_11_label};
        const Space v683_2 = singleton(v682_11_head);
        const Space v683_3 = intersect(constant_3,v683_2);
        const Space v683_4 = (has_head(v683_3) ? constant_4 : Space{});
        const Space v683_5 = subtract(constant_2,v683_4);
        Space v683_7;
        if (!v683_5.empty()) {
          const Space v684_6 = routine_32(c, v682_11_head, v682_6, v682_11_tail);
          v683_7 = compose(v683_5,v684_6);
        }
        const Space v683_8 = intersect(constant_3,v683_2);
        const Space v683_9 = (has_head(v683_8) ? constant_4 : Space{});
        Space v683_11;
        if (!v683_9.empty()) {
          const Space v685_10 = routine_33(c, v682_11_head, v682_6, v682_11_tail);
          v683_11 = compose(v683_9,v685_10);
        }
        const Space v683_12 = unite(v683_7,v683_11);
        v682_11_result = unite(v682_11_result,v683_12);
      }
      const Space v682_11 = std::move(v682_11_result);
      v677_12 = compose(v677_10,v682_11);
    }
    const Space v677_13 = unite(v677_8,v677_12);
    v676_11_result = unite(v676_11_result,v677_13);
  }
  const Space v676_11 = std::move(v676_11_result);
  return v676_11;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v686_12_result;
  for (int v686_12_label = 1; v686_12_label <= 2; ++v686_12_label) {
    const Space v686_12_tail = child(s0,v686_12_label);
    if (v686_12_tail.empty()) continue;
    const Path v686_12_head{v686_12_label};
    const Space v687_2 = singleton(v686_12_head);
    const Space v687_3 = intersect(constant_3,v687_2);
    const Space v687_4 = (has_head(v687_3) ? constant_4 : Space{});
    const Space v687_5 = subtract(constant_2,v687_4);
    Space v687_8;
    if (!v687_5.empty()) {
      const Path v688_6 = concat_path(p0,v686_12_head);
      Space v688_7_result;
      for (int v688_7_label = 1; v688_7_label <= 2; ++v688_7_label) {
        const Space v688_7_tail = child(v686_12_tail,v688_7_label);
        if (v688_7_tail.empty()) continue;
        const Path v688_7_head{v688_7_label};
        const Space v689_2 = singleton(v688_7_head);
        const Space v689_3 = intersect(constant_3,v689_2);
        const Space v689_4 = (has_head(v689_3) ? constant_4 : Space{});
        const Space v689_5 = subtract(constant_2,v689_4);
        Space v689_8;
        if (!v689_5.empty()) {
          const Path v690_6 = concat_path(v688_6,v688_7_head);
          const Space v690_7 = routine_114(c, v690_6, p1, v688_7_tail);
          v689_8 = compose(v689_5,v690_7);
        }
        const Space v689_9 = intersect(constant_3,v689_2);
        const Space v689_10 = (has_head(v689_9) ? constant_4 : Space{});
        Space v689_12;
        if (!v689_10.empty()) {
          const Path v691_6 = concat_path(v688_6,v688_7_head);
          const Space v691_11 = routine_115(c, v691_6, p1, v688_7_tail);
          v689_12 = compose(v689_10,v691_11);
        }
        const Space v689_13 = unite(v689_8,v689_12);
        v688_7_result = unite(v688_7_result,v689_13);
      }
      const Space v688_7 = std::move(v688_7_result);
      v687_8 = compose(v687_5,v688_7);
    }
    const Space v687_9 = intersect(constant_3,v687_2);
    const Space v687_10 = (has_head(v687_9) ? constant_4 : Space{});
    Space v687_12;
    if (!v687_10.empty()) {
      const Path v692_6 = concat_path(p0,v686_12_head);
      Space v692_11_result;
      for (int v692_11_label = 1; v692_11_label <= 2; ++v692_11_label) {
        const Space v692_11_tail = child(v686_12_tail,v692_11_label);
        if (v692_11_tail.empty()) continue;
        const Path v692_11_head{v692_11_label};
        const Space v693_2 = singleton(v692_11_head);
        const Space v693_3 = intersect(constant_3,v693_2);
        const Space v693_4 = (has_head(v693_3) ? constant_4 : Space{});
        const Space v693_5 = subtract(constant_2,v693_4);
        Space v693_8;
        if (!v693_5.empty()) {
          const Path v694_6 = concat_path(v692_6,v692_11_head);
          const Space v694_7 = routine_114(c, v694_6, p1, v692_11_tail);
          v693_8 = compose(v693_5,v694_7);
        }
        const Space v693_9 = intersect(constant_3,v693_2);
        const Space v693_10 = (has_head(v693_9) ? constant_4 : Space{});
        Space v693_12;
        if (!v693_10.empty()) {
          const Path v695_6 = concat_path(v692_6,v692_11_head);
          const Space v695_11 = routine_36(c, v695_6, p1, v692_11_tail);
          v693_12 = compose(v693_10,v695_11);
        }
        const Space v693_13 = unite(v693_8,v693_12);
        v692_11_result = unite(v692_11_result,v693_13);
      }
      const Space v692_11 = std::move(v692_11_result);
      v687_12 = compose(v687_10,v692_11);
    }
    const Space v687_13 = unite(v687_8,v687_12);
    v686_12_result = unite(v686_12_result,v687_13);
  }
  const Space v686_12 = std::move(v686_12_result);
  return v686_12;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v696_9_result;
  for (int v696_9_label = 1; v696_9_label <= 2; ++v696_9_label) {
    const Space v696_9_tail = child(s0,v696_9_label);
    if (v696_9_tail.empty()) continue;
    const Path v696_9_head{v696_9_label};
    const Space v697_2 = singleton(v696_9_head);
    const Space v697_3 = intersect(constant_3,v697_2);
    const Space v697_4 = (has_head(v697_3) ? constant_4 : Space{});
    const Space v697_5 = subtract(constant_2,v697_4);
    Space v697_8;
    if (!v697_5.empty()) {
      const Path v698_6 = concat_path(p0,v696_9_head);
      Space v698_7_result;
      for (int v698_7_label = 1; v698_7_label <= 2; ++v698_7_label) {
        const Space v698_7_tail = child(v696_9_tail,v698_7_label);
        if (v698_7_tail.empty()) continue;
        const Path v698_7_head{v698_7_label};
        const Space v699_2 = singleton(v698_7_head);
        const Space v699_3 = intersect(constant_3,v699_2);
        const Space v699_4 = (has_head(v699_3) ? constant_4 : Space{});
        const Space v699_5 = subtract(constant_2,v699_4);
        Space v699_8;
        if (!v699_5.empty()) {
          const Path v700_6 = concat_path(v698_6,v698_7_head);
          const Space v700_7 = routine_114(c, v700_6, p1, v698_7_tail);
          v699_8 = compose(v699_5,v700_7);
        }
        const Space v699_9 = intersect(constant_3,v699_2);
        const Space v699_10 = (has_head(v699_9) ? constant_4 : Space{});
        Space v699_12;
        if (!v699_10.empty()) {
          const Path v701_6 = concat_path(v698_6,v698_7_head);
          const Space v701_11 = routine_115(c, v701_6, p1, v698_7_tail);
          v699_12 = compose(v699_10,v701_11);
        }
        const Space v699_13 = unite(v699_8,v699_12);
        v698_7_result = unite(v698_7_result,v699_13);
      }
      const Space v698_7 = std::move(v698_7_result);
      v697_8 = compose(v697_5,v698_7);
    }
    const Space v697_9 = intersect(constant_3,v697_2);
    const Space v697_10 = (has_head(v697_9) ? constant_4 : Space{});
    const Space v697_11 = compose(v697_10,v696_9_tail);
    const Path v702_6 = concat_path(p0,v696_9_head);
    const Space v697_12 = wrap(v697_11,v702_6);
    const Space v697_13 = wrap(v697_12,p1);
    const Space v697_14 = unite(v697_8,v697_13);
    v696_9_result = unite(v696_9_result,v697_14);
  }
  const Space v696_9 = std::move(v696_9_result);
  return v696_9;
}

static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v703_12_result;
  for (int v703_12_label = 1; v703_12_label <= 2; ++v703_12_label) {
    const Space v703_12_tail = child(s0,v703_12_label);
    if (v703_12_tail.empty()) continue;
    const Path v703_12_head{v703_12_label};
    const Space v704_2 = singleton(v703_12_head);
    const Space v704_3 = intersect(constant_3,v704_2);
    const Space v704_4 = (has_head(v704_3) ? constant_4 : Space{});
    const Space v704_5 = subtract(constant_2,v704_4);
    Space v704_8;
    if (!v704_5.empty()) {
      const Path v705_6 = concat_path(p0,v703_12_head);
      Space v705_7_result;
      for (int v705_7_label = 1; v705_7_label <= 2; ++v705_7_label) {
        const Space v705_7_tail = child(v703_12_tail,v705_7_label);
        if (v705_7_tail.empty()) continue;
        const Path v705_7_head{v705_7_label};
        const Space v706_2 = singleton(v705_7_head);
        const Space v706_3 = intersect(constant_3,v706_2);
        const Space v706_4 = (has_head(v706_3) ? constant_4 : Space{});
        const Space v706_5 = subtract(constant_2,v706_4);
        Space v706_8;
        if (!v706_5.empty()) {
          const Path v707_6 = concat_path(v705_6,v705_7_head);
          const Space v707_7 = routine_116(c, v707_6, p1, v705_7_tail);
          v706_8 = compose(v706_5,v707_7);
        }
        const Space v706_9 = intersect(constant_3,v706_2);
        const Space v706_10 = (has_head(v706_9) ? constant_4 : Space{});
        Space v706_12;
        if (!v706_10.empty()) {
          const Path v708_6 = concat_path(v705_6,v705_7_head);
          const Space v708_11 = routine_117(c, v708_6, p1, v705_7_tail);
          v706_12 = compose(v706_10,v708_11);
        }
        const Space v706_13 = unite(v706_8,v706_12);
        v705_7_result = unite(v705_7_result,v706_13);
      }
      const Space v705_7 = std::move(v705_7_result);
      v704_8 = compose(v704_5,v705_7);
    }
    const Space v704_9 = intersect(constant_3,v704_2);
    const Space v704_10 = (has_head(v704_9) ? constant_4 : Space{});
    Space v704_12;
    if (!v704_10.empty()) {
      const Path v709_6 = concat_path(p0,v703_12_head);
      Space v709_11_result;
      for (int v709_11_label = 1; v709_11_label <= 2; ++v709_11_label) {
        const Space v709_11_tail = child(v703_12_tail,v709_11_label);
        if (v709_11_tail.empty()) continue;
        const Path v709_11_head{v709_11_label};
        const Space v710_2 = singleton(v709_11_head);
        const Space v710_3 = intersect(constant_3,v710_2);
        const Space v710_4 = (has_head(v710_3) ? constant_4 : Space{});
        const Space v710_5 = subtract(constant_2,v710_4);
        Space v710_8;
        if (!v710_5.empty()) {
          const Path v711_6 = concat_path(v709_6,v709_11_head);
          const Space v711_7 = routine_116(c, v711_6, p1, v709_11_tail);
          v710_8 = compose(v710_5,v711_7);
        }
        const Space v710_9 = intersect(constant_3,v710_2);
        const Space v710_10 = (has_head(v710_9) ? constant_4 : Space{});
        Space v710_12;
        if (!v710_10.empty()) {
          const Path v712_6 = concat_path(v709_6,v709_11_head);
          const Space v712_11 = routine_36(c, v712_6, p1, v709_11_tail);
          v710_12 = compose(v710_10,v712_11);
        }
        const Space v710_13 = unite(v710_8,v710_12);
        v709_11_result = unite(v709_11_result,v710_13);
      }
      const Space v709_11 = std::move(v709_11_result);
      v704_12 = compose(v704_10,v709_11);
    }
    const Space v704_13 = unite(v704_8,v704_12);
    v703_12_result = unite(v703_12_result,v704_13);
  }
  const Space v703_12 = std::move(v703_12_result);
  return v703_12;
}

static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v713_9_result;
  for (int v713_9_label = 1; v713_9_label <= 2; ++v713_9_label) {
    const Space v713_9_tail = child(s0,v713_9_label);
    if (v713_9_tail.empty()) continue;
    const Path v713_9_head{v713_9_label};
    const Space v714_2 = singleton(v713_9_head);
    const Space v714_3 = intersect(constant_3,v714_2);
    const Space v714_4 = (has_head(v714_3) ? constant_4 : Space{});
    const Space v714_5 = subtract(constant_2,v714_4);
    Space v714_8;
    if (!v714_5.empty()) {
      const Path v715_6 = concat_path(p0,v713_9_head);
      Space v715_7_result;
      for (int v715_7_label = 1; v715_7_label <= 2; ++v715_7_label) {
        const Space v715_7_tail = child(v713_9_tail,v715_7_label);
        if (v715_7_tail.empty()) continue;
        const Path v715_7_head{v715_7_label};
        const Space v716_2 = singleton(v715_7_head);
        const Space v716_3 = intersect(constant_3,v716_2);
        const Space v716_4 = (has_head(v716_3) ? constant_4 : Space{});
        const Space v716_5 = subtract(constant_2,v716_4);
        Space v716_8;
        if (!v716_5.empty()) {
          const Path v717_6 = concat_path(v715_6,v715_7_head);
          const Space v717_7 = routine_116(c, v717_6, p1, v715_7_tail);
          v716_8 = compose(v716_5,v717_7);
        }
        const Space v716_9 = intersect(constant_3,v716_2);
        const Space v716_10 = (has_head(v716_9) ? constant_4 : Space{});
        Space v716_12;
        if (!v716_10.empty()) {
          const Path v718_6 = concat_path(v715_6,v715_7_head);
          const Space v718_11 = routine_117(c, v718_6, p1, v715_7_tail);
          v716_12 = compose(v716_10,v718_11);
        }
        const Space v716_13 = unite(v716_8,v716_12);
        v715_7_result = unite(v715_7_result,v716_13);
      }
      const Space v715_7 = std::move(v715_7_result);
      v714_8 = compose(v714_5,v715_7);
    }
    const Space v714_9 = intersect(constant_3,v714_2);
    const Space v714_10 = (has_head(v714_9) ? constant_4 : Space{});
    const Space v714_11 = compose(v714_10,v713_9_tail);
    const Path v719_6 = concat_path(p0,v713_9_head);
    const Space v714_12 = wrap(v714_11,v719_6);
    const Space v714_13 = wrap(v714_12,p1);
    const Space v714_14 = unite(v714_8,v714_13);
    v713_9_result = unite(v713_9_result,v714_14);
  }
  const Space v713_9 = std::move(v713_9_result);
  return v713_9;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v720_12_result;
  for (int v720_12_label = 1; v720_12_label <= 2; ++v720_12_label) {
    const Space v720_12_tail = child(s0,v720_12_label);
    if (v720_12_tail.empty()) continue;
    const Path v720_12_head{v720_12_label};
    const Space v721_2 = singleton(v720_12_head);
    const Space v721_3 = intersect(constant_3,v721_2);
    const Space v721_4 = (has_head(v721_3) ? constant_4 : Space{});
    const Space v721_5 = subtract(constant_2,v721_4);
    Space v721_8;
    if (!v721_5.empty()) {
      const Path v722_6 = concat_path(p0,v720_12_head);
      Space v722_7_result;
      for (int v722_7_label = 1; v722_7_label <= 2; ++v722_7_label) {
        const Space v722_7_tail = child(v720_12_tail,v722_7_label);
        if (v722_7_tail.empty()) continue;
        const Path v722_7_head{v722_7_label};
        const Space v723_2 = singleton(v722_7_head);
        const Space v723_3 = intersect(constant_3,v723_2);
        const Space v723_4 = (has_head(v723_3) ? constant_4 : Space{});
        const Space v723_5 = subtract(constant_2,v723_4);
        Space v723_8;
        if (!v723_5.empty()) {
          const Path v724_6 = concat_path(v722_6,v722_7_head);
          const Space v724_7 = routine_118(c, v724_6, v722_7_tail, s1);
          v723_8 = compose(v723_5,v724_7);
        }
        const Space v723_9 = intersect(constant_3,v723_2);
        const Space v723_10 = (has_head(v723_9) ? constant_4 : Space{});
        Space v723_12;
        if (!v723_10.empty()) {
          const Path v725_6 = concat_path(v722_6,v722_7_head);
          const Space v725_11 = routine_119(c, v725_6, v722_7_tail, s1);
          v723_12 = compose(v723_10,v725_11);
        }
        const Space v723_13 = unite(v723_8,v723_12);
        v722_7_result = unite(v722_7_result,v723_13);
      }
      const Space v722_7 = std::move(v722_7_result);
      v721_8 = compose(v721_5,v722_7);
    }
    const Space v721_9 = intersect(constant_3,v721_2);
    const Space v721_10 = (has_head(v721_9) ? constant_4 : Space{});
    Space v721_12;
    if (!v721_10.empty()) {
      const Path v726_6 = concat_path(p0,v720_12_head);
      Space v726_11_result;
      for (int v726_11_label = 1; v726_11_label <= 2; ++v726_11_label) {
        const Space v726_11_tail = child(v720_12_tail,v726_11_label);
        if (v726_11_tail.empty()) continue;
        const Path v726_11_head{v726_11_label};
        const Space v727_2 = singleton(v726_11_head);
        const Space v727_3 = intersect(constant_3,v727_2);
        const Space v727_4 = (has_head(v727_3) ? constant_4 : Space{});
        const Space v727_5 = subtract(constant_2,v727_4);
        Space v727_8;
        if (!v727_5.empty()) {
          const Path v728_6 = concat_path(v726_6,v726_11_head);
          const Space v728_7 = routine_118(c, v728_6, v726_11_tail, s1);
          v727_8 = compose(v727_5,v728_7);
        }
        const Space v727_9 = intersect(constant_3,v727_2);
        const Space v727_10 = (has_head(v727_9) ? constant_4 : Space{});
        Space v727_12;
        if (!v727_10.empty()) {
          const Path v729_6 = concat_path(v726_6,v726_11_head);
          const Space v729_11 = routine_12(c, v729_6, v726_11_tail, s1);
          v727_12 = compose(v727_10,v729_11);
        }
        const Space v727_13 = unite(v727_8,v727_12);
        v726_11_result = unite(v726_11_result,v727_13);
      }
      const Space v726_11 = std::move(v726_11_result);
      v721_12 = compose(v721_10,v726_11);
    }
    const Space v721_13 = unite(v721_8,v721_12);
    v720_12_result = unite(v720_12_result,v721_13);
  }
  const Space v720_12 = std::move(v720_12_result);
  return v720_12;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v730_12_result;
  for (int v730_12_label = 1; v730_12_label <= 2; ++v730_12_label) {
    const Space v730_12_tail = child(s0,v730_12_label);
    if (v730_12_tail.empty()) continue;
    const Path v730_12_head{v730_12_label};
    const Space v731_2 = singleton(v730_12_head);
    const Space v731_3 = intersect(constant_3,v731_2);
    const Space v731_4 = (has_head(v731_3) ? constant_4 : Space{});
    const Space v731_5 = subtract(constant_2,v731_4);
    Space v731_8;
    if (!v731_5.empty()) {
      const Path v732_6 = concat_path(p0,v730_12_head);
      Space v732_7_result;
      for (int v732_7_label = 1; v732_7_label <= 2; ++v732_7_label) {
        const Space v732_7_tail = child(v730_12_tail,v732_7_label);
        if (v732_7_tail.empty()) continue;
        const Path v732_7_head{v732_7_label};
        const Space v733_2 = singleton(v732_7_head);
        const Space v733_3 = intersect(constant_3,v733_2);
        const Space v733_4 = (has_head(v733_3) ? constant_4 : Space{});
        const Space v733_5 = subtract(constant_2,v733_4);
        Space v733_8;
        if (!v733_5.empty()) {
          const Path v734_6 = concat_path(v732_6,v732_7_head);
          const Space v734_7 = routine_118(c, v734_6, v732_7_tail, s1);
          v733_8 = compose(v733_5,v734_7);
        }
        const Space v733_9 = intersect(constant_3,v733_2);
        const Space v733_10 = (has_head(v733_9) ? constant_4 : Space{});
        Space v733_12;
        if (!v733_10.empty()) {
          const Path v735_6 = concat_path(v732_6,v732_7_head);
          const Space v735_11 = routine_119(c, v735_6, v732_7_tail, s1);
          v733_12 = compose(v733_10,v735_11);
        }
        const Space v733_13 = unite(v733_8,v733_12);
        v732_7_result = unite(v732_7_result,v733_13);
      }
      const Space v732_7 = std::move(v732_7_result);
      v731_8 = compose(v731_5,v732_7);
    }
    const Space v731_9 = intersect(constant_3,v731_2);
    const Space v731_10 = (has_head(v731_9) ? constant_4 : Space{});
    Space v731_12;
    if (!v731_10.empty()) {
      const Path v736_6 = concat_path(p0,v730_12_head);
      Space v736_11_result;
      for (int v736_11_label = 1; v736_11_label <= 2; ++v736_11_label) {
        const Space v736_11_tail = child(v730_12_tail,v736_11_label);
        if (v736_11_tail.empty()) continue;
        const Path v736_11_head{v736_11_label};
        const Space v737_2 = singleton(v736_11_head);
        const Space v737_3 = intersect(constant_3,v737_2);
        const Space v737_4 = (has_head(v737_3) ? constant_4 : Space{});
        const Space v737_5 = subtract(constant_2,v737_4);
        Space v737_7;
        if (!v737_5.empty()) {
          const Space v738_6 = routine_39(c, v736_11_head, v736_6, v736_11_tail, s1);
          v737_7 = compose(v737_5,v738_6);
        }
        const Space v737_8 = intersect(constant_3,v737_2);
        const Space v737_9 = (has_head(v737_8) ? constant_4 : Space{});
        Space v737_11;
        if (!v737_9.empty()) {
          const Space v739_10 = routine_40(c, v736_11_head, v736_6, v736_11_tail, s1);
          v737_11 = compose(v737_9,v739_10);
        }
        const Space v737_12 = unite(v737_7,v737_11);
        v736_11_result = unite(v736_11_result,v737_12);
      }
      const Space v736_11 = std::move(v736_11_result);
      v731_12 = compose(v731_10,v736_11);
    }
    const Space v731_13 = unite(v731_8,v731_12);
    v730_12_result = unite(v730_12_result,v731_13);
  }
  const Space v730_12 = std::move(v730_12_result);
  return v730_12;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v740_13_result;
  for (int v740_13_label = 1; v740_13_label <= 2; ++v740_13_label) {
    const Space v740_13_tail = child(s0,v740_13_label);
    if (v740_13_tail.empty()) continue;
    const Path v740_13_head{v740_13_label};
    const Space v741_2 = singleton(v740_13_head);
    const Space v741_3 = intersect(constant_3,v741_2);
    const Space v741_4 = (has_head(v741_3) ? constant_4 : Space{});
    const Space v741_5 = subtract(constant_2,v741_4);
    Space v741_8;
    if (!v741_5.empty()) {
      const Path v742_6 = concat_path(p0,v740_13_head);
      Space v742_7_result;
      for (int v742_7_label = 1; v742_7_label <= 2; ++v742_7_label) {
        const Space v742_7_tail = child(v740_13_tail,v742_7_label);
        if (v742_7_tail.empty()) continue;
        const Path v742_7_head{v742_7_label};
        const Space v743_2 = singleton(v742_7_head);
        const Space v743_3 = intersect(constant_3,v743_2);
        const Space v743_4 = (has_head(v743_3) ? constant_4 : Space{});
        const Space v743_5 = subtract(constant_2,v743_4);
        Space v743_8;
        if (!v743_5.empty()) {
          const Path v744_6 = concat_path(v742_6,v742_7_head);
          const Space v744_7 = routine_120(c, v744_6, p1, v742_7_tail, s1);
          v743_8 = compose(v743_5,v744_7);
        }
        const Space v743_9 = intersect(constant_3,v743_2);
        const Space v743_10 = (has_head(v743_9) ? constant_4 : Space{});
        Space v743_12;
        if (!v743_10.empty()) {
          const Path v745_6 = concat_path(v742_6,v742_7_head);
          const Space v745_11 = routine_121(c, v745_6, p1, v742_7_tail, s1);
          v743_12 = compose(v743_10,v745_11);
        }
        const Space v743_13 = unite(v743_8,v743_12);
        v742_7_result = unite(v742_7_result,v743_13);
      }
      const Space v742_7 = std::move(v742_7_result);
      v741_8 = compose(v741_5,v742_7);
    }
    const Space v741_9 = intersect(constant_3,v741_2);
    const Space v741_10 = (has_head(v741_9) ? constant_4 : Space{});
    Space v741_12;
    if (!v741_10.empty()) {
      const Path v746_6 = concat_path(p0,v740_13_head);
      Space v746_11_result;
      for (int v746_11_label = 1; v746_11_label <= 2; ++v746_11_label) {
        const Space v746_11_tail = child(v740_13_tail,v746_11_label);
        if (v746_11_tail.empty()) continue;
        const Path v746_11_head{v746_11_label};
        const Space v747_2 = singleton(v746_11_head);
        const Space v747_3 = intersect(constant_3,v747_2);
        const Space v747_4 = (has_head(v747_3) ? constant_4 : Space{});
        const Space v747_5 = subtract(constant_2,v747_4);
        Space v747_8;
        if (!v747_5.empty()) {
          const Path v748_6 = concat_path(v746_6,v746_11_head);
          const Space v748_7 = routine_120(c, v748_6, p1, v746_11_tail, s1);
          v747_8 = compose(v747_5,v748_7);
        }
        const Space v747_9 = intersect(constant_3,v747_2);
        const Space v747_10 = (has_head(v747_9) ? constant_4 : Space{});
        Space v747_12;
        if (!v747_10.empty()) {
          const Path v749_6 = concat_path(v746_6,v746_11_head);
          const Space v749_11 = routine_43(c, v749_6, p1, v746_11_tail, s1);
          v747_12 = compose(v747_10,v749_11);
        }
        const Space v747_13 = unite(v747_8,v747_12);
        v746_11_result = unite(v746_11_result,v747_13);
      }
      const Space v746_11 = std::move(v746_11_result);
      v741_12 = compose(v741_10,v746_11);
    }
    const Space v741_13 = unite(v741_8,v741_12);
    v740_13_result = unite(v740_13_result,v741_13);
  }
  const Space v740_13 = std::move(v740_13_result);
  return v740_13;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v750_8 = unwrap(s1,constant_0);
  const Space v750_10 = unwrap(v750_8,constant_6);
  const Space v750_11 = unwrap(v750_10,p0);
  Space v750_18_result;
  for (int v750_18_label = 1; v750_18_label <= 2; ++v750_18_label) {
    const Space v750_18_tail = child(s0,v750_18_label);
    if (v750_18_tail.empty()) continue;
    const Path v750_18_head{v750_18_label};
    const Space v751_2 = singleton(v750_18_head);
    const Space v751_3 = intersect(constant_3,v751_2);
    const Space v751_4 = (has_head(v751_3) ? constant_4 : Space{});
    const Space v751_5 = subtract(constant_2,v751_4);
    Space v751_8;
    if (!v751_5.empty()) {
      const Path v752_6 = concat_path(p0,v750_18_head);
      Space v752_7_result;
      for (int v752_7_label = 1; v752_7_label <= 2; ++v752_7_label) {
        const Space v752_7_tail = child(v750_18_tail,v752_7_label);
        if (v752_7_tail.empty()) continue;
        const Path v752_7_head{v752_7_label};
        const Space v753_2 = singleton(v752_7_head);
        const Space v753_3 = intersect(constant_3,v753_2);
        const Space v753_4 = (has_head(v753_3) ? constant_4 : Space{});
        const Space v753_5 = subtract(constant_2,v753_4);
        Space v753_8;
        if (!v753_5.empty()) {
          const Path v754_6 = concat_path(v752_6,v752_7_head);
          const Space v754_7 = routine_120(c, v754_6, p1, v752_7_tail, s1);
          v753_8 = compose(v753_5,v754_7);
        }
        const Space v753_9 = intersect(constant_3,v753_2);
        const Space v753_10 = (has_head(v753_9) ? constant_4 : Space{});
        Space v753_12;
        if (!v753_10.empty()) {
          const Path v755_6 = concat_path(v752_6,v752_7_head);
          const Space v755_11 = routine_121(c, v755_6, p1, v752_7_tail, s1);
          v753_12 = compose(v753_10,v755_11);
        }
        const Space v753_13 = unite(v753_8,v753_12);
        v752_7_result = unite(v752_7_result,v753_13);
      }
      const Space v752_7 = std::move(v752_7_result);
      v751_8 = compose(v751_5,v752_7);
    }
    const Space v751_9 = intersect(constant_3,v751_2);
    const Space v751_10 = (has_head(v751_9) ? constant_4 : Space{});
    Space v751_13;
    if (!v751_10.empty()) {
      const Space v756_11 = unwrap(v750_11,v750_18_head);
      Space v756_12_result;
      for (int v756_12_label = 1; v756_12_label <= 2; ++v756_12_label) {
        const Space v756_12_tail = child(v756_11,v756_12_label);
        if (v756_12_tail.empty()) continue;
        const Path v756_12_head{v756_12_label};
        const Space v757_2 = singleton(v756_12_head);
        const Space v757_3 = intersect(constant_3,v757_2);
        const Space v757_4 = (has_head(v757_3) ? constant_4 : Space{});
        const Space v757_5 = subtract(constant_2,v757_4);
        Space v757_7;
        if (!v757_5.empty()) {
          const Space v758_6 = routine_78(c, v756_12_head, p1, v756_12_tail);
          v757_7 = compose(v757_5,v758_6);
        }
        const Space v757_8 = intersect(constant_3,v757_2);
        const Space v757_9 = (has_head(v757_8) ? constant_4 : Space{});
        Space v757_11;
        if (!v757_9.empty()) {
          const Space v759_10 = routine_79(c, v756_12_head, p1, v756_12_tail);
          v757_11 = compose(v757_9,v759_10);
        }
        const Space v757_12 = unite(v757_7,v757_11);
        v756_12_result = unite(v756_12_result,v757_12);
      }
      const Space v756_12 = std::move(v756_12_result);
      v751_13 = compose(v751_10,v756_12);
    }
    const Space v751_14 = unite(v751_8,v751_13);
    v750_18_result = unite(v750_18_result,v751_14);
  }
  const Space v750_18 = std::move(v750_18_result);
  return v750_18;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v760_12_result;
  for (int v760_12_label = 1; v760_12_label <= 2; ++v760_12_label) {
    const Space v760_12_tail = child(s0,v760_12_label);
    if (v760_12_tail.empty()) continue;
    const Path v760_12_head{v760_12_label};
    const Space v761_2 = singleton(v760_12_head);
    const Space v761_3 = intersect(constant_3,v761_2);
    const Space v761_4 = (has_head(v761_3) ? constant_4 : Space{});
    const Space v761_5 = subtract(constant_2,v761_4);
    Space v761_8;
    if (!v761_5.empty()) {
      const Path v762_6 = concat_path(p0,v760_12_head);
      Space v762_7_result;
      for (int v762_7_label = 1; v762_7_label <= 2; ++v762_7_label) {
        const Space v762_7_tail = child(v760_12_tail,v762_7_label);
        if (v762_7_tail.empty()) continue;
        const Path v762_7_head{v762_7_label};
        const Space v763_2 = singleton(v762_7_head);
        const Space v763_3 = intersect(constant_3,v763_2);
        const Space v763_4 = (has_head(v763_3) ? constant_4 : Space{});
        const Space v763_5 = subtract(constant_2,v763_4);
        Space v763_8;
        if (!v763_5.empty()) {
          const Path v764_6 = concat_path(v762_6,v762_7_head);
          const Space v764_7 = routine_122(c, v764_6, p1, v762_7_tail);
          v763_8 = compose(v763_5,v764_7);
        }
        const Space v763_9 = intersect(constant_3,v763_2);
        const Space v763_10 = (has_head(v763_9) ? constant_4 : Space{});
        Space v763_12;
        if (!v763_10.empty()) {
          const Path v765_6 = concat_path(v762_6,v762_7_head);
          const Space v765_11 = routine_123(c, v765_6, p1, v762_7_tail);
          v763_12 = compose(v763_10,v765_11);
        }
        const Space v763_13 = unite(v763_8,v763_12);
        v762_7_result = unite(v762_7_result,v763_13);
      }
      const Space v762_7 = std::move(v762_7_result);
      v761_8 = compose(v761_5,v762_7);
    }
    const Space v761_9 = intersect(constant_3,v761_2);
    const Space v761_10 = (has_head(v761_9) ? constant_4 : Space{});
    Space v761_12;
    if (!v761_10.empty()) {
      const Path v766_6 = concat_path(p0,v760_12_head);
      Space v766_11_result;
      for (int v766_11_label = 1; v766_11_label <= 2; ++v766_11_label) {
        const Space v766_11_tail = child(v760_12_tail,v766_11_label);
        if (v766_11_tail.empty()) continue;
        const Path v766_11_head{v766_11_label};
        const Space v767_2 = singleton(v766_11_head);
        const Space v767_3 = intersect(constant_3,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_4 : Space{});
        const Space v767_5 = subtract(constant_2,v767_4);
        Space v767_8;
        if (!v767_5.empty()) {
          const Path v768_6 = concat_path(v766_6,v766_11_head);
          const Space v768_7 = routine_122(c, v768_6, p1, v766_11_tail);
          v767_8 = compose(v767_5,v768_7);
        }
        const Space v767_9 = intersect(constant_3,v767_2);
        const Space v767_10 = (has_head(v767_9) ? constant_4 : Space{});
        Space v767_12;
        if (!v767_10.empty()) {
          const Path v769_6 = concat_path(v766_6,v766_11_head);
          const Space v769_11 = routine_84(c, v769_6, p1, v766_11_tail);
          v767_12 = compose(v767_10,v769_11);
        }
        const Space v767_13 = unite(v767_8,v767_12);
        v766_11_result = unite(v766_11_result,v767_13);
      }
      const Space v766_11 = std::move(v766_11_result);
      v761_12 = compose(v761_10,v766_11);
    }
    const Space v761_13 = unite(v761_8,v761_12);
    v760_12_result = unite(v760_12_result,v761_13);
  }
  const Space v760_12 = std::move(v760_12_result);
  return v760_12;
}

static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v770_9_result;
  for (int v770_9_label = 1; v770_9_label <= 2; ++v770_9_label) {
    const Space v770_9_tail = child(s0,v770_9_label);
    if (v770_9_tail.empty()) continue;
    const Path v770_9_head{v770_9_label};
    const Space v771_2 = singleton(v770_9_head);
    const Space v771_3 = intersect(constant_3,v771_2);
    const Space v771_4 = (has_head(v771_3) ? constant_4 : Space{});
    const Space v771_5 = subtract(constant_2,v771_4);
    Space v771_8;
    if (!v771_5.empty()) {
      const Path v772_6 = concat_path(p0,v770_9_head);
      Space v772_7_result;
      for (int v772_7_label = 1; v772_7_label <= 2; ++v772_7_label) {
        const Space v772_7_tail = child(v770_9_tail,v772_7_label);
        if (v772_7_tail.empty()) continue;
        const Path v772_7_head{v772_7_label};
        const Space v773_2 = singleton(v772_7_head);
        const Space v773_3 = intersect(constant_3,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_4 : Space{});
        const Space v773_5 = subtract(constant_2,v773_4);
        Space v773_8;
        if (!v773_5.empty()) {
          const Path v774_6 = concat_path(v772_6,v772_7_head);
          const Space v774_7 = routine_122(c, v774_6, p1, v772_7_tail);
          v773_8 = compose(v773_5,v774_7);
        }
        const Space v773_9 = intersect(constant_3,v773_2);
        const Space v773_10 = (has_head(v773_9) ? constant_4 : Space{});
        Space v773_12;
        if (!v773_10.empty()) {
          const Path v775_6 = concat_path(v772_6,v772_7_head);
          const Space v775_11 = routine_123(c, v775_6, p1, v772_7_tail);
          v773_12 = compose(v773_10,v775_11);
        }
        const Space v773_13 = unite(v773_8,v773_12);
        v772_7_result = unite(v772_7_result,v773_13);
      }
      const Space v772_7 = std::move(v772_7_result);
      v771_8 = compose(v771_5,v772_7);
    }
    const Space v771_9 = intersect(constant_3,v771_2);
    const Space v771_10 = (has_head(v771_9) ? constant_4 : Space{});
    const Space v771_11 = compose(v771_10,v770_9_tail);
    const Path v776_6 = concat_path(p0,v770_9_head);
    const Space v771_12 = wrap(v771_11,v776_6);
    const Space v771_13 = wrap(v771_12,p1);
    const Space v771_14 = unite(v771_8,v771_13);
    v770_9_result = unite(v770_9_result,v771_14);
  }
  const Space v770_9 = std::move(v770_9_result);
  return v770_9;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v777_13_result;
  for (int v777_13_label = 1; v777_13_label <= 2; ++v777_13_label) {
    const Space v777_13_tail = child(s0,v777_13_label);
    if (v777_13_tail.empty()) continue;
    const Path v777_13_head{v777_13_label};
    const Space v778_2 = singleton(v777_13_head);
    const Space v778_3 = intersect(constant_3,v778_2);
    const Space v778_4 = (has_head(v778_3) ? constant_4 : Space{});
    const Space v778_5 = subtract(constant_2,v778_4);
    Space v778_8;
    if (!v778_5.empty()) {
      const Path v779_6 = concat_path(p0,v777_13_head);
      Space v779_7_result;
      for (int v779_7_label = 1; v779_7_label <= 2; ++v779_7_label) {
        const Space v779_7_tail = child(v777_13_tail,v779_7_label);
        if (v779_7_tail.empty()) continue;
        const Path v779_7_head{v779_7_label};
        const Space v780_2 = singleton(v779_7_head);
        const Space v780_3 = intersect(constant_3,v780_2);
        const Space v780_4 = (has_head(v780_3) ? constant_4 : Space{});
        const Space v780_5 = subtract(constant_2,v780_4);
        Space v780_8;
        if (!v780_5.empty()) {
          const Path v781_6 = concat_path(v779_6,v779_7_head);
          const Space v781_7 = routine_124(c, v781_6, p1, v779_7_tail, s1);
          v780_8 = compose(v780_5,v781_7);
        }
        const Space v780_9 = intersect(constant_3,v780_2);
        const Space v780_10 = (has_head(v780_9) ? constant_4 : Space{});
        Space v780_12;
        if (!v780_10.empty()) {
          const Path v782_6 = concat_path(v779_6,v779_7_head);
          const Space v782_11 = routine_125(c, v782_6, p1, v779_7_tail, s1);
          v780_12 = compose(v780_10,v782_11);
        }
        const Space v780_13 = unite(v780_8,v780_12);
        v779_7_result = unite(v779_7_result,v780_13);
      }
      const Space v779_7 = std::move(v779_7_result);
      v778_8 = compose(v778_5,v779_7);
    }
    const Space v778_9 = intersect(constant_3,v778_2);
    const Space v778_10 = (has_head(v778_9) ? constant_4 : Space{});
    Space v778_12;
    if (!v778_10.empty()) {
      const Path v783_6 = concat_path(p0,v777_13_head);
      Space v783_11_result;
      for (int v783_11_label = 1; v783_11_label <= 2; ++v783_11_label) {
        const Space v783_11_tail = child(v777_13_tail,v783_11_label);
        if (v783_11_tail.empty()) continue;
        const Path v783_11_head{v783_11_label};
        const Space v784_2 = singleton(v783_11_head);
        const Space v784_3 = intersect(constant_3,v784_2);
        const Space v784_4 = (has_head(v784_3) ? constant_4 : Space{});
        const Space v784_5 = subtract(constant_2,v784_4);
        Space v784_8;
        if (!v784_5.empty()) {
          const Path v785_6 = concat_path(v783_6,v783_11_head);
          const Space v785_7 = routine_124(c, v785_6, p1, v783_11_tail, s1);
          v784_8 = compose(v784_5,v785_7);
        }
        const Space v784_9 = intersect(constant_3,v784_2);
        const Space v784_10 = (has_head(v784_9) ? constant_4 : Space{});
        Space v784_12;
        if (!v784_10.empty()) {
          const Path v786_6 = concat_path(v783_6,v783_11_head);
          const Space v786_11 = routine_43(c, v786_6, p1, v783_11_tail, s1);
          v784_12 = compose(v784_10,v786_11);
        }
        const Space v784_13 = unite(v784_8,v784_12);
        v783_11_result = unite(v783_11_result,v784_13);
      }
      const Space v783_11 = std::move(v783_11_result);
      v778_12 = compose(v778_10,v783_11);
    }
    const Space v778_13 = unite(v778_8,v778_12);
    v777_13_result = unite(v777_13_result,v778_13);
  }
  const Space v777_13 = std::move(v777_13_result);
  return v777_13;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v787_8 = unwrap(s1,constant_0);
  const Space v787_10 = unwrap(v787_8,constant_6);
  const Space v787_11 = unwrap(v787_10,p0);
  Space v787_18_result;
  for (int v787_18_label = 1; v787_18_label <= 2; ++v787_18_label) {
    const Space v787_18_tail = child(s0,v787_18_label);
    if (v787_18_tail.empty()) continue;
    const Path v787_18_head{v787_18_label};
    const Space v788_2 = singleton(v787_18_head);
    const Space v788_3 = intersect(constant_3,v788_2);
    const Space v788_4 = (has_head(v788_3) ? constant_4 : Space{});
    const Space v788_5 = subtract(constant_2,v788_4);
    Space v788_8;
    if (!v788_5.empty()) {
      const Path v789_6 = concat_path(p0,v787_18_head);
      Space v789_7_result;
      for (int v789_7_label = 1; v789_7_label <= 2; ++v789_7_label) {
        const Space v789_7_tail = child(v787_18_tail,v789_7_label);
        if (v789_7_tail.empty()) continue;
        const Path v789_7_head{v789_7_label};
        const Space v790_2 = singleton(v789_7_head);
        const Space v790_3 = intersect(constant_3,v790_2);
        const Space v790_4 = (has_head(v790_3) ? constant_4 : Space{});
        const Space v790_5 = subtract(constant_2,v790_4);
        Space v790_8;
        if (!v790_5.empty()) {
          const Path v791_6 = concat_path(v789_6,v789_7_head);
          const Space v791_7 = routine_124(c, v791_6, p1, v789_7_tail, s1);
          v790_8 = compose(v790_5,v791_7);
        }
        const Space v790_9 = intersect(constant_3,v790_2);
        const Space v790_10 = (has_head(v790_9) ? constant_4 : Space{});
        Space v790_12;
        if (!v790_10.empty()) {
          const Path v792_6 = concat_path(v789_6,v789_7_head);
          const Space v792_11 = routine_125(c, v792_6, p1, v789_7_tail, s1);
          v790_12 = compose(v790_10,v792_11);
        }
        const Space v790_13 = unite(v790_8,v790_12);
        v789_7_result = unite(v789_7_result,v790_13);
      }
      const Space v789_7 = std::move(v789_7_result);
      v788_8 = compose(v788_5,v789_7);
    }
    const Space v788_9 = intersect(constant_3,v788_2);
    const Space v788_10 = (has_head(v788_9) ? constant_4 : Space{});
    Space v788_13;
    if (!v788_10.empty()) {
      const Space v793_11 = unwrap(v787_11,v787_18_head);
      Space v793_12_result;
      for (int v793_12_label = 1; v793_12_label <= 2; ++v793_12_label) {
        const Space v793_12_tail = child(v793_11,v793_12_label);
        if (v793_12_tail.empty()) continue;
        const Path v793_12_head{v793_12_label};
        const Space v794_2 = singleton(v793_12_head);
        const Space v794_3 = intersect(constant_3,v794_2);
        const Space v794_4 = (has_head(v794_3) ? constant_4 : Space{});
        const Space v794_5 = subtract(constant_2,v794_4);
        Space v794_7;
        if (!v794_5.empty()) {
          const Space v795_6 = routine_78(c, v793_12_head, p1, v793_12_tail);
          v794_7 = compose(v794_5,v795_6);
        }
        const Space v794_8 = intersect(constant_3,v794_2);
        const Space v794_9 = (has_head(v794_8) ? constant_4 : Space{});
        Space v794_11;
        if (!v794_9.empty()) {
          const Space v796_10 = routine_79(c, v793_12_head, p1, v793_12_tail);
          v794_11 = compose(v794_9,v796_10);
        }
        const Space v794_12 = unite(v794_7,v794_11);
        v793_12_result = unite(v793_12_result,v794_12);
      }
      const Space v793_12 = std::move(v793_12_result);
      v788_13 = compose(v788_10,v793_12);
    }
    const Space v788_14 = unite(v788_8,v788_13);
    v787_18_result = unite(v787_18_result,v788_14);
  }
  const Space v787_18 = std::move(v787_18_result);
  return v787_18;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v797_12_result;
  for (int v797_12_label = 1; v797_12_label <= 2; ++v797_12_label) {
    const Space v797_12_tail = child(s0,v797_12_label);
    if (v797_12_tail.empty()) continue;
    const Path v797_12_head{v797_12_label};
    const Space v798_2 = singleton(v797_12_head);
    const Space v798_3 = intersect(constant_3,v798_2);
    const Space v798_4 = (has_head(v798_3) ? constant_4 : Space{});
    const Space v798_5 = subtract(constant_2,v798_4);
    Space v798_8;
    if (!v798_5.empty()) {
      const Path v799_6 = concat_path(p0,v797_12_head);
      Space v799_7_result;
      for (int v799_7_label = 1; v799_7_label <= 2; ++v799_7_label) {
        const Space v799_7_tail = child(v797_12_tail,v799_7_label);
        if (v799_7_tail.empty()) continue;
        const Path v799_7_head{v799_7_label};
        const Space v800_2 = singleton(v799_7_head);
        const Space v800_3 = intersect(constant_3,v800_2);
        const Space v800_4 = (has_head(v800_3) ? constant_4 : Space{});
        const Space v800_5 = subtract(constant_2,v800_4);
        Space v800_8;
        if (!v800_5.empty()) {
          const Path v801_6 = concat_path(v799_6,v799_7_head);
          const Space v801_7 = routine_126(c, v801_6, p1, v799_7_tail);
          v800_8 = compose(v800_5,v801_7);
        }
        const Space v800_9 = intersect(constant_3,v800_2);
        const Space v800_10 = (has_head(v800_9) ? constant_4 : Space{});
        Space v800_12;
        if (!v800_10.empty()) {
          const Path v802_6 = concat_path(v799_6,v799_7_head);
          const Space v802_11 = routine_127(c, v802_6, p1, v799_7_tail);
          v800_12 = compose(v800_10,v802_11);
        }
        const Space v800_13 = unite(v800_8,v800_12);
        v799_7_result = unite(v799_7_result,v800_13);
      }
      const Space v799_7 = std::move(v799_7_result);
      v798_8 = compose(v798_5,v799_7);
    }
    const Space v798_9 = intersect(constant_3,v798_2);
    const Space v798_10 = (has_head(v798_9) ? constant_4 : Space{});
    Space v798_12;
    if (!v798_10.empty()) {
      const Path v803_6 = concat_path(p0,v797_12_head);
      Space v803_11_result;
      for (int v803_11_label = 1; v803_11_label <= 2; ++v803_11_label) {
        const Space v803_11_tail = child(v797_12_tail,v803_11_label);
        if (v803_11_tail.empty()) continue;
        const Path v803_11_head{v803_11_label};
        const Space v804_2 = singleton(v803_11_head);
        const Space v804_3 = intersect(constant_3,v804_2);
        const Space v804_4 = (has_head(v804_3) ? constant_4 : Space{});
        const Space v804_5 = subtract(constant_2,v804_4);
        Space v804_8;
        if (!v804_5.empty()) {
          const Path v805_6 = concat_path(v803_6,v803_11_head);
          const Space v805_7 = routine_126(c, v805_6, p1, v803_11_tail);
          v804_8 = compose(v804_5,v805_7);
        }
        const Space v804_9 = intersect(constant_3,v804_2);
        const Space v804_10 = (has_head(v804_9) ? constant_4 : Space{});
        Space v804_12;
        if (!v804_10.empty()) {
          const Path v806_6 = concat_path(v803_6,v803_11_head);
          const Space v806_11 = routine_84(c, v806_6, p1, v803_11_tail);
          v804_12 = compose(v804_10,v806_11);
        }
        const Space v804_13 = unite(v804_8,v804_12);
        v803_11_result = unite(v803_11_result,v804_13);
      }
      const Space v803_11 = std::move(v803_11_result);
      v798_12 = compose(v798_10,v803_11);
    }
    const Space v798_13 = unite(v798_8,v798_12);
    v797_12_result = unite(v797_12_result,v798_13);
  }
  const Space v797_12 = std::move(v797_12_result);
  return v797_12;
}

static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v807_9_result;
  for (int v807_9_label = 1; v807_9_label <= 2; ++v807_9_label) {
    const Space v807_9_tail = child(s0,v807_9_label);
    if (v807_9_tail.empty()) continue;
    const Path v807_9_head{v807_9_label};
    const Space v808_2 = singleton(v807_9_head);
    const Space v808_3 = intersect(constant_3,v808_2);
    const Space v808_4 = (has_head(v808_3) ? constant_4 : Space{});
    const Space v808_5 = subtract(constant_2,v808_4);
    Space v808_8;
    if (!v808_5.empty()) {
      const Path v809_6 = concat_path(p0,v807_9_head);
      Space v809_7_result;
      for (int v809_7_label = 1; v809_7_label <= 2; ++v809_7_label) {
        const Space v809_7_tail = child(v807_9_tail,v809_7_label);
        if (v809_7_tail.empty()) continue;
        const Path v809_7_head{v809_7_label};
        const Space v810_2 = singleton(v809_7_head);
        const Space v810_3 = intersect(constant_3,v810_2);
        const Space v810_4 = (has_head(v810_3) ? constant_4 : Space{});
        const Space v810_5 = subtract(constant_2,v810_4);
        Space v810_8;
        if (!v810_5.empty()) {
          const Path v811_6 = concat_path(v809_6,v809_7_head);
          const Space v811_7 = routine_126(c, v811_6, p1, v809_7_tail);
          v810_8 = compose(v810_5,v811_7);
        }
        const Space v810_9 = intersect(constant_3,v810_2);
        const Space v810_10 = (has_head(v810_9) ? constant_4 : Space{});
        Space v810_12;
        if (!v810_10.empty()) {
          const Path v812_6 = concat_path(v809_6,v809_7_head);
          const Space v812_11 = routine_127(c, v812_6, p1, v809_7_tail);
          v810_12 = compose(v810_10,v812_11);
        }
        const Space v810_13 = unite(v810_8,v810_12);
        v809_7_result = unite(v809_7_result,v810_13);
      }
      const Space v809_7 = std::move(v809_7_result);
      v808_8 = compose(v808_5,v809_7);
    }
    const Space v808_9 = intersect(constant_3,v808_2);
    const Space v808_10 = (has_head(v808_9) ? constant_4 : Space{});
    const Space v808_11 = compose(v808_10,v807_9_tail);
    const Path v813_6 = concat_path(p0,v807_9_head);
    const Space v808_12 = wrap(v808_11,v813_6);
    const Space v808_13 = wrap(v808_12,p1);
    const Space v808_14 = unite(v808_8,v808_13);
    v807_9_result = unite(v807_9_result,v808_14);
  }
  const Space v807_9 = std::move(v807_9_result);
  return v807_9;
}

static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v814_3 = wrap(s0,p0);
  const Space v814_4 = wrap(v814_3,p1);
  return v814_4;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v815_12_result;
  for (int v815_12_label = 1; v815_12_label <= 2; ++v815_12_label) {
    const Space v815_12_tail = child(s0,v815_12_label);
    if (v815_12_tail.empty()) continue;
    const Path v815_12_head{v815_12_label};
    const Space v816_2 = singleton(v815_12_head);
    const Space v816_3 = intersect(constant_3,v816_2);
    const Space v816_4 = (has_head(v816_3) ? constant_4 : Space{});
    const Space v816_5 = subtract(constant_2,v816_4);
    Space v816_8;
    if (!v816_5.empty()) {
      const Path v817_6 = concat_path(p0,v815_12_head);
      Space v817_7_result;
      for (int v817_7_label = 1; v817_7_label <= 2; ++v817_7_label) {
        const Space v817_7_tail = child(v815_12_tail,v817_7_label);
        if (v817_7_tail.empty()) continue;
        const Path v817_7_head{v817_7_label};
        const Space v818_2 = singleton(v817_7_head);
        const Space v818_3 = intersect(constant_3,v818_2);
        const Space v818_4 = (has_head(v818_3) ? constant_4 : Space{});
        const Space v818_5 = subtract(constant_2,v818_4);
        Space v818_8;
        if (!v818_5.empty()) {
          const Path v819_6 = concat_path(v817_6,v817_7_head);
          const Space v819_7 = routine_128(c, v819_6, v817_7_tail, s1);
          v818_8 = compose(v818_5,v819_7);
        }
        const Space v818_9 = intersect(constant_3,v818_2);
        const Space v818_10 = (has_head(v818_9) ? constant_4 : Space{});
        Space v818_12;
        if (!v818_10.empty()) {
          const Path v820_6 = concat_path(v817_6,v817_7_head);
          const Space v820_11 = routine_129(c, v820_6, v817_7_tail, s1);
          v818_12 = compose(v818_10,v820_11);
        }
        const Space v818_13 = unite(v818_8,v818_12);
        v817_7_result = unite(v817_7_result,v818_13);
      }
      const Space v817_7 = std::move(v817_7_result);
      v816_8 = compose(v816_5,v817_7);
    }
    const Space v816_9 = intersect(constant_3,v816_2);
    const Space v816_10 = (has_head(v816_9) ? constant_4 : Space{});
    Space v816_12;
    if (!v816_10.empty()) {
      const Path v821_6 = concat_path(p0,v815_12_head);
      Space v821_11_result;
      for (int v821_11_label = 1; v821_11_label <= 2; ++v821_11_label) {
        const Space v821_11_tail = child(v815_12_tail,v821_11_label);
        if (v821_11_tail.empty()) continue;
        const Path v821_11_head{v821_11_label};
        const Space v822_2 = singleton(v821_11_head);
        const Space v822_3 = intersect(constant_3,v822_2);
        const Space v822_4 = (has_head(v822_3) ? constant_4 : Space{});
        const Space v822_5 = subtract(constant_2,v822_4);
        Space v822_8;
        if (!v822_5.empty()) {
          const Path v823_6 = concat_path(v821_6,v821_11_head);
          const Space v823_7 = routine_128(c, v823_6, v821_11_tail, s1);
          v822_8 = compose(v822_5,v823_7);
        }
        const Space v822_9 = intersect(constant_3,v822_2);
        const Space v822_10 = (has_head(v822_9) ? constant_4 : Space{});
        Space v822_12;
        if (!v822_10.empty()) {
          const Path v824_6 = concat_path(v821_6,v821_11_head);
          const Space v824_11 = routine_15(c, v824_6, v821_11_tail, s1);
          v822_12 = compose(v822_10,v824_11);
        }
        const Space v822_13 = unite(v822_8,v822_12);
        v821_11_result = unite(v821_11_result,v822_13);
      }
      const Space v821_11 = std::move(v821_11_result);
      v816_12 = compose(v816_10,v821_11);
    }
    const Space v816_13 = unite(v816_8,v816_12);
    v815_12_result = unite(v815_12_result,v816_13);
  }
  const Space v815_12 = std::move(v815_12_result);
  return v815_12;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v825_12_result;
  for (int v825_12_label = 1; v825_12_label <= 2; ++v825_12_label) {
    const Space v825_12_tail = child(s0,v825_12_label);
    if (v825_12_tail.empty()) continue;
    const Path v825_12_head{v825_12_label};
    const Space v826_2 = singleton(v825_12_head);
    const Space v826_3 = intersect(constant_3,v826_2);
    const Space v826_4 = (has_head(v826_3) ? constant_4 : Space{});
    const Space v826_5 = subtract(constant_2,v826_4);
    Space v826_8;
    if (!v826_5.empty()) {
      const Path v827_6 = concat_path(p0,v825_12_head);
      Space v827_7_result;
      for (int v827_7_label = 1; v827_7_label <= 2; ++v827_7_label) {
        const Space v827_7_tail = child(v825_12_tail,v827_7_label);
        if (v827_7_tail.empty()) continue;
        const Path v827_7_head{v827_7_label};
        const Space v828_2 = singleton(v827_7_head);
        const Space v828_3 = intersect(constant_3,v828_2);
        const Space v828_4 = (has_head(v828_3) ? constant_4 : Space{});
        const Space v828_5 = subtract(constant_2,v828_4);
        Space v828_8;
        if (!v828_5.empty()) {
          const Path v829_6 = concat_path(v827_6,v827_7_head);
          const Space v829_7 = routine_128(c, v829_6, v827_7_tail, s1);
          v828_8 = compose(v828_5,v829_7);
        }
        const Space v828_9 = intersect(constant_3,v828_2);
        const Space v828_10 = (has_head(v828_9) ? constant_4 : Space{});
        Space v828_12;
        if (!v828_10.empty()) {
          const Path v830_6 = concat_path(v827_6,v827_7_head);
          const Space v830_11 = routine_129(c, v830_6, v827_7_tail, s1);
          v828_12 = compose(v828_10,v830_11);
        }
        const Space v828_13 = unite(v828_8,v828_12);
        v827_7_result = unite(v827_7_result,v828_13);
      }
      const Space v827_7 = std::move(v827_7_result);
      v826_8 = compose(v826_5,v827_7);
    }
    const Space v826_9 = intersect(constant_3,v826_2);
    const Space v826_10 = (has_head(v826_9) ? constant_4 : Space{});
    Space v826_12;
    if (!v826_10.empty()) {
      const Path v831_6 = concat_path(p0,v825_12_head);
      Space v831_11_result;
      for (int v831_11_label = 1; v831_11_label <= 2; ++v831_11_label) {
        const Space v831_11_tail = child(v825_12_tail,v831_11_label);
        if (v831_11_tail.empty()) continue;
        const Path v831_11_head{v831_11_label};
        const Space v832_2 = singleton(v831_11_head);
        const Space v832_3 = intersect(constant_3,v832_2);
        const Space v832_4 = (has_head(v832_3) ? constant_4 : Space{});
        const Space v832_5 = subtract(constant_2,v832_4);
        Space v832_7;
        if (!v832_5.empty()) {
          const Space v833_6 = routine_46(c, v831_11_head, v831_6, v831_11_tail, s1);
          v832_7 = compose(v832_5,v833_6);
        }
        const Space v832_8 = intersect(constant_3,v832_2);
        const Space v832_9 = (has_head(v832_8) ? constant_4 : Space{});
        Space v832_11;
        if (!v832_9.empty()) {
          const Space v834_10 = routine_47(c, v831_11_head, v831_6, v831_11_tail, s1);
          v832_11 = compose(v832_9,v834_10);
        }
        const Space v832_12 = unite(v832_7,v832_11);
        v831_11_result = unite(v831_11_result,v832_12);
      }
      const Space v831_11 = std::move(v831_11_result);
      v826_12 = compose(v826_10,v831_11);
    }
    const Space v826_13 = unite(v826_8,v826_12);
    v825_12_result = unite(v825_12_result,v826_13);
  }
  const Space v825_12 = std::move(v825_12_result);
  return v825_12;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v835_13_result;
  for (int v835_13_label = 1; v835_13_label <= 2; ++v835_13_label) {
    const Space v835_13_tail = child(s0,v835_13_label);
    if (v835_13_tail.empty()) continue;
    const Path v835_13_head{v835_13_label};
    const Space v836_2 = singleton(v835_13_head);
    const Space v836_3 = intersect(constant_3,v836_2);
    const Space v836_4 = (has_head(v836_3) ? constant_4 : Space{});
    const Space v836_5 = subtract(constant_2,v836_4);
    Space v836_8;
    if (!v836_5.empty()) {
      const Path v837_6 = concat_path(p0,v835_13_head);
      Space v837_7_result;
      for (int v837_7_label = 1; v837_7_label <= 2; ++v837_7_label) {
        const Space v837_7_tail = child(v835_13_tail,v837_7_label);
        if (v837_7_tail.empty()) continue;
        const Path v837_7_head{v837_7_label};
        const Space v838_2 = singleton(v837_7_head);
        const Space v838_3 = intersect(constant_3,v838_2);
        const Space v838_4 = (has_head(v838_3) ? constant_4 : Space{});
        const Space v838_5 = subtract(constant_2,v838_4);
        Space v838_8;
        if (!v838_5.empty()) {
          const Path v839_6 = concat_path(v837_6,v837_7_head);
          const Space v839_7 = routine_130(c, v839_6, p1, v837_7_tail, s1);
          v838_8 = compose(v838_5,v839_7);
        }
        const Space v838_9 = intersect(constant_3,v838_2);
        const Space v838_10 = (has_head(v838_9) ? constant_4 : Space{});
        Space v838_12;
        if (!v838_10.empty()) {
          const Path v840_6 = concat_path(v837_6,v837_7_head);
          const Space v840_11 = routine_131(c, v840_6, p1, v837_7_tail, s1);
          v838_12 = compose(v838_10,v840_11);
        }
        const Space v838_13 = unite(v838_8,v838_12);
        v837_7_result = unite(v837_7_result,v838_13);
      }
      const Space v837_7 = std::move(v837_7_result);
      v836_8 = compose(v836_5,v837_7);
    }
    const Space v836_9 = intersect(constant_3,v836_2);
    const Space v836_10 = (has_head(v836_9) ? constant_4 : Space{});
    Space v836_12;
    if (!v836_10.empty()) {
      const Path v841_6 = concat_path(p0,v835_13_head);
      Space v841_11_result;
      for (int v841_11_label = 1; v841_11_label <= 2; ++v841_11_label) {
        const Space v841_11_tail = child(v835_13_tail,v841_11_label);
        if (v841_11_tail.empty()) continue;
        const Path v841_11_head{v841_11_label};
        const Space v842_2 = singleton(v841_11_head);
        const Space v842_3 = intersect(constant_3,v842_2);
        const Space v842_4 = (has_head(v842_3) ? constant_4 : Space{});
        const Space v842_5 = subtract(constant_2,v842_4);
        Space v842_8;
        if (!v842_5.empty()) {
          const Path v843_6 = concat_path(v841_6,v841_11_head);
          const Space v843_7 = routine_130(c, v843_6, p1, v841_11_tail, s1);
          v842_8 = compose(v842_5,v843_7);
        }
        const Space v842_9 = intersect(constant_3,v842_2);
        const Space v842_10 = (has_head(v842_9) ? constant_4 : Space{});
        Space v842_12;
        if (!v842_10.empty()) {
          const Path v844_6 = concat_path(v841_6,v841_11_head);
          const Space v844_11 = routine_50(c, v844_6, p1, v841_11_tail, s1);
          v842_12 = compose(v842_10,v844_11);
        }
        const Space v842_13 = unite(v842_8,v842_12);
        v841_11_result = unite(v841_11_result,v842_13);
      }
      const Space v841_11 = std::move(v841_11_result);
      v836_12 = compose(v836_10,v841_11);
    }
    const Space v836_13 = unite(v836_8,v836_12);
    v835_13_result = unite(v835_13_result,v836_13);
  }
  const Space v835_13 = std::move(v835_13_result);
  return v835_13;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v845_8 = unwrap(s1,constant_5);
  const Space v845_10 = unwrap(v845_8,constant_6);
  const Space v845_11 = unwrap(v845_10,p0);
  Space v845_18_result;
  for (int v845_18_label = 1; v845_18_label <= 2; ++v845_18_label) {
    const Space v845_18_tail = child(s0,v845_18_label);
    if (v845_18_tail.empty()) continue;
    const Path v845_18_head{v845_18_label};
    const Space v846_2 = singleton(v845_18_head);
    const Space v846_3 = intersect(constant_3,v846_2);
    const Space v846_4 = (has_head(v846_3) ? constant_4 : Space{});
    const Space v846_5 = subtract(constant_2,v846_4);
    Space v846_8;
    if (!v846_5.empty()) {
      const Path v847_6 = concat_path(p0,v845_18_head);
      Space v847_7_result;
      for (int v847_7_label = 1; v847_7_label <= 2; ++v847_7_label) {
        const Space v847_7_tail = child(v845_18_tail,v847_7_label);
        if (v847_7_tail.empty()) continue;
        const Path v847_7_head{v847_7_label};
        const Space v848_2 = singleton(v847_7_head);
        const Space v848_3 = intersect(constant_3,v848_2);
        const Space v848_4 = (has_head(v848_3) ? constant_4 : Space{});
        const Space v848_5 = subtract(constant_2,v848_4);
        Space v848_8;
        if (!v848_5.empty()) {
          const Path v849_6 = concat_path(v847_6,v847_7_head);
          const Space v849_7 = routine_130(c, v849_6, p1, v847_7_tail, s1);
          v848_8 = compose(v848_5,v849_7);
        }
        const Space v848_9 = intersect(constant_3,v848_2);
        const Space v848_10 = (has_head(v848_9) ? constant_4 : Space{});
        Space v848_12;
        if (!v848_10.empty()) {
          const Path v850_6 = concat_path(v847_6,v847_7_head);
          const Space v850_11 = routine_131(c, v850_6, p1, v847_7_tail, s1);
          v848_12 = compose(v848_10,v850_11);
        }
        const Space v848_13 = unite(v848_8,v848_12);
        v847_7_result = unite(v847_7_result,v848_13);
      }
      const Space v847_7 = std::move(v847_7_result);
      v846_8 = compose(v846_5,v847_7);
    }
    const Space v846_9 = intersect(constant_3,v846_2);
    const Space v846_10 = (has_head(v846_9) ? constant_4 : Space{});
    Space v846_13;
    if (!v846_10.empty()) {
      const Space v851_11 = unwrap(v845_11,v845_18_head);
      Space v851_12_result;
      for (int v851_12_label = 1; v851_12_label <= 2; ++v851_12_label) {
        const Space v851_12_tail = child(v851_11,v851_12_label);
        if (v851_12_tail.empty()) continue;
        const Path v851_12_head{v851_12_label};
        const Space v852_2 = singleton(v851_12_head);
        const Space v852_3 = intersect(constant_3,v852_2);
        const Space v852_4 = (has_head(v852_3) ? constant_4 : Space{});
        const Space v852_5 = subtract(constant_2,v852_4);
        Space v852_7;
        if (!v852_5.empty()) {
          const Space v853_6 = routine_89(c, v851_12_head, p1, v851_12_tail);
          v852_7 = compose(v852_5,v853_6);
        }
        const Space v852_8 = intersect(constant_3,v852_2);
        const Space v852_9 = (has_head(v852_8) ? constant_4 : Space{});
        Space v852_11;
        if (!v852_9.empty()) {
          const Space v854_10 = routine_90(c, v851_12_head, p1, v851_12_tail);
          v852_11 = compose(v852_9,v854_10);
        }
        const Space v852_12 = unite(v852_7,v852_11);
        v851_12_result = unite(v851_12_result,v852_12);
      }
      const Space v851_12 = std::move(v851_12_result);
      v846_13 = compose(v846_10,v851_12);
    }
    const Space v846_14 = unite(v846_8,v846_13);
    v845_18_result = unite(v845_18_result,v846_14);
  }
  const Space v845_18 = std::move(v845_18_result);
  return v845_18;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v855_12_result;
  for (int v855_12_label = 1; v855_12_label <= 2; ++v855_12_label) {
    const Space v855_12_tail = child(s0,v855_12_label);
    if (v855_12_tail.empty()) continue;
    const Path v855_12_head{v855_12_label};
    const Space v856_2 = singleton(v855_12_head);
    const Space v856_3 = intersect(constant_3,v856_2);
    const Space v856_4 = (has_head(v856_3) ? constant_4 : Space{});
    const Space v856_5 = subtract(constant_2,v856_4);
    Space v856_8;
    if (!v856_5.empty()) {
      const Path v857_6 = concat_path(p0,v855_12_head);
      Space v857_7_result;
      for (int v857_7_label = 1; v857_7_label <= 2; ++v857_7_label) {
        const Space v857_7_tail = child(v855_12_tail,v857_7_label);
        if (v857_7_tail.empty()) continue;
        const Path v857_7_head{v857_7_label};
        const Space v858_2 = singleton(v857_7_head);
        const Space v858_3 = intersect(constant_3,v858_2);
        const Space v858_4 = (has_head(v858_3) ? constant_4 : Space{});
        const Space v858_5 = subtract(constant_2,v858_4);
        Space v858_8;
        if (!v858_5.empty()) {
          const Path v859_6 = concat_path(v857_6,v857_7_head);
          const Space v859_7 = routine_132(c, v859_6, p1, v857_7_tail);
          v858_8 = compose(v858_5,v859_7);
        }
        const Space v858_9 = intersect(constant_3,v858_2);
        const Space v858_10 = (has_head(v858_9) ? constant_4 : Space{});
        Space v858_12;
        if (!v858_10.empty()) {
          const Path v860_6 = concat_path(v857_6,v857_7_head);
          const Space v860_11 = routine_133(c, v860_6, p1, v857_7_tail);
          v858_12 = compose(v858_10,v860_11);
        }
        const Space v858_13 = unite(v858_8,v858_12);
        v857_7_result = unite(v857_7_result,v858_13);
      }
      const Space v857_7 = std::move(v857_7_result);
      v856_8 = compose(v856_5,v857_7);
    }
    const Space v856_9 = intersect(constant_3,v856_2);
    const Space v856_10 = (has_head(v856_9) ? constant_4 : Space{});
    Space v856_12;
    if (!v856_10.empty()) {
      const Path v861_6 = concat_path(p0,v855_12_head);
      Space v861_11_result;
      for (int v861_11_label = 1; v861_11_label <= 2; ++v861_11_label) {
        const Space v861_11_tail = child(v855_12_tail,v861_11_label);
        if (v861_11_tail.empty()) continue;
        const Path v861_11_head{v861_11_label};
        const Space v862_2 = singleton(v861_11_head);
        const Space v862_3 = intersect(constant_3,v862_2);
        const Space v862_4 = (has_head(v862_3) ? constant_4 : Space{});
        const Space v862_5 = subtract(constant_2,v862_4);
        Space v862_8;
        if (!v862_5.empty()) {
          const Path v863_6 = concat_path(v861_6,v861_11_head);
          const Space v863_7 = routine_132(c, v863_6, p1, v861_11_tail);
          v862_8 = compose(v862_5,v863_7);
        }
        const Space v862_9 = intersect(constant_3,v862_2);
        const Space v862_10 = (has_head(v862_9) ? constant_4 : Space{});
        Space v862_12;
        if (!v862_10.empty()) {
          const Path v864_6 = concat_path(v861_6,v861_11_head);
          const Space v864_11 = routine_95(c, v864_6, p1, v861_11_tail);
          v862_12 = compose(v862_10,v864_11);
        }
        const Space v862_13 = unite(v862_8,v862_12);
        v861_11_result = unite(v861_11_result,v862_13);
      }
      const Space v861_11 = std::move(v861_11_result);
      v856_12 = compose(v856_10,v861_11);
    }
    const Space v856_13 = unite(v856_8,v856_12);
    v855_12_result = unite(v855_12_result,v856_13);
  }
  const Space v855_12 = std::move(v855_12_result);
  return v855_12;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v865_9_result;
  for (int v865_9_label = 1; v865_9_label <= 2; ++v865_9_label) {
    const Space v865_9_tail = child(s0,v865_9_label);
    if (v865_9_tail.empty()) continue;
    const Path v865_9_head{v865_9_label};
    const Space v866_2 = singleton(v865_9_head);
    const Space v866_3 = intersect(constant_3,v866_2);
    const Space v866_4 = (has_head(v866_3) ? constant_4 : Space{});
    const Space v866_5 = subtract(constant_2,v866_4);
    Space v866_8;
    if (!v866_5.empty()) {
      const Path v867_6 = concat_path(p0,v865_9_head);
      Space v867_7_result;
      for (int v867_7_label = 1; v867_7_label <= 2; ++v867_7_label) {
        const Space v867_7_tail = child(v865_9_tail,v867_7_label);
        if (v867_7_tail.empty()) continue;
        const Path v867_7_head{v867_7_label};
        const Space v868_2 = singleton(v867_7_head);
        const Space v868_3 = intersect(constant_3,v868_2);
        const Space v868_4 = (has_head(v868_3) ? constant_4 : Space{});
        const Space v868_5 = subtract(constant_2,v868_4);
        Space v868_8;
        if (!v868_5.empty()) {
          const Path v869_6 = concat_path(v867_6,v867_7_head);
          const Space v869_7 = routine_132(c, v869_6, p1, v867_7_tail);
          v868_8 = compose(v868_5,v869_7);
        }
        const Space v868_9 = intersect(constant_3,v868_2);
        const Space v868_10 = (has_head(v868_9) ? constant_4 : Space{});
        Space v868_12;
        if (!v868_10.empty()) {
          const Path v870_6 = concat_path(v867_6,v867_7_head);
          const Space v870_11 = routine_133(c, v870_6, p1, v867_7_tail);
          v868_12 = compose(v868_10,v870_11);
        }
        const Space v868_13 = unite(v868_8,v868_12);
        v867_7_result = unite(v867_7_result,v868_13);
      }
      const Space v867_7 = std::move(v867_7_result);
      v866_8 = compose(v866_5,v867_7);
    }
    const Space v866_9 = intersect(constant_3,v866_2);
    const Space v866_10 = (has_head(v866_9) ? constant_4 : Space{});
    const Space v866_11 = compose(v866_10,v865_9_tail);
    const Path v871_6 = concat_path(p0,v865_9_head);
    const Space v866_12 = wrap(v866_11,v871_6);
    const Space v866_13 = wrap(v866_12,p1);
    const Space v866_14 = unite(v866_8,v866_13);
    v865_9_result = unite(v865_9_result,v866_14);
  }
  const Space v865_9 = std::move(v865_9_result);
  return v865_9;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v872_13_result;
  for (int v872_13_label = 1; v872_13_label <= 2; ++v872_13_label) {
    const Space v872_13_tail = child(s0,v872_13_label);
    if (v872_13_tail.empty()) continue;
    const Path v872_13_head{v872_13_label};
    const Space v873_2 = singleton(v872_13_head);
    const Space v873_3 = intersect(constant_3,v873_2);
    const Space v873_4 = (has_head(v873_3) ? constant_4 : Space{});
    const Space v873_5 = subtract(constant_2,v873_4);
    Space v873_8;
    if (!v873_5.empty()) {
      const Path v874_6 = concat_path(p0,v872_13_head);
      Space v874_7_result;
      for (int v874_7_label = 1; v874_7_label <= 2; ++v874_7_label) {
        const Space v874_7_tail = child(v872_13_tail,v874_7_label);
        if (v874_7_tail.empty()) continue;
        const Path v874_7_head{v874_7_label};
        const Space v875_2 = singleton(v874_7_head);
        const Space v875_3 = intersect(constant_3,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_4 : Space{});
        const Space v875_5 = subtract(constant_2,v875_4);
        Space v875_8;
        if (!v875_5.empty()) {
          const Path v876_6 = concat_path(v874_6,v874_7_head);
          const Space v876_7 = routine_134(c, v876_6, p1, v874_7_tail, s1);
          v875_8 = compose(v875_5,v876_7);
        }
        const Space v875_9 = intersect(constant_3,v875_2);
        const Space v875_10 = (has_head(v875_9) ? constant_4 : Space{});
        Space v875_12;
        if (!v875_10.empty()) {
          const Path v877_6 = concat_path(v874_6,v874_7_head);
          const Space v877_11 = routine_135(c, v877_6, p1, v874_7_tail, s1);
          v875_12 = compose(v875_10,v877_11);
        }
        const Space v875_13 = unite(v875_8,v875_12);
        v874_7_result = unite(v874_7_result,v875_13);
      }
      const Space v874_7 = std::move(v874_7_result);
      v873_8 = compose(v873_5,v874_7);
    }
    const Space v873_9 = intersect(constant_3,v873_2);
    const Space v873_10 = (has_head(v873_9) ? constant_4 : Space{});
    Space v873_12;
    if (!v873_10.empty()) {
      const Path v878_6 = concat_path(p0,v872_13_head);
      Space v878_11_result;
      for (int v878_11_label = 1; v878_11_label <= 2; ++v878_11_label) {
        const Space v878_11_tail = child(v872_13_tail,v878_11_label);
        if (v878_11_tail.empty()) continue;
        const Path v878_11_head{v878_11_label};
        const Space v879_2 = singleton(v878_11_head);
        const Space v879_3 = intersect(constant_3,v879_2);
        const Space v879_4 = (has_head(v879_3) ? constant_4 : Space{});
        const Space v879_5 = subtract(constant_2,v879_4);
        Space v879_8;
        if (!v879_5.empty()) {
          const Path v880_6 = concat_path(v878_6,v878_11_head);
          const Space v880_7 = routine_134(c, v880_6, p1, v878_11_tail, s1);
          v879_8 = compose(v879_5,v880_7);
        }
        const Space v879_9 = intersect(constant_3,v879_2);
        const Space v879_10 = (has_head(v879_9) ? constant_4 : Space{});
        Space v879_12;
        if (!v879_10.empty()) {
          const Path v881_6 = concat_path(v878_6,v878_11_head);
          const Space v881_11 = routine_50(c, v881_6, p1, v878_11_tail, s1);
          v879_12 = compose(v879_10,v881_11);
        }
        const Space v879_13 = unite(v879_8,v879_12);
        v878_11_result = unite(v878_11_result,v879_13);
      }
      const Space v878_11 = std::move(v878_11_result);
      v873_12 = compose(v873_10,v878_11);
    }
    const Space v873_13 = unite(v873_8,v873_12);
    v872_13_result = unite(v872_13_result,v873_13);
  }
  const Space v872_13 = std::move(v872_13_result);
  return v872_13;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v882_8 = unwrap(s1,constant_5);
  const Space v882_10 = unwrap(v882_8,constant_6);
  const Space v882_11 = unwrap(v882_10,p0);
  Space v882_18_result;
  for (int v882_18_label = 1; v882_18_label <= 2; ++v882_18_label) {
    const Space v882_18_tail = child(s0,v882_18_label);
    if (v882_18_tail.empty()) continue;
    const Path v882_18_head{v882_18_label};
    const Space v883_2 = singleton(v882_18_head);
    const Space v883_3 = intersect(constant_3,v883_2);
    const Space v883_4 = (has_head(v883_3) ? constant_4 : Space{});
    const Space v883_5 = subtract(constant_2,v883_4);
    Space v883_8;
    if (!v883_5.empty()) {
      const Path v884_6 = concat_path(p0,v882_18_head);
      Space v884_7_result;
      for (int v884_7_label = 1; v884_7_label <= 2; ++v884_7_label) {
        const Space v884_7_tail = child(v882_18_tail,v884_7_label);
        if (v884_7_tail.empty()) continue;
        const Path v884_7_head{v884_7_label};
        const Space v885_2 = singleton(v884_7_head);
        const Space v885_3 = intersect(constant_3,v885_2);
        const Space v885_4 = (has_head(v885_3) ? constant_4 : Space{});
        const Space v885_5 = subtract(constant_2,v885_4);
        Space v885_8;
        if (!v885_5.empty()) {
          const Path v886_6 = concat_path(v884_6,v884_7_head);
          const Space v886_7 = routine_134(c, v886_6, p1, v884_7_tail, s1);
          v885_8 = compose(v885_5,v886_7);
        }
        const Space v885_9 = intersect(constant_3,v885_2);
        const Space v885_10 = (has_head(v885_9) ? constant_4 : Space{});
        Space v885_12;
        if (!v885_10.empty()) {
          const Path v887_6 = concat_path(v884_6,v884_7_head);
          const Space v887_11 = routine_135(c, v887_6, p1, v884_7_tail, s1);
          v885_12 = compose(v885_10,v887_11);
        }
        const Space v885_13 = unite(v885_8,v885_12);
        v884_7_result = unite(v884_7_result,v885_13);
      }
      const Space v884_7 = std::move(v884_7_result);
      v883_8 = compose(v883_5,v884_7);
    }
    const Space v883_9 = intersect(constant_3,v883_2);
    const Space v883_10 = (has_head(v883_9) ? constant_4 : Space{});
    Space v883_13;
    if (!v883_10.empty()) {
      const Space v888_11 = unwrap(v882_11,v882_18_head);
      Space v888_12_result;
      for (int v888_12_label = 1; v888_12_label <= 2; ++v888_12_label) {
        const Space v888_12_tail = child(v888_11,v888_12_label);
        if (v888_12_tail.empty()) continue;
        const Path v888_12_head{v888_12_label};
        const Space v889_2 = singleton(v888_12_head);
        const Space v889_3 = intersect(constant_3,v889_2);
        const Space v889_4 = (has_head(v889_3) ? constant_4 : Space{});
        const Space v889_5 = subtract(constant_2,v889_4);
        Space v889_7;
        if (!v889_5.empty()) {
          const Space v890_6 = routine_89(c, v888_12_head, p1, v888_12_tail);
          v889_7 = compose(v889_5,v890_6);
        }
        const Space v889_8 = intersect(constant_3,v889_2);
        const Space v889_9 = (has_head(v889_8) ? constant_4 : Space{});
        Space v889_11;
        if (!v889_9.empty()) {
          const Space v891_10 = routine_90(c, v888_12_head, p1, v888_12_tail);
          v889_11 = compose(v889_9,v891_10);
        }
        const Space v889_12 = unite(v889_7,v889_11);
        v888_12_result = unite(v888_12_result,v889_12);
      }
      const Space v888_12 = std::move(v888_12_result);
      v883_13 = compose(v883_10,v888_12);
    }
    const Space v883_14 = unite(v883_8,v883_13);
    v882_18_result = unite(v882_18_result,v883_14);
  }
  const Space v882_18 = std::move(v882_18_result);
  return v882_18;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v892_12_result;
  for (int v892_12_label = 1; v892_12_label <= 2; ++v892_12_label) {
    const Space v892_12_tail = child(s0,v892_12_label);
    if (v892_12_tail.empty()) continue;
    const Path v892_12_head{v892_12_label};
    const Space v893_2 = singleton(v892_12_head);
    const Space v893_3 = intersect(constant_3,v893_2);
    const Space v893_4 = (has_head(v893_3) ? constant_4 : Space{});
    const Space v893_5 = subtract(constant_2,v893_4);
    Space v893_8;
    if (!v893_5.empty()) {
      const Path v894_6 = concat_path(p0,v892_12_head);
      Space v894_7_result;
      for (int v894_7_label = 1; v894_7_label <= 2; ++v894_7_label) {
        const Space v894_7_tail = child(v892_12_tail,v894_7_label);
        if (v894_7_tail.empty()) continue;
        const Path v894_7_head{v894_7_label};
        const Space v895_2 = singleton(v894_7_head);
        const Space v895_3 = intersect(constant_3,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_4 : Space{});
        const Space v895_5 = subtract(constant_2,v895_4);
        Space v895_8;
        if (!v895_5.empty()) {
          const Path v896_6 = concat_path(v894_6,v894_7_head);
          const Space v896_7 = routine_136(c, v896_6, p1, v894_7_tail);
          v895_8 = compose(v895_5,v896_7);
        }
        const Space v895_9 = intersect(constant_3,v895_2);
        const Space v895_10 = (has_head(v895_9) ? constant_4 : Space{});
        Space v895_12;
        if (!v895_10.empty()) {
          const Path v897_6 = concat_path(v894_6,v894_7_head);
          const Space v897_11 = routine_137(c, v897_6, p1, v894_7_tail);
          v895_12 = compose(v895_10,v897_11);
        }
        const Space v895_13 = unite(v895_8,v895_12);
        v894_7_result = unite(v894_7_result,v895_13);
      }
      const Space v894_7 = std::move(v894_7_result);
      v893_8 = compose(v893_5,v894_7);
    }
    const Space v893_9 = intersect(constant_3,v893_2);
    const Space v893_10 = (has_head(v893_9) ? constant_4 : Space{});
    Space v893_12;
    if (!v893_10.empty()) {
      const Path v898_6 = concat_path(p0,v892_12_head);
      Space v898_11_result;
      for (int v898_11_label = 1; v898_11_label <= 2; ++v898_11_label) {
        const Space v898_11_tail = child(v892_12_tail,v898_11_label);
        if (v898_11_tail.empty()) continue;
        const Path v898_11_head{v898_11_label};
        const Space v899_2 = singleton(v898_11_head);
        const Space v899_3 = intersect(constant_3,v899_2);
        const Space v899_4 = (has_head(v899_3) ? constant_4 : Space{});
        const Space v899_5 = subtract(constant_2,v899_4);
        Space v899_8;
        if (!v899_5.empty()) {
          const Path v900_6 = concat_path(v898_6,v898_11_head);
          const Space v900_7 = routine_136(c, v900_6, p1, v898_11_tail);
          v899_8 = compose(v899_5,v900_7);
        }
        const Space v899_9 = intersect(constant_3,v899_2);
        const Space v899_10 = (has_head(v899_9) ? constant_4 : Space{});
        Space v899_12;
        if (!v899_10.empty()) {
          const Path v901_6 = concat_path(v898_6,v898_11_head);
          const Space v901_11 = routine_95(c, v901_6, p1, v898_11_tail);
          v899_12 = compose(v899_10,v901_11);
        }
        const Space v899_13 = unite(v899_8,v899_12);
        v898_11_result = unite(v898_11_result,v899_13);
      }
      const Space v898_11 = std::move(v898_11_result);
      v893_12 = compose(v893_10,v898_11);
    }
    const Space v893_13 = unite(v893_8,v893_12);
    v892_12_result = unite(v892_12_result,v893_13);
  }
  const Space v892_12 = std::move(v892_12_result);
  return v892_12;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v902_9_result;
  for (int v902_9_label = 1; v902_9_label <= 2; ++v902_9_label) {
    const Space v902_9_tail = child(s0,v902_9_label);
    if (v902_9_tail.empty()) continue;
    const Path v902_9_head{v902_9_label};
    const Space v903_2 = singleton(v902_9_head);
    const Space v903_3 = intersect(constant_3,v903_2);
    const Space v903_4 = (has_head(v903_3) ? constant_4 : Space{});
    const Space v903_5 = subtract(constant_2,v903_4);
    Space v903_8;
    if (!v903_5.empty()) {
      const Path v904_6 = concat_path(p0,v902_9_head);
      Space v904_7_result;
      for (int v904_7_label = 1; v904_7_label <= 2; ++v904_7_label) {
        const Space v904_7_tail = child(v902_9_tail,v904_7_label);
        if (v904_7_tail.empty()) continue;
        const Path v904_7_head{v904_7_label};
        const Space v905_2 = singleton(v904_7_head);
        const Space v905_3 = intersect(constant_3,v905_2);
        const Space v905_4 = (has_head(v905_3) ? constant_4 : Space{});
        const Space v905_5 = subtract(constant_2,v905_4);
        Space v905_8;
        if (!v905_5.empty()) {
          const Path v906_6 = concat_path(v904_6,v904_7_head);
          const Space v906_7 = routine_136(c, v906_6, p1, v904_7_tail);
          v905_8 = compose(v905_5,v906_7);
        }
        const Space v905_9 = intersect(constant_3,v905_2);
        const Space v905_10 = (has_head(v905_9) ? constant_4 : Space{});
        Space v905_12;
        if (!v905_10.empty()) {
          const Path v907_6 = concat_path(v904_6,v904_7_head);
          const Space v907_11 = routine_137(c, v907_6, p1, v904_7_tail);
          v905_12 = compose(v905_10,v907_11);
        }
        const Space v905_13 = unite(v905_8,v905_12);
        v904_7_result = unite(v904_7_result,v905_13);
      }
      const Space v904_7 = std::move(v904_7_result);
      v903_8 = compose(v903_5,v904_7);
    }
    const Space v903_9 = intersect(constant_3,v903_2);
    const Space v903_10 = (has_head(v903_9) ? constant_4 : Space{});
    const Space v903_11 = compose(v903_10,v902_9_tail);
    const Path v908_6 = concat_path(p0,v902_9_head);
    const Space v903_12 = wrap(v903_11,v908_6);
    const Space v903_13 = wrap(v903_12,p1);
    const Space v903_14 = unite(v903_8,v903_13);
    v902_9_result = unite(v902_9_result,v903_14);
  }
  const Space v902_9 = std::move(v902_9_result);
  return v902_9;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v909_3 = wrap(s0,p0);
  const Space v909_4 = wrap(v909_3,p1);
  return v909_4;
}

static Space routine_96(Context& c, const Path& p0, const Space& s0) {
  const Space v910_2 = Space{};
  return v910_2;
}

static Space routine_97(Context& c, const Path& p0, const Space& s0) {
  Space v911_6_result;
  for (int v911_6_label = 1; v911_6_label <= 2; ++v911_6_label) {
    const Space v911_6_tail = child(s0,v911_6_label);
    if (v911_6_tail.empty()) continue;
    const Path v911_6_head{v911_6_label};
    const Space v912_2 = singleton(v911_6_head);
    const Space v912_3 = intersect(constant_3,v912_2);
    const Space v912_4 = (has_head(v912_3) ? constant_4 : Space{});
    Space v912_7;
    if (!v912_4.empty()) {
      const Path v913_5 = concat_path(p0,v911_6_head);
      Space v913_6_result;
      for (int v913_6_label = 1; v913_6_label <= 2; ++v913_6_label) {
        const Space v913_6_tail = child(v911_6_tail,v913_6_label);
        if (v913_6_tail.empty()) continue;
        const Path v913_6_head{v913_6_label};
        const Space v914_2 = singleton(v913_6_head);
        const Space v914_3 = intersect(constant_3,v914_2);
        const Space v914_4 = (has_head(v914_3) ? constant_4 : Space{});
        const Space v914_5 = subtract(constant_2,v914_4);
        Space v914_7;
        if (!v914_5.empty()) {
          const Space v915_6 = routine_18(c, v913_6_head, v913_5, v913_6_tail);
          v914_7 = compose(v914_5,v915_6);
        }
        const Space v914_8 = intersect(constant_3,v914_2);
        const Space v914_9 = (has_head(v914_8) ? constant_4 : Space{});
        Space v914_11;
        if (!v914_9.empty()) {
          const Space v916_10 = routine_19(c, v913_6_head, v913_5, v913_6_tail);
          v914_11 = compose(v914_9,v916_10);
        }
        const Space v914_12 = unite(v914_7,v914_11);
        v913_6_result = unite(v913_6_result,v914_12);
      }
      const Space v913_6 = std::move(v913_6_result);
      v912_7 = compose(v912_4,v913_6);
    }
    v911_6_result = unite(v911_6_result,v912_7);
  }
  const Space v911_6 = std::move(v911_6_result);
  return v911_6;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v917_12_result;
  for (int v917_12_label = 1; v917_12_label <= 2; ++v917_12_label) {
    const Space v917_12_tail = child(s0,v917_12_label);
    if (v917_12_tail.empty()) continue;
    const Path v917_12_head{v917_12_label};
    const Space v918_2 = singleton(v917_12_head);
    const Space v918_3 = intersect(constant_3,v918_2);
    const Space v918_4 = (has_head(v918_3) ? constant_4 : Space{});
    const Space v918_5 = subtract(constant_2,v918_4);
    Space v918_8;
    if (!v918_5.empty()) {
      const Path v919_6 = concat_path(p0,v917_12_head);
      Space v919_7_result;
      for (int v919_7_label = 1; v919_7_label <= 2; ++v919_7_label) {
        const Space v919_7_tail = child(v917_12_tail,v919_7_label);
        if (v919_7_tail.empty()) continue;
        const Path v919_7_head{v919_7_label};
        const Space v920_2 = singleton(v919_7_head);
        const Space v920_3 = intersect(constant_3,v920_2);
        const Space v920_4 = (has_head(v920_3) ? constant_4 : Space{});
        const Space v920_5 = subtract(constant_2,v920_4);
        Space v920_8;
        if (!v920_5.empty()) {
          const Path v921_6 = concat_path(v919_6,v919_7_head);
          const Space v921_7 = routine_138(c, v921_6, p1, v919_7_tail);
          v920_8 = compose(v920_5,v921_7);
        }
        const Space v920_9 = intersect(constant_3,v920_2);
        const Space v920_10 = (has_head(v920_9) ? constant_4 : Space{});
        Space v920_12;
        if (!v920_10.empty()) {
          const Path v922_6 = concat_path(v919_6,v919_7_head);
          const Space v922_11 = routine_139(c, v922_6, p1, v919_7_tail);
          v920_12 = compose(v920_10,v922_11);
        }
        const Space v920_13 = unite(v920_8,v920_12);
        v919_7_result = unite(v919_7_result,v920_13);
      }
      const Space v919_7 = std::move(v919_7_result);
      v918_8 = compose(v918_5,v919_7);
    }
    const Space v918_9 = intersect(constant_3,v918_2);
    const Space v918_10 = (has_head(v918_9) ? constant_4 : Space{});
    Space v918_12;
    if (!v918_10.empty()) {
      const Path v923_6 = concat_path(p0,v917_12_head);
      Space v923_11_result;
      for (int v923_11_label = 1; v923_11_label <= 2; ++v923_11_label) {
        const Space v923_11_tail = child(v917_12_tail,v923_11_label);
        if (v923_11_tail.empty()) continue;
        const Path v923_11_head{v923_11_label};
        const Space v924_2 = singleton(v923_11_head);
        const Space v924_3 = intersect(constant_3,v924_2);
        const Space v924_4 = (has_head(v924_3) ? constant_4 : Space{});
        const Space v924_5 = subtract(constant_2,v924_4);
        Space v924_8;
        if (!v924_5.empty()) {
          const Path v925_6 = concat_path(v923_6,v923_11_head);
          const Space v925_7 = routine_138(c, v925_6, p1, v923_11_tail);
          v924_8 = compose(v924_5,v925_7);
        }
        const Space v924_9 = intersect(constant_3,v924_2);
        const Space v924_10 = (has_head(v924_9) ? constant_4 : Space{});
        Space v924_12;
        if (!v924_10.empty()) {
          const Path v926_6 = concat_path(v923_6,v923_11_head);
          const Space v926_11 = routine_22(c, v926_6, p1, v923_11_tail);
          v924_12 = compose(v924_10,v926_11);
        }
        const Space v924_13 = unite(v924_8,v924_12);
        v923_11_result = unite(v923_11_result,v924_13);
      }
      const Space v923_11 = std::move(v923_11_result);
      v918_12 = compose(v918_10,v923_11);
    }
    const Space v918_13 = unite(v918_8,v918_12);
    v917_12_result = unite(v917_12_result,v918_13);
  }
  const Space v917_12 = std::move(v917_12_result);
  return v917_12;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v927_10_result;
  for (int v927_10_label = 1; v927_10_label <= 2; ++v927_10_label) {
    const Space v927_10_tail = child(s0,v927_10_label);
    if (v927_10_tail.empty()) continue;
    const Path v927_10_head{v927_10_label};
    const Space v928_2 = singleton(v927_10_head);
    const Space v928_3 = intersect(constant_3,v928_2);
    const Space v928_4 = (has_head(v928_3) ? constant_4 : Space{});
    const Space v928_5 = compose(v928_4,v927_10_tail);
    const Path v929_6 = concat_path(p0,v927_10_head);
    const Space v928_7 = wrap(v928_5,v929_6);
    const Space v928_8 = wrap(v928_7,p1);
    const Space v928_9 = wrap(v928_8,constant_6);
    const Space v928_10 = intersect(constant_3,v928_2);
    const Space v928_11 = (has_head(v928_10) ? constant_4 : Space{});
    const Space v928_12 = subtract(constant_2,v928_11);
    Space v928_14;
    if (!v928_12.empty()) {
      Space v930_13_result;
      for (int v930_13_label = 1; v930_13_label <= 2; ++v930_13_label) {
        const Space v930_13_tail = child(v927_10_tail,v930_13_label);
        if (v930_13_tail.empty()) continue;
        const Path v930_13_head{v930_13_label};
        const Space v931_2 = singleton(v930_13_head);
        const Space v931_3 = intersect(constant_3,v931_2);
        const Space v931_4 = (has_head(v931_3) ? constant_4 : Space{});
        const Space v931_5 = subtract(constant_2,v931_4);
        Space v931_8;
        if (!v931_5.empty()) {
          const Path v932_6 = concat_path(v929_6,v930_13_head);
          const Space v932_7 = routine_138(c, v932_6, p1, v930_13_tail);
          v931_8 = compose(v931_5,v932_7);
        }
        const Space v931_9 = intersect(constant_3,v931_2);
        const Space v931_10 = (has_head(v931_9) ? constant_4 : Space{});
        Space v931_12;
        if (!v931_10.empty()) {
          const Path v933_6 = concat_path(v929_6,v930_13_head);
          const Space v933_11 = routine_139(c, v933_6, p1, v930_13_tail);
          v931_12 = compose(v931_10,v933_11);
        }
        const Space v931_13 = unite(v931_8,v931_12);
        v930_13_result = unite(v930_13_result,v931_13);
      }
      const Space v930_13 = std::move(v930_13_result);
      v928_14 = compose(v928_12,v930_13);
    }
    const Space v928_15 = unite(v928_9,v928_14);
    v927_10_result = unite(v927_10_result,v928_15);
  }
  const Space v927_10 = std::move(v927_10_result);
  return v927_10;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v934_12_result;
  for (int v934_12_label = 1; v934_12_label <= 2; ++v934_12_label) {
    const Space v934_12_tail = child(s0,v934_12_label);
    if (v934_12_tail.empty()) continue;
    const Path v934_12_head{v934_12_label};
    const Space v935_2 = singleton(v934_12_head);
    const Space v935_3 = intersect(constant_3,v935_2);
    const Space v935_4 = (has_head(v935_3) ? constant_4 : Space{});
    const Space v935_5 = subtract(constant_2,v935_4);
    Space v935_8;
    if (!v935_5.empty()) {
      const Path v936_6 = concat_path(p0,v934_12_head);
      Space v936_7_result;
      for (int v936_7_label = 1; v936_7_label <= 2; ++v936_7_label) {
        const Space v936_7_tail = child(v934_12_tail,v936_7_label);
        if (v936_7_tail.empty()) continue;
        const Path v936_7_head{v936_7_label};
        const Space v937_2 = singleton(v936_7_head);
        const Space v937_3 = intersect(constant_3,v937_2);
        const Space v937_4 = (has_head(v937_3) ? constant_4 : Space{});
        const Space v937_5 = subtract(constant_2,v937_4);
        Space v937_8;
        if (!v937_5.empty()) {
          const Path v938_6 = concat_path(v936_6,v936_7_head);
          const Space v938_7 = routine_140(c, v938_6, p1, v936_7_tail);
          v937_8 = compose(v937_5,v938_7);
        }
        const Space v937_9 = intersect(constant_3,v937_2);
        const Space v937_10 = (has_head(v937_9) ? constant_4 : Space{});
        Space v937_12;
        if (!v937_10.empty()) {
          const Path v939_6 = concat_path(v936_6,v936_7_head);
          const Space v939_11 = routine_141(c, v939_6, p1, v936_7_tail);
          v937_12 = compose(v937_10,v939_11);
        }
        const Space v937_13 = unite(v937_8,v937_12);
        v936_7_result = unite(v936_7_result,v937_13);
      }
      const Space v936_7 = std::move(v936_7_result);
      v935_8 = compose(v935_5,v936_7);
    }
    const Space v935_9 = intersect(constant_3,v935_2);
    const Space v935_10 = (has_head(v935_9) ? constant_4 : Space{});
    Space v935_12;
    if (!v935_10.empty()) {
      const Path v940_6 = concat_path(p0,v934_12_head);
      Space v940_11_result;
      for (int v940_11_label = 1; v940_11_label <= 2; ++v940_11_label) {
        const Space v940_11_tail = child(v934_12_tail,v940_11_label);
        if (v940_11_tail.empty()) continue;
        const Path v940_11_head{v940_11_label};
        const Space v941_2 = singleton(v940_11_head);
        const Space v941_3 = intersect(constant_3,v941_2);
        const Space v941_4 = (has_head(v941_3) ? constant_4 : Space{});
        const Space v941_5 = subtract(constant_2,v941_4);
        Space v941_8;
        if (!v941_5.empty()) {
          const Path v942_6 = concat_path(v940_6,v940_11_head);
          const Space v942_7 = routine_140(c, v942_6, p1, v940_11_tail);
          v941_8 = compose(v941_5,v942_7);
        }
        const Space v941_9 = intersect(constant_3,v941_2);
        const Space v941_10 = (has_head(v941_9) ? constant_4 : Space{});
        Space v941_12;
        if (!v941_10.empty()) {
          const Path v943_6 = concat_path(v940_6,v940_11_head);
          const Space v943_11 = routine_22(c, v943_6, p1, v940_11_tail);
          v941_12 = compose(v941_10,v943_11);
        }
        const Space v941_13 = unite(v941_8,v941_12);
        v940_11_result = unite(v940_11_result,v941_13);
      }
      const Space v940_11 = std::move(v940_11_result);
      v935_12 = compose(v935_10,v940_11);
    }
    const Space v935_13 = unite(v935_8,v935_12);
    v934_12_result = unite(v934_12_result,v935_13);
  }
  const Space v934_12 = std::move(v934_12_result);
  return v934_12;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v944_10_result;
  for (int v944_10_label = 1; v944_10_label <= 2; ++v944_10_label) {
    const Space v944_10_tail = child(s0,v944_10_label);
    if (v944_10_tail.empty()) continue;
    const Path v944_10_head{v944_10_label};
    const Space v945_2 = singleton(v944_10_head);
    const Space v945_3 = intersect(constant_3,v945_2);
    const Space v945_4 = (has_head(v945_3) ? constant_4 : Space{});
    const Space v945_5 = compose(v945_4,v944_10_tail);
    const Path v946_6 = concat_path(p0,v944_10_head);
    const Space v945_7 = wrap(v945_5,v946_6);
    const Space v945_8 = wrap(v945_7,p1);
    const Space v945_9 = wrap(v945_8,constant_6);
    const Space v945_10 = intersect(constant_3,v945_2);
    const Space v945_11 = (has_head(v945_10) ? constant_4 : Space{});
    const Space v945_12 = subtract(constant_2,v945_11);
    Space v945_14;
    if (!v945_12.empty()) {
      Space v947_13_result;
      for (int v947_13_label = 1; v947_13_label <= 2; ++v947_13_label) {
        const Space v947_13_tail = child(v944_10_tail,v947_13_label);
        if (v947_13_tail.empty()) continue;
        const Path v947_13_head{v947_13_label};
        const Space v948_2 = singleton(v947_13_head);
        const Space v948_3 = intersect(constant_3,v948_2);
        const Space v948_4 = (has_head(v948_3) ? constant_4 : Space{});
        const Space v948_5 = subtract(constant_2,v948_4);
        Space v948_8;
        if (!v948_5.empty()) {
          const Path v949_6 = concat_path(v946_6,v947_13_head);
          const Space v949_7 = routine_140(c, v949_6, p1, v947_13_tail);
          v948_8 = compose(v948_5,v949_7);
        }
        const Space v948_9 = intersect(constant_3,v948_2);
        const Space v948_10 = (has_head(v948_9) ? constant_4 : Space{});
        Space v948_12;
        if (!v948_10.empty()) {
          const Path v950_6 = concat_path(v946_6,v947_13_head);
          const Space v950_11 = routine_141(c, v950_6, p1, v947_13_tail);
          v948_12 = compose(v948_10,v950_11);
        }
        const Space v948_13 = unite(v948_8,v948_12);
        v947_13_result = unite(v947_13_result,v948_13);
      }
      const Space v947_13 = std::move(v947_13_result);
      v945_14 = compose(v945_12,v947_13);
    }
    const Space v945_15 = unite(v945_9,v945_14);
    v944_10_result = unite(v944_10_result,v945_15);
  }
  const Space v944_10 = std::move(v944_10_result);
  return v944_10;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v951_3 = Space{};
  return v951_3;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v952_7_result;
  for (int v952_7_label = 1; v952_7_label <= 2; ++v952_7_label) {
    const Space v952_7_tail = child(s0,v952_7_label);
    if (v952_7_tail.empty()) continue;
    const Path v952_7_head{v952_7_label};
    const Space v953_2 = singleton(v952_7_head);
    const Space v953_3 = intersect(constant_3,v953_2);
    const Space v953_4 = (has_head(v953_3) ? constant_4 : Space{});
    Space v953_7;
    if (!v953_4.empty()) {
      const Path v954_5 = concat_path(p0,v952_7_head);
      Space v954_6_result;
      for (int v954_6_label = 1; v954_6_label <= 2; ++v954_6_label) {
        const Space v954_6_tail = child(v952_7_tail,v954_6_label);
        if (v954_6_tail.empty()) continue;
        const Path v954_6_head{v954_6_label};
        const Space v955_2 = singleton(v954_6_head);
        const Space v955_3 = intersect(constant_3,v955_2);
        const Space v955_4 = (has_head(v955_3) ? constant_4 : Space{});
        const Space v955_5 = subtract(constant_2,v955_4);
        Space v955_7;
        if (!v955_5.empty()) {
          const Space v956_6 = routine_25(c, v954_6_head, v954_5, v954_6_tail, s1);
          v955_7 = compose(v955_5,v956_6);
        }
        const Space v955_8 = intersect(constant_3,v955_2);
        const Space v955_9 = (has_head(v955_8) ? constant_4 : Space{});
        Space v955_11;
        if (!v955_9.empty()) {
          const Space v957_10 = routine_26(c, v954_6_head, v954_5, v954_6_tail, s1);
          v955_11 = compose(v955_9,v957_10);
        }
        const Space v955_12 = unite(v955_7,v955_11);
        v954_6_result = unite(v954_6_result,v955_12);
      }
      const Space v954_6 = std::move(v954_6_result);
      v953_7 = compose(v953_4,v954_6);
    }
    v952_7_result = unite(v952_7_result,v953_7);
  }
  const Space v952_7 = std::move(v952_7_result);
  return v952_7;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v958_13_result;
  for (int v958_13_label = 1; v958_13_label <= 2; ++v958_13_label) {
    const Space v958_13_tail = child(s0,v958_13_label);
    if (v958_13_tail.empty()) continue;
    const Path v958_13_head{v958_13_label};
    const Space v959_2 = singleton(v958_13_head);
    const Space v959_3 = intersect(constant_3,v959_2);
    const Space v959_4 = (has_head(v959_3) ? constant_4 : Space{});
    const Space v959_5 = subtract(constant_2,v959_4);
    Space v959_8;
    if (!v959_5.empty()) {
      const Path v960_6 = concat_path(p0,v958_13_head);
      Space v960_7_result;
      for (int v960_7_label = 1; v960_7_label <= 2; ++v960_7_label) {
        const Space v960_7_tail = child(v958_13_tail,v960_7_label);
        if (v960_7_tail.empty()) continue;
        const Path v960_7_head{v960_7_label};
        const Space v961_2 = singleton(v960_7_head);
        const Space v961_3 = intersect(constant_3,v961_2);
        const Space v961_4 = (has_head(v961_3) ? constant_4 : Space{});
        const Space v961_5 = subtract(constant_2,v961_4);
        Space v961_8;
        if (!v961_5.empty()) {
          const Path v962_6 = concat_path(v960_6,v960_7_head);
          const Space v962_7 = routine_142(c, v962_6, p1, v960_7_tail, s1);
          v961_8 = compose(v961_5,v962_7);
        }
        const Space v961_9 = intersect(constant_3,v961_2);
        const Space v961_10 = (has_head(v961_9) ? constant_4 : Space{});
        Space v961_12;
        if (!v961_10.empty()) {
          const Path v963_6 = concat_path(v960_6,v960_7_head);
          const Space v963_11 = routine_143(c, v963_6, p1, v960_7_tail, s1);
          v961_12 = compose(v961_10,v963_11);
        }
        const Space v961_13 = unite(v961_8,v961_12);
        v960_7_result = unite(v960_7_result,v961_13);
      }
      const Space v960_7 = std::move(v960_7_result);
      v959_8 = compose(v959_5,v960_7);
    }
    const Space v959_9 = intersect(constant_3,v959_2);
    const Space v959_10 = (has_head(v959_9) ? constant_4 : Space{});
    Space v959_12;
    if (!v959_10.empty()) {
      const Path v964_6 = concat_path(p0,v958_13_head);
      Space v964_11_result;
      for (int v964_11_label = 1; v964_11_label <= 2; ++v964_11_label) {
        const Space v964_11_tail = child(v958_13_tail,v964_11_label);
        if (v964_11_tail.empty()) continue;
        const Path v964_11_head{v964_11_label};
        const Space v965_2 = singleton(v964_11_head);
        const Space v965_3 = intersect(constant_3,v965_2);
        const Space v965_4 = (has_head(v965_3) ? constant_4 : Space{});
        const Space v965_5 = subtract(constant_2,v965_4);
        Space v965_8;
        if (!v965_5.empty()) {
          const Path v966_6 = concat_path(v964_6,v964_11_head);
          const Space v966_7 = routine_142(c, v966_6, p1, v964_11_tail, s1);
          v965_8 = compose(v965_5,v966_7);
        }
        const Space v965_9 = intersect(constant_3,v965_2);
        const Space v965_10 = (has_head(v965_9) ? constant_4 : Space{});
        Space v965_12;
        if (!v965_10.empty()) {
          const Path v967_6 = concat_path(v964_6,v964_11_head);
          const Space v967_11 = routine_29(c, v967_6, p1, v964_11_tail, s1);
          v965_12 = compose(v965_10,v967_11);
        }
        const Space v965_13 = unite(v965_8,v965_12);
        v964_11_result = unite(v964_11_result,v965_13);
      }
      const Space v964_11 = std::move(v964_11_result);
      v959_12 = compose(v959_10,v964_11);
    }
    const Space v959_13 = unite(v959_8,v959_12);
    v958_13_result = unite(v958_13_result,v959_13);
  }
  const Space v958_13 = std::move(v958_13_result);
  return v958_13;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v968_8 = unwrap(s1,constant_5);
  const Space v968_10 = unwrap(v968_8,constant_6);
  const Space v968_11 = unwrap(v968_10,p0);
  Space v968_18_result;
  for (int v968_18_label = 1; v968_18_label <= 2; ++v968_18_label) {
    const Space v968_18_tail = child(s0,v968_18_label);
    if (v968_18_tail.empty()) continue;
    const Path v968_18_head{v968_18_label};
    const Space v969_2 = singleton(v968_18_head);
    const Space v969_3 = intersect(constant_3,v969_2);
    const Space v969_4 = (has_head(v969_3) ? constant_4 : Space{});
    const Space v969_5 = subtract(constant_2,v969_4);
    Space v969_8;
    if (!v969_5.empty()) {
      const Path v970_6 = concat_path(p0,v968_18_head);
      Space v970_7_result;
      for (int v970_7_label = 1; v970_7_label <= 2; ++v970_7_label) {
        const Space v970_7_tail = child(v968_18_tail,v970_7_label);
        if (v970_7_tail.empty()) continue;
        const Path v970_7_head{v970_7_label};
        const Space v971_2 = singleton(v970_7_head);
        const Space v971_3 = intersect(constant_3,v971_2);
        const Space v971_4 = (has_head(v971_3) ? constant_4 : Space{});
        const Space v971_5 = subtract(constant_2,v971_4);
        Space v971_8;
        if (!v971_5.empty()) {
          const Path v972_6 = concat_path(v970_6,v970_7_head);
          const Space v972_7 = routine_142(c, v972_6, p1, v970_7_tail, s1);
          v971_8 = compose(v971_5,v972_7);
        }
        const Space v971_9 = intersect(constant_3,v971_2);
        const Space v971_10 = (has_head(v971_9) ? constant_4 : Space{});
        Space v971_12;
        if (!v971_10.empty()) {
          const Path v973_6 = concat_path(v970_6,v970_7_head);
          const Space v973_11 = routine_143(c, v973_6, p1, v970_7_tail, s1);
          v971_12 = compose(v971_10,v973_11);
        }
        const Space v971_13 = unite(v971_8,v971_12);
        v970_7_result = unite(v970_7_result,v971_13);
      }
      const Space v970_7 = std::move(v970_7_result);
      v969_8 = compose(v969_5,v970_7);
    }
    const Space v969_9 = intersect(constant_3,v969_2);
    const Space v969_10 = (has_head(v969_9) ? constant_4 : Space{});
    Space v969_13;
    if (!v969_10.empty()) {
      const Space v974_11 = unwrap(v968_11,v968_18_head);
      Space v974_12_result;
      for (int v974_12_label = 1; v974_12_label <= 2; ++v974_12_label) {
        const Space v974_12_tail = child(v974_11,v974_12_label);
        if (v974_12_tail.empty()) continue;
        const Path v974_12_head{v974_12_label};
        const Space v975_2 = singleton(v974_12_head);
        const Space v975_3 = intersect(constant_3,v975_2);
        const Space v975_4 = (has_head(v975_3) ? constant_4 : Space{});
        const Space v975_5 = subtract(constant_2,v975_4);
        Space v975_7;
        if (!v975_5.empty()) {
          const Space v976_6 = routine_61(c, v974_12_head, p1, v974_12_tail);
          v975_7 = compose(v975_5,v976_6);
        }
        const Space v975_8 = intersect(constant_3,v975_2);
        const Space v975_9 = (has_head(v975_8) ? constant_4 : Space{});
        Space v975_11;
        if (!v975_9.empty()) {
          const Space v977_10 = routine_62(c, v974_12_head, p1, v974_12_tail);
          v975_11 = compose(v975_9,v977_10);
        }
        const Space v975_12 = unite(v975_7,v975_11);
        v974_12_result = unite(v974_12_result,v975_12);
      }
      const Space v974_12 = std::move(v974_12_result);
      v969_13 = compose(v969_10,v974_12);
    }
    const Space v969_14 = unite(v969_8,v969_13);
    v968_18_result = unite(v968_18_result,v969_14);
  }
  const Space v968_18 = std::move(v968_18_result);
  return v968_18;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v978_12_result;
  for (int v978_12_label = 1; v978_12_label <= 2; ++v978_12_label) {
    const Space v978_12_tail = child(s0,v978_12_label);
    if (v978_12_tail.empty()) continue;
    const Path v978_12_head{v978_12_label};
    const Space v979_2 = singleton(v978_12_head);
    const Space v979_3 = intersect(constant_3,v979_2);
    const Space v979_4 = (has_head(v979_3) ? constant_4 : Space{});
    const Space v979_5 = subtract(constant_2,v979_4);
    Space v979_8;
    if (!v979_5.empty()) {
      const Path v980_6 = concat_path(p0,v978_12_head);
      Space v980_7_result;
      for (int v980_7_label = 1; v980_7_label <= 2; ++v980_7_label) {
        const Space v980_7_tail = child(v978_12_tail,v980_7_label);
        if (v980_7_tail.empty()) continue;
        const Path v980_7_head{v980_7_label};
        const Space v981_2 = singleton(v980_7_head);
        const Space v981_3 = intersect(constant_3,v981_2);
        const Space v981_4 = (has_head(v981_3) ? constant_4 : Space{});
        const Space v981_5 = subtract(constant_2,v981_4);
        Space v981_8;
        if (!v981_5.empty()) {
          const Path v982_6 = concat_path(v980_6,v980_7_head);
          const Space v982_7 = routine_144(c, v982_6, p1, v980_7_tail);
          v981_8 = compose(v981_5,v982_7);
        }
        const Space v981_9 = intersect(constant_3,v981_2);
        const Space v981_10 = (has_head(v981_9) ? constant_4 : Space{});
        Space v981_12;
        if (!v981_10.empty()) {
          const Path v983_6 = concat_path(v980_6,v980_7_head);
          const Space v983_11 = routine_145(c, v983_6, p1, v980_7_tail);
          v981_12 = compose(v981_10,v983_11);
        }
        const Space v981_13 = unite(v981_8,v981_12);
        v980_7_result = unite(v980_7_result,v981_13);
      }
      const Space v980_7 = std::move(v980_7_result);
      v979_8 = compose(v979_5,v980_7);
    }
    const Space v979_9 = intersect(constant_3,v979_2);
    const Space v979_10 = (has_head(v979_9) ? constant_4 : Space{});
    Space v979_12;
    if (!v979_10.empty()) {
      const Path v984_6 = concat_path(p0,v978_12_head);
      Space v984_11_result;
      for (int v984_11_label = 1; v984_11_label <= 2; ++v984_11_label) {
        const Space v984_11_tail = child(v978_12_tail,v984_11_label);
        if (v984_11_tail.empty()) continue;
        const Path v984_11_head{v984_11_label};
        const Space v985_2 = singleton(v984_11_head);
        const Space v985_3 = intersect(constant_3,v985_2);
        const Space v985_4 = (has_head(v985_3) ? constant_4 : Space{});
        const Space v985_5 = subtract(constant_2,v985_4);
        Space v985_8;
        if (!v985_5.empty()) {
          const Path v986_6 = concat_path(v984_6,v984_11_head);
          const Space v986_7 = routine_144(c, v986_6, p1, v984_11_tail);
          v985_8 = compose(v985_5,v986_7);
        }
        const Space v985_9 = intersect(constant_3,v985_2);
        const Space v985_10 = (has_head(v985_9) ? constant_4 : Space{});
        Space v985_12;
        if (!v985_10.empty()) {
          const Path v987_6 = concat_path(v984_6,v984_11_head);
          const Space v987_11 = routine_67(c, v987_6, p1, v984_11_tail);
          v985_12 = compose(v985_10,v987_11);
        }
        const Space v985_13 = unite(v985_8,v985_12);
        v984_11_result = unite(v984_11_result,v985_13);
      }
      const Space v984_11 = std::move(v984_11_result);
      v979_12 = compose(v979_10,v984_11);
    }
    const Space v979_13 = unite(v979_8,v979_12);
    v978_12_result = unite(v978_12_result,v979_13);
  }
  const Space v978_12 = std::move(v978_12_result);
  return v978_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v988_9_result;
  for (int v988_9_label = 1; v988_9_label <= 2; ++v988_9_label) {
    const Space v988_9_tail = child(s0,v988_9_label);
    if (v988_9_tail.empty()) continue;
    const Path v988_9_head{v988_9_label};
    const Space v989_2 = singleton(v988_9_head);
    const Space v989_3 = intersect(constant_3,v989_2);
    const Space v989_4 = (has_head(v989_3) ? constant_4 : Space{});
    const Space v989_5 = subtract(constant_2,v989_4);
    Space v989_8;
    if (!v989_5.empty()) {
      const Path v990_6 = concat_path(p0,v988_9_head);
      Space v990_7_result;
      for (int v990_7_label = 1; v990_7_label <= 2; ++v990_7_label) {
        const Space v990_7_tail = child(v988_9_tail,v990_7_label);
        if (v990_7_tail.empty()) continue;
        const Path v990_7_head{v990_7_label};
        const Space v991_2 = singleton(v990_7_head);
        const Space v991_3 = intersect(constant_3,v991_2);
        const Space v991_4 = (has_head(v991_3) ? constant_4 : Space{});
        const Space v991_5 = subtract(constant_2,v991_4);
        Space v991_8;
        if (!v991_5.empty()) {
          const Path v992_6 = concat_path(v990_6,v990_7_head);
          const Space v992_7 = routine_144(c, v992_6, p1, v990_7_tail);
          v991_8 = compose(v991_5,v992_7);
        }
        const Space v991_9 = intersect(constant_3,v991_2);
        const Space v991_10 = (has_head(v991_9) ? constant_4 : Space{});
        Space v991_12;
        if (!v991_10.empty()) {
          const Path v993_6 = concat_path(v990_6,v990_7_head);
          const Space v993_11 = routine_145(c, v993_6, p1, v990_7_tail);
          v991_12 = compose(v991_10,v993_11);
        }
        const Space v991_13 = unite(v991_8,v991_12);
        v990_7_result = unite(v990_7_result,v991_13);
      }
      const Space v990_7 = std::move(v990_7_result);
      v989_8 = compose(v989_5,v990_7);
    }
    const Space v989_9 = intersect(constant_3,v989_2);
    const Space v989_10 = (has_head(v989_9) ? constant_4 : Space{});
    const Space v989_11 = compose(v989_10,v988_9_tail);
    const Path v994_6 = concat_path(p0,v988_9_head);
    const Space v989_12 = wrap(v989_11,v994_6);
    const Space v989_13 = wrap(v989_12,p1);
    const Space v989_14 = unite(v989_8,v989_13);
    v988_9_result = unite(v988_9_result,v989_14);
  }
  const Space v988_9 = std::move(v988_9_result);
  return v988_9;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v995_13_result;
  for (int v995_13_label = 1; v995_13_label <= 2; ++v995_13_label) {
    const Space v995_13_tail = child(s0,v995_13_label);
    if (v995_13_tail.empty()) continue;
    const Path v995_13_head{v995_13_label};
    const Space v996_2 = singleton(v995_13_head);
    const Space v996_3 = intersect(constant_3,v996_2);
    const Space v996_4 = (has_head(v996_3) ? constant_4 : Space{});
    const Space v996_5 = subtract(constant_2,v996_4);
    Space v996_8;
    if (!v996_5.empty()) {
      const Path v997_6 = concat_path(p0,v995_13_head);
      Space v997_7_result;
      for (int v997_7_label = 1; v997_7_label <= 2; ++v997_7_label) {
        const Space v997_7_tail = child(v995_13_tail,v997_7_label);
        if (v997_7_tail.empty()) continue;
        const Path v997_7_head{v997_7_label};
        const Space v998_2 = singleton(v997_7_head);
        const Space v998_3 = intersect(constant_3,v998_2);
        const Space v998_4 = (has_head(v998_3) ? constant_4 : Space{});
        const Space v998_5 = subtract(constant_2,v998_4);
        Space v998_8;
        if (!v998_5.empty()) {
          const Path v999_6 = concat_path(v997_6,v997_7_head);
          const Space v999_7 = routine_146(c, v999_6, p1, v997_7_tail, s1);
          v998_8 = compose(v998_5,v999_7);
        }
        const Space v998_9 = intersect(constant_3,v998_2);
        const Space v998_10 = (has_head(v998_9) ? constant_4 : Space{});
        Space v998_12;
        if (!v998_10.empty()) {
          const Path v1000_6 = concat_path(v997_6,v997_7_head);
          const Space v1000_11 = routine_147(c, v1000_6, p1, v997_7_tail, s1);
          v998_12 = compose(v998_10,v1000_11);
        }
        const Space v998_13 = unite(v998_8,v998_12);
        v997_7_result = unite(v997_7_result,v998_13);
      }
      const Space v997_7 = std::move(v997_7_result);
      v996_8 = compose(v996_5,v997_7);
    }
    const Space v996_9 = intersect(constant_3,v996_2);
    const Space v996_10 = (has_head(v996_9) ? constant_4 : Space{});
    Space v996_12;
    if (!v996_10.empty()) {
      const Path v1001_6 = concat_path(p0,v995_13_head);
      Space v1001_11_result;
      for (int v1001_11_label = 1; v1001_11_label <= 2; ++v1001_11_label) {
        const Space v1001_11_tail = child(v995_13_tail,v1001_11_label);
        if (v1001_11_tail.empty()) continue;
        const Path v1001_11_head{v1001_11_label};
        const Space v1002_2 = singleton(v1001_11_head);
        const Space v1002_3 = intersect(constant_3,v1002_2);
        const Space v1002_4 = (has_head(v1002_3) ? constant_4 : Space{});
        const Space v1002_5 = subtract(constant_2,v1002_4);
        Space v1002_8;
        if (!v1002_5.empty()) {
          const Path v1003_6 = concat_path(v1001_6,v1001_11_head);
          const Space v1003_7 = routine_146(c, v1003_6, p1, v1001_11_tail, s1);
          v1002_8 = compose(v1002_5,v1003_7);
        }
        const Space v1002_9 = intersect(constant_3,v1002_2);
        const Space v1002_10 = (has_head(v1002_9) ? constant_4 : Space{});
        Space v1002_12;
        if (!v1002_10.empty()) {
          const Path v1004_6 = concat_path(v1001_6,v1001_11_head);
          const Space v1004_11 = routine_29(c, v1004_6, p1, v1001_11_tail, s1);
          v1002_12 = compose(v1002_10,v1004_11);
        }
        const Space v1002_13 = unite(v1002_8,v1002_12);
        v1001_11_result = unite(v1001_11_result,v1002_13);
      }
      const Space v1001_11 = std::move(v1001_11_result);
      v996_12 = compose(v996_10,v1001_11);
    }
    const Space v996_13 = unite(v996_8,v996_12);
    v995_13_result = unite(v995_13_result,v996_13);
  }
  const Space v995_13 = std::move(v995_13_result);
  return v995_13;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1005_8 = unwrap(s1,constant_5);
  const Space v1005_10 = unwrap(v1005_8,constant_6);
  const Space v1005_11 = unwrap(v1005_10,p0);
  Space v1005_18_result;
  for (int v1005_18_label = 1; v1005_18_label <= 2; ++v1005_18_label) {
    const Space v1005_18_tail = child(s0,v1005_18_label);
    if (v1005_18_tail.empty()) continue;
    const Path v1005_18_head{v1005_18_label};
    const Space v1006_2 = singleton(v1005_18_head);
    const Space v1006_3 = intersect(constant_3,v1006_2);
    const Space v1006_4 = (has_head(v1006_3) ? constant_4 : Space{});
    const Space v1006_5 = subtract(constant_2,v1006_4);
    Space v1006_8;
    if (!v1006_5.empty()) {
      const Path v1007_6 = concat_path(p0,v1005_18_head);
      Space v1007_7_result;
      for (int v1007_7_label = 1; v1007_7_label <= 2; ++v1007_7_label) {
        const Space v1007_7_tail = child(v1005_18_tail,v1007_7_label);
        if (v1007_7_tail.empty()) continue;
        const Path v1007_7_head{v1007_7_label};
        const Space v1008_2 = singleton(v1007_7_head);
        const Space v1008_3 = intersect(constant_3,v1008_2);
        const Space v1008_4 = (has_head(v1008_3) ? constant_4 : Space{});
        const Space v1008_5 = subtract(constant_2,v1008_4);
        Space v1008_8;
        if (!v1008_5.empty()) {
          const Path v1009_6 = concat_path(v1007_6,v1007_7_head);
          const Space v1009_7 = routine_146(c, v1009_6, p1, v1007_7_tail, s1);
          v1008_8 = compose(v1008_5,v1009_7);
        }
        const Space v1008_9 = intersect(constant_3,v1008_2);
        const Space v1008_10 = (has_head(v1008_9) ? constant_4 : Space{});
        Space v1008_12;
        if (!v1008_10.empty()) {
          const Path v1010_6 = concat_path(v1007_6,v1007_7_head);
          const Space v1010_11 = routine_147(c, v1010_6, p1, v1007_7_tail, s1);
          v1008_12 = compose(v1008_10,v1010_11);
        }
        const Space v1008_13 = unite(v1008_8,v1008_12);
        v1007_7_result = unite(v1007_7_result,v1008_13);
      }
      const Space v1007_7 = std::move(v1007_7_result);
      v1006_8 = compose(v1006_5,v1007_7);
    }
    const Space v1006_9 = intersect(constant_3,v1006_2);
    const Space v1006_10 = (has_head(v1006_9) ? constant_4 : Space{});
    Space v1006_13;
    if (!v1006_10.empty()) {
      const Space v1011_11 = unwrap(v1005_11,v1005_18_head);
      Space v1011_12_result;
      for (int v1011_12_label = 1; v1011_12_label <= 2; ++v1011_12_label) {
        const Space v1011_12_tail = child(v1011_11,v1011_12_label);
        if (v1011_12_tail.empty()) continue;
        const Path v1011_12_head{v1011_12_label};
        const Space v1012_2 = singleton(v1011_12_head);
        const Space v1012_3 = intersect(constant_3,v1012_2);
        const Space v1012_4 = (has_head(v1012_3) ? constant_4 : Space{});
        const Space v1012_5 = subtract(constant_2,v1012_4);
        Space v1012_7;
        if (!v1012_5.empty()) {
          const Space v1013_6 = routine_61(c, v1011_12_head, p1, v1011_12_tail);
          v1012_7 = compose(v1012_5,v1013_6);
        }
        const Space v1012_8 = intersect(constant_3,v1012_2);
        const Space v1012_9 = (has_head(v1012_8) ? constant_4 : Space{});
        Space v1012_11;
        if (!v1012_9.empty()) {
          const Space v1014_10 = routine_62(c, v1011_12_head, p1, v1011_12_tail);
          v1012_11 = compose(v1012_9,v1014_10);
        }
        const Space v1012_12 = unite(v1012_7,v1012_11);
        v1011_12_result = unite(v1011_12_result,v1012_12);
      }
      const Space v1011_12 = std::move(v1011_12_result);
      v1006_13 = compose(v1006_10,v1011_12);
    }
    const Space v1006_14 = unite(v1006_8,v1006_13);
    v1005_18_result = unite(v1005_18_result,v1006_14);
  }
  const Space v1005_18 = std::move(v1005_18_result);
  return v1005_18;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1015_12_result;
  for (int v1015_12_label = 1; v1015_12_label <= 2; ++v1015_12_label) {
    const Space v1015_12_tail = child(s0,v1015_12_label);
    if (v1015_12_tail.empty()) continue;
    const Path v1015_12_head{v1015_12_label};
    const Space v1016_2 = singleton(v1015_12_head);
    const Space v1016_3 = intersect(constant_3,v1016_2);
    const Space v1016_4 = (has_head(v1016_3) ? constant_4 : Space{});
    const Space v1016_5 = subtract(constant_2,v1016_4);
    Space v1016_8;
    if (!v1016_5.empty()) {
      const Path v1017_6 = concat_path(p0,v1015_12_head);
      Space v1017_7_result;
      for (int v1017_7_label = 1; v1017_7_label <= 2; ++v1017_7_label) {
        const Space v1017_7_tail = child(v1015_12_tail,v1017_7_label);
        if (v1017_7_tail.empty()) continue;
        const Path v1017_7_head{v1017_7_label};
        const Space v1018_2 = singleton(v1017_7_head);
        const Space v1018_3 = intersect(constant_3,v1018_2);
        const Space v1018_4 = (has_head(v1018_3) ? constant_4 : Space{});
        const Space v1018_5 = subtract(constant_2,v1018_4);
        Space v1018_8;
        if (!v1018_5.empty()) {
          const Path v1019_6 = concat_path(v1017_6,v1017_7_head);
          const Space v1019_7 = routine_148(c, v1019_6, p1, v1017_7_tail);
          v1018_8 = compose(v1018_5,v1019_7);
        }
        const Space v1018_9 = intersect(constant_3,v1018_2);
        const Space v1018_10 = (has_head(v1018_9) ? constant_4 : Space{});
        Space v1018_12;
        if (!v1018_10.empty()) {
          const Path v1020_6 = concat_path(v1017_6,v1017_7_head);
          const Space v1020_11 = routine_149(c, v1020_6, p1, v1017_7_tail);
          v1018_12 = compose(v1018_10,v1020_11);
        }
        const Space v1018_13 = unite(v1018_8,v1018_12);
        v1017_7_result = unite(v1017_7_result,v1018_13);
      }
      const Space v1017_7 = std::move(v1017_7_result);
      v1016_8 = compose(v1016_5,v1017_7);
    }
    const Space v1016_9 = intersect(constant_3,v1016_2);
    const Space v1016_10 = (has_head(v1016_9) ? constant_4 : Space{});
    Space v1016_12;
    if (!v1016_10.empty()) {
      const Path v1021_6 = concat_path(p0,v1015_12_head);
      Space v1021_11_result;
      for (int v1021_11_label = 1; v1021_11_label <= 2; ++v1021_11_label) {
        const Space v1021_11_tail = child(v1015_12_tail,v1021_11_label);
        if (v1021_11_tail.empty()) continue;
        const Path v1021_11_head{v1021_11_label};
        const Space v1022_2 = singleton(v1021_11_head);
        const Space v1022_3 = intersect(constant_3,v1022_2);
        const Space v1022_4 = (has_head(v1022_3) ? constant_4 : Space{});
        const Space v1022_5 = subtract(constant_2,v1022_4);
        Space v1022_8;
        if (!v1022_5.empty()) {
          const Path v1023_6 = concat_path(v1021_6,v1021_11_head);
          const Space v1023_7 = routine_148(c, v1023_6, p1, v1021_11_tail);
          v1022_8 = compose(v1022_5,v1023_7);
        }
        const Space v1022_9 = intersect(constant_3,v1022_2);
        const Space v1022_10 = (has_head(v1022_9) ? constant_4 : Space{});
        Space v1022_12;
        if (!v1022_10.empty()) {
          const Path v1024_6 = concat_path(v1021_6,v1021_11_head);
          const Space v1024_11 = routine_67(c, v1024_6, p1, v1021_11_tail);
          v1022_12 = compose(v1022_10,v1024_11);
        }
        const Space v1022_13 = unite(v1022_8,v1022_12);
        v1021_11_result = unite(v1021_11_result,v1022_13);
      }
      const Space v1021_11 = std::move(v1021_11_result);
      v1016_12 = compose(v1016_10,v1021_11);
    }
    const Space v1016_13 = unite(v1016_8,v1016_12);
    v1015_12_result = unite(v1015_12_result,v1016_13);
  }
  const Space v1015_12 = std::move(v1015_12_result);
  return v1015_12;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1025_9_result;
  for (int v1025_9_label = 1; v1025_9_label <= 2; ++v1025_9_label) {
    const Space v1025_9_tail = child(s0,v1025_9_label);
    if (v1025_9_tail.empty()) continue;
    const Path v1025_9_head{v1025_9_label};
    const Space v1026_2 = singleton(v1025_9_head);
    const Space v1026_3 = intersect(constant_3,v1026_2);
    const Space v1026_4 = (has_head(v1026_3) ? constant_4 : Space{});
    const Space v1026_5 = subtract(constant_2,v1026_4);
    Space v1026_8;
    if (!v1026_5.empty()) {
      const Path v1027_6 = concat_path(p0,v1025_9_head);
      Space v1027_7_result;
      for (int v1027_7_label = 1; v1027_7_label <= 2; ++v1027_7_label) {
        const Space v1027_7_tail = child(v1025_9_tail,v1027_7_label);
        if (v1027_7_tail.empty()) continue;
        const Path v1027_7_head{v1027_7_label};
        const Space v1028_2 = singleton(v1027_7_head);
        const Space v1028_3 = intersect(constant_3,v1028_2);
        const Space v1028_4 = (has_head(v1028_3) ? constant_4 : Space{});
        const Space v1028_5 = subtract(constant_2,v1028_4);
        Space v1028_8;
        if (!v1028_5.empty()) {
          const Path v1029_6 = concat_path(v1027_6,v1027_7_head);
          const Space v1029_7 = routine_148(c, v1029_6, p1, v1027_7_tail);
          v1028_8 = compose(v1028_5,v1029_7);
        }
        const Space v1028_9 = intersect(constant_3,v1028_2);
        const Space v1028_10 = (has_head(v1028_9) ? constant_4 : Space{});
        Space v1028_12;
        if (!v1028_10.empty()) {
          const Path v1030_6 = concat_path(v1027_6,v1027_7_head);
          const Space v1030_11 = routine_149(c, v1030_6, p1, v1027_7_tail);
          v1028_12 = compose(v1028_10,v1030_11);
        }
        const Space v1028_13 = unite(v1028_8,v1028_12);
        v1027_7_result = unite(v1027_7_result,v1028_13);
      }
      const Space v1027_7 = std::move(v1027_7_result);
      v1026_8 = compose(v1026_5,v1027_7);
    }
    const Space v1026_9 = intersect(constant_3,v1026_2);
    const Space v1026_10 = (has_head(v1026_9) ? constant_4 : Space{});
    const Space v1026_11 = compose(v1026_10,v1025_9_tail);
    const Path v1031_6 = concat_path(p0,v1025_9_head);
    const Space v1026_12 = wrap(v1026_11,v1031_6);
    const Space v1026_13 = wrap(v1026_12,p1);
    const Space v1026_14 = unite(v1026_8,v1026_13);
    v1025_9_result = unite(v1025_9_result,v1026_14);
  }
  const Space v1025_9 = std::move(v1025_9_result);
  return v1025_9;
}

static Space routine_112(Context& c, const Path& p0, const Space& s0) {
  const Space v1032_2 = Space{};
  return v1032_2;
}

static Space routine_113(Context& c, const Path& p0, const Space& s0) {
  Space v1033_6_result;
  for (int v1033_6_label = 1; v1033_6_label <= 2; ++v1033_6_label) {
    const Space v1033_6_tail = child(s0,v1033_6_label);
    if (v1033_6_tail.empty()) continue;
    const Path v1033_6_head{v1033_6_label};
    const Space v1034_2 = singleton(v1033_6_head);
    const Space v1034_3 = intersect(constant_3,v1034_2);
    const Space v1034_4 = (has_head(v1034_3) ? constant_4 : Space{});
    Space v1034_7;
    if (!v1034_4.empty()) {
      const Path v1035_5 = concat_path(p0,v1033_6_head);
      Space v1035_6_result;
      for (int v1035_6_label = 1; v1035_6_label <= 2; ++v1035_6_label) {
        const Space v1035_6_tail = child(v1033_6_tail,v1035_6_label);
        if (v1035_6_tail.empty()) continue;
        const Path v1035_6_head{v1035_6_label};
        const Space v1036_2 = singleton(v1035_6_head);
        const Space v1036_3 = intersect(constant_3,v1036_2);
        const Space v1036_4 = (has_head(v1036_3) ? constant_4 : Space{});
        const Space v1036_5 = subtract(constant_2,v1036_4);
        Space v1036_7;
        if (!v1036_5.empty()) {
          const Space v1037_6 = routine_32(c, v1035_6_head, v1035_5, v1035_6_tail);
          v1036_7 = compose(v1036_5,v1037_6);
        }
        const Space v1036_8 = intersect(constant_3,v1036_2);
        const Space v1036_9 = (has_head(v1036_8) ? constant_4 : Space{});
        Space v1036_11;
        if (!v1036_9.empty()) {
          const Space v1038_10 = routine_33(c, v1035_6_head, v1035_5, v1035_6_tail);
          v1036_11 = compose(v1036_9,v1038_10);
        }
        const Space v1036_12 = unite(v1036_7,v1036_11);
        v1035_6_result = unite(v1035_6_result,v1036_12);
      }
      const Space v1035_6 = std::move(v1035_6_result);
      v1034_7 = compose(v1034_4,v1035_6);
    }
    v1033_6_result = unite(v1033_6_result,v1034_7);
  }
  const Space v1033_6 = std::move(v1033_6_result);
  return v1033_6;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1039_12_result;
  for (int v1039_12_label = 1; v1039_12_label <= 2; ++v1039_12_label) {
    const Space v1039_12_tail = child(s0,v1039_12_label);
    if (v1039_12_tail.empty()) continue;
    const Path v1039_12_head{v1039_12_label};
    const Space v1040_2 = singleton(v1039_12_head);
    const Space v1040_3 = intersect(constant_3,v1040_2);
    const Space v1040_4 = (has_head(v1040_3) ? constant_4 : Space{});
    const Space v1040_5 = subtract(constant_2,v1040_4);
    Space v1040_8;
    if (!v1040_5.empty()) {
      const Path v1041_6 = concat_path(p0,v1039_12_head);
      Space v1041_7_result;
      for (int v1041_7_label = 1; v1041_7_label <= 2; ++v1041_7_label) {
        const Space v1041_7_tail = child(v1039_12_tail,v1041_7_label);
        if (v1041_7_tail.empty()) continue;
        const Path v1041_7_head{v1041_7_label};
        const Space v1042_2 = singleton(v1041_7_head);
        const Space v1042_3 = intersect(constant_3,v1042_2);
        const Space v1042_4 = (has_head(v1042_3) ? constant_4 : Space{});
        const Space v1042_5 = subtract(constant_2,v1042_4);
        Space v1042_8;
        if (!v1042_5.empty()) {
          const Path v1043_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1043_7 = routine_150(c, v1043_6, p1, v1041_7_tail);
          v1042_8 = compose(v1042_5,v1043_7);
        }
        const Space v1042_9 = intersect(constant_3,v1042_2);
        const Space v1042_10 = (has_head(v1042_9) ? constant_4 : Space{});
        Space v1042_12;
        if (!v1042_10.empty()) {
          const Path v1044_6 = concat_path(v1041_6,v1041_7_head);
          const Space v1044_11 = routine_151(c, v1044_6, p1, v1041_7_tail);
          v1042_12 = compose(v1042_10,v1044_11);
        }
        const Space v1042_13 = unite(v1042_8,v1042_12);
        v1041_7_result = unite(v1041_7_result,v1042_13);
      }
      const Space v1041_7 = std::move(v1041_7_result);
      v1040_8 = compose(v1040_5,v1041_7);
    }
    const Space v1040_9 = intersect(constant_3,v1040_2);
    const Space v1040_10 = (has_head(v1040_9) ? constant_4 : Space{});
    Space v1040_12;
    if (!v1040_10.empty()) {
      const Path v1045_6 = concat_path(p0,v1039_12_head);
      Space v1045_11_result;
      for (int v1045_11_label = 1; v1045_11_label <= 2; ++v1045_11_label) {
        const Space v1045_11_tail = child(v1039_12_tail,v1045_11_label);
        if (v1045_11_tail.empty()) continue;
        const Path v1045_11_head{v1045_11_label};
        const Space v1046_2 = singleton(v1045_11_head);
        const Space v1046_3 = intersect(constant_3,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_4 : Space{});
        const Space v1046_5 = subtract(constant_2,v1046_4);
        Space v1046_8;
        if (!v1046_5.empty()) {
          const Path v1047_6 = concat_path(v1045_6,v1045_11_head);
          const Space v1047_7 = routine_150(c, v1047_6, p1, v1045_11_tail);
          v1046_8 = compose(v1046_5,v1047_7);
        }
        const Space v1046_9 = intersect(constant_3,v1046_2);
        const Space v1046_10 = (has_head(v1046_9) ? constant_4 : Space{});
        Space v1046_12;
        if (!v1046_10.empty()) {
          const Path v1048_6 = concat_path(v1045_6,v1045_11_head);
          const Space v1048_11 = routine_36(c, v1048_6, p1, v1045_11_tail);
          v1046_12 = compose(v1046_10,v1048_11);
        }
        const Space v1046_13 = unite(v1046_8,v1046_12);
        v1045_11_result = unite(v1045_11_result,v1046_13);
      }
      const Space v1045_11 = std::move(v1045_11_result);
      v1040_12 = compose(v1040_10,v1045_11);
    }
    const Space v1040_13 = unite(v1040_8,v1040_12);
    v1039_12_result = unite(v1039_12_result,v1040_13);
  }
  const Space v1039_12 = std::move(v1039_12_result);
  return v1039_12;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1049_9_result;
  for (int v1049_9_label = 1; v1049_9_label <= 2; ++v1049_9_label) {
    const Space v1049_9_tail = child(s0,v1049_9_label);
    if (v1049_9_tail.empty()) continue;
    const Path v1049_9_head{v1049_9_label};
    const Space v1050_2 = singleton(v1049_9_head);
    const Space v1050_3 = intersect(constant_3,v1050_2);
    const Space v1050_4 = (has_head(v1050_3) ? constant_4 : Space{});
    const Space v1050_5 = subtract(constant_2,v1050_4);
    Space v1050_8;
    if (!v1050_5.empty()) {
      const Path v1051_6 = concat_path(p0,v1049_9_head);
      Space v1051_7_result;
      for (int v1051_7_label = 1; v1051_7_label <= 2; ++v1051_7_label) {
        const Space v1051_7_tail = child(v1049_9_tail,v1051_7_label);
        if (v1051_7_tail.empty()) continue;
        const Path v1051_7_head{v1051_7_label};
        const Space v1052_2 = singleton(v1051_7_head);
        const Space v1052_3 = intersect(constant_3,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_4 : Space{});
        const Space v1052_5 = subtract(constant_2,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1053_7 = routine_150(c, v1053_6, p1, v1051_7_tail);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_3,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_4 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1054_11 = routine_151(c, v1054_6, p1, v1051_7_tail);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_7_result = unite(v1051_7_result,v1052_13);
      }
      const Space v1051_7 = std::move(v1051_7_result);
      v1050_8 = compose(v1050_5,v1051_7);
    }
    const Space v1050_9 = intersect(constant_3,v1050_2);
    const Space v1050_10 = (has_head(v1050_9) ? constant_4 : Space{});
    const Space v1050_11 = compose(v1050_10,v1049_9_tail);
    const Path v1055_6 = concat_path(p0,v1049_9_head);
    const Space v1050_12 = wrap(v1050_11,v1055_6);
    const Space v1050_13 = wrap(v1050_12,p1);
    const Space v1050_14 = unite(v1050_8,v1050_13);
    v1049_9_result = unite(v1049_9_result,v1050_14);
  }
  const Space v1049_9 = std::move(v1049_9_result);
  return v1049_9;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1056_12_result;
  for (int v1056_12_label = 1; v1056_12_label <= 2; ++v1056_12_label) {
    const Space v1056_12_tail = child(s0,v1056_12_label);
    if (v1056_12_tail.empty()) continue;
    const Path v1056_12_head{v1056_12_label};
    const Space v1057_2 = singleton(v1056_12_head);
    const Space v1057_3 = intersect(constant_3,v1057_2);
    const Space v1057_4 = (has_head(v1057_3) ? constant_4 : Space{});
    const Space v1057_5 = subtract(constant_2,v1057_4);
    Space v1057_8;
    if (!v1057_5.empty()) {
      const Path v1058_6 = concat_path(p0,v1056_12_head);
      Space v1058_7_result;
      for (int v1058_7_label = 1; v1058_7_label <= 2; ++v1058_7_label) {
        const Space v1058_7_tail = child(v1056_12_tail,v1058_7_label);
        if (v1058_7_tail.empty()) continue;
        const Path v1058_7_head{v1058_7_label};
        const Space v1059_2 = singleton(v1058_7_head);
        const Space v1059_3 = intersect(constant_3,v1059_2);
        const Space v1059_4 = (has_head(v1059_3) ? constant_4 : Space{});
        const Space v1059_5 = subtract(constant_2,v1059_4);
        Space v1059_8;
        if (!v1059_5.empty()) {
          const Path v1060_6 = concat_path(v1058_6,v1058_7_head);
          const Space v1060_7 = routine_152(c, v1060_6, p1, v1058_7_tail);
          v1059_8 = compose(v1059_5,v1060_7);
        }
        const Space v1059_9 = intersect(constant_3,v1059_2);
        const Space v1059_10 = (has_head(v1059_9) ? constant_4 : Space{});
        Space v1059_12;
        if (!v1059_10.empty()) {
          const Path v1061_6 = concat_path(v1058_6,v1058_7_head);
          const Space v1061_11 = routine_153(c, v1061_6, p1, v1058_7_tail);
          v1059_12 = compose(v1059_10,v1061_11);
        }
        const Space v1059_13 = unite(v1059_8,v1059_12);
        v1058_7_result = unite(v1058_7_result,v1059_13);
      }
      const Space v1058_7 = std::move(v1058_7_result);
      v1057_8 = compose(v1057_5,v1058_7);
    }
    const Space v1057_9 = intersect(constant_3,v1057_2);
    const Space v1057_10 = (has_head(v1057_9) ? constant_4 : Space{});
    Space v1057_12;
    if (!v1057_10.empty()) {
      const Path v1062_6 = concat_path(p0,v1056_12_head);
      Space v1062_11_result;
      for (int v1062_11_label = 1; v1062_11_label <= 2; ++v1062_11_label) {
        const Space v1062_11_tail = child(v1056_12_tail,v1062_11_label);
        if (v1062_11_tail.empty()) continue;
        const Path v1062_11_head{v1062_11_label};
        const Space v1063_2 = singleton(v1062_11_head);
        const Space v1063_3 = intersect(constant_3,v1063_2);
        const Space v1063_4 = (has_head(v1063_3) ? constant_4 : Space{});
        const Space v1063_5 = subtract(constant_2,v1063_4);
        Space v1063_8;
        if (!v1063_5.empty()) {
          const Path v1064_6 = concat_path(v1062_6,v1062_11_head);
          const Space v1064_7 = routine_152(c, v1064_6, p1, v1062_11_tail);
          v1063_8 = compose(v1063_5,v1064_7);
        }
        const Space v1063_9 = intersect(constant_3,v1063_2);
        const Space v1063_10 = (has_head(v1063_9) ? constant_4 : Space{});
        Space v1063_12;
        if (!v1063_10.empty()) {
          const Path v1065_6 = concat_path(v1062_6,v1062_11_head);
          const Space v1065_11 = routine_36(c, v1065_6, p1, v1062_11_tail);
          v1063_12 = compose(v1063_10,v1065_11);
        }
        const Space v1063_13 = unite(v1063_8,v1063_12);
        v1062_11_result = unite(v1062_11_result,v1063_13);
      }
      const Space v1062_11 = std::move(v1062_11_result);
      v1057_12 = compose(v1057_10,v1062_11);
    }
    const Space v1057_13 = unite(v1057_8,v1057_12);
    v1056_12_result = unite(v1056_12_result,v1057_13);
  }
  const Space v1056_12 = std::move(v1056_12_result);
  return v1056_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1066_9_result;
  for (int v1066_9_label = 1; v1066_9_label <= 2; ++v1066_9_label) {
    const Space v1066_9_tail = child(s0,v1066_9_label);
    if (v1066_9_tail.empty()) continue;
    const Path v1066_9_head{v1066_9_label};
    const Space v1067_2 = singleton(v1066_9_head);
    const Space v1067_3 = intersect(constant_3,v1067_2);
    const Space v1067_4 = (has_head(v1067_3) ? constant_4 : Space{});
    const Space v1067_5 = subtract(constant_2,v1067_4);
    Space v1067_8;
    if (!v1067_5.empty()) {
      const Path v1068_6 = concat_path(p0,v1066_9_head);
      Space v1068_7_result;
      for (int v1068_7_label = 1; v1068_7_label <= 2; ++v1068_7_label) {
        const Space v1068_7_tail = child(v1066_9_tail,v1068_7_label);
        if (v1068_7_tail.empty()) continue;
        const Path v1068_7_head{v1068_7_label};
        const Space v1069_2 = singleton(v1068_7_head);
        const Space v1069_3 = intersect(constant_3,v1069_2);
        const Space v1069_4 = (has_head(v1069_3) ? constant_4 : Space{});
        const Space v1069_5 = subtract(constant_2,v1069_4);
        Space v1069_8;
        if (!v1069_5.empty()) {
          const Path v1070_6 = concat_path(v1068_6,v1068_7_head);
          const Space v1070_7 = routine_152(c, v1070_6, p1, v1068_7_tail);
          v1069_8 = compose(v1069_5,v1070_7);
        }
        const Space v1069_9 = intersect(constant_3,v1069_2);
        const Space v1069_10 = (has_head(v1069_9) ? constant_4 : Space{});
        Space v1069_12;
        if (!v1069_10.empty()) {
          const Path v1071_6 = concat_path(v1068_6,v1068_7_head);
          const Space v1071_11 = routine_153(c, v1071_6, p1, v1068_7_tail);
          v1069_12 = compose(v1069_10,v1071_11);
        }
        const Space v1069_13 = unite(v1069_8,v1069_12);
        v1068_7_result = unite(v1068_7_result,v1069_13);
      }
      const Space v1068_7 = std::move(v1068_7_result);
      v1067_8 = compose(v1067_5,v1068_7);
    }
    const Space v1067_9 = intersect(constant_3,v1067_2);
    const Space v1067_10 = (has_head(v1067_9) ? constant_4 : Space{});
    const Space v1067_11 = compose(v1067_10,v1066_9_tail);
    const Path v1072_6 = concat_path(p0,v1066_9_head);
    const Space v1067_12 = wrap(v1067_11,v1072_6);
    const Space v1067_13 = wrap(v1067_12,p1);
    const Space v1067_14 = unite(v1067_8,v1067_13);
    v1066_9_result = unite(v1066_9_result,v1067_14);
  }
  const Space v1066_9 = std::move(v1066_9_result);
  return v1066_9;
}

static Space routine_118(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1073_3 = Space{};
  return v1073_3;
}

static Space routine_119(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1074_7_result;
  for (int v1074_7_label = 1; v1074_7_label <= 2; ++v1074_7_label) {
    const Space v1074_7_tail = child(s0,v1074_7_label);
    if (v1074_7_tail.empty()) continue;
    const Path v1074_7_head{v1074_7_label};
    const Space v1075_2 = singleton(v1074_7_head);
    const Space v1075_3 = intersect(constant_3,v1075_2);
    const Space v1075_4 = (has_head(v1075_3) ? constant_4 : Space{});
    Space v1075_7;
    if (!v1075_4.empty()) {
      const Path v1076_5 = concat_path(p0,v1074_7_head);
      Space v1076_6_result;
      for (int v1076_6_label = 1; v1076_6_label <= 2; ++v1076_6_label) {
        const Space v1076_6_tail = child(v1074_7_tail,v1076_6_label);
        if (v1076_6_tail.empty()) continue;
        const Path v1076_6_head{v1076_6_label};
        const Space v1077_2 = singleton(v1076_6_head);
        const Space v1077_3 = intersect(constant_3,v1077_2);
        const Space v1077_4 = (has_head(v1077_3) ? constant_4 : Space{});
        const Space v1077_5 = subtract(constant_2,v1077_4);
        Space v1077_7;
        if (!v1077_5.empty()) {
          const Space v1078_6 = routine_39(c, v1076_6_head, v1076_5, v1076_6_tail, s1);
          v1077_7 = compose(v1077_5,v1078_6);
        }
        const Space v1077_8 = intersect(constant_3,v1077_2);
        const Space v1077_9 = (has_head(v1077_8) ? constant_4 : Space{});
        Space v1077_11;
        if (!v1077_9.empty()) {
          const Space v1079_10 = routine_40(c, v1076_6_head, v1076_5, v1076_6_tail, s1);
          v1077_11 = compose(v1077_9,v1079_10);
        }
        const Space v1077_12 = unite(v1077_7,v1077_11);
        v1076_6_result = unite(v1076_6_result,v1077_12);
      }
      const Space v1076_6 = std::move(v1076_6_result);
      v1075_7 = compose(v1075_4,v1076_6);
    }
    v1074_7_result = unite(v1074_7_result,v1075_7);
  }
  const Space v1074_7 = std::move(v1074_7_result);
  return v1074_7;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1080_13_result;
  for (int v1080_13_label = 1; v1080_13_label <= 2; ++v1080_13_label) {
    const Space v1080_13_tail = child(s0,v1080_13_label);
    if (v1080_13_tail.empty()) continue;
    const Path v1080_13_head{v1080_13_label};
    const Space v1081_2 = singleton(v1080_13_head);
    const Space v1081_3 = intersect(constant_3,v1081_2);
    const Space v1081_4 = (has_head(v1081_3) ? constant_4 : Space{});
    const Space v1081_5 = subtract(constant_2,v1081_4);
    Space v1081_8;
    if (!v1081_5.empty()) {
      const Path v1082_6 = concat_path(p0,v1080_13_head);
      Space v1082_7_result;
      for (int v1082_7_label = 1; v1082_7_label <= 2; ++v1082_7_label) {
        const Space v1082_7_tail = child(v1080_13_tail,v1082_7_label);
        if (v1082_7_tail.empty()) continue;
        const Path v1082_7_head{v1082_7_label};
        const Space v1083_2 = singleton(v1082_7_head);
        const Space v1083_3 = intersect(constant_3,v1083_2);
        const Space v1083_4 = (has_head(v1083_3) ? constant_4 : Space{});
        const Space v1083_5 = subtract(constant_2,v1083_4);
        Space v1083_8;
        if (!v1083_5.empty()) {
          const Path v1084_6 = concat_path(v1082_6,v1082_7_head);
          const Space v1084_7 = routine_154(c, v1084_6, p1, v1082_7_tail, s1);
          v1083_8 = compose(v1083_5,v1084_7);
        }
        const Space v1083_9 = intersect(constant_3,v1083_2);
        const Space v1083_10 = (has_head(v1083_9) ? constant_4 : Space{});
        Space v1083_12;
        if (!v1083_10.empty()) {
          const Path v1085_6 = concat_path(v1082_6,v1082_7_head);
          const Space v1085_11 = routine_155(c, v1085_6, p1, v1082_7_tail, s1);
          v1083_12 = compose(v1083_10,v1085_11);
        }
        const Space v1083_13 = unite(v1083_8,v1083_12);
        v1082_7_result = unite(v1082_7_result,v1083_13);
      }
      const Space v1082_7 = std::move(v1082_7_result);
      v1081_8 = compose(v1081_5,v1082_7);
    }
    const Space v1081_9 = intersect(constant_3,v1081_2);
    const Space v1081_10 = (has_head(v1081_9) ? constant_4 : Space{});
    Space v1081_12;
    if (!v1081_10.empty()) {
      const Path v1086_6 = concat_path(p0,v1080_13_head);
      Space v1086_11_result;
      for (int v1086_11_label = 1; v1086_11_label <= 2; ++v1086_11_label) {
        const Space v1086_11_tail = child(v1080_13_tail,v1086_11_label);
        if (v1086_11_tail.empty()) continue;
        const Path v1086_11_head{v1086_11_label};
        const Space v1087_2 = singleton(v1086_11_head);
        const Space v1087_3 = intersect(constant_3,v1087_2);
        const Space v1087_4 = (has_head(v1087_3) ? constant_4 : Space{});
        const Space v1087_5 = subtract(constant_2,v1087_4);
        Space v1087_8;
        if (!v1087_5.empty()) {
          const Path v1088_6 = concat_path(v1086_6,v1086_11_head);
          const Space v1088_7 = routine_154(c, v1088_6, p1, v1086_11_tail, s1);
          v1087_8 = compose(v1087_5,v1088_7);
        }
        const Space v1087_9 = intersect(constant_3,v1087_2);
        const Space v1087_10 = (has_head(v1087_9) ? constant_4 : Space{});
        Space v1087_12;
        if (!v1087_10.empty()) {
          const Path v1089_6 = concat_path(v1086_6,v1086_11_head);
          const Space v1089_11 = routine_43(c, v1089_6, p1, v1086_11_tail, s1);
          v1087_12 = compose(v1087_10,v1089_11);
        }
        const Space v1087_13 = unite(v1087_8,v1087_12);
        v1086_11_result = unite(v1086_11_result,v1087_13);
      }
      const Space v1086_11 = std::move(v1086_11_result);
      v1081_12 = compose(v1081_10,v1086_11);
    }
    const Space v1081_13 = unite(v1081_8,v1081_12);
    v1080_13_result = unite(v1080_13_result,v1081_13);
  }
  const Space v1080_13 = std::move(v1080_13_result);
  return v1080_13;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1090_8 = unwrap(s1,constant_0);
  const Space v1090_10 = unwrap(v1090_8,constant_6);
  const Space v1090_11 = unwrap(v1090_10,p0);
  Space v1090_18_result;
  for (int v1090_18_label = 1; v1090_18_label <= 2; ++v1090_18_label) {
    const Space v1090_18_tail = child(s0,v1090_18_label);
    if (v1090_18_tail.empty()) continue;
    const Path v1090_18_head{v1090_18_label};
    const Space v1091_2 = singleton(v1090_18_head);
    const Space v1091_3 = intersect(constant_3,v1091_2);
    const Space v1091_4 = (has_head(v1091_3) ? constant_4 : Space{});
    const Space v1091_5 = subtract(constant_2,v1091_4);
    Space v1091_8;
    if (!v1091_5.empty()) {
      const Path v1092_6 = concat_path(p0,v1090_18_head);
      Space v1092_7_result;
      for (int v1092_7_label = 1; v1092_7_label <= 2; ++v1092_7_label) {
        const Space v1092_7_tail = child(v1090_18_tail,v1092_7_label);
        if (v1092_7_tail.empty()) continue;
        const Path v1092_7_head{v1092_7_label};
        const Space v1093_2 = singleton(v1092_7_head);
        const Space v1093_3 = intersect(constant_3,v1093_2);
        const Space v1093_4 = (has_head(v1093_3) ? constant_4 : Space{});
        const Space v1093_5 = subtract(constant_2,v1093_4);
        Space v1093_8;
        if (!v1093_5.empty()) {
          const Path v1094_6 = concat_path(v1092_6,v1092_7_head);
          const Space v1094_7 = routine_154(c, v1094_6, p1, v1092_7_tail, s1);
          v1093_8 = compose(v1093_5,v1094_7);
        }
        const Space v1093_9 = intersect(constant_3,v1093_2);
        const Space v1093_10 = (has_head(v1093_9) ? constant_4 : Space{});
        Space v1093_12;
        if (!v1093_10.empty()) {
          const Path v1095_6 = concat_path(v1092_6,v1092_7_head);
          const Space v1095_11 = routine_155(c, v1095_6, p1, v1092_7_tail, s1);
          v1093_12 = compose(v1093_10,v1095_11);
        }
        const Space v1093_13 = unite(v1093_8,v1093_12);
        v1092_7_result = unite(v1092_7_result,v1093_13);
      }
      const Space v1092_7 = std::move(v1092_7_result);
      v1091_8 = compose(v1091_5,v1092_7);
    }
    const Space v1091_9 = intersect(constant_3,v1091_2);
    const Space v1091_10 = (has_head(v1091_9) ? constant_4 : Space{});
    Space v1091_13;
    if (!v1091_10.empty()) {
      const Space v1096_11 = unwrap(v1090_11,v1090_18_head);
      Space v1096_12_result;
      for (int v1096_12_label = 1; v1096_12_label <= 2; ++v1096_12_label) {
        const Space v1096_12_tail = child(v1096_11,v1096_12_label);
        if (v1096_12_tail.empty()) continue;
        const Path v1096_12_head{v1096_12_label};
        const Space v1097_2 = singleton(v1096_12_head);
        const Space v1097_3 = intersect(constant_3,v1097_2);
        const Space v1097_4 = (has_head(v1097_3) ? constant_4 : Space{});
        const Space v1097_5 = subtract(constant_2,v1097_4);
        Space v1097_7;
        if (!v1097_5.empty()) {
          const Space v1098_6 = routine_78(c, v1096_12_head, p1, v1096_12_tail);
          v1097_7 = compose(v1097_5,v1098_6);
        }
        const Space v1097_8 = intersect(constant_3,v1097_2);
        const Space v1097_9 = (has_head(v1097_8) ? constant_4 : Space{});
        Space v1097_11;
        if (!v1097_9.empty()) {
          const Space v1099_10 = routine_79(c, v1096_12_head, p1, v1096_12_tail);
          v1097_11 = compose(v1097_9,v1099_10);
        }
        const Space v1097_12 = unite(v1097_7,v1097_11);
        v1096_12_result = unite(v1096_12_result,v1097_12);
      }
      const Space v1096_12 = std::move(v1096_12_result);
      v1091_13 = compose(v1091_10,v1096_12);
    }
    const Space v1091_14 = unite(v1091_8,v1091_13);
    v1090_18_result = unite(v1090_18_result,v1091_14);
  }
  const Space v1090_18 = std::move(v1090_18_result);
  return v1090_18;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1100_12_result;
  for (int v1100_12_label = 1; v1100_12_label <= 2; ++v1100_12_label) {
    const Space v1100_12_tail = child(s0,v1100_12_label);
    if (v1100_12_tail.empty()) continue;
    const Path v1100_12_head{v1100_12_label};
    const Space v1101_2 = singleton(v1100_12_head);
    const Space v1101_3 = intersect(constant_3,v1101_2);
    const Space v1101_4 = (has_head(v1101_3) ? constant_4 : Space{});
    const Space v1101_5 = subtract(constant_2,v1101_4);
    Space v1101_8;
    if (!v1101_5.empty()) {
      const Path v1102_6 = concat_path(p0,v1100_12_head);
      Space v1102_7_result;
      for (int v1102_7_label = 1; v1102_7_label <= 2; ++v1102_7_label) {
        const Space v1102_7_tail = child(v1100_12_tail,v1102_7_label);
        if (v1102_7_tail.empty()) continue;
        const Path v1102_7_head{v1102_7_label};
        const Space v1103_2 = singleton(v1102_7_head);
        const Space v1103_3 = intersect(constant_3,v1103_2);
        const Space v1103_4 = (has_head(v1103_3) ? constant_4 : Space{});
        const Space v1103_5 = subtract(constant_2,v1103_4);
        Space v1103_8;
        if (!v1103_5.empty()) {
          const Path v1104_6 = concat_path(v1102_6,v1102_7_head);
          const Space v1104_7 = routine_156(c, v1104_6, p1, v1102_7_tail);
          v1103_8 = compose(v1103_5,v1104_7);
        }
        const Space v1103_9 = intersect(constant_3,v1103_2);
        const Space v1103_10 = (has_head(v1103_9) ? constant_4 : Space{});
        Space v1103_12;
        if (!v1103_10.empty()) {
          const Path v1105_6 = concat_path(v1102_6,v1102_7_head);
          const Space v1105_11 = routine_157(c, v1105_6, p1, v1102_7_tail);
          v1103_12 = compose(v1103_10,v1105_11);
        }
        const Space v1103_13 = unite(v1103_8,v1103_12);
        v1102_7_result = unite(v1102_7_result,v1103_13);
      }
      const Space v1102_7 = std::move(v1102_7_result);
      v1101_8 = compose(v1101_5,v1102_7);
    }
    const Space v1101_9 = intersect(constant_3,v1101_2);
    const Space v1101_10 = (has_head(v1101_9) ? constant_4 : Space{});
    Space v1101_12;
    if (!v1101_10.empty()) {
      const Path v1106_6 = concat_path(p0,v1100_12_head);
      Space v1106_11_result;
      for (int v1106_11_label = 1; v1106_11_label <= 2; ++v1106_11_label) {
        const Space v1106_11_tail = child(v1100_12_tail,v1106_11_label);
        if (v1106_11_tail.empty()) continue;
        const Path v1106_11_head{v1106_11_label};
        const Space v1107_2 = singleton(v1106_11_head);
        const Space v1107_3 = intersect(constant_3,v1107_2);
        const Space v1107_4 = (has_head(v1107_3) ? constant_4 : Space{});
        const Space v1107_5 = subtract(constant_2,v1107_4);
        Space v1107_8;
        if (!v1107_5.empty()) {
          const Path v1108_6 = concat_path(v1106_6,v1106_11_head);
          const Space v1108_7 = routine_156(c, v1108_6, p1, v1106_11_tail);
          v1107_8 = compose(v1107_5,v1108_7);
        }
        const Space v1107_9 = intersect(constant_3,v1107_2);
        const Space v1107_10 = (has_head(v1107_9) ? constant_4 : Space{});
        Space v1107_12;
        if (!v1107_10.empty()) {
          const Path v1109_6 = concat_path(v1106_6,v1106_11_head);
          const Space v1109_11 = routine_84(c, v1109_6, p1, v1106_11_tail);
          v1107_12 = compose(v1107_10,v1109_11);
        }
        const Space v1107_13 = unite(v1107_8,v1107_12);
        v1106_11_result = unite(v1106_11_result,v1107_13);
      }
      const Space v1106_11 = std::move(v1106_11_result);
      v1101_12 = compose(v1101_10,v1106_11);
    }
    const Space v1101_13 = unite(v1101_8,v1101_12);
    v1100_12_result = unite(v1100_12_result,v1101_13);
  }
  const Space v1100_12 = std::move(v1100_12_result);
  return v1100_12;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1110_9_result;
  for (int v1110_9_label = 1; v1110_9_label <= 2; ++v1110_9_label) {
    const Space v1110_9_tail = child(s0,v1110_9_label);
    if (v1110_9_tail.empty()) continue;
    const Path v1110_9_head{v1110_9_label};
    const Space v1111_2 = singleton(v1110_9_head);
    const Space v1111_3 = intersect(constant_3,v1111_2);
    const Space v1111_4 = (has_head(v1111_3) ? constant_4 : Space{});
    const Space v1111_5 = subtract(constant_2,v1111_4);
    Space v1111_8;
    if (!v1111_5.empty()) {
      const Path v1112_6 = concat_path(p0,v1110_9_head);
      Space v1112_7_result;
      for (int v1112_7_label = 1; v1112_7_label <= 2; ++v1112_7_label) {
        const Space v1112_7_tail = child(v1110_9_tail,v1112_7_label);
        if (v1112_7_tail.empty()) continue;
        const Path v1112_7_head{v1112_7_label};
        const Space v1113_2 = singleton(v1112_7_head);
        const Space v1113_3 = intersect(constant_3,v1113_2);
        const Space v1113_4 = (has_head(v1113_3) ? constant_4 : Space{});
        const Space v1113_5 = subtract(constant_2,v1113_4);
        Space v1113_8;
        if (!v1113_5.empty()) {
          const Path v1114_6 = concat_path(v1112_6,v1112_7_head);
          const Space v1114_7 = routine_156(c, v1114_6, p1, v1112_7_tail);
          v1113_8 = compose(v1113_5,v1114_7);
        }
        const Space v1113_9 = intersect(constant_3,v1113_2);
        const Space v1113_10 = (has_head(v1113_9) ? constant_4 : Space{});
        Space v1113_12;
        if (!v1113_10.empty()) {
          const Path v1115_6 = concat_path(v1112_6,v1112_7_head);
          const Space v1115_11 = routine_157(c, v1115_6, p1, v1112_7_tail);
          v1113_12 = compose(v1113_10,v1115_11);
        }
        const Space v1113_13 = unite(v1113_8,v1113_12);
        v1112_7_result = unite(v1112_7_result,v1113_13);
      }
      const Space v1112_7 = std::move(v1112_7_result);
      v1111_8 = compose(v1111_5,v1112_7);
    }
    const Space v1111_9 = intersect(constant_3,v1111_2);
    const Space v1111_10 = (has_head(v1111_9) ? constant_4 : Space{});
    const Space v1111_11 = compose(v1111_10,v1110_9_tail);
    const Path v1116_6 = concat_path(p0,v1110_9_head);
    const Space v1111_12 = wrap(v1111_11,v1116_6);
    const Space v1111_13 = wrap(v1111_12,p1);
    const Space v1111_14 = unite(v1111_8,v1111_13);
    v1110_9_result = unite(v1110_9_result,v1111_14);
  }
  const Space v1110_9 = std::move(v1110_9_result);
  return v1110_9;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1117_13_result;
  for (int v1117_13_label = 1; v1117_13_label <= 2; ++v1117_13_label) {
    const Space v1117_13_tail = child(s0,v1117_13_label);
    if (v1117_13_tail.empty()) continue;
    const Path v1117_13_head{v1117_13_label};
    const Space v1118_2 = singleton(v1117_13_head);
    const Space v1118_3 = intersect(constant_3,v1118_2);
    const Space v1118_4 = (has_head(v1118_3) ? constant_4 : Space{});
    const Space v1118_5 = subtract(constant_2,v1118_4);
    Space v1118_8;
    if (!v1118_5.empty()) {
      const Path v1119_6 = concat_path(p0,v1117_13_head);
      Space v1119_7_result;
      for (int v1119_7_label = 1; v1119_7_label <= 2; ++v1119_7_label) {
        const Space v1119_7_tail = child(v1117_13_tail,v1119_7_label);
        if (v1119_7_tail.empty()) continue;
        const Path v1119_7_head{v1119_7_label};
        const Space v1120_2 = singleton(v1119_7_head);
        const Space v1120_3 = intersect(constant_3,v1120_2);
        const Space v1120_4 = (has_head(v1120_3) ? constant_4 : Space{});
        const Space v1120_5 = subtract(constant_2,v1120_4);
        Space v1120_8;
        if (!v1120_5.empty()) {
          const Path v1121_6 = concat_path(v1119_6,v1119_7_head);
          const Space v1121_7 = routine_158(c, v1121_6, p1, v1119_7_tail, s1);
          v1120_8 = compose(v1120_5,v1121_7);
        }
        const Space v1120_9 = intersect(constant_3,v1120_2);
        const Space v1120_10 = (has_head(v1120_9) ? constant_4 : Space{});
        Space v1120_12;
        if (!v1120_10.empty()) {
          const Path v1122_6 = concat_path(v1119_6,v1119_7_head);
          const Space v1122_11 = routine_159(c, v1122_6, p1, v1119_7_tail, s1);
          v1120_12 = compose(v1120_10,v1122_11);
        }
        const Space v1120_13 = unite(v1120_8,v1120_12);
        v1119_7_result = unite(v1119_7_result,v1120_13);
      }
      const Space v1119_7 = std::move(v1119_7_result);
      v1118_8 = compose(v1118_5,v1119_7);
    }
    const Space v1118_9 = intersect(constant_3,v1118_2);
    const Space v1118_10 = (has_head(v1118_9) ? constant_4 : Space{});
    Space v1118_12;
    if (!v1118_10.empty()) {
      const Path v1123_6 = concat_path(p0,v1117_13_head);
      Space v1123_11_result;
      for (int v1123_11_label = 1; v1123_11_label <= 2; ++v1123_11_label) {
        const Space v1123_11_tail = child(v1117_13_tail,v1123_11_label);
        if (v1123_11_tail.empty()) continue;
        const Path v1123_11_head{v1123_11_label};
        const Space v1124_2 = singleton(v1123_11_head);
        const Space v1124_3 = intersect(constant_3,v1124_2);
        const Space v1124_4 = (has_head(v1124_3) ? constant_4 : Space{});
        const Space v1124_5 = subtract(constant_2,v1124_4);
        Space v1124_8;
        if (!v1124_5.empty()) {
          const Path v1125_6 = concat_path(v1123_6,v1123_11_head);
          const Space v1125_7 = routine_158(c, v1125_6, p1, v1123_11_tail, s1);
          v1124_8 = compose(v1124_5,v1125_7);
        }
        const Space v1124_9 = intersect(constant_3,v1124_2);
        const Space v1124_10 = (has_head(v1124_9) ? constant_4 : Space{});
        Space v1124_12;
        if (!v1124_10.empty()) {
          const Path v1126_6 = concat_path(v1123_6,v1123_11_head);
          const Space v1126_11 = routine_43(c, v1126_6, p1, v1123_11_tail, s1);
          v1124_12 = compose(v1124_10,v1126_11);
        }
        const Space v1124_13 = unite(v1124_8,v1124_12);
        v1123_11_result = unite(v1123_11_result,v1124_13);
      }
      const Space v1123_11 = std::move(v1123_11_result);
      v1118_12 = compose(v1118_10,v1123_11);
    }
    const Space v1118_13 = unite(v1118_8,v1118_12);
    v1117_13_result = unite(v1117_13_result,v1118_13);
  }
  const Space v1117_13 = std::move(v1117_13_result);
  return v1117_13;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1127_8 = unwrap(s1,constant_0);
  const Space v1127_10 = unwrap(v1127_8,constant_6);
  const Space v1127_11 = unwrap(v1127_10,p0);
  Space v1127_18_result;
  for (int v1127_18_label = 1; v1127_18_label <= 2; ++v1127_18_label) {
    const Space v1127_18_tail = child(s0,v1127_18_label);
    if (v1127_18_tail.empty()) continue;
    const Path v1127_18_head{v1127_18_label};
    const Space v1128_2 = singleton(v1127_18_head);
    const Space v1128_3 = intersect(constant_3,v1128_2);
    const Space v1128_4 = (has_head(v1128_3) ? constant_4 : Space{});
    const Space v1128_5 = subtract(constant_2,v1128_4);
    Space v1128_8;
    if (!v1128_5.empty()) {
      const Path v1129_6 = concat_path(p0,v1127_18_head);
      Space v1129_7_result;
      for (int v1129_7_label = 1; v1129_7_label <= 2; ++v1129_7_label) {
        const Space v1129_7_tail = child(v1127_18_tail,v1129_7_label);
        if (v1129_7_tail.empty()) continue;
        const Path v1129_7_head{v1129_7_label};
        const Space v1130_2 = singleton(v1129_7_head);
        const Space v1130_3 = intersect(constant_3,v1130_2);
        const Space v1130_4 = (has_head(v1130_3) ? constant_4 : Space{});
        const Space v1130_5 = subtract(constant_2,v1130_4);
        Space v1130_8;
        if (!v1130_5.empty()) {
          const Path v1131_6 = concat_path(v1129_6,v1129_7_head);
          const Space v1131_7 = routine_158(c, v1131_6, p1, v1129_7_tail, s1);
          v1130_8 = compose(v1130_5,v1131_7);
        }
        const Space v1130_9 = intersect(constant_3,v1130_2);
        const Space v1130_10 = (has_head(v1130_9) ? constant_4 : Space{});
        Space v1130_12;
        if (!v1130_10.empty()) {
          const Path v1132_6 = concat_path(v1129_6,v1129_7_head);
          const Space v1132_11 = routine_159(c, v1132_6, p1, v1129_7_tail, s1);
          v1130_12 = compose(v1130_10,v1132_11);
        }
        const Space v1130_13 = unite(v1130_8,v1130_12);
        v1129_7_result = unite(v1129_7_result,v1130_13);
      }
      const Space v1129_7 = std::move(v1129_7_result);
      v1128_8 = compose(v1128_5,v1129_7);
    }
    const Space v1128_9 = intersect(constant_3,v1128_2);
    const Space v1128_10 = (has_head(v1128_9) ? constant_4 : Space{});
    Space v1128_13;
    if (!v1128_10.empty()) {
      const Space v1133_11 = unwrap(v1127_11,v1127_18_head);
      Space v1133_12_result;
      for (int v1133_12_label = 1; v1133_12_label <= 2; ++v1133_12_label) {
        const Space v1133_12_tail = child(v1133_11,v1133_12_label);
        if (v1133_12_tail.empty()) continue;
        const Path v1133_12_head{v1133_12_label};
        const Space v1134_2 = singleton(v1133_12_head);
        const Space v1134_3 = intersect(constant_3,v1134_2);
        const Space v1134_4 = (has_head(v1134_3) ? constant_4 : Space{});
        const Space v1134_5 = subtract(constant_2,v1134_4);
        Space v1134_7;
        if (!v1134_5.empty()) {
          const Space v1135_6 = routine_78(c, v1133_12_head, p1, v1133_12_tail);
          v1134_7 = compose(v1134_5,v1135_6);
        }
        const Space v1134_8 = intersect(constant_3,v1134_2);
        const Space v1134_9 = (has_head(v1134_8) ? constant_4 : Space{});
        Space v1134_11;
        if (!v1134_9.empty()) {
          const Space v1136_10 = routine_79(c, v1133_12_head, p1, v1133_12_tail);
          v1134_11 = compose(v1134_9,v1136_10);
        }
        const Space v1134_12 = unite(v1134_7,v1134_11);
        v1133_12_result = unite(v1133_12_result,v1134_12);
      }
      const Space v1133_12 = std::move(v1133_12_result);
      v1128_13 = compose(v1128_10,v1133_12);
    }
    const Space v1128_14 = unite(v1128_8,v1128_13);
    v1127_18_result = unite(v1127_18_result,v1128_14);
  }
  const Space v1127_18 = std::move(v1127_18_result);
  return v1127_18;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1137_12_result;
  for (int v1137_12_label = 1; v1137_12_label <= 2; ++v1137_12_label) {
    const Space v1137_12_tail = child(s0,v1137_12_label);
    if (v1137_12_tail.empty()) continue;
    const Path v1137_12_head{v1137_12_label};
    const Space v1138_2 = singleton(v1137_12_head);
    const Space v1138_3 = intersect(constant_3,v1138_2);
    const Space v1138_4 = (has_head(v1138_3) ? constant_4 : Space{});
    const Space v1138_5 = subtract(constant_2,v1138_4);
    Space v1138_8;
    if (!v1138_5.empty()) {
      const Path v1139_6 = concat_path(p0,v1137_12_head);
      Space v1139_7_result;
      for (int v1139_7_label = 1; v1139_7_label <= 2; ++v1139_7_label) {
        const Space v1139_7_tail = child(v1137_12_tail,v1139_7_label);
        if (v1139_7_tail.empty()) continue;
        const Path v1139_7_head{v1139_7_label};
        const Space v1140_2 = singleton(v1139_7_head);
        const Space v1140_3 = intersect(constant_3,v1140_2);
        const Space v1140_4 = (has_head(v1140_3) ? constant_4 : Space{});
        const Space v1140_5 = subtract(constant_2,v1140_4);
        Space v1140_8;
        if (!v1140_5.empty()) {
          const Path v1141_6 = concat_path(v1139_6,v1139_7_head);
          const Space v1141_7 = routine_160(c, v1141_6, p1, v1139_7_tail);
          v1140_8 = compose(v1140_5,v1141_7);
        }
        const Space v1140_9 = intersect(constant_3,v1140_2);
        const Space v1140_10 = (has_head(v1140_9) ? constant_4 : Space{});
        Space v1140_12;
        if (!v1140_10.empty()) {
          const Path v1142_6 = concat_path(v1139_6,v1139_7_head);
          const Space v1142_11 = routine_161(c, v1142_6, p1, v1139_7_tail);
          v1140_12 = compose(v1140_10,v1142_11);
        }
        const Space v1140_13 = unite(v1140_8,v1140_12);
        v1139_7_result = unite(v1139_7_result,v1140_13);
      }
      const Space v1139_7 = std::move(v1139_7_result);
      v1138_8 = compose(v1138_5,v1139_7);
    }
    const Space v1138_9 = intersect(constant_3,v1138_2);
    const Space v1138_10 = (has_head(v1138_9) ? constant_4 : Space{});
    Space v1138_12;
    if (!v1138_10.empty()) {
      const Path v1143_6 = concat_path(p0,v1137_12_head);
      Space v1143_11_result;
      for (int v1143_11_label = 1; v1143_11_label <= 2; ++v1143_11_label) {
        const Space v1143_11_tail = child(v1137_12_tail,v1143_11_label);
        if (v1143_11_tail.empty()) continue;
        const Path v1143_11_head{v1143_11_label};
        const Space v1144_2 = singleton(v1143_11_head);
        const Space v1144_3 = intersect(constant_3,v1144_2);
        const Space v1144_4 = (has_head(v1144_3) ? constant_4 : Space{});
        const Space v1144_5 = subtract(constant_2,v1144_4);
        Space v1144_8;
        if (!v1144_5.empty()) {
          const Path v1145_6 = concat_path(v1143_6,v1143_11_head);
          const Space v1145_7 = routine_160(c, v1145_6, p1, v1143_11_tail);
          v1144_8 = compose(v1144_5,v1145_7);
        }
        const Space v1144_9 = intersect(constant_3,v1144_2);
        const Space v1144_10 = (has_head(v1144_9) ? constant_4 : Space{});
        Space v1144_12;
        if (!v1144_10.empty()) {
          const Path v1146_6 = concat_path(v1143_6,v1143_11_head);
          const Space v1146_11 = routine_84(c, v1146_6, p1, v1143_11_tail);
          v1144_12 = compose(v1144_10,v1146_11);
        }
        const Space v1144_13 = unite(v1144_8,v1144_12);
        v1143_11_result = unite(v1143_11_result,v1144_13);
      }
      const Space v1143_11 = std::move(v1143_11_result);
      v1138_12 = compose(v1138_10,v1143_11);
    }
    const Space v1138_13 = unite(v1138_8,v1138_12);
    v1137_12_result = unite(v1137_12_result,v1138_13);
  }
  const Space v1137_12 = std::move(v1137_12_result);
  return v1137_12;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1147_9_result;
  for (int v1147_9_label = 1; v1147_9_label <= 2; ++v1147_9_label) {
    const Space v1147_9_tail = child(s0,v1147_9_label);
    if (v1147_9_tail.empty()) continue;
    const Path v1147_9_head{v1147_9_label};
    const Space v1148_2 = singleton(v1147_9_head);
    const Space v1148_3 = intersect(constant_3,v1148_2);
    const Space v1148_4 = (has_head(v1148_3) ? constant_4 : Space{});
    const Space v1148_5 = subtract(constant_2,v1148_4);
    Space v1148_8;
    if (!v1148_5.empty()) {
      const Path v1149_6 = concat_path(p0,v1147_9_head);
      Space v1149_7_result;
      for (int v1149_7_label = 1; v1149_7_label <= 2; ++v1149_7_label) {
        const Space v1149_7_tail = child(v1147_9_tail,v1149_7_label);
        if (v1149_7_tail.empty()) continue;
        const Path v1149_7_head{v1149_7_label};
        const Space v1150_2 = singleton(v1149_7_head);
        const Space v1150_3 = intersect(constant_3,v1150_2);
        const Space v1150_4 = (has_head(v1150_3) ? constant_4 : Space{});
        const Space v1150_5 = subtract(constant_2,v1150_4);
        Space v1150_8;
        if (!v1150_5.empty()) {
          const Path v1151_6 = concat_path(v1149_6,v1149_7_head);
          const Space v1151_7 = routine_160(c, v1151_6, p1, v1149_7_tail);
          v1150_8 = compose(v1150_5,v1151_7);
        }
        const Space v1150_9 = intersect(constant_3,v1150_2);
        const Space v1150_10 = (has_head(v1150_9) ? constant_4 : Space{});
        Space v1150_12;
        if (!v1150_10.empty()) {
          const Path v1152_6 = concat_path(v1149_6,v1149_7_head);
          const Space v1152_11 = routine_161(c, v1152_6, p1, v1149_7_tail);
          v1150_12 = compose(v1150_10,v1152_11);
        }
        const Space v1150_13 = unite(v1150_8,v1150_12);
        v1149_7_result = unite(v1149_7_result,v1150_13);
      }
      const Space v1149_7 = std::move(v1149_7_result);
      v1148_8 = compose(v1148_5,v1149_7);
    }
    const Space v1148_9 = intersect(constant_3,v1148_2);
    const Space v1148_10 = (has_head(v1148_9) ? constant_4 : Space{});
    const Space v1148_11 = compose(v1148_10,v1147_9_tail);
    const Path v1153_6 = concat_path(p0,v1147_9_head);
    const Space v1148_12 = wrap(v1148_11,v1153_6);
    const Space v1148_13 = wrap(v1148_12,p1);
    const Space v1148_14 = unite(v1148_8,v1148_13);
    v1147_9_result = unite(v1147_9_result,v1148_14);
  }
  const Space v1147_9 = std::move(v1147_9_result);
  return v1147_9;
}

static Space routine_128(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1154_3 = Space{};
  return v1154_3;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1155_7_result;
  for (int v1155_7_label = 1; v1155_7_label <= 2; ++v1155_7_label) {
    const Space v1155_7_tail = child(s0,v1155_7_label);
    if (v1155_7_tail.empty()) continue;
    const Path v1155_7_head{v1155_7_label};
    const Space v1156_2 = singleton(v1155_7_head);
    const Space v1156_3 = intersect(constant_3,v1156_2);
    const Space v1156_4 = (has_head(v1156_3) ? constant_4 : Space{});
    Space v1156_7;
    if (!v1156_4.empty()) {
      const Path v1157_5 = concat_path(p0,v1155_7_head);
      Space v1157_6_result;
      for (int v1157_6_label = 1; v1157_6_label <= 2; ++v1157_6_label) {
        const Space v1157_6_tail = child(v1155_7_tail,v1157_6_label);
        if (v1157_6_tail.empty()) continue;
        const Path v1157_6_head{v1157_6_label};
        const Space v1158_2 = singleton(v1157_6_head);
        const Space v1158_3 = intersect(constant_3,v1158_2);
        const Space v1158_4 = (has_head(v1158_3) ? constant_4 : Space{});
        const Space v1158_5 = subtract(constant_2,v1158_4);
        Space v1158_7;
        if (!v1158_5.empty()) {
          const Space v1159_6 = routine_46(c, v1157_6_head, v1157_5, v1157_6_tail, s1);
          v1158_7 = compose(v1158_5,v1159_6);
        }
        const Space v1158_8 = intersect(constant_3,v1158_2);
        const Space v1158_9 = (has_head(v1158_8) ? constant_4 : Space{});
        Space v1158_11;
        if (!v1158_9.empty()) {
          const Space v1160_10 = routine_47(c, v1157_6_head, v1157_5, v1157_6_tail, s1);
          v1158_11 = compose(v1158_9,v1160_10);
        }
        const Space v1158_12 = unite(v1158_7,v1158_11);
        v1157_6_result = unite(v1157_6_result,v1158_12);
      }
      const Space v1157_6 = std::move(v1157_6_result);
      v1156_7 = compose(v1156_4,v1157_6);
    }
    v1155_7_result = unite(v1155_7_result,v1156_7);
  }
  const Space v1155_7 = std::move(v1155_7_result);
  return v1155_7;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1161_13_result;
  for (int v1161_13_label = 1; v1161_13_label <= 2; ++v1161_13_label) {
    const Space v1161_13_tail = child(s0,v1161_13_label);
    if (v1161_13_tail.empty()) continue;
    const Path v1161_13_head{v1161_13_label};
    const Space v1162_2 = singleton(v1161_13_head);
    const Space v1162_3 = intersect(constant_3,v1162_2);
    const Space v1162_4 = (has_head(v1162_3) ? constant_4 : Space{});
    const Space v1162_5 = subtract(constant_2,v1162_4);
    Space v1162_8;
    if (!v1162_5.empty()) {
      const Path v1163_6 = concat_path(p0,v1161_13_head);
      Space v1163_7_result;
      for (int v1163_7_label = 1; v1163_7_label <= 2; ++v1163_7_label) {
        const Space v1163_7_tail = child(v1161_13_tail,v1163_7_label);
        if (v1163_7_tail.empty()) continue;
        const Path v1163_7_head{v1163_7_label};
        const Space v1164_2 = singleton(v1163_7_head);
        const Space v1164_3 = intersect(constant_3,v1164_2);
        const Space v1164_4 = (has_head(v1164_3) ? constant_4 : Space{});
        const Space v1164_5 = subtract(constant_2,v1164_4);
        Space v1164_8;
        if (!v1164_5.empty()) {
          const Path v1165_6 = concat_path(v1163_6,v1163_7_head);
          const Space v1165_7 = routine_162(c, v1165_6, p1, v1163_7_tail, s1);
          v1164_8 = compose(v1164_5,v1165_7);
        }
        const Space v1164_9 = intersect(constant_3,v1164_2);
        const Space v1164_10 = (has_head(v1164_9) ? constant_4 : Space{});
        Space v1164_12;
        if (!v1164_10.empty()) {
          const Path v1166_6 = concat_path(v1163_6,v1163_7_head);
          const Space v1166_11 = routine_163(c, v1166_6, p1, v1163_7_tail, s1);
          v1164_12 = compose(v1164_10,v1166_11);
        }
        const Space v1164_13 = unite(v1164_8,v1164_12);
        v1163_7_result = unite(v1163_7_result,v1164_13);
      }
      const Space v1163_7 = std::move(v1163_7_result);
      v1162_8 = compose(v1162_5,v1163_7);
    }
    const Space v1162_9 = intersect(constant_3,v1162_2);
    const Space v1162_10 = (has_head(v1162_9) ? constant_4 : Space{});
    Space v1162_12;
    if (!v1162_10.empty()) {
      const Path v1167_6 = concat_path(p0,v1161_13_head);
      Space v1167_11_result;
      for (int v1167_11_label = 1; v1167_11_label <= 2; ++v1167_11_label) {
        const Space v1167_11_tail = child(v1161_13_tail,v1167_11_label);
        if (v1167_11_tail.empty()) continue;
        const Path v1167_11_head{v1167_11_label};
        const Space v1168_2 = singleton(v1167_11_head);
        const Space v1168_3 = intersect(constant_3,v1168_2);
        const Space v1168_4 = (has_head(v1168_3) ? constant_4 : Space{});
        const Space v1168_5 = subtract(constant_2,v1168_4);
        Space v1168_8;
        if (!v1168_5.empty()) {
          const Path v1169_6 = concat_path(v1167_6,v1167_11_head);
          const Space v1169_7 = routine_162(c, v1169_6, p1, v1167_11_tail, s1);
          v1168_8 = compose(v1168_5,v1169_7);
        }
        const Space v1168_9 = intersect(constant_3,v1168_2);
        const Space v1168_10 = (has_head(v1168_9) ? constant_4 : Space{});
        Space v1168_12;
        if (!v1168_10.empty()) {
          const Path v1170_6 = concat_path(v1167_6,v1167_11_head);
          const Space v1170_11 = routine_50(c, v1170_6, p1, v1167_11_tail, s1);
          v1168_12 = compose(v1168_10,v1170_11);
        }
        const Space v1168_13 = unite(v1168_8,v1168_12);
        v1167_11_result = unite(v1167_11_result,v1168_13);
      }
      const Space v1167_11 = std::move(v1167_11_result);
      v1162_12 = compose(v1162_10,v1167_11);
    }
    const Space v1162_13 = unite(v1162_8,v1162_12);
    v1161_13_result = unite(v1161_13_result,v1162_13);
  }
  const Space v1161_13 = std::move(v1161_13_result);
  return v1161_13;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1171_8 = unwrap(s1,constant_5);
  const Space v1171_10 = unwrap(v1171_8,constant_6);
  const Space v1171_11 = unwrap(v1171_10,p0);
  Space v1171_18_result;
  for (int v1171_18_label = 1; v1171_18_label <= 2; ++v1171_18_label) {
    const Space v1171_18_tail = child(s0,v1171_18_label);
    if (v1171_18_tail.empty()) continue;
    const Path v1171_18_head{v1171_18_label};
    const Space v1172_2 = singleton(v1171_18_head);
    const Space v1172_3 = intersect(constant_3,v1172_2);
    const Space v1172_4 = (has_head(v1172_3) ? constant_4 : Space{});
    const Space v1172_5 = subtract(constant_2,v1172_4);
    Space v1172_8;
    if (!v1172_5.empty()) {
      const Path v1173_6 = concat_path(p0,v1171_18_head);
      Space v1173_7_result;
      for (int v1173_7_label = 1; v1173_7_label <= 2; ++v1173_7_label) {
        const Space v1173_7_tail = child(v1171_18_tail,v1173_7_label);
        if (v1173_7_tail.empty()) continue;
        const Path v1173_7_head{v1173_7_label};
        const Space v1174_2 = singleton(v1173_7_head);
        const Space v1174_3 = intersect(constant_3,v1174_2);
        const Space v1174_4 = (has_head(v1174_3) ? constant_4 : Space{});
        const Space v1174_5 = subtract(constant_2,v1174_4);
        Space v1174_8;
        if (!v1174_5.empty()) {
          const Path v1175_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1175_7 = routine_162(c, v1175_6, p1, v1173_7_tail, s1);
          v1174_8 = compose(v1174_5,v1175_7);
        }
        const Space v1174_9 = intersect(constant_3,v1174_2);
        const Space v1174_10 = (has_head(v1174_9) ? constant_4 : Space{});
        Space v1174_12;
        if (!v1174_10.empty()) {
          const Path v1176_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1176_11 = routine_163(c, v1176_6, p1, v1173_7_tail, s1);
          v1174_12 = compose(v1174_10,v1176_11);
        }
        const Space v1174_13 = unite(v1174_8,v1174_12);
        v1173_7_result = unite(v1173_7_result,v1174_13);
      }
      const Space v1173_7 = std::move(v1173_7_result);
      v1172_8 = compose(v1172_5,v1173_7);
    }
    const Space v1172_9 = intersect(constant_3,v1172_2);
    const Space v1172_10 = (has_head(v1172_9) ? constant_4 : Space{});
    Space v1172_13;
    if (!v1172_10.empty()) {
      const Space v1177_11 = unwrap(v1171_11,v1171_18_head);
      Space v1177_12_result;
      for (int v1177_12_label = 1; v1177_12_label <= 2; ++v1177_12_label) {
        const Space v1177_12_tail = child(v1177_11,v1177_12_label);
        if (v1177_12_tail.empty()) continue;
        const Path v1177_12_head{v1177_12_label};
        const Space v1178_2 = singleton(v1177_12_head);
        const Space v1178_3 = intersect(constant_3,v1178_2);
        const Space v1178_4 = (has_head(v1178_3) ? constant_4 : Space{});
        const Space v1178_5 = subtract(constant_2,v1178_4);
        Space v1178_7;
        if (!v1178_5.empty()) {
          const Space v1179_6 = routine_89(c, v1177_12_head, p1, v1177_12_tail);
          v1178_7 = compose(v1178_5,v1179_6);
        }
        const Space v1178_8 = intersect(constant_3,v1178_2);
        const Space v1178_9 = (has_head(v1178_8) ? constant_4 : Space{});
        Space v1178_11;
        if (!v1178_9.empty()) {
          const Space v1180_10 = routine_90(c, v1177_12_head, p1, v1177_12_tail);
          v1178_11 = compose(v1178_9,v1180_10);
        }
        const Space v1178_12 = unite(v1178_7,v1178_11);
        v1177_12_result = unite(v1177_12_result,v1178_12);
      }
      const Space v1177_12 = std::move(v1177_12_result);
      v1172_13 = compose(v1172_10,v1177_12);
    }
    const Space v1172_14 = unite(v1172_8,v1172_13);
    v1171_18_result = unite(v1171_18_result,v1172_14);
  }
  const Space v1171_18 = std::move(v1171_18_result);
  return v1171_18;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1181_12_result;
  for (int v1181_12_label = 1; v1181_12_label <= 2; ++v1181_12_label) {
    const Space v1181_12_tail = child(s0,v1181_12_label);
    if (v1181_12_tail.empty()) continue;
    const Path v1181_12_head{v1181_12_label};
    const Space v1182_2 = singleton(v1181_12_head);
    const Space v1182_3 = intersect(constant_3,v1182_2);
    const Space v1182_4 = (has_head(v1182_3) ? constant_4 : Space{});
    const Space v1182_5 = subtract(constant_2,v1182_4);
    Space v1182_8;
    if (!v1182_5.empty()) {
      const Path v1183_6 = concat_path(p0,v1181_12_head);
      Space v1183_7_result;
      for (int v1183_7_label = 1; v1183_7_label <= 2; ++v1183_7_label) {
        const Space v1183_7_tail = child(v1181_12_tail,v1183_7_label);
        if (v1183_7_tail.empty()) continue;
        const Path v1183_7_head{v1183_7_label};
        const Space v1184_2 = singleton(v1183_7_head);
        const Space v1184_3 = intersect(constant_3,v1184_2);
        const Space v1184_4 = (has_head(v1184_3) ? constant_4 : Space{});
        const Space v1184_5 = subtract(constant_2,v1184_4);
        Space v1184_8;
        if (!v1184_5.empty()) {
          const Path v1185_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1185_7 = routine_164(c, v1185_6, p1, v1183_7_tail);
          v1184_8 = compose(v1184_5,v1185_7);
        }
        const Space v1184_9 = intersect(constant_3,v1184_2);
        const Space v1184_10 = (has_head(v1184_9) ? constant_4 : Space{});
        Space v1184_12;
        if (!v1184_10.empty()) {
          const Path v1186_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1186_11 = routine_165(c, v1186_6, p1, v1183_7_tail);
          v1184_12 = compose(v1184_10,v1186_11);
        }
        const Space v1184_13 = unite(v1184_8,v1184_12);
        v1183_7_result = unite(v1183_7_result,v1184_13);
      }
      const Space v1183_7 = std::move(v1183_7_result);
      v1182_8 = compose(v1182_5,v1183_7);
    }
    const Space v1182_9 = intersect(constant_3,v1182_2);
    const Space v1182_10 = (has_head(v1182_9) ? constant_4 : Space{});
    Space v1182_12;
    if (!v1182_10.empty()) {
      const Path v1187_6 = concat_path(p0,v1181_12_head);
      Space v1187_11_result;
      for (int v1187_11_label = 1; v1187_11_label <= 2; ++v1187_11_label) {
        const Space v1187_11_tail = child(v1181_12_tail,v1187_11_label);
        if (v1187_11_tail.empty()) continue;
        const Path v1187_11_head{v1187_11_label};
        const Space v1188_2 = singleton(v1187_11_head);
        const Space v1188_3 = intersect(constant_3,v1188_2);
        const Space v1188_4 = (has_head(v1188_3) ? constant_4 : Space{});
        const Space v1188_5 = subtract(constant_2,v1188_4);
        Space v1188_8;
        if (!v1188_5.empty()) {
          const Path v1189_6 = concat_path(v1187_6,v1187_11_head);
          const Space v1189_7 = routine_164(c, v1189_6, p1, v1187_11_tail);
          v1188_8 = compose(v1188_5,v1189_7);
        }
        const Space v1188_9 = intersect(constant_3,v1188_2);
        const Space v1188_10 = (has_head(v1188_9) ? constant_4 : Space{});
        Space v1188_12;
        if (!v1188_10.empty()) {
          const Path v1190_6 = concat_path(v1187_6,v1187_11_head);
          const Space v1190_11 = routine_95(c, v1190_6, p1, v1187_11_tail);
          v1188_12 = compose(v1188_10,v1190_11);
        }
        const Space v1188_13 = unite(v1188_8,v1188_12);
        v1187_11_result = unite(v1187_11_result,v1188_13);
      }
      const Space v1187_11 = std::move(v1187_11_result);
      v1182_12 = compose(v1182_10,v1187_11);
    }
    const Space v1182_13 = unite(v1182_8,v1182_12);
    v1181_12_result = unite(v1181_12_result,v1182_13);
  }
  const Space v1181_12 = std::move(v1181_12_result);
  return v1181_12;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1191_9_result;
  for (int v1191_9_label = 1; v1191_9_label <= 2; ++v1191_9_label) {
    const Space v1191_9_tail = child(s0,v1191_9_label);
    if (v1191_9_tail.empty()) continue;
    const Path v1191_9_head{v1191_9_label};
    const Space v1192_2 = singleton(v1191_9_head);
    const Space v1192_3 = intersect(constant_3,v1192_2);
    const Space v1192_4 = (has_head(v1192_3) ? constant_4 : Space{});
    const Space v1192_5 = subtract(constant_2,v1192_4);
    Space v1192_8;
    if (!v1192_5.empty()) {
      const Path v1193_6 = concat_path(p0,v1191_9_head);
      Space v1193_7_result;
      for (int v1193_7_label = 1; v1193_7_label <= 2; ++v1193_7_label) {
        const Space v1193_7_tail = child(v1191_9_tail,v1193_7_label);
        if (v1193_7_tail.empty()) continue;
        const Path v1193_7_head{v1193_7_label};
        const Space v1194_2 = singleton(v1193_7_head);
        const Space v1194_3 = intersect(constant_3,v1194_2);
        const Space v1194_4 = (has_head(v1194_3) ? constant_4 : Space{});
        const Space v1194_5 = subtract(constant_2,v1194_4);
        Space v1194_8;
        if (!v1194_5.empty()) {
          const Path v1195_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1195_7 = routine_164(c, v1195_6, p1, v1193_7_tail);
          v1194_8 = compose(v1194_5,v1195_7);
        }
        const Space v1194_9 = intersect(constant_3,v1194_2);
        const Space v1194_10 = (has_head(v1194_9) ? constant_4 : Space{});
        Space v1194_12;
        if (!v1194_10.empty()) {
          const Path v1196_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1196_11 = routine_165(c, v1196_6, p1, v1193_7_tail);
          v1194_12 = compose(v1194_10,v1196_11);
        }
        const Space v1194_13 = unite(v1194_8,v1194_12);
        v1193_7_result = unite(v1193_7_result,v1194_13);
      }
      const Space v1193_7 = std::move(v1193_7_result);
      v1192_8 = compose(v1192_5,v1193_7);
    }
    const Space v1192_9 = intersect(constant_3,v1192_2);
    const Space v1192_10 = (has_head(v1192_9) ? constant_4 : Space{});
    const Space v1192_11 = compose(v1192_10,v1191_9_tail);
    const Path v1197_6 = concat_path(p0,v1191_9_head);
    const Space v1192_12 = wrap(v1192_11,v1197_6);
    const Space v1192_13 = wrap(v1192_12,p1);
    const Space v1192_14 = unite(v1192_8,v1192_13);
    v1191_9_result = unite(v1191_9_result,v1192_14);
  }
  const Space v1191_9 = std::move(v1191_9_result);
  return v1191_9;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1198_13_result;
  for (int v1198_13_label = 1; v1198_13_label <= 2; ++v1198_13_label) {
    const Space v1198_13_tail = child(s0,v1198_13_label);
    if (v1198_13_tail.empty()) continue;
    const Path v1198_13_head{v1198_13_label};
    const Space v1199_2 = singleton(v1198_13_head);
    const Space v1199_3 = intersect(constant_3,v1199_2);
    const Space v1199_4 = (has_head(v1199_3) ? constant_4 : Space{});
    const Space v1199_5 = subtract(constant_2,v1199_4);
    Space v1199_8;
    if (!v1199_5.empty()) {
      const Path v1200_6 = concat_path(p0,v1198_13_head);
      Space v1200_7_result;
      for (int v1200_7_label = 1; v1200_7_label <= 2; ++v1200_7_label) {
        const Space v1200_7_tail = child(v1198_13_tail,v1200_7_label);
        if (v1200_7_tail.empty()) continue;
        const Path v1200_7_head{v1200_7_label};
        const Space v1201_2 = singleton(v1200_7_head);
        const Space v1201_3 = intersect(constant_3,v1201_2);
        const Space v1201_4 = (has_head(v1201_3) ? constant_4 : Space{});
        const Space v1201_5 = subtract(constant_2,v1201_4);
        Space v1201_8;
        if (!v1201_5.empty()) {
          const Path v1202_6 = concat_path(v1200_6,v1200_7_head);
          const Space v1202_7 = routine_166(c, v1202_6, p1, v1200_7_tail, s1);
          v1201_8 = compose(v1201_5,v1202_7);
        }
        const Space v1201_9 = intersect(constant_3,v1201_2);
        const Space v1201_10 = (has_head(v1201_9) ? constant_4 : Space{});
        Space v1201_12;
        if (!v1201_10.empty()) {
          const Path v1203_6 = concat_path(v1200_6,v1200_7_head);
          const Space v1203_11 = routine_167(c, v1203_6, p1, v1200_7_tail, s1);
          v1201_12 = compose(v1201_10,v1203_11);
        }
        const Space v1201_13 = unite(v1201_8,v1201_12);
        v1200_7_result = unite(v1200_7_result,v1201_13);
      }
      const Space v1200_7 = std::move(v1200_7_result);
      v1199_8 = compose(v1199_5,v1200_7);
    }
    const Space v1199_9 = intersect(constant_3,v1199_2);
    const Space v1199_10 = (has_head(v1199_9) ? constant_4 : Space{});
    Space v1199_12;
    if (!v1199_10.empty()) {
      const Path v1204_6 = concat_path(p0,v1198_13_head);
      Space v1204_11_result;
      for (int v1204_11_label = 1; v1204_11_label <= 2; ++v1204_11_label) {
        const Space v1204_11_tail = child(v1198_13_tail,v1204_11_label);
        if (v1204_11_tail.empty()) continue;
        const Path v1204_11_head{v1204_11_label};
        const Space v1205_2 = singleton(v1204_11_head);
        const Space v1205_3 = intersect(constant_3,v1205_2);
        const Space v1205_4 = (has_head(v1205_3) ? constant_4 : Space{});
        const Space v1205_5 = subtract(constant_2,v1205_4);
        Space v1205_8;
        if (!v1205_5.empty()) {
          const Path v1206_6 = concat_path(v1204_6,v1204_11_head);
          const Space v1206_7 = routine_166(c, v1206_6, p1, v1204_11_tail, s1);
          v1205_8 = compose(v1205_5,v1206_7);
        }
        const Space v1205_9 = intersect(constant_3,v1205_2);
        const Space v1205_10 = (has_head(v1205_9) ? constant_4 : Space{});
        Space v1205_12;
        if (!v1205_10.empty()) {
          const Path v1207_6 = concat_path(v1204_6,v1204_11_head);
          const Space v1207_11 = routine_50(c, v1207_6, p1, v1204_11_tail, s1);
          v1205_12 = compose(v1205_10,v1207_11);
        }
        const Space v1205_13 = unite(v1205_8,v1205_12);
        v1204_11_result = unite(v1204_11_result,v1205_13);
      }
      const Space v1204_11 = std::move(v1204_11_result);
      v1199_12 = compose(v1199_10,v1204_11);
    }
    const Space v1199_13 = unite(v1199_8,v1199_12);
    v1198_13_result = unite(v1198_13_result,v1199_13);
  }
  const Space v1198_13 = std::move(v1198_13_result);
  return v1198_13;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1208_8 = unwrap(s1,constant_5);
  const Space v1208_10 = unwrap(v1208_8,constant_6);
  const Space v1208_11 = unwrap(v1208_10,p0);
  Space v1208_18_result;
  for (int v1208_18_label = 1; v1208_18_label <= 2; ++v1208_18_label) {
    const Space v1208_18_tail = child(s0,v1208_18_label);
    if (v1208_18_tail.empty()) continue;
    const Path v1208_18_head{v1208_18_label};
    const Space v1209_2 = singleton(v1208_18_head);
    const Space v1209_3 = intersect(constant_3,v1209_2);
    const Space v1209_4 = (has_head(v1209_3) ? constant_4 : Space{});
    const Space v1209_5 = subtract(constant_2,v1209_4);
    Space v1209_8;
    if (!v1209_5.empty()) {
      const Path v1210_6 = concat_path(p0,v1208_18_head);
      Space v1210_7_result;
      for (int v1210_7_label = 1; v1210_7_label <= 2; ++v1210_7_label) {
        const Space v1210_7_tail = child(v1208_18_tail,v1210_7_label);
        if (v1210_7_tail.empty()) continue;
        const Path v1210_7_head{v1210_7_label};
        const Space v1211_2 = singleton(v1210_7_head);
        const Space v1211_3 = intersect(constant_3,v1211_2);
        const Space v1211_4 = (has_head(v1211_3) ? constant_4 : Space{});
        const Space v1211_5 = subtract(constant_2,v1211_4);
        Space v1211_8;
        if (!v1211_5.empty()) {
          const Path v1212_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1212_7 = routine_166(c, v1212_6, p1, v1210_7_tail, s1);
          v1211_8 = compose(v1211_5,v1212_7);
        }
        const Space v1211_9 = intersect(constant_3,v1211_2);
        const Space v1211_10 = (has_head(v1211_9) ? constant_4 : Space{});
        Space v1211_12;
        if (!v1211_10.empty()) {
          const Path v1213_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1213_11 = routine_167(c, v1213_6, p1, v1210_7_tail, s1);
          v1211_12 = compose(v1211_10,v1213_11);
        }
        const Space v1211_13 = unite(v1211_8,v1211_12);
        v1210_7_result = unite(v1210_7_result,v1211_13);
      }
      const Space v1210_7 = std::move(v1210_7_result);
      v1209_8 = compose(v1209_5,v1210_7);
    }
    const Space v1209_9 = intersect(constant_3,v1209_2);
    const Space v1209_10 = (has_head(v1209_9) ? constant_4 : Space{});
    Space v1209_13;
    if (!v1209_10.empty()) {
      const Space v1214_11 = unwrap(v1208_11,v1208_18_head);
      Space v1214_12_result;
      for (int v1214_12_label = 1; v1214_12_label <= 2; ++v1214_12_label) {
        const Space v1214_12_tail = child(v1214_11,v1214_12_label);
        if (v1214_12_tail.empty()) continue;
        const Path v1214_12_head{v1214_12_label};
        const Space v1215_2 = singleton(v1214_12_head);
        const Space v1215_3 = intersect(constant_3,v1215_2);
        const Space v1215_4 = (has_head(v1215_3) ? constant_4 : Space{});
        const Space v1215_5 = subtract(constant_2,v1215_4);
        Space v1215_7;
        if (!v1215_5.empty()) {
          const Space v1216_6 = routine_89(c, v1214_12_head, p1, v1214_12_tail);
          v1215_7 = compose(v1215_5,v1216_6);
        }
        const Space v1215_8 = intersect(constant_3,v1215_2);
        const Space v1215_9 = (has_head(v1215_8) ? constant_4 : Space{});
        Space v1215_11;
        if (!v1215_9.empty()) {
          const Space v1217_10 = routine_90(c, v1214_12_head, p1, v1214_12_tail);
          v1215_11 = compose(v1215_9,v1217_10);
        }
        const Space v1215_12 = unite(v1215_7,v1215_11);
        v1214_12_result = unite(v1214_12_result,v1215_12);
      }
      const Space v1214_12 = std::move(v1214_12_result);
      v1209_13 = compose(v1209_10,v1214_12);
    }
    const Space v1209_14 = unite(v1209_8,v1209_13);
    v1208_18_result = unite(v1208_18_result,v1209_14);
  }
  const Space v1208_18 = std::move(v1208_18_result);
  return v1208_18;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1218_12_result;
  for (int v1218_12_label = 1; v1218_12_label <= 2; ++v1218_12_label) {
    const Space v1218_12_tail = child(s0,v1218_12_label);
    if (v1218_12_tail.empty()) continue;
    const Path v1218_12_head{v1218_12_label};
    const Space v1219_2 = singleton(v1218_12_head);
    const Space v1219_3 = intersect(constant_3,v1219_2);
    const Space v1219_4 = (has_head(v1219_3) ? constant_4 : Space{});
    const Space v1219_5 = subtract(constant_2,v1219_4);
    Space v1219_8;
    if (!v1219_5.empty()) {
      const Path v1220_6 = concat_path(p0,v1218_12_head);
      Space v1220_7_result;
      for (int v1220_7_label = 1; v1220_7_label <= 2; ++v1220_7_label) {
        const Space v1220_7_tail = child(v1218_12_tail,v1220_7_label);
        if (v1220_7_tail.empty()) continue;
        const Path v1220_7_head{v1220_7_label};
        const Space v1221_2 = singleton(v1220_7_head);
        const Space v1221_3 = intersect(constant_3,v1221_2);
        const Space v1221_4 = (has_head(v1221_3) ? constant_4 : Space{});
        const Space v1221_5 = subtract(constant_2,v1221_4);
        Space v1221_8;
        if (!v1221_5.empty()) {
          const Path v1222_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1222_7 = routine_168(c, v1222_6, p1, v1220_7_tail);
          v1221_8 = compose(v1221_5,v1222_7);
        }
        const Space v1221_9 = intersect(constant_3,v1221_2);
        const Space v1221_10 = (has_head(v1221_9) ? constant_4 : Space{});
        Space v1221_12;
        if (!v1221_10.empty()) {
          const Path v1223_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1223_11 = routine_169(c, v1223_6, p1, v1220_7_tail);
          v1221_12 = compose(v1221_10,v1223_11);
        }
        const Space v1221_13 = unite(v1221_8,v1221_12);
        v1220_7_result = unite(v1220_7_result,v1221_13);
      }
      const Space v1220_7 = std::move(v1220_7_result);
      v1219_8 = compose(v1219_5,v1220_7);
    }
    const Space v1219_9 = intersect(constant_3,v1219_2);
    const Space v1219_10 = (has_head(v1219_9) ? constant_4 : Space{});
    Space v1219_12;
    if (!v1219_10.empty()) {
      const Path v1224_6 = concat_path(p0,v1218_12_head);
      Space v1224_11_result;
      for (int v1224_11_label = 1; v1224_11_label <= 2; ++v1224_11_label) {
        const Space v1224_11_tail = child(v1218_12_tail,v1224_11_label);
        if (v1224_11_tail.empty()) continue;
        const Path v1224_11_head{v1224_11_label};
        const Space v1225_2 = singleton(v1224_11_head);
        const Space v1225_3 = intersect(constant_3,v1225_2);
        const Space v1225_4 = (has_head(v1225_3) ? constant_4 : Space{});
        const Space v1225_5 = subtract(constant_2,v1225_4);
        Space v1225_8;
        if (!v1225_5.empty()) {
          const Path v1226_6 = concat_path(v1224_6,v1224_11_head);
          const Space v1226_7 = routine_168(c, v1226_6, p1, v1224_11_tail);
          v1225_8 = compose(v1225_5,v1226_7);
        }
        const Space v1225_9 = intersect(constant_3,v1225_2);
        const Space v1225_10 = (has_head(v1225_9) ? constant_4 : Space{});
        Space v1225_12;
        if (!v1225_10.empty()) {
          const Path v1227_6 = concat_path(v1224_6,v1224_11_head);
          const Space v1227_11 = routine_95(c, v1227_6, p1, v1224_11_tail);
          v1225_12 = compose(v1225_10,v1227_11);
        }
        const Space v1225_13 = unite(v1225_8,v1225_12);
        v1224_11_result = unite(v1224_11_result,v1225_13);
      }
      const Space v1224_11 = std::move(v1224_11_result);
      v1219_12 = compose(v1219_10,v1224_11);
    }
    const Space v1219_13 = unite(v1219_8,v1219_12);
    v1218_12_result = unite(v1218_12_result,v1219_13);
  }
  const Space v1218_12 = std::move(v1218_12_result);
  return v1218_12;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1228_9_result;
  for (int v1228_9_label = 1; v1228_9_label <= 2; ++v1228_9_label) {
    const Space v1228_9_tail = child(s0,v1228_9_label);
    if (v1228_9_tail.empty()) continue;
    const Path v1228_9_head{v1228_9_label};
    const Space v1229_2 = singleton(v1228_9_head);
    const Space v1229_3 = intersect(constant_3,v1229_2);
    const Space v1229_4 = (has_head(v1229_3) ? constant_4 : Space{});
    const Space v1229_5 = subtract(constant_2,v1229_4);
    Space v1229_8;
    if (!v1229_5.empty()) {
      const Path v1230_6 = concat_path(p0,v1228_9_head);
      Space v1230_7_result;
      for (int v1230_7_label = 1; v1230_7_label <= 2; ++v1230_7_label) {
        const Space v1230_7_tail = child(v1228_9_tail,v1230_7_label);
        if (v1230_7_tail.empty()) continue;
        const Path v1230_7_head{v1230_7_label};
        const Space v1231_2 = singleton(v1230_7_head);
        const Space v1231_3 = intersect(constant_3,v1231_2);
        const Space v1231_4 = (has_head(v1231_3) ? constant_4 : Space{});
        const Space v1231_5 = subtract(constant_2,v1231_4);
        Space v1231_8;
        if (!v1231_5.empty()) {
          const Path v1232_6 = concat_path(v1230_6,v1230_7_head);
          const Space v1232_7 = routine_168(c, v1232_6, p1, v1230_7_tail);
          v1231_8 = compose(v1231_5,v1232_7);
        }
        const Space v1231_9 = intersect(constant_3,v1231_2);
        const Space v1231_10 = (has_head(v1231_9) ? constant_4 : Space{});
        Space v1231_12;
        if (!v1231_10.empty()) {
          const Path v1233_6 = concat_path(v1230_6,v1230_7_head);
          const Space v1233_11 = routine_169(c, v1233_6, p1, v1230_7_tail);
          v1231_12 = compose(v1231_10,v1233_11);
        }
        const Space v1231_13 = unite(v1231_8,v1231_12);
        v1230_7_result = unite(v1230_7_result,v1231_13);
      }
      const Space v1230_7 = std::move(v1230_7_result);
      v1229_8 = compose(v1229_5,v1230_7);
    }
    const Space v1229_9 = intersect(constant_3,v1229_2);
    const Space v1229_10 = (has_head(v1229_9) ? constant_4 : Space{});
    const Space v1229_11 = compose(v1229_10,v1228_9_tail);
    const Path v1234_6 = concat_path(p0,v1228_9_head);
    const Space v1229_12 = wrap(v1229_11,v1234_6);
    const Space v1229_13 = wrap(v1229_12,p1);
    const Space v1229_14 = unite(v1229_8,v1229_13);
    v1228_9_result = unite(v1228_9_result,v1229_14);
  }
  const Space v1228_9 = std::move(v1228_9_result);
  return v1228_9;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1235_5_result;
  for (int v1235_5_label = 1; v1235_5_label <= 2; ++v1235_5_label) {
    const Space v1235_5_tail = child(s0,v1235_5_label);
    if (v1235_5_tail.empty()) continue;
    const Path v1235_5_head{v1235_5_label};
    const Space v1236_2 = singleton(v1235_5_head);
    const Space v1236_3 = intersect(constant_3,v1236_2);
    const Space v1236_4 = (has_head(v1236_3) ? constant_4 : Space{});
    Space v1236_7;
    if (!v1236_4.empty()) {
      const Path v1237_5 = concat_path(p0,v1235_5_head);
      Space v1237_6_result;
      for (int v1237_6_label = 1; v1237_6_label <= 2; ++v1237_6_label) {
        const Space v1237_6_tail = child(v1235_5_tail,v1237_6_label);
        if (v1237_6_tail.empty()) continue;
        const Path v1237_6_head{v1237_6_label};
        const Space v1238_2 = singleton(v1237_6_head);
        const Space v1238_3 = intersect(constant_3,v1238_2);
        const Space v1238_4 = (has_head(v1238_3) ? constant_4 : Space{});
        Space v1238_7;
        if (!v1238_4.empty()) {
          const Path v1239_5 = concat_path(v1237_5,v1237_6_head);
          const Space v1239_6 = routine_22(c, v1239_5, p1, v1237_6_tail);
          v1238_7 = compose(v1238_4,v1239_6);
        }
        v1237_6_result = unite(v1237_6_result,v1238_7);
      }
      const Space v1237_6 = std::move(v1237_6_result);
      v1236_7 = compose(v1236_4,v1237_6);
    }
    v1235_5_result = unite(v1235_5_result,v1236_7);
  }
  const Space v1235_5 = std::move(v1235_5_result);
  return v1235_5;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1240_4_result;
  for (int v1240_4_label = 1; v1240_4_label <= 2; ++v1240_4_label) {
    const Space v1240_4_tail = child(s0,v1240_4_label);
    if (v1240_4_tail.empty()) continue;
    const Path v1240_4_head{v1240_4_label};
    const Space v1241_2 = singleton(v1240_4_head);
    const Space v1241_3 = intersect(constant_3,v1241_2);
    const Space v1241_4 = (has_head(v1241_3) ? constant_4 : Space{});
    const Space v1241_5 = compose(v1241_4,v1240_4_tail);
    const Path v1241_6 = concat_path(p0,v1240_4_head);
    const Space v1241_7 = wrap(v1241_5,v1241_6);
    v1240_4_result = unite(v1240_4_result,v1241_7);
  }
  const Space v1240_4 = std::move(v1240_4_result);
  const Space v1240_5 = wrap(v1240_4,p1);
  const Space v1240_7 = wrap(v1240_5,constant_6);
  return v1240_7;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1242_3 = Space{};
  return v1242_3;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1243_4_result;
  for (int v1243_4_label = 1; v1243_4_label <= 2; ++v1243_4_label) {
    const Space v1243_4_tail = child(s0,v1243_4_label);
    if (v1243_4_tail.empty()) continue;
    const Path v1243_4_head{v1243_4_label};
    const Space v1244_2 = singleton(v1243_4_head);
    const Space v1244_3 = intersect(constant_3,v1244_2);
    const Space v1244_4 = (has_head(v1244_3) ? constant_4 : Space{});
    const Space v1244_5 = compose(v1244_4,v1243_4_tail);
    const Path v1244_6 = concat_path(p0,v1243_4_head);
    const Space v1244_7 = wrap(v1244_5,v1244_6);
    v1243_4_result = unite(v1243_4_result,v1244_7);
  }
  const Space v1243_4 = std::move(v1243_4_result);
  const Space v1243_5 = wrap(v1243_4,p1);
  const Space v1243_7 = wrap(v1243_5,constant_6);
  return v1243_7;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1245_6_result;
  for (int v1245_6_label = 1; v1245_6_label <= 2; ++v1245_6_label) {
    const Space v1245_6_tail = child(s0,v1245_6_label);
    if (v1245_6_tail.empty()) continue;
    const Path v1245_6_head{v1245_6_label};
    const Space v1246_2 = singleton(v1245_6_head);
    const Space v1246_3 = intersect(constant_3,v1246_2);
    const Space v1246_4 = (has_head(v1246_3) ? constant_4 : Space{});
    Space v1246_7;
    if (!v1246_4.empty()) {
      const Path v1247_5 = concat_path(p0,v1245_6_head);
      Space v1247_6_result;
      for (int v1247_6_label = 1; v1247_6_label <= 2; ++v1247_6_label) {
        const Space v1247_6_tail = child(v1245_6_tail,v1247_6_label);
        if (v1247_6_tail.empty()) continue;
        const Path v1247_6_head{v1247_6_label};
        const Space v1248_2 = singleton(v1247_6_head);
        const Space v1248_3 = intersect(constant_3,v1248_2);
        const Space v1248_4 = (has_head(v1248_3) ? constant_4 : Space{});
        Space v1248_7;
        if (!v1248_4.empty()) {
          const Path v1249_5 = concat_path(v1247_5,v1247_6_head);
          const Space v1249_6 = routine_29(c, v1249_5, p1, v1247_6_tail, s1);
          v1248_7 = compose(v1248_4,v1249_6);
        }
        v1247_6_result = unite(v1247_6_result,v1248_7);
      }
      const Space v1247_6 = std::move(v1247_6_result);
      v1246_7 = compose(v1246_4,v1247_6);
    }
    v1245_6_result = unite(v1245_6_result,v1246_7);
  }
  const Space v1245_6 = std::move(v1245_6_result);
  return v1245_6;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1250_6 = unwrap(s1,constant_5);
  const Space v1250_8 = unwrap(v1250_6,constant_6);
  const Space v1250_9 = unwrap(v1250_8,p0);
  Space v1250_13_result;
  for (int v1250_13_label = 1; v1250_13_label <= 2; ++v1250_13_label) {
    const Space v1250_13_tail = child(s0,v1250_13_label);
    if (v1250_13_tail.empty()) continue;
    const Path v1250_13_head{v1250_13_label};
    const Space v1251_2 = singleton(v1250_13_head);
    const Space v1251_3 = intersect(constant_3,v1251_2);
    const Space v1251_4 = (has_head(v1251_3) ? constant_4 : Space{});
    Space v1251_7;
    if (!v1251_4.empty()) {
      const Space v1252_5 = unwrap(v1250_9,v1250_13_head);
      Space v1252_6_result;
      for (int v1252_6_label = 1; v1252_6_label <= 2; ++v1252_6_label) {
        const Space v1252_6_tail = child(v1252_5,v1252_6_label);
        if (v1252_6_tail.empty()) continue;
        const Path v1252_6_head{v1252_6_label};
        const Space v1253_2 = singleton(v1252_6_head);
        const Space v1253_3 = intersect(constant_3,v1253_2);
        const Space v1253_4 = (has_head(v1253_3) ? constant_4 : Space{});
        const Space v1253_5 = subtract(constant_2,v1253_4);
        Space v1253_7;
        if (!v1253_5.empty()) {
          const Space v1254_6 = routine_61(c, v1252_6_head, p1, v1252_6_tail);
          v1253_7 = compose(v1253_5,v1254_6);
        }
        const Space v1253_8 = intersect(constant_3,v1253_2);
        const Space v1253_9 = (has_head(v1253_8) ? constant_4 : Space{});
        Space v1253_11;
        if (!v1253_9.empty()) {
          const Space v1255_10 = routine_62(c, v1252_6_head, p1, v1252_6_tail);
          v1253_11 = compose(v1253_9,v1255_10);
        }
        const Space v1253_12 = unite(v1253_7,v1253_11);
        v1252_6_result = unite(v1252_6_result,v1253_12);
      }
      const Space v1252_6 = std::move(v1252_6_result);
      v1251_7 = compose(v1251_4,v1252_6);
    }
    v1250_13_result = unite(v1250_13_result,v1251_7);
  }
  const Space v1250_13 = std::move(v1250_13_result);
  return v1250_13;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1256_12_result;
  for (int v1256_12_label = 1; v1256_12_label <= 2; ++v1256_12_label) {
    const Space v1256_12_tail = child(s0,v1256_12_label);
    if (v1256_12_tail.empty()) continue;
    const Path v1256_12_head{v1256_12_label};
    const Space v1257_2 = singleton(v1256_12_head);
    const Space v1257_3 = intersect(constant_3,v1257_2);
    const Space v1257_4 = (has_head(v1257_3) ? constant_4 : Space{});
    const Space v1257_5 = subtract(constant_2,v1257_4);
    Space v1257_8;
    if (!v1257_5.empty()) {
      const Path v1258_6 = concat_path(p0,v1256_12_head);
      Space v1258_7_result;
      for (int v1258_7_label = 1; v1258_7_label <= 2; ++v1258_7_label) {
        const Space v1258_7_tail = child(v1256_12_tail,v1258_7_label);
        if (v1258_7_tail.empty()) continue;
        const Path v1258_7_head{v1258_7_label};
        const Space v1259_2 = singleton(v1258_7_head);
        const Space v1259_3 = intersect(constant_3,v1259_2);
        const Space v1259_4 = (has_head(v1259_3) ? constant_4 : Space{});
        const Space v1259_5 = subtract(constant_2,v1259_4);
        Space v1259_8;
        if (!v1259_5.empty()) {
          const Path v1260_6 = concat_path(v1258_6,v1258_7_head);
          const Space v1260_7 = routine_170(c, v1260_6, p1, v1258_7_tail);
          v1259_8 = compose(v1259_5,v1260_7);
        }
        const Space v1259_9 = intersect(constant_3,v1259_2);
        const Space v1259_10 = (has_head(v1259_9) ? constant_4 : Space{});
        Space v1259_12;
        if (!v1259_10.empty()) {
          const Path v1261_6 = concat_path(v1258_6,v1258_7_head);
          const Space v1261_11 = routine_171(c, v1261_6, p1, v1258_7_tail);
          v1259_12 = compose(v1259_10,v1261_11);
        }
        const Space v1259_13 = unite(v1259_8,v1259_12);
        v1258_7_result = unite(v1258_7_result,v1259_13);
      }
      const Space v1258_7 = std::move(v1258_7_result);
      v1257_8 = compose(v1257_5,v1258_7);
    }
    const Space v1257_9 = intersect(constant_3,v1257_2);
    const Space v1257_10 = (has_head(v1257_9) ? constant_4 : Space{});
    Space v1257_12;
    if (!v1257_10.empty()) {
      const Path v1262_6 = concat_path(p0,v1256_12_head);
      Space v1262_11_result;
      for (int v1262_11_label = 1; v1262_11_label <= 2; ++v1262_11_label) {
        const Space v1262_11_tail = child(v1256_12_tail,v1262_11_label);
        if (v1262_11_tail.empty()) continue;
        const Path v1262_11_head{v1262_11_label};
        const Space v1263_2 = singleton(v1262_11_head);
        const Space v1263_3 = intersect(constant_3,v1263_2);
        const Space v1263_4 = (has_head(v1263_3) ? constant_4 : Space{});
        const Space v1263_5 = subtract(constant_2,v1263_4);
        Space v1263_8;
        if (!v1263_5.empty()) {
          const Path v1264_6 = concat_path(v1262_6,v1262_11_head);
          const Space v1264_7 = routine_170(c, v1264_6, p1, v1262_11_tail);
          v1263_8 = compose(v1263_5,v1264_7);
        }
        const Space v1263_9 = intersect(constant_3,v1263_2);
        const Space v1263_10 = (has_head(v1263_9) ? constant_4 : Space{});
        Space v1263_12;
        if (!v1263_10.empty()) {
          const Path v1265_6 = concat_path(v1262_6,v1262_11_head);
          const Space v1265_11 = routine_67(c, v1265_6, p1, v1262_11_tail);
          v1263_12 = compose(v1263_10,v1265_11);
        }
        const Space v1263_13 = unite(v1263_8,v1263_12);
        v1262_11_result = unite(v1262_11_result,v1263_13);
      }
      const Space v1262_11 = std::move(v1262_11_result);
      v1257_12 = compose(v1257_10,v1262_11);
    }
    const Space v1257_13 = unite(v1257_8,v1257_12);
    v1256_12_result = unite(v1256_12_result,v1257_13);
  }
  const Space v1256_12 = std::move(v1256_12_result);
  return v1256_12;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1266_9_result;
  for (int v1266_9_label = 1; v1266_9_label <= 2; ++v1266_9_label) {
    const Space v1266_9_tail = child(s0,v1266_9_label);
    if (v1266_9_tail.empty()) continue;
    const Path v1266_9_head{v1266_9_label};
    const Space v1267_2 = singleton(v1266_9_head);
    const Space v1267_3 = intersect(constant_3,v1267_2);
    const Space v1267_4 = (has_head(v1267_3) ? constant_4 : Space{});
    const Space v1267_5 = subtract(constant_2,v1267_4);
    Space v1267_8;
    if (!v1267_5.empty()) {
      const Path v1268_6 = concat_path(p0,v1266_9_head);
      Space v1268_7_result;
      for (int v1268_7_label = 1; v1268_7_label <= 2; ++v1268_7_label) {
        const Space v1268_7_tail = child(v1266_9_tail,v1268_7_label);
        if (v1268_7_tail.empty()) continue;
        const Path v1268_7_head{v1268_7_label};
        const Space v1269_2 = singleton(v1268_7_head);
        const Space v1269_3 = intersect(constant_3,v1269_2);
        const Space v1269_4 = (has_head(v1269_3) ? constant_4 : Space{});
        const Space v1269_5 = subtract(constant_2,v1269_4);
        Space v1269_8;
        if (!v1269_5.empty()) {
          const Path v1270_6 = concat_path(v1268_6,v1268_7_head);
          const Space v1270_7 = routine_170(c, v1270_6, p1, v1268_7_tail);
          v1269_8 = compose(v1269_5,v1270_7);
        }
        const Space v1269_9 = intersect(constant_3,v1269_2);
        const Space v1269_10 = (has_head(v1269_9) ? constant_4 : Space{});
        Space v1269_12;
        if (!v1269_10.empty()) {
          const Path v1271_6 = concat_path(v1268_6,v1268_7_head);
          const Space v1271_11 = routine_171(c, v1271_6, p1, v1268_7_tail);
          v1269_12 = compose(v1269_10,v1271_11);
        }
        const Space v1269_13 = unite(v1269_8,v1269_12);
        v1268_7_result = unite(v1268_7_result,v1269_13);
      }
      const Space v1268_7 = std::move(v1268_7_result);
      v1267_8 = compose(v1267_5,v1268_7);
    }
    const Space v1267_9 = intersect(constant_3,v1267_2);
    const Space v1267_10 = (has_head(v1267_9) ? constant_4 : Space{});
    const Space v1267_11 = compose(v1267_10,v1266_9_tail);
    const Path v1272_6 = concat_path(p0,v1266_9_head);
    const Space v1267_12 = wrap(v1267_11,v1272_6);
    const Space v1267_13 = wrap(v1267_12,p1);
    const Space v1267_14 = unite(v1267_8,v1267_13);
    v1266_9_result = unite(v1266_9_result,v1267_14);
  }
  const Space v1266_9 = std::move(v1266_9_result);
  return v1266_9;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1273_4 = Space{};
  return v1273_4;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1274_6 = unwrap(s1,constant_5);
  const Space v1274_8 = unwrap(v1274_6,constant_6);
  const Space v1274_9 = unwrap(v1274_8,p0);
  Space v1274_13_result;
  for (int v1274_13_label = 1; v1274_13_label <= 2; ++v1274_13_label) {
    const Space v1274_13_tail = child(s0,v1274_13_label);
    if (v1274_13_tail.empty()) continue;
    const Path v1274_13_head{v1274_13_label};
    const Space v1275_2 = singleton(v1274_13_head);
    const Space v1275_3 = intersect(constant_3,v1275_2);
    const Space v1275_4 = (has_head(v1275_3) ? constant_4 : Space{});
    Space v1275_7;
    if (!v1275_4.empty()) {
      const Space v1276_5 = unwrap(v1274_9,v1274_13_head);
      Space v1276_6_result;
      for (int v1276_6_label = 1; v1276_6_label <= 2; ++v1276_6_label) {
        const Space v1276_6_tail = child(v1276_5,v1276_6_label);
        if (v1276_6_tail.empty()) continue;
        const Path v1276_6_head{v1276_6_label};
        const Space v1277_2 = singleton(v1276_6_head);
        const Space v1277_3 = intersect(constant_3,v1277_2);
        const Space v1277_4 = (has_head(v1277_3) ? constant_4 : Space{});
        const Space v1277_5 = subtract(constant_2,v1277_4);
        Space v1277_7;
        if (!v1277_5.empty()) {
          const Space v1278_6 = routine_61(c, v1276_6_head, p1, v1276_6_tail);
          v1277_7 = compose(v1277_5,v1278_6);
        }
        const Space v1277_8 = intersect(constant_3,v1277_2);
        const Space v1277_9 = (has_head(v1277_8) ? constant_4 : Space{});
        Space v1277_11;
        if (!v1277_9.empty()) {
          const Space v1279_10 = routine_62(c, v1276_6_head, p1, v1276_6_tail);
          v1277_11 = compose(v1277_9,v1279_10);
        }
        const Space v1277_12 = unite(v1277_7,v1277_11);
        v1276_6_result = unite(v1276_6_result,v1277_12);
      }
      const Space v1276_6 = std::move(v1276_6_result);
      v1275_7 = compose(v1275_4,v1276_6);
    }
    v1274_13_result = unite(v1274_13_result,v1275_7);
  }
  const Space v1274_13 = std::move(v1274_13_result);
  return v1274_13;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1280_12_result;
  for (int v1280_12_label = 1; v1280_12_label <= 2; ++v1280_12_label) {
    const Space v1280_12_tail = child(s0,v1280_12_label);
    if (v1280_12_tail.empty()) continue;
    const Path v1280_12_head{v1280_12_label};
    const Space v1281_2 = singleton(v1280_12_head);
    const Space v1281_3 = intersect(constant_3,v1281_2);
    const Space v1281_4 = (has_head(v1281_3) ? constant_4 : Space{});
    const Space v1281_5 = subtract(constant_2,v1281_4);
    Space v1281_8;
    if (!v1281_5.empty()) {
      const Path v1282_6 = concat_path(p0,v1280_12_head);
      Space v1282_7_result;
      for (int v1282_7_label = 1; v1282_7_label <= 2; ++v1282_7_label) {
        const Space v1282_7_tail = child(v1280_12_tail,v1282_7_label);
        if (v1282_7_tail.empty()) continue;
        const Path v1282_7_head{v1282_7_label};
        const Space v1283_2 = singleton(v1282_7_head);
        const Space v1283_3 = intersect(constant_3,v1283_2);
        const Space v1283_4 = (has_head(v1283_3) ? constant_4 : Space{});
        const Space v1283_5 = subtract(constant_2,v1283_4);
        Space v1283_8;
        if (!v1283_5.empty()) {
          const Path v1284_6 = concat_path(v1282_6,v1282_7_head);
          const Space v1284_7 = routine_172(c, v1284_6, p1, v1282_7_tail);
          v1283_8 = compose(v1283_5,v1284_7);
        }
        const Space v1283_9 = intersect(constant_3,v1283_2);
        const Space v1283_10 = (has_head(v1283_9) ? constant_4 : Space{});
        Space v1283_12;
        if (!v1283_10.empty()) {
          const Path v1285_6 = concat_path(v1282_6,v1282_7_head);
          const Space v1285_11 = routine_173(c, v1285_6, p1, v1282_7_tail);
          v1283_12 = compose(v1283_10,v1285_11);
        }
        const Space v1283_13 = unite(v1283_8,v1283_12);
        v1282_7_result = unite(v1282_7_result,v1283_13);
      }
      const Space v1282_7 = std::move(v1282_7_result);
      v1281_8 = compose(v1281_5,v1282_7);
    }
    const Space v1281_9 = intersect(constant_3,v1281_2);
    const Space v1281_10 = (has_head(v1281_9) ? constant_4 : Space{});
    Space v1281_12;
    if (!v1281_10.empty()) {
      const Path v1286_6 = concat_path(p0,v1280_12_head);
      Space v1286_11_result;
      for (int v1286_11_label = 1; v1286_11_label <= 2; ++v1286_11_label) {
        const Space v1286_11_tail = child(v1280_12_tail,v1286_11_label);
        if (v1286_11_tail.empty()) continue;
        const Path v1286_11_head{v1286_11_label};
        const Space v1287_2 = singleton(v1286_11_head);
        const Space v1287_3 = intersect(constant_3,v1287_2);
        const Space v1287_4 = (has_head(v1287_3) ? constant_4 : Space{});
        const Space v1287_5 = subtract(constant_2,v1287_4);
        Space v1287_8;
        if (!v1287_5.empty()) {
          const Path v1288_6 = concat_path(v1286_6,v1286_11_head);
          const Space v1288_7 = routine_172(c, v1288_6, p1, v1286_11_tail);
          v1287_8 = compose(v1287_5,v1288_7);
        }
        const Space v1287_9 = intersect(constant_3,v1287_2);
        const Space v1287_10 = (has_head(v1287_9) ? constant_4 : Space{});
        Space v1287_12;
        if (!v1287_10.empty()) {
          const Path v1289_6 = concat_path(v1286_6,v1286_11_head);
          const Space v1289_11 = routine_67(c, v1289_6, p1, v1286_11_tail);
          v1287_12 = compose(v1287_10,v1289_11);
        }
        const Space v1287_13 = unite(v1287_8,v1287_12);
        v1286_11_result = unite(v1286_11_result,v1287_13);
      }
      const Space v1286_11 = std::move(v1286_11_result);
      v1281_12 = compose(v1281_10,v1286_11);
    }
    const Space v1281_13 = unite(v1281_8,v1281_12);
    v1280_12_result = unite(v1280_12_result,v1281_13);
  }
  const Space v1280_12 = std::move(v1280_12_result);
  return v1280_12;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1290_9_result;
  for (int v1290_9_label = 1; v1290_9_label <= 2; ++v1290_9_label) {
    const Space v1290_9_tail = child(s0,v1290_9_label);
    if (v1290_9_tail.empty()) continue;
    const Path v1290_9_head{v1290_9_label};
    const Space v1291_2 = singleton(v1290_9_head);
    const Space v1291_3 = intersect(constant_3,v1291_2);
    const Space v1291_4 = (has_head(v1291_3) ? constant_4 : Space{});
    const Space v1291_5 = subtract(constant_2,v1291_4);
    Space v1291_8;
    if (!v1291_5.empty()) {
      const Path v1292_6 = concat_path(p0,v1290_9_head);
      Space v1292_7_result;
      for (int v1292_7_label = 1; v1292_7_label <= 2; ++v1292_7_label) {
        const Space v1292_7_tail = child(v1290_9_tail,v1292_7_label);
        if (v1292_7_tail.empty()) continue;
        const Path v1292_7_head{v1292_7_label};
        const Space v1293_2 = singleton(v1292_7_head);
        const Space v1293_3 = intersect(constant_3,v1293_2);
        const Space v1293_4 = (has_head(v1293_3) ? constant_4 : Space{});
        const Space v1293_5 = subtract(constant_2,v1293_4);
        Space v1293_8;
        if (!v1293_5.empty()) {
          const Path v1294_6 = concat_path(v1292_6,v1292_7_head);
          const Space v1294_7 = routine_172(c, v1294_6, p1, v1292_7_tail);
          v1293_8 = compose(v1293_5,v1294_7);
        }
        const Space v1293_9 = intersect(constant_3,v1293_2);
        const Space v1293_10 = (has_head(v1293_9) ? constant_4 : Space{});
        Space v1293_12;
        if (!v1293_10.empty()) {
          const Path v1295_6 = concat_path(v1292_6,v1292_7_head);
          const Space v1295_11 = routine_173(c, v1295_6, p1, v1292_7_tail);
          v1293_12 = compose(v1293_10,v1295_11);
        }
        const Space v1293_13 = unite(v1293_8,v1293_12);
        v1292_7_result = unite(v1292_7_result,v1293_13);
      }
      const Space v1292_7 = std::move(v1292_7_result);
      v1291_8 = compose(v1291_5,v1292_7);
    }
    const Space v1291_9 = intersect(constant_3,v1291_2);
    const Space v1291_10 = (has_head(v1291_9) ? constant_4 : Space{});
    const Space v1291_11 = compose(v1291_10,v1290_9_tail);
    const Path v1296_6 = concat_path(p0,v1290_9_head);
    const Space v1291_12 = wrap(v1291_11,v1296_6);
    const Space v1291_13 = wrap(v1291_12,p1);
    const Space v1291_14 = unite(v1291_8,v1291_13);
    v1290_9_result = unite(v1290_9_result,v1291_14);
  }
  const Space v1290_9 = std::move(v1290_9_result);
  return v1290_9;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1297_5_result;
  for (int v1297_5_label = 1; v1297_5_label <= 2; ++v1297_5_label) {
    const Space v1297_5_tail = child(s0,v1297_5_label);
    if (v1297_5_tail.empty()) continue;
    const Path v1297_5_head{v1297_5_label};
    const Space v1298_2 = singleton(v1297_5_head);
    const Space v1298_3 = intersect(constant_3,v1298_2);
    const Space v1298_4 = (has_head(v1298_3) ? constant_4 : Space{});
    Space v1298_7;
    if (!v1298_4.empty()) {
      const Path v1299_5 = concat_path(p0,v1297_5_head);
      Space v1299_6_result;
      for (int v1299_6_label = 1; v1299_6_label <= 2; ++v1299_6_label) {
        const Space v1299_6_tail = child(v1297_5_tail,v1299_6_label);
        if (v1299_6_tail.empty()) continue;
        const Path v1299_6_head{v1299_6_label};
        const Space v1300_2 = singleton(v1299_6_head);
        const Space v1300_3 = intersect(constant_3,v1300_2);
        const Space v1300_4 = (has_head(v1300_3) ? constant_4 : Space{});
        Space v1300_7;
        if (!v1300_4.empty()) {
          const Path v1301_5 = concat_path(v1299_5,v1299_6_head);
          const Space v1301_6 = routine_36(c, v1301_5, p1, v1299_6_tail);
          v1300_7 = compose(v1300_4,v1301_6);
        }
        v1299_6_result = unite(v1299_6_result,v1300_7);
      }
      const Space v1299_6 = std::move(v1299_6_result);
      v1298_7 = compose(v1298_4,v1299_6);
    }
    v1297_5_result = unite(v1297_5_result,v1298_7);
  }
  const Space v1297_5 = std::move(v1297_5_result);
  return v1297_5;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1302_4_result;
  for (int v1302_4_label = 1; v1302_4_label <= 2; ++v1302_4_label) {
    const Space v1302_4_tail = child(s0,v1302_4_label);
    if (v1302_4_tail.empty()) continue;
    const Path v1302_4_head{v1302_4_label};
    const Space v1303_2 = singleton(v1302_4_head);
    const Space v1303_3 = intersect(constant_3,v1303_2);
    const Space v1303_4 = (has_head(v1303_3) ? constant_4 : Space{});
    const Space v1303_5 = compose(v1303_4,v1302_4_tail);
    const Path v1303_6 = concat_path(p0,v1302_4_head);
    const Space v1303_7 = wrap(v1303_5,v1303_6);
    v1302_4_result = unite(v1302_4_result,v1303_7);
  }
  const Space v1302_4 = std::move(v1302_4_result);
  const Space v1302_5 = wrap(v1302_4,p1);
  return v1302_5;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1304_3 = Space{};
  return v1304_3;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1305_4_result;
  for (int v1305_4_label = 1; v1305_4_label <= 2; ++v1305_4_label) {
    const Space v1305_4_tail = child(s0,v1305_4_label);
    if (v1305_4_tail.empty()) continue;
    const Path v1305_4_head{v1305_4_label};
    const Space v1306_2 = singleton(v1305_4_head);
    const Space v1306_3 = intersect(constant_3,v1306_2);
    const Space v1306_4 = (has_head(v1306_3) ? constant_4 : Space{});
    const Space v1306_5 = compose(v1306_4,v1305_4_tail);
    const Path v1306_6 = concat_path(p0,v1305_4_head);
    const Space v1306_7 = wrap(v1306_5,v1306_6);
    v1305_4_result = unite(v1305_4_result,v1306_7);
  }
  const Space v1305_4 = std::move(v1305_4_result);
  const Space v1305_5 = wrap(v1305_4,p1);
  return v1305_5;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1307_6_result;
  for (int v1307_6_label = 1; v1307_6_label <= 2; ++v1307_6_label) {
    const Space v1307_6_tail = child(s0,v1307_6_label);
    if (v1307_6_tail.empty()) continue;
    const Path v1307_6_head{v1307_6_label};
    const Space v1308_2 = singleton(v1307_6_head);
    const Space v1308_3 = intersect(constant_3,v1308_2);
    const Space v1308_4 = (has_head(v1308_3) ? constant_4 : Space{});
    Space v1308_7;
    if (!v1308_4.empty()) {
      const Path v1309_5 = concat_path(p0,v1307_6_head);
      Space v1309_6_result;
      for (int v1309_6_label = 1; v1309_6_label <= 2; ++v1309_6_label) {
        const Space v1309_6_tail = child(v1307_6_tail,v1309_6_label);
        if (v1309_6_tail.empty()) continue;
        const Path v1309_6_head{v1309_6_label};
        const Space v1310_2 = singleton(v1309_6_head);
        const Space v1310_3 = intersect(constant_3,v1310_2);
        const Space v1310_4 = (has_head(v1310_3) ? constant_4 : Space{});
        Space v1310_7;
        if (!v1310_4.empty()) {
          const Path v1311_5 = concat_path(v1309_5,v1309_6_head);
          const Space v1311_6 = routine_43(c, v1311_5, p1, v1309_6_tail, s1);
          v1310_7 = compose(v1310_4,v1311_6);
        }
        v1309_6_result = unite(v1309_6_result,v1310_7);
      }
      const Space v1309_6 = std::move(v1309_6_result);
      v1308_7 = compose(v1308_4,v1309_6);
    }
    v1307_6_result = unite(v1307_6_result,v1308_7);
  }
  const Space v1307_6 = std::move(v1307_6_result);
  return v1307_6;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1312_6 = unwrap(s1,constant_0);
  const Space v1312_8 = unwrap(v1312_6,constant_6);
  const Space v1312_9 = unwrap(v1312_8,p0);
  Space v1312_13_result;
  for (int v1312_13_label = 1; v1312_13_label <= 2; ++v1312_13_label) {
    const Space v1312_13_tail = child(s0,v1312_13_label);
    if (v1312_13_tail.empty()) continue;
    const Path v1312_13_head{v1312_13_label};
    const Space v1313_2 = singleton(v1312_13_head);
    const Space v1313_3 = intersect(constant_3,v1313_2);
    const Space v1313_4 = (has_head(v1313_3) ? constant_4 : Space{});
    Space v1313_7;
    if (!v1313_4.empty()) {
      const Space v1314_5 = unwrap(v1312_9,v1312_13_head);
      Space v1314_6_result;
      for (int v1314_6_label = 1; v1314_6_label <= 2; ++v1314_6_label) {
        const Space v1314_6_tail = child(v1314_5,v1314_6_label);
        if (v1314_6_tail.empty()) continue;
        const Path v1314_6_head{v1314_6_label};
        const Space v1315_2 = singleton(v1314_6_head);
        const Space v1315_3 = intersect(constant_3,v1315_2);
        const Space v1315_4 = (has_head(v1315_3) ? constant_4 : Space{});
        const Space v1315_5 = subtract(constant_2,v1315_4);
        Space v1315_7;
        if (!v1315_5.empty()) {
          const Space v1316_6 = routine_78(c, v1314_6_head, p1, v1314_6_tail);
          v1315_7 = compose(v1315_5,v1316_6);
        }
        const Space v1315_8 = intersect(constant_3,v1315_2);
        const Space v1315_9 = (has_head(v1315_8) ? constant_4 : Space{});
        Space v1315_11;
        if (!v1315_9.empty()) {
          const Space v1317_10 = routine_79(c, v1314_6_head, p1, v1314_6_tail);
          v1315_11 = compose(v1315_9,v1317_10);
        }
        const Space v1315_12 = unite(v1315_7,v1315_11);
        v1314_6_result = unite(v1314_6_result,v1315_12);
      }
      const Space v1314_6 = std::move(v1314_6_result);
      v1313_7 = compose(v1313_4,v1314_6);
    }
    v1312_13_result = unite(v1312_13_result,v1313_7);
  }
  const Space v1312_13 = std::move(v1312_13_result);
  return v1312_13;
}

static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1318_12_result;
  for (int v1318_12_label = 1; v1318_12_label <= 2; ++v1318_12_label) {
    const Space v1318_12_tail = child(s0,v1318_12_label);
    if (v1318_12_tail.empty()) continue;
    const Path v1318_12_head{v1318_12_label};
    const Space v1319_2 = singleton(v1318_12_head);
    const Space v1319_3 = intersect(constant_3,v1319_2);
    const Space v1319_4 = (has_head(v1319_3) ? constant_4 : Space{});
    const Space v1319_5 = subtract(constant_2,v1319_4);
    Space v1319_8;
    if (!v1319_5.empty()) {
      const Path v1320_6 = concat_path(p0,v1318_12_head);
      Space v1320_7_result;
      for (int v1320_7_label = 1; v1320_7_label <= 2; ++v1320_7_label) {
        const Space v1320_7_tail = child(v1318_12_tail,v1320_7_label);
        if (v1320_7_tail.empty()) continue;
        const Path v1320_7_head{v1320_7_label};
        const Space v1321_2 = singleton(v1320_7_head);
        const Space v1321_3 = intersect(constant_3,v1321_2);
        const Space v1321_4 = (has_head(v1321_3) ? constant_4 : Space{});
        const Space v1321_5 = subtract(constant_2,v1321_4);
        Space v1321_8;
        if (!v1321_5.empty()) {
          const Path v1322_6 = concat_path(v1320_6,v1320_7_head);
          const Space v1322_7 = routine_174(c, v1322_6, p1, v1320_7_tail);
          v1321_8 = compose(v1321_5,v1322_7);
        }
        const Space v1321_9 = intersect(constant_3,v1321_2);
        const Space v1321_10 = (has_head(v1321_9) ? constant_4 : Space{});
        Space v1321_12;
        if (!v1321_10.empty()) {
          const Path v1323_6 = concat_path(v1320_6,v1320_7_head);
          const Space v1323_11 = routine_175(c, v1323_6, p1, v1320_7_tail);
          v1321_12 = compose(v1321_10,v1323_11);
        }
        const Space v1321_13 = unite(v1321_8,v1321_12);
        v1320_7_result = unite(v1320_7_result,v1321_13);
      }
      const Space v1320_7 = std::move(v1320_7_result);
      v1319_8 = compose(v1319_5,v1320_7);
    }
    const Space v1319_9 = intersect(constant_3,v1319_2);
    const Space v1319_10 = (has_head(v1319_9) ? constant_4 : Space{});
    Space v1319_12;
    if (!v1319_10.empty()) {
      const Path v1324_6 = concat_path(p0,v1318_12_head);
      Space v1324_11_result;
      for (int v1324_11_label = 1; v1324_11_label <= 2; ++v1324_11_label) {
        const Space v1324_11_tail = child(v1318_12_tail,v1324_11_label);
        if (v1324_11_tail.empty()) continue;
        const Path v1324_11_head{v1324_11_label};
        const Space v1325_2 = singleton(v1324_11_head);
        const Space v1325_3 = intersect(constant_3,v1325_2);
        const Space v1325_4 = (has_head(v1325_3) ? constant_4 : Space{});
        const Space v1325_5 = subtract(constant_2,v1325_4);
        Space v1325_8;
        if (!v1325_5.empty()) {
          const Path v1326_6 = concat_path(v1324_6,v1324_11_head);
          const Space v1326_7 = routine_174(c, v1326_6, p1, v1324_11_tail);
          v1325_8 = compose(v1325_5,v1326_7);
        }
        const Space v1325_9 = intersect(constant_3,v1325_2);
        const Space v1325_10 = (has_head(v1325_9) ? constant_4 : Space{});
        Space v1325_12;
        if (!v1325_10.empty()) {
          const Path v1327_6 = concat_path(v1324_6,v1324_11_head);
          const Space v1327_11 = routine_84(c, v1327_6, p1, v1324_11_tail);
          v1325_12 = compose(v1325_10,v1327_11);
        }
        const Space v1325_13 = unite(v1325_8,v1325_12);
        v1324_11_result = unite(v1324_11_result,v1325_13);
      }
      const Space v1324_11 = std::move(v1324_11_result);
      v1319_12 = compose(v1319_10,v1324_11);
    }
    const Space v1319_13 = unite(v1319_8,v1319_12);
    v1318_12_result = unite(v1318_12_result,v1319_13);
  }
  const Space v1318_12 = std::move(v1318_12_result);
  return v1318_12;
}

static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1328_9_result;
  for (int v1328_9_label = 1; v1328_9_label <= 2; ++v1328_9_label) {
    const Space v1328_9_tail = child(s0,v1328_9_label);
    if (v1328_9_tail.empty()) continue;
    const Path v1328_9_head{v1328_9_label};
    const Space v1329_2 = singleton(v1328_9_head);
    const Space v1329_3 = intersect(constant_3,v1329_2);
    const Space v1329_4 = (has_head(v1329_3) ? constant_4 : Space{});
    const Space v1329_5 = subtract(constant_2,v1329_4);
    Space v1329_8;
    if (!v1329_5.empty()) {
      const Path v1330_6 = concat_path(p0,v1328_9_head);
      Space v1330_7_result;
      for (int v1330_7_label = 1; v1330_7_label <= 2; ++v1330_7_label) {
        const Space v1330_7_tail = child(v1328_9_tail,v1330_7_label);
        if (v1330_7_tail.empty()) continue;
        const Path v1330_7_head{v1330_7_label};
        const Space v1331_2 = singleton(v1330_7_head);
        const Space v1331_3 = intersect(constant_3,v1331_2);
        const Space v1331_4 = (has_head(v1331_3) ? constant_4 : Space{});
        const Space v1331_5 = subtract(constant_2,v1331_4);
        Space v1331_8;
        if (!v1331_5.empty()) {
          const Path v1332_6 = concat_path(v1330_6,v1330_7_head);
          const Space v1332_7 = routine_174(c, v1332_6, p1, v1330_7_tail);
          v1331_8 = compose(v1331_5,v1332_7);
        }
        const Space v1331_9 = intersect(constant_3,v1331_2);
        const Space v1331_10 = (has_head(v1331_9) ? constant_4 : Space{});
        Space v1331_12;
        if (!v1331_10.empty()) {
          const Path v1333_6 = concat_path(v1330_6,v1330_7_head);
          const Space v1333_11 = routine_175(c, v1333_6, p1, v1330_7_tail);
          v1331_12 = compose(v1331_10,v1333_11);
        }
        const Space v1331_13 = unite(v1331_8,v1331_12);
        v1330_7_result = unite(v1330_7_result,v1331_13);
      }
      const Space v1330_7 = std::move(v1330_7_result);
      v1329_8 = compose(v1329_5,v1330_7);
    }
    const Space v1329_9 = intersect(constant_3,v1329_2);
    const Space v1329_10 = (has_head(v1329_9) ? constant_4 : Space{});
    const Space v1329_11 = compose(v1329_10,v1328_9_tail);
    const Path v1334_6 = concat_path(p0,v1328_9_head);
    const Space v1329_12 = wrap(v1329_11,v1334_6);
    const Space v1329_13 = wrap(v1329_12,p1);
    const Space v1329_14 = unite(v1329_8,v1329_13);
    v1328_9_result = unite(v1328_9_result,v1329_14);
  }
  const Space v1328_9 = std::move(v1328_9_result);
  return v1328_9;
}

static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1335_4 = Space{};
  return v1335_4;
}

static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1336_6 = unwrap(s1,constant_0);
  const Space v1336_8 = unwrap(v1336_6,constant_6);
  const Space v1336_9 = unwrap(v1336_8,p0);
  Space v1336_13_result;
  for (int v1336_13_label = 1; v1336_13_label <= 2; ++v1336_13_label) {
    const Space v1336_13_tail = child(s0,v1336_13_label);
    if (v1336_13_tail.empty()) continue;
    const Path v1336_13_head{v1336_13_label};
    const Space v1337_2 = singleton(v1336_13_head);
    const Space v1337_3 = intersect(constant_3,v1337_2);
    const Space v1337_4 = (has_head(v1337_3) ? constant_4 : Space{});
    Space v1337_7;
    if (!v1337_4.empty()) {
      const Space v1338_5 = unwrap(v1336_9,v1336_13_head);
      Space v1338_6_result;
      for (int v1338_6_label = 1; v1338_6_label <= 2; ++v1338_6_label) {
        const Space v1338_6_tail = child(v1338_5,v1338_6_label);
        if (v1338_6_tail.empty()) continue;
        const Path v1338_6_head{v1338_6_label};
        const Space v1339_2 = singleton(v1338_6_head);
        const Space v1339_3 = intersect(constant_3,v1339_2);
        const Space v1339_4 = (has_head(v1339_3) ? constant_4 : Space{});
        const Space v1339_5 = subtract(constant_2,v1339_4);
        Space v1339_7;
        if (!v1339_5.empty()) {
          const Space v1340_6 = routine_78(c, v1338_6_head, p1, v1338_6_tail);
          v1339_7 = compose(v1339_5,v1340_6);
        }
        const Space v1339_8 = intersect(constant_3,v1339_2);
        const Space v1339_9 = (has_head(v1339_8) ? constant_4 : Space{});
        Space v1339_11;
        if (!v1339_9.empty()) {
          const Space v1341_10 = routine_79(c, v1338_6_head, p1, v1338_6_tail);
          v1339_11 = compose(v1339_9,v1341_10);
        }
        const Space v1339_12 = unite(v1339_7,v1339_11);
        v1338_6_result = unite(v1338_6_result,v1339_12);
      }
      const Space v1338_6 = std::move(v1338_6_result);
      v1337_7 = compose(v1337_4,v1338_6);
    }
    v1336_13_result = unite(v1336_13_result,v1337_7);
  }
  const Space v1336_13 = std::move(v1336_13_result);
  return v1336_13;
}

static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1342_12_result;
  for (int v1342_12_label = 1; v1342_12_label <= 2; ++v1342_12_label) {
    const Space v1342_12_tail = child(s0,v1342_12_label);
    if (v1342_12_tail.empty()) continue;
    const Path v1342_12_head{v1342_12_label};
    const Space v1343_2 = singleton(v1342_12_head);
    const Space v1343_3 = intersect(constant_3,v1343_2);
    const Space v1343_4 = (has_head(v1343_3) ? constant_4 : Space{});
    const Space v1343_5 = subtract(constant_2,v1343_4);
    Space v1343_8;
    if (!v1343_5.empty()) {
      const Path v1344_6 = concat_path(p0,v1342_12_head);
      Space v1344_7_result;
      for (int v1344_7_label = 1; v1344_7_label <= 2; ++v1344_7_label) {
        const Space v1344_7_tail = child(v1342_12_tail,v1344_7_label);
        if (v1344_7_tail.empty()) continue;
        const Path v1344_7_head{v1344_7_label};
        const Space v1345_2 = singleton(v1344_7_head);
        const Space v1345_3 = intersect(constant_3,v1345_2);
        const Space v1345_4 = (has_head(v1345_3) ? constant_4 : Space{});
        const Space v1345_5 = subtract(constant_2,v1345_4);
        Space v1345_8;
        if (!v1345_5.empty()) {
          const Path v1346_6 = concat_path(v1344_6,v1344_7_head);
          const Space v1346_7 = routine_176(c, v1346_6, p1, v1344_7_tail);
          v1345_8 = compose(v1345_5,v1346_7);
        }
        const Space v1345_9 = intersect(constant_3,v1345_2);
        const Space v1345_10 = (has_head(v1345_9) ? constant_4 : Space{});
        Space v1345_12;
        if (!v1345_10.empty()) {
          const Path v1347_6 = concat_path(v1344_6,v1344_7_head);
          const Space v1347_11 = routine_177(c, v1347_6, p1, v1344_7_tail);
          v1345_12 = compose(v1345_10,v1347_11);
        }
        const Space v1345_13 = unite(v1345_8,v1345_12);
        v1344_7_result = unite(v1344_7_result,v1345_13);
      }
      const Space v1344_7 = std::move(v1344_7_result);
      v1343_8 = compose(v1343_5,v1344_7);
    }
    const Space v1343_9 = intersect(constant_3,v1343_2);
    const Space v1343_10 = (has_head(v1343_9) ? constant_4 : Space{});
    Space v1343_12;
    if (!v1343_10.empty()) {
      const Path v1348_6 = concat_path(p0,v1342_12_head);
      Space v1348_11_result;
      for (int v1348_11_label = 1; v1348_11_label <= 2; ++v1348_11_label) {
        const Space v1348_11_tail = child(v1342_12_tail,v1348_11_label);
        if (v1348_11_tail.empty()) continue;
        const Path v1348_11_head{v1348_11_label};
        const Space v1349_2 = singleton(v1348_11_head);
        const Space v1349_3 = intersect(constant_3,v1349_2);
        const Space v1349_4 = (has_head(v1349_3) ? constant_4 : Space{});
        const Space v1349_5 = subtract(constant_2,v1349_4);
        Space v1349_8;
        if (!v1349_5.empty()) {
          const Path v1350_6 = concat_path(v1348_6,v1348_11_head);
          const Space v1350_7 = routine_176(c, v1350_6, p1, v1348_11_tail);
          v1349_8 = compose(v1349_5,v1350_7);
        }
        const Space v1349_9 = intersect(constant_3,v1349_2);
        const Space v1349_10 = (has_head(v1349_9) ? constant_4 : Space{});
        Space v1349_12;
        if (!v1349_10.empty()) {
          const Path v1351_6 = concat_path(v1348_6,v1348_11_head);
          const Space v1351_11 = routine_84(c, v1351_6, p1, v1348_11_tail);
          v1349_12 = compose(v1349_10,v1351_11);
        }
        const Space v1349_13 = unite(v1349_8,v1349_12);
        v1348_11_result = unite(v1348_11_result,v1349_13);
      }
      const Space v1348_11 = std::move(v1348_11_result);
      v1343_12 = compose(v1343_10,v1348_11);
    }
    const Space v1343_13 = unite(v1343_8,v1343_12);
    v1342_12_result = unite(v1342_12_result,v1343_13);
  }
  const Space v1342_12 = std::move(v1342_12_result);
  return v1342_12;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1352_9_result;
  for (int v1352_9_label = 1; v1352_9_label <= 2; ++v1352_9_label) {
    const Space v1352_9_tail = child(s0,v1352_9_label);
    if (v1352_9_tail.empty()) continue;
    const Path v1352_9_head{v1352_9_label};
    const Space v1353_2 = singleton(v1352_9_head);
    const Space v1353_3 = intersect(constant_3,v1353_2);
    const Space v1353_4 = (has_head(v1353_3) ? constant_4 : Space{});
    const Space v1353_5 = subtract(constant_2,v1353_4);
    Space v1353_8;
    if (!v1353_5.empty()) {
      const Path v1354_6 = concat_path(p0,v1352_9_head);
      Space v1354_7_result;
      for (int v1354_7_label = 1; v1354_7_label <= 2; ++v1354_7_label) {
        const Space v1354_7_tail = child(v1352_9_tail,v1354_7_label);
        if (v1354_7_tail.empty()) continue;
        const Path v1354_7_head{v1354_7_label};
        const Space v1355_2 = singleton(v1354_7_head);
        const Space v1355_3 = intersect(constant_3,v1355_2);
        const Space v1355_4 = (has_head(v1355_3) ? constant_4 : Space{});
        const Space v1355_5 = subtract(constant_2,v1355_4);
        Space v1355_8;
        if (!v1355_5.empty()) {
          const Path v1356_6 = concat_path(v1354_6,v1354_7_head);
          const Space v1356_7 = routine_176(c, v1356_6, p1, v1354_7_tail);
          v1355_8 = compose(v1355_5,v1356_7);
        }
        const Space v1355_9 = intersect(constant_3,v1355_2);
        const Space v1355_10 = (has_head(v1355_9) ? constant_4 : Space{});
        Space v1355_12;
        if (!v1355_10.empty()) {
          const Path v1357_6 = concat_path(v1354_6,v1354_7_head);
          const Space v1357_11 = routine_177(c, v1357_6, p1, v1354_7_tail);
          v1355_12 = compose(v1355_10,v1357_11);
        }
        const Space v1355_13 = unite(v1355_8,v1355_12);
        v1354_7_result = unite(v1354_7_result,v1355_13);
      }
      const Space v1354_7 = std::move(v1354_7_result);
      v1353_8 = compose(v1353_5,v1354_7);
    }
    const Space v1353_9 = intersect(constant_3,v1353_2);
    const Space v1353_10 = (has_head(v1353_9) ? constant_4 : Space{});
    const Space v1353_11 = compose(v1353_10,v1352_9_tail);
    const Path v1358_6 = concat_path(p0,v1352_9_head);
    const Space v1353_12 = wrap(v1353_11,v1358_6);
    const Space v1353_13 = wrap(v1353_12,p1);
    const Space v1353_14 = unite(v1353_8,v1353_13);
    v1352_9_result = unite(v1352_9_result,v1353_14);
  }
  const Space v1352_9 = std::move(v1352_9_result);
  return v1352_9;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1359_6_result;
  for (int v1359_6_label = 1; v1359_6_label <= 2; ++v1359_6_label) {
    const Space v1359_6_tail = child(s0,v1359_6_label);
    if (v1359_6_tail.empty()) continue;
    const Path v1359_6_head{v1359_6_label};
    const Space v1360_2 = singleton(v1359_6_head);
    const Space v1360_3 = intersect(constant_3,v1360_2);
    const Space v1360_4 = (has_head(v1360_3) ? constant_4 : Space{});
    Space v1360_7;
    if (!v1360_4.empty()) {
      const Path v1361_5 = concat_path(p0,v1359_6_head);
      Space v1361_6_result;
      for (int v1361_6_label = 1; v1361_6_label <= 2; ++v1361_6_label) {
        const Space v1361_6_tail = child(v1359_6_tail,v1361_6_label);
        if (v1361_6_tail.empty()) continue;
        const Path v1361_6_head{v1361_6_label};
        const Space v1362_2 = singleton(v1361_6_head);
        const Space v1362_3 = intersect(constant_3,v1362_2);
        const Space v1362_4 = (has_head(v1362_3) ? constant_4 : Space{});
        Space v1362_7;
        if (!v1362_4.empty()) {
          const Path v1363_5 = concat_path(v1361_5,v1361_6_head);
          const Space v1363_6 = routine_50(c, v1363_5, p1, v1361_6_tail, s1);
          v1362_7 = compose(v1362_4,v1363_6);
        }
        v1361_6_result = unite(v1361_6_result,v1362_7);
      }
      const Space v1361_6 = std::move(v1361_6_result);
      v1360_7 = compose(v1360_4,v1361_6);
    }
    v1359_6_result = unite(v1359_6_result,v1360_7);
  }
  const Space v1359_6 = std::move(v1359_6_result);
  return v1359_6;
}

static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1364_6 = unwrap(s1,constant_5);
  const Space v1364_8 = unwrap(v1364_6,constant_6);
  const Space v1364_9 = unwrap(v1364_8,p0);
  Space v1364_13_result;
  for (int v1364_13_label = 1; v1364_13_label <= 2; ++v1364_13_label) {
    const Space v1364_13_tail = child(s0,v1364_13_label);
    if (v1364_13_tail.empty()) continue;
    const Path v1364_13_head{v1364_13_label};
    const Space v1365_2 = singleton(v1364_13_head);
    const Space v1365_3 = intersect(constant_3,v1365_2);
    const Space v1365_4 = (has_head(v1365_3) ? constant_4 : Space{});
    Space v1365_7;
    if (!v1365_4.empty()) {
      const Space v1366_5 = unwrap(v1364_9,v1364_13_head);
      Space v1366_6_result;
      for (int v1366_6_label = 1; v1366_6_label <= 2; ++v1366_6_label) {
        const Space v1366_6_tail = child(v1366_5,v1366_6_label);
        if (v1366_6_tail.empty()) continue;
        const Path v1366_6_head{v1366_6_label};
        const Space v1367_2 = singleton(v1366_6_head);
        const Space v1367_3 = intersect(constant_3,v1367_2);
        const Space v1367_4 = (has_head(v1367_3) ? constant_4 : Space{});
        const Space v1367_5 = subtract(constant_2,v1367_4);
        Space v1367_7;
        if (!v1367_5.empty()) {
          const Space v1368_6 = routine_89(c, v1366_6_head, p1, v1366_6_tail);
          v1367_7 = compose(v1367_5,v1368_6);
        }
        const Space v1367_8 = intersect(constant_3,v1367_2);
        const Space v1367_9 = (has_head(v1367_8) ? constant_4 : Space{});
        Space v1367_11;
        if (!v1367_9.empty()) {
          const Space v1369_10 = routine_90(c, v1366_6_head, p1, v1366_6_tail);
          v1367_11 = compose(v1367_9,v1369_10);
        }
        const Space v1367_12 = unite(v1367_7,v1367_11);
        v1366_6_result = unite(v1366_6_result,v1367_12);
      }
      const Space v1366_6 = std::move(v1366_6_result);
      v1365_7 = compose(v1365_4,v1366_6);
    }
    v1364_13_result = unite(v1364_13_result,v1365_7);
  }
  const Space v1364_13 = std::move(v1364_13_result);
  return v1364_13;
}

static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1370_12_result;
  for (int v1370_12_label = 1; v1370_12_label <= 2; ++v1370_12_label) {
    const Space v1370_12_tail = child(s0,v1370_12_label);
    if (v1370_12_tail.empty()) continue;
    const Path v1370_12_head{v1370_12_label};
    const Space v1371_2 = singleton(v1370_12_head);
    const Space v1371_3 = intersect(constant_3,v1371_2);
    const Space v1371_4 = (has_head(v1371_3) ? constant_4 : Space{});
    const Space v1371_5 = subtract(constant_2,v1371_4);
    Space v1371_8;
    if (!v1371_5.empty()) {
      const Path v1372_6 = concat_path(p0,v1370_12_head);
      Space v1372_7_result;
      for (int v1372_7_label = 1; v1372_7_label <= 2; ++v1372_7_label) {
        const Space v1372_7_tail = child(v1370_12_tail,v1372_7_label);
        if (v1372_7_tail.empty()) continue;
        const Path v1372_7_head{v1372_7_label};
        const Space v1373_2 = singleton(v1372_7_head);
        const Space v1373_3 = intersect(constant_3,v1373_2);
        const Space v1373_4 = (has_head(v1373_3) ? constant_4 : Space{});
        const Space v1373_5 = subtract(constant_2,v1373_4);
        Space v1373_8;
        if (!v1373_5.empty()) {
          const Path v1374_6 = concat_path(v1372_6,v1372_7_head);
          const Space v1374_7 = routine_178(c, v1374_6, p1, v1372_7_tail);
          v1373_8 = compose(v1373_5,v1374_7);
        }
        const Space v1373_9 = intersect(constant_3,v1373_2);
        const Space v1373_10 = (has_head(v1373_9) ? constant_4 : Space{});
        Space v1373_12;
        if (!v1373_10.empty()) {
          const Path v1375_6 = concat_path(v1372_6,v1372_7_head);
          const Space v1375_11 = routine_179(c, v1375_6, p1, v1372_7_tail);
          v1373_12 = compose(v1373_10,v1375_11);
        }
        const Space v1373_13 = unite(v1373_8,v1373_12);
        v1372_7_result = unite(v1372_7_result,v1373_13);
      }
      const Space v1372_7 = std::move(v1372_7_result);
      v1371_8 = compose(v1371_5,v1372_7);
    }
    const Space v1371_9 = intersect(constant_3,v1371_2);
    const Space v1371_10 = (has_head(v1371_9) ? constant_4 : Space{});
    Space v1371_12;
    if (!v1371_10.empty()) {
      const Path v1376_6 = concat_path(p0,v1370_12_head);
      Space v1376_11_result;
      for (int v1376_11_label = 1; v1376_11_label <= 2; ++v1376_11_label) {
        const Space v1376_11_tail = child(v1370_12_tail,v1376_11_label);
        if (v1376_11_tail.empty()) continue;
        const Path v1376_11_head{v1376_11_label};
        const Space v1377_2 = singleton(v1376_11_head);
        const Space v1377_3 = intersect(constant_3,v1377_2);
        const Space v1377_4 = (has_head(v1377_3) ? constant_4 : Space{});
        const Space v1377_5 = subtract(constant_2,v1377_4);
        Space v1377_8;
        if (!v1377_5.empty()) {
          const Path v1378_6 = concat_path(v1376_6,v1376_11_head);
          const Space v1378_7 = routine_178(c, v1378_6, p1, v1376_11_tail);
          v1377_8 = compose(v1377_5,v1378_7);
        }
        const Space v1377_9 = intersect(constant_3,v1377_2);
        const Space v1377_10 = (has_head(v1377_9) ? constant_4 : Space{});
        Space v1377_12;
        if (!v1377_10.empty()) {
          const Path v1379_6 = concat_path(v1376_6,v1376_11_head);
          const Space v1379_11 = routine_95(c, v1379_6, p1, v1376_11_tail);
          v1377_12 = compose(v1377_10,v1379_11);
        }
        const Space v1377_13 = unite(v1377_8,v1377_12);
        v1376_11_result = unite(v1376_11_result,v1377_13);
      }
      const Space v1376_11 = std::move(v1376_11_result);
      v1371_12 = compose(v1371_10,v1376_11);
    }
    const Space v1371_13 = unite(v1371_8,v1371_12);
    v1370_12_result = unite(v1370_12_result,v1371_13);
  }
  const Space v1370_12 = std::move(v1370_12_result);
  return v1370_12;
}

static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1380_9_result;
  for (int v1380_9_label = 1; v1380_9_label <= 2; ++v1380_9_label) {
    const Space v1380_9_tail = child(s0,v1380_9_label);
    if (v1380_9_tail.empty()) continue;
    const Path v1380_9_head{v1380_9_label};
    const Space v1381_2 = singleton(v1380_9_head);
    const Space v1381_3 = intersect(constant_3,v1381_2);
    const Space v1381_4 = (has_head(v1381_3) ? constant_4 : Space{});
    const Space v1381_5 = subtract(constant_2,v1381_4);
    Space v1381_8;
    if (!v1381_5.empty()) {
      const Path v1382_6 = concat_path(p0,v1380_9_head);
      Space v1382_7_result;
      for (int v1382_7_label = 1; v1382_7_label <= 2; ++v1382_7_label) {
        const Space v1382_7_tail = child(v1380_9_tail,v1382_7_label);
        if (v1382_7_tail.empty()) continue;
        const Path v1382_7_head{v1382_7_label};
        const Space v1383_2 = singleton(v1382_7_head);
        const Space v1383_3 = intersect(constant_3,v1383_2);
        const Space v1383_4 = (has_head(v1383_3) ? constant_4 : Space{});
        const Space v1383_5 = subtract(constant_2,v1383_4);
        Space v1383_8;
        if (!v1383_5.empty()) {
          const Path v1384_6 = concat_path(v1382_6,v1382_7_head);
          const Space v1384_7 = routine_178(c, v1384_6, p1, v1382_7_tail);
          v1383_8 = compose(v1383_5,v1384_7);
        }
        const Space v1383_9 = intersect(constant_3,v1383_2);
        const Space v1383_10 = (has_head(v1383_9) ? constant_4 : Space{});
        Space v1383_12;
        if (!v1383_10.empty()) {
          const Path v1385_6 = concat_path(v1382_6,v1382_7_head);
          const Space v1385_11 = routine_179(c, v1385_6, p1, v1382_7_tail);
          v1383_12 = compose(v1383_10,v1385_11);
        }
        const Space v1383_13 = unite(v1383_8,v1383_12);
        v1382_7_result = unite(v1382_7_result,v1383_13);
      }
      const Space v1382_7 = std::move(v1382_7_result);
      v1381_8 = compose(v1381_5,v1382_7);
    }
    const Space v1381_9 = intersect(constant_3,v1381_2);
    const Space v1381_10 = (has_head(v1381_9) ? constant_4 : Space{});
    const Space v1381_11 = compose(v1381_10,v1380_9_tail);
    const Path v1386_6 = concat_path(p0,v1380_9_head);
    const Space v1381_12 = wrap(v1381_11,v1386_6);
    const Space v1381_13 = wrap(v1381_12,p1);
    const Space v1381_14 = unite(v1381_8,v1381_13);
    v1380_9_result = unite(v1380_9_result,v1381_14);
  }
  const Space v1380_9 = std::move(v1380_9_result);
  return v1380_9;
}

static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1387_4 = Space{};
  return v1387_4;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1388_6 = unwrap(s1,constant_5);
  const Space v1388_8 = unwrap(v1388_6,constant_6);
  const Space v1388_9 = unwrap(v1388_8,p0);
  Space v1388_13_result;
  for (int v1388_13_label = 1; v1388_13_label <= 2; ++v1388_13_label) {
    const Space v1388_13_tail = child(s0,v1388_13_label);
    if (v1388_13_tail.empty()) continue;
    const Path v1388_13_head{v1388_13_label};
    const Space v1389_2 = singleton(v1388_13_head);
    const Space v1389_3 = intersect(constant_3,v1389_2);
    const Space v1389_4 = (has_head(v1389_3) ? constant_4 : Space{});
    Space v1389_7;
    if (!v1389_4.empty()) {
      const Space v1390_5 = unwrap(v1388_9,v1388_13_head);
      Space v1390_6_result;
      for (int v1390_6_label = 1; v1390_6_label <= 2; ++v1390_6_label) {
        const Space v1390_6_tail = child(v1390_5,v1390_6_label);
        if (v1390_6_tail.empty()) continue;
        const Path v1390_6_head{v1390_6_label};
        const Space v1391_2 = singleton(v1390_6_head);
        const Space v1391_3 = intersect(constant_3,v1391_2);
        const Space v1391_4 = (has_head(v1391_3) ? constant_4 : Space{});
        const Space v1391_5 = subtract(constant_2,v1391_4);
        Space v1391_7;
        if (!v1391_5.empty()) {
          const Space v1392_6 = routine_89(c, v1390_6_head, p1, v1390_6_tail);
          v1391_7 = compose(v1391_5,v1392_6);
        }
        const Space v1391_8 = intersect(constant_3,v1391_2);
        const Space v1391_9 = (has_head(v1391_8) ? constant_4 : Space{});
        Space v1391_11;
        if (!v1391_9.empty()) {
          const Space v1393_10 = routine_90(c, v1390_6_head, p1, v1390_6_tail);
          v1391_11 = compose(v1391_9,v1393_10);
        }
        const Space v1391_12 = unite(v1391_7,v1391_11);
        v1390_6_result = unite(v1390_6_result,v1391_12);
      }
      const Space v1390_6 = std::move(v1390_6_result);
      v1389_7 = compose(v1389_4,v1390_6);
    }
    v1388_13_result = unite(v1388_13_result,v1389_7);
  }
  const Space v1388_13 = std::move(v1388_13_result);
  return v1388_13;
}

static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1394_12_result;
  for (int v1394_12_label = 1; v1394_12_label <= 2; ++v1394_12_label) {
    const Space v1394_12_tail = child(s0,v1394_12_label);
    if (v1394_12_tail.empty()) continue;
    const Path v1394_12_head{v1394_12_label};
    const Space v1395_2 = singleton(v1394_12_head);
    const Space v1395_3 = intersect(constant_3,v1395_2);
    const Space v1395_4 = (has_head(v1395_3) ? constant_4 : Space{});
    const Space v1395_5 = subtract(constant_2,v1395_4);
    Space v1395_8;
    if (!v1395_5.empty()) {
      const Path v1396_6 = concat_path(p0,v1394_12_head);
      Space v1396_7_result;
      for (int v1396_7_label = 1; v1396_7_label <= 2; ++v1396_7_label) {
        const Space v1396_7_tail = child(v1394_12_tail,v1396_7_label);
        if (v1396_7_tail.empty()) continue;
        const Path v1396_7_head{v1396_7_label};
        const Space v1397_2 = singleton(v1396_7_head);
        const Space v1397_3 = intersect(constant_3,v1397_2);
        const Space v1397_4 = (has_head(v1397_3) ? constant_4 : Space{});
        const Space v1397_5 = subtract(constant_2,v1397_4);
        Space v1397_8;
        if (!v1397_5.empty()) {
          const Path v1398_6 = concat_path(v1396_6,v1396_7_head);
          const Space v1398_7 = routine_180(c, v1398_6, p1, v1396_7_tail);
          v1397_8 = compose(v1397_5,v1398_7);
        }
        const Space v1397_9 = intersect(constant_3,v1397_2);
        const Space v1397_10 = (has_head(v1397_9) ? constant_4 : Space{});
        Space v1397_12;
        if (!v1397_10.empty()) {
          const Path v1399_6 = concat_path(v1396_6,v1396_7_head);
          const Space v1399_11 = routine_181(c, v1399_6, p1, v1396_7_tail);
          v1397_12 = compose(v1397_10,v1399_11);
        }
        const Space v1397_13 = unite(v1397_8,v1397_12);
        v1396_7_result = unite(v1396_7_result,v1397_13);
      }
      const Space v1396_7 = std::move(v1396_7_result);
      v1395_8 = compose(v1395_5,v1396_7);
    }
    const Space v1395_9 = intersect(constant_3,v1395_2);
    const Space v1395_10 = (has_head(v1395_9) ? constant_4 : Space{});
    Space v1395_12;
    if (!v1395_10.empty()) {
      const Path v1400_6 = concat_path(p0,v1394_12_head);
      Space v1400_11_result;
      for (int v1400_11_label = 1; v1400_11_label <= 2; ++v1400_11_label) {
        const Space v1400_11_tail = child(v1394_12_tail,v1400_11_label);
        if (v1400_11_tail.empty()) continue;
        const Path v1400_11_head{v1400_11_label};
        const Space v1401_2 = singleton(v1400_11_head);
        const Space v1401_3 = intersect(constant_3,v1401_2);
        const Space v1401_4 = (has_head(v1401_3) ? constant_4 : Space{});
        const Space v1401_5 = subtract(constant_2,v1401_4);
        Space v1401_8;
        if (!v1401_5.empty()) {
          const Path v1402_6 = concat_path(v1400_6,v1400_11_head);
          const Space v1402_7 = routine_180(c, v1402_6, p1, v1400_11_tail);
          v1401_8 = compose(v1401_5,v1402_7);
        }
        const Space v1401_9 = intersect(constant_3,v1401_2);
        const Space v1401_10 = (has_head(v1401_9) ? constant_4 : Space{});
        Space v1401_12;
        if (!v1401_10.empty()) {
          const Path v1403_6 = concat_path(v1400_6,v1400_11_head);
          const Space v1403_11 = routine_95(c, v1403_6, p1, v1400_11_tail);
          v1401_12 = compose(v1401_10,v1403_11);
        }
        const Space v1401_13 = unite(v1401_8,v1401_12);
        v1400_11_result = unite(v1400_11_result,v1401_13);
      }
      const Space v1400_11 = std::move(v1400_11_result);
      v1395_12 = compose(v1395_10,v1400_11);
    }
    const Space v1395_13 = unite(v1395_8,v1395_12);
    v1394_12_result = unite(v1394_12_result,v1395_13);
  }
  const Space v1394_12 = std::move(v1394_12_result);
  return v1394_12;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1404_9_result;
  for (int v1404_9_label = 1; v1404_9_label <= 2; ++v1404_9_label) {
    const Space v1404_9_tail = child(s0,v1404_9_label);
    if (v1404_9_tail.empty()) continue;
    const Path v1404_9_head{v1404_9_label};
    const Space v1405_2 = singleton(v1404_9_head);
    const Space v1405_3 = intersect(constant_3,v1405_2);
    const Space v1405_4 = (has_head(v1405_3) ? constant_4 : Space{});
    const Space v1405_5 = subtract(constant_2,v1405_4);
    Space v1405_8;
    if (!v1405_5.empty()) {
      const Path v1406_6 = concat_path(p0,v1404_9_head);
      Space v1406_7_result;
      for (int v1406_7_label = 1; v1406_7_label <= 2; ++v1406_7_label) {
        const Space v1406_7_tail = child(v1404_9_tail,v1406_7_label);
        if (v1406_7_tail.empty()) continue;
        const Path v1406_7_head{v1406_7_label};
        const Space v1407_2 = singleton(v1406_7_head);
        const Space v1407_3 = intersect(constant_3,v1407_2);
        const Space v1407_4 = (has_head(v1407_3) ? constant_4 : Space{});
        const Space v1407_5 = subtract(constant_2,v1407_4);
        Space v1407_8;
        if (!v1407_5.empty()) {
          const Path v1408_6 = concat_path(v1406_6,v1406_7_head);
          const Space v1408_7 = routine_180(c, v1408_6, p1, v1406_7_tail);
          v1407_8 = compose(v1407_5,v1408_7);
        }
        const Space v1407_9 = intersect(constant_3,v1407_2);
        const Space v1407_10 = (has_head(v1407_9) ? constant_4 : Space{});
        Space v1407_12;
        if (!v1407_10.empty()) {
          const Path v1409_6 = concat_path(v1406_6,v1406_7_head);
          const Space v1409_11 = routine_181(c, v1409_6, p1, v1406_7_tail);
          v1407_12 = compose(v1407_10,v1409_11);
        }
        const Space v1407_13 = unite(v1407_8,v1407_12);
        v1406_7_result = unite(v1406_7_result,v1407_13);
      }
      const Space v1406_7 = std::move(v1406_7_result);
      v1405_8 = compose(v1405_5,v1406_7);
    }
    const Space v1405_9 = intersect(constant_3,v1405_2);
    const Space v1405_10 = (has_head(v1405_9) ? constant_4 : Space{});
    const Space v1405_11 = compose(v1405_10,v1404_9_tail);
    const Path v1410_6 = concat_path(p0,v1404_9_head);
    const Space v1405_12 = wrap(v1405_11,v1410_6);
    const Space v1405_13 = wrap(v1405_12,p1);
    const Space v1405_14 = unite(v1405_8,v1405_13);
    v1404_9_result = unite(v1404_9_result,v1405_14);
  }
  const Space v1404_9 = std::move(v1404_9_result);
  return v1404_9;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1411_5_result;
  for (int v1411_5_label = 1; v1411_5_label <= 2; ++v1411_5_label) {
    const Space v1411_5_tail = child(s0,v1411_5_label);
    if (v1411_5_tail.empty()) continue;
    const Path v1411_5_head{v1411_5_label};
    const Space v1412_2 = singleton(v1411_5_head);
    const Space v1412_3 = intersect(constant_3,v1412_2);
    const Space v1412_4 = (has_head(v1412_3) ? constant_4 : Space{});
    Space v1412_7;
    if (!v1412_4.empty()) {
      const Path v1413_5 = concat_path(p0,v1411_5_head);
      Space v1413_6_result;
      for (int v1413_6_label = 1; v1413_6_label <= 2; ++v1413_6_label) {
        const Space v1413_6_tail = child(v1411_5_tail,v1413_6_label);
        if (v1413_6_tail.empty()) continue;
        const Path v1413_6_head{v1413_6_label};
        const Space v1414_2 = singleton(v1413_6_head);
        const Space v1414_3 = intersect(constant_3,v1414_2);
        const Space v1414_4 = (has_head(v1414_3) ? constant_4 : Space{});
        Space v1414_7;
        if (!v1414_4.empty()) {
          const Path v1415_5 = concat_path(v1413_5,v1413_6_head);
          const Space v1415_6 = routine_67(c, v1415_5, p1, v1413_6_tail);
          v1414_7 = compose(v1414_4,v1415_6);
        }
        v1413_6_result = unite(v1413_6_result,v1414_7);
      }
      const Space v1413_6 = std::move(v1413_6_result);
      v1412_7 = compose(v1412_4,v1413_6);
    }
    v1411_5_result = unite(v1411_5_result,v1412_7);
  }
  const Space v1411_5 = std::move(v1411_5_result);
  return v1411_5;
}

static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1416_4_result;
  for (int v1416_4_label = 1; v1416_4_label <= 2; ++v1416_4_label) {
    const Space v1416_4_tail = child(s0,v1416_4_label);
    if (v1416_4_tail.empty()) continue;
    const Path v1416_4_head{v1416_4_label};
    const Space v1417_2 = singleton(v1416_4_head);
    const Space v1417_3 = intersect(constant_3,v1417_2);
    const Space v1417_4 = (has_head(v1417_3) ? constant_4 : Space{});
    const Space v1417_5 = compose(v1417_4,v1416_4_tail);
    const Path v1417_6 = concat_path(p0,v1416_4_head);
    const Space v1417_7 = wrap(v1417_5,v1417_6);
    v1416_4_result = unite(v1416_4_result,v1417_7);
  }
  const Space v1416_4 = std::move(v1416_4_result);
  const Space v1416_5 = wrap(v1416_4,p1);
  return v1416_5;
}

static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1418_3 = Space{};
  return v1418_3;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1419_4_result;
  for (int v1419_4_label = 1; v1419_4_label <= 2; ++v1419_4_label) {
    const Space v1419_4_tail = child(s0,v1419_4_label);
    if (v1419_4_tail.empty()) continue;
    const Path v1419_4_head{v1419_4_label};
    const Space v1420_2 = singleton(v1419_4_head);
    const Space v1420_3 = intersect(constant_3,v1420_2);
    const Space v1420_4 = (has_head(v1420_3) ? constant_4 : Space{});
    const Space v1420_5 = compose(v1420_4,v1419_4_tail);
    const Path v1420_6 = concat_path(p0,v1419_4_head);
    const Space v1420_7 = wrap(v1420_5,v1420_6);
    v1419_4_result = unite(v1419_4_result,v1420_7);
  }
  const Space v1419_4 = std::move(v1419_4_result);
  const Space v1419_5 = wrap(v1419_4,p1);
  return v1419_5;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1421_5_result;
  for (int v1421_5_label = 1; v1421_5_label <= 2; ++v1421_5_label) {
    const Space v1421_5_tail = child(s0,v1421_5_label);
    if (v1421_5_tail.empty()) continue;
    const Path v1421_5_head{v1421_5_label};
    const Space v1422_2 = singleton(v1421_5_head);
    const Space v1422_3 = intersect(constant_3,v1422_2);
    const Space v1422_4 = (has_head(v1422_3) ? constant_4 : Space{});
    Space v1422_7;
    if (!v1422_4.empty()) {
      const Path v1423_5 = concat_path(p0,v1421_5_head);
      Space v1423_6_result;
      for (int v1423_6_label = 1; v1423_6_label <= 2; ++v1423_6_label) {
        const Space v1423_6_tail = child(v1421_5_tail,v1423_6_label);
        if (v1423_6_tail.empty()) continue;
        const Path v1423_6_head{v1423_6_label};
        const Space v1424_2 = singleton(v1423_6_head);
        const Space v1424_3 = intersect(constant_3,v1424_2);
        const Space v1424_4 = (has_head(v1424_3) ? constant_4 : Space{});
        Space v1424_7;
        if (!v1424_4.empty()) {
          const Path v1425_5 = concat_path(v1423_5,v1423_6_head);
          const Space v1425_6 = routine_84(c, v1425_5, p1, v1423_6_tail);
          v1424_7 = compose(v1424_4,v1425_6);
        }
        v1423_6_result = unite(v1423_6_result,v1424_7);
      }
      const Space v1423_6 = std::move(v1423_6_result);
      v1422_7 = compose(v1422_4,v1423_6);
    }
    v1421_5_result = unite(v1421_5_result,v1422_7);
  }
  const Space v1421_5 = std::move(v1421_5_result);
  return v1421_5;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1426_4_result;
  for (int v1426_4_label = 1; v1426_4_label <= 2; ++v1426_4_label) {
    const Space v1426_4_tail = child(s0,v1426_4_label);
    if (v1426_4_tail.empty()) continue;
    const Path v1426_4_head{v1426_4_label};
    const Space v1427_2 = singleton(v1426_4_head);
    const Space v1427_3 = intersect(constant_3,v1427_2);
    const Space v1427_4 = (has_head(v1427_3) ? constant_4 : Space{});
    const Space v1427_5 = compose(v1427_4,v1426_4_tail);
    const Path v1427_6 = concat_path(p0,v1426_4_head);
    const Space v1427_7 = wrap(v1427_5,v1427_6);
    v1426_4_result = unite(v1426_4_result,v1427_7);
  }
  const Space v1426_4 = std::move(v1426_4_result);
  const Space v1426_5 = wrap(v1426_4,p1);
  return v1426_5;
}

static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1428_3 = Space{};
  return v1428_3;
}

static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1429_4_result;
  for (int v1429_4_label = 1; v1429_4_label <= 2; ++v1429_4_label) {
    const Space v1429_4_tail = child(s0,v1429_4_label);
    if (v1429_4_tail.empty()) continue;
    const Path v1429_4_head{v1429_4_label};
    const Space v1430_2 = singleton(v1429_4_head);
    const Space v1430_3 = intersect(constant_3,v1430_2);
    const Space v1430_4 = (has_head(v1430_3) ? constant_4 : Space{});
    const Space v1430_5 = compose(v1430_4,v1429_4_tail);
    const Path v1430_6 = concat_path(p0,v1429_4_head);
    const Space v1430_7 = wrap(v1430_5,v1430_6);
    v1429_4_result = unite(v1429_4_result,v1430_7);
  }
  const Space v1429_4 = std::move(v1429_4_result);
  const Space v1429_5 = wrap(v1429_4,p1);
  return v1429_5;
}

static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1431_5_result;
  for (int v1431_5_label = 1; v1431_5_label <= 2; ++v1431_5_label) {
    const Space v1431_5_tail = child(s0,v1431_5_label);
    if (v1431_5_tail.empty()) continue;
    const Path v1431_5_head{v1431_5_label};
    const Space v1432_2 = singleton(v1431_5_head);
    const Space v1432_3 = intersect(constant_3,v1432_2);
    const Space v1432_4 = (has_head(v1432_3) ? constant_4 : Space{});
    Space v1432_7;
    if (!v1432_4.empty()) {
      const Path v1433_5 = concat_path(p0,v1431_5_head);
      Space v1433_6_result;
      for (int v1433_6_label = 1; v1433_6_label <= 2; ++v1433_6_label) {
        const Space v1433_6_tail = child(v1431_5_tail,v1433_6_label);
        if (v1433_6_tail.empty()) continue;
        const Path v1433_6_head{v1433_6_label};
        const Space v1434_2 = singleton(v1433_6_head);
        const Space v1434_3 = intersect(constant_3,v1434_2);
        const Space v1434_4 = (has_head(v1434_3) ? constant_4 : Space{});
        Space v1434_7;
        if (!v1434_4.empty()) {
          const Path v1435_5 = concat_path(v1433_5,v1433_6_head);
          const Space v1435_6 = routine_95(c, v1435_5, p1, v1433_6_tail);
          v1434_7 = compose(v1434_4,v1435_6);
        }
        v1433_6_result = unite(v1433_6_result,v1434_7);
      }
      const Space v1433_6 = std::move(v1433_6_result);
      v1432_7 = compose(v1432_4,v1433_6);
    }
    v1431_5_result = unite(v1431_5_result,v1432_7);
  }
  const Space v1431_5 = std::move(v1431_5_result);
  return v1431_5;
}

static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1436_4_result;
  for (int v1436_4_label = 1; v1436_4_label <= 2; ++v1436_4_label) {
    const Space v1436_4_tail = child(s0,v1436_4_label);
    if (v1436_4_tail.empty()) continue;
    const Path v1436_4_head{v1436_4_label};
    const Space v1437_2 = singleton(v1436_4_head);
    const Space v1437_3 = intersect(constant_3,v1437_2);
    const Space v1437_4 = (has_head(v1437_3) ? constant_4 : Space{});
    const Space v1437_5 = compose(v1437_4,v1436_4_tail);
    const Path v1437_6 = concat_path(p0,v1436_4_head);
    const Space v1437_7 = wrap(v1437_5,v1437_6);
    v1436_4_result = unite(v1436_4_result,v1437_7);
  }
  const Space v1436_4 = std::move(v1436_4_result);
  const Space v1436_5 = wrap(v1436_4,p1);
  return v1436_5;
}

static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1438_3 = Space{};
  return v1438_3;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1439_4_result;
  for (int v1439_4_label = 1; v1439_4_label <= 2; ++v1439_4_label) {
    const Space v1439_4_tail = child(s0,v1439_4_label);
    if (v1439_4_tail.empty()) continue;
    const Path v1439_4_head{v1439_4_label};
    const Space v1440_2 = singleton(v1439_4_head);
    const Space v1440_3 = intersect(constant_3,v1440_2);
    const Space v1440_4 = (has_head(v1440_3) ? constant_4 : Space{});
    const Space v1440_5 = compose(v1440_4,v1439_4_tail);
    const Path v1440_6 = concat_path(p0,v1439_4_head);
    const Space v1440_7 = wrap(v1440_5,v1440_6);
    v1439_4_result = unite(v1439_4_result,v1440_7);
  }
  const Space v1439_4 = std::move(v1439_4_result);
  const Space v1439_5 = wrap(v1439_4,p1);
  return v1439_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
