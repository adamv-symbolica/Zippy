#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1};
static const Path constant_1 = Path{2};
static const Space constant_2 = literal_text("1 0 ");
static const Path constant_3 = Path{3};
static const Path constant_4 = Path{4};
static const Path constant_5 = Path{1,3};
static const Path constant_6 = Path{4,3};
static Space routine_0(Context& c, const Space* s0);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = wrap(bound_space(s0),constant_0);
  const Space v0_4 = unwrap(bound_space(s0),constant_1);
  const auto v0_6_branches = branches(c,v0_4);
  std::vector<Space> v0_6_outputs;
  v0_6_outputs.reserve(v0_6_branches.size());
  for (const auto& v0_6_branch : v0_6_branches) {
    const Path v0_6_head{v0_6_branch.first};
    const Space& v0_6_tail = v0_6_branch.second;
    const Space v1_2 = subtract(v0_6_tail,constant_2);
    const Space v1_3 = wrap(v1_2,v0_6_head);
    v0_6_outputs.push_back(v1_3);
  }
  const Space v0_6 = join_outputs(std::move(v0_6_outputs));
  const Space v0_8 = wrap(v0_6,constant_3);
  const Space v0_10 = wrap(v0_8,constant_4);
  const Space v0_11 = unite(v0_2,v0_10);
  Space v0_18 = v0_11;
  for (;;) {
    const Space v2_1 = unwrap(v0_18,constant_0);
    const Space v2_2 = unwrap(v0_18,constant_4);
    const Space v2_3 = unite(v2_1,v2_2);
    const Space v2_4 = wrap(v2_3,constant_0);
    const Space v2_5 = unwrap(v2_1,constant_1);
    const auto v2_6_branches = branches(c,v2_5);
    std::vector<Space> v2_6_outputs;
    v2_6_outputs.reserve(v2_6_branches.size());
    for (const auto& v2_6_branch : v2_6_branches) {
      const Path v2_6_head{v2_6_branch.first};
      const Space& v2_6_tail = v2_6_branch.second;
      const Space v3_2 = subtract(v2_6_tail,constant_2);
      const Space v3_3 = wrap(v3_2,v2_6_head);
      v2_6_outputs.push_back(v3_3);
    }
    const Space v2_6 = join_outputs(std::move(v2_6_outputs));
    const Space v2_7 = unwrap(v2_1,constant_3);
    const Space v2_8 = unwrap(v2_2,constant_3);
    const auto v2_9_branches = branches(c,v2_7);
    std::vector<Space> v2_9_outputs;
    v2_9_outputs.reserve(v2_9_branches.size());
    for (const auto& v2_9_branch : v2_9_branches) {
      const Path v2_9_head{v2_9_branch.first};
      const Space& v2_9_tail = v2_9_branch.second;
      const auto v4_2_branches = branches(c,v2_9_tail);
      std::vector<Space> v4_2_outputs;
      v4_2_outputs.reserve(v4_2_branches.size());
      for (const auto& v4_2_branch : v4_2_branches) {
        const Path v4_2_head{v4_2_branch.first};
        const Space& v4_2_tail = v4_2_branch.second;
        const Space v5_2 = unwrap(v2_8,v4_2_head);
        const Space v5_3 = subtract(v5_2,constant_2);
        v4_2_outputs.push_back(v5_3);
      }
      const Space v4_2 = join_outputs(std::move(v4_2_outputs));
      const Space v4_3 = wrap(v4_2,v2_9_head);
      v2_9_outputs.push_back(v4_3);
    }
    const Space v2_9 = join_outputs(std::move(v2_9_outputs));
    const Space v2_10 = unite(v2_6,v2_9);
    const auto v2_11_branches = branches(c,v2_8);
    std::vector<Space> v2_11_outputs;
    v2_11_outputs.reserve(v2_11_branches.size());
    for (const auto& v2_11_branch : v2_11_branches) {
      const Path v2_11_head{v2_11_branch.first};
      const Space& v2_11_tail = v2_11_branch.second;
      const auto v6_2_branches = branches(c,v2_11_tail);
      std::vector<Space> v6_2_outputs;
      v6_2_outputs.reserve(v6_2_branches.size());
      for (const auto& v6_2_branch : v6_2_branches) {
        const Path v6_2_head{v6_2_branch.first};
        const Space& v6_2_tail = v6_2_branch.second;
        const Space v7_2 = unwrap(v2_7,v6_2_head);
        const Space v7_3 = subtract(v7_2,constant_2);
        v6_2_outputs.push_back(v7_3);
      }
      const Space v6_2 = join_outputs(std::move(v6_2_outputs));
      const Space v6_3 = wrap(v6_2,v2_11_head);
      v2_11_outputs.push_back(v6_3);
    }
    const Space v2_11 = join_outputs(std::move(v2_11_outputs));
    const Space v2_12 = unite(v2_10,v2_11);
    const auto v2_13_branches = branches(c,v2_8);
    std::vector<Space> v2_13_outputs;
    v2_13_outputs.reserve(v2_13_branches.size());
    for (const auto& v2_13_branch : v2_13_branches) {
      const Path v2_13_head{v2_13_branch.first};
      const Space& v2_13_tail = v2_13_branch.second;
      const auto v8_2_branches = branches(c,v2_13_tail);
      std::vector<Space> v8_2_outputs;
      v8_2_outputs.reserve(v8_2_branches.size());
      for (const auto& v8_2_branch : v8_2_branches) {
        const Path v8_2_head{v8_2_branch.first};
        const Space& v8_2_tail = v8_2_branch.second;
        const Space v9_2 = unwrap(v2_8,v8_2_head);
        const Space v9_3 = subtract(v9_2,constant_2);
        v8_2_outputs.push_back(v9_3);
      }
      const Space v8_2 = join_outputs(std::move(v8_2_outputs));
      const Space v8_3 = wrap(v8_2,v2_13_head);
      v2_13_outputs.push_back(v8_3);
    }
    const Space v2_13 = join_outputs(std::move(v2_13_outputs));
    const Space v2_14 = unite(v2_12,v2_13);
    const Space v2_15 = unwrap(v0_18,constant_5);
    const Space v2_16 = subtract(v2_14,v2_15);
    const Space v2_17 = unwrap(v0_18,constant_6);
    const Space v2_18 = subtract(v2_16,v2_17);
    const Space v2_19 = wrap(v2_18,constant_6);
    const Space v2_20 = unite(v2_4,v2_19);
    const Space v2_21 = unite(v2_20,v0_18);
    Space v0_18_next = unite(v0_18,v2_21);
    if (equal(v0_18_next,v0_18)) break;
    v0_18 = std::move(v0_18_next);
  }
  const Space v0_19 = unwrap(v0_18,constant_5);
  return v0_19;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"4 1 8 99 111 109 112 108 101 116 101 2 4 101 100 103 101 3 4 112 97 116 104 4 5 100 101 108 116 97"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
