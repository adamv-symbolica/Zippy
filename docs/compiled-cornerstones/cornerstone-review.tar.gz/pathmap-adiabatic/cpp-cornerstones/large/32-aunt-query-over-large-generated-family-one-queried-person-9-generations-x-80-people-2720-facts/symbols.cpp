#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1};
static const Path constant_1 = Path{2};
static const Path constant_2 = Path{3};
static const Path constant_3 = Path{4};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  const Space v0_3 = unwrap(bound_space(s0),constant_0);
  const Space v0_5 = unwrap(bound_space(s0),constant_1);
  const Space v0_7 = unwrap(bound_space(s0),constant_2);
  const auto v0_8_branches = branches(c,bound_space(s1));
  std::vector<Space> v0_8_outputs;
  v0_8_outputs.reserve(v0_8_branches.size());
  for (const auto& v0_8_branch : v0_8_branches) {
    const Path v0_8_head{v0_8_branch.first};
    const Space& v0_8_tail = v0_8_branch.second;
    const Space v1_2 = unwrap(v0_5,v0_8_head);
    const Space v1_3 = restrict_to(v0_5,v1_2);
    const Space v1_4 = tails_union(v1_3);
    const Space v1_5 = restrict_to(v0_3,v1_4);
    const Space v1_6 = tails_union(v1_5);
    const Space v1_7 = subtract(v1_6,v1_2);
    const Space v1_8 = intersect(v1_7,v0_7);
    const Space v1_9 = wrap(v1_8,v0_8_head);
    v0_8_outputs.push_back(v1_9);
  }
  const Space v0_8 = join_outputs(std::move(v0_8_outputs));
  const Space v0_10 = wrap(v0_8,constant_3);
  return v0_10;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"4 1 6 112 97 114 101 110 116 2 5 99 104 105 108 100 3 6 102 101 109 97 108 101 4 4 65 117 110 116"); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
