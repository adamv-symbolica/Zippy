#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static Space routine_0(Context& c, const Space* s0, const Space* s1, const Space* s2);
static Space routine_0(Context& c, const Space* s0, const Space* s1, const Space* s2) {
  const Space v0_3 = compose(bound_space(s0),bound_space(s1));
  const Space v0_4 = restrict_to(v0_3,bound_space(s2));
  return v0_4;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1),space_arg(e,2)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
