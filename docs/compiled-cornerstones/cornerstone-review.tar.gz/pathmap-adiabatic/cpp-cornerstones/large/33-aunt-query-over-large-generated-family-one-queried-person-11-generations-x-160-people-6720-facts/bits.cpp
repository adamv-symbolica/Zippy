#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{2,1,2,1,1,1,2,1,1,1,2,1,1,1,1,2,2};
static const Path constant_4 = Path{2,1,1,1,1,1,2,1,1,1,2,1,1,1,1,2,2};
static const Path constant_5 = Path{1,1,2,1,1,1,2,1,1,1,2,1,1,1,1,2,2};
static const Path constant_6 = Path{2,2};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_61(Context& c, const Path& p0, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_82(Context& c, const Path& p0, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Space& s0);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_46(Context& c, const Path& p0, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  Space v0_5_result;
  for (int v0_5_label = 1; v0_5_label <= 2; ++v0_5_label) {
    const Space v0_5_tail = child(bound_space(s1),v0_5_label);
    if (v0_5_tail.empty()) continue;
    const Path v0_5_head{v0_5_label};
    const Space v1_2 = singleton(v0_5_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_5_result = unite(v0_5_result,v1_12);
  }
  const Space v0_5 = std::move(v0_5_result);
  const Space v0_7 = wrap(v0_5,constant_3);
  return v0_7;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v4_12_result;
  for (int v4_12_label = 1; v4_12_label <= 2; ++v4_12_label) {
    const Space v4_12_tail = child(s0,v4_12_label);
    if (v4_12_tail.empty()) continue;
    const Path v4_12_head{v4_12_label};
    const Space v5_2 = singleton(v4_12_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_12_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_12_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail, s1);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail, s1);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_12_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_12_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail, s1);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail, s1);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_12_result = unite(v4_12_result,v5_13);
  }
  const Space v4_12 = std::move(v4_12_result);
  return v4_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v14_7 = unwrap(s1,constant_4);
  const Space v14_9 = unwrap(s1,constant_5);
  const Space v14_10 = unwrap(v14_9,p0);
  const Space v14_12 = unwrap(s1,constant_6);
  Space v14_22_result;
  for (int v14_22_label = 1; v14_22_label <= 2; ++v14_22_label) {
    const Space v14_22_tail = child(s0,v14_22_label);
    if (v14_22_tail.empty()) continue;
    const Path v14_22_head{v14_22_label};
    const Space v15_2 = singleton(v14_22_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_22_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_22_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_18;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_10,v14_22_head);
      const Space v20_12 = restrict_to(v14_9,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(v14_7,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = subtract(v20_15,v20_11);
      const Space v20_17 = intersect(v20_16,v14_12);
      v15_18 = compose(v15_10,v20_17);
    }
    const Path v27_6 = concat_path(p0,v14_22_head);
    const Space v15_19 = wrap(v15_18,v27_6);
    const Space v15_20 = unite(v15_8,v15_19);
    v14_22_result = unite(v14_22_result,v15_20);
  }
  const Space v14_22 = std::move(v14_22_result);
  return v14_22;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v28_12_result;
  for (int v28_12_label = 1; v28_12_label <= 2; ++v28_12_label) {
    const Space v28_12_tail = child(s0,v28_12_label);
    if (v28_12_tail.empty()) continue;
    const Path v28_12_head{v28_12_label};
    const Space v29_2 = singleton(v28_12_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_12_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_12_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail, s1);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail, s1);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_12_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_12_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail, s1);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail, s1);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_12_result = unite(v28_12_result,v29_13);
  }
  const Space v28_12 = std::move(v28_12_result);
  return v28_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v38_7 = unwrap(s1,constant_4);
  const Space v38_9 = unwrap(s1,constant_5);
  const Space v38_10 = unwrap(v38_9,p0);
  const Space v38_12 = unwrap(s1,constant_6);
  Space v38_22_result;
  for (int v38_22_label = 1; v38_22_label <= 2; ++v38_22_label) {
    const Space v38_22_tail = child(s0,v38_22_label);
    if (v38_22_tail.empty()) continue;
    const Path v38_22_head{v38_22_label};
    const Space v39_2 = singleton(v38_22_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_22_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_22_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail, s1);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail, s1);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_18;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_10,v38_22_head);
      const Space v44_12 = restrict_to(v38_9,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(v38_7,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = subtract(v44_15,v44_11);
      const Space v44_17 = intersect(v44_16,v38_12);
      v39_18 = compose(v39_10,v44_17);
    }
    const Path v51_6 = concat_path(p0,v38_22_head);
    const Space v39_19 = wrap(v39_18,v51_6);
    const Space v39_20 = unite(v39_8,v39_19);
    v38_22_result = unite(v38_22_result,v39_20);
  }
  const Space v38_22 = std::move(v38_22_result);
  return v38_22;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v52_4 = unwrap(s1,constant_4);
  const Space v52_6 = unwrap(s1,constant_5);
  const Space v52_7 = unwrap(v52_6,p0);
  const Space v52_8 = restrict_to(v52_6,v52_7);
  Space v52_18_result;
  for (int v52_18_label = 1; v52_18_label <= 2; ++v52_18_label) {
    const Space v52_18_tail = child(v52_8,v52_18_label);
    if (v52_18_tail.empty()) continue;
    const Path v52_18_head{v52_18_label};
    const Space v53_2 = singleton(v52_18_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_18_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_18_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_18_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_18_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_18_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_18_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_18_result = unite(v52_18_result,v53_12);
  }
  const Space v52_18 = std::move(v52_18_result);
  const Space v52_19 = restrict_to(v52_4,v52_18);
  Space v52_29_result;
  for (int v52_29_label = 1; v52_29_label <= 2; ++v52_29_label) {
    const Space v52_29_tail = child(v52_19,v52_29_label);
    if (v52_29_tail.empty()) continue;
    const Path v52_29_head{v52_29_label};
    const Space v62_2 = singleton(v52_29_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_29_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_29_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_29_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_29_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_29_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_29_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_29_result = unite(v52_29_result,v62_12);
  }
  const Space v52_29 = std::move(v52_29_result);
  const Space v52_30 = subtract(v52_29,v52_7);
  const Space v52_32 = unwrap(s1,constant_6);
  const Space v52_33 = intersect(v52_30,v52_32);
  const Space v52_34 = wrap(v52_33,p0);
  return v52_34;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v103_12_result;
  for (int v103_12_label = 1; v103_12_label <= 2; ++v103_12_label) {
    const Space v103_12_tail = child(s0,v103_12_label);
    if (v103_12_tail.empty()) continue;
    const Path v103_12_head{v103_12_label};
    const Space v104_2 = singleton(v103_12_head);
    const Space v104_3 = intersect(constant_1,v104_2);
    const Space v104_4 = (has_head(v104_3) ? constant_2 : Space{});
    const Space v104_5 = subtract(constant_0,v104_4);
    Space v104_8;
    if (!v104_5.empty()) {
      const Path v105_6 = concat_path(p0,v103_12_head);
      Space v105_7_result;
      for (int v105_7_label = 1; v105_7_label <= 2; ++v105_7_label) {
        const Space v105_7_tail = child(v103_12_tail,v105_7_label);
        if (v105_7_tail.empty()) continue;
        const Path v105_7_head{v105_7_label};
        const Space v106_2 = singleton(v105_7_head);
        const Space v106_3 = intersect(constant_1,v106_2);
        const Space v106_4 = (has_head(v106_3) ? constant_2 : Space{});
        const Space v106_5 = subtract(constant_0,v106_4);
        Space v106_8;
        if (!v106_5.empty()) {
          const Path v107_6 = concat_path(v105_6,v105_7_head);
          const Space v107_7 = routine_22(c, v107_6, v105_7_tail, s1);
          v106_8 = compose(v106_5,v107_7);
        }
        const Space v106_9 = intersect(constant_1,v106_2);
        const Space v106_10 = (has_head(v106_9) ? constant_2 : Space{});
        Space v106_12;
        if (!v106_10.empty()) {
          const Path v108_6 = concat_path(v105_6,v105_7_head);
          const Space v108_11 = routine_23(c, v108_6, v105_7_tail, s1);
          v106_12 = compose(v106_10,v108_11);
        }
        const Space v106_13 = unite(v106_8,v106_12);
        v105_7_result = unite(v105_7_result,v106_13);
      }
      const Space v105_7 = std::move(v105_7_result);
      v104_8 = compose(v104_5,v105_7);
    }
    const Space v104_9 = intersect(constant_1,v104_2);
    const Space v104_10 = (has_head(v104_9) ? constant_2 : Space{});
    Space v104_12;
    if (!v104_10.empty()) {
      const Path v109_6 = concat_path(p0,v103_12_head);
      Space v109_11_result;
      for (int v109_11_label = 1; v109_11_label <= 2; ++v109_11_label) {
        const Space v109_11_tail = child(v103_12_tail,v109_11_label);
        if (v109_11_tail.empty()) continue;
        const Path v109_11_head{v109_11_label};
        const Space v110_2 = singleton(v109_11_head);
        const Space v110_3 = intersect(constant_1,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_2 : Space{});
        const Space v110_5 = subtract(constant_0,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_11_head);
          const Space v111_7 = routine_22(c, v111_6, v109_11_tail, s1);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_1,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_2 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_11_head);
          const Space v112_11 = routine_5(c, v112_6, v109_11_tail, s1);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_11_result = unite(v109_11_result,v110_13);
      }
      const Space v109_11 = std::move(v109_11_result);
      v104_12 = compose(v104_10,v109_11);
    }
    const Space v104_13 = unite(v104_8,v104_12);
    v103_12_result = unite(v103_12_result,v104_13);
  }
  const Space v103_12 = std::move(v103_12_result);
  return v103_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v113_7 = unwrap(s1,constant_4);
  const Space v113_9 = unwrap(s1,constant_5);
  const Space v113_10 = unwrap(v113_9,p0);
  const Space v113_12 = unwrap(s1,constant_6);
  Space v113_22_result;
  for (int v113_22_label = 1; v113_22_label <= 2; ++v113_22_label) {
    const Space v113_22_tail = child(s0,v113_22_label);
    if (v113_22_tail.empty()) continue;
    const Path v113_22_head{v113_22_label};
    const Space v114_2 = singleton(v113_22_head);
    const Space v114_3 = intersect(constant_1,v114_2);
    const Space v114_4 = (has_head(v114_3) ? constant_2 : Space{});
    const Space v114_5 = subtract(constant_0,v114_4);
    Space v114_8;
    if (!v114_5.empty()) {
      const Path v115_6 = concat_path(p0,v113_22_head);
      Space v115_7_result;
      for (int v115_7_label = 1; v115_7_label <= 2; ++v115_7_label) {
        const Space v115_7_tail = child(v113_22_tail,v115_7_label);
        if (v115_7_tail.empty()) continue;
        const Path v115_7_head{v115_7_label};
        const Space v116_2 = singleton(v115_7_head);
        const Space v116_3 = intersect(constant_1,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_2 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_8;
        if (!v116_5.empty()) {
          const Path v117_6 = concat_path(v115_6,v115_7_head);
          const Space v117_7 = routine_22(c, v117_6, v115_7_tail, s1);
          v116_8 = compose(v116_5,v117_7);
        }
        const Space v116_9 = intersect(constant_1,v116_2);
        const Space v116_10 = (has_head(v116_9) ? constant_2 : Space{});
        Space v116_12;
        if (!v116_10.empty()) {
          const Path v118_6 = concat_path(v115_6,v115_7_head);
          const Space v118_11 = routine_23(c, v118_6, v115_7_tail, s1);
          v116_12 = compose(v116_10,v118_11);
        }
        const Space v116_13 = unite(v116_8,v116_12);
        v115_7_result = unite(v115_7_result,v116_13);
      }
      const Space v115_7 = std::move(v115_7_result);
      v114_8 = compose(v114_5,v115_7);
    }
    const Space v114_9 = intersect(constant_1,v114_2);
    const Space v114_10 = (has_head(v114_9) ? constant_2 : Space{});
    Space v114_18;
    if (!v114_10.empty()) {
      const Space v119_11 = unwrap(v113_10,v113_22_head);
      const Space v119_12 = restrict_to(v113_9,v119_11);
      Space v119_13_result;
      for (int v119_13_label = 1; v119_13_label <= 2; ++v119_13_label) {
        const Space v119_13_tail = child(v119_12,v119_13_label);
        if (v119_13_tail.empty()) continue;
        const Path v119_13_head{v119_13_label};
        const Space v120_2 = singleton(v119_13_head);
        const Space v120_3 = intersect(constant_1,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
        const Space v120_5 = subtract(constant_0,v120_4);
        Space v120_7;
        if (!v120_5.empty()) {
          const Space v121_6 = routine_6(c, v119_13_head, v119_13_tail);
          v120_7 = compose(v120_5,v121_6);
        }
        const Space v120_8 = intersect(constant_1,v120_2);
        const Space v120_9 = (has_head(v120_8) ? constant_2 : Space{});
        Space v120_11;
        if (!v120_9.empty()) {
          const Space v122_10 = routine_7(c, v119_13_head, v119_13_tail);
          v120_11 = compose(v120_9,v122_10);
        }
        const Space v120_12 = unite(v120_7,v120_11);
        v119_13_result = unite(v119_13_result,v120_12);
      }
      const Space v119_13 = std::move(v119_13_result);
      const Space v119_14 = restrict_to(v113_7,v119_13);
      Space v119_15_result;
      for (int v119_15_label = 1; v119_15_label <= 2; ++v119_15_label) {
        const Space v119_15_tail = child(v119_14,v119_15_label);
        if (v119_15_tail.empty()) continue;
        const Path v119_15_head{v119_15_label};
        const Space v123_2 = singleton(v119_15_head);
        const Space v123_3 = intersect(constant_1,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_2 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_7;
        if (!v123_5.empty()) {
          const Space v124_6 = routine_8(c, v119_15_head, v119_15_tail);
          v123_7 = compose(v123_5,v124_6);
        }
        const Space v123_8 = intersect(constant_1,v123_2);
        const Space v123_9 = (has_head(v123_8) ? constant_2 : Space{});
        Space v123_11;
        if (!v123_9.empty()) {
          const Space v125_10 = routine_9(c, v119_15_head, v119_15_tail);
          v123_11 = compose(v123_9,v125_10);
        }
        const Space v123_12 = unite(v123_7,v123_11);
        v119_15_result = unite(v119_15_result,v123_12);
      }
      const Space v119_15 = std::move(v119_15_result);
      const Space v119_16 = subtract(v119_15,v119_11);
      const Space v119_17 = intersect(v119_16,v113_12);
      v114_18 = compose(v114_10,v119_17);
    }
    const Path v126_6 = concat_path(p0,v113_22_head);
    const Space v114_19 = wrap(v114_18,v126_6);
    const Space v114_20 = unite(v114_8,v114_19);
    v113_22_result = unite(v113_22_result,v114_20);
  }
  const Space v113_22 = std::move(v113_22_result);
  return v113_22;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v127_11_result;
  for (int v127_11_label = 1; v127_11_label <= 2; ++v127_11_label) {
    const Space v127_11_tail = child(s0,v127_11_label);
    if (v127_11_tail.empty()) continue;
    const Path v127_11_head{v127_11_label};
    const Space v128_2 = singleton(v127_11_head);
    const Space v128_3 = intersect(constant_1,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_2 : Space{});
    const Space v128_5 = subtract(constant_0,v128_4);
    Space v128_8;
    if (!v128_5.empty()) {
      const Path v129_6 = concat_path(p0,v127_11_head);
      Space v129_7_result;
      for (int v129_7_label = 1; v129_7_label <= 2; ++v129_7_label) {
        const Space v129_7_tail = child(v127_11_tail,v129_7_label);
        if (v129_7_tail.empty()) continue;
        const Path v129_7_head{v129_7_label};
        const Space v130_2 = singleton(v129_7_head);
        const Space v130_3 = intersect(constant_1,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_2 : Space{});
        const Space v130_5 = subtract(constant_0,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v129_6,v129_7_head);
          const Space v131_7 = routine_24(c, v131_6, v129_7_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_1,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_2 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v129_6,v129_7_head);
          const Space v132_11 = routine_25(c, v132_6, v129_7_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_7_result = unite(v129_7_result,v130_13);
      }
      const Space v129_7 = std::move(v129_7_result);
      v128_8 = compose(v128_5,v129_7);
    }
    const Space v128_9 = intersect(constant_1,v128_2);
    const Space v128_10 = (has_head(v128_9) ? constant_2 : Space{});
    Space v128_12;
    if (!v128_10.empty()) {
      const Path v133_6 = concat_path(p0,v127_11_head);
      Space v133_11_result;
      for (int v133_11_label = 1; v133_11_label <= 2; ++v133_11_label) {
        const Space v133_11_tail = child(v127_11_tail,v133_11_label);
        if (v133_11_tail.empty()) continue;
        const Path v133_11_head{v133_11_label};
        const Space v134_2 = singleton(v133_11_head);
        const Space v134_3 = intersect(constant_1,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_2 : Space{});
        const Space v134_5 = subtract(constant_0,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v133_6,v133_11_head);
          const Space v135_7 = routine_24(c, v135_6, v133_11_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_1,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_2 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v133_6,v133_11_head);
          const Space v136_11 = routine_14(c, v136_6, v133_11_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_11_result = unite(v133_11_result,v134_13);
      }
      const Space v133_11 = std::move(v133_11_result);
      v128_12 = compose(v128_10,v133_11);
    }
    const Space v128_13 = unite(v128_8,v128_12);
    v127_11_result = unite(v127_11_result,v128_13);
  }
  const Space v127_11 = std::move(v127_11_result);
  return v127_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v137_8_result;
  for (int v137_8_label = 1; v137_8_label <= 2; ++v137_8_label) {
    const Space v137_8_tail = child(s0,v137_8_label);
    if (v137_8_tail.empty()) continue;
    const Path v137_8_head{v137_8_label};
    const Space v138_2 = singleton(v137_8_head);
    const Space v138_3 = intersect(constant_1,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_2 : Space{});
    const Space v138_5 = subtract(constant_0,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_8_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_8_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_1,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_2 : Space{});
        const Space v140_5 = subtract(constant_0,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_24(c, v141_6, v139_7_tail);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_1,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_2 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_25(c, v142_6, v139_7_tail);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_1,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_2 : Space{});
    const Space v138_11 = compose(v138_10,v137_8_tail);
    const Space v138_12 = unite(v138_8,v138_11);
    v137_8_result = unite(v137_8_result,v138_12);
  }
  const Space v137_8 = std::move(v137_8_result);
  return v137_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v144_11_result;
  for (int v144_11_label = 1; v144_11_label <= 2; ++v144_11_label) {
    const Space v144_11_tail = child(s0,v144_11_label);
    if (v144_11_tail.empty()) continue;
    const Path v144_11_head{v144_11_label};
    const Space v145_2 = singleton(v144_11_head);
    const Space v145_3 = intersect(constant_1,v145_2);
    const Space v145_4 = (has_head(v145_3) ? constant_2 : Space{});
    const Space v145_5 = subtract(constant_0,v145_4);
    Space v145_8;
    if (!v145_5.empty()) {
      const Path v146_6 = concat_path(p0,v144_11_head);
      Space v146_7_result;
      for (int v146_7_label = 1; v146_7_label <= 2; ++v146_7_label) {
        const Space v146_7_tail = child(v144_11_tail,v146_7_label);
        if (v146_7_tail.empty()) continue;
        const Path v146_7_head{v146_7_label};
        const Space v147_2 = singleton(v146_7_head);
        const Space v147_3 = intersect(constant_1,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_2 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v146_6,v146_7_head);
          const Space v148_7 = routine_26(c, v148_6, v146_7_tail);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_1,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_2 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v146_6,v146_7_head);
          const Space v149_11 = routine_27(c, v149_6, v146_7_tail);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_7_result = unite(v146_7_result,v147_13);
      }
      const Space v146_7 = std::move(v146_7_result);
      v145_8 = compose(v145_5,v146_7);
    }
    const Space v145_9 = intersect(constant_1,v145_2);
    const Space v145_10 = (has_head(v145_9) ? constant_2 : Space{});
    Space v145_12;
    if (!v145_10.empty()) {
      const Path v150_6 = concat_path(p0,v144_11_head);
      Space v150_11_result;
      for (int v150_11_label = 1; v150_11_label <= 2; ++v150_11_label) {
        const Space v150_11_tail = child(v144_11_tail,v150_11_label);
        if (v150_11_tail.empty()) continue;
        const Path v150_11_head{v150_11_label};
        const Space v151_2 = singleton(v150_11_head);
        const Space v151_3 = intersect(constant_1,v151_2);
        const Space v151_4 = (has_head(v151_3) ? constant_2 : Space{});
        const Space v151_5 = subtract(constant_0,v151_4);
        Space v151_8;
        if (!v151_5.empty()) {
          const Path v152_6 = concat_path(v150_6,v150_11_head);
          const Space v152_7 = routine_26(c, v152_6, v150_11_tail);
          v151_8 = compose(v151_5,v152_7);
        }
        const Space v151_9 = intersect(constant_1,v151_2);
        const Space v151_10 = (has_head(v151_9) ? constant_2 : Space{});
        Space v151_12;
        if (!v151_10.empty()) {
          const Path v153_6 = concat_path(v150_6,v150_11_head);
          const Space v153_11 = routine_17(c, v153_6, v150_11_tail);
          v151_12 = compose(v151_10,v153_11);
        }
        const Space v151_13 = unite(v151_8,v151_12);
        v150_11_result = unite(v150_11_result,v151_13);
      }
      const Space v150_11 = std::move(v150_11_result);
      v145_12 = compose(v145_10,v150_11);
    }
    const Space v145_13 = unite(v145_8,v145_12);
    v144_11_result = unite(v144_11_result,v145_13);
  }
  const Space v144_11 = std::move(v144_11_result);
  return v144_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v154_8_result;
  for (int v154_8_label = 1; v154_8_label <= 2; ++v154_8_label) {
    const Space v154_8_tail = child(s0,v154_8_label);
    if (v154_8_tail.empty()) continue;
    const Path v154_8_head{v154_8_label};
    const Space v155_2 = singleton(v154_8_head);
    const Space v155_3 = intersect(constant_1,v155_2);
    const Space v155_4 = (has_head(v155_3) ? constant_2 : Space{});
    const Space v155_5 = subtract(constant_0,v155_4);
    Space v155_8;
    if (!v155_5.empty()) {
      const Path v156_6 = concat_path(p0,v154_8_head);
      Space v156_7_result;
      for (int v156_7_label = 1; v156_7_label <= 2; ++v156_7_label) {
        const Space v156_7_tail = child(v154_8_tail,v156_7_label);
        if (v156_7_tail.empty()) continue;
        const Path v156_7_head{v156_7_label};
        const Space v157_2 = singleton(v156_7_head);
        const Space v157_3 = intersect(constant_1,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_2 : Space{});
        const Space v157_5 = subtract(constant_0,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_7_head);
          const Space v158_7 = routine_26(c, v158_6, v156_7_tail);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_1,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_2 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_7_head);
          const Space v159_11 = routine_27(c, v159_6, v156_7_tail);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_7_result = unite(v156_7_result,v157_13);
      }
      const Space v156_7 = std::move(v156_7_result);
      v155_8 = compose(v155_5,v156_7);
    }
    const Space v155_9 = intersect(constant_1,v155_2);
    const Space v155_10 = (has_head(v155_9) ? constant_2 : Space{});
    const Space v155_11 = compose(v155_10,v154_8_tail);
    const Space v155_12 = unite(v155_8,v155_11);
    v154_8_result = unite(v154_8_result,v155_12);
  }
  const Space v154_8 = std::move(v154_8_result);
  return v154_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v161_11_result;
  for (int v161_11_label = 1; v161_11_label <= 2; ++v161_11_label) {
    const Space v161_11_tail = child(s0,v161_11_label);
    if (v161_11_tail.empty()) continue;
    const Path v161_11_head{v161_11_label};
    const Space v162_2 = singleton(v161_11_head);
    const Space v162_3 = intersect(constant_1,v162_2);
    const Space v162_4 = (has_head(v162_3) ? constant_2 : Space{});
    const Space v162_5 = subtract(constant_0,v162_4);
    Space v162_8;
    if (!v162_5.empty()) {
      const Path v163_6 = concat_path(p0,v161_11_head);
      Space v163_7_result;
      for (int v163_7_label = 1; v163_7_label <= 2; ++v163_7_label) {
        const Space v163_7_tail = child(v161_11_tail,v163_7_label);
        if (v163_7_tail.empty()) continue;
        const Path v163_7_head{v163_7_label};
        const Space v164_2 = singleton(v163_7_head);
        const Space v164_3 = intersect(constant_1,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
        const Space v164_5 = subtract(constant_0,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v163_6,v163_7_head);
          const Space v165_7 = routine_28(c, v165_6, v163_7_tail);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_1,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v163_6,v163_7_head);
          const Space v166_11 = routine_29(c, v166_6, v163_7_tail);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_7_result = unite(v163_7_result,v164_13);
      }
      const Space v163_7 = std::move(v163_7_result);
      v162_8 = compose(v162_5,v163_7);
    }
    const Space v162_9 = intersect(constant_1,v162_2);
    const Space v162_10 = (has_head(v162_9) ? constant_2 : Space{});
    Space v162_12;
    if (!v162_10.empty()) {
      const Path v167_6 = concat_path(p0,v161_11_head);
      Space v167_11_result;
      for (int v167_11_label = 1; v167_11_label <= 2; ++v167_11_label) {
        const Space v167_11_tail = child(v161_11_tail,v167_11_label);
        if (v167_11_tail.empty()) continue;
        const Path v167_11_head{v167_11_label};
        const Space v168_2 = singleton(v167_11_head);
        const Space v168_3 = intersect(constant_1,v168_2);
        const Space v168_4 = (has_head(v168_3) ? constant_2 : Space{});
        const Space v168_5 = subtract(constant_0,v168_4);
        Space v168_8;
        if (!v168_5.empty()) {
          const Path v169_6 = concat_path(v167_6,v167_11_head);
          const Space v169_7 = routine_28(c, v169_6, v167_11_tail);
          v168_8 = compose(v168_5,v169_7);
        }
        const Space v168_9 = intersect(constant_1,v168_2);
        const Space v168_10 = (has_head(v168_9) ? constant_2 : Space{});
        Space v168_12;
        if (!v168_10.empty()) {
          const Path v170_6 = concat_path(v167_6,v167_11_head);
          const Space v170_11 = routine_14(c, v170_6, v167_11_tail);
          v168_12 = compose(v168_10,v170_11);
        }
        const Space v168_13 = unite(v168_8,v168_12);
        v167_11_result = unite(v167_11_result,v168_13);
      }
      const Space v167_11 = std::move(v167_11_result);
      v162_12 = compose(v162_10,v167_11);
    }
    const Space v162_13 = unite(v162_8,v162_12);
    v161_11_result = unite(v161_11_result,v162_13);
  }
  const Space v161_11 = std::move(v161_11_result);
  return v161_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v171_8_result;
  for (int v171_8_label = 1; v171_8_label <= 2; ++v171_8_label) {
    const Space v171_8_tail = child(s0,v171_8_label);
    if (v171_8_tail.empty()) continue;
    const Path v171_8_head{v171_8_label};
    const Space v172_2 = singleton(v171_8_head);
    const Space v172_3 = intersect(constant_1,v172_2);
    const Space v172_4 = (has_head(v172_3) ? constant_2 : Space{});
    const Space v172_5 = subtract(constant_0,v172_4);
    Space v172_8;
    if (!v172_5.empty()) {
      const Path v173_6 = concat_path(p0,v171_8_head);
      Space v173_7_result;
      for (int v173_7_label = 1; v173_7_label <= 2; ++v173_7_label) {
        const Space v173_7_tail = child(v171_8_tail,v173_7_label);
        if (v173_7_tail.empty()) continue;
        const Path v173_7_head{v173_7_label};
        const Space v174_2 = singleton(v173_7_head);
        const Space v174_3 = intersect(constant_1,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_2 : Space{});
        const Space v174_5 = subtract(constant_0,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_7_head);
          const Space v175_7 = routine_28(c, v175_6, v173_7_tail);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_1,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_2 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_7_head);
          const Space v176_11 = routine_29(c, v176_6, v173_7_tail);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_7_result = unite(v173_7_result,v174_13);
      }
      const Space v173_7 = std::move(v173_7_result);
      v172_8 = compose(v172_5,v173_7);
    }
    const Space v172_9 = intersect(constant_1,v172_2);
    const Space v172_10 = (has_head(v172_9) ? constant_2 : Space{});
    const Space v172_11 = compose(v172_10,v171_8_tail);
    const Space v172_12 = unite(v172_8,v172_11);
    v171_8_result = unite(v171_8_result,v172_12);
  }
  const Space v171_8 = std::move(v171_8_result);
  return v171_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v177_11_result;
  for (int v177_11_label = 1; v177_11_label <= 2; ++v177_11_label) {
    const Space v177_11_tail = child(s0,v177_11_label);
    if (v177_11_tail.empty()) continue;
    const Path v177_11_head{v177_11_label};
    const Space v178_2 = singleton(v177_11_head);
    const Space v178_3 = intersect(constant_1,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_2 : Space{});
    const Space v178_5 = subtract(constant_0,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_11_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_11_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_1,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
        const Space v180_5 = subtract(constant_0,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_30(c, v181_6, v179_7_tail);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_1,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_2 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_31(c, v182_6, v179_7_tail);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_1,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_2 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_11_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_11_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_1,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_2 : Space{});
        const Space v184_5 = subtract(constant_0,v184_4);
        Space v184_8;
        if (!v184_5.empty()) {
          const Path v185_6 = concat_path(v183_6,v183_11_head);
          const Space v185_7 = routine_30(c, v185_6, v183_11_tail);
          v184_8 = compose(v184_5,v185_7);
        }
        const Space v184_9 = intersect(constant_1,v184_2);
        const Space v184_10 = (has_head(v184_9) ? constant_2 : Space{});
        Space v184_12;
        if (!v184_10.empty()) {
          const Path v186_6 = concat_path(v183_6,v183_11_head);
          const Space v186_11 = routine_17(c, v186_6, v183_11_tail);
          v184_12 = compose(v184_10,v186_11);
        }
        const Space v184_13 = unite(v184_8,v184_12);
        v183_11_result = unite(v183_11_result,v184_13);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_11_result = unite(v177_11_result,v178_13);
  }
  const Space v177_11 = std::move(v177_11_result);
  return v177_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v187_8_result;
  for (int v187_8_label = 1; v187_8_label <= 2; ++v187_8_label) {
    const Space v187_8_tail = child(s0,v187_8_label);
    if (v187_8_tail.empty()) continue;
    const Path v187_8_head{v187_8_label};
    const Space v188_2 = singleton(v187_8_head);
    const Space v188_3 = intersect(constant_1,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_2 : Space{});
    const Space v188_5 = subtract(constant_0,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_8_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_8_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_1,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_2 : Space{});
        const Space v190_5 = subtract(constant_0,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_30(c, v191_6, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_1,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_2 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_31(c, v192_6, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_1,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_2 : Space{});
    const Space v188_11 = compose(v188_10,v187_8_tail);
    const Space v188_12 = unite(v188_8,v188_11);
    v187_8_result = unite(v187_8_result,v188_12);
  }
  const Space v187_8 = std::move(v187_8_result);
  return v187_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v193_12_result;
  for (int v193_12_label = 1; v193_12_label <= 2; ++v193_12_label) {
    const Space v193_12_tail = child(s0,v193_12_label);
    if (v193_12_tail.empty()) continue;
    const Path v193_12_head{v193_12_label};
    const Space v194_2 = singleton(v193_12_head);
    const Space v194_3 = intersect(constant_1,v194_2);
    const Space v194_4 = (has_head(v194_3) ? constant_2 : Space{});
    const Space v194_5 = subtract(constant_0,v194_4);
    Space v194_8;
    if (!v194_5.empty()) {
      const Path v195_6 = concat_path(p0,v193_12_head);
      Space v195_7_result;
      for (int v195_7_label = 1; v195_7_label <= 2; ++v195_7_label) {
        const Space v195_7_tail = child(v193_12_tail,v195_7_label);
        if (v195_7_tail.empty()) continue;
        const Path v195_7_head{v195_7_label};
        const Space v196_2 = singleton(v195_7_head);
        const Space v196_3 = intersect(constant_1,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_2 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v195_6,v195_7_head);
          const Space v197_7 = routine_32(c, v197_6, v195_7_tail, s1);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_1,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_2 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v195_6,v195_7_head);
          const Space v198_11 = routine_33(c, v198_6, v195_7_tail, s1);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_7_result = unite(v195_7_result,v196_13);
      }
      const Space v195_7 = std::move(v195_7_result);
      v194_8 = compose(v194_5,v195_7);
    }
    const Space v194_9 = intersect(constant_1,v194_2);
    const Space v194_10 = (has_head(v194_9) ? constant_2 : Space{});
    Space v194_12;
    if (!v194_10.empty()) {
      const Path v199_6 = concat_path(p0,v193_12_head);
      Space v199_11_result;
      for (int v199_11_label = 1; v199_11_label <= 2; ++v199_11_label) {
        const Space v199_11_tail = child(v193_12_tail,v199_11_label);
        if (v199_11_tail.empty()) continue;
        const Path v199_11_head{v199_11_label};
        const Space v200_2 = singleton(v199_11_head);
        const Space v200_3 = intersect(constant_1,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_2 : Space{});
        const Space v200_5 = subtract(constant_0,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_11_head);
          const Space v201_7 = routine_32(c, v201_6, v199_11_tail, s1);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_1,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_2 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_11_head);
          const Space v202_11 = routine_5(c, v202_6, v199_11_tail, s1);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_11_result = unite(v199_11_result,v200_13);
      }
      const Space v199_11 = std::move(v199_11_result);
      v194_12 = compose(v194_10,v199_11);
    }
    const Space v194_13 = unite(v194_8,v194_12);
    v193_12_result = unite(v193_12_result,v194_13);
  }
  const Space v193_12 = std::move(v193_12_result);
  return v193_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v203_7 = unwrap(s1,constant_4);
  const Space v203_9 = unwrap(s1,constant_5);
  const Space v203_10 = unwrap(v203_9,p0);
  const Space v203_12 = unwrap(s1,constant_6);
  Space v203_22_result;
  for (int v203_22_label = 1; v203_22_label <= 2; ++v203_22_label) {
    const Space v203_22_tail = child(s0,v203_22_label);
    if (v203_22_tail.empty()) continue;
    const Path v203_22_head{v203_22_label};
    const Space v204_2 = singleton(v203_22_head);
    const Space v204_3 = intersect(constant_1,v204_2);
    const Space v204_4 = (has_head(v204_3) ? constant_2 : Space{});
    const Space v204_5 = subtract(constant_0,v204_4);
    Space v204_8;
    if (!v204_5.empty()) {
      const Path v205_6 = concat_path(p0,v203_22_head);
      Space v205_7_result;
      for (int v205_7_label = 1; v205_7_label <= 2; ++v205_7_label) {
        const Space v205_7_tail = child(v203_22_tail,v205_7_label);
        if (v205_7_tail.empty()) continue;
        const Path v205_7_head{v205_7_label};
        const Space v206_2 = singleton(v205_7_head);
        const Space v206_3 = intersect(constant_1,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_2 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_7_head);
          const Space v207_7 = routine_32(c, v207_6, v205_7_tail, s1);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_1,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_2 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_7_head);
          const Space v208_11 = routine_33(c, v208_6, v205_7_tail, s1);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_7_result = unite(v205_7_result,v206_13);
      }
      const Space v205_7 = std::move(v205_7_result);
      v204_8 = compose(v204_5,v205_7);
    }
    const Space v204_9 = intersect(constant_1,v204_2);
    const Space v204_10 = (has_head(v204_9) ? constant_2 : Space{});
    Space v204_18;
    if (!v204_10.empty()) {
      const Space v209_11 = unwrap(v203_10,v203_22_head);
      const Space v209_12 = restrict_to(v203_9,v209_11);
      Space v209_13_result;
      for (int v209_13_label = 1; v209_13_label <= 2; ++v209_13_label) {
        const Space v209_13_tail = child(v209_12,v209_13_label);
        if (v209_13_tail.empty()) continue;
        const Path v209_13_head{v209_13_label};
        const Space v210_2 = singleton(v209_13_head);
        const Space v210_3 = intersect(constant_1,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_2 : Space{});
        const Space v210_5 = subtract(constant_0,v210_4);
        Space v210_7;
        if (!v210_5.empty()) {
          const Space v211_6 = routine_6(c, v209_13_head, v209_13_tail);
          v210_7 = compose(v210_5,v211_6);
        }
        const Space v210_8 = intersect(constant_1,v210_2);
        const Space v210_9 = (has_head(v210_8) ? constant_2 : Space{});
        Space v210_11;
        if (!v210_9.empty()) {
          const Space v212_10 = routine_7(c, v209_13_head, v209_13_tail);
          v210_11 = compose(v210_9,v212_10);
        }
        const Space v210_12 = unite(v210_7,v210_11);
        v209_13_result = unite(v209_13_result,v210_12);
      }
      const Space v209_13 = std::move(v209_13_result);
      const Space v209_14 = restrict_to(v203_7,v209_13);
      Space v209_15_result;
      for (int v209_15_label = 1; v209_15_label <= 2; ++v209_15_label) {
        const Space v209_15_tail = child(v209_14,v209_15_label);
        if (v209_15_tail.empty()) continue;
        const Path v209_15_head{v209_15_label};
        const Space v213_2 = singleton(v209_15_head);
        const Space v213_3 = intersect(constant_1,v213_2);
        const Space v213_4 = (has_head(v213_3) ? constant_2 : Space{});
        const Space v213_5 = subtract(constant_0,v213_4);
        Space v213_7;
        if (!v213_5.empty()) {
          const Space v214_6 = routine_8(c, v209_15_head, v209_15_tail);
          v213_7 = compose(v213_5,v214_6);
        }
        const Space v213_8 = intersect(constant_1,v213_2);
        const Space v213_9 = (has_head(v213_8) ? constant_2 : Space{});
        Space v213_11;
        if (!v213_9.empty()) {
          const Space v215_10 = routine_9(c, v209_15_head, v209_15_tail);
          v213_11 = compose(v213_9,v215_10);
        }
        const Space v213_12 = unite(v213_7,v213_11);
        v209_15_result = unite(v209_15_result,v213_12);
      }
      const Space v209_15 = std::move(v209_15_result);
      const Space v209_16 = subtract(v209_15,v209_11);
      const Space v209_17 = intersect(v209_16,v203_12);
      v204_18 = compose(v204_10,v209_17);
    }
    const Path v216_6 = concat_path(p0,v203_22_head);
    const Space v204_19 = wrap(v204_18,v216_6);
    const Space v204_20 = unite(v204_8,v204_19);
    v203_22_result = unite(v203_22_result,v204_20);
  }
  const Space v203_22 = std::move(v203_22_result);
  return v203_22;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v217_11_result;
  for (int v217_11_label = 1; v217_11_label <= 2; ++v217_11_label) {
    const Space v217_11_tail = child(s0,v217_11_label);
    if (v217_11_tail.empty()) continue;
    const Path v217_11_head{v217_11_label};
    const Space v218_2 = singleton(v217_11_head);
    const Space v218_3 = intersect(constant_1,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_2 : Space{});
    const Space v218_5 = subtract(constant_0,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_11_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_11_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_1,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_2 : Space{});
        const Space v220_5 = subtract(constant_0,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_34(c, v221_6, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_1,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_2 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_35(c, v222_6, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_1,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_2 : Space{});
    Space v218_12;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_11_head);
      Space v223_11_result;
      for (int v223_11_label = 1; v223_11_label <= 2; ++v223_11_label) {
        const Space v223_11_tail = child(v217_11_tail,v223_11_label);
        if (v223_11_tail.empty()) continue;
        const Path v223_11_head{v223_11_label};
        const Space v224_2 = singleton(v223_11_head);
        const Space v224_3 = intersect(constant_1,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_2 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_11_head);
          const Space v225_7 = routine_34(c, v225_6, v223_11_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_1,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_2 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_11_head);
          const Space v226_11 = routine_14(c, v226_6, v223_11_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_11_result = unite(v223_11_result,v224_13);
      }
      const Space v223_11 = std::move(v223_11_result);
      v218_12 = compose(v218_10,v223_11);
    }
    const Space v218_13 = unite(v218_8,v218_12);
    v217_11_result = unite(v217_11_result,v218_13);
  }
  const Space v217_11 = std::move(v217_11_result);
  return v217_11;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v227_8_result;
  for (int v227_8_label = 1; v227_8_label <= 2; ++v227_8_label) {
    const Space v227_8_tail = child(s0,v227_8_label);
    if (v227_8_tail.empty()) continue;
    const Path v227_8_head{v227_8_label};
    const Space v228_2 = singleton(v227_8_head);
    const Space v228_3 = intersect(constant_1,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_2 : Space{});
    const Space v228_5 = subtract(constant_0,v228_4);
    Space v228_8;
    if (!v228_5.empty()) {
      const Path v229_6 = concat_path(p0,v227_8_head);
      Space v229_7_result;
      for (int v229_7_label = 1; v229_7_label <= 2; ++v229_7_label) {
        const Space v229_7_tail = child(v227_8_tail,v229_7_label);
        if (v229_7_tail.empty()) continue;
        const Path v229_7_head{v229_7_label};
        const Space v230_2 = singleton(v229_7_head);
        const Space v230_3 = intersect(constant_1,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_2 : Space{});
        const Space v230_5 = subtract(constant_0,v230_4);
        Space v230_8;
        if (!v230_5.empty()) {
          const Path v231_6 = concat_path(v229_6,v229_7_head);
          const Space v231_7 = routine_34(c, v231_6, v229_7_tail);
          v230_8 = compose(v230_5,v231_7);
        }
        const Space v230_9 = intersect(constant_1,v230_2);
        const Space v230_10 = (has_head(v230_9) ? constant_2 : Space{});
        Space v230_12;
        if (!v230_10.empty()) {
          const Path v232_6 = concat_path(v229_6,v229_7_head);
          const Space v232_11 = routine_35(c, v232_6, v229_7_tail);
          v230_12 = compose(v230_10,v232_11);
        }
        const Space v230_13 = unite(v230_8,v230_12);
        v229_7_result = unite(v229_7_result,v230_13);
      }
      const Space v229_7 = std::move(v229_7_result);
      v228_8 = compose(v228_5,v229_7);
    }
    const Space v228_9 = intersect(constant_1,v228_2);
    const Space v228_10 = (has_head(v228_9) ? constant_2 : Space{});
    const Space v228_11 = compose(v228_10,v227_8_tail);
    const Space v228_12 = unite(v228_8,v228_11);
    v227_8_result = unite(v227_8_result,v228_12);
  }
  const Space v227_8 = std::move(v227_8_result);
  return v227_8;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v233_11_result;
  for (int v233_11_label = 1; v233_11_label <= 2; ++v233_11_label) {
    const Space v233_11_tail = child(s0,v233_11_label);
    if (v233_11_tail.empty()) continue;
    const Path v233_11_head{v233_11_label};
    const Space v234_2 = singleton(v233_11_head);
    const Space v234_3 = intersect(constant_1,v234_2);
    const Space v234_4 = (has_head(v234_3) ? constant_2 : Space{});
    const Space v234_5 = subtract(constant_0,v234_4);
    Space v234_8;
    if (!v234_5.empty()) {
      const Path v235_6 = concat_path(p0,v233_11_head);
      Space v235_7_result;
      for (int v235_7_label = 1; v235_7_label <= 2; ++v235_7_label) {
        const Space v235_7_tail = child(v233_11_tail,v235_7_label);
        if (v235_7_tail.empty()) continue;
        const Path v235_7_head{v235_7_label};
        const Space v236_2 = singleton(v235_7_head);
        const Space v236_3 = intersect(constant_1,v236_2);
        const Space v236_4 = (has_head(v236_3) ? constant_2 : Space{});
        const Space v236_5 = subtract(constant_0,v236_4);
        Space v236_8;
        if (!v236_5.empty()) {
          const Path v237_6 = concat_path(v235_6,v235_7_head);
          const Space v237_7 = routine_36(c, v237_6, v235_7_tail);
          v236_8 = compose(v236_5,v237_7);
        }
        const Space v236_9 = intersect(constant_1,v236_2);
        const Space v236_10 = (has_head(v236_9) ? constant_2 : Space{});
        Space v236_12;
        if (!v236_10.empty()) {
          const Path v238_6 = concat_path(v235_6,v235_7_head);
          const Space v238_11 = routine_37(c, v238_6, v235_7_tail);
          v236_12 = compose(v236_10,v238_11);
        }
        const Space v236_13 = unite(v236_8,v236_12);
        v235_7_result = unite(v235_7_result,v236_13);
      }
      const Space v235_7 = std::move(v235_7_result);
      v234_8 = compose(v234_5,v235_7);
    }
    const Space v234_9 = intersect(constant_1,v234_2);
    const Space v234_10 = (has_head(v234_9) ? constant_2 : Space{});
    Space v234_12;
    if (!v234_10.empty()) {
      const Path v239_6 = concat_path(p0,v233_11_head);
      Space v239_11_result;
      for (int v239_11_label = 1; v239_11_label <= 2; ++v239_11_label) {
        const Space v239_11_tail = child(v233_11_tail,v239_11_label);
        if (v239_11_tail.empty()) continue;
        const Path v239_11_head{v239_11_label};
        const Space v240_2 = singleton(v239_11_head);
        const Space v240_3 = intersect(constant_1,v240_2);
        const Space v240_4 = (has_head(v240_3) ? constant_2 : Space{});
        const Space v240_5 = subtract(constant_0,v240_4);
        Space v240_8;
        if (!v240_5.empty()) {
          const Path v241_6 = concat_path(v239_6,v239_11_head);
          const Space v241_7 = routine_36(c, v241_6, v239_11_tail);
          v240_8 = compose(v240_5,v241_7);
        }
        const Space v240_9 = intersect(constant_1,v240_2);
        const Space v240_10 = (has_head(v240_9) ? constant_2 : Space{});
        Space v240_12;
        if (!v240_10.empty()) {
          const Path v242_6 = concat_path(v239_6,v239_11_head);
          const Space v242_11 = routine_17(c, v242_6, v239_11_tail);
          v240_12 = compose(v240_10,v242_11);
        }
        const Space v240_13 = unite(v240_8,v240_12);
        v239_11_result = unite(v239_11_result,v240_13);
      }
      const Space v239_11 = std::move(v239_11_result);
      v234_12 = compose(v234_10,v239_11);
    }
    const Space v234_13 = unite(v234_8,v234_12);
    v233_11_result = unite(v233_11_result,v234_13);
  }
  const Space v233_11 = std::move(v233_11_result);
  return v233_11;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v243_8_result;
  for (int v243_8_label = 1; v243_8_label <= 2; ++v243_8_label) {
    const Space v243_8_tail = child(s0,v243_8_label);
    if (v243_8_tail.empty()) continue;
    const Path v243_8_head{v243_8_label};
    const Space v244_2 = singleton(v243_8_head);
    const Space v244_3 = intersect(constant_1,v244_2);
    const Space v244_4 = (has_head(v244_3) ? constant_2 : Space{});
    const Space v244_5 = subtract(constant_0,v244_4);
    Space v244_8;
    if (!v244_5.empty()) {
      const Path v245_6 = concat_path(p0,v243_8_head);
      Space v245_7_result;
      for (int v245_7_label = 1; v245_7_label <= 2; ++v245_7_label) {
        const Space v245_7_tail = child(v243_8_tail,v245_7_label);
        if (v245_7_tail.empty()) continue;
        const Path v245_7_head{v245_7_label};
        const Space v246_2 = singleton(v245_7_head);
        const Space v246_3 = intersect(constant_1,v246_2);
        const Space v246_4 = (has_head(v246_3) ? constant_2 : Space{});
        const Space v246_5 = subtract(constant_0,v246_4);
        Space v246_8;
        if (!v246_5.empty()) {
          const Path v247_6 = concat_path(v245_6,v245_7_head);
          const Space v247_7 = routine_36(c, v247_6, v245_7_tail);
          v246_8 = compose(v246_5,v247_7);
        }
        const Space v246_9 = intersect(constant_1,v246_2);
        const Space v246_10 = (has_head(v246_9) ? constant_2 : Space{});
        Space v246_12;
        if (!v246_10.empty()) {
          const Path v248_6 = concat_path(v245_6,v245_7_head);
          const Space v248_11 = routine_37(c, v248_6, v245_7_tail);
          v246_12 = compose(v246_10,v248_11);
        }
        const Space v246_13 = unite(v246_8,v246_12);
        v245_7_result = unite(v245_7_result,v246_13);
      }
      const Space v245_7 = std::move(v245_7_result);
      v244_8 = compose(v244_5,v245_7);
    }
    const Space v244_9 = intersect(constant_1,v244_2);
    const Space v244_10 = (has_head(v244_9) ? constant_2 : Space{});
    const Space v244_11 = compose(v244_10,v243_8_tail);
    const Space v244_12 = unite(v244_8,v244_11);
    v243_8_result = unite(v243_8_result,v244_12);
  }
  const Space v243_8 = std::move(v243_8_result);
  return v243_8;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v249_11_result;
  for (int v249_11_label = 1; v249_11_label <= 2; ++v249_11_label) {
    const Space v249_11_tail = child(s0,v249_11_label);
    if (v249_11_tail.empty()) continue;
    const Path v249_11_head{v249_11_label};
    const Space v250_2 = singleton(v249_11_head);
    const Space v250_3 = intersect(constant_1,v250_2);
    const Space v250_4 = (has_head(v250_3) ? constant_2 : Space{});
    const Space v250_5 = subtract(constant_0,v250_4);
    Space v250_8;
    if (!v250_5.empty()) {
      const Path v251_6 = concat_path(p0,v249_11_head);
      Space v251_7_result;
      for (int v251_7_label = 1; v251_7_label <= 2; ++v251_7_label) {
        const Space v251_7_tail = child(v249_11_tail,v251_7_label);
        if (v251_7_tail.empty()) continue;
        const Path v251_7_head{v251_7_label};
        const Space v252_2 = singleton(v251_7_head);
        const Space v252_3 = intersect(constant_1,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_2 : Space{});
        const Space v252_5 = subtract(constant_0,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_7_head);
          const Space v253_7 = routine_38(c, v253_6, v251_7_tail);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_1,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_2 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_7_head);
          const Space v254_11 = routine_39(c, v254_6, v251_7_tail);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_7_result = unite(v251_7_result,v252_13);
      }
      const Space v251_7 = std::move(v251_7_result);
      v250_8 = compose(v250_5,v251_7);
    }
    const Space v250_9 = intersect(constant_1,v250_2);
    const Space v250_10 = (has_head(v250_9) ? constant_2 : Space{});
    Space v250_12;
    if (!v250_10.empty()) {
      const Path v255_6 = concat_path(p0,v249_11_head);
      Space v255_11_result;
      for (int v255_11_label = 1; v255_11_label <= 2; ++v255_11_label) {
        const Space v255_11_tail = child(v249_11_tail,v255_11_label);
        if (v255_11_tail.empty()) continue;
        const Path v255_11_head{v255_11_label};
        const Space v256_2 = singleton(v255_11_head);
        const Space v256_3 = intersect(constant_1,v256_2);
        const Space v256_4 = (has_head(v256_3) ? constant_2 : Space{});
        const Space v256_5 = subtract(constant_0,v256_4);
        Space v256_8;
        if (!v256_5.empty()) {
          const Path v257_6 = concat_path(v255_6,v255_11_head);
          const Space v257_7 = routine_38(c, v257_6, v255_11_tail);
          v256_8 = compose(v256_5,v257_7);
        }
        const Space v256_9 = intersect(constant_1,v256_2);
        const Space v256_10 = (has_head(v256_9) ? constant_2 : Space{});
        Space v256_12;
        if (!v256_10.empty()) {
          const Path v258_6 = concat_path(v255_6,v255_11_head);
          const Space v258_11 = routine_14(c, v258_6, v255_11_tail);
          v256_12 = compose(v256_10,v258_11);
        }
        const Space v256_13 = unite(v256_8,v256_12);
        v255_11_result = unite(v255_11_result,v256_13);
      }
      const Space v255_11 = std::move(v255_11_result);
      v250_12 = compose(v250_10,v255_11);
    }
    const Space v250_13 = unite(v250_8,v250_12);
    v249_11_result = unite(v249_11_result,v250_13);
  }
  const Space v249_11 = std::move(v249_11_result);
  return v249_11;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v259_8_result;
  for (int v259_8_label = 1; v259_8_label <= 2; ++v259_8_label) {
    const Space v259_8_tail = child(s0,v259_8_label);
    if (v259_8_tail.empty()) continue;
    const Path v259_8_head{v259_8_label};
    const Space v260_2 = singleton(v259_8_head);
    const Space v260_3 = intersect(constant_1,v260_2);
    const Space v260_4 = (has_head(v260_3) ? constant_2 : Space{});
    const Space v260_5 = subtract(constant_0,v260_4);
    Space v260_8;
    if (!v260_5.empty()) {
      const Path v261_6 = concat_path(p0,v259_8_head);
      Space v261_7_result;
      for (int v261_7_label = 1; v261_7_label <= 2; ++v261_7_label) {
        const Space v261_7_tail = child(v259_8_tail,v261_7_label);
        if (v261_7_tail.empty()) continue;
        const Path v261_7_head{v261_7_label};
        const Space v262_2 = singleton(v261_7_head);
        const Space v262_3 = intersect(constant_1,v262_2);
        const Space v262_4 = (has_head(v262_3) ? constant_2 : Space{});
        const Space v262_5 = subtract(constant_0,v262_4);
        Space v262_8;
        if (!v262_5.empty()) {
          const Path v263_6 = concat_path(v261_6,v261_7_head);
          const Space v263_7 = routine_38(c, v263_6, v261_7_tail);
          v262_8 = compose(v262_5,v263_7);
        }
        const Space v262_9 = intersect(constant_1,v262_2);
        const Space v262_10 = (has_head(v262_9) ? constant_2 : Space{});
        Space v262_12;
        if (!v262_10.empty()) {
          const Path v264_6 = concat_path(v261_6,v261_7_head);
          const Space v264_11 = routine_39(c, v264_6, v261_7_tail);
          v262_12 = compose(v262_10,v264_11);
        }
        const Space v262_13 = unite(v262_8,v262_12);
        v261_7_result = unite(v261_7_result,v262_13);
      }
      const Space v261_7 = std::move(v261_7_result);
      v260_8 = compose(v260_5,v261_7);
    }
    const Space v260_9 = intersect(constant_1,v260_2);
    const Space v260_10 = (has_head(v260_9) ? constant_2 : Space{});
    const Space v260_11 = compose(v260_10,v259_8_tail);
    const Space v260_12 = unite(v260_8,v260_11);
    v259_8_result = unite(v259_8_result,v260_12);
  }
  const Space v259_8 = std::move(v259_8_result);
  return v259_8;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v265_11_result;
  for (int v265_11_label = 1; v265_11_label <= 2; ++v265_11_label) {
    const Space v265_11_tail = child(s0,v265_11_label);
    if (v265_11_tail.empty()) continue;
    const Path v265_11_head{v265_11_label};
    const Space v266_2 = singleton(v265_11_head);
    const Space v266_3 = intersect(constant_1,v266_2);
    const Space v266_4 = (has_head(v266_3) ? constant_2 : Space{});
    const Space v266_5 = subtract(constant_0,v266_4);
    Space v266_8;
    if (!v266_5.empty()) {
      const Path v267_6 = concat_path(p0,v265_11_head);
      Space v267_7_result;
      for (int v267_7_label = 1; v267_7_label <= 2; ++v267_7_label) {
        const Space v267_7_tail = child(v265_11_tail,v267_7_label);
        if (v267_7_tail.empty()) continue;
        const Path v267_7_head{v267_7_label};
        const Space v268_2 = singleton(v267_7_head);
        const Space v268_3 = intersect(constant_1,v268_2);
        const Space v268_4 = (has_head(v268_3) ? constant_2 : Space{});
        const Space v268_5 = subtract(constant_0,v268_4);
        Space v268_8;
        if (!v268_5.empty()) {
          const Path v269_6 = concat_path(v267_6,v267_7_head);
          const Space v269_7 = routine_40(c, v269_6, v267_7_tail);
          v268_8 = compose(v268_5,v269_7);
        }
        const Space v268_9 = intersect(constant_1,v268_2);
        const Space v268_10 = (has_head(v268_9) ? constant_2 : Space{});
        Space v268_12;
        if (!v268_10.empty()) {
          const Path v270_6 = concat_path(v267_6,v267_7_head);
          const Space v270_11 = routine_41(c, v270_6, v267_7_tail);
          v268_12 = compose(v268_10,v270_11);
        }
        const Space v268_13 = unite(v268_8,v268_12);
        v267_7_result = unite(v267_7_result,v268_13);
      }
      const Space v267_7 = std::move(v267_7_result);
      v266_8 = compose(v266_5,v267_7);
    }
    const Space v266_9 = intersect(constant_1,v266_2);
    const Space v266_10 = (has_head(v266_9) ? constant_2 : Space{});
    Space v266_12;
    if (!v266_10.empty()) {
      const Path v271_6 = concat_path(p0,v265_11_head);
      Space v271_11_result;
      for (int v271_11_label = 1; v271_11_label <= 2; ++v271_11_label) {
        const Space v271_11_tail = child(v265_11_tail,v271_11_label);
        if (v271_11_tail.empty()) continue;
        const Path v271_11_head{v271_11_label};
        const Space v272_2 = singleton(v271_11_head);
        const Space v272_3 = intersect(constant_1,v272_2);
        const Space v272_4 = (has_head(v272_3) ? constant_2 : Space{});
        const Space v272_5 = subtract(constant_0,v272_4);
        Space v272_8;
        if (!v272_5.empty()) {
          const Path v273_6 = concat_path(v271_6,v271_11_head);
          const Space v273_7 = routine_40(c, v273_6, v271_11_tail);
          v272_8 = compose(v272_5,v273_7);
        }
        const Space v272_9 = intersect(constant_1,v272_2);
        const Space v272_10 = (has_head(v272_9) ? constant_2 : Space{});
        Space v272_12;
        if (!v272_10.empty()) {
          const Path v274_6 = concat_path(v271_6,v271_11_head);
          const Space v274_11 = routine_17(c, v274_6, v271_11_tail);
          v272_12 = compose(v272_10,v274_11);
        }
        const Space v272_13 = unite(v272_8,v272_12);
        v271_11_result = unite(v271_11_result,v272_13);
      }
      const Space v271_11 = std::move(v271_11_result);
      v266_12 = compose(v266_10,v271_11);
    }
    const Space v266_13 = unite(v266_8,v266_12);
    v265_11_result = unite(v265_11_result,v266_13);
  }
  const Space v265_11 = std::move(v265_11_result);
  return v265_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v275_8_result;
  for (int v275_8_label = 1; v275_8_label <= 2; ++v275_8_label) {
    const Space v275_8_tail = child(s0,v275_8_label);
    if (v275_8_tail.empty()) continue;
    const Path v275_8_head{v275_8_label};
    const Space v276_2 = singleton(v275_8_head);
    const Space v276_3 = intersect(constant_1,v276_2);
    const Space v276_4 = (has_head(v276_3) ? constant_2 : Space{});
    const Space v276_5 = subtract(constant_0,v276_4);
    Space v276_8;
    if (!v276_5.empty()) {
      const Path v277_6 = concat_path(p0,v275_8_head);
      Space v277_7_result;
      for (int v277_7_label = 1; v277_7_label <= 2; ++v277_7_label) {
        const Space v277_7_tail = child(v275_8_tail,v277_7_label);
        if (v277_7_tail.empty()) continue;
        const Path v277_7_head{v277_7_label};
        const Space v278_2 = singleton(v277_7_head);
        const Space v278_3 = intersect(constant_1,v278_2);
        const Space v278_4 = (has_head(v278_3) ? constant_2 : Space{});
        const Space v278_5 = subtract(constant_0,v278_4);
        Space v278_8;
        if (!v278_5.empty()) {
          const Path v279_6 = concat_path(v277_6,v277_7_head);
          const Space v279_7 = routine_40(c, v279_6, v277_7_tail);
          v278_8 = compose(v278_5,v279_7);
        }
        const Space v278_9 = intersect(constant_1,v278_2);
        const Space v278_10 = (has_head(v278_9) ? constant_2 : Space{});
        Space v278_12;
        if (!v278_10.empty()) {
          const Path v280_6 = concat_path(v277_6,v277_7_head);
          const Space v280_11 = routine_41(c, v280_6, v277_7_tail);
          v278_12 = compose(v278_10,v280_11);
        }
        const Space v278_13 = unite(v278_8,v278_12);
        v277_7_result = unite(v277_7_result,v278_13);
      }
      const Space v277_7 = std::move(v277_7_result);
      v276_8 = compose(v276_5,v277_7);
    }
    const Space v276_9 = intersect(constant_1,v276_2);
    const Space v276_10 = (has_head(v276_9) ? constant_2 : Space{});
    const Space v276_11 = compose(v276_10,v275_8_tail);
    const Space v276_12 = unite(v276_8,v276_11);
    v275_8_result = unite(v275_8_result,v276_12);
  }
  const Space v275_8 = std::move(v275_8_result);
  return v275_8;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v281_12_result;
  for (int v281_12_label = 1; v281_12_label <= 2; ++v281_12_label) {
    const Space v281_12_tail = child(s0,v281_12_label);
    if (v281_12_tail.empty()) continue;
    const Path v281_12_head{v281_12_label};
    const Space v282_2 = singleton(v281_12_head);
    const Space v282_3 = intersect(constant_1,v282_2);
    const Space v282_4 = (has_head(v282_3) ? constant_2 : Space{});
    const Space v282_5 = subtract(constant_0,v282_4);
    Space v282_8;
    if (!v282_5.empty()) {
      const Path v283_6 = concat_path(p0,v281_12_head);
      Space v283_7_result;
      for (int v283_7_label = 1; v283_7_label <= 2; ++v283_7_label) {
        const Space v283_7_tail = child(v281_12_tail,v283_7_label);
        if (v283_7_tail.empty()) continue;
        const Path v283_7_head{v283_7_label};
        const Space v284_2 = singleton(v283_7_head);
        const Space v284_3 = intersect(constant_1,v284_2);
        const Space v284_4 = (has_head(v284_3) ? constant_2 : Space{});
        const Space v284_5 = subtract(constant_0,v284_4);
        Space v284_8;
        if (!v284_5.empty()) {
          const Path v285_6 = concat_path(v283_6,v283_7_head);
          const Space v285_7 = routine_42(c, v285_6, v283_7_tail, s1);
          v284_8 = compose(v284_5,v285_7);
        }
        const Space v284_9 = intersect(constant_1,v284_2);
        const Space v284_10 = (has_head(v284_9) ? constant_2 : Space{});
        Space v284_12;
        if (!v284_10.empty()) {
          const Path v286_6 = concat_path(v283_6,v283_7_head);
          const Space v286_11 = routine_43(c, v286_6, v283_7_tail, s1);
          v284_12 = compose(v284_10,v286_11);
        }
        const Space v284_13 = unite(v284_8,v284_12);
        v283_7_result = unite(v283_7_result,v284_13);
      }
      const Space v283_7 = std::move(v283_7_result);
      v282_8 = compose(v282_5,v283_7);
    }
    const Space v282_9 = intersect(constant_1,v282_2);
    const Space v282_10 = (has_head(v282_9) ? constant_2 : Space{});
    Space v282_12;
    if (!v282_10.empty()) {
      const Path v287_6 = concat_path(p0,v281_12_head);
      Space v287_11_result;
      for (int v287_11_label = 1; v287_11_label <= 2; ++v287_11_label) {
        const Space v287_11_tail = child(v281_12_tail,v287_11_label);
        if (v287_11_tail.empty()) continue;
        const Path v287_11_head{v287_11_label};
        const Space v288_2 = singleton(v287_11_head);
        const Space v288_3 = intersect(constant_1,v288_2);
        const Space v288_4 = (has_head(v288_3) ? constant_2 : Space{});
        const Space v288_5 = subtract(constant_0,v288_4);
        Space v288_8;
        if (!v288_5.empty()) {
          const Path v289_6 = concat_path(v287_6,v287_11_head);
          const Space v289_7 = routine_42(c, v289_6, v287_11_tail, s1);
          v288_8 = compose(v288_5,v289_7);
        }
        const Space v288_9 = intersect(constant_1,v288_2);
        const Space v288_10 = (has_head(v288_9) ? constant_2 : Space{});
        Space v288_12;
        if (!v288_10.empty()) {
          const Path v290_6 = concat_path(v287_6,v287_11_head);
          const Space v290_11 = routine_5(c, v290_6, v287_11_tail, s1);
          v288_12 = compose(v288_10,v290_11);
        }
        const Space v288_13 = unite(v288_8,v288_12);
        v287_11_result = unite(v287_11_result,v288_13);
      }
      const Space v287_11 = std::move(v287_11_result);
      v282_12 = compose(v282_10,v287_11);
    }
    const Space v282_13 = unite(v282_8,v282_12);
    v281_12_result = unite(v281_12_result,v282_13);
  }
  const Space v281_12 = std::move(v281_12_result);
  return v281_12;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v291_7 = unwrap(s1,constant_4);
  const Space v291_9 = unwrap(s1,constant_5);
  const Space v291_10 = unwrap(v291_9,p0);
  const Space v291_12 = unwrap(s1,constant_6);
  Space v291_22_result;
  for (int v291_22_label = 1; v291_22_label <= 2; ++v291_22_label) {
    const Space v291_22_tail = child(s0,v291_22_label);
    if (v291_22_tail.empty()) continue;
    const Path v291_22_head{v291_22_label};
    const Space v292_2 = singleton(v291_22_head);
    const Space v292_3 = intersect(constant_1,v292_2);
    const Space v292_4 = (has_head(v292_3) ? constant_2 : Space{});
    const Space v292_5 = subtract(constant_0,v292_4);
    Space v292_8;
    if (!v292_5.empty()) {
      const Path v293_6 = concat_path(p0,v291_22_head);
      Space v293_7_result;
      for (int v293_7_label = 1; v293_7_label <= 2; ++v293_7_label) {
        const Space v293_7_tail = child(v291_22_tail,v293_7_label);
        if (v293_7_tail.empty()) continue;
        const Path v293_7_head{v293_7_label};
        const Space v294_2 = singleton(v293_7_head);
        const Space v294_3 = intersect(constant_1,v294_2);
        const Space v294_4 = (has_head(v294_3) ? constant_2 : Space{});
        const Space v294_5 = subtract(constant_0,v294_4);
        Space v294_8;
        if (!v294_5.empty()) {
          const Path v295_6 = concat_path(v293_6,v293_7_head);
          const Space v295_7 = routine_42(c, v295_6, v293_7_tail, s1);
          v294_8 = compose(v294_5,v295_7);
        }
        const Space v294_9 = intersect(constant_1,v294_2);
        const Space v294_10 = (has_head(v294_9) ? constant_2 : Space{});
        Space v294_12;
        if (!v294_10.empty()) {
          const Path v296_6 = concat_path(v293_6,v293_7_head);
          const Space v296_11 = routine_43(c, v296_6, v293_7_tail, s1);
          v294_12 = compose(v294_10,v296_11);
        }
        const Space v294_13 = unite(v294_8,v294_12);
        v293_7_result = unite(v293_7_result,v294_13);
      }
      const Space v293_7 = std::move(v293_7_result);
      v292_8 = compose(v292_5,v293_7);
    }
    const Space v292_9 = intersect(constant_1,v292_2);
    const Space v292_10 = (has_head(v292_9) ? constant_2 : Space{});
    Space v292_18;
    if (!v292_10.empty()) {
      const Space v297_11 = unwrap(v291_10,v291_22_head);
      const Space v297_12 = restrict_to(v291_9,v297_11);
      Space v297_13_result;
      for (int v297_13_label = 1; v297_13_label <= 2; ++v297_13_label) {
        const Space v297_13_tail = child(v297_12,v297_13_label);
        if (v297_13_tail.empty()) continue;
        const Path v297_13_head{v297_13_label};
        const Space v298_2 = singleton(v297_13_head);
        const Space v298_3 = intersect(constant_1,v298_2);
        const Space v298_4 = (has_head(v298_3) ? constant_2 : Space{});
        const Space v298_5 = subtract(constant_0,v298_4);
        Space v298_7;
        if (!v298_5.empty()) {
          const Space v299_6 = routine_6(c, v297_13_head, v297_13_tail);
          v298_7 = compose(v298_5,v299_6);
        }
        const Space v298_8 = intersect(constant_1,v298_2);
        const Space v298_9 = (has_head(v298_8) ? constant_2 : Space{});
        Space v298_11;
        if (!v298_9.empty()) {
          const Space v300_10 = routine_7(c, v297_13_head, v297_13_tail);
          v298_11 = compose(v298_9,v300_10);
        }
        const Space v298_12 = unite(v298_7,v298_11);
        v297_13_result = unite(v297_13_result,v298_12);
      }
      const Space v297_13 = std::move(v297_13_result);
      const Space v297_14 = restrict_to(v291_7,v297_13);
      Space v297_15_result;
      for (int v297_15_label = 1; v297_15_label <= 2; ++v297_15_label) {
        const Space v297_15_tail = child(v297_14,v297_15_label);
        if (v297_15_tail.empty()) continue;
        const Path v297_15_head{v297_15_label};
        const Space v301_2 = singleton(v297_15_head);
        const Space v301_3 = intersect(constant_1,v301_2);
        const Space v301_4 = (has_head(v301_3) ? constant_2 : Space{});
        const Space v301_5 = subtract(constant_0,v301_4);
        Space v301_7;
        if (!v301_5.empty()) {
          const Space v302_6 = routine_8(c, v297_15_head, v297_15_tail);
          v301_7 = compose(v301_5,v302_6);
        }
        const Space v301_8 = intersect(constant_1,v301_2);
        const Space v301_9 = (has_head(v301_8) ? constant_2 : Space{});
        Space v301_11;
        if (!v301_9.empty()) {
          const Space v303_10 = routine_9(c, v297_15_head, v297_15_tail);
          v301_11 = compose(v301_9,v303_10);
        }
        const Space v301_12 = unite(v301_7,v301_11);
        v297_15_result = unite(v297_15_result,v301_12);
      }
      const Space v297_15 = std::move(v297_15_result);
      const Space v297_16 = subtract(v297_15,v297_11);
      const Space v297_17 = intersect(v297_16,v291_12);
      v292_18 = compose(v292_10,v297_17);
    }
    const Path v304_6 = concat_path(p0,v291_22_head);
    const Space v292_19 = wrap(v292_18,v304_6);
    const Space v292_20 = unite(v292_8,v292_19);
    v291_22_result = unite(v291_22_result,v292_20);
  }
  const Space v291_22 = std::move(v291_22_result);
  return v291_22;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  Space v305_11_result;
  for (int v305_11_label = 1; v305_11_label <= 2; ++v305_11_label) {
    const Space v305_11_tail = child(s0,v305_11_label);
    if (v305_11_tail.empty()) continue;
    const Path v305_11_head{v305_11_label};
    const Space v306_2 = singleton(v305_11_head);
    const Space v306_3 = intersect(constant_1,v306_2);
    const Space v306_4 = (has_head(v306_3) ? constant_2 : Space{});
    const Space v306_5 = subtract(constant_0,v306_4);
    Space v306_8;
    if (!v306_5.empty()) {
      const Path v307_6 = concat_path(p0,v305_11_head);
      Space v307_7_result;
      for (int v307_7_label = 1; v307_7_label <= 2; ++v307_7_label) {
        const Space v307_7_tail = child(v305_11_tail,v307_7_label);
        if (v307_7_tail.empty()) continue;
        const Path v307_7_head{v307_7_label};
        const Space v308_2 = singleton(v307_7_head);
        const Space v308_3 = intersect(constant_1,v308_2);
        const Space v308_4 = (has_head(v308_3) ? constant_2 : Space{});
        const Space v308_5 = subtract(constant_0,v308_4);
        Space v308_8;
        if (!v308_5.empty()) {
          const Path v309_6 = concat_path(v307_6,v307_7_head);
          const Space v309_7 = routine_44(c, v309_6, v307_7_tail);
          v308_8 = compose(v308_5,v309_7);
        }
        const Space v308_9 = intersect(constant_1,v308_2);
        const Space v308_10 = (has_head(v308_9) ? constant_2 : Space{});
        Space v308_12;
        if (!v308_10.empty()) {
          const Path v310_6 = concat_path(v307_6,v307_7_head);
          const Space v310_11 = routine_45(c, v310_6, v307_7_tail);
          v308_12 = compose(v308_10,v310_11);
        }
        const Space v308_13 = unite(v308_8,v308_12);
        v307_7_result = unite(v307_7_result,v308_13);
      }
      const Space v307_7 = std::move(v307_7_result);
      v306_8 = compose(v306_5,v307_7);
    }
    const Space v306_9 = intersect(constant_1,v306_2);
    const Space v306_10 = (has_head(v306_9) ? constant_2 : Space{});
    Space v306_12;
    if (!v306_10.empty()) {
      const Path v311_6 = concat_path(p0,v305_11_head);
      Space v311_11_result;
      for (int v311_11_label = 1; v311_11_label <= 2; ++v311_11_label) {
        const Space v311_11_tail = child(v305_11_tail,v311_11_label);
        if (v311_11_tail.empty()) continue;
        const Path v311_11_head{v311_11_label};
        const Space v312_2 = singleton(v311_11_head);
        const Space v312_3 = intersect(constant_1,v312_2);
        const Space v312_4 = (has_head(v312_3) ? constant_2 : Space{});
        const Space v312_5 = subtract(constant_0,v312_4);
        Space v312_8;
        if (!v312_5.empty()) {
          const Path v313_6 = concat_path(v311_6,v311_11_head);
          const Space v313_7 = routine_44(c, v313_6, v311_11_tail);
          v312_8 = compose(v312_5,v313_7);
        }
        const Space v312_9 = intersect(constant_1,v312_2);
        const Space v312_10 = (has_head(v312_9) ? constant_2 : Space{});
        Space v312_12;
        if (!v312_10.empty()) {
          const Path v314_6 = concat_path(v311_6,v311_11_head);
          const Space v314_11 = routine_14(c, v314_6, v311_11_tail);
          v312_12 = compose(v312_10,v314_11);
        }
        const Space v312_13 = unite(v312_8,v312_12);
        v311_11_result = unite(v311_11_result,v312_13);
      }
      const Space v311_11 = std::move(v311_11_result);
      v306_12 = compose(v306_10,v311_11);
    }
    const Space v306_13 = unite(v306_8,v306_12);
    v305_11_result = unite(v305_11_result,v306_13);
  }
  const Space v305_11 = std::move(v305_11_result);
  return v305_11;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  Space v315_8_result;
  for (int v315_8_label = 1; v315_8_label <= 2; ++v315_8_label) {
    const Space v315_8_tail = child(s0,v315_8_label);
    if (v315_8_tail.empty()) continue;
    const Path v315_8_head{v315_8_label};
    const Space v316_2 = singleton(v315_8_head);
    const Space v316_3 = intersect(constant_1,v316_2);
    const Space v316_4 = (has_head(v316_3) ? constant_2 : Space{});
    const Space v316_5 = subtract(constant_0,v316_4);
    Space v316_8;
    if (!v316_5.empty()) {
      const Path v317_6 = concat_path(p0,v315_8_head);
      Space v317_7_result;
      for (int v317_7_label = 1; v317_7_label <= 2; ++v317_7_label) {
        const Space v317_7_tail = child(v315_8_tail,v317_7_label);
        if (v317_7_tail.empty()) continue;
        const Path v317_7_head{v317_7_label};
        const Space v318_2 = singleton(v317_7_head);
        const Space v318_3 = intersect(constant_1,v318_2);
        const Space v318_4 = (has_head(v318_3) ? constant_2 : Space{});
        const Space v318_5 = subtract(constant_0,v318_4);
        Space v318_8;
        if (!v318_5.empty()) {
          const Path v319_6 = concat_path(v317_6,v317_7_head);
          const Space v319_7 = routine_44(c, v319_6, v317_7_tail);
          v318_8 = compose(v318_5,v319_7);
        }
        const Space v318_9 = intersect(constant_1,v318_2);
        const Space v318_10 = (has_head(v318_9) ? constant_2 : Space{});
        Space v318_12;
        if (!v318_10.empty()) {
          const Path v320_6 = concat_path(v317_6,v317_7_head);
          const Space v320_11 = routine_45(c, v320_6, v317_7_tail);
          v318_12 = compose(v318_10,v320_11);
        }
        const Space v318_13 = unite(v318_8,v318_12);
        v317_7_result = unite(v317_7_result,v318_13);
      }
      const Space v317_7 = std::move(v317_7_result);
      v316_8 = compose(v316_5,v317_7);
    }
    const Space v316_9 = intersect(constant_1,v316_2);
    const Space v316_10 = (has_head(v316_9) ? constant_2 : Space{});
    const Space v316_11 = compose(v316_10,v315_8_tail);
    const Space v316_12 = unite(v316_8,v316_11);
    v315_8_result = unite(v315_8_result,v316_12);
  }
  const Space v315_8 = std::move(v315_8_result);
  return v315_8;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  Space v321_11_result;
  for (int v321_11_label = 1; v321_11_label <= 2; ++v321_11_label) {
    const Space v321_11_tail = child(s0,v321_11_label);
    if (v321_11_tail.empty()) continue;
    const Path v321_11_head{v321_11_label};
    const Space v322_2 = singleton(v321_11_head);
    const Space v322_3 = intersect(constant_1,v322_2);
    const Space v322_4 = (has_head(v322_3) ? constant_2 : Space{});
    const Space v322_5 = subtract(constant_0,v322_4);
    Space v322_8;
    if (!v322_5.empty()) {
      const Path v323_6 = concat_path(p0,v321_11_head);
      Space v323_7_result;
      for (int v323_7_label = 1; v323_7_label <= 2; ++v323_7_label) {
        const Space v323_7_tail = child(v321_11_tail,v323_7_label);
        if (v323_7_tail.empty()) continue;
        const Path v323_7_head{v323_7_label};
        const Space v324_2 = singleton(v323_7_head);
        const Space v324_3 = intersect(constant_1,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_2 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_7_head);
          const Space v325_7 = routine_46(c, v325_6, v323_7_tail);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_1,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_2 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_7_head);
          const Space v326_11 = routine_47(c, v326_6, v323_7_tail);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_7_result = unite(v323_7_result,v324_13);
      }
      const Space v323_7 = std::move(v323_7_result);
      v322_8 = compose(v322_5,v323_7);
    }
    const Space v322_9 = intersect(constant_1,v322_2);
    const Space v322_10 = (has_head(v322_9) ? constant_2 : Space{});
    Space v322_12;
    if (!v322_10.empty()) {
      const Path v327_6 = concat_path(p0,v321_11_head);
      Space v327_11_result;
      for (int v327_11_label = 1; v327_11_label <= 2; ++v327_11_label) {
        const Space v327_11_tail = child(v321_11_tail,v327_11_label);
        if (v327_11_tail.empty()) continue;
        const Path v327_11_head{v327_11_label};
        const Space v328_2 = singleton(v327_11_head);
        const Space v328_3 = intersect(constant_1,v328_2);
        const Space v328_4 = (has_head(v328_3) ? constant_2 : Space{});
        const Space v328_5 = subtract(constant_0,v328_4);
        Space v328_8;
        if (!v328_5.empty()) {
          const Path v329_6 = concat_path(v327_6,v327_11_head);
          const Space v329_7 = routine_46(c, v329_6, v327_11_tail);
          v328_8 = compose(v328_5,v329_7);
        }
        const Space v328_9 = intersect(constant_1,v328_2);
        const Space v328_10 = (has_head(v328_9) ? constant_2 : Space{});
        Space v328_12;
        if (!v328_10.empty()) {
          const Path v330_6 = concat_path(v327_6,v327_11_head);
          const Space v330_11 = routine_17(c, v330_6, v327_11_tail);
          v328_12 = compose(v328_10,v330_11);
        }
        const Space v328_13 = unite(v328_8,v328_12);
        v327_11_result = unite(v327_11_result,v328_13);
      }
      const Space v327_11 = std::move(v327_11_result);
      v322_12 = compose(v322_10,v327_11);
    }
    const Space v322_13 = unite(v322_8,v322_12);
    v321_11_result = unite(v321_11_result,v322_13);
  }
  const Space v321_11 = std::move(v321_11_result);
  return v321_11;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v331_8_result;
  for (int v331_8_label = 1; v331_8_label <= 2; ++v331_8_label) {
    const Space v331_8_tail = child(s0,v331_8_label);
    if (v331_8_tail.empty()) continue;
    const Path v331_8_head{v331_8_label};
    const Space v332_2 = singleton(v331_8_head);
    const Space v332_3 = intersect(constant_1,v332_2);
    const Space v332_4 = (has_head(v332_3) ? constant_2 : Space{});
    const Space v332_5 = subtract(constant_0,v332_4);
    Space v332_8;
    if (!v332_5.empty()) {
      const Path v333_6 = concat_path(p0,v331_8_head);
      Space v333_7_result;
      for (int v333_7_label = 1; v333_7_label <= 2; ++v333_7_label) {
        const Space v333_7_tail = child(v331_8_tail,v333_7_label);
        if (v333_7_tail.empty()) continue;
        const Path v333_7_head{v333_7_label};
        const Space v334_2 = singleton(v333_7_head);
        const Space v334_3 = intersect(constant_1,v334_2);
        const Space v334_4 = (has_head(v334_3) ? constant_2 : Space{});
        const Space v334_5 = subtract(constant_0,v334_4);
        Space v334_8;
        if (!v334_5.empty()) {
          const Path v335_6 = concat_path(v333_6,v333_7_head);
          const Space v335_7 = routine_46(c, v335_6, v333_7_tail);
          v334_8 = compose(v334_5,v335_7);
        }
        const Space v334_9 = intersect(constant_1,v334_2);
        const Space v334_10 = (has_head(v334_9) ? constant_2 : Space{});
        Space v334_12;
        if (!v334_10.empty()) {
          const Path v336_6 = concat_path(v333_6,v333_7_head);
          const Space v336_11 = routine_47(c, v336_6, v333_7_tail);
          v334_12 = compose(v334_10,v336_11);
        }
        const Space v334_13 = unite(v334_8,v334_12);
        v333_7_result = unite(v333_7_result,v334_13);
      }
      const Space v333_7 = std::move(v333_7_result);
      v332_8 = compose(v332_5,v333_7);
    }
    const Space v332_9 = intersect(constant_1,v332_2);
    const Space v332_10 = (has_head(v332_9) ? constant_2 : Space{});
    const Space v332_11 = compose(v332_10,v331_8_tail);
    const Space v332_12 = unite(v332_8,v332_11);
    v331_8_result = unite(v331_8_result,v332_12);
  }
  const Space v331_8 = std::move(v331_8_result);
  return v331_8;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  Space v337_11_result;
  for (int v337_11_label = 1; v337_11_label <= 2; ++v337_11_label) {
    const Space v337_11_tail = child(s0,v337_11_label);
    if (v337_11_tail.empty()) continue;
    const Path v337_11_head{v337_11_label};
    const Space v338_2 = singleton(v337_11_head);
    const Space v338_3 = intersect(constant_1,v338_2);
    const Space v338_4 = (has_head(v338_3) ? constant_2 : Space{});
    const Space v338_5 = subtract(constant_0,v338_4);
    Space v338_8;
    if (!v338_5.empty()) {
      const Path v339_6 = concat_path(p0,v337_11_head);
      Space v339_7_result;
      for (int v339_7_label = 1; v339_7_label <= 2; ++v339_7_label) {
        const Space v339_7_tail = child(v337_11_tail,v339_7_label);
        if (v339_7_tail.empty()) continue;
        const Path v339_7_head{v339_7_label};
        const Space v340_2 = singleton(v339_7_head);
        const Space v340_3 = intersect(constant_1,v340_2);
        const Space v340_4 = (has_head(v340_3) ? constant_2 : Space{});
        const Space v340_5 = subtract(constant_0,v340_4);
        Space v340_8;
        if (!v340_5.empty()) {
          const Path v341_6 = concat_path(v339_6,v339_7_head);
          const Space v341_7 = routine_48(c, v341_6, v339_7_tail);
          v340_8 = compose(v340_5,v341_7);
        }
        const Space v340_9 = intersect(constant_1,v340_2);
        const Space v340_10 = (has_head(v340_9) ? constant_2 : Space{});
        Space v340_12;
        if (!v340_10.empty()) {
          const Path v342_6 = concat_path(v339_6,v339_7_head);
          const Space v342_11 = routine_49(c, v342_6, v339_7_tail);
          v340_12 = compose(v340_10,v342_11);
        }
        const Space v340_13 = unite(v340_8,v340_12);
        v339_7_result = unite(v339_7_result,v340_13);
      }
      const Space v339_7 = std::move(v339_7_result);
      v338_8 = compose(v338_5,v339_7);
    }
    const Space v338_9 = intersect(constant_1,v338_2);
    const Space v338_10 = (has_head(v338_9) ? constant_2 : Space{});
    Space v338_12;
    if (!v338_10.empty()) {
      const Path v343_6 = concat_path(p0,v337_11_head);
      Space v343_11_result;
      for (int v343_11_label = 1; v343_11_label <= 2; ++v343_11_label) {
        const Space v343_11_tail = child(v337_11_tail,v343_11_label);
        if (v343_11_tail.empty()) continue;
        const Path v343_11_head{v343_11_label};
        const Space v344_2 = singleton(v343_11_head);
        const Space v344_3 = intersect(constant_1,v344_2);
        const Space v344_4 = (has_head(v344_3) ? constant_2 : Space{});
        const Space v344_5 = subtract(constant_0,v344_4);
        Space v344_8;
        if (!v344_5.empty()) {
          const Path v345_6 = concat_path(v343_6,v343_11_head);
          const Space v345_7 = routine_48(c, v345_6, v343_11_tail);
          v344_8 = compose(v344_5,v345_7);
        }
        const Space v344_9 = intersect(constant_1,v344_2);
        const Space v344_10 = (has_head(v344_9) ? constant_2 : Space{});
        Space v344_12;
        if (!v344_10.empty()) {
          const Path v346_6 = concat_path(v343_6,v343_11_head);
          const Space v346_11 = routine_14(c, v346_6, v343_11_tail);
          v344_12 = compose(v344_10,v346_11);
        }
        const Space v344_13 = unite(v344_8,v344_12);
        v343_11_result = unite(v343_11_result,v344_13);
      }
      const Space v343_11 = std::move(v343_11_result);
      v338_12 = compose(v338_10,v343_11);
    }
    const Space v338_13 = unite(v338_8,v338_12);
    v337_11_result = unite(v337_11_result,v338_13);
  }
  const Space v337_11 = std::move(v337_11_result);
  return v337_11;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  Space v347_8_result;
  for (int v347_8_label = 1; v347_8_label <= 2; ++v347_8_label) {
    const Space v347_8_tail = child(s0,v347_8_label);
    if (v347_8_tail.empty()) continue;
    const Path v347_8_head{v347_8_label};
    const Space v348_2 = singleton(v347_8_head);
    const Space v348_3 = intersect(constant_1,v348_2);
    const Space v348_4 = (has_head(v348_3) ? constant_2 : Space{});
    const Space v348_5 = subtract(constant_0,v348_4);
    Space v348_8;
    if (!v348_5.empty()) {
      const Path v349_6 = concat_path(p0,v347_8_head);
      Space v349_7_result;
      for (int v349_7_label = 1; v349_7_label <= 2; ++v349_7_label) {
        const Space v349_7_tail = child(v347_8_tail,v349_7_label);
        if (v349_7_tail.empty()) continue;
        const Path v349_7_head{v349_7_label};
        const Space v350_2 = singleton(v349_7_head);
        const Space v350_3 = intersect(constant_1,v350_2);
        const Space v350_4 = (has_head(v350_3) ? constant_2 : Space{});
        const Space v350_5 = subtract(constant_0,v350_4);
        Space v350_8;
        if (!v350_5.empty()) {
          const Path v351_6 = concat_path(v349_6,v349_7_head);
          const Space v351_7 = routine_48(c, v351_6, v349_7_tail);
          v350_8 = compose(v350_5,v351_7);
        }
        const Space v350_9 = intersect(constant_1,v350_2);
        const Space v350_10 = (has_head(v350_9) ? constant_2 : Space{});
        Space v350_12;
        if (!v350_10.empty()) {
          const Path v352_6 = concat_path(v349_6,v349_7_head);
          const Space v352_11 = routine_49(c, v352_6, v349_7_tail);
          v350_12 = compose(v350_10,v352_11);
        }
        const Space v350_13 = unite(v350_8,v350_12);
        v349_7_result = unite(v349_7_result,v350_13);
      }
      const Space v349_7 = std::move(v349_7_result);
      v348_8 = compose(v348_5,v349_7);
    }
    const Space v348_9 = intersect(constant_1,v348_2);
    const Space v348_10 = (has_head(v348_9) ? constant_2 : Space{});
    const Space v348_11 = compose(v348_10,v347_8_tail);
    const Space v348_12 = unite(v348_8,v348_11);
    v347_8_result = unite(v347_8_result,v348_12);
  }
  const Space v347_8 = std::move(v347_8_result);
  return v347_8;
}

static Space routine_40(Context& c, const Path& p0, const Space& s0) {
  Space v353_11_result;
  for (int v353_11_label = 1; v353_11_label <= 2; ++v353_11_label) {
    const Space v353_11_tail = child(s0,v353_11_label);
    if (v353_11_tail.empty()) continue;
    const Path v353_11_head{v353_11_label};
    const Space v354_2 = singleton(v353_11_head);
    const Space v354_3 = intersect(constant_1,v354_2);
    const Space v354_4 = (has_head(v354_3) ? constant_2 : Space{});
    const Space v354_5 = subtract(constant_0,v354_4);
    Space v354_8;
    if (!v354_5.empty()) {
      const Path v355_6 = concat_path(p0,v353_11_head);
      Space v355_7_result;
      for (int v355_7_label = 1; v355_7_label <= 2; ++v355_7_label) {
        const Space v355_7_tail = child(v353_11_tail,v355_7_label);
        if (v355_7_tail.empty()) continue;
        const Path v355_7_head{v355_7_label};
        const Space v356_2 = singleton(v355_7_head);
        const Space v356_3 = intersect(constant_1,v356_2);
        const Space v356_4 = (has_head(v356_3) ? constant_2 : Space{});
        const Space v356_5 = subtract(constant_0,v356_4);
        Space v356_8;
        if (!v356_5.empty()) {
          const Path v357_6 = concat_path(v355_6,v355_7_head);
          const Space v357_7 = routine_50(c, v357_6, v355_7_tail);
          v356_8 = compose(v356_5,v357_7);
        }
        const Space v356_9 = intersect(constant_1,v356_2);
        const Space v356_10 = (has_head(v356_9) ? constant_2 : Space{});
        Space v356_12;
        if (!v356_10.empty()) {
          const Path v358_6 = concat_path(v355_6,v355_7_head);
          const Space v358_11 = routine_51(c, v358_6, v355_7_tail);
          v356_12 = compose(v356_10,v358_11);
        }
        const Space v356_13 = unite(v356_8,v356_12);
        v355_7_result = unite(v355_7_result,v356_13);
      }
      const Space v355_7 = std::move(v355_7_result);
      v354_8 = compose(v354_5,v355_7);
    }
    const Space v354_9 = intersect(constant_1,v354_2);
    const Space v354_10 = (has_head(v354_9) ? constant_2 : Space{});
    Space v354_12;
    if (!v354_10.empty()) {
      const Path v359_6 = concat_path(p0,v353_11_head);
      Space v359_11_result;
      for (int v359_11_label = 1; v359_11_label <= 2; ++v359_11_label) {
        const Space v359_11_tail = child(v353_11_tail,v359_11_label);
        if (v359_11_tail.empty()) continue;
        const Path v359_11_head{v359_11_label};
        const Space v360_2 = singleton(v359_11_head);
        const Space v360_3 = intersect(constant_1,v360_2);
        const Space v360_4 = (has_head(v360_3) ? constant_2 : Space{});
        const Space v360_5 = subtract(constant_0,v360_4);
        Space v360_8;
        if (!v360_5.empty()) {
          const Path v361_6 = concat_path(v359_6,v359_11_head);
          const Space v361_7 = routine_50(c, v361_6, v359_11_tail);
          v360_8 = compose(v360_5,v361_7);
        }
        const Space v360_9 = intersect(constant_1,v360_2);
        const Space v360_10 = (has_head(v360_9) ? constant_2 : Space{});
        Space v360_12;
        if (!v360_10.empty()) {
          const Path v362_6 = concat_path(v359_6,v359_11_head);
          const Space v362_11 = routine_17(c, v362_6, v359_11_tail);
          v360_12 = compose(v360_10,v362_11);
        }
        const Space v360_13 = unite(v360_8,v360_12);
        v359_11_result = unite(v359_11_result,v360_13);
      }
      const Space v359_11 = std::move(v359_11_result);
      v354_12 = compose(v354_10,v359_11);
    }
    const Space v354_13 = unite(v354_8,v354_12);
    v353_11_result = unite(v353_11_result,v354_13);
  }
  const Space v353_11 = std::move(v353_11_result);
  return v353_11;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0) {
  Space v363_8_result;
  for (int v363_8_label = 1; v363_8_label <= 2; ++v363_8_label) {
    const Space v363_8_tail = child(s0,v363_8_label);
    if (v363_8_tail.empty()) continue;
    const Path v363_8_head{v363_8_label};
    const Space v364_2 = singleton(v363_8_head);
    const Space v364_3 = intersect(constant_1,v364_2);
    const Space v364_4 = (has_head(v364_3) ? constant_2 : Space{});
    const Space v364_5 = subtract(constant_0,v364_4);
    Space v364_8;
    if (!v364_5.empty()) {
      const Path v365_6 = concat_path(p0,v363_8_head);
      Space v365_7_result;
      for (int v365_7_label = 1; v365_7_label <= 2; ++v365_7_label) {
        const Space v365_7_tail = child(v363_8_tail,v365_7_label);
        if (v365_7_tail.empty()) continue;
        const Path v365_7_head{v365_7_label};
        const Space v366_2 = singleton(v365_7_head);
        const Space v366_3 = intersect(constant_1,v366_2);
        const Space v366_4 = (has_head(v366_3) ? constant_2 : Space{});
        const Space v366_5 = subtract(constant_0,v366_4);
        Space v366_8;
        if (!v366_5.empty()) {
          const Path v367_6 = concat_path(v365_6,v365_7_head);
          const Space v367_7 = routine_50(c, v367_6, v365_7_tail);
          v366_8 = compose(v366_5,v367_7);
        }
        const Space v366_9 = intersect(constant_1,v366_2);
        const Space v366_10 = (has_head(v366_9) ? constant_2 : Space{});
        Space v366_12;
        if (!v366_10.empty()) {
          const Path v368_6 = concat_path(v365_6,v365_7_head);
          const Space v368_11 = routine_51(c, v368_6, v365_7_tail);
          v366_12 = compose(v366_10,v368_11);
        }
        const Space v366_13 = unite(v366_8,v366_12);
        v365_7_result = unite(v365_7_result,v366_13);
      }
      const Space v365_7 = std::move(v365_7_result);
      v364_8 = compose(v364_5,v365_7);
    }
    const Space v364_9 = intersect(constant_1,v364_2);
    const Space v364_10 = (has_head(v364_9) ? constant_2 : Space{});
    const Space v364_11 = compose(v364_10,v363_8_tail);
    const Space v364_12 = unite(v364_8,v364_11);
    v363_8_result = unite(v363_8_result,v364_12);
  }
  const Space v363_8 = std::move(v363_8_result);
  return v363_8;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v369_12_result;
  for (int v369_12_label = 1; v369_12_label <= 2; ++v369_12_label) {
    const Space v369_12_tail = child(s0,v369_12_label);
    if (v369_12_tail.empty()) continue;
    const Path v369_12_head{v369_12_label};
    const Space v370_2 = singleton(v369_12_head);
    const Space v370_3 = intersect(constant_1,v370_2);
    const Space v370_4 = (has_head(v370_3) ? constant_2 : Space{});
    const Space v370_5 = subtract(constant_0,v370_4);
    Space v370_8;
    if (!v370_5.empty()) {
      const Path v371_6 = concat_path(p0,v369_12_head);
      Space v371_7_result;
      for (int v371_7_label = 1; v371_7_label <= 2; ++v371_7_label) {
        const Space v371_7_tail = child(v369_12_tail,v371_7_label);
        if (v371_7_tail.empty()) continue;
        const Path v371_7_head{v371_7_label};
        const Space v372_2 = singleton(v371_7_head);
        const Space v372_3 = intersect(constant_1,v372_2);
        const Space v372_4 = (has_head(v372_3) ? constant_2 : Space{});
        const Space v372_5 = subtract(constant_0,v372_4);
        Space v372_8;
        if (!v372_5.empty()) {
          const Path v373_6 = concat_path(v371_6,v371_7_head);
          const Space v373_7 = routine_52(c, v373_6, v371_7_tail, s1);
          v372_8 = compose(v372_5,v373_7);
        }
        const Space v372_9 = intersect(constant_1,v372_2);
        const Space v372_10 = (has_head(v372_9) ? constant_2 : Space{});
        Space v372_12;
        if (!v372_10.empty()) {
          const Path v374_6 = concat_path(v371_6,v371_7_head);
          const Space v374_11 = routine_53(c, v374_6, v371_7_tail, s1);
          v372_12 = compose(v372_10,v374_11);
        }
        const Space v372_13 = unite(v372_8,v372_12);
        v371_7_result = unite(v371_7_result,v372_13);
      }
      const Space v371_7 = std::move(v371_7_result);
      v370_8 = compose(v370_5,v371_7);
    }
    const Space v370_9 = intersect(constant_1,v370_2);
    const Space v370_10 = (has_head(v370_9) ? constant_2 : Space{});
    Space v370_12;
    if (!v370_10.empty()) {
      const Path v375_6 = concat_path(p0,v369_12_head);
      Space v375_11_result;
      for (int v375_11_label = 1; v375_11_label <= 2; ++v375_11_label) {
        const Space v375_11_tail = child(v369_12_tail,v375_11_label);
        if (v375_11_tail.empty()) continue;
        const Path v375_11_head{v375_11_label};
        const Space v376_2 = singleton(v375_11_head);
        const Space v376_3 = intersect(constant_1,v376_2);
        const Space v376_4 = (has_head(v376_3) ? constant_2 : Space{});
        const Space v376_5 = subtract(constant_0,v376_4);
        Space v376_8;
        if (!v376_5.empty()) {
          const Path v377_6 = concat_path(v375_6,v375_11_head);
          const Space v377_7 = routine_52(c, v377_6, v375_11_tail, s1);
          v376_8 = compose(v376_5,v377_7);
        }
        const Space v376_9 = intersect(constant_1,v376_2);
        const Space v376_10 = (has_head(v376_9) ? constant_2 : Space{});
        Space v376_12;
        if (!v376_10.empty()) {
          const Path v378_6 = concat_path(v375_6,v375_11_head);
          const Space v378_11 = routine_5(c, v378_6, v375_11_tail, s1);
          v376_12 = compose(v376_10,v378_11);
        }
        const Space v376_13 = unite(v376_8,v376_12);
        v375_11_result = unite(v375_11_result,v376_13);
      }
      const Space v375_11 = std::move(v375_11_result);
      v370_12 = compose(v370_10,v375_11);
    }
    const Space v370_13 = unite(v370_8,v370_12);
    v369_12_result = unite(v369_12_result,v370_13);
  }
  const Space v369_12 = std::move(v369_12_result);
  return v369_12;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v379_7 = unwrap(s1,constant_4);
  const Space v379_9 = unwrap(s1,constant_5);
  const Space v379_10 = unwrap(v379_9,p0);
  const Space v379_12 = unwrap(s1,constant_6);
  Space v379_22_result;
  for (int v379_22_label = 1; v379_22_label <= 2; ++v379_22_label) {
    const Space v379_22_tail = child(s0,v379_22_label);
    if (v379_22_tail.empty()) continue;
    const Path v379_22_head{v379_22_label};
    const Space v380_2 = singleton(v379_22_head);
    const Space v380_3 = intersect(constant_1,v380_2);
    const Space v380_4 = (has_head(v380_3) ? constant_2 : Space{});
    const Space v380_5 = subtract(constant_0,v380_4);
    Space v380_8;
    if (!v380_5.empty()) {
      const Path v381_6 = concat_path(p0,v379_22_head);
      Space v381_7_result;
      for (int v381_7_label = 1; v381_7_label <= 2; ++v381_7_label) {
        const Space v381_7_tail = child(v379_22_tail,v381_7_label);
        if (v381_7_tail.empty()) continue;
        const Path v381_7_head{v381_7_label};
        const Space v382_2 = singleton(v381_7_head);
        const Space v382_3 = intersect(constant_1,v382_2);
        const Space v382_4 = (has_head(v382_3) ? constant_2 : Space{});
        const Space v382_5 = subtract(constant_0,v382_4);
        Space v382_8;
        if (!v382_5.empty()) {
          const Path v383_6 = concat_path(v381_6,v381_7_head);
          const Space v383_7 = routine_52(c, v383_6, v381_7_tail, s1);
          v382_8 = compose(v382_5,v383_7);
        }
        const Space v382_9 = intersect(constant_1,v382_2);
        const Space v382_10 = (has_head(v382_9) ? constant_2 : Space{});
        Space v382_12;
        if (!v382_10.empty()) {
          const Path v384_6 = concat_path(v381_6,v381_7_head);
          const Space v384_11 = routine_53(c, v384_6, v381_7_tail, s1);
          v382_12 = compose(v382_10,v384_11);
        }
        const Space v382_13 = unite(v382_8,v382_12);
        v381_7_result = unite(v381_7_result,v382_13);
      }
      const Space v381_7 = std::move(v381_7_result);
      v380_8 = compose(v380_5,v381_7);
    }
    const Space v380_9 = intersect(constant_1,v380_2);
    const Space v380_10 = (has_head(v380_9) ? constant_2 : Space{});
    Space v380_18;
    if (!v380_10.empty()) {
      const Space v385_11 = unwrap(v379_10,v379_22_head);
      const Space v385_12 = restrict_to(v379_9,v385_11);
      Space v385_13_result;
      for (int v385_13_label = 1; v385_13_label <= 2; ++v385_13_label) {
        const Space v385_13_tail = child(v385_12,v385_13_label);
        if (v385_13_tail.empty()) continue;
        const Path v385_13_head{v385_13_label};
        const Space v386_2 = singleton(v385_13_head);
        const Space v386_3 = intersect(constant_1,v386_2);
        const Space v386_4 = (has_head(v386_3) ? constant_2 : Space{});
        const Space v386_5 = subtract(constant_0,v386_4);
        Space v386_7;
        if (!v386_5.empty()) {
          const Space v387_6 = routine_6(c, v385_13_head, v385_13_tail);
          v386_7 = compose(v386_5,v387_6);
        }
        const Space v386_8 = intersect(constant_1,v386_2);
        const Space v386_9 = (has_head(v386_8) ? constant_2 : Space{});
        Space v386_11;
        if (!v386_9.empty()) {
          const Space v388_10 = routine_7(c, v385_13_head, v385_13_tail);
          v386_11 = compose(v386_9,v388_10);
        }
        const Space v386_12 = unite(v386_7,v386_11);
        v385_13_result = unite(v385_13_result,v386_12);
      }
      const Space v385_13 = std::move(v385_13_result);
      const Space v385_14 = restrict_to(v379_7,v385_13);
      Space v385_15_result;
      for (int v385_15_label = 1; v385_15_label <= 2; ++v385_15_label) {
        const Space v385_15_tail = child(v385_14,v385_15_label);
        if (v385_15_tail.empty()) continue;
        const Path v385_15_head{v385_15_label};
        const Space v389_2 = singleton(v385_15_head);
        const Space v389_3 = intersect(constant_1,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_2 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_7;
        if (!v389_5.empty()) {
          const Space v390_6 = routine_8(c, v385_15_head, v385_15_tail);
          v389_7 = compose(v389_5,v390_6);
        }
        const Space v389_8 = intersect(constant_1,v389_2);
        const Space v389_9 = (has_head(v389_8) ? constant_2 : Space{});
        Space v389_11;
        if (!v389_9.empty()) {
          const Space v391_10 = routine_9(c, v385_15_head, v385_15_tail);
          v389_11 = compose(v389_9,v391_10);
        }
        const Space v389_12 = unite(v389_7,v389_11);
        v385_15_result = unite(v385_15_result,v389_12);
      }
      const Space v385_15 = std::move(v385_15_result);
      const Space v385_16 = subtract(v385_15,v385_11);
      const Space v385_17 = intersect(v385_16,v379_12);
      v380_18 = compose(v380_10,v385_17);
    }
    const Path v392_6 = concat_path(p0,v379_22_head);
    const Space v380_19 = wrap(v380_18,v392_6);
    const Space v380_20 = unite(v380_8,v380_19);
    v379_22_result = unite(v379_22_result,v380_20);
  }
  const Space v379_22 = std::move(v379_22_result);
  return v379_22;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  Space v393_11_result;
  for (int v393_11_label = 1; v393_11_label <= 2; ++v393_11_label) {
    const Space v393_11_tail = child(s0,v393_11_label);
    if (v393_11_tail.empty()) continue;
    const Path v393_11_head{v393_11_label};
    const Space v394_2 = singleton(v393_11_head);
    const Space v394_3 = intersect(constant_1,v394_2);
    const Space v394_4 = (has_head(v394_3) ? constant_2 : Space{});
    const Space v394_5 = subtract(constant_0,v394_4);
    Space v394_8;
    if (!v394_5.empty()) {
      const Path v395_6 = concat_path(p0,v393_11_head);
      Space v395_7_result;
      for (int v395_7_label = 1; v395_7_label <= 2; ++v395_7_label) {
        const Space v395_7_tail = child(v393_11_tail,v395_7_label);
        if (v395_7_tail.empty()) continue;
        const Path v395_7_head{v395_7_label};
        const Space v396_2 = singleton(v395_7_head);
        const Space v396_3 = intersect(constant_1,v396_2);
        const Space v396_4 = (has_head(v396_3) ? constant_2 : Space{});
        const Space v396_5 = subtract(constant_0,v396_4);
        Space v396_8;
        if (!v396_5.empty()) {
          const Path v397_6 = concat_path(v395_6,v395_7_head);
          const Space v397_7 = routine_54(c, v397_6, v395_7_tail);
          v396_8 = compose(v396_5,v397_7);
        }
        const Space v396_9 = intersect(constant_1,v396_2);
        const Space v396_10 = (has_head(v396_9) ? constant_2 : Space{});
        Space v396_12;
        if (!v396_10.empty()) {
          const Path v398_6 = concat_path(v395_6,v395_7_head);
          const Space v398_11 = routine_55(c, v398_6, v395_7_tail);
          v396_12 = compose(v396_10,v398_11);
        }
        const Space v396_13 = unite(v396_8,v396_12);
        v395_7_result = unite(v395_7_result,v396_13);
      }
      const Space v395_7 = std::move(v395_7_result);
      v394_8 = compose(v394_5,v395_7);
    }
    const Space v394_9 = intersect(constant_1,v394_2);
    const Space v394_10 = (has_head(v394_9) ? constant_2 : Space{});
    Space v394_12;
    if (!v394_10.empty()) {
      const Path v399_6 = concat_path(p0,v393_11_head);
      Space v399_11_result;
      for (int v399_11_label = 1; v399_11_label <= 2; ++v399_11_label) {
        const Space v399_11_tail = child(v393_11_tail,v399_11_label);
        if (v399_11_tail.empty()) continue;
        const Path v399_11_head{v399_11_label};
        const Space v400_2 = singleton(v399_11_head);
        const Space v400_3 = intersect(constant_1,v400_2);
        const Space v400_4 = (has_head(v400_3) ? constant_2 : Space{});
        const Space v400_5 = subtract(constant_0,v400_4);
        Space v400_8;
        if (!v400_5.empty()) {
          const Path v401_6 = concat_path(v399_6,v399_11_head);
          const Space v401_7 = routine_54(c, v401_6, v399_11_tail);
          v400_8 = compose(v400_5,v401_7);
        }
        const Space v400_9 = intersect(constant_1,v400_2);
        const Space v400_10 = (has_head(v400_9) ? constant_2 : Space{});
        Space v400_12;
        if (!v400_10.empty()) {
          const Path v402_6 = concat_path(v399_6,v399_11_head);
          const Space v402_11 = routine_14(c, v402_6, v399_11_tail);
          v400_12 = compose(v400_10,v402_11);
        }
        const Space v400_13 = unite(v400_8,v400_12);
        v399_11_result = unite(v399_11_result,v400_13);
      }
      const Space v399_11 = std::move(v399_11_result);
      v394_12 = compose(v394_10,v399_11);
    }
    const Space v394_13 = unite(v394_8,v394_12);
    v393_11_result = unite(v393_11_result,v394_13);
  }
  const Space v393_11 = std::move(v393_11_result);
  return v393_11;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0) {
  Space v403_8_result;
  for (int v403_8_label = 1; v403_8_label <= 2; ++v403_8_label) {
    const Space v403_8_tail = child(s0,v403_8_label);
    if (v403_8_tail.empty()) continue;
    const Path v403_8_head{v403_8_label};
    const Space v404_2 = singleton(v403_8_head);
    const Space v404_3 = intersect(constant_1,v404_2);
    const Space v404_4 = (has_head(v404_3) ? constant_2 : Space{});
    const Space v404_5 = subtract(constant_0,v404_4);
    Space v404_8;
    if (!v404_5.empty()) {
      const Path v405_6 = concat_path(p0,v403_8_head);
      Space v405_7_result;
      for (int v405_7_label = 1; v405_7_label <= 2; ++v405_7_label) {
        const Space v405_7_tail = child(v403_8_tail,v405_7_label);
        if (v405_7_tail.empty()) continue;
        const Path v405_7_head{v405_7_label};
        const Space v406_2 = singleton(v405_7_head);
        const Space v406_3 = intersect(constant_1,v406_2);
        const Space v406_4 = (has_head(v406_3) ? constant_2 : Space{});
        const Space v406_5 = subtract(constant_0,v406_4);
        Space v406_8;
        if (!v406_5.empty()) {
          const Path v407_6 = concat_path(v405_6,v405_7_head);
          const Space v407_7 = routine_54(c, v407_6, v405_7_tail);
          v406_8 = compose(v406_5,v407_7);
        }
        const Space v406_9 = intersect(constant_1,v406_2);
        const Space v406_10 = (has_head(v406_9) ? constant_2 : Space{});
        Space v406_12;
        if (!v406_10.empty()) {
          const Path v408_6 = concat_path(v405_6,v405_7_head);
          const Space v408_11 = routine_55(c, v408_6, v405_7_tail);
          v406_12 = compose(v406_10,v408_11);
        }
        const Space v406_13 = unite(v406_8,v406_12);
        v405_7_result = unite(v405_7_result,v406_13);
      }
      const Space v405_7 = std::move(v405_7_result);
      v404_8 = compose(v404_5,v405_7);
    }
    const Space v404_9 = intersect(constant_1,v404_2);
    const Space v404_10 = (has_head(v404_9) ? constant_2 : Space{});
    const Space v404_11 = compose(v404_10,v403_8_tail);
    const Space v404_12 = unite(v404_8,v404_11);
    v403_8_result = unite(v403_8_result,v404_12);
  }
  const Space v403_8 = std::move(v403_8_result);
  return v403_8;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0) {
  Space v409_11_result;
  for (int v409_11_label = 1; v409_11_label <= 2; ++v409_11_label) {
    const Space v409_11_tail = child(s0,v409_11_label);
    if (v409_11_tail.empty()) continue;
    const Path v409_11_head{v409_11_label};
    const Space v410_2 = singleton(v409_11_head);
    const Space v410_3 = intersect(constant_1,v410_2);
    const Space v410_4 = (has_head(v410_3) ? constant_2 : Space{});
    const Space v410_5 = subtract(constant_0,v410_4);
    Space v410_8;
    if (!v410_5.empty()) {
      const Path v411_6 = concat_path(p0,v409_11_head);
      Space v411_7_result;
      for (int v411_7_label = 1; v411_7_label <= 2; ++v411_7_label) {
        const Space v411_7_tail = child(v409_11_tail,v411_7_label);
        if (v411_7_tail.empty()) continue;
        const Path v411_7_head{v411_7_label};
        const Space v412_2 = singleton(v411_7_head);
        const Space v412_3 = intersect(constant_1,v412_2);
        const Space v412_4 = (has_head(v412_3) ? constant_2 : Space{});
        const Space v412_5 = subtract(constant_0,v412_4);
        Space v412_8;
        if (!v412_5.empty()) {
          const Path v413_6 = concat_path(v411_6,v411_7_head);
          const Space v413_7 = routine_56(c, v413_6, v411_7_tail);
          v412_8 = compose(v412_5,v413_7);
        }
        const Space v412_9 = intersect(constant_1,v412_2);
        const Space v412_10 = (has_head(v412_9) ? constant_2 : Space{});
        Space v412_12;
        if (!v412_10.empty()) {
          const Path v414_6 = concat_path(v411_6,v411_7_head);
          const Space v414_11 = routine_57(c, v414_6, v411_7_tail);
          v412_12 = compose(v412_10,v414_11);
        }
        const Space v412_13 = unite(v412_8,v412_12);
        v411_7_result = unite(v411_7_result,v412_13);
      }
      const Space v411_7 = std::move(v411_7_result);
      v410_8 = compose(v410_5,v411_7);
    }
    const Space v410_9 = intersect(constant_1,v410_2);
    const Space v410_10 = (has_head(v410_9) ? constant_2 : Space{});
    Space v410_12;
    if (!v410_10.empty()) {
      const Path v415_6 = concat_path(p0,v409_11_head);
      Space v415_11_result;
      for (int v415_11_label = 1; v415_11_label <= 2; ++v415_11_label) {
        const Space v415_11_tail = child(v409_11_tail,v415_11_label);
        if (v415_11_tail.empty()) continue;
        const Path v415_11_head{v415_11_label};
        const Space v416_2 = singleton(v415_11_head);
        const Space v416_3 = intersect(constant_1,v416_2);
        const Space v416_4 = (has_head(v416_3) ? constant_2 : Space{});
        const Space v416_5 = subtract(constant_0,v416_4);
        Space v416_8;
        if (!v416_5.empty()) {
          const Path v417_6 = concat_path(v415_6,v415_11_head);
          const Space v417_7 = routine_56(c, v417_6, v415_11_tail);
          v416_8 = compose(v416_5,v417_7);
        }
        const Space v416_9 = intersect(constant_1,v416_2);
        const Space v416_10 = (has_head(v416_9) ? constant_2 : Space{});
        Space v416_12;
        if (!v416_10.empty()) {
          const Path v418_6 = concat_path(v415_6,v415_11_head);
          const Space v418_11 = routine_17(c, v418_6, v415_11_tail);
          v416_12 = compose(v416_10,v418_11);
        }
        const Space v416_13 = unite(v416_8,v416_12);
        v415_11_result = unite(v415_11_result,v416_13);
      }
      const Space v415_11 = std::move(v415_11_result);
      v410_12 = compose(v410_10,v415_11);
    }
    const Space v410_13 = unite(v410_8,v410_12);
    v409_11_result = unite(v409_11_result,v410_13);
  }
  const Space v409_11 = std::move(v409_11_result);
  return v409_11;
}

static Space routine_47(Context& c, const Path& p0, const Space& s0) {
  Space v419_8_result;
  for (int v419_8_label = 1; v419_8_label <= 2; ++v419_8_label) {
    const Space v419_8_tail = child(s0,v419_8_label);
    if (v419_8_tail.empty()) continue;
    const Path v419_8_head{v419_8_label};
    const Space v420_2 = singleton(v419_8_head);
    const Space v420_3 = intersect(constant_1,v420_2);
    const Space v420_4 = (has_head(v420_3) ? constant_2 : Space{});
    const Space v420_5 = subtract(constant_0,v420_4);
    Space v420_8;
    if (!v420_5.empty()) {
      const Path v421_6 = concat_path(p0,v419_8_head);
      Space v421_7_result;
      for (int v421_7_label = 1; v421_7_label <= 2; ++v421_7_label) {
        const Space v421_7_tail = child(v419_8_tail,v421_7_label);
        if (v421_7_tail.empty()) continue;
        const Path v421_7_head{v421_7_label};
        const Space v422_2 = singleton(v421_7_head);
        const Space v422_3 = intersect(constant_1,v422_2);
        const Space v422_4 = (has_head(v422_3) ? constant_2 : Space{});
        const Space v422_5 = subtract(constant_0,v422_4);
        Space v422_8;
        if (!v422_5.empty()) {
          const Path v423_6 = concat_path(v421_6,v421_7_head);
          const Space v423_7 = routine_56(c, v423_6, v421_7_tail);
          v422_8 = compose(v422_5,v423_7);
        }
        const Space v422_9 = intersect(constant_1,v422_2);
        const Space v422_10 = (has_head(v422_9) ? constant_2 : Space{});
        Space v422_12;
        if (!v422_10.empty()) {
          const Path v424_6 = concat_path(v421_6,v421_7_head);
          const Space v424_11 = routine_57(c, v424_6, v421_7_tail);
          v422_12 = compose(v422_10,v424_11);
        }
        const Space v422_13 = unite(v422_8,v422_12);
        v421_7_result = unite(v421_7_result,v422_13);
      }
      const Space v421_7 = std::move(v421_7_result);
      v420_8 = compose(v420_5,v421_7);
    }
    const Space v420_9 = intersect(constant_1,v420_2);
    const Space v420_10 = (has_head(v420_9) ? constant_2 : Space{});
    const Space v420_11 = compose(v420_10,v419_8_tail);
    const Space v420_12 = unite(v420_8,v420_11);
    v419_8_result = unite(v419_8_result,v420_12);
  }
  const Space v419_8 = std::move(v419_8_result);
  return v419_8;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v425_11_result;
  for (int v425_11_label = 1; v425_11_label <= 2; ++v425_11_label) {
    const Space v425_11_tail = child(s0,v425_11_label);
    if (v425_11_tail.empty()) continue;
    const Path v425_11_head{v425_11_label};
    const Space v426_2 = singleton(v425_11_head);
    const Space v426_3 = intersect(constant_1,v426_2);
    const Space v426_4 = (has_head(v426_3) ? constant_2 : Space{});
    const Space v426_5 = subtract(constant_0,v426_4);
    Space v426_8;
    if (!v426_5.empty()) {
      const Path v427_6 = concat_path(p0,v425_11_head);
      Space v427_7_result;
      for (int v427_7_label = 1; v427_7_label <= 2; ++v427_7_label) {
        const Space v427_7_tail = child(v425_11_tail,v427_7_label);
        if (v427_7_tail.empty()) continue;
        const Path v427_7_head{v427_7_label};
        const Space v428_2 = singleton(v427_7_head);
        const Space v428_3 = intersect(constant_1,v428_2);
        const Space v428_4 = (has_head(v428_3) ? constant_2 : Space{});
        const Space v428_5 = subtract(constant_0,v428_4);
        Space v428_8;
        if (!v428_5.empty()) {
          const Path v429_6 = concat_path(v427_6,v427_7_head);
          const Space v429_7 = routine_58(c, v429_6, v427_7_tail);
          v428_8 = compose(v428_5,v429_7);
        }
        const Space v428_9 = intersect(constant_1,v428_2);
        const Space v428_10 = (has_head(v428_9) ? constant_2 : Space{});
        Space v428_12;
        if (!v428_10.empty()) {
          const Path v430_6 = concat_path(v427_6,v427_7_head);
          const Space v430_11 = routine_59(c, v430_6, v427_7_tail);
          v428_12 = compose(v428_10,v430_11);
        }
        const Space v428_13 = unite(v428_8,v428_12);
        v427_7_result = unite(v427_7_result,v428_13);
      }
      const Space v427_7 = std::move(v427_7_result);
      v426_8 = compose(v426_5,v427_7);
    }
    const Space v426_9 = intersect(constant_1,v426_2);
    const Space v426_10 = (has_head(v426_9) ? constant_2 : Space{});
    Space v426_12;
    if (!v426_10.empty()) {
      const Path v431_6 = concat_path(p0,v425_11_head);
      Space v431_11_result;
      for (int v431_11_label = 1; v431_11_label <= 2; ++v431_11_label) {
        const Space v431_11_tail = child(v425_11_tail,v431_11_label);
        if (v431_11_tail.empty()) continue;
        const Path v431_11_head{v431_11_label};
        const Space v432_2 = singleton(v431_11_head);
        const Space v432_3 = intersect(constant_1,v432_2);
        const Space v432_4 = (has_head(v432_3) ? constant_2 : Space{});
        const Space v432_5 = subtract(constant_0,v432_4);
        Space v432_8;
        if (!v432_5.empty()) {
          const Path v433_6 = concat_path(v431_6,v431_11_head);
          const Space v433_7 = routine_58(c, v433_6, v431_11_tail);
          v432_8 = compose(v432_5,v433_7);
        }
        const Space v432_9 = intersect(constant_1,v432_2);
        const Space v432_10 = (has_head(v432_9) ? constant_2 : Space{});
        Space v432_12;
        if (!v432_10.empty()) {
          const Path v434_6 = concat_path(v431_6,v431_11_head);
          const Space v434_11 = routine_14(c, v434_6, v431_11_tail);
          v432_12 = compose(v432_10,v434_11);
        }
        const Space v432_13 = unite(v432_8,v432_12);
        v431_11_result = unite(v431_11_result,v432_13);
      }
      const Space v431_11 = std::move(v431_11_result);
      v426_12 = compose(v426_10,v431_11);
    }
    const Space v426_13 = unite(v426_8,v426_12);
    v425_11_result = unite(v425_11_result,v426_13);
  }
  const Space v425_11 = std::move(v425_11_result);
  return v425_11;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v435_8_result;
  for (int v435_8_label = 1; v435_8_label <= 2; ++v435_8_label) {
    const Space v435_8_tail = child(s0,v435_8_label);
    if (v435_8_tail.empty()) continue;
    const Path v435_8_head{v435_8_label};
    const Space v436_2 = singleton(v435_8_head);
    const Space v436_3 = intersect(constant_1,v436_2);
    const Space v436_4 = (has_head(v436_3) ? constant_2 : Space{});
    const Space v436_5 = subtract(constant_0,v436_4);
    Space v436_8;
    if (!v436_5.empty()) {
      const Path v437_6 = concat_path(p0,v435_8_head);
      Space v437_7_result;
      for (int v437_7_label = 1; v437_7_label <= 2; ++v437_7_label) {
        const Space v437_7_tail = child(v435_8_tail,v437_7_label);
        if (v437_7_tail.empty()) continue;
        const Path v437_7_head{v437_7_label};
        const Space v438_2 = singleton(v437_7_head);
        const Space v438_3 = intersect(constant_1,v438_2);
        const Space v438_4 = (has_head(v438_3) ? constant_2 : Space{});
        const Space v438_5 = subtract(constant_0,v438_4);
        Space v438_8;
        if (!v438_5.empty()) {
          const Path v439_6 = concat_path(v437_6,v437_7_head);
          const Space v439_7 = routine_58(c, v439_6, v437_7_tail);
          v438_8 = compose(v438_5,v439_7);
        }
        const Space v438_9 = intersect(constant_1,v438_2);
        const Space v438_10 = (has_head(v438_9) ? constant_2 : Space{});
        Space v438_12;
        if (!v438_10.empty()) {
          const Path v440_6 = concat_path(v437_6,v437_7_head);
          const Space v440_11 = routine_59(c, v440_6, v437_7_tail);
          v438_12 = compose(v438_10,v440_11);
        }
        const Space v438_13 = unite(v438_8,v438_12);
        v437_7_result = unite(v437_7_result,v438_13);
      }
      const Space v437_7 = std::move(v437_7_result);
      v436_8 = compose(v436_5,v437_7);
    }
    const Space v436_9 = intersect(constant_1,v436_2);
    const Space v436_10 = (has_head(v436_9) ? constant_2 : Space{});
    const Space v436_11 = compose(v436_10,v435_8_tail);
    const Space v436_12 = unite(v436_8,v436_11);
    v435_8_result = unite(v435_8_result,v436_12);
  }
  const Space v435_8 = std::move(v435_8_result);
  return v435_8;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v441_11_result;
  for (int v441_11_label = 1; v441_11_label <= 2; ++v441_11_label) {
    const Space v441_11_tail = child(s0,v441_11_label);
    if (v441_11_tail.empty()) continue;
    const Path v441_11_head{v441_11_label};
    const Space v442_2 = singleton(v441_11_head);
    const Space v442_3 = intersect(constant_1,v442_2);
    const Space v442_4 = (has_head(v442_3) ? constant_2 : Space{});
    const Space v442_5 = subtract(constant_0,v442_4);
    Space v442_8;
    if (!v442_5.empty()) {
      const Path v443_6 = concat_path(p0,v441_11_head);
      Space v443_7_result;
      for (int v443_7_label = 1; v443_7_label <= 2; ++v443_7_label) {
        const Space v443_7_tail = child(v441_11_tail,v443_7_label);
        if (v443_7_tail.empty()) continue;
        const Path v443_7_head{v443_7_label};
        const Space v444_2 = singleton(v443_7_head);
        const Space v444_3 = intersect(constant_1,v444_2);
        const Space v444_4 = (has_head(v444_3) ? constant_2 : Space{});
        const Space v444_5 = subtract(constant_0,v444_4);
        Space v444_8;
        if (!v444_5.empty()) {
          const Path v445_6 = concat_path(v443_6,v443_7_head);
          const Space v445_7 = routine_60(c, v445_6, v443_7_tail);
          v444_8 = compose(v444_5,v445_7);
        }
        const Space v444_9 = intersect(constant_1,v444_2);
        const Space v444_10 = (has_head(v444_9) ? constant_2 : Space{});
        Space v444_12;
        if (!v444_10.empty()) {
          const Path v446_6 = concat_path(v443_6,v443_7_head);
          const Space v446_11 = routine_61(c, v446_6, v443_7_tail);
          v444_12 = compose(v444_10,v446_11);
        }
        const Space v444_13 = unite(v444_8,v444_12);
        v443_7_result = unite(v443_7_result,v444_13);
      }
      const Space v443_7 = std::move(v443_7_result);
      v442_8 = compose(v442_5,v443_7);
    }
    const Space v442_9 = intersect(constant_1,v442_2);
    const Space v442_10 = (has_head(v442_9) ? constant_2 : Space{});
    Space v442_12;
    if (!v442_10.empty()) {
      const Path v447_6 = concat_path(p0,v441_11_head);
      Space v447_11_result;
      for (int v447_11_label = 1; v447_11_label <= 2; ++v447_11_label) {
        const Space v447_11_tail = child(v441_11_tail,v447_11_label);
        if (v447_11_tail.empty()) continue;
        const Path v447_11_head{v447_11_label};
        const Space v448_2 = singleton(v447_11_head);
        const Space v448_3 = intersect(constant_1,v448_2);
        const Space v448_4 = (has_head(v448_3) ? constant_2 : Space{});
        const Space v448_5 = subtract(constant_0,v448_4);
        Space v448_8;
        if (!v448_5.empty()) {
          const Path v449_6 = concat_path(v447_6,v447_11_head);
          const Space v449_7 = routine_60(c, v449_6, v447_11_tail);
          v448_8 = compose(v448_5,v449_7);
        }
        const Space v448_9 = intersect(constant_1,v448_2);
        const Space v448_10 = (has_head(v448_9) ? constant_2 : Space{});
        Space v448_12;
        if (!v448_10.empty()) {
          const Path v450_6 = concat_path(v447_6,v447_11_head);
          const Space v450_11 = routine_17(c, v450_6, v447_11_tail);
          v448_12 = compose(v448_10,v450_11);
        }
        const Space v448_13 = unite(v448_8,v448_12);
        v447_11_result = unite(v447_11_result,v448_13);
      }
      const Space v447_11 = std::move(v447_11_result);
      v442_12 = compose(v442_10,v447_11);
    }
    const Space v442_13 = unite(v442_8,v442_12);
    v441_11_result = unite(v441_11_result,v442_13);
  }
  const Space v441_11 = std::move(v441_11_result);
  return v441_11;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v451_8_result;
  for (int v451_8_label = 1; v451_8_label <= 2; ++v451_8_label) {
    const Space v451_8_tail = child(s0,v451_8_label);
    if (v451_8_tail.empty()) continue;
    const Path v451_8_head{v451_8_label};
    const Space v452_2 = singleton(v451_8_head);
    const Space v452_3 = intersect(constant_1,v452_2);
    const Space v452_4 = (has_head(v452_3) ? constant_2 : Space{});
    const Space v452_5 = subtract(constant_0,v452_4);
    Space v452_8;
    if (!v452_5.empty()) {
      const Path v453_6 = concat_path(p0,v451_8_head);
      Space v453_7_result;
      for (int v453_7_label = 1; v453_7_label <= 2; ++v453_7_label) {
        const Space v453_7_tail = child(v451_8_tail,v453_7_label);
        if (v453_7_tail.empty()) continue;
        const Path v453_7_head{v453_7_label};
        const Space v454_2 = singleton(v453_7_head);
        const Space v454_3 = intersect(constant_1,v454_2);
        const Space v454_4 = (has_head(v454_3) ? constant_2 : Space{});
        const Space v454_5 = subtract(constant_0,v454_4);
        Space v454_8;
        if (!v454_5.empty()) {
          const Path v455_6 = concat_path(v453_6,v453_7_head);
          const Space v455_7 = routine_60(c, v455_6, v453_7_tail);
          v454_8 = compose(v454_5,v455_7);
        }
        const Space v454_9 = intersect(constant_1,v454_2);
        const Space v454_10 = (has_head(v454_9) ? constant_2 : Space{});
        Space v454_12;
        if (!v454_10.empty()) {
          const Path v456_6 = concat_path(v453_6,v453_7_head);
          const Space v456_11 = routine_61(c, v456_6, v453_7_tail);
          v454_12 = compose(v454_10,v456_11);
        }
        const Space v454_13 = unite(v454_8,v454_12);
        v453_7_result = unite(v453_7_result,v454_13);
      }
      const Space v453_7 = std::move(v453_7_result);
      v452_8 = compose(v452_5,v453_7);
    }
    const Space v452_9 = intersect(constant_1,v452_2);
    const Space v452_10 = (has_head(v452_9) ? constant_2 : Space{});
    const Space v452_11 = compose(v452_10,v451_8_tail);
    const Space v452_12 = unite(v452_8,v452_11);
    v451_8_result = unite(v451_8_result,v452_12);
  }
  const Space v451_8 = std::move(v451_8_result);
  return v451_8;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v457_12_result;
  for (int v457_12_label = 1; v457_12_label <= 2; ++v457_12_label) {
    const Space v457_12_tail = child(s0,v457_12_label);
    if (v457_12_tail.empty()) continue;
    const Path v457_12_head{v457_12_label};
    const Space v458_2 = singleton(v457_12_head);
    const Space v458_3 = intersect(constant_1,v458_2);
    const Space v458_4 = (has_head(v458_3) ? constant_2 : Space{});
    const Space v458_5 = subtract(constant_0,v458_4);
    Space v458_8;
    if (!v458_5.empty()) {
      const Path v459_6 = concat_path(p0,v457_12_head);
      Space v459_7_result;
      for (int v459_7_label = 1; v459_7_label <= 2; ++v459_7_label) {
        const Space v459_7_tail = child(v457_12_tail,v459_7_label);
        if (v459_7_tail.empty()) continue;
        const Path v459_7_head{v459_7_label};
        const Space v460_2 = singleton(v459_7_head);
        const Space v460_3 = intersect(constant_1,v460_2);
        const Space v460_4 = (has_head(v460_3) ? constant_2 : Space{});
        const Space v460_5 = subtract(constant_0,v460_4);
        Space v460_8;
        if (!v460_5.empty()) {
          const Path v461_6 = concat_path(v459_6,v459_7_head);
          const Space v461_7 = routine_62(c, v461_6, v459_7_tail, s1);
          v460_8 = compose(v460_5,v461_7);
        }
        const Space v460_9 = intersect(constant_1,v460_2);
        const Space v460_10 = (has_head(v460_9) ? constant_2 : Space{});
        Space v460_12;
        if (!v460_10.empty()) {
          const Path v462_6 = concat_path(v459_6,v459_7_head);
          const Space v462_11 = routine_63(c, v462_6, v459_7_tail, s1);
          v460_12 = compose(v460_10,v462_11);
        }
        const Space v460_13 = unite(v460_8,v460_12);
        v459_7_result = unite(v459_7_result,v460_13);
      }
      const Space v459_7 = std::move(v459_7_result);
      v458_8 = compose(v458_5,v459_7);
    }
    const Space v458_9 = intersect(constant_1,v458_2);
    const Space v458_10 = (has_head(v458_9) ? constant_2 : Space{});
    Space v458_12;
    if (!v458_10.empty()) {
      const Path v463_6 = concat_path(p0,v457_12_head);
      Space v463_11_result;
      for (int v463_11_label = 1; v463_11_label <= 2; ++v463_11_label) {
        const Space v463_11_tail = child(v457_12_tail,v463_11_label);
        if (v463_11_tail.empty()) continue;
        const Path v463_11_head{v463_11_label};
        const Space v464_2 = singleton(v463_11_head);
        const Space v464_3 = intersect(constant_1,v464_2);
        const Space v464_4 = (has_head(v464_3) ? constant_2 : Space{});
        const Space v464_5 = subtract(constant_0,v464_4);
        Space v464_8;
        if (!v464_5.empty()) {
          const Path v465_6 = concat_path(v463_6,v463_11_head);
          const Space v465_7 = routine_62(c, v465_6, v463_11_tail, s1);
          v464_8 = compose(v464_5,v465_7);
        }
        const Space v464_9 = intersect(constant_1,v464_2);
        const Space v464_10 = (has_head(v464_9) ? constant_2 : Space{});
        Space v464_12;
        if (!v464_10.empty()) {
          const Path v466_6 = concat_path(v463_6,v463_11_head);
          const Space v466_11 = routine_5(c, v466_6, v463_11_tail, s1);
          v464_12 = compose(v464_10,v466_11);
        }
        const Space v464_13 = unite(v464_8,v464_12);
        v463_11_result = unite(v463_11_result,v464_13);
      }
      const Space v463_11 = std::move(v463_11_result);
      v458_12 = compose(v458_10,v463_11);
    }
    const Space v458_13 = unite(v458_8,v458_12);
    v457_12_result = unite(v457_12_result,v458_13);
  }
  const Space v457_12 = std::move(v457_12_result);
  return v457_12;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v467_7 = unwrap(s1,constant_4);
  const Space v467_9 = unwrap(s1,constant_5);
  const Space v467_10 = unwrap(v467_9,p0);
  const Space v467_12 = unwrap(s1,constant_6);
  Space v467_22_result;
  for (int v467_22_label = 1; v467_22_label <= 2; ++v467_22_label) {
    const Space v467_22_tail = child(s0,v467_22_label);
    if (v467_22_tail.empty()) continue;
    const Path v467_22_head{v467_22_label};
    const Space v468_2 = singleton(v467_22_head);
    const Space v468_3 = intersect(constant_1,v468_2);
    const Space v468_4 = (has_head(v468_3) ? constant_2 : Space{});
    const Space v468_5 = subtract(constant_0,v468_4);
    Space v468_8;
    if (!v468_5.empty()) {
      const Path v469_6 = concat_path(p0,v467_22_head);
      Space v469_7_result;
      for (int v469_7_label = 1; v469_7_label <= 2; ++v469_7_label) {
        const Space v469_7_tail = child(v467_22_tail,v469_7_label);
        if (v469_7_tail.empty()) continue;
        const Path v469_7_head{v469_7_label};
        const Space v470_2 = singleton(v469_7_head);
        const Space v470_3 = intersect(constant_1,v470_2);
        const Space v470_4 = (has_head(v470_3) ? constant_2 : Space{});
        const Space v470_5 = subtract(constant_0,v470_4);
        Space v470_8;
        if (!v470_5.empty()) {
          const Path v471_6 = concat_path(v469_6,v469_7_head);
          const Space v471_7 = routine_62(c, v471_6, v469_7_tail, s1);
          v470_8 = compose(v470_5,v471_7);
        }
        const Space v470_9 = intersect(constant_1,v470_2);
        const Space v470_10 = (has_head(v470_9) ? constant_2 : Space{});
        Space v470_12;
        if (!v470_10.empty()) {
          const Path v472_6 = concat_path(v469_6,v469_7_head);
          const Space v472_11 = routine_63(c, v472_6, v469_7_tail, s1);
          v470_12 = compose(v470_10,v472_11);
        }
        const Space v470_13 = unite(v470_8,v470_12);
        v469_7_result = unite(v469_7_result,v470_13);
      }
      const Space v469_7 = std::move(v469_7_result);
      v468_8 = compose(v468_5,v469_7);
    }
    const Space v468_9 = intersect(constant_1,v468_2);
    const Space v468_10 = (has_head(v468_9) ? constant_2 : Space{});
    Space v468_18;
    if (!v468_10.empty()) {
      const Space v473_11 = unwrap(v467_10,v467_22_head);
      const Space v473_12 = restrict_to(v467_9,v473_11);
      Space v473_13_result;
      for (int v473_13_label = 1; v473_13_label <= 2; ++v473_13_label) {
        const Space v473_13_tail = child(v473_12,v473_13_label);
        if (v473_13_tail.empty()) continue;
        const Path v473_13_head{v473_13_label};
        const Space v474_2 = singleton(v473_13_head);
        const Space v474_3 = intersect(constant_1,v474_2);
        const Space v474_4 = (has_head(v474_3) ? constant_2 : Space{});
        const Space v474_5 = subtract(constant_0,v474_4);
        Space v474_7;
        if (!v474_5.empty()) {
          const Space v475_6 = routine_6(c, v473_13_head, v473_13_tail);
          v474_7 = compose(v474_5,v475_6);
        }
        const Space v474_8 = intersect(constant_1,v474_2);
        const Space v474_9 = (has_head(v474_8) ? constant_2 : Space{});
        Space v474_11;
        if (!v474_9.empty()) {
          const Space v476_10 = routine_7(c, v473_13_head, v473_13_tail);
          v474_11 = compose(v474_9,v476_10);
        }
        const Space v474_12 = unite(v474_7,v474_11);
        v473_13_result = unite(v473_13_result,v474_12);
      }
      const Space v473_13 = std::move(v473_13_result);
      const Space v473_14 = restrict_to(v467_7,v473_13);
      Space v473_15_result;
      for (int v473_15_label = 1; v473_15_label <= 2; ++v473_15_label) {
        const Space v473_15_tail = child(v473_14,v473_15_label);
        if (v473_15_tail.empty()) continue;
        const Path v473_15_head{v473_15_label};
        const Space v477_2 = singleton(v473_15_head);
        const Space v477_3 = intersect(constant_1,v477_2);
        const Space v477_4 = (has_head(v477_3) ? constant_2 : Space{});
        const Space v477_5 = subtract(constant_0,v477_4);
        Space v477_7;
        if (!v477_5.empty()) {
          const Space v478_6 = routine_8(c, v473_15_head, v473_15_tail);
          v477_7 = compose(v477_5,v478_6);
        }
        const Space v477_8 = intersect(constant_1,v477_2);
        const Space v477_9 = (has_head(v477_8) ? constant_2 : Space{});
        Space v477_11;
        if (!v477_9.empty()) {
          const Space v479_10 = routine_9(c, v473_15_head, v473_15_tail);
          v477_11 = compose(v477_9,v479_10);
        }
        const Space v477_12 = unite(v477_7,v477_11);
        v473_15_result = unite(v473_15_result,v477_12);
      }
      const Space v473_15 = std::move(v473_15_result);
      const Space v473_16 = subtract(v473_15,v473_11);
      const Space v473_17 = intersect(v473_16,v467_12);
      v468_18 = compose(v468_10,v473_17);
    }
    const Path v480_6 = concat_path(p0,v467_22_head);
    const Space v468_19 = wrap(v468_18,v480_6);
    const Space v468_20 = unite(v468_8,v468_19);
    v467_22_result = unite(v467_22_result,v468_20);
  }
  const Space v467_22 = std::move(v467_22_result);
  return v467_22;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0) {
  Space v481_11_result;
  for (int v481_11_label = 1; v481_11_label <= 2; ++v481_11_label) {
    const Space v481_11_tail = child(s0,v481_11_label);
    if (v481_11_tail.empty()) continue;
    const Path v481_11_head{v481_11_label};
    const Space v482_2 = singleton(v481_11_head);
    const Space v482_3 = intersect(constant_1,v482_2);
    const Space v482_4 = (has_head(v482_3) ? constant_2 : Space{});
    const Space v482_5 = subtract(constant_0,v482_4);
    Space v482_8;
    if (!v482_5.empty()) {
      const Path v483_6 = concat_path(p0,v481_11_head);
      Space v483_7_result;
      for (int v483_7_label = 1; v483_7_label <= 2; ++v483_7_label) {
        const Space v483_7_tail = child(v481_11_tail,v483_7_label);
        if (v483_7_tail.empty()) continue;
        const Path v483_7_head{v483_7_label};
        const Space v484_2 = singleton(v483_7_head);
        const Space v484_3 = intersect(constant_1,v484_2);
        const Space v484_4 = (has_head(v484_3) ? constant_2 : Space{});
        const Space v484_5 = subtract(constant_0,v484_4);
        Space v484_8;
        if (!v484_5.empty()) {
          const Path v485_6 = concat_path(v483_6,v483_7_head);
          const Space v485_7 = routine_64(c, v485_6, v483_7_tail);
          v484_8 = compose(v484_5,v485_7);
        }
        const Space v484_9 = intersect(constant_1,v484_2);
        const Space v484_10 = (has_head(v484_9) ? constant_2 : Space{});
        Space v484_12;
        if (!v484_10.empty()) {
          const Path v486_6 = concat_path(v483_6,v483_7_head);
          const Space v486_11 = routine_65(c, v486_6, v483_7_tail);
          v484_12 = compose(v484_10,v486_11);
        }
        const Space v484_13 = unite(v484_8,v484_12);
        v483_7_result = unite(v483_7_result,v484_13);
      }
      const Space v483_7 = std::move(v483_7_result);
      v482_8 = compose(v482_5,v483_7);
    }
    const Space v482_9 = intersect(constant_1,v482_2);
    const Space v482_10 = (has_head(v482_9) ? constant_2 : Space{});
    Space v482_12;
    if (!v482_10.empty()) {
      const Path v487_6 = concat_path(p0,v481_11_head);
      Space v487_11_result;
      for (int v487_11_label = 1; v487_11_label <= 2; ++v487_11_label) {
        const Space v487_11_tail = child(v481_11_tail,v487_11_label);
        if (v487_11_tail.empty()) continue;
        const Path v487_11_head{v487_11_label};
        const Space v488_2 = singleton(v487_11_head);
        const Space v488_3 = intersect(constant_1,v488_2);
        const Space v488_4 = (has_head(v488_3) ? constant_2 : Space{});
        const Space v488_5 = subtract(constant_0,v488_4);
        Space v488_8;
        if (!v488_5.empty()) {
          const Path v489_6 = concat_path(v487_6,v487_11_head);
          const Space v489_7 = routine_64(c, v489_6, v487_11_tail);
          v488_8 = compose(v488_5,v489_7);
        }
        const Space v488_9 = intersect(constant_1,v488_2);
        const Space v488_10 = (has_head(v488_9) ? constant_2 : Space{});
        Space v488_12;
        if (!v488_10.empty()) {
          const Path v490_6 = concat_path(v487_6,v487_11_head);
          const Space v490_11 = routine_14(c, v490_6, v487_11_tail);
          v488_12 = compose(v488_10,v490_11);
        }
        const Space v488_13 = unite(v488_8,v488_12);
        v487_11_result = unite(v487_11_result,v488_13);
      }
      const Space v487_11 = std::move(v487_11_result);
      v482_12 = compose(v482_10,v487_11);
    }
    const Space v482_13 = unite(v482_8,v482_12);
    v481_11_result = unite(v481_11_result,v482_13);
  }
  const Space v481_11 = std::move(v481_11_result);
  return v481_11;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v491_8_result;
  for (int v491_8_label = 1; v491_8_label <= 2; ++v491_8_label) {
    const Space v491_8_tail = child(s0,v491_8_label);
    if (v491_8_tail.empty()) continue;
    const Path v491_8_head{v491_8_label};
    const Space v492_2 = singleton(v491_8_head);
    const Space v492_3 = intersect(constant_1,v492_2);
    const Space v492_4 = (has_head(v492_3) ? constant_2 : Space{});
    const Space v492_5 = subtract(constant_0,v492_4);
    Space v492_8;
    if (!v492_5.empty()) {
      const Path v493_6 = concat_path(p0,v491_8_head);
      Space v493_7_result;
      for (int v493_7_label = 1; v493_7_label <= 2; ++v493_7_label) {
        const Space v493_7_tail = child(v491_8_tail,v493_7_label);
        if (v493_7_tail.empty()) continue;
        const Path v493_7_head{v493_7_label};
        const Space v494_2 = singleton(v493_7_head);
        const Space v494_3 = intersect(constant_1,v494_2);
        const Space v494_4 = (has_head(v494_3) ? constant_2 : Space{});
        const Space v494_5 = subtract(constant_0,v494_4);
        Space v494_8;
        if (!v494_5.empty()) {
          const Path v495_6 = concat_path(v493_6,v493_7_head);
          const Space v495_7 = routine_64(c, v495_6, v493_7_tail);
          v494_8 = compose(v494_5,v495_7);
        }
        const Space v494_9 = intersect(constant_1,v494_2);
        const Space v494_10 = (has_head(v494_9) ? constant_2 : Space{});
        Space v494_12;
        if (!v494_10.empty()) {
          const Path v496_6 = concat_path(v493_6,v493_7_head);
          const Space v496_11 = routine_65(c, v496_6, v493_7_tail);
          v494_12 = compose(v494_10,v496_11);
        }
        const Space v494_13 = unite(v494_8,v494_12);
        v493_7_result = unite(v493_7_result,v494_13);
      }
      const Space v493_7 = std::move(v493_7_result);
      v492_8 = compose(v492_5,v493_7);
    }
    const Space v492_9 = intersect(constant_1,v492_2);
    const Space v492_10 = (has_head(v492_9) ? constant_2 : Space{});
    const Space v492_11 = compose(v492_10,v491_8_tail);
    const Space v492_12 = unite(v492_8,v492_11);
    v491_8_result = unite(v491_8_result,v492_12);
  }
  const Space v491_8 = std::move(v491_8_result);
  return v491_8;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v497_11_result;
  for (int v497_11_label = 1; v497_11_label <= 2; ++v497_11_label) {
    const Space v497_11_tail = child(s0,v497_11_label);
    if (v497_11_tail.empty()) continue;
    const Path v497_11_head{v497_11_label};
    const Space v498_2 = singleton(v497_11_head);
    const Space v498_3 = intersect(constant_1,v498_2);
    const Space v498_4 = (has_head(v498_3) ? constant_2 : Space{});
    const Space v498_5 = subtract(constant_0,v498_4);
    Space v498_8;
    if (!v498_5.empty()) {
      const Path v499_6 = concat_path(p0,v497_11_head);
      Space v499_7_result;
      for (int v499_7_label = 1; v499_7_label <= 2; ++v499_7_label) {
        const Space v499_7_tail = child(v497_11_tail,v499_7_label);
        if (v499_7_tail.empty()) continue;
        const Path v499_7_head{v499_7_label};
        const Space v500_2 = singleton(v499_7_head);
        const Space v500_3 = intersect(constant_1,v500_2);
        const Space v500_4 = (has_head(v500_3) ? constant_2 : Space{});
        const Space v500_5 = subtract(constant_0,v500_4);
        Space v500_8;
        if (!v500_5.empty()) {
          const Path v501_6 = concat_path(v499_6,v499_7_head);
          const Space v501_7 = routine_66(c, v501_6, v499_7_tail);
          v500_8 = compose(v500_5,v501_7);
        }
        const Space v500_9 = intersect(constant_1,v500_2);
        const Space v500_10 = (has_head(v500_9) ? constant_2 : Space{});
        Space v500_12;
        if (!v500_10.empty()) {
          const Path v502_6 = concat_path(v499_6,v499_7_head);
          const Space v502_11 = routine_67(c, v502_6, v499_7_tail);
          v500_12 = compose(v500_10,v502_11);
        }
        const Space v500_13 = unite(v500_8,v500_12);
        v499_7_result = unite(v499_7_result,v500_13);
      }
      const Space v499_7 = std::move(v499_7_result);
      v498_8 = compose(v498_5,v499_7);
    }
    const Space v498_9 = intersect(constant_1,v498_2);
    const Space v498_10 = (has_head(v498_9) ? constant_2 : Space{});
    Space v498_12;
    if (!v498_10.empty()) {
      const Path v503_6 = concat_path(p0,v497_11_head);
      Space v503_11_result;
      for (int v503_11_label = 1; v503_11_label <= 2; ++v503_11_label) {
        const Space v503_11_tail = child(v497_11_tail,v503_11_label);
        if (v503_11_tail.empty()) continue;
        const Path v503_11_head{v503_11_label};
        const Space v504_2 = singleton(v503_11_head);
        const Space v504_3 = intersect(constant_1,v504_2);
        const Space v504_4 = (has_head(v504_3) ? constant_2 : Space{});
        const Space v504_5 = subtract(constant_0,v504_4);
        Space v504_8;
        if (!v504_5.empty()) {
          const Path v505_6 = concat_path(v503_6,v503_11_head);
          const Space v505_7 = routine_66(c, v505_6, v503_11_tail);
          v504_8 = compose(v504_5,v505_7);
        }
        const Space v504_9 = intersect(constant_1,v504_2);
        const Space v504_10 = (has_head(v504_9) ? constant_2 : Space{});
        Space v504_12;
        if (!v504_10.empty()) {
          const Path v506_6 = concat_path(v503_6,v503_11_head);
          const Space v506_11 = routine_17(c, v506_6, v503_11_tail);
          v504_12 = compose(v504_10,v506_11);
        }
        const Space v504_13 = unite(v504_8,v504_12);
        v503_11_result = unite(v503_11_result,v504_13);
      }
      const Space v503_11 = std::move(v503_11_result);
      v498_12 = compose(v498_10,v503_11);
    }
    const Space v498_13 = unite(v498_8,v498_12);
    v497_11_result = unite(v497_11_result,v498_13);
  }
  const Space v497_11 = std::move(v497_11_result);
  return v497_11;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v507_8_result;
  for (int v507_8_label = 1; v507_8_label <= 2; ++v507_8_label) {
    const Space v507_8_tail = child(s0,v507_8_label);
    if (v507_8_tail.empty()) continue;
    const Path v507_8_head{v507_8_label};
    const Space v508_2 = singleton(v507_8_head);
    const Space v508_3 = intersect(constant_1,v508_2);
    const Space v508_4 = (has_head(v508_3) ? constant_2 : Space{});
    const Space v508_5 = subtract(constant_0,v508_4);
    Space v508_8;
    if (!v508_5.empty()) {
      const Path v509_6 = concat_path(p0,v507_8_head);
      Space v509_7_result;
      for (int v509_7_label = 1; v509_7_label <= 2; ++v509_7_label) {
        const Space v509_7_tail = child(v507_8_tail,v509_7_label);
        if (v509_7_tail.empty()) continue;
        const Path v509_7_head{v509_7_label};
        const Space v510_2 = singleton(v509_7_head);
        const Space v510_3 = intersect(constant_1,v510_2);
        const Space v510_4 = (has_head(v510_3) ? constant_2 : Space{});
        const Space v510_5 = subtract(constant_0,v510_4);
        Space v510_8;
        if (!v510_5.empty()) {
          const Path v511_6 = concat_path(v509_6,v509_7_head);
          const Space v511_7 = routine_66(c, v511_6, v509_7_tail);
          v510_8 = compose(v510_5,v511_7);
        }
        const Space v510_9 = intersect(constant_1,v510_2);
        const Space v510_10 = (has_head(v510_9) ? constant_2 : Space{});
        Space v510_12;
        if (!v510_10.empty()) {
          const Path v512_6 = concat_path(v509_6,v509_7_head);
          const Space v512_11 = routine_67(c, v512_6, v509_7_tail);
          v510_12 = compose(v510_10,v512_11);
        }
        const Space v510_13 = unite(v510_8,v510_12);
        v509_7_result = unite(v509_7_result,v510_13);
      }
      const Space v509_7 = std::move(v509_7_result);
      v508_8 = compose(v508_5,v509_7);
    }
    const Space v508_9 = intersect(constant_1,v508_2);
    const Space v508_10 = (has_head(v508_9) ? constant_2 : Space{});
    const Space v508_11 = compose(v508_10,v507_8_tail);
    const Space v508_12 = unite(v508_8,v508_11);
    v507_8_result = unite(v507_8_result,v508_12);
  }
  const Space v507_8 = std::move(v507_8_result);
  return v507_8;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0) {
  Space v513_11_result;
  for (int v513_11_label = 1; v513_11_label <= 2; ++v513_11_label) {
    const Space v513_11_tail = child(s0,v513_11_label);
    if (v513_11_tail.empty()) continue;
    const Path v513_11_head{v513_11_label};
    const Space v514_2 = singleton(v513_11_head);
    const Space v514_3 = intersect(constant_1,v514_2);
    const Space v514_4 = (has_head(v514_3) ? constant_2 : Space{});
    const Space v514_5 = subtract(constant_0,v514_4);
    Space v514_8;
    if (!v514_5.empty()) {
      const Path v515_6 = concat_path(p0,v513_11_head);
      Space v515_7_result;
      for (int v515_7_label = 1; v515_7_label <= 2; ++v515_7_label) {
        const Space v515_7_tail = child(v513_11_tail,v515_7_label);
        if (v515_7_tail.empty()) continue;
        const Path v515_7_head{v515_7_label};
        const Space v516_2 = singleton(v515_7_head);
        const Space v516_3 = intersect(constant_1,v516_2);
        const Space v516_4 = (has_head(v516_3) ? constant_2 : Space{});
        const Space v516_5 = subtract(constant_0,v516_4);
        Space v516_8;
        if (!v516_5.empty()) {
          const Path v517_6 = concat_path(v515_6,v515_7_head);
          const Space v517_7 = routine_68(c, v517_6, v515_7_tail);
          v516_8 = compose(v516_5,v517_7);
        }
        const Space v516_9 = intersect(constant_1,v516_2);
        const Space v516_10 = (has_head(v516_9) ? constant_2 : Space{});
        Space v516_12;
        if (!v516_10.empty()) {
          const Path v518_6 = concat_path(v515_6,v515_7_head);
          const Space v518_11 = routine_69(c, v518_6, v515_7_tail);
          v516_12 = compose(v516_10,v518_11);
        }
        const Space v516_13 = unite(v516_8,v516_12);
        v515_7_result = unite(v515_7_result,v516_13);
      }
      const Space v515_7 = std::move(v515_7_result);
      v514_8 = compose(v514_5,v515_7);
    }
    const Space v514_9 = intersect(constant_1,v514_2);
    const Space v514_10 = (has_head(v514_9) ? constant_2 : Space{});
    Space v514_12;
    if (!v514_10.empty()) {
      const Path v519_6 = concat_path(p0,v513_11_head);
      Space v519_11_result;
      for (int v519_11_label = 1; v519_11_label <= 2; ++v519_11_label) {
        const Space v519_11_tail = child(v513_11_tail,v519_11_label);
        if (v519_11_tail.empty()) continue;
        const Path v519_11_head{v519_11_label};
        const Space v520_2 = singleton(v519_11_head);
        const Space v520_3 = intersect(constant_1,v520_2);
        const Space v520_4 = (has_head(v520_3) ? constant_2 : Space{});
        const Space v520_5 = subtract(constant_0,v520_4);
        Space v520_8;
        if (!v520_5.empty()) {
          const Path v521_6 = concat_path(v519_6,v519_11_head);
          const Space v521_7 = routine_68(c, v521_6, v519_11_tail);
          v520_8 = compose(v520_5,v521_7);
        }
        const Space v520_9 = intersect(constant_1,v520_2);
        const Space v520_10 = (has_head(v520_9) ? constant_2 : Space{});
        Space v520_12;
        if (!v520_10.empty()) {
          const Path v522_6 = concat_path(v519_6,v519_11_head);
          const Space v522_11 = routine_14(c, v522_6, v519_11_tail);
          v520_12 = compose(v520_10,v522_11);
        }
        const Space v520_13 = unite(v520_8,v520_12);
        v519_11_result = unite(v519_11_result,v520_13);
      }
      const Space v519_11 = std::move(v519_11_result);
      v514_12 = compose(v514_10,v519_11);
    }
    const Space v514_13 = unite(v514_8,v514_12);
    v513_11_result = unite(v513_11_result,v514_13);
  }
  const Space v513_11 = std::move(v513_11_result);
  return v513_11;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0) {
  Space v523_8_result;
  for (int v523_8_label = 1; v523_8_label <= 2; ++v523_8_label) {
    const Space v523_8_tail = child(s0,v523_8_label);
    if (v523_8_tail.empty()) continue;
    const Path v523_8_head{v523_8_label};
    const Space v524_2 = singleton(v523_8_head);
    const Space v524_3 = intersect(constant_1,v524_2);
    const Space v524_4 = (has_head(v524_3) ? constant_2 : Space{});
    const Space v524_5 = subtract(constant_0,v524_4);
    Space v524_8;
    if (!v524_5.empty()) {
      const Path v525_6 = concat_path(p0,v523_8_head);
      Space v525_7_result;
      for (int v525_7_label = 1; v525_7_label <= 2; ++v525_7_label) {
        const Space v525_7_tail = child(v523_8_tail,v525_7_label);
        if (v525_7_tail.empty()) continue;
        const Path v525_7_head{v525_7_label};
        const Space v526_2 = singleton(v525_7_head);
        const Space v526_3 = intersect(constant_1,v526_2);
        const Space v526_4 = (has_head(v526_3) ? constant_2 : Space{});
        const Space v526_5 = subtract(constant_0,v526_4);
        Space v526_8;
        if (!v526_5.empty()) {
          const Path v527_6 = concat_path(v525_6,v525_7_head);
          const Space v527_7 = routine_68(c, v527_6, v525_7_tail);
          v526_8 = compose(v526_5,v527_7);
        }
        const Space v526_9 = intersect(constant_1,v526_2);
        const Space v526_10 = (has_head(v526_9) ? constant_2 : Space{});
        Space v526_12;
        if (!v526_10.empty()) {
          const Path v528_6 = concat_path(v525_6,v525_7_head);
          const Space v528_11 = routine_69(c, v528_6, v525_7_tail);
          v526_12 = compose(v526_10,v528_11);
        }
        const Space v526_13 = unite(v526_8,v526_12);
        v525_7_result = unite(v525_7_result,v526_13);
      }
      const Space v525_7 = std::move(v525_7_result);
      v524_8 = compose(v524_5,v525_7);
    }
    const Space v524_9 = intersect(constant_1,v524_2);
    const Space v524_10 = (has_head(v524_9) ? constant_2 : Space{});
    const Space v524_11 = compose(v524_10,v523_8_tail);
    const Space v524_12 = unite(v524_8,v524_11);
    v523_8_result = unite(v523_8_result,v524_12);
  }
  const Space v523_8 = std::move(v523_8_result);
  return v523_8;
}

static Space routine_60(Context& c, const Path& p0, const Space& s0) {
  Space v529_11_result;
  for (int v529_11_label = 1; v529_11_label <= 2; ++v529_11_label) {
    const Space v529_11_tail = child(s0,v529_11_label);
    if (v529_11_tail.empty()) continue;
    const Path v529_11_head{v529_11_label};
    const Space v530_2 = singleton(v529_11_head);
    const Space v530_3 = intersect(constant_1,v530_2);
    const Space v530_4 = (has_head(v530_3) ? constant_2 : Space{});
    const Space v530_5 = subtract(constant_0,v530_4);
    Space v530_8;
    if (!v530_5.empty()) {
      const Path v531_6 = concat_path(p0,v529_11_head);
      Space v531_7_result;
      for (int v531_7_label = 1; v531_7_label <= 2; ++v531_7_label) {
        const Space v531_7_tail = child(v529_11_tail,v531_7_label);
        if (v531_7_tail.empty()) continue;
        const Path v531_7_head{v531_7_label};
        const Space v532_2 = singleton(v531_7_head);
        const Space v532_3 = intersect(constant_1,v532_2);
        const Space v532_4 = (has_head(v532_3) ? constant_2 : Space{});
        const Space v532_5 = subtract(constant_0,v532_4);
        Space v532_8;
        if (!v532_5.empty()) {
          const Path v533_6 = concat_path(v531_6,v531_7_head);
          const Space v533_7 = routine_70(c, v533_6, v531_7_tail);
          v532_8 = compose(v532_5,v533_7);
        }
        const Space v532_9 = intersect(constant_1,v532_2);
        const Space v532_10 = (has_head(v532_9) ? constant_2 : Space{});
        Space v532_12;
        if (!v532_10.empty()) {
          const Path v534_6 = concat_path(v531_6,v531_7_head);
          const Space v534_11 = routine_71(c, v534_6, v531_7_tail);
          v532_12 = compose(v532_10,v534_11);
        }
        const Space v532_13 = unite(v532_8,v532_12);
        v531_7_result = unite(v531_7_result,v532_13);
      }
      const Space v531_7 = std::move(v531_7_result);
      v530_8 = compose(v530_5,v531_7);
    }
    const Space v530_9 = intersect(constant_1,v530_2);
    const Space v530_10 = (has_head(v530_9) ? constant_2 : Space{});
    Space v530_12;
    if (!v530_10.empty()) {
      const Path v535_6 = concat_path(p0,v529_11_head);
      Space v535_11_result;
      for (int v535_11_label = 1; v535_11_label <= 2; ++v535_11_label) {
        const Space v535_11_tail = child(v529_11_tail,v535_11_label);
        if (v535_11_tail.empty()) continue;
        const Path v535_11_head{v535_11_label};
        const Space v536_2 = singleton(v535_11_head);
        const Space v536_3 = intersect(constant_1,v536_2);
        const Space v536_4 = (has_head(v536_3) ? constant_2 : Space{});
        const Space v536_5 = subtract(constant_0,v536_4);
        Space v536_8;
        if (!v536_5.empty()) {
          const Path v537_6 = concat_path(v535_6,v535_11_head);
          const Space v537_7 = routine_70(c, v537_6, v535_11_tail);
          v536_8 = compose(v536_5,v537_7);
        }
        const Space v536_9 = intersect(constant_1,v536_2);
        const Space v536_10 = (has_head(v536_9) ? constant_2 : Space{});
        Space v536_12;
        if (!v536_10.empty()) {
          const Path v538_6 = concat_path(v535_6,v535_11_head);
          const Space v538_11 = routine_17(c, v538_6, v535_11_tail);
          v536_12 = compose(v536_10,v538_11);
        }
        const Space v536_13 = unite(v536_8,v536_12);
        v535_11_result = unite(v535_11_result,v536_13);
      }
      const Space v535_11 = std::move(v535_11_result);
      v530_12 = compose(v530_10,v535_11);
    }
    const Space v530_13 = unite(v530_8,v530_12);
    v529_11_result = unite(v529_11_result,v530_13);
  }
  const Space v529_11 = std::move(v529_11_result);
  return v529_11;
}

static Space routine_61(Context& c, const Path& p0, const Space& s0) {
  Space v539_8_result;
  for (int v539_8_label = 1; v539_8_label <= 2; ++v539_8_label) {
    const Space v539_8_tail = child(s0,v539_8_label);
    if (v539_8_tail.empty()) continue;
    const Path v539_8_head{v539_8_label};
    const Space v540_2 = singleton(v539_8_head);
    const Space v540_3 = intersect(constant_1,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_2 : Space{});
    const Space v540_5 = subtract(constant_0,v540_4);
    Space v540_8;
    if (!v540_5.empty()) {
      const Path v541_6 = concat_path(p0,v539_8_head);
      Space v541_7_result;
      for (int v541_7_label = 1; v541_7_label <= 2; ++v541_7_label) {
        const Space v541_7_tail = child(v539_8_tail,v541_7_label);
        if (v541_7_tail.empty()) continue;
        const Path v541_7_head{v541_7_label};
        const Space v542_2 = singleton(v541_7_head);
        const Space v542_3 = intersect(constant_1,v542_2);
        const Space v542_4 = (has_head(v542_3) ? constant_2 : Space{});
        const Space v542_5 = subtract(constant_0,v542_4);
        Space v542_8;
        if (!v542_5.empty()) {
          const Path v543_6 = concat_path(v541_6,v541_7_head);
          const Space v543_7 = routine_70(c, v543_6, v541_7_tail);
          v542_8 = compose(v542_5,v543_7);
        }
        const Space v542_9 = intersect(constant_1,v542_2);
        const Space v542_10 = (has_head(v542_9) ? constant_2 : Space{});
        Space v542_12;
        if (!v542_10.empty()) {
          const Path v544_6 = concat_path(v541_6,v541_7_head);
          const Space v544_11 = routine_71(c, v544_6, v541_7_tail);
          v542_12 = compose(v542_10,v544_11);
        }
        const Space v542_13 = unite(v542_8,v542_12);
        v541_7_result = unite(v541_7_result,v542_13);
      }
      const Space v541_7 = std::move(v541_7_result);
      v540_8 = compose(v540_5,v541_7);
    }
    const Space v540_9 = intersect(constant_1,v540_2);
    const Space v540_10 = (has_head(v540_9) ? constant_2 : Space{});
    const Space v540_11 = compose(v540_10,v539_8_tail);
    const Space v540_12 = unite(v540_8,v540_11);
    v539_8_result = unite(v539_8_result,v540_12);
  }
  const Space v539_8 = std::move(v539_8_result);
  return v539_8;
}

static Space routine_62(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v545_5_result;
  for (int v545_5_label = 1; v545_5_label <= 2; ++v545_5_label) {
    const Space v545_5_tail = child(s0,v545_5_label);
    if (v545_5_tail.empty()) continue;
    const Path v545_5_head{v545_5_label};
    const Space v546_2 = singleton(v545_5_head);
    const Space v546_3 = intersect(constant_1,v546_2);
    const Space v546_4 = (has_head(v546_3) ? constant_2 : Space{});
    Space v546_7;
    if (!v546_4.empty()) {
      const Path v547_5 = concat_path(p0,v545_5_head);
      Space v547_6_result;
      for (int v547_6_label = 1; v547_6_label <= 2; ++v547_6_label) {
        const Space v547_6_tail = child(v545_5_tail,v547_6_label);
        if (v547_6_tail.empty()) continue;
        const Path v547_6_head{v547_6_label};
        const Space v548_2 = singleton(v547_6_head);
        const Space v548_3 = intersect(constant_1,v548_2);
        const Space v548_4 = (has_head(v548_3) ? constant_2 : Space{});
        Space v548_7;
        if (!v548_4.empty()) {
          const Path v549_5 = concat_path(v547_5,v547_6_head);
          const Space v549_6 = routine_5(c, v549_5, v547_6_tail, s1);
          v548_7 = compose(v548_4,v549_6);
        }
        v547_6_result = unite(v547_6_result,v548_7);
      }
      const Space v547_6 = std::move(v547_6_result);
      v546_7 = compose(v546_4,v547_6);
    }
    v545_5_result = unite(v545_5_result,v546_7);
  }
  const Space v545_5 = std::move(v545_5_result);
  return v545_5;
}

static Space routine_63(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v550_5 = unwrap(s1,constant_4);
  const Space v550_7 = unwrap(s1,constant_5);
  const Space v550_8 = unwrap(v550_7,p0);
  const Space v550_10 = unwrap(s1,constant_6);
  Space v550_17_result;
  for (int v550_17_label = 1; v550_17_label <= 2; ++v550_17_label) {
    const Space v550_17_tail = child(s0,v550_17_label);
    if (v550_17_tail.empty()) continue;
    const Path v550_17_head{v550_17_label};
    const Space v551_2 = singleton(v550_17_head);
    const Space v551_3 = intersect(constant_1,v551_2);
    const Space v551_4 = (has_head(v551_3) ? constant_2 : Space{});
    Space v551_12;
    if (!v551_4.empty()) {
      const Space v552_5 = unwrap(v550_8,v550_17_head);
      const Space v552_6 = restrict_to(v550_7,v552_5);
      Space v552_7_result;
      for (int v552_7_label = 1; v552_7_label <= 2; ++v552_7_label) {
        const Space v552_7_tail = child(v552_6,v552_7_label);
        if (v552_7_tail.empty()) continue;
        const Path v552_7_head{v552_7_label};
        const Space v553_2 = singleton(v552_7_head);
        const Space v553_3 = intersect(constant_1,v553_2);
        const Space v553_4 = (has_head(v553_3) ? constant_2 : Space{});
        const Space v553_5 = subtract(constant_0,v553_4);
        Space v553_7;
        if (!v553_5.empty()) {
          const Space v554_6 = routine_6(c, v552_7_head, v552_7_tail);
          v553_7 = compose(v553_5,v554_6);
        }
        const Space v553_8 = intersect(constant_1,v553_2);
        const Space v553_9 = (has_head(v553_8) ? constant_2 : Space{});
        Space v553_11;
        if (!v553_9.empty()) {
          const Space v555_10 = routine_7(c, v552_7_head, v552_7_tail);
          v553_11 = compose(v553_9,v555_10);
        }
        const Space v553_12 = unite(v553_7,v553_11);
        v552_7_result = unite(v552_7_result,v553_12);
      }
      const Space v552_7 = std::move(v552_7_result);
      const Space v552_8 = restrict_to(v550_5,v552_7);
      Space v552_9_result;
      for (int v552_9_label = 1; v552_9_label <= 2; ++v552_9_label) {
        const Space v552_9_tail = child(v552_8,v552_9_label);
        if (v552_9_tail.empty()) continue;
        const Path v552_9_head{v552_9_label};
        const Space v556_2 = singleton(v552_9_head);
        const Space v556_3 = intersect(constant_1,v556_2);
        const Space v556_4 = (has_head(v556_3) ? constant_2 : Space{});
        const Space v556_5 = subtract(constant_0,v556_4);
        Space v556_7;
        if (!v556_5.empty()) {
          const Space v557_6 = routine_8(c, v552_9_head, v552_9_tail);
          v556_7 = compose(v556_5,v557_6);
        }
        const Space v556_8 = intersect(constant_1,v556_2);
        const Space v556_9 = (has_head(v556_8) ? constant_2 : Space{});
        Space v556_11;
        if (!v556_9.empty()) {
          const Space v558_10 = routine_9(c, v552_9_head, v552_9_tail);
          v556_11 = compose(v556_9,v558_10);
        }
        const Space v556_12 = unite(v556_7,v556_11);
        v552_9_result = unite(v552_9_result,v556_12);
      }
      const Space v552_9 = std::move(v552_9_result);
      const Space v552_10 = subtract(v552_9,v552_5);
      const Space v552_11 = intersect(v552_10,v550_10);
      v551_12 = compose(v551_4,v552_11);
    }
    const Path v551_13 = concat_path(p0,v550_17_head);
    const Space v551_14 = wrap(v551_12,v551_13);
    v550_17_result = unite(v550_17_result,v551_14);
  }
  const Space v550_17 = std::move(v550_17_result);
  return v550_17;
}

static Space routine_64(Context& c, const Path& p0, const Space& s0) {
  Space v559_11_result;
  for (int v559_11_label = 1; v559_11_label <= 2; ++v559_11_label) {
    const Space v559_11_tail = child(s0,v559_11_label);
    if (v559_11_tail.empty()) continue;
    const Path v559_11_head{v559_11_label};
    const Space v560_2 = singleton(v559_11_head);
    const Space v560_3 = intersect(constant_1,v560_2);
    const Space v560_4 = (has_head(v560_3) ? constant_2 : Space{});
    const Space v560_5 = subtract(constant_0,v560_4);
    Space v560_8;
    if (!v560_5.empty()) {
      const Path v561_6 = concat_path(p0,v559_11_head);
      Space v561_7_result;
      for (int v561_7_label = 1; v561_7_label <= 2; ++v561_7_label) {
        const Space v561_7_tail = child(v559_11_tail,v561_7_label);
        if (v561_7_tail.empty()) continue;
        const Path v561_7_head{v561_7_label};
        const Space v562_2 = singleton(v561_7_head);
        const Space v562_3 = intersect(constant_1,v562_2);
        const Space v562_4 = (has_head(v562_3) ? constant_2 : Space{});
        const Space v562_5 = subtract(constant_0,v562_4);
        Space v562_8;
        if (!v562_5.empty()) {
          const Path v563_6 = concat_path(v561_6,v561_7_head);
          const Space v563_7 = routine_72(c, v563_6, v561_7_tail);
          v562_8 = compose(v562_5,v563_7);
        }
        const Space v562_9 = intersect(constant_1,v562_2);
        const Space v562_10 = (has_head(v562_9) ? constant_2 : Space{});
        Space v562_12;
        if (!v562_10.empty()) {
          const Path v564_6 = concat_path(v561_6,v561_7_head);
          const Space v564_11 = routine_73(c, v564_6, v561_7_tail);
          v562_12 = compose(v562_10,v564_11);
        }
        const Space v562_13 = unite(v562_8,v562_12);
        v561_7_result = unite(v561_7_result,v562_13);
      }
      const Space v561_7 = std::move(v561_7_result);
      v560_8 = compose(v560_5,v561_7);
    }
    const Space v560_9 = intersect(constant_1,v560_2);
    const Space v560_10 = (has_head(v560_9) ? constant_2 : Space{});
    Space v560_12;
    if (!v560_10.empty()) {
      const Path v565_6 = concat_path(p0,v559_11_head);
      Space v565_11_result;
      for (int v565_11_label = 1; v565_11_label <= 2; ++v565_11_label) {
        const Space v565_11_tail = child(v559_11_tail,v565_11_label);
        if (v565_11_tail.empty()) continue;
        const Path v565_11_head{v565_11_label};
        const Space v566_2 = singleton(v565_11_head);
        const Space v566_3 = intersect(constant_1,v566_2);
        const Space v566_4 = (has_head(v566_3) ? constant_2 : Space{});
        const Space v566_5 = subtract(constant_0,v566_4);
        Space v566_8;
        if (!v566_5.empty()) {
          const Path v567_6 = concat_path(v565_6,v565_11_head);
          const Space v567_7 = routine_72(c, v567_6, v565_11_tail);
          v566_8 = compose(v566_5,v567_7);
        }
        const Space v566_9 = intersect(constant_1,v566_2);
        const Space v566_10 = (has_head(v566_9) ? constant_2 : Space{});
        Space v566_12;
        if (!v566_10.empty()) {
          const Path v568_6 = concat_path(v565_6,v565_11_head);
          const Space v568_11 = routine_14(c, v568_6, v565_11_tail);
          v566_12 = compose(v566_10,v568_11);
        }
        const Space v566_13 = unite(v566_8,v566_12);
        v565_11_result = unite(v565_11_result,v566_13);
      }
      const Space v565_11 = std::move(v565_11_result);
      v560_12 = compose(v560_10,v565_11);
    }
    const Space v560_13 = unite(v560_8,v560_12);
    v559_11_result = unite(v559_11_result,v560_13);
  }
  const Space v559_11 = std::move(v559_11_result);
  return v559_11;
}

static Space routine_65(Context& c, const Path& p0, const Space& s0) {
  Space v569_8_result;
  for (int v569_8_label = 1; v569_8_label <= 2; ++v569_8_label) {
    const Space v569_8_tail = child(s0,v569_8_label);
    if (v569_8_tail.empty()) continue;
    const Path v569_8_head{v569_8_label};
    const Space v570_2 = singleton(v569_8_head);
    const Space v570_3 = intersect(constant_1,v570_2);
    const Space v570_4 = (has_head(v570_3) ? constant_2 : Space{});
    const Space v570_5 = subtract(constant_0,v570_4);
    Space v570_8;
    if (!v570_5.empty()) {
      const Path v571_6 = concat_path(p0,v569_8_head);
      Space v571_7_result;
      for (int v571_7_label = 1; v571_7_label <= 2; ++v571_7_label) {
        const Space v571_7_tail = child(v569_8_tail,v571_7_label);
        if (v571_7_tail.empty()) continue;
        const Path v571_7_head{v571_7_label};
        const Space v572_2 = singleton(v571_7_head);
        const Space v572_3 = intersect(constant_1,v572_2);
        const Space v572_4 = (has_head(v572_3) ? constant_2 : Space{});
        const Space v572_5 = subtract(constant_0,v572_4);
        Space v572_8;
        if (!v572_5.empty()) {
          const Path v573_6 = concat_path(v571_6,v571_7_head);
          const Space v573_7 = routine_72(c, v573_6, v571_7_tail);
          v572_8 = compose(v572_5,v573_7);
        }
        const Space v572_9 = intersect(constant_1,v572_2);
        const Space v572_10 = (has_head(v572_9) ? constant_2 : Space{});
        Space v572_12;
        if (!v572_10.empty()) {
          const Path v574_6 = concat_path(v571_6,v571_7_head);
          const Space v574_11 = routine_73(c, v574_6, v571_7_tail);
          v572_12 = compose(v572_10,v574_11);
        }
        const Space v572_13 = unite(v572_8,v572_12);
        v571_7_result = unite(v571_7_result,v572_13);
      }
      const Space v571_7 = std::move(v571_7_result);
      v570_8 = compose(v570_5,v571_7);
    }
    const Space v570_9 = intersect(constant_1,v570_2);
    const Space v570_10 = (has_head(v570_9) ? constant_2 : Space{});
    const Space v570_11 = compose(v570_10,v569_8_tail);
    const Space v570_12 = unite(v570_8,v570_11);
    v569_8_result = unite(v569_8_result,v570_12);
  }
  const Space v569_8 = std::move(v569_8_result);
  return v569_8;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0) {
  Space v575_11_result;
  for (int v575_11_label = 1; v575_11_label <= 2; ++v575_11_label) {
    const Space v575_11_tail = child(s0,v575_11_label);
    if (v575_11_tail.empty()) continue;
    const Path v575_11_head{v575_11_label};
    const Space v576_2 = singleton(v575_11_head);
    const Space v576_3 = intersect(constant_1,v576_2);
    const Space v576_4 = (has_head(v576_3) ? constant_2 : Space{});
    const Space v576_5 = subtract(constant_0,v576_4);
    Space v576_8;
    if (!v576_5.empty()) {
      const Path v577_6 = concat_path(p0,v575_11_head);
      Space v577_7_result;
      for (int v577_7_label = 1; v577_7_label <= 2; ++v577_7_label) {
        const Space v577_7_tail = child(v575_11_tail,v577_7_label);
        if (v577_7_tail.empty()) continue;
        const Path v577_7_head{v577_7_label};
        const Space v578_2 = singleton(v577_7_head);
        const Space v578_3 = intersect(constant_1,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_2 : Space{});
        const Space v578_5 = subtract(constant_0,v578_4);
        Space v578_8;
        if (!v578_5.empty()) {
          const Path v579_6 = concat_path(v577_6,v577_7_head);
          const Space v579_7 = routine_74(c, v579_6, v577_7_tail);
          v578_8 = compose(v578_5,v579_7);
        }
        const Space v578_9 = intersect(constant_1,v578_2);
        const Space v578_10 = (has_head(v578_9) ? constant_2 : Space{});
        Space v578_12;
        if (!v578_10.empty()) {
          const Path v580_6 = concat_path(v577_6,v577_7_head);
          const Space v580_11 = routine_75(c, v580_6, v577_7_tail);
          v578_12 = compose(v578_10,v580_11);
        }
        const Space v578_13 = unite(v578_8,v578_12);
        v577_7_result = unite(v577_7_result,v578_13);
      }
      const Space v577_7 = std::move(v577_7_result);
      v576_8 = compose(v576_5,v577_7);
    }
    const Space v576_9 = intersect(constant_1,v576_2);
    const Space v576_10 = (has_head(v576_9) ? constant_2 : Space{});
    Space v576_12;
    if (!v576_10.empty()) {
      const Path v581_6 = concat_path(p0,v575_11_head);
      Space v581_11_result;
      for (int v581_11_label = 1; v581_11_label <= 2; ++v581_11_label) {
        const Space v581_11_tail = child(v575_11_tail,v581_11_label);
        if (v581_11_tail.empty()) continue;
        const Path v581_11_head{v581_11_label};
        const Space v582_2 = singleton(v581_11_head);
        const Space v582_3 = intersect(constant_1,v582_2);
        const Space v582_4 = (has_head(v582_3) ? constant_2 : Space{});
        const Space v582_5 = subtract(constant_0,v582_4);
        Space v582_8;
        if (!v582_5.empty()) {
          const Path v583_6 = concat_path(v581_6,v581_11_head);
          const Space v583_7 = routine_74(c, v583_6, v581_11_tail);
          v582_8 = compose(v582_5,v583_7);
        }
        const Space v582_9 = intersect(constant_1,v582_2);
        const Space v582_10 = (has_head(v582_9) ? constant_2 : Space{});
        Space v582_12;
        if (!v582_10.empty()) {
          const Path v584_6 = concat_path(v581_6,v581_11_head);
          const Space v584_11 = routine_17(c, v584_6, v581_11_tail);
          v582_12 = compose(v582_10,v584_11);
        }
        const Space v582_13 = unite(v582_8,v582_12);
        v581_11_result = unite(v581_11_result,v582_13);
      }
      const Space v581_11 = std::move(v581_11_result);
      v576_12 = compose(v576_10,v581_11);
    }
    const Space v576_13 = unite(v576_8,v576_12);
    v575_11_result = unite(v575_11_result,v576_13);
  }
  const Space v575_11 = std::move(v575_11_result);
  return v575_11;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v585_8_result;
  for (int v585_8_label = 1; v585_8_label <= 2; ++v585_8_label) {
    const Space v585_8_tail = child(s0,v585_8_label);
    if (v585_8_tail.empty()) continue;
    const Path v585_8_head{v585_8_label};
    const Space v586_2 = singleton(v585_8_head);
    const Space v586_3 = intersect(constant_1,v586_2);
    const Space v586_4 = (has_head(v586_3) ? constant_2 : Space{});
    const Space v586_5 = subtract(constant_0,v586_4);
    Space v586_8;
    if (!v586_5.empty()) {
      const Path v587_6 = concat_path(p0,v585_8_head);
      Space v587_7_result;
      for (int v587_7_label = 1; v587_7_label <= 2; ++v587_7_label) {
        const Space v587_7_tail = child(v585_8_tail,v587_7_label);
        if (v587_7_tail.empty()) continue;
        const Path v587_7_head{v587_7_label};
        const Space v588_2 = singleton(v587_7_head);
        const Space v588_3 = intersect(constant_1,v588_2);
        const Space v588_4 = (has_head(v588_3) ? constant_2 : Space{});
        const Space v588_5 = subtract(constant_0,v588_4);
        Space v588_8;
        if (!v588_5.empty()) {
          const Path v589_6 = concat_path(v587_6,v587_7_head);
          const Space v589_7 = routine_74(c, v589_6, v587_7_tail);
          v588_8 = compose(v588_5,v589_7);
        }
        const Space v588_9 = intersect(constant_1,v588_2);
        const Space v588_10 = (has_head(v588_9) ? constant_2 : Space{});
        Space v588_12;
        if (!v588_10.empty()) {
          const Path v590_6 = concat_path(v587_6,v587_7_head);
          const Space v590_11 = routine_75(c, v590_6, v587_7_tail);
          v588_12 = compose(v588_10,v590_11);
        }
        const Space v588_13 = unite(v588_8,v588_12);
        v587_7_result = unite(v587_7_result,v588_13);
      }
      const Space v587_7 = std::move(v587_7_result);
      v586_8 = compose(v586_5,v587_7);
    }
    const Space v586_9 = intersect(constant_1,v586_2);
    const Space v586_10 = (has_head(v586_9) ? constant_2 : Space{});
    const Space v586_11 = compose(v586_10,v585_8_tail);
    const Space v586_12 = unite(v586_8,v586_11);
    v585_8_result = unite(v585_8_result,v586_12);
  }
  const Space v585_8 = std::move(v585_8_result);
  return v585_8;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  Space v591_11_result;
  for (int v591_11_label = 1; v591_11_label <= 2; ++v591_11_label) {
    const Space v591_11_tail = child(s0,v591_11_label);
    if (v591_11_tail.empty()) continue;
    const Path v591_11_head{v591_11_label};
    const Space v592_2 = singleton(v591_11_head);
    const Space v592_3 = intersect(constant_1,v592_2);
    const Space v592_4 = (has_head(v592_3) ? constant_2 : Space{});
    const Space v592_5 = subtract(constant_0,v592_4);
    Space v592_8;
    if (!v592_5.empty()) {
      const Path v593_6 = concat_path(p0,v591_11_head);
      Space v593_7_result;
      for (int v593_7_label = 1; v593_7_label <= 2; ++v593_7_label) {
        const Space v593_7_tail = child(v591_11_tail,v593_7_label);
        if (v593_7_tail.empty()) continue;
        const Path v593_7_head{v593_7_label};
        const Space v594_2 = singleton(v593_7_head);
        const Space v594_3 = intersect(constant_1,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_2 : Space{});
        const Space v594_5 = subtract(constant_0,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_7_head);
          const Space v595_7 = routine_76(c, v595_6, v593_7_tail);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_1,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_2 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_7_head);
          const Space v596_11 = routine_77(c, v596_6, v593_7_tail);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_7_result = unite(v593_7_result,v594_13);
      }
      const Space v593_7 = std::move(v593_7_result);
      v592_8 = compose(v592_5,v593_7);
    }
    const Space v592_9 = intersect(constant_1,v592_2);
    const Space v592_10 = (has_head(v592_9) ? constant_2 : Space{});
    Space v592_12;
    if (!v592_10.empty()) {
      const Path v597_6 = concat_path(p0,v591_11_head);
      Space v597_11_result;
      for (int v597_11_label = 1; v597_11_label <= 2; ++v597_11_label) {
        const Space v597_11_tail = child(v591_11_tail,v597_11_label);
        if (v597_11_tail.empty()) continue;
        const Path v597_11_head{v597_11_label};
        const Space v598_2 = singleton(v597_11_head);
        const Space v598_3 = intersect(constant_1,v598_2);
        const Space v598_4 = (has_head(v598_3) ? constant_2 : Space{});
        const Space v598_5 = subtract(constant_0,v598_4);
        Space v598_8;
        if (!v598_5.empty()) {
          const Path v599_6 = concat_path(v597_6,v597_11_head);
          const Space v599_7 = routine_76(c, v599_6, v597_11_tail);
          v598_8 = compose(v598_5,v599_7);
        }
        const Space v598_9 = intersect(constant_1,v598_2);
        const Space v598_10 = (has_head(v598_9) ? constant_2 : Space{});
        Space v598_12;
        if (!v598_10.empty()) {
          const Path v600_6 = concat_path(v597_6,v597_11_head);
          const Space v600_11 = routine_14(c, v600_6, v597_11_tail);
          v598_12 = compose(v598_10,v600_11);
        }
        const Space v598_13 = unite(v598_8,v598_12);
        v597_11_result = unite(v597_11_result,v598_13);
      }
      const Space v597_11 = std::move(v597_11_result);
      v592_12 = compose(v592_10,v597_11);
    }
    const Space v592_13 = unite(v592_8,v592_12);
    v591_11_result = unite(v591_11_result,v592_13);
  }
  const Space v591_11 = std::move(v591_11_result);
  return v591_11;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  Space v601_8_result;
  for (int v601_8_label = 1; v601_8_label <= 2; ++v601_8_label) {
    const Space v601_8_tail = child(s0,v601_8_label);
    if (v601_8_tail.empty()) continue;
    const Path v601_8_head{v601_8_label};
    const Space v602_2 = singleton(v601_8_head);
    const Space v602_3 = intersect(constant_1,v602_2);
    const Space v602_4 = (has_head(v602_3) ? constant_2 : Space{});
    const Space v602_5 = subtract(constant_0,v602_4);
    Space v602_8;
    if (!v602_5.empty()) {
      const Path v603_6 = concat_path(p0,v601_8_head);
      Space v603_7_result;
      for (int v603_7_label = 1; v603_7_label <= 2; ++v603_7_label) {
        const Space v603_7_tail = child(v601_8_tail,v603_7_label);
        if (v603_7_tail.empty()) continue;
        const Path v603_7_head{v603_7_label};
        const Space v604_2 = singleton(v603_7_head);
        const Space v604_3 = intersect(constant_1,v604_2);
        const Space v604_4 = (has_head(v604_3) ? constant_2 : Space{});
        const Space v604_5 = subtract(constant_0,v604_4);
        Space v604_8;
        if (!v604_5.empty()) {
          const Path v605_6 = concat_path(v603_6,v603_7_head);
          const Space v605_7 = routine_76(c, v605_6, v603_7_tail);
          v604_8 = compose(v604_5,v605_7);
        }
        const Space v604_9 = intersect(constant_1,v604_2);
        const Space v604_10 = (has_head(v604_9) ? constant_2 : Space{});
        Space v604_12;
        if (!v604_10.empty()) {
          const Path v606_6 = concat_path(v603_6,v603_7_head);
          const Space v606_11 = routine_77(c, v606_6, v603_7_tail);
          v604_12 = compose(v604_10,v606_11);
        }
        const Space v604_13 = unite(v604_8,v604_12);
        v603_7_result = unite(v603_7_result,v604_13);
      }
      const Space v603_7 = std::move(v603_7_result);
      v602_8 = compose(v602_5,v603_7);
    }
    const Space v602_9 = intersect(constant_1,v602_2);
    const Space v602_10 = (has_head(v602_9) ? constant_2 : Space{});
    const Space v602_11 = compose(v602_10,v601_8_tail);
    const Space v602_12 = unite(v602_8,v602_11);
    v601_8_result = unite(v601_8_result,v602_12);
  }
  const Space v601_8 = std::move(v601_8_result);
  return v601_8;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v607_11_result;
  for (int v607_11_label = 1; v607_11_label <= 2; ++v607_11_label) {
    const Space v607_11_tail = child(s0,v607_11_label);
    if (v607_11_tail.empty()) continue;
    const Path v607_11_head{v607_11_label};
    const Space v608_2 = singleton(v607_11_head);
    const Space v608_3 = intersect(constant_1,v608_2);
    const Space v608_4 = (has_head(v608_3) ? constant_2 : Space{});
    const Space v608_5 = subtract(constant_0,v608_4);
    Space v608_8;
    if (!v608_5.empty()) {
      const Path v609_6 = concat_path(p0,v607_11_head);
      Space v609_7_result;
      for (int v609_7_label = 1; v609_7_label <= 2; ++v609_7_label) {
        const Space v609_7_tail = child(v607_11_tail,v609_7_label);
        if (v609_7_tail.empty()) continue;
        const Path v609_7_head{v609_7_label};
        const Space v610_2 = singleton(v609_7_head);
        const Space v610_3 = intersect(constant_1,v610_2);
        const Space v610_4 = (has_head(v610_3) ? constant_2 : Space{});
        const Space v610_5 = subtract(constant_0,v610_4);
        Space v610_8;
        if (!v610_5.empty()) {
          const Path v611_6 = concat_path(v609_6,v609_7_head);
          const Space v611_7 = routine_78(c, v611_6, v609_7_tail);
          v610_8 = compose(v610_5,v611_7);
        }
        const Space v610_9 = intersect(constant_1,v610_2);
        const Space v610_10 = (has_head(v610_9) ? constant_2 : Space{});
        Space v610_12;
        if (!v610_10.empty()) {
          const Path v612_6 = concat_path(v609_6,v609_7_head);
          const Space v612_11 = routine_79(c, v612_6, v609_7_tail);
          v610_12 = compose(v610_10,v612_11);
        }
        const Space v610_13 = unite(v610_8,v610_12);
        v609_7_result = unite(v609_7_result,v610_13);
      }
      const Space v609_7 = std::move(v609_7_result);
      v608_8 = compose(v608_5,v609_7);
    }
    const Space v608_9 = intersect(constant_1,v608_2);
    const Space v608_10 = (has_head(v608_9) ? constant_2 : Space{});
    Space v608_12;
    if (!v608_10.empty()) {
      const Path v613_6 = concat_path(p0,v607_11_head);
      Space v613_11_result;
      for (int v613_11_label = 1; v613_11_label <= 2; ++v613_11_label) {
        const Space v613_11_tail = child(v607_11_tail,v613_11_label);
        if (v613_11_tail.empty()) continue;
        const Path v613_11_head{v613_11_label};
        const Space v614_2 = singleton(v613_11_head);
        const Space v614_3 = intersect(constant_1,v614_2);
        const Space v614_4 = (has_head(v614_3) ? constant_2 : Space{});
        const Space v614_5 = subtract(constant_0,v614_4);
        Space v614_8;
        if (!v614_5.empty()) {
          const Path v615_6 = concat_path(v613_6,v613_11_head);
          const Space v615_7 = routine_78(c, v615_6, v613_11_tail);
          v614_8 = compose(v614_5,v615_7);
        }
        const Space v614_9 = intersect(constant_1,v614_2);
        const Space v614_10 = (has_head(v614_9) ? constant_2 : Space{});
        Space v614_12;
        if (!v614_10.empty()) {
          const Path v616_6 = concat_path(v613_6,v613_11_head);
          const Space v616_11 = routine_17(c, v616_6, v613_11_tail);
          v614_12 = compose(v614_10,v616_11);
        }
        const Space v614_13 = unite(v614_8,v614_12);
        v613_11_result = unite(v613_11_result,v614_13);
      }
      const Space v613_11 = std::move(v613_11_result);
      v608_12 = compose(v608_10,v613_11);
    }
    const Space v608_13 = unite(v608_8,v608_12);
    v607_11_result = unite(v607_11_result,v608_13);
  }
  const Space v607_11 = std::move(v607_11_result);
  return v607_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v617_8_result;
  for (int v617_8_label = 1; v617_8_label <= 2; ++v617_8_label) {
    const Space v617_8_tail = child(s0,v617_8_label);
    if (v617_8_tail.empty()) continue;
    const Path v617_8_head{v617_8_label};
    const Space v618_2 = singleton(v617_8_head);
    const Space v618_3 = intersect(constant_1,v618_2);
    const Space v618_4 = (has_head(v618_3) ? constant_2 : Space{});
    const Space v618_5 = subtract(constant_0,v618_4);
    Space v618_8;
    if (!v618_5.empty()) {
      const Path v619_6 = concat_path(p0,v617_8_head);
      Space v619_7_result;
      for (int v619_7_label = 1; v619_7_label <= 2; ++v619_7_label) {
        const Space v619_7_tail = child(v617_8_tail,v619_7_label);
        if (v619_7_tail.empty()) continue;
        const Path v619_7_head{v619_7_label};
        const Space v620_2 = singleton(v619_7_head);
        const Space v620_3 = intersect(constant_1,v620_2);
        const Space v620_4 = (has_head(v620_3) ? constant_2 : Space{});
        const Space v620_5 = subtract(constant_0,v620_4);
        Space v620_8;
        if (!v620_5.empty()) {
          const Path v621_6 = concat_path(v619_6,v619_7_head);
          const Space v621_7 = routine_78(c, v621_6, v619_7_tail);
          v620_8 = compose(v620_5,v621_7);
        }
        const Space v620_9 = intersect(constant_1,v620_2);
        const Space v620_10 = (has_head(v620_9) ? constant_2 : Space{});
        Space v620_12;
        if (!v620_10.empty()) {
          const Path v622_6 = concat_path(v619_6,v619_7_head);
          const Space v622_11 = routine_79(c, v622_6, v619_7_tail);
          v620_12 = compose(v620_10,v622_11);
        }
        const Space v620_13 = unite(v620_8,v620_12);
        v619_7_result = unite(v619_7_result,v620_13);
      }
      const Space v619_7 = std::move(v619_7_result);
      v618_8 = compose(v618_5,v619_7);
    }
    const Space v618_9 = intersect(constant_1,v618_2);
    const Space v618_10 = (has_head(v618_9) ? constant_2 : Space{});
    const Space v618_11 = compose(v618_10,v617_8_tail);
    const Space v618_12 = unite(v618_8,v618_11);
    v617_8_result = unite(v617_8_result,v618_12);
  }
  const Space v617_8 = std::move(v617_8_result);
  return v617_8;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  Space v623_11_result;
  for (int v623_11_label = 1; v623_11_label <= 2; ++v623_11_label) {
    const Space v623_11_tail = child(s0,v623_11_label);
    if (v623_11_tail.empty()) continue;
    const Path v623_11_head{v623_11_label};
    const Space v624_2 = singleton(v623_11_head);
    const Space v624_3 = intersect(constant_1,v624_2);
    const Space v624_4 = (has_head(v624_3) ? constant_2 : Space{});
    const Space v624_5 = subtract(constant_0,v624_4);
    Space v624_8;
    if (!v624_5.empty()) {
      const Path v625_6 = concat_path(p0,v623_11_head);
      Space v625_7_result;
      for (int v625_7_label = 1; v625_7_label <= 2; ++v625_7_label) {
        const Space v625_7_tail = child(v623_11_tail,v625_7_label);
        if (v625_7_tail.empty()) continue;
        const Path v625_7_head{v625_7_label};
        const Space v626_2 = singleton(v625_7_head);
        const Space v626_3 = intersect(constant_1,v626_2);
        const Space v626_4 = (has_head(v626_3) ? constant_2 : Space{});
        const Space v626_5 = subtract(constant_0,v626_4);
        Space v626_8;
        if (!v626_5.empty()) {
          const Path v627_6 = concat_path(v625_6,v625_7_head);
          const Space v627_7 = routine_80(c, v627_6, v625_7_tail);
          v626_8 = compose(v626_5,v627_7);
        }
        const Space v626_9 = intersect(constant_1,v626_2);
        const Space v626_10 = (has_head(v626_9) ? constant_2 : Space{});
        Space v626_12;
        if (!v626_10.empty()) {
          const Path v628_6 = concat_path(v625_6,v625_7_head);
          const Space v628_11 = routine_81(c, v628_6, v625_7_tail);
          v626_12 = compose(v626_10,v628_11);
        }
        const Space v626_13 = unite(v626_8,v626_12);
        v625_7_result = unite(v625_7_result,v626_13);
      }
      const Space v625_7 = std::move(v625_7_result);
      v624_8 = compose(v624_5,v625_7);
    }
    const Space v624_9 = intersect(constant_1,v624_2);
    const Space v624_10 = (has_head(v624_9) ? constant_2 : Space{});
    Space v624_12;
    if (!v624_10.empty()) {
      const Path v629_6 = concat_path(p0,v623_11_head);
      Space v629_11_result;
      for (int v629_11_label = 1; v629_11_label <= 2; ++v629_11_label) {
        const Space v629_11_tail = child(v623_11_tail,v629_11_label);
        if (v629_11_tail.empty()) continue;
        const Path v629_11_head{v629_11_label};
        const Space v630_2 = singleton(v629_11_head);
        const Space v630_3 = intersect(constant_1,v630_2);
        const Space v630_4 = (has_head(v630_3) ? constant_2 : Space{});
        const Space v630_5 = subtract(constant_0,v630_4);
        Space v630_8;
        if (!v630_5.empty()) {
          const Path v631_6 = concat_path(v629_6,v629_11_head);
          const Space v631_7 = routine_80(c, v631_6, v629_11_tail);
          v630_8 = compose(v630_5,v631_7);
        }
        const Space v630_9 = intersect(constant_1,v630_2);
        const Space v630_10 = (has_head(v630_9) ? constant_2 : Space{});
        Space v630_12;
        if (!v630_10.empty()) {
          const Path v632_6 = concat_path(v629_6,v629_11_head);
          const Space v632_11 = routine_14(c, v632_6, v629_11_tail);
          v630_12 = compose(v630_10,v632_11);
        }
        const Space v630_13 = unite(v630_8,v630_12);
        v629_11_result = unite(v629_11_result,v630_13);
      }
      const Space v629_11 = std::move(v629_11_result);
      v624_12 = compose(v624_10,v629_11);
    }
    const Space v624_13 = unite(v624_8,v624_12);
    v623_11_result = unite(v623_11_result,v624_13);
  }
  const Space v623_11 = std::move(v623_11_result);
  return v623_11;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0) {
  Space v633_8_result;
  for (int v633_8_label = 1; v633_8_label <= 2; ++v633_8_label) {
    const Space v633_8_tail = child(s0,v633_8_label);
    if (v633_8_tail.empty()) continue;
    const Path v633_8_head{v633_8_label};
    const Space v634_2 = singleton(v633_8_head);
    const Space v634_3 = intersect(constant_1,v634_2);
    const Space v634_4 = (has_head(v634_3) ? constant_2 : Space{});
    const Space v634_5 = subtract(constant_0,v634_4);
    Space v634_8;
    if (!v634_5.empty()) {
      const Path v635_6 = concat_path(p0,v633_8_head);
      Space v635_7_result;
      for (int v635_7_label = 1; v635_7_label <= 2; ++v635_7_label) {
        const Space v635_7_tail = child(v633_8_tail,v635_7_label);
        if (v635_7_tail.empty()) continue;
        const Path v635_7_head{v635_7_label};
        const Space v636_2 = singleton(v635_7_head);
        const Space v636_3 = intersect(constant_1,v636_2);
        const Space v636_4 = (has_head(v636_3) ? constant_2 : Space{});
        const Space v636_5 = subtract(constant_0,v636_4);
        Space v636_8;
        if (!v636_5.empty()) {
          const Path v637_6 = concat_path(v635_6,v635_7_head);
          const Space v637_7 = routine_80(c, v637_6, v635_7_tail);
          v636_8 = compose(v636_5,v637_7);
        }
        const Space v636_9 = intersect(constant_1,v636_2);
        const Space v636_10 = (has_head(v636_9) ? constant_2 : Space{});
        Space v636_12;
        if (!v636_10.empty()) {
          const Path v638_6 = concat_path(v635_6,v635_7_head);
          const Space v638_11 = routine_81(c, v638_6, v635_7_tail);
          v636_12 = compose(v636_10,v638_11);
        }
        const Space v636_13 = unite(v636_8,v636_12);
        v635_7_result = unite(v635_7_result,v636_13);
      }
      const Space v635_7 = std::move(v635_7_result);
      v634_8 = compose(v634_5,v635_7);
    }
    const Space v634_9 = intersect(constant_1,v634_2);
    const Space v634_10 = (has_head(v634_9) ? constant_2 : Space{});
    const Space v634_11 = compose(v634_10,v633_8_tail);
    const Space v634_12 = unite(v634_8,v634_11);
    v633_8_result = unite(v633_8_result,v634_12);
  }
  const Space v633_8 = std::move(v633_8_result);
  return v633_8;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  Space v639_11_result;
  for (int v639_11_label = 1; v639_11_label <= 2; ++v639_11_label) {
    const Space v639_11_tail = child(s0,v639_11_label);
    if (v639_11_tail.empty()) continue;
    const Path v639_11_head{v639_11_label};
    const Space v640_2 = singleton(v639_11_head);
    const Space v640_3 = intersect(constant_1,v640_2);
    const Space v640_4 = (has_head(v640_3) ? constant_2 : Space{});
    const Space v640_5 = subtract(constant_0,v640_4);
    Space v640_8;
    if (!v640_5.empty()) {
      const Path v641_6 = concat_path(p0,v639_11_head);
      Space v641_7_result;
      for (int v641_7_label = 1; v641_7_label <= 2; ++v641_7_label) {
        const Space v641_7_tail = child(v639_11_tail,v641_7_label);
        if (v641_7_tail.empty()) continue;
        const Path v641_7_head{v641_7_label};
        const Space v642_2 = singleton(v641_7_head);
        const Space v642_3 = intersect(constant_1,v642_2);
        const Space v642_4 = (has_head(v642_3) ? constant_2 : Space{});
        const Space v642_5 = subtract(constant_0,v642_4);
        Space v642_8;
        if (!v642_5.empty()) {
          const Path v643_6 = concat_path(v641_6,v641_7_head);
          const Space v643_7 = routine_82(c, v643_6, v641_7_tail);
          v642_8 = compose(v642_5,v643_7);
        }
        const Space v642_9 = intersect(constant_1,v642_2);
        const Space v642_10 = (has_head(v642_9) ? constant_2 : Space{});
        Space v642_12;
        if (!v642_10.empty()) {
          const Path v644_6 = concat_path(v641_6,v641_7_head);
          const Space v644_11 = routine_83(c, v644_6, v641_7_tail);
          v642_12 = compose(v642_10,v644_11);
        }
        const Space v642_13 = unite(v642_8,v642_12);
        v641_7_result = unite(v641_7_result,v642_13);
      }
      const Space v641_7 = std::move(v641_7_result);
      v640_8 = compose(v640_5,v641_7);
    }
    const Space v640_9 = intersect(constant_1,v640_2);
    const Space v640_10 = (has_head(v640_9) ? constant_2 : Space{});
    Space v640_12;
    if (!v640_10.empty()) {
      const Path v645_6 = concat_path(p0,v639_11_head);
      Space v645_11_result;
      for (int v645_11_label = 1; v645_11_label <= 2; ++v645_11_label) {
        const Space v645_11_tail = child(v639_11_tail,v645_11_label);
        if (v645_11_tail.empty()) continue;
        const Path v645_11_head{v645_11_label};
        const Space v646_2 = singleton(v645_11_head);
        const Space v646_3 = intersect(constant_1,v646_2);
        const Space v646_4 = (has_head(v646_3) ? constant_2 : Space{});
        const Space v646_5 = subtract(constant_0,v646_4);
        Space v646_8;
        if (!v646_5.empty()) {
          const Path v647_6 = concat_path(v645_6,v645_11_head);
          const Space v647_7 = routine_82(c, v647_6, v645_11_tail);
          v646_8 = compose(v646_5,v647_7);
        }
        const Space v646_9 = intersect(constant_1,v646_2);
        const Space v646_10 = (has_head(v646_9) ? constant_2 : Space{});
        Space v646_12;
        if (!v646_10.empty()) {
          const Path v648_6 = concat_path(v645_6,v645_11_head);
          const Space v648_11 = routine_17(c, v648_6, v645_11_tail);
          v646_12 = compose(v646_10,v648_11);
        }
        const Space v646_13 = unite(v646_8,v646_12);
        v645_11_result = unite(v645_11_result,v646_13);
      }
      const Space v645_11 = std::move(v645_11_result);
      v640_12 = compose(v640_10,v645_11);
    }
    const Space v640_13 = unite(v640_8,v640_12);
    v639_11_result = unite(v639_11_result,v640_13);
  }
  const Space v639_11 = std::move(v639_11_result);
  return v639_11;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  Space v649_8_result;
  for (int v649_8_label = 1; v649_8_label <= 2; ++v649_8_label) {
    const Space v649_8_tail = child(s0,v649_8_label);
    if (v649_8_tail.empty()) continue;
    const Path v649_8_head{v649_8_label};
    const Space v650_2 = singleton(v649_8_head);
    const Space v650_3 = intersect(constant_1,v650_2);
    const Space v650_4 = (has_head(v650_3) ? constant_2 : Space{});
    const Space v650_5 = subtract(constant_0,v650_4);
    Space v650_8;
    if (!v650_5.empty()) {
      const Path v651_6 = concat_path(p0,v649_8_head);
      Space v651_7_result;
      for (int v651_7_label = 1; v651_7_label <= 2; ++v651_7_label) {
        const Space v651_7_tail = child(v649_8_tail,v651_7_label);
        if (v651_7_tail.empty()) continue;
        const Path v651_7_head{v651_7_label};
        const Space v652_2 = singleton(v651_7_head);
        const Space v652_3 = intersect(constant_1,v652_2);
        const Space v652_4 = (has_head(v652_3) ? constant_2 : Space{});
        const Space v652_5 = subtract(constant_0,v652_4);
        Space v652_8;
        if (!v652_5.empty()) {
          const Path v653_6 = concat_path(v651_6,v651_7_head);
          const Space v653_7 = routine_82(c, v653_6, v651_7_tail);
          v652_8 = compose(v652_5,v653_7);
        }
        const Space v652_9 = intersect(constant_1,v652_2);
        const Space v652_10 = (has_head(v652_9) ? constant_2 : Space{});
        Space v652_12;
        if (!v652_10.empty()) {
          const Path v654_6 = concat_path(v651_6,v651_7_head);
          const Space v654_11 = routine_83(c, v654_6, v651_7_tail);
          v652_12 = compose(v652_10,v654_11);
        }
        const Space v652_13 = unite(v652_8,v652_12);
        v651_7_result = unite(v651_7_result,v652_13);
      }
      const Space v651_7 = std::move(v651_7_result);
      v650_8 = compose(v650_5,v651_7);
    }
    const Space v650_9 = intersect(constant_1,v650_2);
    const Space v650_10 = (has_head(v650_9) ? constant_2 : Space{});
    const Space v650_11 = compose(v650_10,v649_8_tail);
    const Space v650_12 = unite(v650_8,v650_11);
    v649_8_result = unite(v649_8_result,v650_12);
  }
  const Space v649_8 = std::move(v649_8_result);
  return v649_8;
}

static Space routine_76(Context& c, const Path& p0, const Space& s0) {
  Space v655_4_result;
  for (int v655_4_label = 1; v655_4_label <= 2; ++v655_4_label) {
    const Space v655_4_tail = child(s0,v655_4_label);
    if (v655_4_tail.empty()) continue;
    const Path v655_4_head{v655_4_label};
    const Space v656_2 = singleton(v655_4_head);
    const Space v656_3 = intersect(constant_1,v656_2);
    const Space v656_4 = (has_head(v656_3) ? constant_2 : Space{});
    Space v656_7;
    if (!v656_4.empty()) {
      const Path v657_5 = concat_path(p0,v655_4_head);
      Space v657_6_result;
      for (int v657_6_label = 1; v657_6_label <= 2; ++v657_6_label) {
        const Space v657_6_tail = child(v655_4_tail,v657_6_label);
        if (v657_6_tail.empty()) continue;
        const Path v657_6_head{v657_6_label};
        const Space v658_2 = singleton(v657_6_head);
        const Space v658_3 = intersect(constant_1,v658_2);
        const Space v658_4 = (has_head(v658_3) ? constant_2 : Space{});
        Space v658_7;
        if (!v658_4.empty()) {
          const Path v659_5 = concat_path(v657_5,v657_6_head);
          const Space v659_6 = routine_14(c, v659_5, v657_6_tail);
          v658_7 = compose(v658_4,v659_6);
        }
        v657_6_result = unite(v657_6_result,v658_7);
      }
      const Space v657_6 = std::move(v657_6_result);
      v656_7 = compose(v656_4,v657_6);
    }
    v655_4_result = unite(v655_4_result,v656_7);
  }
  const Space v655_4 = std::move(v655_4_result);
  return v655_4;
}

static Space routine_77(Context& c, const Path& p0, const Space& s0) {
  Space v660_3_result;
  for (int v660_3_label = 1; v660_3_label <= 2; ++v660_3_label) {
    const Space v660_3_tail = child(s0,v660_3_label);
    if (v660_3_tail.empty()) continue;
    const Path v660_3_head{v660_3_label};
    const Space v661_2 = singleton(v660_3_head);
    const Space v661_3 = intersect(constant_1,v661_2);
    const Space v661_4 = (has_head(v661_3) ? constant_2 : Space{});
    const Space v661_5 = compose(v661_4,v660_3_tail);
    v660_3_result = unite(v660_3_result,v661_5);
  }
  const Space v660_3 = std::move(v660_3_result);
  return v660_3;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v662_4_result;
  for (int v662_4_label = 1; v662_4_label <= 2; ++v662_4_label) {
    const Space v662_4_tail = child(s0,v662_4_label);
    if (v662_4_tail.empty()) continue;
    const Path v662_4_head{v662_4_label};
    const Space v663_2 = singleton(v662_4_head);
    const Space v663_3 = intersect(constant_1,v663_2);
    const Space v663_4 = (has_head(v663_3) ? constant_2 : Space{});
    Space v663_7;
    if (!v663_4.empty()) {
      const Path v664_5 = concat_path(p0,v662_4_head);
      Space v664_6_result;
      for (int v664_6_label = 1; v664_6_label <= 2; ++v664_6_label) {
        const Space v664_6_tail = child(v662_4_tail,v664_6_label);
        if (v664_6_tail.empty()) continue;
        const Path v664_6_head{v664_6_label};
        const Space v665_2 = singleton(v664_6_head);
        const Space v665_3 = intersect(constant_1,v665_2);
        const Space v665_4 = (has_head(v665_3) ? constant_2 : Space{});
        Space v665_7;
        if (!v665_4.empty()) {
          const Path v666_5 = concat_path(v664_5,v664_6_head);
          const Space v666_6 = routine_17(c, v666_5, v664_6_tail);
          v665_7 = compose(v665_4,v666_6);
        }
        v664_6_result = unite(v664_6_result,v665_7);
      }
      const Space v664_6 = std::move(v664_6_result);
      v663_7 = compose(v663_4,v664_6);
    }
    v662_4_result = unite(v662_4_result,v663_7);
  }
  const Space v662_4 = std::move(v662_4_result);
  return v662_4;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  Space v667_3_result;
  for (int v667_3_label = 1; v667_3_label <= 2; ++v667_3_label) {
    const Space v667_3_tail = child(s0,v667_3_label);
    if (v667_3_tail.empty()) continue;
    const Path v667_3_head{v667_3_label};
    const Space v668_2 = singleton(v667_3_head);
    const Space v668_3 = intersect(constant_1,v668_2);
    const Space v668_4 = (has_head(v668_3) ? constant_2 : Space{});
    const Space v668_5 = compose(v668_4,v667_3_tail);
    v667_3_result = unite(v667_3_result,v668_5);
  }
  const Space v667_3 = std::move(v667_3_result);
  return v667_3;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0) {
  const Space v669_2 = Space{};
  return v669_2;
}

static Space routine_81(Context& c, const Path& p0, const Space& s0) {
  Space v670_3_result;
  for (int v670_3_label = 1; v670_3_label <= 2; ++v670_3_label) {
    const Space v670_3_tail = child(s0,v670_3_label);
    if (v670_3_tail.empty()) continue;
    const Path v670_3_head{v670_3_label};
    const Space v671_2 = singleton(v670_3_head);
    const Space v671_3 = intersect(constant_1,v671_2);
    const Space v671_4 = (has_head(v671_3) ? constant_2 : Space{});
    const Space v671_5 = compose(v671_4,v670_3_tail);
    v670_3_result = unite(v670_3_result,v671_5);
  }
  const Space v670_3 = std::move(v670_3_result);
  return v670_3;
}

static Space routine_82(Context& c, const Path& p0, const Space& s0) {
  const Space v672_2 = Space{};
  return v672_2;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v673_3_result;
  for (int v673_3_label = 1; v673_3_label <= 2; ++v673_3_label) {
    const Space v673_3_tail = child(s0,v673_3_label);
    if (v673_3_tail.empty()) continue;
    const Path v673_3_head{v673_3_label};
    const Space v674_2 = singleton(v673_3_head);
    const Space v674_3 = intersect(constant_1,v674_2);
    const Space v674_4 = (has_head(v674_3) ? constant_2 : Space{});
    const Space v674_5 = compose(v674_4,v673_3_tail);
    v673_3_result = unite(v673_3_result,v674_5);
  }
  const Space v673_3 = std::move(v673_3_result);
  return v673_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
